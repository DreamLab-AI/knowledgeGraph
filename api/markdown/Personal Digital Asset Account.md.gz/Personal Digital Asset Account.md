Personal accounts are individual user accounts that grant access to digital services, platforms, or financial instruments, uniquely associated with a natural person. In the context of digital assets and cryptocurrency, personal accounts include exchange accounts, self-custody wallets, and HMRC Self Assessment registrations through which an individual reports capital gains from asset disposals. Proper management of personal accounts intersects identity management, authentication, privacy, and tax compliance obligations.

Personal accounts are individually attributed user accounts providing access to digital services, financial platforms, or governmental systems, uniquely bound to a natural person's verified identity. They are the primary locus of credential management, authentication, and access-control enforcement. In the digital asset space, personal accounts span exchange trading accounts, self-custody wallets, and HMRC Self Assessment portals used to declare capital gains from cryptocurrency disposals.

### Semantic Classification

### Content

If you sold Bitcoin in the UK in **May 2025**, here is what you need to know about tax reporting:

- The UK tax year runs from **6 April 2024 to 5 April 2025**.
- As your sale occurred in May 2025, this falls in the **2025–2026 tax year** (6 April 2025 to 5 April 2026)[](https://koinly.io/guides/hmrc-cryptocurrency-tax-guide/).
- If you file your self-assessment **online**, you must report your crypto gains (and pay any tax due) by **31 January 2027**[](https://www.blockpit.io/tax-guides/crypto-tax-united-kingdom-hmrc)[](https://www.kraken.com/learn/uk-crypto-tax-guide)[](https://koinly.io/guides/hmrc-cryptocurrency-tax-guide/)[](https://www.ross-brooke.co.uk/what-we-do/capital-gains-tax/capital-gains-tax-reporting-residential-sales/).
- If you file with a **paper return**, the deadline is **31 October 2026**[](https://www.blockpit.io/tax-guides/crypto-tax-united-kingdom-hmrc)[](https://www.kraken.com/learn/uk-crypto-tax-guide)[](https://koinly.io/guides/hmrc-cryptocurrency-tax-guide/).
- Most individuals file online.
- You must report all taxable gains for the 2025–2026 tax year, including those from Bitcoin sales, using the **Self Assessment tax return**.
- If your total capital gains for the tax year exceed the Annual Exempt Amount (£3,000 for 2025–26), tax will be owed; even if below, you may still need to report if your proceeds are high or you are already in Self Assessment[](https://www.blockpit.io/tax-guides/crypto-tax-united-kingdom-hmrc)[](https://koinly.io/guides/hmrc-cryptocurrency-tax-guide/).
- Register for Self Assessment (if not already registered).
- Complete the Capital Gains Summary section, including your Bitcoin transaction(s).
- Submit digitally by the deadline and pay tax owed by the same date[](https://www.blockpit.io/tax-guides/crypto-tax-united-kingdom-hmrc)[](https://www.kraken.com/learn/uk-crypto-tax-guide)[](https://koinly.io/guides/hmrc-cryptocurrency-tax-guide/).
  | Event | Sale Date | Tax Year | Deadline (Online Return) |
  | ---- | ---- | ---- |
  | Bitcoin Sale | May 2025 | 2025–2026 | 31 January 2027[](https://koinly.io/guides/hmrc-cryptocurrency-tax-guide/)[](https://www.ross-brooke.co.uk/what-we-do/capital-gains-tax/capital-gains-tax-reporting-residential-sales/) |

  ## When to Report UK Bitcoin Sales for Tax as an Individual

## Tax Year and Reporting Period

## Reporting Deadline

## Which Gains to Report

## How to Report

## Summary Table

### Provenance

