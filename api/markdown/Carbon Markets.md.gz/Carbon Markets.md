Carbon markets are regulated or voluntary trading systems in which carbon credits or allowances — each representing one metric tonne of CO₂ equivalent avoided, reduced, or removed — are issued, bought, sold, and retired to place a price on greenhouse gas emissions and channel investment towards least-cost mitigation activities. Compliance markets operate under mandatory emissions-trading schemes (ETS) such as the EU ETS, California Cap-and-Trade, and the Article 6 mechanisms of the Paris Agreement, where regulated emitters must surrender allowances matching verified output. Voluntary carbon markets (VCMs) allow organisations and individuals outside regulatory caps to purchase independently verified credits from projects ranging from avoided deforestation to direct air capture, enabling net-zero and carbon-neutrality claims. Market integrity depends on robust project standards, third-party verification, transparent registry infrastructure, and governance frameworks to prevent double counting and ensure additionality.

### Overview

- Carbon markets are the primary market-based policy instrument for pricing [[Greenhouse Gas Emissions]] and redirecting capital towards [[Emissions Reduction]] activities. By internalising the cost of carbon into business decision-making, they create incentives to decarbonise at least cost across an economy, complementing regulatory standards and [[Carbon Tax|carbon taxes]].
- The theoretical foundation derives from Ronald Coase's 1960 work on externalities and was operationalised in the US EPA's Acid Rain Programme (1990), which demonstrated that tradeable SO₂ allowances could achieve pollution targets at significantly lower economic cost than uniform command-and-control regulations.
- Two principal market types exist:
  - **Compliance markets**: legally mandatory schemes where regulated emitters must balance their emissions with allowances or verified credits. Examples include the [[EU Emissions Trading System]] (world's largest, covering power, industry, and aviation), California Cap-and-Trade, the UK ETS, and emerging schemes in China, South Korea, and Canada.
  - **Voluntary carbon markets**: optional markets where corporates, financial institutions, and individuals purchase credits to meet self-imposed climate targets or as a supplement to compliance obligations. Governed by private standards rather than statute.
- Market price signals serve as indicators of the marginal cost of abatement and guide investment in renewable energy, energy efficiency, nature-based solutions, and engineered carbon removal.

### Key Mechanisms

#### Cap-and-Trade

- A regulator sets a declining total cap on covered emissions; allowances representing fractions of that cap are distributed (via free allocation or auction) to regulated entities.
- Entities with surplus allowances may sell them; those with deficits must buy. The cap ensures an environmental ceiling; trading ensures cost-efficiency.
- Price discovery emerges from supply-demand dynamics, creating a [[Carbon Price Discovery]] mechanism. Banking and borrowing rules govern inter-period flexibility.

#### Baseline-and-Credit (Project Mechanisms)

- A project proponent establishes a counterfactual baseline (what emissions would have been without the project) and earns credits equal to verified reductions relative to that baseline.
- Requires rigorous [[Additionality Assessment]] — demonstrating the project would not have occurred without carbon finance — and permanence guarantees.
- Used in both the [[Clean Development Mechanism]] (Kyoto Protocol) and modern VCM project standards.

#### Offsetting

- Entities purchase [[Carbon Offset|carbon offsets]] from verified projects to compensate for residual emissions they cannot yet eliminate. Credits must be retired in a [[Carbon Registry]] to prevent double use.
- Offset quality is assessed against additionality, measurability, permanence, and avoidance of leakage — i.e. emissions shifting to unregulated activities elsewhere.

#### Article 6 International Mechanisms

- Article 6 of the [[Paris Agreement]] establishes cooperative approaches (Article 6.2 bilateral trades via Internationally Transferred Mitigation Outcomes — ITMOs) and a centralised multilateral crediting mechanism (Article 6.4, successor to the CDM), enabling sovereign carbon trading across national borders.
- Corresponding adjustments ensure that credits transferred between countries are not counted twice in nationally determined contributions (NDCs).

### Key Standards and Verification Bodies

- [[Verified Carbon Standard]] (VCS, administered by Verra): the largest voluntary standard by issuance, covering avoided deforestation (REDD+), renewable energy, agriculture, and industrial projects.
- [[Gold Standard]]: established by WWF, emphasises sustainable development co-benefits alongside emissions reductions; widely used in cookstove and clean energy projects.
- [[American Carbon Registry]] (ACR): independent standard operating in both voluntary and compliance contexts.
- [[Climate Action Reserve]] (CAR): US-focused, often used for compliance offset programmes in California.
- [[Core Carbon Principles]] (ICVCM): meta-standard published by the [[Integrity Council for the Voluntary Carbon Market]], defining minimum quality thresholds across all voluntary methodologies.
- [[Science Based Targets initiative]] (SBTi): prescribes how corporates should limit offset use within science-aligned decarbonisation pathways.
- [[CORSIA]]: the Carbon Offsetting and Reduction Scheme for International Aviation, administered by ICAO; mandates airlines to offset growth in emissions above 2020 baseline levels using approved credits.

### Applications and Use Cases

- **Corporate net-zero compliance**: organisations purchase and retire VCM credits to neutralise residual emissions after exhausting direct abatement measures, enabling credible [[Net Zero Targets]] claims.
- **Regulatory compliance**: heavy industry, power generators, and airlines surrender allowances under mandatory ETS schemes to comply with emissions caps.
- **Project finance for mitigation**: carbon revenue streams (from credit sales) provide the financial viability for renewable energy, methane capture, reforestation, and blue carbon (mangrove, seagrass) projects in developing economies.
- **Climate finance channelling**: [[Climate Finance]] flows from developed to developing countries are partially intermediated via carbon credits, supporting [[Sustainable Development Goals]] alignment.
- **Carbon Border Adjustment**: the EU's [[Carbon Border Adjustment Mechanism]] (CBAM) applies the EU ETS carbon price to imports of carbon-intensive goods (steel, cement, aluminium, fertilisers, hydrogen), preventing [[Carbon Leakage]].
- **Blockchain tokenisation**: [[Carbon Credit Token|tokenised carbon credits]] on distributed ledgers enable fractional ownership, automated retirement, and transparent audit trails, bridging carbon markets to [[Decentralised Finance]] infrastructure.
- **Nature-based solutions financing**: carbon market revenues fund [[Forest Conservation]], [[Blue Carbon]], soil carbon sequestration, and biodiversity co-benefit projects.
- **Price signal for energy transition**: high ETS carbon prices improve the competitive economics of low-carbon technologies including [[Carbon Capture and Storage]], green hydrogen, and industrial electrification.

### Standards and Governance Context

- The [[United Nations Framework Convention on Climate Change]] (UNFCCC) provides the overarching legal framework within which Article 6 mechanisms operate.
- The [[EU Emissions Trading System]] entered Phase 4 (2021–2030) with an annual cap reduction rate of 2.2% per year and a Market Stability Reserve to manage allowance oversupply.
- [[CORSIA]] applies from 2024 onwards (mandatory phase), requiring airlines to offset net international aviation emissions growth above 2020 baselines.
- The [[Integrity Council for the Voluntary Carbon Market]] (ICVCM) published its [[Core Carbon Principles]] to set a global quality benchmark for voluntary credits, addressing the credibility concerns raised by investigative reporting into REDD+ over-crediting in 2023.
- The [[Taskforce on Scaling Voluntary Carbon Markets]] (TSVCM) and successor body the [[Voluntary Carbon Markets Integrity Initiative]] (VCMI) are developing demand-side guidance on credible corporate use of carbon credits.
- [[ISO 14064]] series provides internationally recognised standards for [[Carbon Accounting]] and greenhouse gas inventories at the organisational and project level.
- The Financial Stability Board and regulators in the EU (MiCA, ESG disclosure requirements) are developing frameworks for oversight of tokenised carbon instruments.

### Challenges and Criticisms

- **Additionality and over-crediting**: concerns that some project types (particularly avoided deforestation / [[REDD+]]) overstate counterfactual emissions baselines, issuing more credits than actual sequestration.
- **Permanence risk**: forestry credits are vulnerable to reversal through wildfires, drought, or land-use change; buffer pools and insurance mechanisms partially address this.
- **Carbon leakage**: emissions may shift to jurisdictions without carbon pricing, undermining aggregate environmental effectiveness. [[Carbon Border Adjustment Mechanism]] is a policy response.
- **Price volatility**: ETS prices fluctuate significantly in response to energy price shocks, policy uncertainty, and macroeconomic conditions, complicating long-term decarbonisation investment decisions.
- **Double counting**: without robust corresponding adjustment rules and registry linkage, the same tonne of reduction could be claimed by both buyer and host country towards their NDC.
- **Corporate greenwashing**: critics argue that offset purchasing delays direct emissions reduction; the [[Science Based Targets initiative]] and VCMI seek to restrict offsets to residual and hard-to-abate emissions.
- **Market fragmentation**: multiple competing standards, registries, and jurisdictions create interoperability challenges and complicate cross-border trading under Article 6.

### Provenance

