Digital Preservation is the managed set of processes, standards, and technologies applied to ensure that digital objects remain accessible, authentic, and usable over extended time periods, spanning decades or centuries. It encompasses format migration, bit-level integrity verification via checksumming, redundant and geographically distributed storage, and comprehensive provenance tracking through metadata standards such as OAIS and PREMIS. Effective digital preservation requires active management of hardware and software obsolescence, format dependency chains, and institutional policy frameworks that together prevent the loss or corruption of cultural, scientific, and organisational digital assets. It is distinguished from simple backup by its explicit concern with long-term interpretability and authenticity rather than mere bit-level recovery.

### Overview

- Digital preservation addresses a fundamental challenge of the information age: digital objects are inherently fragile. They depend on specific hardware, software, file formats, and operating systems — all of which become obsolete on timescales far shorter than the cultural and scientific value of the content.
- Unlike analogue materials whose degradation is physically visible, digital obsolescence is often silent: a file may be present but unreadable if the software required to interpret it no longer exists.
- The discipline draws from library science, archival theory, information systems engineering, and cryptography, making it inherently interdisciplinary.
- Key preservation threats include:
  - **Bit rot**: gradual corruption of storage media without active [[Data Integrity]] checking.
  - **Format obsolescence**: proprietary or poorly documented [[File Format]] specifications becoming undecodable.
  - **Software dependency**: applications and codecs required to render content being discontinued.
  - **Metadata loss**: loss of context that makes content interpretable even when bits survive.
  - **Organisational discontinuity**: institutions ceasing to maintain collections.
- Active preservation is therefore distinguished from passive storage: it requires ongoing monitoring, periodic migration, and institutional commitment.

### Key Components

#### Bit-Level Integrity

- [[Checksum Verification]] using cryptographic hash functions (MD5, SHA-256) to detect silent data corruption on storage media.
- Fixity information is recorded at ingest and periodically re-verified against stored content.
- Tools: BagIt specification, Fixity auditing software, PREMIS rights metadata.

#### Format Management

- [[Format Migration]] converts content from obsolete or at-risk formats to stable, well-documented equivalents (e.g. TIFF for images, PDF/A for documents, FLAC for audio).
- Format registries such as PRONOM (UK National Archives) and UDFR provide authoritative [[Metadata Standard]] for format identification.
- Emulation as an alternative to migration: preserving original software environments via [[Virtual Machine]] or emulator to run legacy applications.

#### Metadata and Provenance

- Descriptive metadata identifies what an object is; structural metadata describes its internal organisation; administrative metadata captures rights, provenance, and preservation actions.
- [[PREMIS Metadata Standard]] (Preservation Metadata: Implementation Strategies) defines a data dictionary for preservation-specific metadata events and rights.
- [[Provenance Tracking]] records the chain of custody and all transformations applied to an object.

#### Storage Infrastructure

- LOCKSS (Lots of Copies Keep Stuff Safe) principle: geographically distributed, independently managed copies resist localised failure.
- [[Distributed Storage]] systems, including RAID arrays, tape libraries, and cloud object stores, are layered to achieve resilience.
- Increasingly, [[Content-Addressable Storage]] (e.g. IPFS) is used so that content can be retrieved by its cryptographic hash, intrinsically linking identity to integrity.

#### Institutional Policy and Governance

- Preservation policies define scope, selection criteria, retention schedules, and acceptable formats.
- Trusted Digital Repository (TDR) certification (ISO 16363 / CoreTrustSeal) provides third-party audit of organisational and technical capability.
- [[Information Lifecycle Management]] frameworks integrate preservation decisions with broader records management.

#### Emerging Technologies

- [[Blockchain]] provides immutable, tamper-evident logs of preservation events and chain-of-custody records without reliance on a central authority.
- [[Smart Contract]] automation can trigger format migration or integrity checks on schedule.
- [[Decentralised Storage]] networks (Filecoin, Arweave) offer cryptoeconomic incentives for long-term storage without centralised infrastructure.
- [[Knowledge Graph]] representations of preserved objects and their relationships enable richer semantic discovery across collections.

### Applications and Use Cases

#### Libraries and Archives

- National archives (UK National Archives, Library of Congress, Europeana) operate large-scale digital preservation programmes covering digitised manuscripts, government records, born-digital publications, and web archives.
- Legal deposit legislation in many jurisdictions mandates preservation of digital publications.

#### Scientific Research Data

- Research funders (UKRI, NSF, Horizon Europe) require data management plans specifying how datasets will be preserved and made accessible beyond the life of a project.
- Disciplines with large-scale datasets (genomics, astronomy, climate science) require specialised preservation workflows integrated with [[Data Management]] pipelines.

#### Cultural Heritage and Museums

- [[Cultural Heritage Management]] institutions preserve digitised artworks, 3D scans of artefacts, and born-digital creative works.
- Video game preservation (e.g. Software Preservation Network) addresses the unique challenges of interactive software.

#### Government and Legal Records

- Electronic records management in government requires preservation in formats admissible as legal evidence.
- Court records, parliamentary proceedings, and administrative documents have long statutory retention requirements.

#### Audiovisual and Broadcasting

- Broadcasters preserve news footage, documentary archives, and historical programme material.
- The complexity of video codecs, subtitle streams, and rights metadata makes audiovisual preservation particularly challenging.

#### Software Preservation

- Organisations such as the Internet Archive and Software Preservation Network maintain runnable copies of historical software.
- Emulation-as-a-Service platforms allow access to legacy software through web browsers without local installation.

#### Digital Asset Management for Enterprises

- Commercial [[Digital Asset Management]] platforms incorporate preservation-grade features for brand assets, product documentation, and multimedia content.

### Standards and Governance Context

#### OAIS Reference Model (ISO 14721)

- The Open Archival Information System reference model defines a conceptual framework for a digital archive, specifying functional entities (ingest, archival storage, data management, administration, preservation planning, access) and information packages (SIP, AIP, DIP).
- Adopted as the foundational standard by virtually all major digital preservation initiatives globally.

#### PREMIS

- The PREMIS Data Dictionary (maintained by the Library of Congress) provides standardised vocabulary and schema for preservation metadata, covering objects, events, agents, and rights.
- Version 3 introduced linked data compatibility, enabling integration with [[Knowledge Graph]] representations.

#### Trusted Digital Repository Certification

- ISO 16363 (audit and certification) and CoreTrustSeal provide frameworks for third-party assessment of repository trustworthiness.
- Extended by NESTOR (Germany) and Data Seal of Approval (Netherlands).

#### BagIt

- IETF RFC 8493 specifies the BagIt packaging format for reliable transfer and storage of arbitrary digital content with embedded fixity information.
- Widely used for inter-institutional transfers and submission to preservation systems.

#### Linked Data and Semantic Web

- Standards organisations including W3C PROV-O (provenance ontology) and Dublin Core provide vocabularies that integrate with [[Metadata Standard]] frameworks.
- Semantic representations enable cross-institutional discovery and interoperability.

#### Relevant Bodies

- Digital Preservation Coalition (DPC) — UK-led international membership body providing guidance, advocacy, and the Digital Preservation Handbook.
- Coalition for Networked Information (CNI), NDSA (National Digital Stewardship Alliance), nestor (Germany).
- ISO TC46/SC11 (Archives/Records Management) produces the core standards.

### Semantic Classification

- **domain-remap:** spatial-computing → infrastructure (digital preservation is a data management and infrastructure concern, not spatially specific)

### Provenance

