A Token Bridge is a protocol that enables the transfer of token value or representation between two distinct blockchain networks that cannot natively communicate. It commonly locks or burns tokens on the source chain and mints or releases an equivalent representation on the destination chain, coordinated by validators, relayers or light-client proofs. Token bridges are a core mechanism for cross-chain liquidity but historically a significant locus of security risk.

### Overview

- Token bridges connect otherwise isolated blockchains so that value can move between them. The dominant pattern is lock-and-mint: tokens are escrowed on the origin chain while a wrapped representation is minted on the target chain, redeemable by burning the wrapper. Designs differ in their trust model, ranging from externally verified multisignature custodians to natively verified light-client and zero-knowledge proof systems.

### Key aspects

- Lock-and-mint and burn-and-release transfer patterns
- Trust models from external multisig to native light clients
- Relayers and validators attesting cross-chain events
- Wrapped token representations on destination chains
- Security surface targeted in major bridge exploits

### Mechanisms

- Lock-and-mint and burn-and-release transfer patterns
- Trust models from external multisig to native light clients
- Relayers and validators attesting cross-chain events

### Applications

- Moving stablecoins and assets across chains
- Supplying cross-chain liquidity to decentralised exchanges
- Enabling multi-chain decentralised applications
- Bridging assets to lower-fee execution layers
- Connecting layer-1 and layer-2 ecosystems

### Provenance

