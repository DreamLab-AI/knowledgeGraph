Skinning is the process of binding a deformable surface mesh to an underlying skeleton so that the mesh deforms naturally as the skeleton is animated. Each vertex is assigned weights that determine how strongly it follows each influencing bone, and these weights drive the deformation during playback. Skinning is essential to character animation, allowing a single rigged model to be posed and animated across many motions.

- Skinning is the process of binding a deformable surface [[Polygon Mesh]] to an underlying skeleton so the mesh deforms naturally as the skeleton is animated.
- Each vertex is assigned weights that determine how strongly it follows each influencing bone.
- It is the deformation half of [[Character Rigging]], complementing the skeletal hierarchy.
- It is essential to [[Character Animation]], letting one rigged model play many motions.

### Overview

- After a [[Character Model]] is built and a skeleton placed inside it, skinning attaches the visible surface to the bones so that movement of the skeleton drives movement of the mesh.
- The most common technique, linear blend skinning, computes each deformed vertex as a weighted average of the transforms of its influencing bones. It is fast and ubiquitous in real-time engines.
- Linear blend skinning suffers from artefacts such as the candy-wrapper collapse at twisting joints; dual quaternion skinning mitigates these at greater computational cost.
- Skin weights may be painted manually by artists or generated automatically through heat-diffusion and geodesic methods, then refined for clean deformation.

### Key aspects

- Vertex-to-bone weight assignment, usually normalised per vertex.
- Bind pose definition establishing the rest state.
- Linear blend versus dual quaternion deformation.
- Weight painting and automatic weight generation.
- Influence limits for real-time performance budgets.

### Mechanisms

- Computation of deformed vertex positions from weighted bone transforms.
- GPU skinning in vertex shaders for real-time playback.
- Corrective blend shapes layered on top of skeletal deformation.
- Export of skin clusters through interchange formats such as FBX.

### Applications

- Character animation in games and real-time experiences.
- Digital human and avatar deformation in spatial computing.
- Film and visual effects creature animation.
- Procedural and motion-captured performance retargeting.

### Provenance

