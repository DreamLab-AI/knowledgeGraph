Application software that constructs, parameterises, and executes computational models of physical, biological, social, or engineered systems, enabling controlled experimentation and behaviour observation across time steps without manipulating real-world systems. Simulation software encompasses physics engines, agent-based modelling frameworks, discrete-event simulators, and real-time digital twin environments, serving domains ranging from aerospace engineering and molecular biology to urban planning and immersive training. Unlike general-purpose scientific computing, simulation software provides domain-specific abstraction layers, visualisation pipelines, and scenario management tools that allow non-specialists to configure and run experiments at scale. The field intersects spatial computing, machine learning, and high-performance computing as simulations grow to planetary scale and real-time fidelity.

### Overview

- Simulation software abstracts the complexity of real systems into mathematical and logical representations that can be executed on computing hardware, producing observable, measurable outputs under user-controlled conditions.
- It matters because physical experimentation is often impossible, dangerous, prohibitively expensive, or too slow — simulating a crash test, a drug interaction, a climate scenario, or a supply chain disruption costs a fraction of the real equivalent.
- At its core, a simulation loop consists of:
  - A **model** — the formal representation of entities, rules, and state transitions
  - A **solver** or **engine** — the numerical or logical machinery that advances the model through time steps or event queues
  - A **scenario manager** — tools to specify initial conditions, inject perturbations, and parameterise sweeps
  - A **visualisation pipeline** — rendering of state data into interpretable 2D/3D output
  - A **data logger** — capturing trajectories and outputs for post-hoc analysis
- As [[High-Performance Computing]] and [[GPU Compute]] have become widely accessible, simulations have scaled from desktop experiments to planet-scale models running on supercomputer clusters or cloud infrastructure.

### Key Components

#### Simulation Engines

- [[Simulation Engine]] — the runtime that advances model state; may be time-stepped (continuous) or event-driven (discrete)
- [[Physics Engine]] — rigid-body dynamics, soft-body, fluid simulation (e.g. PhysX, Bullet, Havok); critical for physically accurate virtual worlds
- [[Numerical Solver]] — integrators (Euler, Runge-Kutta, Verlet) and linear-algebra backends that compute state transitions

#### Modelling Paradigms

- [[Agent-Based Modelling]] — populations of autonomous agents following local rules; emergent macro behaviour arises from micro interactions (e.g. NetLogo, Mesa, AnyLogic)
- [[Discrete Event Simulation]] — state changes triggered by discrete events on a calendar queue; standard for logistics, manufacturing, and network modelling (e.g. SimPy, Arena, AnyLogic)
- [[Finite Element Analysis]] — mesh-based approximation of PDEs for structural, thermal, and electromagnetic domains (e.g. ANSYS, Abaqus, OpenFOAM)
- [[Monte Carlo Method]] — stochastic sampling to approximate distributions and quantify uncertainty (used across finance, nuclear physics, epidemiology)
- [[System Dynamics]] — stock-and-flow models of feedback-rich systems at aggregate level (e.g. Vensim, Stella)

#### Infrastructure

- [[GPU Compute]] — massively parallel hardware essential for real-time physics, ray tracing, and ML-accelerated simulation
- [[Rendering Engine]] — converts geometry and material data into visualisable frames; real-time (Unreal, Unity) or offline (Blender Cycles, NVIDIA Omniverse)
- [[High-Performance Computing]] — cluster or cloud execution for large-scale sweeps and Monte Carlo ensembles
- [[Data Logger]] — time-series and event capture feeding post-processing, ML training, and audit trails

#### Outputs and Artefacts

- [[Synthetic Data Generation]] — simulation as a source of labelled training data for [[Machine Learning Pipeline]]s
- [[Scenario Manager]] — parameterised experiment definition, sensitivity analysis, and factorial sweeps
- [[Visualisation Pipeline]] — 2D plots, 3D real-time rendering, and immersive [[XR Training]] environments

### Applications and Use Cases

#### Engineering and Science

- **Aerospace and Defence** — aerodynamic CFD, flight simulators, mission rehearsal; simulation reduces physical prototyping costs by orders of magnitude
- **Automotive** — crash simulation via FEA, virtual homologation, [[Autonomous Vehicle Testing]] in simulation before road trials (NVIDIA DRIVE Sim, CARLA, Waymo Simulation)
- **Civil and Structural** — building information modelling linked to FEA for seismic, wind, and thermal performance
- **[[Climate Modelling]]** — coupled atmosphere-ocean models (e.g. CESM, OpenIFS) running on HPC grids to project climate trajectories
- **Drug Discovery** — molecular dynamics (GROMACS, AMBER) simulating protein folding and ligand binding

#### Industry and Operations

- **Manufacturing** — factory layout optimisation via discrete-event simulation; robot path planning; digital-twin-driven predictive maintenance
- **Supply Chain** — disruption modelling, demand variability, inventory optimisation through agent-based and DES tools
- **Energy** — grid stability, renewable integration, and nuclear reactor neutronics

#### AI and Robotics

- **Reinforcement Learning** — sim-to-real pipelines (Isaac Gym, MuJoCo, PyBullet, Brax) training agents in simulation before physical deployment
- **[[Synthetic Data Generation]]** — photorealistic rendered datasets for computer vision (NVIDIA Omniverse Replicator, BlenderProc)
- **Robotics** — kinematic and dynamic simulation for robot design and motion planning

#### Immersive and Spatial Computing

- **[[XR Training]]** — medical, military, and industrial training in photorealistic simulated environments
- **[[Digital Twin]]** — operational mirrors of physical infrastructure; live data feeds update simulation state in near-real-time
- **Metaverse** — persistent shared virtual worlds underpin their physics and social dynamics with simulation runtimes

### Standards and Context

- **IEEE 1516 (HLA — High Level Architecture)** — federation standard for distributed simulation interoperability, enabling multiple simulators to exchange state data in real time
- **SISO (Simulation Interoperability Standards Organisation)** — body maintaining HLA, DIS (Distributed Interactive Simulation), and TENA standards
- **Modelica** — open equation-based modelling language for multi-domain physical systems; underpins tools such as Dymola and OpenModelica
- **FMI/FMU (Functional Mock-up Interface)** — industry standard (Modelica Association) for simulator co-simulation and model exchange across toolchains
- **SysML / MBSE** — [[Model-Based Systems Engineering]] practice that treats simulation models as first-class system-specification artefacts
- **OpenUSD** — NVIDIA/Pixar scene-description standard adopted by NVIDIA Omniverse and increasingly by simulation platforms as an interchange format for 3D simulation environments
- Regulatory contexts in aerospace (DO-178C for software qualification), automotive (ISO 26262, SOTIF), and nuclear (NQA-1) mandate verified simulation as part of the safety case

### Prominent Platforms

- **NVIDIA Omniverse / Isaac Sim** — USD-based platform for robotics simulation, synthetic data, and digital twins
- **MathWorks Simulink / MATLAB** — industry-standard continuous and discrete simulation with code generation
- **Siemens Simcenter** — multi-physics simulation suite for FEA, CFD, and 1D systems
- **AnyLogic** — multi-method platform supporting DES, ABM, and system dynamics in a single model
- **Unreal Engine / Unity** — real-time 3D engines repurposed for high-fidelity simulation, training, and synthetic data
- **OpenFOAM** — open-source CFD simulation widely used in academia and industry
- **CARLA / NVIDIA DRIVE Sim** — autonomous vehicle simulation environments with sensor modelling and scenario scripting
- **MuJoCo / PyBullet / IsaacGym / Brax** — physics simulators optimised for [[Reinforcement Learning]] training pipelines

### Provenance

