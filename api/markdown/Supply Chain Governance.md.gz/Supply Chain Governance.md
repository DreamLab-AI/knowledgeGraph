Supply chain governance is the set of means by which a buyer or lead firm steers the behaviour of the firms in its supply network, and the sources opened here treat it in two ways that are related but not the same: as a theory of value chain structure and as a practice of codes, audits and standards.[^1][^2]

## Governance in value chain theory

Gereffi, Humphrey and Sturgeon build a theoretical framework to help explain governance patterns in global value chains.[^1] Their theory generates five types of governance, hierarchy, captive, relational, modular and market, which range from high to low levels of explicit coordination and power asymmetry.[^1] They note that such networks are frequently characterised by a high degree of monitoring and control by lead firms.[^1] The text opened is the 2003 pre-publication version.

## Governance by codes and standards

The UN Global Compact and BSR guide describes a supplier code of conduct as, for many companies, a natural extension of corporate values statements and an affirmation of existing expectations rather than a new set of requirements.[^2] See [[Supplier Code of Conduct]]. The Responsible Business Alliance calls its Code of Conduct a set of social, environmental and ethical industry standards that reference international norms.[^3]

Verification is by audit. The Global Compact guide gives an example of audits based on the SA8000 standard and carried out by specialised, independent third-party auditors in the local language.[^2] Social Accountability International says accreditation, or oversight by a credible and authorised independent third party, ensures that social audits are undertaken impartially, competently and effectively.[^4] See [[SA8000]].

## Scope and limits

Governance by codes and audits sits within [[Sustainable Supply Chains]] and underlies [[Supply Chain Due Diligence]] and [[Sustainable Procurement]]. Gereffi and colleagues' types describe how coordination is organised; they do not discuss codes and audits in the passages opened, so the two bodies of work are linked here by topic only. No opened source measures whether code-and-audit governance improves outcomes for workers or the environment.

[^1]: Gary Gereffi, John Humphrey and Timothy Sturgeon, Review of International Political Economy (pre-publication version of 4 November 2003, Duke University site), “The Governance of Global Value Chains”. https://www.soc.duke.edu/sloan_2004/Papers/governance_of_gvcs_final.pdf
[^2]: United Nations Global Compact and Business for Social Responsibility, 2010, “Supply Chain Sustainability: A Practical Guide for Continuous Improvement”. https://www.bsr.org/reports/BSR_UNGC_SupplyChainReport.pdf
[^3]: Responsible Business Alliance, Code of Conduct. https://www.responsiblebusiness.org/code-of-conduct/
[^4]: Social Accountability International (SAI), SA8000 Standard. https://sa-intl.org/programs/sa8000/

