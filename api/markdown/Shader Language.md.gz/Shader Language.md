A Shader Language is a domain-specific programming language designed to express GPU-executable programs that control one or more programmable stages of a graphics or compute pipeline. Shader languages provide specialised type systems encompassing vectors, matrices, samplers, and atomic types, while deliberately restricting features incompatible with massively parallel execution such as dynamic memory allocation and unbounded recursion. Major production languages include GLSL (OpenGL Shading Language) for OpenGL and WebGL, HLSL (High-Level Shading Language) for DirectX, Metal Shading Language for Apple silicon and macOS/iOS platforms, and the emerging WGSL (WebGPU Shading Language) for the web-native WebGPU API. Modern shader toolchains commonly cross-compile to the hardware-agnostic intermediate representation SPIR-V, enabling portability across vendors and runtime environments.

### Overview

- Shader languages emerged in the early 2000s as graphics hardware evolved from fixed-function pipelines to fully programmable ones. [[OpenGL]] introduced the [[GLSL]] (OpenGL Shading Language) specification with version 2.0 (2004), giving developers explicit control over vertex transformation and fragment colouring. Microsoft simultaneously developed [[HLSL]] (High-Level Shading Language) as the shader lingua franca for [[DirectX]]. Both languages remain the dominant choices for desktop and console [[Real-Time Rendering]] today.
- The significance of shader languages extends well beyond aesthetics. They are the primary mechanism by which rendering quality features — [[Physically Based Rendering]], global illumination, shadow algorithms, post-processing effects — are specified and iterated upon in production. More recently, [[Compute Shader]] stages have extended shader languages into general [[GPU Compute]] territory, overlapping significantly with [[GPGPU]] workloads once reserved for [[OpenCL C]] or [[CUDA]].
- Web graphics added a further tier: [[WebGL]] adopted a restricted GLSL ES subset, and the successor [[WebGPU]] API defines [[WGSL]] (WebGPU Shading Language) as its native shader language — a more formally specified, safer language designed with the memory-safety requirements of browser sandboxing in mind.
- The rise of [[SPIR-V]] as a vendor-neutral IR has decoupled shader authoring from the target runtime: tools like glslang, DXC, and Naga can translate GLSL, HLSL, or WGSL into SPIR-V, which [[Vulkan]], [[OpenCL]], and WebGPU drivers then consume.

### Key Components

- **Programmable Pipeline Stages** — each stage corresponds to a distinct shader type:
  - [[Vertex Shader]] — transforms per-vertex attributes (position, normal, UV) from object space into clip space; executes once per input vertex.
  - [[Fragment Shader]] (also called Pixel Shader in HLSL nomenclature) — computes the final colour of a rasterised fragment; primary home of lighting and texturing logic.
  - [[Geometry Shader]] — optional stage that receives assembled primitives and can emit new geometry; used for effects like particle expansion, shadow-volume extrusion.
  - [[Tessellation Shader]] — subdivides coarse surface patches into finer geometry at runtime; enables level-of-detail and smooth curved surfaces.
  - [[Compute Shader]] — executes arbitrary parallel workloads without fixed pipeline wiring; key to [[GPU Compute]], simulation, and machine-learning inference on the GPU.
  - [[Mesh Shader]] — newer NVIDIA/DirectX 12 Ultimate stage that replaces vertex + geometry with a flexible meshlet-based model for efficient culling of large scenes.
  - [[Ray Generation Shader]], closest-hit, any-hit, and miss shaders — introduced by [[DirectX Raytracing]] (DXR) and [[Vulkan Ray Tracing]] to support [[Ray Tracing]] pipelines.
- **Type System** — built-in scalar (float, int, bool), vector (vec2/vec3/vec4 in GLSL; float2/float3/float4 in HLSL), matrix (mat4/float4x4), and sampler types (sampler2D, TextureCube). Structured buffer and storage image types appear in compute contexts.
- **Built-in Functions** — trigonometric (sin, cos, atan), linear-algebraic (dot, cross, normalize, reflect, refract), texture-sampling (texture, textureLod, textureGather), and derivative (dFdx, dFdy) intrinsics expose GPU-native operations unavailable in software at comparable performance.
- **Qualifier / Attribute System** — in/out/uniform/varying qualifiers control data flow between CPU, pipeline stages, and framebuffer; layout qualifiers specify binding points, descriptor sets, and memory layout (std140, std430).
- **Preprocessor and Conditionals** — C-style `#define`, `#ifdef`, `#pragma` preprocessors enable [[Shader Permutation]] management (material variants, platform switching).
- **Intermediate Representation** — [[SPIR-V]] (Standard Portable Intermediate Representation — Vulkan) is the binary IR to which GLSL and HLSL are commonly compiled, enabling offline validation, reflection, and hardware-agnostic distribution.

### Applications and Use Cases

- **Game Engines** — [[Unity]] uses HLSL-like ShaderLab and HLSL via its Scriptable Render Pipeline; [[Unreal Engine]] uses HLSL throughout its material graph. Shader languages are the backbone of every visual effect from ambient occlusion to hair simulation.
- **Augmented Reality and Virtual Reality** — [[Augmented Reality]] and [[Virtual Reality]] headsets demand low-latency, reprojection-aware rendering. Shader languages implement foveated rendering, time-warp, and lens distortion correction directly on the GPU.
- **Web and Browser Graphics** — [[WebGL]] shaders (GLSL ES 1.0/3.0) and [[WGSL]] for [[WebGPU]] bring GPU-accelerated visualisations, 3D scenes, and data dashboards to web browsers without plugins.
- **Scientific Visualisation** — volumetric rendering of medical CT/MRI data, fluid simulation visualisation, and astronomical data rendering all rely on compute and fragment shaders.
- **Machine Learning Inference** — compute shaders increasingly implement neural network layers (convolutions, attention) for on-device inference, especially on mobile where dedicated ML hardware may be absent. This is a key bridge to [[Neural Rendering]] and [[Machine Learning Accelerator]] workloads.
- **Post-Processing Effects** — screen-space ambient occlusion (SSAO), depth of field, bloom, tone-mapping, and anti-aliasing (TAA, DLSS-like upsampling) are implemented entirely as fragment or compute shaders operating on framebuffer textures.
- **Procedural Content** — [[Procedural Generation]] of terrain heightmaps, noise textures, and animated materials (lava, water, clouds) is authored in shader languages, executing at frame-rate on the GPU.
- **General GPU Compute** — through [[Compute Shader]], shader languages overlap with [[GPGPU]] for physics simulation, cloth, fluid dynamics, and collision detection — tasks that benefit from the GPU's massive parallelism without requiring a specialised CUDA/OpenCL setup.

### Standards and Context

- **[[Khronos Group]]** — maintains the GLSL specification (currently GLSL 4.60 for OpenGL 4.6, GLSL ES 3.20 for OpenGL ES/WebGL2) and co-developed SPIR-V as part of the Vulkan ecosystem.
- **Microsoft** — owns and evolves [[HLSL]] through successive DirectX Shader Model versions (SM 5.1 for DirectX 11/12, SM 6.x adding wave intrinsics, ray tracing, mesh shaders). The DXC (DirectX Shader Compiler, built on LLVM/Clang) is open-source.
- **Apple** — defines [[Metal Shading Language]] as a superset of C++14 with GPU extensions; it is the exclusive shading interface for Metal on iOS, iPadOS, macOS, and visionOS, meaning all spatial computing on Apple hardware depends on it.
- **[[World Wide Web Consortium]] GPU for the Web CG** — standardises [[WGSL]] as the required shading language for the [[WebGPU]] API. WGSL has stricter memory-safety guarantees than GLSL or HLSL, making it suitable for untrusted web content.
- **[[SPIR-V]]** (Khronos) — binary intermediate representation serving as the common compilation target for Vulkan, OpenCL 2.1+, and (via translation) WebGPU. Enables offline compilation, shader reflection (automatic pipeline layout inference), and portable distribution of shader libraries.
- **Shader Model Versioning** — DirectX Shader Models define capability tiers; SM 6.6 (DirectX 12 Ultimate) introduced resource binding, sampler feedback, and mesh/amplification shader tiers aligned with hardware capability.
- **Cross-compilation Ecosystem** — SPIRV-Cross translates SPIR-V back to GLSL/HLSL/MSL; GLSLANG and DXC compile GLSL and HLSL to SPIR-V; Naga (Rust-native) handles WGSL, GLSL, HLSL, and SPIR-V interoperably for the [[WebGPU]] ecosystem.

### Current Landscape (2026)

- Slang emerged as the defining cross-platform shading language of the period: NVIDIA donated it to the Khronos Group under the Slang Initiative (announced 21 November 2024, Apache 2.0, GitHub-hosted), moving it from single-vendor control to multi-vendor governance and a self-governing contributor model where core language decisions are made in the open without Khronos membership.
- Slang's single-source-to-many-targets compiler now emits SPIR-V (Vulkan), HLSL (Direct3D), GLSL (OpenGL), WGSL (WebGPU) and Metal Shading Language, with a WebAssembly-based live playground (~5MB) that compiles shaders locally in the browser; the 2024.14.x line added Metal and WGSL backends, and releases have continued steadily (v2025.18.2 in October 2025).
- Neural graphics became the dominant theme of 2025: Slang's automatic differentiation reached performance parity with hand-written CUDA on a Gaussian-splatting rasteriser, positioning shading languages as a vehicle for in-shader neural computation rather than purely classical rendering.
- Adoption is measurable — the 2026 Khronos Real-Time Shading Ecosystem Survey put Slang at roughly 34% usage (ranked #4), approaching HLSL's 41%, with GLSL still most widely used and direct SPIR-V usage at ~39%; Valve compiled its entire Source 2 HLSL codebase with Slang (shipping generated SPIR-V in Counter-Strike 2 and Dota 2) with only around 10 lines changed.
- WebGPU's shading language WGSL reached a W3C Candidate Recommendation ("1.0"-equivalent) milestone in 2025, with WebGPU shipping in Chrome (Windows, Mac, and beginning Intel Linux) and Safari on macOS 26, cementing WGSL as the browser-native successor to WebGL/GLSL ES.
- HLSL is being modernised and, for the first time, standardised: Microsoft and Google continued the Clang-based HLSL implementation (adding RWBuffer/RWStructuredBuffer support and an LLVM Offload Test Suite), and in early 2026 Ecma International formed Technical Committee 57 (TC57) to produce an open, royalty-free HLSL language specification.
- Rust-based GPU programming matured as an alternative front end — Rust GPU (SPIR-V for wgpu/Bevy/Vulkan) and Rust CUDA — alongside the Naga cross-compiler (WGSL/GLSL/SPIR-V/MSL/HLSL) that underpins the wgpu ecosystem.
- Open challenges as of 2026 include reconciling divergent atomics and binding-model semantics across backends (Slang added an Atomic type to paper over HLSL/MSL/WGSL differences), maturing still-experimental Metal and WGSL Slang backends, and delivering complete, interoperable open specifications for both HLSL (TC57) and WGSL (W3C) so multiple independent implementations can converge.

### References

- 1. Khronos Group / shader-slang.org (2024). Khronos Hosts Open Source Slang Shading Language and Compiler. http://shader-slang.org/news/2024/11/21/khronos-hosts-open-source-slang-shading-language-and-compiler/
- 2. shader-slang.org (2024). There's a lot going on with Slang! (Metal, WGSL, playground, auto-diff). https://shader-slang.org/blog/2024/11/20/theres-a-lot-going-on-with-slang/
- 3. Khronos Group (2026). 2026 Real-Time Shading Ecosystem Survey Report. https://members.khronos.org/document/dl/36688
- 4. Chris Bieneman / Abolish \r\n (2026). State of HLSL: February 2026 (Clang implementation, Ecma TC57). https://www.abolishcrlf.org/2026/02/10/HLSLState.html
- 5. Shading Languages Symposium 2026 (2026). WGSL - Past, Present, and Future. https://www.youtube.com/watch?v=wY9NbaGYum8
- 6. GamingOnLinux (2024). Khronos Group takes over cross-platform Slang shading language from NVIDIA (Valve / Source 2). https://www.gamingonlinux.com/2024/11/khronos-group-takes-over-cross-platform-slang-shading-language-from-nvidia/

### Provenance

