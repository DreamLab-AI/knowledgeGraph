
A language preference is a set of linguistic parameters that govern how an agent expresses and parses language. In the SAC-CG Agent Ontology the class `LanguagePreference` is defined as covering "preferred language, register, clarity constraints, or structural tendencies affecting expression and parsing".[^1]

It is a component of an [[Agent Profile]], attached by the `usesLanguage` property, whose comment adds "grammar formality, and interaction mode" to preferred linguistic expression. The ontology's example individual for the class is labelled "Standard Language Model".

It is a configuration of language use and not a model of delivery. The delivery side, such as pacing and assertiveness, belongs to [[Tone Model]], and stable decision biases belong to [[Agent Personality]]. As a [[Configuration]] it records choices that can be set per agent.

The ontology is a Community Group draft; the profile module is version 0.2.0, not a W3C Recommendation.

[^1]: Semantic Agent Communication Community Group, “Agent Profile Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent-profile.ttl

