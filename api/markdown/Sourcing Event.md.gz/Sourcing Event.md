A sourcing event is a single competitive solicitation, such as a request for quotation, a request for proposal or an auction, set up and run in an e-sourcing system.[^1]

No standards or public source defines the term. Oracle's PeopleSoft Strategic Sourcing data sheet says the product lets an organisation “streamline its RFx processes”, conduct real-time auctions and award contracts or purchase orders, and it lists sourcing event creation among its key features, with weighting assigned to bid factors for response optimisation and evaluation, digital signatures, configurable bidder search criteria and filter criteria for an event workbench.[^1] The data sheet describes the RFx process as formulating requirements, selecting and inviting bidders, receiving bids, scoring and analysing the results, negotiating terms and awarding the contract.[^1]

## Related terms in procurement law

UNCITRAL defines a solicitation as an invitation to tender, present submissions or participate in request-for-proposals proceedings or an electronic reverse auction.[^2] The United States Federal Acquisition Regulation defines a solicitation as any request to submit offers or quotations to the Government.[^3] The Federal Acquisition Regulation adds that solicitations under sealed bid procedures are called invitations for bids and those under negotiated procedures are called requests for proposals.[^3] Those definitions describe the public-law act of inviting submissions, not the software object, so they bound the sense of a sourcing event without equating the two.[^2][^3]

See [[Request for Quotation]], [[Request for Proposal]], [[Reverse Auction]] and [[Strategic Sourcing]].

## What the sources do not establish

This page rests on one vendor data sheet and two public-law definitions of a related word, so it is thinly evidenced and gives no view on how sourcing events are used in practice.[^1]

[^1]: Oracle, PeopleSoft Strategic Sourcing data sheet (software vendor), “PeopleSoft Strategic Sourcing”. https://www.oracle.com/ae/a/ocom/docs/applications/peoplesoft/peoplesoft-strategic-sourcing.pdf
[^2]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf
[^3]: US General Services Administration and Department of Defense, Federal Acquisition Regulation, acquisition.gov, “FAR 2.101 Definitions”. https://www.acquisition.gov/far/2.101

