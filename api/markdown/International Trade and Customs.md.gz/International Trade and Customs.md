International trade and customs covers the procedures, classifications, duties, controls and documents through which goods cross customs borders.[^1][^2]

The European Commission describes its customs procedures pages as information on importing and exporting goods.[^1] HM Revenue and Customs' import guidance covers bringing goods into the UK from any country, including how much tax and duty is payable and whether a licence or certificate is needed.[^2] Usage differs between the EU, the UK and the World Trade Organization, and each linked page says whose terms a source reports.[^3][^2][^4]

## Parts of the area

Procedure and clearance. In the Union Customs Code a customs procedure is one under which goods may be placed: release for free circulation, special procedures or export.[^3] See [[Customs Procedure]], [[Customs Clearance]] and [[Customs Declaration]].

Classification and origin. The Harmonised System is a World Customs Organization nomenclature that more than 200 countries and economies use as a basis for their customs tariffs.[^5] In the UK the commodity code on an import declaration determines the rate of duty and whether an import licence is needed.[^2] Origin is, with tariff classification and customs value, one of the factors that determine the tariff treatment applied in the EU.[^6] See [[Tariff Classification]], [[Harmonised System]] and [[Rules of Origin]]. The WCO is covered at [[World Customs Organization]].

Duties and measures. The WTO calls customs duties on merchandise imports tariffs, and describes market access for goods as the tariff and non-tariff conditions agreed by members for entry of goods into their markets.[^4][^7] See [[Customs Duty]], [[Trade Measure]] and [[World Trade Organization]].

Documents. The UK guidance for exporters says the completed invoice and any licences or certificates must travel with the goods.[^8] See [[Trade Document]], [[Bill of Lading]] and [[Electronic Bill of Lading]].

## Not covered by these sources

Incoterms and free trade zones have their own pages; the Union Customs Code lists free zones, with customs warehousing, among the storage special procedures.[^3] See [[Incoterms]] and [[Free Trade Zone]].

## Evidence limits

Sources here are EU, UK and WTO publications, one WCO page and one carrier glossary. United States and other national regimes were not opened, so procedures described here should not be assumed to apply elsewhere.[^1][^2][^4][^5]

[^1]: European Commission, “Customs Procedures for import and export - Taxation and Customs Union”. https://taxation-customs.ec.europa.eu/customs/customs-procedures-import-and-export_en
[^2]: HM Revenue and Customs, “Import goods into the UK: step by step - GOV.UK”. https://www.gov.uk/import-goods-into-uk
[^3]: European Parliament and Council, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code (recast)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^4]: World Trade Organization, “WTO | Tariffs”. https://www.wto.org/english/tratop_e/tariffs_e/tariffs_e.htm
[^5]: World Customs Organization, “What is the Harmonized System (HS)?” (web page). https://www.wcoomd.org/en/topics/nomenclature/overview/what-is-the-harmonized-system.aspx
[^6]: European Commission, “Rules of origin for goods - Taxation and Customs Union”. https://taxation-customs.ec.europa.eu/customs/rules-origin-goods_en
[^7]: World Trade Organization, “WTO | Market access for goods - gateway”. https://www.wto.org/english/tratop_e/markacc_e/markacc_e.htm
[^8]: HM Revenue and Customs, “Export goods from the UK: step by step - GOV.UK”. https://www.gov.uk/export-goods

