Vendor-managed inventory is a supply arrangement in which the supplier assumes responsibility for tracking and replenishing a customer's inventory.[^1][^2]

An NC State University article defines the concept as a supply initiative where the supplier assumes responsibility of tracking and replenishing a customer's inventory, and says it comes in a number of forms, including Synchronized Customer Response, Continuous Replenishment, Efficient Consumer Response, Rapid Replenishment, CPFR and centralised inventory management.[^1] An operations research preprint on industrial vending machines describes arrangements in which suppliers take responsibility for managing inventory replenishment at the customer's location, determining both the timing and the quantity of replenishments from real-time inventory levels and demand data.[^2]

## Structures

That preprint says VMI agreements typically fall into two categories: supplier-owned inventory, or consignment, in which the supplier keeps ownership until the point of sale, and traditional VMI, in which the retailer takes ownership on delivery. It adds that, to limit overstocking in traditional arrangements, contracts often set inventory upper bounds with penalties for non-compliance.[^2]

## Risks reported

The NC State article warns that VMI poses significant risks, and gives the example of large telecoms in 2001 pushing billions of inventory onto contract manufacturers. It cites a case in which material shortages increased even when the agreed inventory levels were maintained, notes the possibility of line shut-downs in a VMI situation, and says companies such as Toyota and Honda have moved away from VMI.[^1] These statements come from one article and the cases it summarises, not from a survey, so they should not be read as the typical outcome.

## Scope and distinctions

Vendor-managed inventory is an [[Inventory Control Practice]]. The preprint treats consignment, in which the supplier retains ownership, as one of two structures of VMI agreements rather than as a separate practice.[^2] See [[Inventory Management]] and [[Procurement]].

## What the sources do not establish

Sources do not give a consistent set of defining features, and the article lists several related practices without distinguishing them. Evidence on benefits is not given in the opened sources.

[^1]: North Carolina State University, Supply Chain Resource Cooperative, “Vendor Managed Inventory? Think twice and consider the risks!”. https://scm.ncsu.edu/scm-articles/article/vendor-managed-inventory-think-twice-and-consider-the-risks
[^2]: arXiv (Sindermann, Gel and Erkip, University of Nebraska-Lincoln and Bilkent University), “Optimal Replenishment Policies for Industrial Vending Machines”. https://arxiv.org/pdf/2503.13643

