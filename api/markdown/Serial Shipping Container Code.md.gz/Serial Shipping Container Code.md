The Serial Shipping Container Code (SSCC) is the GS1 identifier for an individual logistics unit, established for transport and storage and needing to be managed through the supply chain.[^1]

GS1 says companies use the SSCC to identify a logistic unit, which can be any combination of trade items packaged together for storage or transport, for example a case, pallet or parcel.[^2] GS1 Sweden, a member organisation, gives the same list of a case, pallet or parcel.[^3] The General Specifications call tracking and tracing logistic units a major application of the GS1 system.[^1]

## In practice

GS1 Sweden says the SSCC is usually coded into the GS1-128 barcode printed on a pallet or transport label, following the GS1 Logistic Label standard, and that GS1-128 can carry further information about the contents, such as an expiry date or batch number.[^3] It says the number can also be carried on an EPC or RFID tag, and that status information about logistic units in transit can be shared through EDI or [[GS1 EPCIS]].[^3]

## Scope and distinctions

The SSCC is one of the keys described at [[GS1 Identification Key]]. Unlike the [[Global Trade Item Number]], which names a type of product, it names one unit of transport or storage.[^1] If a trade item is shipped as an independent logistic unit, the General Specifications say it should additionally be identified with an SSCC, and that a GTIN combined with a serial number does not replace the SSCC as the identifier of a logistic unit.[^1]

## What the sources do not establish

Every source here is GS1 or a GS1 member organisation, so the page rests on one standards family. The sources do not give the structure of the code, how SSCCs are assigned or reused, or how widely they are used.[^1][^2][^3]

[^1]: GS1, “GS1 General Specifications Standard”, release 26.0. https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf
[^2]: GS1, “Serial Shipping Container Code (SSCC)”. https://www.gs1.org/standards/id-keys/sscc
[^3]: GS1 Sweden, “GS1 Package Number (SSCC)”. https://gs1.se/en/standards-and-services/serial-shipping-container-code-sscc/

