A request for proposal (RFP) is a solicitation used in negotiated acquisitions to communicate requirements to prospective suppliers and to ask them for proposals.[^1][^2]

The United States Federal Acquisition Regulation, at 15.203, says RFPs are used in negotiated acquisitions to communicate Government requirements to prospective contractors and to solicit proposals. For competitive acquisitions an RFP must at a minimum describe the requirement, the anticipated terms and conditions of the contract, the information required in the proposal, and the factors and significant subfactors that will be used to evaluate it and their relative importance. Electronic commerce may be used to issue RFPs and receive proposals, and contracting officers deciding whether to allow facsimile proposals should consider anticipated proposal size, urgency and the availability of electronic commerce methods.[^1] The same regulation says solicitations under negotiated procedures are called requests for proposals.[^3]

UNCITRAL's Model Law provides for request for proposals without negotiation, where the procuring entity needs to consider the financial aspects of proposals separately and only after completing the examination and evaluation of their technical, quality and performance characteristics.[^2] Its glossary describes the method as evaluating financial terms after the evaluation of technical, quality and performance characteristics, with submissions presented in two separate sealed envelopes.[^4]

## Scope and distinctions

The Model Law has other proposal methods, including request for proposals with dialogue and with consecutive negotiations, so request for proposals is a family of methods and not one.[^2] See [[Request for Quotation]], [[Reverse Auction]] and [[Procurement]].

## What the sources do not establish

Both sources describe public procurement. Private-sector RFP practice, response scoring and the related request for information were not separately sourced.[^1][^2]

[^1]: US General Services Administration and Department of Defense, Federal Acquisition Regulation, acquisition.gov, “FAR 15.203 Requests for proposals.”. https://www.acquisition.gov/far/15.203
[^2]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf
[^3]: US General Services Administration and Department of Defense, Federal Acquisition Regulation, acquisition.gov, “FAR 2.101 Definitions”. https://www.acquisition.gov/far/2.101
[^4]: United Nations Commission on International Trade Law (UNCITRAL), “Glossary of procurement-related terms used in the 2011 UNCITRAL Model Law on Public Procurement”. https://uncitral.un.org/sites/default/files/procurement/procurem/ml-procurement-2011/Glossary-e.pdf

