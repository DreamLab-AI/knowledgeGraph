
A key type specifies the cryptographic algorithm or format of a key. In the SAC-CG Agent Ontology the class `KeyType` is defined as specifying "the cryptographic algorithm or format (Ed25519, RSA, secp256k1)".[^1]

A [[Cryptographic Key]] (the ontology's `KeyMaterial`) is related to its type through the `keyType` property, an object property from key material to `KeyType`. Because the range is a class, the algorithm is a named resource and not a free string, which lets different keys share a type.

The three examples in the definition span signature and public-key families. The concept connects to [[Cryptographic Algorithm]], since a key type names the algorithm or format a key follows.

The ontology is a Community Group draft; the security binding module is version 0.2.0, not a W3C Recommendation.

[^1]: Semantic Agent Communication Community Group, “Security Binding Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/security-binding.ttl

