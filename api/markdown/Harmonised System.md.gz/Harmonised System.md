The Harmonised System (HS) is the international product nomenclature developed by the World Customs Organization, which classifies traded goods under six digit codes and underlies national customs tariffs.[^1][^2]

The WCO describes it as a multipurpose nomenclature of more than 5,000 commodity groups, each identified by a six digit code, arranged in a legal and logical structure and supported by well-defined rules to achieve uniform classification.[^1] It says the system is used by more than 200 countries and economies as a basis for their customs tariffs and for international trade statistics, and that it is governed by an international convention whose official interpretation is given in Explanatory Notes published by the WCO.[^1] Maersk's glossary says it came into effect in 1988 and that, under the HS Convention, contracting parties are obliged to base their tariff schedules on the nomenclature while setting their own rates of duty.[^2]

## National codes

GOV.UK uses the term commodity code for the reference numbers that describe a product on an import declaration and determine duty; the page does not name the HS or say how UK codes extend it.[^3] The Union Customs Code refers to classification decisions, classification opinions and amendments of the explanatory notes to the Nomenclature of the Harmonized Commodity Description and Coding System adopted by the organisation set up by the Customs Co-operation Council convention, which shows that EU law refers to WCO classification decisions.[^4] See [[Tariff Classification]] and [[World Customs Organization]].

## Citation note

Itself a WCO publication, the nomenclature is cite-only in this corpus. This page paraphrases the WCO description and reproduces no part of the code structure beyond the six digit level described there.[^1]

## Evidence limits

Only one WCO page was opened, backed by a carrier glossary and by incidental references in EU and UK texts. The HS Convention and the Explanatory Notes were not opened.[^1][^2][^3][^4]

[^1]: World Customs Organization, “What is the Harmonized System (HS)?” (web page). https://www.wcoomd.org/en/topics/nomenclature/overview/what-is-the-harmonized-system.aspx
[^2]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms
[^3]: HM Revenue and Customs, “Finding commodity codes for imports into or exports out of the UK - GOV.UK”. https://www.gov.uk/guidance/finding-commodity-codes-for-imports-or-exports
[^4]: European Parliament and Council, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code (recast)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952

