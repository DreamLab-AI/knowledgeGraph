Microsoft Mesh is a platform for shared mixed reality experiences that lets people in different physical locations join a common virtual space using avatars or holographic representations, integrating with Microsoft Teams to deliver immersive collaboration scenarios such as design review, training and distributed meetings.

### Semantic Classification

### Content

- Microsoft Mesh is a Microsoft platform for shared mixed reality, allowing geographically separated participants to occupy a single virtual space through avatars and to interact with shared 3D content. It integrates with Microsoft Teams to add immersive meeting spaces alongside conventional video calls.
- The platform builds on spatial anchoring, avatar representation and cloud-hosted scene state so that the same virtual environment is presented consistently to each participant. It is intended for collaboration scenarios such as design review, training and distributed meetings rather than general consumer social use.

### Current Landscape (2026)

- Microsoft retired Mesh as a standalone platform on 1 December 2025: the Mesh PC and Meta Quest apps stopped working, the mesh.cloud.microsoft site was decommissioned, and the "Immersive space (3D)" view was removed from Teams meetings, folding all 3D collaboration into Teams.
- The replacement, "immersive events in Teams", reached general availability on the same day (1 December 2025), running natively on PC, Mac and Meta Quest and scheduled directly from the Teams or Outlook calendar rather than a separate app.
- The transition was staged through 2025: Microsoft signalled Mesh would "evolve" in the M365 admin centre (MC1074973) in May, retired the Unity-based Mesh Toolkit on 24 June 2025, and confirmed the December sunset via message MC1111181 in June 2025.
- Capability shifted rather than simply migrated: immersive events support customisable branded environments, uploaded 3D models, templates and a new no-code "Action Groups" feature to trigger animations and media, but everyday "immersive space" 3D meetings are capped at 16 participants versus the up-to-330 Mesh events once hosted.
- Licensing tightened around Teams: hosting an immersive event now requires a qualifying commercial Teams licence plus Teams Premium (or Teams Enterprise), while co-organisers and attendees join with a standard Teams/Microsoft 365 E3/E5 licence, and administration relies on existing Microsoft 365 identity, security and compliance controls.
- The move is widely read as Microsoft scaling back its workplace-metaverse ambitions amid weak demand, following the earlier collapse of the AltspaceVR/Industrial Metaverse push, though Redmond frames it as consolidating immersive investment inside Teams rather than abandoning 3D collaboration.
- Open challenges as of 2026 include the reduced concurrency and lost bespoke-environment flexibility for existing Mesh customers, the confusing overlap between "immersive space (3D) view" and "immersive events", and the unproven enterprise appetite for avatar-based 3D meetings against mature 2D video conferencing.

### References

- 1. Microsoft Teams Blog / Tech Community (2025). Immersive events in Microsoft Teams: Now generally available. https://techcommunity.microsoft.com/blog/microsoftteamsblog/immersive-events-in-microsoft-teams-now-generally-available/4468628
- 2. The Register (2025). Microsoft mops up Mesh after another metaverse misfire. https://www.theregister.com/software/2025/12/02/microsoft-mops-up-mesh-after-another-metaverse-misfire/
- 3. Computerworld (2025). Microsoft retires Mesh app, launches 'immersive spaces' for Teams. https://www.computerworld.com/article/4100319/microsoft-retires-mesh-app-launches-immersive-spaces-for-teams.html
- 4. Directions on Microsoft (2025). Microsoft Is Finally Nixing its Mesh Mixed-Reality Efforts. https://www.directionsonmicrosoft.com/microsoft-is-finally-nixing-its-mesh-mixed-reality-efforts/
- 5. Campus Technology (2025). Teams Gains 3D Meeting Capability as Microsoft Retires Mesh Platform. https://campustechnology.com/articles/2025/12/11/teams-gains-3d-meeting-capability-as-microsoft-retires-mesh-platform.aspx

### Provenance

