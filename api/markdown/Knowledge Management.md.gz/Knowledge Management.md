Knowledge Management (KM) is the systematic discipline of identifying, capturing, organising, storing, sharing, and applying the collective explicit and tacit knowledge assets of an organisation or distributed community to improve decision-making, innovation, and operational effectiveness. It integrates organisational theory, information science, and technology — spanning knowledge repositories, ontologies, semantic search, and communities of practice — to prevent knowledge loss, enable reuse, and accelerate learning. Modern KM increasingly employs AI-augmented techniques such as knowledge graphs, retrieval-augmented generation, and large language model reasoning to make both structured and unstructured knowledge discoverable and actionable by human and autonomous agents alike. It is a mature field with established frameworks (SECI, DIKW hierarchy, Cynefin) and dedicated standards bodies.

### Overview

- Knowledge Management emerged as a formal discipline in the early 1990s, catalysed by work from Nonaka and Takeuchi on the SECI model (Socialisation, Externalisation, Combination, Internalisation) and the rise of enterprise intranets.
- Its central problem is the **knowledge retention and transfer challenge**: organisations continuously lose institutional knowledge through staff turnover, siloed communication, and inadequate documentation practices.
- KM addresses the full DIKW hierarchy — from raw [[Data]] through [[Information]] to [[Knowledge]] and ultimately [[Wisdom]] — by providing processes and tools at each level.
- Contemporary KM systems increasingly integrate [[Artificial Intelligence]] to automate classification, surface contextually relevant knowledge, and reason over distributed knowledge bases.
- The field spans both **people-centric** approaches (communities of practice, mentoring, storytelling) and **technology-centric** approaches (knowledge bases, semantic repositories, expert systems).

### Key Components

- **Knowledge Capture**
  - Converting [[Tacit Knowledge]] (know-how, expertise) into [[Explicit Knowledge]] (documented procedures, case studies) is the foundational challenge.
  - Techniques include structured interviews, after-action reviews, [[Lessons Learned]] databases, and AI-assisted transcription.
- **Knowledge Organisation**
  - [[Taxonomy]] structures organise knowledge into navigable hierarchies.
  - [[Ontology|Ontologies]] provide richer semantic relationships between concepts, enabling reasoning and inference.
  - [[Metadata]] tagging ensures discoverability across heterogeneous repositories.
  - [[Information Architecture]] governs how knowledge assets are structured and navigated.
- **Knowledge Repositories**
  - Enterprise wikis, intranets, content management systems, and [[Knowledge Graph]] platforms serve as primary stores.
  - Modern implementations use [[Semantic Search]] and vector embeddings to retrieve knowledge by meaning rather than keyword.
  - [[Enterprise Search]] federates across multiple repositories to present a unified knowledge surface.
- **Knowledge Sharing**
  - [[Community of Practice]] networks (Wenger's model) facilitate peer-to-peer knowledge exchange across organisational boundaries.
  - Social collaboration platforms, discussion forums, and expert directories lower the barrier to knowledge finding.
  - [[Distributed Collaboration]] tooling (wikis, shared workspaces, asynchronous video) extends sharing across geographies and time zones.
- **Knowledge Application**
  - [[Decision Support System|Decision Support Systems]] integrate KM outputs to guide operational choices.
  - [[Retrieval-Augmented Generation]] pipelines inject contextually retrieved knowledge into [[Large Language Model]] reasoning, grounding outputs in organisational facts.
  - Expert systems and [[Knowledge Representation]] formalisms enable automated inference from captured knowledge.
- **Knowledge Governance**
  - [[Data Governance]] frameworks establish ownership, quality standards, access control, and lifecycle policies for knowledge assets.
  - [[Knowledge Audit]] processes identify gaps, redundancies, and obsolete content.
  - Version control and provenance tracking maintain trustworthiness of living knowledge bases.

### Mechanisms and Frameworks

- **SECI Model** (Nonaka & Takeuchi, 1995): four modes of knowledge conversion — Socialisation (tacit→tacit), Externalisation (tacit→explicit), Combination (explicit→explicit), Internalisation (explicit→tacit).
- **DIKW Hierarchy**: data → information → knowledge → wisdom — frames KM's scope from raw signals to actionable understanding.
- **Cynefin Framework** (Snowden): sense-making model distinguishing simple, complicated, complex, and chaotic knowledge contexts, guiding appropriate KM responses.
- **Communities of Practice** (Wenger): voluntary networks of practitioners who share domain expertise through ongoing interaction.
- **Second-Generation KM**: shift from document-centric repositories to context-aware, socially mediated, and AI-augmented knowledge systems.
- **Knowledge Graphs** as infrastructure: entities, relationships, and attributes stored as RDF triples or property graphs, queryable via SPARQL or Cypher, enabling machine-readable organisational memory.

### Applications and Use Cases

- **Enterprise Knowledge Bases**: technology companies (e.g. Confluence, SharePoint, Notion) serve as KM platforms enabling teams to document and retrieve institutional knowledge.
- **Customer Support**: AI-powered KM systems retrieve relevant articles, procedures, and precedents to resolve support cases faster.
- **Research & Development**: pharmaceutical, aerospace, and defence organisations use KM to capture experimental results, patent landscapes, and design rationale.
- **Healthcare**: clinical knowledge management systems surface evidence-based guidelines, drug interactions, and diagnostic protocols at point of care.
- **Legal Sector**: knowledge management enables law firms to retrieve precedents, contracts, and regulatory interpretations efficiently.
- **AI Agent Memory**: autonomous agents use KM architectures — vector databases, knowledge graphs, episodic memory stores — to persist and retrieve context across sessions.
- **Open Source Communities**: wikis, issue trackers, and documentation systems manage distributed contributor knowledge across global teams.
- **Government and Public Sector**: policy knowledge bases, lessons-learned registers, and inter-agency knowledge sharing improve public service delivery.

### Standards and Context

- **ISO 30401:2018** — Knowledge Management Systems: Requirements. The primary international standard defining KM system requirements and good practice for organisations.
- **ISO/IEC 11179** — Metadata Registries: underpins the metadata standards that enable KM systems to interoperate through shared controlled vocabularies.
- **W3C Semantic Web Stack** — [[RDF]], [[OWL]], [[SPARQL]], and [[SKOS]] provide the technical substrate for machine-readable knowledge representation and sharing.
- **SKOS (Simple Knowledge Organization System)** — W3C recommendation for representing controlled vocabularies, thesauri, and taxonomies as linked data.
- **Dublin Core Metadata Initiative (DCMI)** — lightweight metadata vocabulary widely used in document-level KM annotations.
- **Knowledge Management Institute (KMI)** and **APQC** (American Productivity and Quality Center) provide maturity models and benchmarking frameworks for KM programmes.
- **OpenCyc / Cyc** and **DBpedia** represent large-scale public knowledge bases instantiating KM at web scale.
- Enterprise KM platforms: Confluence (Atlassian), SharePoint (Microsoft), Notion, Guru, Glean, and open-source alternatives (XWiki, DokuWiki).

### Semantic Classification

- **domain-remap:** spatial-computing → data (KM is fundamentally an information/data discipline, not specific to spatial computing)

### Provenance

