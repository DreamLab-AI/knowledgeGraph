Creator royalties are automatic, programmable payments directed to the original creator of a digital asset — typically an NFT — each time that asset is resold on a secondary market. Encoded in smart contract logic or enforced through marketplace policy, royalties provide creators with a fraction of every subsequent transaction price, extending their economic participation beyond the initial sale. The mechanism is foundational to sustainable creator economies on blockchain platforms, though enforcement remains contested between on-chain protocol enforcement and off-chain marketplace compliance. Debate centres on whether royalty obligations can be made non-bypassable at the token-transfer level or rely on voluntary marketplace co-operation.

### Overview

- Creator royalties extend an artist's economic participation beyond the moment of first sale. When an [[NFT]] is minted, the minting contract (or accompanying metadata) specifies a royalty percentage and a recipient address. Each time the NFT is resold through a compliant [[NFT Marketplace]], the marketplace withholds that percentage from the sale proceeds and transfers it to the creator's wallet before settling the remainder with the seller.
- The core challenge is that royalty enforcement is not natively guaranteed by the [[Ethereum Virtual Machine]] or similar execution environments: a token transfer is simply a state change, carrying no obligation to route funds to anyone. Royalty logic lives in marketplace contracts, meaning any marketplace that chooses not to implement the check can facilitate "royalty-free" transfers.
- This created a competitive dynamic in 2022–2023 where zero-royalty marketplaces attracted sellers willing to bypass creator payments, prompting platforms such as [[OpenSea]] to experiment with on-chain blocklists (the [[Operator Filter Registry]]) that prevented non-compliant markets from transferring certain NFT collections. That experiment was ultimately discontinued, illustrating how difficult protocol-level enforcement is without changes to underlying [[Token Standard]] specifications.
- The debate has spurred development of [[EIP-2981]] (the NFT Royalty Standard), which standardises how royalty information is expressed on-chain, and later discussions around more coercive mechanisms such as transfer hooks (e.g. [[ERC-721C]]) that require royalty payment as a condition of any transfer.

### Key Mechanisms

#### Marketplace-Layer Enforcement

- The most common implementation: marketplaces query [[EIP-2981]]-compliant contracts for royalty info and voluntarily withhold and forward the fee.
- Relies on marketplace reputation and community norms rather than cryptographic enforcement.
- Susceptible to competitive undercutting by zero-royalty rivals.

#### Transfer-Hook Enforcement ([[ERC-721C]] and equivalents)

- Newer token standards embed a callback or hook that executes on every transfer, allowing the contract itself to reject the transfer unless a royalty payment is included.
- Provides stronger guarantees but restricts composability — [[Decentralised Finance]] protocols and peer-to-peer transfers may break if they do not satisfy hook conditions.
- Trade-off: stronger creator protection vs. reduced token utility in DeFi contexts.

#### Royalty Percentage and Recipient

- [[EIP-2981]] exposes `royaltyInfo(tokenId, salePrice)` returning `(receiver, royaltyAmount)`.
- Percentage is set at mint time, typically 2–10%, and stored immutably or with controlled mutability in the contract.
- [[Royalty Splitting]] extensions allow multiple recipients (e.g., creator + collaborators) using on-chain payment splitter contracts.

#### Off-Chain Policy Agreements

- Some platforms use Terms of Service to bind marketplace operators contractually rather than technically.
- Enforced through legal agreements, not [[Smart Contract]] logic.

### Applications and Use Cases

#### Digital Art and Music NFTs

- Visual artists and musicians mint [[NFT]] editions where each secondary resale routes a percentage back to them, creating passive income streams from collector trading activity.
- Platforms such as [[Foundation]], [[SuperRare]], and [[Zora]] pioneered this model for fine-art NFTs.

#### Gaming Assets

- In-game items, skins, and characters minted as NFTs can carry royalties, so game studios earn on player-to-player trading in [[Decentralised Marketplace]] environments without needing centralised exchange control.
- Connects to broader [[Play-to-Earn]] and [[GameFi]] economies.

#### Virtual Real Estate and Metaverse Items

- Land parcels and wearables in [[Metaverse]] platforms like [[Decentraland]] and [[The Sandbox]] use royalty contracts so original creators benefit from speculative resale markets.
- Bridges creator royalties into [[Spatial Computing]] and immersive economy contexts.

#### Music Rights Fractionalisation

- Royalty streams themselves can be tokenised and sold as fractional ownership rights (e.g., via [[Royal]] or [[Opulous]]), creating investable yield-bearing assets backed by streaming or synchronisation income.
- This is adjacent to but distinct from NFT resale royalties — it represents primary rights, not resale fees.

#### Collaborative Creative Works

- Co-creators can use on-chain [[Royalty Splitting]] (e.g., via [[0xSplits]] protocol) to distribute royalty proceeds proportionally among contributors without a trusted third-party administrator.

### Standards and Governance Context

#### EIP-2981 — NFT Royalty Standard

- Proposed and finalised on [[Ethereum]], [[EIP-2981]] defines a minimal interface for querying royalty payment information from a token contract.
- Adopted by [[OpenSea]], [[Rarible]], [[LooksRare]], and most major [[EVM]]-compatible marketplaces as the de facto read layer for creator fee data.
- Limitations: it is informational only — compliant marketplaces read the data but are not obligated by the protocol to honour it.

#### ERC-721C (Limit Break)

- An extension by [[Limit Break]] that enforces royalties at the transfer level using a custom transfer validator, making royalty payment a precondition of token movement.
- Represents the "programmable royalties" approach: stronger guarantees, narrower composability.

#### Operator Filter Registry (OpenSea, 2022–2023)

- [[OpenSea]]'s short-lived mechanism that let collection owners block sales on non-compliant marketplaces via a on-chain registry.
- Withdrawn in early 2024 after failing to create lasting industry-wide co-operation.

#### Regulatory Overlap

- In some jurisdictions, resale royalty rights for physical art already exist in law (e.g., Artist's Resale Right / droit de suite under EU Directive 2001/84/EC).
- NFT creator royalties are the digital analogue but lack equivalent legislative backing in most markets, making enforcement entirely market- or protocol-dependent.
- [[Web3]] legal scholars debate whether on-chain royalty obligations could one day be recognised as enforceable [[Smart Legal Contract]] provisions.

### Challenges and Limitations

- **Enforcement fragility**: without protocol-level coercion, creators depend on marketplace goodwill, which erodes under competitive pressure from zero-royalty venues.
- **Composability tension**: transfer-hook approaches that enforce royalties can break [[Decentralised Finance]] lending, fractionalization, and wrapped-token protocols that perform token movements without paying fees.
- **Wash trading**: reported sales between related wallets can artificially generate royalty flows to the creator from fictional volume, distorting income statistics.
- **Cross-chain fragmentation**: royalty standards differ across [[Solana]], [[Flow]], [[Tezos]], and [[EVM]]-compatible chains, creating inconsistent creator experiences.
- **Off-chain income gap**: royalties only apply to on-chain transfers; off-chain bilateral trades or OTC deals generate no royalty disbursements.

### Provenance

