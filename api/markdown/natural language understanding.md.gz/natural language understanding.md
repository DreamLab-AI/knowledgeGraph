Natural Language Understanding (NLU) is the subfield of Natural Language Processing dedicated to enabling machines to comprehend the meaning, intent, and pragmatic context of human language input beyond surface-level syntax. Core NLU tasks include semantic role labelling, named entity recognition, coreference resolution, intent classification, relation extraction, and natural language inference, all requiring models to construct structured semantic representations of utterance meaning. Modern NLU systems are predominantly built on large pre-trained Transformer architectures such as BERT and its derivatives, which learn contextualised word representations from massive corpora via self-supervised objectives. NLU serves as the comprehension layer in conversational AI, information extraction pipelines, question answering systems, and dialogue management frameworks.

### Overview

- NLU occupies a specific position within the broader [[Natural Language Processing]] landscape: it is concerned with the transition from surface-level linguistic form to deep semantic content — understanding what is meant, not merely what is said.
- The field draws from several parent disciplines:
  - [[Computational Linguistics]] — formal theories of syntax, semantics, and pragmatics
  - [[Cognitive Science]] — models of human language comprehension and mental representation
  - [[Machine Learning]] — statistical and neural approaches for learning from annotated and unannotated corpora
  - [[Knowledge Representation]] — formal structures (ontologies, frames, semantic networks) for encoding meaning
- NLU distinguishes itself from [[Natural Language Generation]] (which produces text) and from broader [[Natural Language Processing]] tasks such as machine translation or text summarisation, though these all rely on NLU components.
- The rise of large pre-trained [[Transformer]] models has unified many previously separate NLU subtasks: a single fine-tuned model can perform intent detection, slot filling, named entity recognition, and question answering simultaneously.
- NLU is increasingly blurred with the capabilities of [[Large Language Model|Large Language Models]] (LLMs), which acquire broad NLU competence implicitly through next-token prediction at scale. However, explicit NLU remains important for reliability, interpretability, and resource-constrained deployment.

### Key Components

#### Syntactic Analysis

- [[Syntactic Parsing]] — constituency and dependency parsing to reveal grammatical structure
- [[Part-of-Speech Tagging]] — assigning word-class labels (noun, verb, adjective) as a prerequisite for deeper analysis
- Morphological analysis — decomposing inflected word forms, critical for morphologically rich languages

#### Semantic Analysis

- [[Semantic Role Labelling]] — identifying "who did what to whom" (agent, patient, instrument, location) for each predicate
- [[Semantic Parsing]] — converting natural language to executable formal representations (lambda calculus, SQL, SPARQL, AMR)
- [[Named Entity Recognition]] — locating and classifying named spans (persons, organisations, locations, dates, quantities)
- [[Word Sense Disambiguation]] — resolving lexical ambiguity (e.g. "bank" as financial institution vs. riverbank)
- [[Lexical Semantics]] — modelling meaning relations: synonymy, hyponymy, antonymy via resources like WordNet

#### Pragmatic & Discourse Analysis

- [[Coreference Resolution]] — linking noun phrases and pronouns that refer to the same real-world entity across a discourse
- [[Discourse Coherence]] — modelling how sentences relate (elaboration, contrast, causation) to form coherent documents
- [[Presupposition]] and implicature detection — recovering implied meaning not stated explicitly
- [[Anaphora Resolution]] — a sub-problem of coreference handling pronominal references

#### Classification & Inference Tasks

- [[Intent Classification]] — identifying the user's communicative goal in a conversational turn (buy, query, navigate)
- [[Slot Filling]] — extracting parameter values for a detected intent (date, destination, quantity)
- [[Natural Language Inference]] (NLI / Textual Entailment) — determining whether a hypothesis follows from, contradicts, or is neutral with respect to a premise
- [[Winograd Schema Challenge]] — commonsense pronoun resolution requiring real-world knowledge
- [[Reading Comprehension]] — answering questions given a passage, probing deep semantic understanding

#### Relation & Knowledge Tasks

- [[Relation Extraction]] — identifying typed relations between named entities within or across sentences
- [[Event Extraction]] — detecting events with their participants, time, and location
- [[Knowledge Graph]] population — NLU as a source of structured facts to enrich knowledge bases such as Wikidata or DBpedia
- [[Open Information Extraction]] — schema-free extraction of (subject, predicate, object) triples

### Mechanisms & Architectures

#### Pre-trained Language Models

- BERT (Bidirectional Encoder Representations from Transformers) revolutionised NLU by pre-training bidirectional contextualised [[Word Embedding|word representations]] on masked language modelling and next-sentence prediction.
- RoBERTa, DeBERTa, ALBERT, and ELECTRA are BERT variants optimising pre-training data, objectives, or efficiency.
- [[Transfer Learning]] enables fine-tuning these models on small labelled NLU datasets, yielding strong performance with minimal supervised data.
- Encoder-only [[Transformer]] architectures (BERT family) are preferred for NLU tasks requiring deep bidirectional context; decoder-only models (GPT family) are stronger at generation but increasingly capable at NLU via instruction tuning.

#### [[Attention Mechanism]]

- Self-attention in the [[Transformer]] allows each token to attend to all other tokens in the input, capturing long-range syntactic and semantic dependencies that recurrent networks struggled to model.
- Cross-attention integrates external knowledge (e.g. from a [[Knowledge Graph]]) into the representation.

#### Training Objectives & Evaluation

- Masked Language Modelling (MLM), Replaced Token Detection, Span Boundary Objective, and Next Sentence Prediction are common self-supervised pre-training objectives used to develop NLU-relevant representations.
- GLUE (General Language Understanding Evaluation) and SuperGLUE are standard benchmark suites aggregating tasks including textual entailment, coreference, question answering, and sentiment analysis.
- BIG-Bench and HELM extend evaluation to more challenging reasoning and compositional NLU tasks.

### Applications & Use Cases

#### Virtual Assistants & [[Conversational AI]]

- Spoken language understanding pipelines (ASR → NLU → dialogue policy) power assistants such as Alexa, Siri, Google Assistant, and enterprise chatbots.
- [[Dialogue Management]] relies on NLU to track dialogue state, resolve entity references across turns, and detect user intent changes.

#### [[Question Answering]]

- Extractive QA (e.g. SQuAD) requires identifying the answer span within a passage — a direct NLU reading-comprehension task.
- Open-domain QA combines retrieval ([[Information Retrieval]]) with NLU-based answer extraction or generation.
- Knowledge base QA translates natural language questions to structured queries via [[Semantic Parsing]].

#### [[Information Extraction]]

- NLU drives extraction pipelines that populate databases and [[Knowledge Graph|Knowledge Graphs]] from unstructured text — clinical notes, legal documents, financial filings, scientific literature.
- [[Relation Extraction]] and [[Event Extraction]] are key components of knowledge base construction.

#### [[Sentiment Analysis]] & Opinion Mining

- Aspect-level sentiment analysis requires NLU to identify opinion targets and associate polarity — going beyond document-level classification.

#### Healthcare & Life Sciences

- Clinical NLU extracts diagnoses, medications, dosages, and adverse events from electronic health records.
- Biomedical NLU supports literature mining, drug discovery, and phenotype extraction.

#### Legal & Regulatory Compliance

- Contract analysis, clause extraction, and obligation identification leverage NLU to reduce manual review burden.
- Regulatory text mining uses NLU to track and interpret evolving compliance requirements.

#### [[Machine Translation]] & Localisation

- Deep semantic understanding of source language meaning is a prerequisite for accurate translation, particularly for idiomatic or domain-specific content.

### Standards & Context

#### Benchmarks

- **GLUE** (Wang et al., 2018) — multi-task NLU benchmark covering entailment, coreference, sentiment, and similarity tasks. Widely adopted for model comparison.
- **SuperGLUE** (Wang et al., 2019) — harder successor to GLUE, adding tasks such as the Winograd Schema Challenge and reading comprehension with commonsense reasoning.
- **SQuAD** (Rajpurkar et al., 2016) — Stanford Question Answering Dataset; the standard reading comprehension benchmark using Wikipedia passages.
- **CoNLL shared tasks** — longstanding series covering NER, coreference resolution, and semantic role labelling with standardised splits and evaluation protocols.

#### Standards Bodies & Frameworks

- **W3C** — OWL, RDF, and SPARQL underpin formal knowledge representation layers used in knowledge-based NLU systems.
- **ISO 24617** series — standardises semantic annotation of discourse relations (ISO TimeML, SemAF) relevant to NLU annotation schemes.
- **NIST** — organises evaluations in text analytics and spoken language understanding (e.g. TREC, TAC tracks).
- Hugging Face Transformers library is the de facto open framework for distributing and fine-tuning NLU models.

#### Ethical & Regulatory Considerations

- NLU systems exhibit demographic biases inherited from training corpora, with documented disparities in performance across gender, dialect, and socioeconomic group.
- The [[EU AI Act]] classifies high-risk NLU applications (e.g. biometric categorisation, emotion recognition) under mandatory conformity assessment requirements.
- Privacy concerns arise when NLU processes sensitive personal communications; differential privacy and federated learning are active areas of mitigation research.

### Provenance

