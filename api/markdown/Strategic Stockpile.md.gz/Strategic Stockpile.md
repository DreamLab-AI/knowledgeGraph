A strategic stockpile is a store of critical goods held by a government, or sometimes a firm, to be drawn on when ordinary supply fails, and the sources opened here describe particular stockpiles instead of defining the term.[^1][^2]

## Examples in the sources

The Congressional Research Service says the US Strategic National Stockpile consists of drugs, vaccines, medical products and ancillary supplies that can be deployed at the request of state, local, tribal and territorial health jurisdictions.[^1] Its establishing statute says the stockpile is to provide for the emergency health security of the United States in the event of a bioterrorist attack or other public health emergency.[^1] Part of it is held in prepackaged, transport-ready containers called push packages.[^1]

The US Department of Energy says the Strategic Petroleum Reserve, the world's largest supply of emergency crude oil, was established primarily to reduce the impact of disruptions in supplies of petroleum products and to carry out obligations of the United States under the international energy program.[^2]

In the European Union, Council Directive 2009/119/EC requires Member States to hold total oil stocks corresponding at the very least to 90 days of average daily net imports or 61 days of average daily inland consumption, whichever is greater.[^3] The European Commission describes rescEU as a strategic reserve of European disaster response capabilities and stockpiles, fully funded by the EU.[^4]

## Policy discussion

The White House 100-day review says the strategic stockpiles of the United States have for too long been neglected, and recommends that the National Defense Stockpile of critical minerals and materials be recapitalized and restored.[^5] It also recommends that industries that have faced shortages of critical goods evaluate mechanisms to strengthen corporate stockpiles of select critical products.[^5]

## Scope and limits

A stockpile is a concentrated form of [[Supply Chain Redundancy]] and one of the tools in [[Supply Chain Resilience Strategy]]. The sources cover medical supplies, oil and disaster response goods; none was opened for critical minerals beyond the White House recommendation, and the Defense Logistics Agency pages were not accessible. They do not measure how well any stockpile has worked.

[^1]: Congressional Research Service, report R47400, 25 January 2023, “The Strategic National Stockpile: Overview and Issues for Congress”. https://www.everycrsreport.com/files/2023-01-25_R47400_01bc6ffca8363c8d92653367c9023ead08da7d46.pdf
[^2]: U.S. Department of Energy, Office of Cybersecurity, Energy Security, and Emergency Response, “Strategic Petroleum Reserve”. https://www.energy.gov/ceser/strategic-petroleum-reserve
[^3]: Council of the European Union, Directive 2009/119/EC of 14 September 2009, “Council Directive 2009/119/EC imposing an obligation on Member States to maintain minimum stocks of crude oil and/or petroleum products”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32009L0119
[^4]: European Commission, European Civil Protection and Humanitarian Aid Operations, rescEU. https://civil-protection-humanitarian-aid.ec.europa.eu/what/civil-protection/resceu_en
[^5]: The White House, report under Executive Order 14017, June 2021, “Building Resilient Supply Chains, Revitalizing American Manufacturing, and Fostering Broad-Based Growth: 100-Day Reviews under Executive Order 14017”. https://bidenwhitehouse.archives.gov/wp-content/uploads/2021/06/100-day-supply-chain-review-report.pdf

