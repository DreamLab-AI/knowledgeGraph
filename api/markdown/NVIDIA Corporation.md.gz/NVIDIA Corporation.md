NVIDIA Corporation is an American multinational technology company specialising in the design and manufacture of graphics processing units (GPUs), system-on-chip units, and related software platforms that underpin modern parallel computing workloads. Founded in 1993, NVIDIA pioneered the GPU category and subsequently extended its platform to cover artificial intelligence accelerators, high-performance computing, autonomous vehicles, robotics, and data centre infrastructure. Its CUDA parallel-computing platform, combined with purpose-built AI accelerator hardware such as the A100 and H100, has made NVIDIA the dominant supplier of compute for training large language models and other deep neural networks. NVIDIA's vertically integrated hardware-software stack—spanning chips, drivers, libraries, and cloud services—positions the company as foundational infrastructure for the AI era.

### Overview

- Founded in 1993 by Jensen Huang, Chris Malachowsky, and Curtis Priem, NVIDIA initially targeted the consumer gaming market with 3D graphics accelerators, introducing the term "GPU" in 1999 with the GeForce 256.
- The strategic pivot towards general-purpose computing on GPUs (GPGPU) through the [[CUDA]] programming platform (2006) unlocked massive-parallel compute for [[Scientific Computing]], simulation, and eventually [[Machine Learning]].
- The 2012 AlexNet result—trained on NVIDIA GPUs—demonstrated that [[Deep Learning]] could outperform classical computer-vision methods, catalysing an industry-wide shift to GPU-accelerated AI.
- NVIDIA's data-centre segment became its largest revenue source by 2023, driven by insatiable demand for [[Large Language Model]] training and inference infrastructure.
- The company's silicon is manufactured by [[TSMC]] and, historically, Samsung, following a fabless model that separates chip design from semiconductor fabrication.
- NVIDIA holds a dominant market share in AI accelerator hardware as of 2025, with competitors including [[AMD]], [[Intel Corporation]], and custom silicon such as [[Google TPU]].

### Key Components

#### GPU Architectures

- **Hopper (H100)** — designed for [[Transformer Architecture]] training, introducing the Transformer Engine with FP8 mixed-precision compute.
- **Ada Lovelace** — consumer and professional-visualisation tier; third-generation RT cores and fourth-generation [[Tensor Core]] units.
- **Blackwell (B100/B200)** — next-generation architecture targeting exaflop-scale AI inference and training clusters.
- **Ampere (A100)** — the first architecture to deploy [[Tensor Core]] with TF32 and BF16 datatypes, widely deployed in cloud-provider AI clusters.

#### Software Platform

- **[[CUDA]]** — C/C++ extension enabling general-purpose parallel programming on NVIDIA GPUs; the foundational API that locks in developer ecosystem.
- **cuDNN** — GPU-accelerated library of primitives for [[Deep Learning]] (convolutions, attention, normalisation); used by PyTorch and TensorFlow backends.
- **TensorRT** — inference-optimisation framework that compiles trained models into efficient GPU kernels for production deployment.
- **NCCL** — collective communication library underpinning distributed multi-GPU training of [[Large Language Model]] clusters.
- **Triton Inference Server** — open-source serving framework supporting multi-model inference on GPU and CPU targets.

#### Interconnect & Systems

- **[[NVLink]]** — high-bandwidth chip-to-chip and GPU-to-GPU interconnect, enabling coherent shared memory across multiple GPUs within a node.
- **NVSwitch** — specialised switching silicon for all-to-all NVLink connectivity in DGX SuperPOD clusters.
- **InfiniBand (via Mellanox acquisition)** — NVIDIA acquired Mellanox Technologies in 2020, gaining ownership of high-speed [[Data Centre]] networking used in HPC and AI clusters.
- **[[NVIDIA DGX]]** — turnkey AI supercomputer systems integrating multiple H100/B100 GPUs, NVLink fabric, and pre-installed software stack.

#### Domain-Specific Platforms

- **[[NVIDIA Omniverse]]** — real-time simulation and collaboration platform built on Universal Scene Description (USD) for [[Digital Twin]], robotics simulation, and [[Spatial Computing]] applications.
- **NVIDIA DRIVE** — autonomous-vehicle computing platform providing sensor fusion, perception, and planning inference for self-driving systems; integrates with [[Autonomous Vehicle]] development workflows.
- **Isaac Sim / Isaac ROS** — [[Robotics]] simulation and deployment frameworks enabling sim-to-real transfer learning.
- **NVIDIA Jetson** — edge AI compute modules for embedded and [[Robotics]] deployments with power-efficient GPU cores.

### Applications and Use Cases

#### Artificial Intelligence Infrastructure

- Training [[Large Language Model]] systems (GPT-4, Llama, Gemini, Mistral) on thousands of H100 or Blackwell GPUs connected via InfiniBand fabric.
- Inference serving for [[Generative AI]] products at scale using TensorRT and Triton, often with FP8 quantisation to maximise throughput per GPU.
- [[Computer Vision]] model training and deployment for autonomous systems, medical imaging, and satellite imagery analysis.

#### High-Performance Computing

- Accelerating molecular dynamics, climate modelling, and computational fluid dynamics simulations in national labs and research institutions.
- Financial risk modelling and Monte Carlo simulation in [[Scientific Computing]] contexts.

#### Professional Visualisation

- Real-time ray tracing for CAD, product design, and architectural visualisation using Quadro/RTX professional GPUs.
- Virtual production and VFX rendering pipelines; integration with [[Spatial Computing]] tools.

#### Gaming

- Consumer GeForce GPU line providing rasterised and ray-traced [[Computer Vision]]-derived rendering; DLSS (Deep Learning Super Sampling) using [[Neural Network]] upscaling to improve frame rates.

#### Autonomous Systems and Robotics

- NVIDIA DRIVE Orin SoC used by automotive OEMs for [[Autonomous Vehicle]] perception and planning.
- Isaac platform used to train [[Robotics]] manipulation policies in simulation with synthetic data before real-world deployment.

#### Edge and Embedded AI

- Jetson modules enabling low-power [[Machine Learning]] inference for drones, industrial inspection, and smart camera systems.

### Standards and Context

- NVIDIA participates in the **PCIe** standard for GPU connectivity to host CPUs via the PCI-SIG consortium.
- The **OpenCL** standard (Khronos Group) provides a vendor-neutral alternative to [[CUDA]], though NVIDIA's proprietary ecosystem dominates AI workloads.
- **ONNX (Open Neural Network Exchange)** enables model portability, and NVIDIA's TensorRT supports ONNX import for cross-framework inference.
- NVIDIA's **NVLink** fabric competes with open interconnect standards; the **Ultra Accelerator Link (UALink)** consortium (AMD, Intel, Google, etc.) represents an industry effort to provide an open alternative for scale-out AI clusters.
- NVIDIA's software stack integration with the **Linux** kernel via open-source GPU kernel modules (released 2022) increased compatibility with HPC cluster software stacks.
- Export controls — US Bureau of Industry and Security (BIS) export restrictions on advanced AI chips (A100, H100, H800, A800) to China have materially affected NVIDIA's supply-chain and product-portfolio strategies.

### Competitive Landscape

- [[AMD]] ROCm platform offers an alternative GPU computing stack, with MI300X targeting [[Large Language Model]] inference; market share remains significantly smaller than NVIDIA in AI training.
- [[Google TPU]] (Tensor Processing Unit) is a custom ASIC optimised for [[Transformer Architecture]] workloads in Google's own data centres; not generally available to third parties.
- [[Intel Corporation]] Gaudi accelerators and Arc GPUs represent Intel's push into AI silicon; Habana Labs (acquired 2019) provides the Gaudi line.
- Custom silicon from Meta (MTIA), Amazon (Trainium/Inferentia), and Microsoft (Maia) represent hyperscaler attempts to reduce [[Data Centre]] dependence on NVIDIA.

### Provenance

