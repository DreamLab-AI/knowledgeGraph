A shipping container is a freight container: an article of transport equipment of a permanent character, strong enough for repeated use, specially designed to carry goods by one or more modes of transport without intermediate reloading, and fitted with corner fittings so that it can be secured and handled.[^1][^2]

Article II of the International Convention for Safe Containers sets out that definition.[^1] Eurostat adds that a container is stackable, easy to fill and empty, and has an internal volume of one cubic metre or more, and that swap bodies are excluded.[^2]

## Standard sizes

USC Sea Grant says intermodal cargo containers are built to standard specifications (ISO 668), generally of steel, in 20-foot or 40-foot lengths, 8 feet 6 inches high, with a gross weight capacity of 30,480 kilograms.[^3] The Glossary for transport statistics lists the main sizes as the 20 foot ISO container, 20 feet long and 8 feet wide, and the 40 foot ISO container, 40 feet long and 8 feet wide.[^4] The unit of count is the TEU, the twenty-foot equivalent unit, and a 40-foot container comprises two TEU.[^5]

## Types

A temperature-controlled form is covered at [[Reefer Container]]. The handbook of the German Insurance Association discusses refrigerated containers in its Section 7.[^5]

## Scope and distinctions

Shipping Container is the unit of [[Freight Containerisation]] and is used in [[Intermodal Transport]] and [[Container Shipping]].

## What the sources do not establish

The ISO 668 standard text is not freely available and was not opened, so dimensions are given as reported by the USC article and the glossary. The sources give no count of containers in service.

[^1]: Latvijas Vēstnesis (likumi.lv), English text of the International Convention for Safe Containers, 1972, Article II. https://likumi.lv/ta/en/starptautiskie-ligumi/id/768-csc-1972-international-convention-for-safe-containers
[^2]: Eurostat, Statistics Explained, “Glossary:Freight container”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Freight_container
[^3]: University of Southern California Sea Grant (Fawcett), “2. The Box: An Inside Look at the Shipping Container”, 2020. https://dornsife.usc.edu/uscseagrant/2020/05/29/2-the-box-an-inside-look-at-the-shipping-container/
[^4]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^5]: German Insurance Association (GDV), “Container Handbook”, Section 7 Refrigerated containers. https://containerhandbuch.de/chb_e/wild/wild_07_00.html

