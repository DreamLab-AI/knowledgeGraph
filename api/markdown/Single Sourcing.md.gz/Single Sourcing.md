Single sourcing is the decision to buy a good or service from only one supplier although several suppliers could provide it.[^1][^2]

A Pennsylvania State University supply chain course module says the difference between single and sole sourcing is one of intent: with single sourcing there are multiple potential suppliers in the marketplace but the buying firm decides to buy from only one. It lists advantages, including more consistent quality, easier root-cause investigation of quality problems with one source, and the need to approve and manage only one supplier, and says it exposes the firm to disruption from manmade events or natural disaster.[^1] The SUNY Oswego purchasing office defines a single source procurement as one in which two or more vendors can supply the commodity, technology or services but the department selects one vendor over the others.[^2]

It adds that a single source is a single contract, so administering volumes and approving changes is limited, and that only one supplier needs coordination for delivery and service.[^1]

## Scope and distinctions

UNCITRAL uses single-source procurement in a different sense: a method of last resort whose main distinct feature is the absence of competition, since the invitation to present a quotation or proposal is addressed only to one supplier or contractor.[^3] The Model Law allows it only in exceptional circumstances, such as a subject matter available only from a particular supplier with no reasonable alternative.[^4] See [[Sole Sourcing]], [[Dual Sourcing]] and [[Sourcing Strategy]].

## What the sources do not establish

Private-sector and university usages agree, but they differ from the UNCITRAL usage, and the course module gives no measured benefit or risk.[^1][^2][^3]

[^1]: Pennsylvania State University Smeal College of Business, SCM 820 course module 4, “Lesson 1: Single or Sole Sourcing”. https://courses.smeal.psu.edu/scm824fa20/scm824fa20_module_4/2011/06/SCM820-M4L1Single-or-Sole-Sourcing.html
[^2]: State University of New York at Oswego, Purchasing office, “Single and Sole Source Procurements”. https://ww1.oswego.edu/purchasing/single-and-sole-source-procurements
[^3]: United Nations Commission on International Trade Law (UNCITRAL), “Glossary of procurement-related terms used in the 2011 UNCITRAL Model Law on Public Procurement”. https://uncitral.un.org/sites/default/files/procurement/procurem/ml-procurement-2011/Glossary-e.pdf
[^4]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf

