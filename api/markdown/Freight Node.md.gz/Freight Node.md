A freight node is a place in a transport network where freight is assembled, dispersed or transferred between vehicles or modes.[^1]

None of the opened sources defines “freight node” as a term. They use “terminal” and “node” for the same ground. Rodrigue and Slack define a terminal as a facility where passengers and freight are assembled or dispersed during transportation, and as any location where freight and passengers originate, terminate or are handled in the transportation process.[^1] They add that terminals are also critical points of transfer between modes, and that intermodalism has turned them into nodes in integrated transport chains.[^1]

## Examples in the sources

Notteboom, Pallis and Rodrigue describe a seaport as a logistic and industrial node in global supply chains, acting as an interface between maritime and inland systems of circulation.[^2] See [[Seaport]]. Rodrigue and Notteboom describe a dry port as a rail or barge terminal linked to a maritime terminal with regular inland transport services.[^3] See [[Dry Port]]. The Intergovernmental Agreement on Dry Ports adopts a list of dry ports as the basis for the coordinated development of “important nodes in an international integrated intermodal transport and logistics system”.[^4]

## Scope

Rodrigue and Slack note that freight must be consolidated at a distribution centre, a port or a rail yard before shipment, so inland yards as well as ports act as consolidation points.[^1] See [[Freight Consolidation]] and [[Intermodal Transport]]. The sources do not set a size threshold for a node, and they use “hub” and “gateway” for the larger ones.[^1]

## Evidence limits

Text here is drawn from two university-hosted open textbooks that share an author, and from one treaty. No independent definition of the exact phrase was found.[^1][^2][^4]

[^1]: Jean-Paul Rodrigue and Brian Slack, The Geography of Transport Systems, “6.1 – The Function of Transport Terminals”. https://transportgeography.org/contents/chapter6/function-of-transport-terminals/
[^2]: Theo Notteboom, Athanasios Pallis and Jean-Paul Rodrigue, Port Economics, Management and Policy, “Chapter 0.1 – Defining Seaports”. https://porteconomicsmanagement.org/pemp/contents/introduction/defining-seaports/
[^3]: Jean-Paul Rodrigue and Theo Notteboom, Port Economics, Management and Policy, “Chapter 2.3 – Inland Ports / Dry Ports”. https://porteconomicsmanagement.org/pemp/contents/part2/dry-ports/
[^4]: UN Economic and Social Commission for Asia and the Pacific, “Intergovernmental Agreement on Dry Ports”. https://repository.unescap.org/bitstreams/89dfe168-8a17-472f-9bf6-12179b724714/download

