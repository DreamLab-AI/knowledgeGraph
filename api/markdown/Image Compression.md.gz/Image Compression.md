The process of encoding digital images with fewer bits by exploiting spatial redundancy, statistical structure, and the limits of human visual perception. Lossless methods (PNG, lossless WebP) permit exact reconstruction, while lossy methods (JPEG, HEIC, AVIF, JPEG XL) discard perceptually insignificant detail through transform coding, quantisation, and entropy coding to achieve far higher ratios, trading fidelity against file size for storage and transmission.

### Semantic Classification

### Content

## Definition

**Image compression** reduces the number of bits needed to represent a digital image. An uncompressed 12-megapixel photograph occupies roughly 36 MB at 8 bits per channel; compression exploits three sources of reducible information: **spatial redundancy** (neighbouring pixels are highly correlated), **statistical redundancy** (symbol distributions are far from uniform, which [[Entropy Coding]] converts into shorter codes), and **perceptual irrelevance** (the human visual system is far less sensitive to fine chrominance detail and high-frequency texture than to luminance structure).

The classical lossy pipeline, exemplified by JPEG (1992), is transform coding: convert RGB to a luma/chroma colour space and subsample chroma; partition into blocks and apply the [[Discrete Cosine Transform]] to concentrate energy into few coefficients; apply [[Quantisation]] — the sole lossy step — scaled by perceptual weighting; then entropy-code the result with Huffman or arithmetic coding. Successors changed the ingredients while keeping the architecture: JPEG 2000 used wavelets; WebP, HEIC, and AVIF reuse intra-frame tools from the VP8, HEVC, and AV1 video codecs respectively; JPEG XL combines a modern DCT path with a lossless mode and bit-exact recompression of legacy JPEGs. Lossless formats (PNG, lossless WebP/JPEG XL) instead combine spatial prediction with dictionary or entropy coding, achieving around 2–3:1 on photographs versus 10–50:1 for perceptually transparent lossy coding.

Image compression contrasts with [[Video Compression]] chiefly in what redundancy is available: video adds the temporal dimension, removed through motion estimation and inter-frame prediction, whereas a still image coder has only spatial and statistical structure to work with — which is why modern still formats are essentially a video codec's intra frame.

## Current Landscape

- **Web formats**: JPEG remains ubiquitous and AVIF is now the practical modern default — roughly 30–50% smaller than JPEG at equal quality and, per caniuse, supported by all major browsers at about 93–94% of global users (Chrome 85+, Firefox 93+, Safari 16.4+, Edge, Opera). WebP retains near-universal support as a fallback.
- **JPEG XL reversal (2026)**: after Google removed experimental JXL from Chrome 110 in February 2023, a memory-safe Rust decoder (jxl-rs) was vendored into Chromium in late 2025 and shipped in **Chrome 145 (February 2026)** behind the `chrome://flags/#enable-jxl-image-format` flag; **Firefox 152 (June 2026)** added it behind a preference. Only Safari (since v17, 2023) enables JPEG XL by default, so as of mid-2026 JXL is still not production-ready as a primary web format and needs AVIF/JPEG fallbacks.
- **Quality measurement**: PSNR and SSIM are giving way to perceptual metrics (MS-SSIM, butteraugli, LPIPS) that better track human judgements, which matters because codecs are tuned against their evaluation metric.
- **Learned compression**: neural codecs using variational autoencoders with hyperpriors (Ballé et al.) and, more recently, diffusion-based decoders exceed classical codecs in rate–distortion terms; ISO/IEC's first learning-based image standard, JPEG AI (ISO/IEC 6048-1), was published in October 2024 with reported gains above 25% over the VVC intra anchor. Trade-offs remain decode cost and non-deterministic detail synthesis.
- **Systems context**: responsive image pipelines (srcset, CDN transcoding) routinely store one master and derive per-device variants, making the codec choice an infrastructure decision as much as a format one.

  **Sources**:

- https://caniuse.com/avif
- https://theimagecdn.com/docs/jpeg-xl-explained
- https://speedvitals.com/blog/avif-vs-jpeg-xl/
- https://freetoolonline.com/news/jpeg-xl-returns-chrome-firefox.html

