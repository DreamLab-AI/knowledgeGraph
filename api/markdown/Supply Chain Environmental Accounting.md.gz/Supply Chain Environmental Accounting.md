Supply chain environmental accounting is the measurement and reporting of the environmental effects of a supply chain, such as its emissions and material flows, and no source opened here defines the term, so this page describes two established methods that fall within it.[^1][^2]

## Emissions inventories

The GHG Protocol Scope 3 Standard sets out how a company accounts for emissions from its value chain. It says that by developing a scope 3 inventory a company can identify where the largest energy, material and resource use is within the supply chain, and can identify the largest emission sources, which it calls hot spots, in the value chain.[^1] Its example is a company whose largest source of value chain emissions is contracted logistics, which may choose to change packaging to increase the volume per shipment or use more low-carbon logistics providers.[^1] Detail is at [[Scope 3 Emissions]].

Companies are likely to face additional challenges in collecting data and ensuring data quality for scope 3, the standard warns, because the emissions come from activities not under the reporting company's ownership or control.[^1] The Science Based Targets initiative says that supplier engagement targets offer a way to influence decarbonisation within a company's supply chain when granular emissions data is challenging to track or unavailable.[^3]

## Material accounts

Material flow accounts show the amounts of physical inputs into an economy, material accumulation in the economy and outputs to other economies or back to nature.[^4] An MIT lecture slide, quoting Brunner and Rechberger, defines material flow analysis as a systematic assessment of the flows and stocks of materials within a system defined in space and time.[^2] Detail is at [[Material Flow Analysis]]. The Eurostat guide works at national scale, so its accounts are not supply chain accounts.

## Scope and limits

Both methods are used in [[Sustainable Supply Chains]], and [[Supply Chain Decarbonisation]] relies on the first. The sources do not describe a method that combines emissions and material accounts for one supply chain, and they do not cover life cycle assessment, whose standards are cite-only and were not opened.

[^1]: World Resources Institute and World Business Council for Sustainable Development, GHG Protocol, “Corporate Value Chain (Scope 3) Accounting and Reporting Standard”. https://ghgprotocol.org/sites/default/files/standards/Corporate-Value-Chain-Accounting-Reporing-Standard_041613_2.pdf
[^2]: Jeremy Gregory, MIT course 3.560/ESD.123 Industrial Ecology, lecture slides (OCW copy hosted by ocw.iti.hr), “Material Flow Analysis”. https://ocw.iti.hr/courses/engineering-systems-division/esd-123j-systems-perspectives-on-industrial-ecology-spring-2006/lecture-notes/lec14.pdf
[^3]: Science Based Targets initiative (developed by WWF), version 1.1, July 2025, “Engaging Supply Chains on the Decarbonization Journey: A Guide to Developing and Achieving Scope 3 Supplier Engagement Targets”. https://sciencebasedtargets.org/resources/files/Supplier-Engagement-Guidance.pdf
[^4]: Eurostat, European Commission, 2001, “Economy-wide material flow accounts and derived indicators: a methodological guide”. https://ec.europa.eu/eurostat/documents/1798247/6191533/3-Economy-wide-material-flow-accounts...-A-methodological-guide-2001-edition.pdf

