Smart Metering is the deployment of digital utility meters that record consumption of electricity, gas, water or heat at fine time resolution and communicate readings automatically to the utility and consumer. It replaces manual periodic readings with two-way communication, enabling near real-time monitoring, remote configuration and dynamic tariffs. Smart meters are a foundational component of advanced metering infrastructure and the broader smart grid.

### Overview

- Smart metering transforms the utility meter from a passive register read manually into a networked sensor that streams high-resolution consumption data. Two-way communication lets utilities perform remote reads, firmware updates and supply control, while customers gain visibility into usage. As the edge layer of advanced metering infrastructure, smart meters enable time-of-use tariffs, demand response and faster outage detection.

### Key aspects

- High-resolution interval consumption recording
- Two-way communication for remote read and control
- Integration with advanced metering infrastructure head-ends
- Support for dynamic and time-of-use tariffs
- Data privacy and security of granular usage records

### Mechanisms

- High-resolution interval consumption recording
- Two-way communication for remote read and control
- Integration with advanced metering infrastructure head-ends

### Applications

- Automated billing and remote meter reading
- Demand response and load shifting programmes
- Outage detection and grid situational awareness
- Consumer energy feedback and efficiency apps
- Distributed energy resource integration

### Provenance

