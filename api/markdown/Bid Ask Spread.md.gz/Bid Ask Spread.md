The bid-ask spread is the difference between the highest price a buyer is willing to pay (the bid) and the lowest price a seller will accept (the ask) for an asset at a given moment. It is a core measure of market liquidity and an implicit transaction cost borne by traders who cross the spread. Narrow spreads indicate liquid, competitive markets, while wide spreads reflect thin liquidity, volatility, or elevated risk for liquidity providers.

### Overview

- The bid-ask spread emerges from the top of the [[Order Book]], where the best bid and best ask meet.
- It compensates market makers for inventory risk and adverse selection while serving as a real-time gauge of [[Liquidity]].
- Spread dynamics are central to [[Market Microstructure]] research and to [[High-Frequency Trading]] strategies.

### Key aspects

- Quoted spread: the raw difference between best bid and best ask.
- Effective spread: realised cost relative to the mid-price at execution.
- Determinants: liquidity, volatility, order-flow toxicity, and competition among market makers.
- Inventory and adverse-selection components that drive market-maker quotes.
- Relationship to depth and the broader [[Order Book]] shape.

### Applications

- Estimating implicit trading costs and transaction-cost analysis.
- Liquidity monitoring across venues and asset classes.
- Market-maker quoting and inventory management.
- Execution algorithms that minimise spread crossing.

### Provenance

