A supply chain cost measure quantifies the expense of operating a supply chain or one of its processes.[^1][^2]

SCOR 12.0 treats cost as one of its five performance attributes, alongside reliability, responsiveness, agility and asset management efficiency.[^1] At level 1 it lists Total Supply Chain Management Costs and Costs of Goods Sold. At level 2 it lists Cost to Plan, Cost to Source, Cost to Make, Cost to Deliver and Cost to Return.[^1] The quick reference guide gives only names for these metrics, so this page does not say how they are calculated.

Gunasekaran, Patel and Tirtiroglu name inventory and logistics costs among the groups of measures that their list of metrics emphasises, together with suppliers, delivery performance and customer service.[^2]

## Scope and distinctions

Cost measures sit under [[Supply Chain Performance Measure]]. SCOR keeps cost apart from asset management efficiency, which holds Cash-to-Cash Cycle Time, so a cost figure and a working capital figure are separate measures.[^1] Related pages cover [[Total Landed Cost]] and [[Cost to Serve]], and the hub is [[Supply Chain Performance and Finance]].

The SCOR cost metrics are organised by process, from planning to returns, which lets a total be broken down to the process that generated it.[^1] That use follows from the level structure in which level-2 metrics serve as diagnostics for the level-1 metrics.[^1]

## What the sources do not establish

Evidence is thin. No source opened here defines total supply chain cost, lists which cost components belong in it, or compares allocation methods. Beamon's 1999 survey of supply chain performance measures was not accessible, and neither was the CSCMP glossary file, so the page rests on SCOR metric names and one paper abstract.[^1][^2]

[^1]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf
[^2]: A. Gunasekaran, C. Patel and E. Tirtiroglu, International Journal of Operations and Production Management 21(1-2), 2001 (Penn State record, abstract only), “Performance measures and metrics in a supply chain environment”. https://pure.psu.edu/en/publications/performance-measures-and-metrics-in-a-supply-chain-environment/

