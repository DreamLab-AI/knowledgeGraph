Regulatory enforcement is the set of actions through which a competent authority compels compliance with laws and rules and sanctions those who breach them. It encompasses investigation, supervision, market surveillance, and the imposition of remedies such as fines, restitution, licence revocation or criminal referral. In financial markets it deters misconduct, protects consumers and investors, and sustains confidence in the integrity of the system.

- Regulatory enforcement is the authority-led process of compelling [[Compliance]] and sanctioning breaches, implementing [[Financial Regulation]] and [[Securities Regulation]] in service of the [[Rule of Law]].
- It relies on [[Market Surveillance]], [[Audit]] and investigation.

### Overview

- Enforcement closes the loop between rule-making and behaviour: without credible consequences, regulation has little deterrent effect.
- Authorities monitor markets, investigate suspected breaches, and apply graduated sanctions proportionate to harm and culpability.
- International coordination, through bodies such as [[IOSCO]], aligns standards and supports cross-border cases.

### Key aspects

- Supervision and ongoing monitoring of regulated entities.
- Investigation and evidence-gathering into suspected breaches.
- Sanctions including fines, restitution, bans and licence action.
- Deterrence and behavioural change across the wider market.
- Due process and proportionality in applying penalties.

### Mechanisms

- Surveillance and reporting detect anomalies; investigations establish facts; administrative or judicial proceedings impose remedies and penalties.

### Applications

- Securities market abuse and insider-dealing cases.
- Anti-money-laundering and sanctions breaches.
- [[Consumer Protection]] in retail financial products.
- Prudential supervision of regulated firms.

### Provenance

