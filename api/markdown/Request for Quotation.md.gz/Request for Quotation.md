A request for quotation (RFQ) is a request to suppliers for a price for a specified good or service, used for readily available items of low value.[^1][^2][^3]

UNCITRAL's Model Law allows a request for quotations for readily available goods or services that are not specially produced or provided to the buyer's description and for which there is an established market, so long as the estimated value is below a threshold in the procurement regulations.[^1] Its glossary describes the method by its main distinct feature: suppliers submit only one quotation, which cannot be changed or negotiated, and the method is available only for low-value simple off-the-shelf items.[^2] The successful quotation is the lowest-priced quotation meeting the needs of the procuring entity as set out in the request.[^1]

## In United States federal practice

Before requesting quotations or offers, the Federal Acquisition Regulation tells the contracting officer to consider the nature of the article and whether it is highly competitive and readily available in several makes or brands, whether an electronic commerce method is available, the urgency and dollar value of the purchase, and past experience of specific dealers' prices.[^3] It also says solicitations under simplified acquisition procedures may require either a quotation or an offer.[^4] When soliciting quotations or offers the contracting officer must notify potential quoters or offerors of the basis for award, either price alone or price and other factors such as past performance and quality.[^3] That differs from the UNCITRAL method, in which price alone decides and quotations may not be negotiated.[^1][^3]

See [[Request for Proposal]], [[Reverse Auction]], [[Sourcing Event]] and [[Procurement]].

## What the sources do not establish

All sources are public-procurement rules, and thresholds vary by jurisdiction, so the page gives no values. Private-sector use of the term was not separately sourced.[^1][^3]

[^1]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf
[^2]: United Nations Commission on International Trade Law (UNCITRAL), “Glossary of procurement-related terms used in the 2011 UNCITRAL Model Law on Public Procurement”. https://uncitral.un.org/sites/default/files/procurement/procurem/ml-procurement-2011/Glossary-e.pdf
[^3]: US General Services Administration and Department of Defense, Federal Acquisition Regulation, acquisition.gov, “FAR 13.106-1 Soliciting competition.”. https://www.acquisition.gov/far/13.106-1
[^4]: US General Services Administration and Department of Defense, Federal Acquisition Regulation, acquisition.gov, “FAR 2.101 Definitions”. https://www.acquisition.gov/far/2.101

