HTML (HyperText Markup Language) is the standard markup language for creating and structuring documents and applications on the World Wide Web. It uses a system of nested elements and attributes to describe the semantic structure of content such as headings, paragraphs, links, images, and interactive controls. Web browsers parse HTML into a document object model that is rendered visually and made accessible to assistive technologies and scripts.

### Overview

- HTML is the foundational layer of the open web platform, working alongside CSS for presentation and scripting for behaviour. Its design favours graceful degradation: browsers ignore elements and attributes they do not understand rather than failing, which has allowed the language to evolve continuously while preserving compatibility with older documents. Successive revisions have added native multimedia, semantic sectioning elements, and rich form controls.

### Key aspects

- Documents are trees of nested elements delimited by tags and qualified by attributes.
- Semantic elements convey the meaning of content to browsers, search engines, and assistive technologies.
- Browsers parse HTML into a Document Object Model that scripts and styles can manipulate.
- The language is designed for robustness, tolerating malformed markup through well-defined error recovery.

### Applications

- Structuring web pages and web application interfaces.
- Embedding multimedia, forms, and interactive controls natively.
- Conveying document semantics for accessibility and search indexing.
- Serving as the rendering target for templating and frontend frameworks.

### Provenance

