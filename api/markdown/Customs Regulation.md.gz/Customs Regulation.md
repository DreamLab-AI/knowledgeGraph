Customs regulation is the body of legal instruments that governs customs: the statutes, regulations, codes and conventions that apply to the importation, exportation, movement and storage of goods.[^1][^2]

The Revised Kyoto Convention of the World Customs Organization defines Customs law as the statutory and regulatory provisions relating to importation, exportation, movement or storage of goods, whose administration and enforcement are specifically charged to the Customs, together with any regulations made by the Customs under their statutory powers.[^1] It defines the Customs territory as the territory in which the Customs law of a Contracting Party applies, and Customs formalities as the operations that must be carried out by the persons concerned and by the Customs to comply with that law.[^1] The Convention entered into force on 3 February 2006.[^3]

## Examples by jurisdiction

In the European Union, customs legislation means the Union Customs Code and the provisions supplementing or implementing it adopted at Union or national level, the Common Customs Tariff, the legislation setting up a Union system of reliefs from customs duty, and international agreements containing customs provisions that are applicable in the Union.[^2] See [[EU Union Customs Code]].

In the United Kingdom, the Customs and Excise Management Act 1979 is an Act to consolidate the enactments relating to the collection and management of the revenues of customs and excise.[^4] In the United States, regulations of US Customs and Border Protection sit in Chapter I of Title 19 of the Code of Federal Regulations, whose parts include Part 141 on entry of merchandise, Part 24 on customs financial and accounting procedure and Part 101 on general provisions.[^5]

## International layer

Beyond national law, the [[WTO Trade Facilitation Agreement]] contains provisions on publication of information, advance rulings and release and clearance of goods.[^6] The Revised Kyoto Convention provides standards for the simplification and harmonisation of customs procedures.[^3]

## Scope and distinctions

Related concepts are covered at [[Customs Procedure]], [[Customs Declaration]] and [[Customs Duty]]. Customs duties, in the Kyoto definition, are the duties laid down in the Customs tariff to which goods are liable on entering or leaving the Customs territory.[^1]

## What the sources do not establish

Opened sources use the terms customs law and customs legislation more often than customs regulation, so this page treats them as one concept. They do not rank the instruments or give a complete list for any jurisdiction, and the examples above are illustrations, not a survey.

[^1]: World Customs Organization, Revised Kyoto Convention General Annex, Chapter 2 on definitions. https://www.wcoomd.org/en/topics/facilitation/instrument-and-tools/conventions/pf_revised_kyoto_conv/kyoto_new/gach2.aspx
[^2]: European Union, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^3]: World Customs Organization, “The Revised Kyoto Convention”. https://www.wcoomd.org/en/topics/facilitation/instrument-and-tools/conventions/pf_revised_kyoto_conv.aspx
[^4]: legislation.gov.uk, “Customs and Excise Management Act 1979”. https://www.legislation.gov.uk/ukpga/1979/2/introduction
[^5]: Cornell Law School Legal Information Institute, “19 CFR Chapter I - U.S. CUSTOMS AND BORDER PROTECTION, DEPARTMENT OF HOMELAND SECURITY; DEPARTMENT OF THE TREASURY”. https://www.law.cornell.edu/cfr/text/19/chapter-I
[^6]: World Trade Organization, “Agreement on Trade Facilitation”. https://www.wto.org/english/docs_e/legal_e/tfa-nov14_e.htm

