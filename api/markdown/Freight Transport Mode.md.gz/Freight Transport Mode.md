A freight transport mode is the way in which goods are physically carried: by rail, road, inland waterway, sea, air or pipeline.[^1][^2]

Eurostat lists rail, maritime, road, inland waterways and air as modes for passengers and goods, and pipelines as a goods-only mode.[^1] The Glossary for transport statistics defines a mode of transport as a method of transport used for the carriage of goods and passengers, and sets the classification for statistical reporting as rail, road, inland waterways, maritime, pipeline, air and an unknown mode.[^2]

## Shares of freight

Eurostat defines the modal split as the relative share of each mode, and for freight it is based on tonne-kilometres.[^1] Among five modes, maritime had the largest share of EU freight transport performance over the last decade, 67.0% (4 753 billion tonne-km) in 2024, its lowest point of the decade. Road had 25.7% (1 821 billion tonne-km), rail 5.4% (385 billion tonne-km) and air 0.2% (16 billion tonne-km) in 2024.[^3] For UK domestic freight in 2024, 168 billion tonne-kilometres were moved by road, 21 by water and 17 by rail, which is 82%, 10% and 8%.[^4] The two sets are not comparable: the EU series covers five modes and the UK series covers domestic freight only.

## Choosing a mode

Eurostat says aircraft are an expensive mode in terms of tonne-kilometres and only competitive for longer distances and relatively light high-value or perishable goods.[^5] An April 2009 briefing from the International Air Transport Association says the heavier, lower unit value bulk commodities and oil will always be shipped by sea or possibly land.[^6]

## Scope and distinctions

Freight Transport Mode is part of [[Freight Transportation]]. Its mode pages are [[Road Freight]], [[Rail Freight]], [[Ocean Freight]] and [[Air Freight]], and a related page is [[Intermodal Transport]]. The ontology links it to [[Carbon Footprint]].

## What the sources do not establish

Tonne-kilometre shares weight long distances heavily, so they do not show shares of tonnes or value. The opened sources give no emissions or unit-cost comparison between modes, and the page makes none.

[^1]: Eurostat, Statistics Explained, “Glossary:Transport mode”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Transport_mode
[^2]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^3]: Eurostat, Statistics Explained, “Freight transport statistics - modal split”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Freight_transport_statistics_-_modal_split
[^4]: UK Department for Transport (GOV.UK), “Transport Statistics Great Britain: 2024 Freight”. https://www.gov.uk/government/statistics/transport-statistics-great-britain-2025/transport-statistics-great-britain-2024-freight
[^5]: Eurostat, Statistics Explained, “Air freight transport statistics”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Air_freight_transport_statistics
[^6]: International Air Transport Association, economic briefing of April 2009 on air freight and world trade. https://www.iata.org/en/iata-repository/publications/economic-reports/air-freight-and-world-trade

