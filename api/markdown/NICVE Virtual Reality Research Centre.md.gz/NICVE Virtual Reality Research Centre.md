A UK academic research centre active from the late 1990s through to the early 2020s, based at the University of Salford, that advanced industrial applications of virtual reality including CAVE systems, immersive workbenches, and telepresence. NICVE succeeded the National Advanced Robotics Research Centre and produced foundational work in multi-user virtual environments, real-time rendering on SGI hardware, and later human-scale mixed reality telecollaboration. The centre evolved through multiple directors and phases before being disbanded in the early 2020s as institutional interest waned.

### Semantic Classification

### Content

- The NICVE was a major academic VR research centre in the late 90's and and 2000's. It followed on from the pioneering work by [Bob Stone](https://www.linkedin.com/in/prof-bob-stone-21b86918/), [Andy Connell](https://www.linkedin.com/in/andrew-connell-vr/),  in the National Advanced Robotics Research Centre (NARRC) at The University Of Salford.
- I was a student in the first year of the [Virtual Reality Master Programme](https://www.timeshighereducation.com/features/salford-offers-virtual-reality-masters/98524.article) at the NICVE, under [Nick Avis](https://www.linkedin.com/in/nick-avis-885177211/), [Karen Padmore](https://www.linkedin.com/in/karen-padmore-a061961/), [Terrence Fernando](https://www.linkedin.com/in/terrence-fernando-6972411/), and [Rob Aspin](https://www.linkedin.com/in/professor-rob-aspin-85655340/). I later worked in the centre under [David Roberts](https://www.linkedin.com/in/david-roberts-0b6b181b/) as it evolved until it was disbanded early in this decade as interest in extended reality and telepresence waned.
- This was from our first paper, published by another of our lecturers; [Ruth Aylett](https://www.linkedin.com/in/ACoAAAACrVwB204Ab7f4c5tb6XmlXPpd9ov_mrA), which we did as the project at the end of the masters programme. Every single triangle in that was hand drawn separately, one at a time, by me. Modelling wasn't really a proper thing back then. It was CAD, or Medit on an SGI O2. You can see the resemblance to N64 games of the era which were all the same hardware/software pipelines. [https://www.aaai.org/Papers/Symposia/Fall/1999/FS-99-01/FS99-01-014.pdf](https://www.aaai.org/Papers/Symposia/Fall/1999/FS-99-01/FS99-01-014.pdf)

![prospectus.bmp](assets/prospectus_1704195118229_0.bmp)

- [Dr Simon Campion](https://www.linkedin.com/in/ACoAAAfPu4gBKe76g1PvTLMvi7uMUwf9ZAMC60s) using our experimental Barco based immersion workbench. Again a mockup, but about right. We took this to Farnborough airshow in support of [Euravia Engineering & Supply Co. Limited](https://www.linkedin.com/company/euravia/)

![workbench.jpg](assets/workbench_1704195169470_0.jpg)

- The NICVE 4 sided system, which was powered by a three rack SGI Onyx2 IR2 "supercomputer". It was made of wood because the tracking systems was electromagnetic (flock of birds). When trains went past everything wobbled a bit. I used to sit in the dark reconverging the CRT guns every week with music blaring. It was a good task. It was I think the first such system outside of the USA, [where it was pioneered](https://ualr.edu/eac/cave/).

![1666439576666.png|1051](assets/1666439576666_1708174000080_0.png)

- One of the SGI cabs being delivered. Must be 1997 then? They were brand new. That was expensive. Really really expensive. We ran the whole building off them.

![Untitled-23.jpg](assets/Untitled-23_1704195226252_0.jpg)

- This was our reality room, with 3 edge blended Barco projectors. They were RGB CRT guns. Pre digital. Wow. This is a mockup because there wasn't enough light for cameras of the time to capture the glory. That's a laser scan of a 747 by Mensi, who sold us a laser scanner for a couple of hundred thousand pounds that took a couple of samples a second.

![1666439697003.png](assets/1666439697003_1708174028512_0.png)

- This was the Trimension Relocatable Reality Centre, at GMEX in Manchester in this case, and a very young me. The compute on the left is an SGI Onyx2 Deskside.

![DSCF2204.JPG](assets/DSCF2204_1704195427620_0.JPG)

- I was a member of the science team on the first ever jump of DaVinci's parachute design, for an IMAX film called [Adrenaline rush, The science of risk (2002) Video Pinkbike](https://www.pinkbike.com/video/464827/)

![Screenshot 2024-01-29 175325.png](assets/Screenshot_2024-01-29_175325_1706551309172_0.png)

### Adrenaline Rush

### Provenance

