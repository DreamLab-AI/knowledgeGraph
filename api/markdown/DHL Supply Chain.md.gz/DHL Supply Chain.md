DHL Supply Chain is the contract logistics division of the DHL group. DHL's own United Kingdom site presents it under the title “DHL Supply Chain – The world’s leading contract logistics provider”, which is the company's description of itself, and lists it among the group's divisions with DHL Express, DHL Global Forwarding, DHL Freight and DHL eCommerce.[^1]

## What the sources show

The Industrial Ontologies Foundry gives DHL as an example of a storage service provider when it provides industrial warehousing and inventory management services to manufacturers, and lists DHL with FedEx and UPS as an example of an integrated carrier business organisation.[^2] The ontology names the group, not the division, so it supports the activity but not the division by name.[^2]

A 2026 Commission decision on parcel joint ventures lists, among DHL group companies in its perimeter, DHL Excel Supply Chain (Spain) S.L.U., which operates logistics services and supply chain solutions.[^3]

## Role in the supply chain

In this vault DHL Supply Chain is a class under [[Third-Party Logistics Provider]], because its own description is contract logistics.[^1]

## What the sources do not establish

Evidence is thin. The division's description rests mainly on DHL's own page, and the independent sources name the group or a national subsidiary, not the division. The “world’s leading” wording is a claim by the company, and no independent ranking was opened. The sources give no figures for sites, staff or revenue that were checked against an independent count; the page shows figures dated to the end of the previous half year, and they are not repeated here.[^1]

[^1]: DHL Supply Chain, United Kingdom site page. https://www.dhl.com/gb-en/home/supply-chain.html
[^2]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^3]: European Commission, Case M.11942 Deutsche Post / CTT / JVs, decision of 18 March 2026. https://ec.europa.eu/competition/mergers/cases1/202623/M_11942_1354.pdf

