Asset Inventory is the systematic, continuously maintained catalogue of all hardware, software, data stores, network devices and cloud resources within an organisation's environment. It establishes the authoritative record of what must be protected, forming the foundation for vulnerability management, configuration control and incident response. An accurate inventory enables defenders to scope attack surfaces, prioritise patching and detect unauthorised or rogue assets.

### Overview

- Asset inventory turns an unknown, sprawling estate into a governed, queryable register. Discovery agents, network scanners and cloud APIs feed a normalised database keyed by ownership, criticality, location and lifecycle state. Because attackers exploit the assets defenders forget, completeness and freshness are the primary quality metrics.

### Key aspects

- Discovery: active and passive scanning, agent-based enumeration and cloud provider API ingestion to detect every reachable asset.
- Classification: tagging assets by business criticality, data sensitivity, owner and environment to drive risk-based prioritisation.
- Lifecycle tracking: recording provisioning, change, decommissioning and ownership transfers so the register reflects reality.
- Reconciliation: deduplicating and merging records from multiple sources into a single authoritative entry per asset.
- Drift detection: flagging rogue, shadow-IT or unmanaged assets that appear outside approved provisioning channels.

### Applications

- Scoping vulnerability scans and patch campaigns to ensure no system is missed.
- Feeding configuration management databases (CMDBs) and IT service management workflows.
- Accelerating incident response by mapping affected systems and their owners during a breach.
- Demonstrating regulatory compliance for frameworks that mandate a known, controlled estate.

### Provenance

