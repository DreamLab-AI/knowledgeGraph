The central processing unit (CPU) is the primary computational component of a computer, executing the instructions of programs through arithmetic, logic, control, and input/output operations. It fetches instructions from memory, decodes them, and executes them in a repeating cycle, coordinated by a control unit and carried out by arithmetic-logic units across one or more cores. As a general-purpose processor it contrasts with specialised accelerators that optimise for narrower, highly parallel workloads.

### Overview

- The CPU executes the fetch-decode-execute cycle that drives general-purpose computation.
- A control unit sequences operations while arithmetic-logic units perform the actual calculations.
- Modern CPUs integrate multiple cores, cache hierarchies, and pipelines to raise throughput.
- Compared with a GPU, a CPU favours low-latency execution of complex, branchy, sequential workloads.

### Key aspects

- The fetch-decode-execute cycle is the fundamental unit of CPU operation.
- Arithmetic-logic units perform integer and logical computation.
- Cache hierarchies reduce the latency of memory access.
- Multiple cores enable thread-level [[Parallel Computing]].
- Contrasts with the [[Graphics Processing Unit]], which favours wide data parallelism.

### Applications

- Running operating systems and general-purpose application logic.
- Orchestrating workloads and dispatching tasks to accelerators.
- Powering [[Edge Computing]] devices where general-purpose flexibility matters.
- Executing latency-sensitive, control-heavy code paths across server and client systems.

### Provenance

