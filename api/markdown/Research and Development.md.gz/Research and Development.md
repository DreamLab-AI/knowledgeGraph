Research and development (R&D) is the systematic, investigative activity undertaken to create new knowledge and to apply it in novel products, processes and services. It spans basic research that expands understanding, applied research that targets specific problems, and experimental development that turns findings into working technology. R&D is the principal engine of innovation and long-term competitive advantage in technology-intensive fields.

### Overview

- Research and Development is situated within the [[Innovation]] area of the ai domain.
- It connects a number of established concepts in the knowledge graph, anchoring edges that previously referenced it without a defining page.

### Key aspects

- Scientific Research (hasPart)
- Engineering Design (hasPart)
- Prototyping (hasPart)
- Innovation (partOf)
- Prototyping (uses)
- Academic Research (uses)

### Mechanisms

- Operates through its relationships with [[Innovation]] and [[Scientific Research]].
- Provides capabilities consumed by dependent and enabled classes listed under Relationships.

### Applications

- Supports [[Innovation]]
- Supports [[Technology Transfer]]
- Supports [[Innovation]]

### Provenance

