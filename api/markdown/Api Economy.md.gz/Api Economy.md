The API economy is the ecosystem of business value created when organisations expose their data and services as application-programming interfaces that other parties can consume, compose, and monetise. By packaging capabilities as products, firms turn internal functions into reusable building blocks that partners and developers integrate, enabling new revenue streams, faster innovation, and platform network effects. It underpins models such as open banking and embedded services, and its growth depends on robust API management, gateways, and developer experience to govern access, security, and consumption at scale.

### Overview

- Api Economy sits within the broader category of [[Platform Economy]], which it specialises.
- It connects to a network of 12 related classes across the knowledge graph, anchoring edges that previously pointed to an undefined node.

### Key aspects

- uses: [[API Gateway]]
- uses: [[REST API]]
- uses: [[GraphQL]]
- requires: [[API Management]]
- requires: [[API]]

### Mechanisms

- Api Economy operates through its constituent parts and dependencies, integrating with adjacent systems to deliver its function within finance.
- Depends on [[Application Programming Interface]] for correct operation.

### Applications

- Applied to advance [[Microservices]].
- Applied to advance [[Platform Economy]].
- Applied to advance [[Webhook]].
- Applied to advance [[Open Banking]].
- Applied to advance [[Digital Platform]].

### Provenance

