The Libertarian Thesis, as represented here by Hans-Hermann Hoppe's 'Democracy: The God That Failed', argues that democratic governance systematically expands state power and erodes individual liberties relative to private property-based natural order, and that radical decentralisation, covenant communities, and privatisation of public goods offer a more consistent path to a free society.

### Semantic Classification

### Content

- ---
  title: Democracy: The God That Failed - A Mind Map
  markmap:
  colorFreezeLevel: 2
  ---

# **Democracy: The God That Failed**

- Inherent flaws of democracy
  - Leads to increased state power
  - Promotes short-term policies
  - Erodes individual freedoms
- Moral and ethical deficiencies
  - Majority rule does not equate to justice
  - Legitimizes coercion and expropriation
- Historical failures of democracy
  - Rise of totalitarian regimes
  - Economic inefficiencies
- Monarchy as privately owned government
  - Promotes long-term planning
  - Incentivizes capital preservation
- Lower time preference of monarchs
  - Interest in preserving the realm's value
  - Less incentive for excessive taxation and exploitation
- Historical examples of monarchical benefits
  - More stable and prosperous societies
- Stateless society based on private property
  - Voluntary interactions and contracts
  - Absence of coercion and forced integration
- Role of private defense agencies
  - Efficient protection of property rights
  - Market-based solutions for security
- Importance of natural elites
  - Emergence of leaders based on merit and virtue
  - Role in maintaining social order
- Errors in classical liberal thought
  - Support for limited government
  - Failure to recognize inherent flaws of the state
- Inconsistency between classical liberalism and democracy
  - Democracy undermines individual liberties
  - Leads to expansion of state power
- Importance of local autonomy
  - Right of secession as a check on state power
  - Benefits of smaller, independent political units
- Role in promoting economic freedom
  - Competition among jurisdictions
  - Enhanced individual choice and mobility
- Strategy for achieving a free society
  - Peaceful secession movements
  - Delegitimization of the central state
- Impact on economic behavior
  - High time preference leads to short-term focus
  - Low time preference promotes long-term planning
- Role in societal development
  - Lower time preference in monarchies
  - Higher time preference in democracies
- Foundation of a free society
  - Protection of individual liberties
  - Basis for economic prosperity
- Erosion under democracy
  - Increased taxation and regulation
  - Forced integration and redistribution
- Negative consequences of state-imposed integration
  - Increased social conflict
  - Erosion of property values
- Contrast with voluntary association
  - Benefits of free choice in association
  - Role in maintaining social harmony
- Critique of socialist economic policies
  - Inefficiencies and misallocation of resources
  - Lack of incentives for production
- Process of desocialization
  - Privatization of state-owned assets
  - Restoration of property rights
- Natural elites in a free society
  - Emergence based on merit and achievement
  - Role in providing leadership and justice
- Corruption of elites under democracy
  - Rise of political opportunists
  - Decline of moral and intellectual standards
- Comparison of monarchies and democracies
  - Examples of successful monarchies
  - Failures of democratic regimes
- Analysis of historical trends
  - Rise and fall of civilizations
  - Impact of political systems on economic development
- Austrian School of Economics
  - Emphasis on individual action and subjective value
  - Critique of state intervention
- Public Choice Theory
  - Analysis of political decision-making
  - Incentives faced by politicians and bureaucrats
- Natural rights philosophy
  - Importance of individual liberty and property rights
  - Critique of coercion and aggression
- Moral basis of voluntary interactions
  - Respect for individual autonomy
  - Condemnation of forced redistribution
- Encouraging local autonomy and self-governance
  - Reducing the power of central governments
  - Allowing for diverse social and economic experiments
- Supporting peaceful secession movements
  - Recognizing the right of self-determination
  - Avoiding violent conflict
- Transferring state-owned assets to private individuals
  - Restoring property rights
  - Enhancing economic efficiency
- Eliminating state monopolies
  - Promoting competition in all sectors
  - Allowing for market-based solutions
- Implementing selective immigration policies
  - Prioritizing skilled and productive immigrants
  - Protecting the interests of existing citizens
- Avoiding forced integration
  - Allowing for voluntary association and dissociation
  - Respecting cultural and social differences
- Eliminating social security, and other welfare programs
  - Restoring individual responsibility
  - Reducing dependency on the state
- Promoting private charity and mutual aid
  - Encouraging voluntary cooperation
  - Strengthening family and community bonds
- **Erosion of Traditional Values**
  - Breakdown of family structures
  - Decline of moral standards
  - Rise of cultural relativism
- **Expansion of State Power**
  - Increased taxation and regulation
  - Growth of bureaucracy
  - Infringement on individual liberties
- **Economic Consequences**
  - Misallocation of resources
  - Inflation and currency debasement
  - Stifling of economic growth
- **Social Consequences**
  - Increased crime and social disorder
  - Dependency on the welfare state
  - Social fragmentation and conflict
- **Ethical Foundation**
  - Based on self-ownership and original appropriation
  - Justification for exclusive control over resources
- **Economic Benefits**
  - Incentives for production and innovation
  - Efficient allocation of resources
  - Protection against aggression and theft
- **Social Implications**
  - Basis for voluntary cooperation and exchange
  - Foundation for a free and prosperous society
- **Minimal State vs. Anarcho-Capitalism**
  - Debate within libertarian thought
  - Arguments for statelessness
- **State as a Source of Disorder**
  - Monopoly on coercion leads to abuse of power
  - State intervention distorts market processes
- **State's Inability to Provide True Security**
  - Forced integration exacerbates social tensions
  - State's own actions often threaten individual security
- **Critique of Open Borders**
  - Potential for social and economic disruption
  - Strain on public resources and welfare systems
- **Advocacy for Controlled Immigration**
  - Importance of cultural compatibility
  - Prioritizing skilled and productive immigrants
- **Role of Private Property Owners**
  - Right to exclude or admit individuals
  - Decentralized control over immigration
- **Decentralized Political Order**
  - Importance of local autonomy and self-governance
  - Role of secession in limiting state power
- **Market-Based Provision of Security**
  - Private defense agencies and insurance companies
  - Competition and innovation in security provision
- **Restoration of Traditional Values**
  - Emphasis on family, community, and personal responsibility
  - Rejection of egalitarianism and cultural relativism
- Exposing the flaws and failures of democratic governance
- Promoting alternative models of social organization
- Challenging the moral and ethical foundations of democracy
- Educating the public about the benefits of free markets and individual liberty
- Advocating for the protection of private property rights
- Emphasizing the importance of voluntary cooperation
- Recognizing the right of self-determination
- Encouraging peaceful separation from oppressive regimes
- Fostering the development of alternative political communities
- Supporting the creation of private alternatives to state services
- Promoting the development of free-market solutions to social problems
- Encouraging the formation of voluntary associations and communities
- Resisting unjust laws and regulations
- Refusing to cooperate with state aggression
- Promoting a culture of non-compliance with state authority
- **Foundation of Libertarian Ethics**
  - Prohibition against initiating force or fraud
  - Respect for self-ownership and property rights
- **Implications for Government**
  - State's monopoly on force inherently violates NAP
  - Taxation as a form of aggression
- **Application to Immigration**
  - Forced integration violates NAP
  - Right of property owners to exclude
- **Traditional Argument for State Provision**
  - Market failure due to free-rider problem
  - National defense as a supposed public good
- **Critique of the Public Goods Argument**
  - Many alleged public goods can be privatized
  - Market solutions often more efficient than state provision
- **Private Provision of Security**
  - Insurance companies as potential providers
  - Market incentives for efficient security provision
- **Critique of Cultural Relativism**
  - Importance of objective moral standards
  - Dangers of moral decay and social disintegration
- **Defense of Traditional Institutions**
  - Family as the foundation of social order
  - Importance of cultural transmission across generations
- **Relationship to Libertarianism**
  - Compatibility of libertarian principles with traditional values
  - Libertarianism as a means of preserving cultural heritage
- **Public Choice Theory Insights**
  - Politicians and bureaucrats as self-interested actors
  - Incentives for state expansion and intervention
- **The Iron Law of Oligarchy**
  - Tendency for power to concentrate in the hands of a few
  - Implications for democratic governance
- **The Role of Ideology**
  - Importance of ideas in shaping political outcomes
  - Need for a counter-ideology to challenge statism
- **The American Revolution**
  - A secessionist movement based on libertarian principles
  - Lessons for contemporary libertarians
- **The Rise and Fall of Classical Liberalism**
  - Factors contributing to the decline of liberalism
  - The role of intellectual errors and compromises
- **The Failure of Socialist Experiments**
  - Economic and social consequences of central planning
  - Lessons for contemporary welfare states
- **The Swiss Model**
  - Decentralized political system
  - Cantons and their autonomy
  - Limited immigration and its effects
- **Medieval Cities**
  - Free cities as examples of stateless order
  - Importance of private law and voluntary associations
- Promoting libertarian ideas through various media
- Engaging in intellectual debate and discourse
- Challenging the dominant statist narrative
- Creating alternative institutions outside the state
- Supporting private education, healthcare, and security services
- Developing free-market solutions to social problems
- Supporting political candidates who advocate for limited government
- Lobbying for policy changes that reduce state power
- Engaging in peaceful civil disobedience
- Promoting entrepreneurship and free enterprise
- Supporting businesses that operate outside the state's control
- Utilizing alternative currencies and financial systems
- Fostering voluntary associations and social networks
- Creating intentional communities based on libertarian principles
- Supporting local autonomy and self-governance
- **The Problem of "Market Failure"**
  - Reframing externalities as property rights violations
  - Internalizing costs through clearly defined property rights
  - Role of arbitration and restitution in resolving disputes
- **The Issue of Monopolies**
  - Distinguishing between coercive and market monopolies
  - Competition as a dynamic process
  - The role of consumer choice in limiting monopoly power
- **Dealing with Predatory Behavior**
  - Incentives for private security agencies to prevent crime
  - The role of reputation and social ostracism
  - Restitution and punishment in a stateless society
- **Gradualism vs. Radical Change**
  - Strategies for reducing state power incrementally
  - The dangers of gradualism
- **The Role of Public Opinion**
  - Importance of changing hearts and minds
  - Delegitimizing the state and its actions
- **The Problem of "Second Best"**
  - Navigating a non-ideal world
  - Prioritizing reforms that maximize liberty
- **Potential for Instability and Conflict**
  - Importance of peaceful and orderly secession
  - Role of negotiation and compromise
- **Economic Viability of Small Political Units**
  - Benefits of free trade and economic integration
  - Examples of successful small states
- **Dealing with External Threats**
  - Role of private defense alliances
  - Deterrence through economic and social strength
- **Developing and Refining Libertarian Theory**
  - Addressing unanswered questions and challenges
  - Integrating insights from other disciplines
- **Communicating Libertarian Ideas**
  - Reaching a wider audience
  - Engaging in public discourse and debate
- **Building a Movement for Liberty**
  - Fostering a culture of liberty
  - Supporting organizations and institutions that promote libertarian values
- **A World of Voluntary Communities**
  - Diverse social and legal systems
  - Peaceful coexistence and cooperation
- **The Flourishing of Human Creativity and Innovation**
  - Unleashing the potential of free markets and free minds
  - Solving social problems through voluntary action
- **A Society Based on Respect for Individual Rights**
  - Protection of life, liberty, and property
  - The triumph of reason and persuasion over force and coercion
- Ideas as the driving force of history
- The power of ideas to shape social and political outcomes
- Standing up for what is right, even when it is unpopular
- Challenging the status quo and promoting a better future
- A future of peace, prosperity, and individual flourishing
- A society where individuals are free to pursue their own goals and dreams
- A world where cooperation replaces conflict and voluntary action replaces coercion
- Embrace the principles of liberty and property rights
- Work towards a free society through education, activism, and community building
- Never give up hope for a better future
- **The Tension:**
- **Libertarianism/Anarcho-capitalism:** Emphasizes individual liberty, private property, and minimal to no state intervention. This seemingly clashes with the idea of strong border controls, which traditionally require state enforcement.
- **Strong Borders:** Implies a centralized authority (typically the state) controlling who and what enters a territory. This seems to contradict the libertarian ideal of minimal state intervention.
- **Local Collective Action:** While local communities can establish rules and norms, they might lack the resources and authority to enforce them effectively against external pressures, especially concerning immigration.
  **Hoppe's Proposed Solution: Covenant Communities and Private Property Rights**
  Hoppe's solution is to fully embrace private property rights and extend them to their logical conclusion. He argues that the problem isn't immigration itself, but **forced integration** resulting from:
- **Public Property:** The existence of public property (roads, parks, etc.) means that once someone is inside a country's borders, they can move relatively freely, potentially ending up in places where they are not wanted.
- **Centralized State Control:** A central government's immigration policy is a one-size-fits-all approach that does not respect the diverse preferences of individual property owners and communities.
  **Hoppe's proposed solution rests on these pillars:**
- **Radical Decentralization and Secession:** Hoppe advocates for radical decentralization, even down to the level of towns, villages, or even individual neighborhoods. This allows for a greater diversity of rules and preferences to be expressed and enforced.
- **Privatization of "Public" Property:** He argues that all land, including roads, should be privately owned. This eliminates the commons problem associated with public property and allows for genuine control over entry and access.
- **Covenant Communities:** In a stateless society, or even in a society with a drastically reduced state, communities would be formed based on voluntary agreements (covenants) between property owners. These covenants would specify the rules of the community, including who is allowed to enter, reside, or do business there.
- **Private Security and Defense:** Private security agencies, funded voluntarily by property owners, would enforce the rules of the covenant, including those related to immigration.
  **How it would work in practice:**
- **Immigration by Invitation Only:** Individuals could only immigrate to a specific community if they were invited by a property owner within that community. This could involve employment contracts, rental agreements, or other forms of sponsorship.
- **Enforcement by Private Agencies:** Private security agencies, hired by property owners or associations, would be responsible for enforcing the community's rules, including expelling those who violate the terms of their entry or stay.
- **Discrimination as a Right:** Property owners would have the right to discriminate based on any criteria they choose when deciding whom to invite or allow onto their property. This could include factors such as skills, cultural background, or even personal preferences.
- **No "Right" to Free Movement:** There would be no inherent right to move freely across different communities. Movement would be contingent on the consent of the property owners in each area.
  **Hoppe's Argument for Consistency:**
  Hoppe argues that this system is the only one truly consistent with libertarian principles because it:
- **Respects Property Rights:** It upholds the absolute right of property owners to control their property, including who is allowed on it.
- **Eliminates Forced Integration:** It prevents individuals from being forced to associate with others they deem undesirable.
- **Minimizes State Power:** It removes the state from the business of immigration control, placing it in the hands of private individuals and communities.
- Hoppe's proposal is highly controversial, even within libertarian circles. Some common criticisms include:
- **Feasibility:** Critics question whether such a system could be implemented in practice, especially in a world with existing states and large-scale migration pressures.
- **Potential for Abuse:** Concerns exist that private security agencies could become too powerful and oppressive, potentially replicating the problems of the state.
- **Discrimination and Inequality:** The system could lead to significant social stratification and discrimination based on wealth, ethnicity, or other factors.
- **Lack of Uniformity:** Critics argue that a patchwork of different rules and enforcement mechanisms could lead to chaos and conflict.
  **In conclusion, Hoppe's solution to the tension between free immigration and small government is to advocate for a radical form of libertarianism where private property rights are absolute and extend to all aspects of social life, including immigration control. He believes that only through such a system can individual liberty and voluntary association be truly protected.**

## **Hans-Hermann Hoppe**

### Main Themes

#### **Critique of Democracy**

#### **Preference for Monarchy**

#### **Advocacy for Natural Order**

#### **Critique of Classical Liberalism**

#### **Decentralization and Secession**

### Key Concepts

#### **Time Preference**

#### **Property Rights**

#### **Forced Integration**

#### **Socialism and Desocialization**

#### **Role of Elites**

### Supporting Arguments

#### **Historical Evidence**

#### **Economic Theory**

#### **Ethical Considerations**

### Policy Implications

#### **Promoting Secession**

#### **Privatization**

#### **Restricting Immigration**

#### **Abolishing the Welfare State**

#### **Critique of Modern Democracy**

#### **Defense of Private Property**

#### **Role of the State**

#### **Immigration Policy**

#### **Vision of a Free Society**

### Implications for Action

#### **Delegitimization of Democracy**

#### **Promotion of Libertarian Principles**

#### **Support for Secessionist Movements**

#### **Building Alternative Institutions**

#### **Engaging in Civil Disobedience**

#### **The Non-Aggression Principle (NAP)**

#### **The Problem of Public Goods**

#### **The Role of Culture and Tradition**

#### **The Dynamics of Political Power**

#### **Historical Examples and Case Studies**

### Practical Strategies for Change

#### **Education and Outreach**

#### **Building Parallel Structures**

#### **Political Activism**

#### **Economic Action**

#### **Community Building**

### Advanced Considerations and Responses to Potential Criticisms

#### **Addressing Criticisms of Anarcho-Capitalism**

#### **The Transition to a Stateless Society**

#### **Addressing Criticisms of Secession**

#### **The Importance of Intellectual Entrepreneurship**

#### **Long-Term Vision**

### Conclusion

#### **The Importance of Ideas**

#### **The Need for Courage and Conviction**

#### **The Promise of Liberty**

#### **Call to Action**

### Provenance

