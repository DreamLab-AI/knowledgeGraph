Supply risk is the risk of potential or actual disturbance to the flow of product or information from upstream of a focal firm, within its supply network.[^1]

Christopher and Peck call supply risk the upstream equivalent of demand risk, one of five categories in their framework.[^1] They list characteristics of a critical path in a supply network, among them long lead-times, such as the time taken to replenish components from order to delivery, and a single source of supply with no short-term alternative.[^1] They add that upstream and downstream visibility is often very poor, which adds to supply chain risk.[^1]

## Evidence of the loss it causes

The European Central Bank reports a firm-level stress test in which sudden disruptions in the supply of critical inputs from high-risk countries would lead to significant, though very uneven, economic losses across firms, regions and sectors.[^2] The Federal Reserve Bank of Cleveland finds evidence that a global semiconductor shortage constrained US vehicle production during the COVID-19 pandemic.[^3] The second case is treated at [[Component Shortage]].

## Related pages

Dependence on one or a few suppliers is a narrower case, set out at [[Supplier Concentration Risk]]. Supply risk sits among the categories at [[Supply Chain Risk Type]].

## What the sources do not establish

This formal definition rests on one source, the Cranfield paper of 2004.[^1] Other definitions in the supply risk literature were not opened for this research and are not reported. None of the sources opened gives a way to measure supply risk.

[^1]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^2]: European Central Bank, Occasional Paper Series, “Navigating a fragmenting global trading system: insights for central banks (No 365)”. https://ecb.europa.eu/pub/pdf/scpops/ecb.op365~362d801aee.es.pdf
[^3]: Federal Reserve Bank of Cleveland, Economic Commentary 2021-17, “Semiconductor Shortages and Vehicle Production and Prices”. https://www.clevelandfed.org/publications/economic-commentary/2021/ec-202117-semiconductor-shortages-vehicle-production-prices

