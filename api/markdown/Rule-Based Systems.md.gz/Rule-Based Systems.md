Rule-based systems are a class of knowledge-based AI systems that encode domain expertise as a collection of condition-action rules (IF <conditions> THEN <actions>) stored in a knowledge base, and employ an inference engine to match those rules against a working memory of current facts to derive new facts, trigger actions, or reach conclusions. The inference engine operates through either forward chaining (data-driven, propagating from known facts to goals) or backward chaining (goal-driven, working from desired conclusions back to supporting facts), enabling transparent, explainable reasoning where every inference can be traced to the specific rules that fired. Rule-based systems are the foundational architecture underlying classical expert systems, modern business rules engines, production systems, and many decision-automation pipelines across medicine, finance, manufacturing, and legal compliance. Their central tension lies between the interpretability of explicit symbolic rules and the scalability challenges that arise as rule sets grow large and rule interactions become complex.

### Overview

- Rule-based systems emerged from foundational work in [[Artificial Intelligence]] during the 1960s–1980s, notably the MYCIN and DENDRAL expert systems at Stanford, and Allen Newell and Herbert Simon's production system framework. They represent one of the oldest and most practically deployed branches of AI, distinguished by their explicit, inspectable reasoning processes.
- The core model — variously called a production system, rule engine, or expert system shell — separates domain knowledge (the rule base) from reasoning mechanism (the inference engine), enabling knowledge engineers to update rules without altering the reasoning infrastructure.
- Rule-based systems remain widely deployed in regulated industries (finance, healthcare, legal) where decisions must be auditable, as well as in [[Business Process Management]], [[Fraud Detection]], and clinical decision support, often operating alongside or in hybrid architectures with [[Machine Learning]] models.
- The field experienced a renewed interest under "AI governance" pressures: regulators in the EU (AI Act) and US increasingly require explainability of automated decisions, driving adoption of hybrid neuro-symbolic approaches that pair [[Neural Networks]] with rule layers.

### Key Components

- **Knowledge Base (Rule Store)**
  - Contains IF-THEN production rules, typically written as `IF <condition pattern> THEN <action>`
  - Rules may carry priority weights, salience values, or activation thresholds for [[Conflict Resolution Strategy]]
  - Managed separately from the inference mechanism, enabling domain experts to modify rules without engineering changes
  - Related to [[Knowledge Representation]] formalisms — rules may encode first-order logic fragments, Horn clauses (as in [[Logic Programming]]), or fuzzy predicates (see [[Fuzzy Logic]])
- **Working Memory (Fact Base)**
  - A dynamic store of current facts, asserted data, and intermediate conclusions
  - Updated as rules fire; changes may trigger further rule evaluations in a [[Forward Chaining]] cycle
  - Distinct from the rule store — the working memory changes at runtime; rules are typically static
- **Inference Engine**
  - The computational core driving the reasoning cycle: match → select → fire (recognise-act cycle)
  - Supports **forward chaining** (data-driven): begin from asserted facts, fire matching rules, propagate new facts until a goal is reached or no rules fire
  - Supports **backward chaining** (goal-driven): begin from a goal, find rules whose consequent matches, recursively resolve sub-goals; characteristic of [[Logic Programming]] systems like Prolog
  - High-performance engines (e.g., CLIPS, Drools, IBM ODM) use the [[Rete Algorithm]] or its successors (TREAT, LEAPS) to avoid re-evaluating all rules on every fact change
- **Conflict Resolution Strategy**
  - When multiple rules match simultaneously (the conflict set), a strategy selects which rule fires: recency (prefer newer facts), specificity (prefer more specific rules), salience (explicit priority), or breadth-first / depth-first ordering
  - Critical to predictability and correctness of rule-based reasoning
- **Explanation Facility**
  - A component that traces which rules fired in which order to produce a conclusion — the primary source of [[Explainable AI]] capability in rule-based architectures
  - Enables clinicians, auditors, and end users to interrogate decisions in domains such as medical diagnosis and credit scoring

### Mechanisms

- **Forward Chaining (Data-Driven Reasoning)**
  - Begins with a set of known facts in working memory
  - The inference engine identifies all rules whose conditions are satisfied (pattern matching, accelerated by [[Rete Algorithm]])
  - Selected rule fires, adding new facts to working memory, potentially enabling further rules
  - Process continues until a goal fact is asserted or no rules remain applicable
  - Common in monitoring, alerting, [[Fraud Detection]], and production-line rule engines
- **Backward Chaining (Goal-Driven Reasoning)**
  - Begins with a desired goal (hypothesis to prove)
  - Inference engine finds rules whose consequent matches the goal, then recursively attempts to satisfy each antecedent as a sub-goal
  - Characteristic of [[Logic Programming]] (Prolog) and diagnostic systems (MYCIN)
  - Efficient when the goal space is small and many facts would be irrelevant
- **Rete Algorithm**
  - Developed by Charles Forgy (1982) for efficient [[Pattern Matching]] in large rule sets
  - Compiles rules into a discrimination network (the Rete net), caching partial matches so that rule re-evaluation after a fact change is proportional to the change, not to the total rule/fact count
  - Foundational to systems like CLIPS, OPS5, Drools, and IBM ILOG; successors include TREAT and LEAPS
- **Hybrid Neuro-Symbolic Integration**
  - Modern architectures combine rule layers with [[Neural Networks]] or [[Machine Learning]] classifiers
  - A neural model may extract structured facts from unstructured input (text, image); a rule engine then reasons over those facts with domain constraints
  - Addresses the brittleness of pure rule systems and the opacity of pure ML systems, aligning with [[Explainable AI]] goals

### Applications and Use Cases

- **Medical Diagnosis and Clinical Decision Support**
  - MYCIN (Stanford, 1970s) diagnosed bacterial infections using ~600 rules; the first clinically validated AI system
  - Modern equivalents: clinical decision support rules in EHR platforms (Epic, Cerner), drug interaction checkers, sepsis alert systems
  - Valued for auditability — clinicians can inspect every rule that contributed to an alert
- **Financial Services and Fraud Detection**
  - Credit scoring rule systems, anti-money-laundering (AML) rule engines, and transaction fraud detection
  - Platforms such as IBM Safer Payments, FICO Blaze Advisor, and SAS Decision Manager encode thousands of rules
  - Rules must satisfy [[Regulatory Compliance]] requirements (e.g., GDPR explainability, Fair Lending regulations)
- **Business Process Management and ERP**
  - Enterprise resource planning systems (SAP, Oracle) embed extensive rule engines for pricing, inventory replenishment, order validation, and approval workflows
  - [[Business Rules Engine]] platforms (Drools, IBM ODM, Corticon) allow business analysts to author and maintain rules without coding
- **Legal and Regulatory Reasoning**
  - Tax calculation engines (e.g., Thomson Reuters ONESOURCE), benefits eligibility systems, and compliance checking encode statutes as rules
  - [[Regulatory Compliance]] automation increasingly relies on rule-based formalisation of regulations, connecting to [[Governance]] frameworks
  - Bridges to [[Smart Contracts]] on blockchain: Ethereum EVM bytecode and Solidity conditionals are effectively rule-based execution over ledger state
- **Robotics and Autonomous Systems**
  - Reactive rule architectures (subsumption architecture, behaviour trees) govern autonomous robot behaviour
  - Safety-critical constraints in [[Robotics]] (collision avoidance, operational envelopes) are often encoded as hard rules overlaid on learning-based planners
- **Telecommunications and Network Management**
  - Network provisioning, fault diagnosis, and SLA monitoring use rule engines to automate responses to events
  - Event-condition-action (ECA) rules in [[Complex Event Processing]] platforms (e.g., Esper, IBM Streams)
- **Natural Language Processing Pre-Processing**
  - Rule-based tokenisation, POS tagging, and named-entity extraction (e.g., GATE, Apache UIMA rules) often precede or complement [[Machine Learning]] NLP pipelines

### Standards and Context

- **W3C Rule Interchange Format (RIF)** — a W3C standard family for exchanging rules between rule systems and the Semantic Web; comprises RIF-BLD (Basic Logic Dialect), RIF-PRD (Production Rule Dialect), and RIF-FLD (Framework for Logic Dialects)
- **SWRL (Semantic Web Rule Language)** — combines OWL2 DL with a Horn clause rule language; enables rule-based reasoning over [[Ontology]] axioms; submitted to W3C by DARPA DAML Programme
- **OMG Decision Model and Notation (DMN)** — Object Management Group standard for capturing business decision logic as decision tables and decision requirement diagrams; implemented in Drools, Camunda, IBM ODM
- **OPS5** — the first widely distributed production system language (Carnegie Mellon, 1977); basis for early expert system shells; used in the R1/XCON VAX configuration expert system at DEC
- **CLIPS** — C Language Integrated Production System; NASA-developed open-source rule engine; extensively used in embedded systems and academic instruction
- **Drools / Red Hat Decision Manager** — the dominant open-source Java-based rule engine; implements the Rete/Phreak algorithm; widely deployed in enterprise [[Business Process Management]]
- **RETE Algorithm (Forgy 1982)** — foundational algorithmic contribution; patented approaches exist in commercial engines; successors TREAT and LEAPS address specific performance pathologies
- **ISO/IEC 10746 (ODP)** — Open Distributed Processing reference model that influenced rule-based specification of distributed system behaviour
- **AI Act (EU, 2024)** — classifies certain automated decision systems as high-risk, requiring transparency; drives demand for rule-based or hybrid explainable architectures in regulated deployments

### Provenance

