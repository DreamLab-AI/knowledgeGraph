A supply chain is the network of organisations, facilities and processes through which products or services are sourced, made and delivered to customers.[^1][^2][^3]

Three sources define the term, each in its own words. The Industrial Ontologies Foundry (IOF) Supply Chain Ontology defines a supply chain system as an engineered system of agents, facilities, machines and information systems, designed to deliver products and services to end customers through an engineered flow of information, material and cash.[^1] Melo, Nickel and Saldanha da Gama describe a supply chain as a network of facilities that perform operations from the acquisition of raw materials, through their transformation into intermediate and finished products, to the distribution of finished goods to customers.[^2] The NIST computer security glossary gives a linked set of resources and processes that begins with the sourcing of products and services and extends through design, development, manufacturing, processing, handling and delivery to the acquirer.[^3]

All three definitions span sourcing to delivery, and they differ in emphasis: the IOF wording names the flows, Melo and colleagues name facilities and operations, and the NIST wording is framed around developers and acquirers, so it is narrower than the general sense used here.[^1][^2][^3] The IOF explanatory note also records a GS1 wording (a system of organisations and business processes involved in manufacture, distribution and maintenance of a product or asset); that wording is cited here only as quoted in the IOF note.[^1]

## Scope and distinctions

A supply chain is the structure, and supply chain management is the discipline that manages it. CSCMP defines [[Supply Chain Management]] as the planning and management of all activities in sourcing and procurement, conversion and logistics management, and treats [[Logistics]] as a part of that discipline.[^4] The European Commission likewise calls logistics a fundamental part of supply chain management.[^5]

Chain is a conventional word. The IOF ontology defines a supply chain node as a geospatial location that is the site of a supply chain process, and a supply chain agent as a person or business organisation that supplies material products or commercial services to other agents in the chain, so the structure it describes has many nodes and agents rather than one line.[^1] Melo and colleagues speak of a network of facilities for the same reason.[^2]

Usage is not settled. Mentzer and colleagues report that so many definitions of supply chain management are in use that there is little consensus, and they review definitions of the supply chain itself.[^6]

## In practice

Fisher distinguishes two functions of a supply chain. The physical function converts raw materials into parts, components and finished goods and transports them. Market mediation ensures that the variety of products reaching the marketplace matches what consumers want to buy.[^7] Choices about the posture of a chain, and about the number, location and capacity of its facilities, are strategic decisions of the kind Fisher and Melo and colleagues discuss.[^7][^2]

No opened source establishes how many tiers a typical chain has, how often chains are linear rather than networked, or how supply chains differ by industry.

[^1]: Industrial Ontologies Foundry, Supply Chain Ontology, SupplyChain.rdf file (pinned release). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^2]: Melo, Nickel and Saldanha da Gama, Fraunhofer ITWM report 130, “Facility Location and Supply Chain Management - A comprehensive review”. https://kluedo.ub.rptu.de/files/1985/bericht130.pdf
[^3]: NIST Computer Security Resource Center, “supply chain - Glossary | CSRC”. https://csrc.nist.gov/glossary/term/supply_chain
[^4]: Council of Supply Chain Management Professionals, “CSCMP Supply Chain Management Definitions and Glossary”. https://cscmp.org/CSCMP/Educate/SCM_Definitions_and_Glossary_of_Terms.aspx
[^5]: European Commission, Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en
[^6]: John T. Mentzer and colleagues, Journal of Business Logistics, 2001, abstract record for the article on defining supply chain management (Crossref). https://api.crossref.org/works/10.1002/j.2158-1592.2001.tb00001.x
[^7]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf

