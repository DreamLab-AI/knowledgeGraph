
A task dependency is the relation that orders one task before another in a task graph. The Agent Ontology describes it as a "dependency relation in a task graph", declared as `TaskDependency`.[^1][^2]

It reifies the ordering that the property `hasDependency` expresses directly between two [[Task Node]] instances, "a dependency between task nodes". A graph can therefore state a dependency either as a plain link between nodes or as an object in its own right, which can then be annotated. The companion property `hasSubtask` expresses hierarchical decomposition of a task and not ordering.

visionGraph places Task Dependency under [[Dependency Graph]], because a task graph is a graph of dependencies between units of work. It is distinct from [[Task Delegation]], which concerns handing a task to another agent and not the order in which tasks must run.

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl

