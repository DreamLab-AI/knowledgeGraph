Robot manipulation is the sub-field of robotics concerned with the planning and execution of purposeful physical interactions between robotic systems and objects in the world, encompassing grasping, assembly, in-hand manipulation, and tool use. It integrates kinematics, dynamics, perception, and motion planning to move objects from one configuration to another while adapting to uncertainty in object shape, pose, surface properties, and environmental dynamics. Robust manipulation requires coordinating end-effectors, force-torque sensing, and real-time control loops to achieve reliable contact-rich behaviour. The field bridges classical planning and modern machine learning, increasingly leveraging deep visuomotor policies and foundation models trained on large-scale demonstration data.

### Overview

- Robot manipulation addresses the fundamental problem of how a robotic agent physically interacts with its environment to rearrange, assemble, or transform objects. Unlike [[Robot Locomotion]], which moves the robot body through space, manipulation focuses on controlled contact between an [[End Effector]] (gripper, robotic hand, or specialised tool) and target objects.
- The challenge is multifaceted: a robot must perceive object pose and geometry via [[Robot Perception]], compute a stable [[Grasp Planning]] strategy, plan a collision-free trajectory using [[Motion Planning]], and execute contact while managing forces through [[Force Control]] or [[Impedance Control]]. Any mismatch in estimated versus actual object pose, friction coefficient, or stiffness can cause grasp failure.
- Manipulation is widely regarded as one of the hardest open problems in robotics due to the combinatorial complexity of [[Contact Mechanics]], the diversity of object shapes and materials, and the need for real-time replanning under sensing noise. Advances in [[Deep Learning]] and large-scale demonstration datasets have substantially improved generalisation since 2020.

### Key Components

#### End Effectors

- [[End Effector]] is the terminal device mounted to the robot wrist; types include parallel-jaw grippers, multi-finger dexterous hands, suction cups, magnetic grippers, and compliant soft grippers.
- Gripper selection is application-dependent: suction is suited to flat-surfaced objects in bin-picking; dexterous hands enable [[In-Hand Manipulation]] and tool use.
- [[Robotic Arm]] kinematics determine the workspace reachable by the end effector.

#### Kinematics and Dynamics

- [[Robot Kinematics]] maps joint angles to end-effector pose via forward kinematics; [[Inverse Kinematics]] inverts this mapping to compute joint commands from a desired Cartesian target.
- Dynamics models account for inertia, gravity, and interaction forces, enabling model-based control strategies.

#### Grasp Planning and Synthesis

- [[Grasp Planning]] algorithms compute contact point configurations that are force-closure (stable against external wrenches) or form-closure (geometrically locked).
- Analytical methods (e.g., Ferrari-Canny quality metric) evaluate grasp quality from object geometry; data-driven methods (Dex-Net, GraspNet) learn grasp quality from large synthetic or real datasets.
- [[Point Cloud Processing]] from [[Depth Sensing]] (RGB-D or LiDAR) provides 3D object models for grasp synthesis.

#### Motion Planning

- [[Motion Planning]] generates collision-free joint trajectories from a start configuration to a grasp pre-contact or post-grasp pose.
- Sampling-based planners (RRT, RRT*, PRM) explore the configuration space; optimisation-based planners (CHOMP, TrajOpt) minimise cost functionals over smooth trajectories.
- Task and motion planning (TAMP) integrates symbolic task planning with geometric motion planning for multi-step manipulation sequences.

#### Force and Compliance Control

- [[Force Control]] enables robots to regulate contact force rather than position, critical for assembly tasks such as peg-in-hole insertion, surface wiping, and delicate object handling.
- [[Impedance Control]] defines a desired mechanical impedance (stiffness, damping, inertia) for the end effector, allowing compliant interaction without explicit force setpoints.
- Force-torque sensors at the wrist provide real-time wrench measurements; tactile sensors on fingertips provide local contact distribution.

#### Perception Pipeline

- [[Sensor Fusion]] combines data from RGB cameras, depth sensors, tactile arrays, and wrist force-torque sensors to maintain an estimate of object state.
- 6-DoF pose estimation algorithms (PoseCNN, FoundPose) determine object position and orientation from images or point clouds.
- Deformable object tracking and transparent/reflective object handling remain active research challenges.

#### Learning-Based Approaches

- Behaviour cloning trains visuomotor policies from human demonstrations, mapping image observations directly to robot actions.
- [[Reinforcement Learning]] enables manipulation policies to be optimised through trial-and-error, typically in simulation (Isaac Gym, MuJoCo) before [[Sim-to-Real Transfer]].
- [[Imitation Learning]] frameworks such as ACT (Action Chunking with Transformers) and diffusion policy have achieved strong results on dexterous tasks from small demonstration sets.
- Foundation models for manipulation (RT-2, OpenVLA, pi0) pre-train on large-scale video and robot datasets, enabling zero-shot or few-shot transfer to novel tasks.

### In-Hand Manipulation

- [[In-Hand Manipulation]] refers to reconfiguring an object within the grasp without re-grasping — rotating, translating, or re-orienting an object using finger motion alone.
- This requires dexterous multi-finger hands (e.g., Shadow Hand, Allegro Hand) and high-frequency tactile sensing.
- [[Reinforcement Learning]] has produced notable in-hand manipulation results (OpenAI Dactyl, solving Rubik's cube with a robotic hand), though brittleness under distribution shift remains a limitation.
- Sim-to-real transfer for in-hand manipulation relies on domain randomisation over object geometry, friction, and actuation noise.

### Bimanual Manipulation

- [[Bimanual Manipulation]] coordinates two robot arms for tasks that cannot be accomplished unimanually — cloth folding, bottle opening, cable routing, and bimanual assembly.
- Requires tight kinematic and force coordination; each arm's trajectory must account for the shared object state.
- Learning from human demonstrations using motion capture or teleoperation is the dominant paradigm for bimanual policy acquisition.

### Applications

#### Industrial Automation

- Automotive assembly lines rely on manipulation for welding, painting, and part assembly, with articulated arms from FANUC, KUKA, ABB, and Yaskawa operating in structured environments.
- Bin-picking systems (Covariant, Mech-Mind, Photoneo) use 3D vision and grasp synthesis to pick randomly oriented parts from bins — a canonical unstructured manipulation benchmark.

#### Warehouse and Logistics

- [[Warehouse Automation]] deployments (Amazon Sparrow, Berkshire Grey, Nimble Robotics) automate order fulfilment by picking and placing individual items from heterogeneous SKU catalogues.
- Depalletising and palletising robots handle box manipulation in distribution centres, reducing repetitive strain injuries.

#### Surgical Robotics

- [[Surgical Robotics]] (da Vinci Surgical System, CMR Versius) extends surgeon dexterity with teleoperated manipulation at millimetre precision, with force feedback and motion scaling.
- Autonomous surgical sub-tasks (suturing, tissue retraction) are an active research area requiring force-controlled manipulation under vision.

#### Service and Domestic Robotics

- Service robots (Boston Dynamics Spot Arm, Hello Robot Stretch, Kinova JACO) tackle open-ended manipulation in homes, hospitals, and offices.
- Domestic manipulation tasks (loading dishwashers, folding laundry, opening drawers) remain difficult due to deformable objects and unstructured environments.

#### Space and Hazardous Environments

- [[Teleoperation]] enables human operators to control manipulation in space (Canadarm2 on the ISS), nuclear facilities, and disaster response scenarios (DARPA Robotics Challenge).
- Autonomous in-space assembly and servicing are emerging use cases for manipulation in microgravity.

#### Medical and Laboratory Automation

- Laboratory automation robots perform liquid handling, sample processing, and plate manipulation in drug discovery and diagnostics workflows.

### Standards and Context

- ISO 9283 defines performance criteria and testing methods for industrial robot arms, relevant to manipulation accuracy benchmarking.
- ROS (Robot Operating System) provides the de facto middleware ecosystem for manipulation; the MoveIt! framework is the standard motion planning interface.
- The NIST Assembly Task Board benchmarks provide standardised tasks for comparing manipulation performance across research platforms.
- IEEE Robotics and Automation Society (RAS) technical committees on robot manipulation coordinate standardisation and benchmark development.
- The Open Motion Planning Library (OMPL) provides implementations of sampling-based planners used across manipulation research.

### Historical Context

- The first industrial manipulator, Unimate (George Devol and Joseph Engelberger), was installed at a General Motors factory in 1961, automating spot welding and die casting.
- Tomas Lozano-Pérez's configuration-space framework (1983) formalised collision-free motion planning, enabling systematic trajectory generation.
- Kenneth Salisbury's work on dexterous robotic hands at MIT in the 1980s established the theoretical foundations for multi-finger [[Grasp Planning]] and [[Impedance Control]].
- The 2003–2007 DARPA Urban Challenge and 2012 DARPA Robotics Challenge stimulated whole-body manipulation research in disaster response.
- Deep learning for manipulation (Levine et al., 2016; Mahler et al. Dex-Net, 2017) demonstrated that end-to-end visuomotor policies could be learned at scale.
- The 2023–2025 wave of manipulation foundation models (RT-2, OpenVLA, Octo, pi0) marks the current frontier, converging robotics with large-scale pre-training paradigms from language and vision.

### Provenance

