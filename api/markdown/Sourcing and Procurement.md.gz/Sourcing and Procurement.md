Sourcing and procurement is the group of activities by which an organisation decides what to buy from outside and acquires goods and services from suppliers, from the make-or-buy choice to ordering and payment.[^1][^2][^3]

UNCITRAL defines procurement in public law as the acquisition of goods, construction or services by a procuring entity.[^1] Medina-Serrano and colleagues describe the underlying sourcing choice as the decision between designing and manufacturing parts or services in-house, buying them from external providers, or combining both.[^2] HM Revenue and Customs describes the purchasing cycle as the typical set of business functions for business-to-business purchasing, from requisition and purchase order through receipt, purchase invoice, supplier payment and recording of transactions.[^3]

The UK Cabinet Office Sourcing Playbook lists the typical commercial activities before a procurement as assessing the market, consulting the market before procurement and developing a sourcing strategy.[^4] The Playbook also supports a range of delivery models, to be carefully considered as part of a mixed economy approach to service delivery, insource and in-house resources or a mix of both.[^4] Kraljic argued in 1983 that purchasing departments could no longer rely on a stable way of business life, because resource depletion, raw materials scarcity, political turbulence, intensified competition and technological change had ended the days of no surprises, and that supply and demand patterns could be upset virtually overnight.[^5]

## Pages in this branch

See [[Procurement]], [[Strategic Sourcing]], [[Category Management]], [[Spend Analysis]], [[Kraljic Portfolio Matrix]], [[Sourcing Strategy]], [[Single Sourcing]], [[Sole Sourcing]], [[Dual Sourcing]], [[Procure-to-Pay]], [[Supplier Management]], [[Request for Quotation]], [[Request for Proposal]] and [[Reverse Auction]].

## What the sources do not establish

No source opened defines sourcing and procurement as a pair. UNCITRAL speaks of public procurement, the Playbook of public service delivery, and Medina-Serrano and colleagues of make-or-buy decisions, so this page is an editorial grouping.[^1][^4][^2]

[^1]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf
[^2]: Ruben Medina-Serrano and colleagues, Journal of Industrial Engineering and Management, 2020, “Strategic Sourcing: Developing a Progressive Framework for Make-Or-Buy Decisions”. https://jiem.org/index.php/jiem/article/download/2858/922
[^3]: HM Revenue and Customs, VAT compliance controls guidelines (Crown copyright), “Procure to pay (part 4)”. https://www.gov.uk/government/publications/help-with-vat-compliance-controls-guidelines-for-compliance-gfc8/procure-to-pay-part-4
[^4]: UK Cabinet Office, Crown copyright (Open Government Licence v3.0), June 2023, “The Sourcing Playbook: Government guidance on service delivery, including outsourcing, insourcing, mixed economy sourcing and contracting”. https://assets.publishing.service.gov.uk/media/64901fcc5f7bb700127fac5e/Sourcing_Playbook_Final.pdf
[^5]: Peter Kraljic, Harvard Business Review, September 1983 (publisher page with opening text), “Purchasing Must Become Supply Management”. https://hbr.org/1983/09/purchasing-must-become-supply-management

