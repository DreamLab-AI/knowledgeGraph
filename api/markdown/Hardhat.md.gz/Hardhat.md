Hardhat is a professional Ethereum development environment that provides a comprehensive toolchain for compiling, deploying, testing, and debugging Solidity smart contracts. It ships with Hardhat Network, an in-process Ethereum node implementation designed for local development that supports forking mainnet state and emitting Solidity stack traces on failure. Hardhat's plugin architecture integrates tightly with ethers.js and Waffle, and its tasks system allows developers to automate bespoke deployment and verification workflows. It has become the dominant development framework in the Ethereum ecosystem, displacing earlier tools such as Truffle.

### Overview

- Hardhat is developed and maintained by Nomic Foundation (formerly Nomic Labs), released under the MIT licence and distributed as an npm package.
- The framework emerged around 2019 and reached broad adoption by 2021, driven by its superior debugging experience, flexible plugin system, and native TypeScript support.
- Unlike [[Remix IDE]] (a browser-based environment for quick experimentation), Hardhat is designed for production-grade development workflows integrated into version-controlled codebases and [[Continuous Integration]] pipelines.
- The core CLI is referred to as the **Hardhat Runner**, which reads a project's `hardhat.config.ts` or `hardhat.config.js` to discover tasks, plugins, and network definitions.
- Hardhat enforces no prescriptive project layout; developers configure paths, compiler versions, and optimiser settings per project.
- Its adoption is especially pronounced in the [[DeFi Protocol]] ecosystem, where rigorous testing of financial logic is critical to avoid catastrophic exploits.

### Key Components

- **Hardhat Network**
  - A local in-process [[Ethereum Virtual Machine]] node built on top of ethereumjs.
  - Supports forking live networks (e.g. [[Ethereum]] mainnet or testnets) at a pinned block number, giving tests access to real deployed state.
  - Emits Solidity-level stack traces and `console.log` output from [[Solidity]] contracts during test runs.
  - Supports configurable mining modes: on every transaction (auto-mine) or on a fixed interval.
- **Hardhat Runner**
  - The primary entry point CLI: `npx hardhat <task>`.
  - Built-in tasks include `compile`, `test`, `run`, `node`, and `clean`.
  - Custom tasks can be defined in the config file using the `task()` API, enabling bespoke deployment and maintenance scripts.
- **Plugin System**
  - Plugins extend Hardhat via the `extendEnvironment` and `extendConfig` APIs.
  - Official plugins include:
    - `@nomicfoundation/hardhat-ethers` — injects [[ethers.js]] into the Hardhat Runtime Environment.
    - `@nomicfoundation/hardhat-chai-matchers` — extends Chai with EVM-aware assertions (e.g. `revertedWith`, `emit`).
    - `@nomicfoundation/hardhat-verify` — automates source code verification on [[Etherscan]] and compatible explorers.
    - `hardhat-gas-reporter` — reports gas usage per test and function.
    - `solidity-coverage` — instruments [[Solidity]] bytecode to produce code-coverage reports.
  - Community plugins extend Hardhat with [[TypeScript]] type generation, contract size linting, proxy pattern helpers, and more.
- **Solidity Compiler Integration**
  - Manages multiple [[Solidity Compiler]] versions simultaneously; per-file compiler version selection is supported.
  - Compilation artefacts (ABI, bytecode, source maps, AST) are written to `artifacts/` and used by tests and deployment scripts.
- **Task and Script Runner**
  - `hardhat run <script>` executes arbitrary [[Node.js]] scripts inside the Hardhat Runtime Environment, providing access to compiled contracts and the configured provider.

### Applications and Use Cases

- **DeFi Protocol Development**
  - Teams building [[DeFi Protocol]] contracts (AMMs, lending protocols, stablecoins) rely on Hardhat's mainnet fork to simulate complex multi-contract interactions under real market conditions.
- **NFT Contract Deployment**
  - [[NFT]] projects use Hardhat to compile ERC-721/ERC-1155 contracts, run full test suites, and publish verified source on [[Etherscan]].
- **DAO Governance Systems**
  - [[Decentralised Autonomous Organisation]] frameworks such as Governor contracts and timelock controllers are developed and audited using Hardhat's detailed revert-reason reporting.
- **Security Audits and Fuzzing**
  - Security engineers use Hardhat in combination with [[Slither]] (static analysis) and fuzzing tools during smart contract audits; the stack-trace capability is invaluable for reproducing discovered exploits.
- **Protocol Upgrades**
  - Proxy-based upgrade patterns (e.g. UUPS, Transparent Proxy) are orchestrated via Hardhat scripts and the `@openzeppelin/hardhat-upgrades` plugin from [[OpenZeppelin]].
- **Layer-2 Development**
  - Hardhat supports custom network definitions, enabling development against [[Layer 2 Scaling]] solutions such as Optimism, Arbitrum, and zkSync via their respective provider configurations.
- **CI/CD Integration**
  - Hardhat's `npx hardhat test` command integrates natively into [[Continuous Integration]] pipelines (GitHub Actions, GitLab CI), enabling automated regression testing on every commit.

### Standards and Context

- Hardhat compiles contracts against the [[Ethereum Yellow Paper]] specification via the Solidity compiler (`solc`), ensuring produced bytecode is compatible with the [[EVM]] specification.
- Contract ABI encoding follows the [[Ethereum ABI Specification]], making artefacts directly consumable by [[ethers.js]], [[web3.js]], and other EVM client libraries.
- Source code verification submitted via `hardhat-verify` conforms to the [[Etherscan]] source verification API, enabling public auditability of deployed contracts.
- The `hardhat-chai-matchers` plugin implements EVM-specific test semantics on top of the [[Mocha]] test runner and the Chai assertion library — both standard tooling in the [[Node.js]] ecosystem.
- Support for [[ERC-20]], [[ERC-721]], [[ERC-1155]], and [[ERC-4626]] token standards is provided through integration with [[OpenZeppelin]] contract libraries, which publish Hardhat-compatible npm packages.
- Since 2022, Hardhat has incrementally shifted its primary integration from [[web3.js]] to [[ethers.js]] v6, reflecting the broader ecosystem's adoption of the latter.

### Comparison with Peers

- **[[Foundry]]** — a Rust-based alternative with faster test execution, native fuzzing, and tests written in [[Solidity]] rather than JavaScript/TypeScript; preferred by security-focused teams. Hardhat holds an edge in plugin ecosystem breadth and JavaScript interoperability.
- **[[Truffle]]** — the predecessor framework from ConsenSys; now deprecated (support ended Q4 2023). Hardhat's superior debugging was the primary driver of migration.
- **[[Brownie]]** — a Python-based framework; preferred by [[Python]]-native teams but has seen declining adoption relative to Hardhat and Foundry.
- **[[Remix IDE]]** — browser-based, suited for learning and rapid prototyping; lacks the CI integration and plugin depth of Hardhat.
- **Anchor** — the equivalent development framework for the [[Solana]] ecosystem; not EVM-compatible.

### Provenance

