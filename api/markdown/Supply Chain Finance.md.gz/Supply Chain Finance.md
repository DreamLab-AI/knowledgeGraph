Supply chain finance (SCF) is the use of financing and risk mitigation practices and techniques to optimise the management of the working capital and liquidity invested in supply chain processes and transactions.[^1] The Standard Definitions for Techniques of Supply Chain Finance add that SCF is typically applied to open account trade and is triggered by supply chain events, and that visibility of the underlying trade flows by the finance provider is a necessary component, which can be enabled by a technology platform.[^1]

The International Chamber of Commerce Banking Commission produced the standard as project facilitator, with BAFT, the Euro Banking Association, Factors Chain International and the International Trade and Forfaiting Association.[^2] ICC explains that the subject's novelty had led to expressions, terms and terminology that were, and remain, often inconsistent, opaque and even contradictory.[^2]

## Techniques

The 2016 standard describes a range of techniques, including the following. Receivables discounting is a form of receivables purchase in which sellers sell individual or multiple receivables, represented by outstanding invoices, to a finance provider at a discount.[^1] Factoring is a form of receivables purchase in which the finance provider typically becomes responsible for managing the debtor portfolio and collecting the receivables.[^1] Payables finance is a buyer-led programme within which sellers in the buyer's supply chain can access finance by means of receivables purchase.[^1] See [[Receivables Factoring]] and [[Reverse Factoring]].

## Accounting treatment

FASB, in Accounting Standards Update 2022-04, describes supplier finance programs, which it says may also be referred to as reverse factoring, payables finance or structured payables arrangements, and requires a buyer in such a program to disclose enough information for users of financial statements to understand the program's nature.[^3]

## Scope and distinctions

SCF financing sits on trade settled on open account terms, see [[Open Account Trade]] and [[Trade Finance]]. The related working capital measure is [[Cash-to-Cash Cycle Time]].[^1]

## What the sources do not establish

The 2016 standard mentions a technology platform only as one way to give the provider visibility, and contains none of the terms blockchain, distributed ledger or smart contract, so the page makes no claim about distributed ledger implementations.[^1] The standard has been updated since 2016 by the same forum, and those updates were not opened. No source here gives the size of the market.

[^1]: Global Supply Chain Finance Forum (ICC Banking Commission, BAFT, Euro Banking Association, Factors Chain International and ITFA), “Standard Definitions for Techniques of Supply Chain Finance”, 2016 (Internet Archive copy of the ICC PDF). https://web.archive.org/web/2023/https://cdn.iccwbo.org/content/uploads/sites/3/2017/01/ICC-Standard-Definitions-for-Techniques-of-Supply-Chain-Finance-Global-SCF-Forum-2016.pdf
[^2]: International Chamber of Commerce, “Five things you need to know about our new Supply Chain Finance terminology”. https://iccwbo.org/news-publications/news/five-things-you-need-to-know-about-our-new-supply-chain-finance-terminology/
[^3]: Financial Accounting Standards Board, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”, Accounting Standards Update No. 2022-04. https://storage.fasb.org/ASU%202022-04.pdf

