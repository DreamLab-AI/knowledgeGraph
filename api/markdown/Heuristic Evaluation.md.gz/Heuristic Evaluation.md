Heuristic evaluation is a usability inspection method in which a small number of expert evaluators judge an interface against a set of recognised usability principles, or heuristics, to identify usability problems. It is a discount technique that requires no test participants, producing a ranked list of issues with severity estimates. Because it depends on evaluator expertise rather than observed user behaviour, it complements, rather than replaces, empirical usability testing.

- Heuristic evaluation is an expert inspection of an interface against established principles to surface [[Usability]] problems early and cheaply.
- It draws on the evaluator's understanding of [[Human-Computer Interaction]] and the user's [[Mental Model]] rather than on observed participants.
- The method produces severity-rated findings that feed back into [[Interaction Design]] and improve the wider [[User Experience]].
- It is most powerful when paired with [[Usability Testing]] and other [[User Research]].

### Overview

- Heuristic evaluation was popularised by Jakob Nielsen and Rolf Molich as a fast, low-cost alternative to full usability studies.
- A handful of evaluators independently walk through the interface, comparing each screen and interaction against a shared heuristic checklist.
- Findings are aggregated, deduplicated, and assigned severity ratings reflecting frequency, impact, and persistence of each problem.
- Three to five evaluators typically uncover the majority of significant issues, balancing cost against coverage.
- The technique is an inspection method: it predicts problems through expert judgement rather than measuring real user performance.

### Mechanisms

- Heuristic checklist — a small set of broadly applicable usability principles such as visibility of system status and error prevention.
- Independent passes — evaluators inspect separately to avoid anchoring before findings are merged.
- Severity rating — each issue is scored to prioritise remediation effort.
- Aggregation — overlapping observations are consolidated into a single ranked defect list.
- Coverage trade-off — more evaluators find more issues with diminishing returns.

### Applications

- Early-stage design reviews before committing to development.
- Audits of existing products to triage usability debt.
- Pre-screening interfaces ahead of expensive empirical [[Usability Testing]].
- Reviewing immersive and spatial interfaces where recruiting test users is costly.
- Establishing a baseline of issues to track across design iterations.

### Provenance

