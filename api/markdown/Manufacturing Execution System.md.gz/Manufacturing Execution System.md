A manufacturing execution system (MES) is a system at Level 3 of the ISA-95 model that manages manufacturing operations, between process control and business planning.[^1][^2]

The International Society of Automation says ISA-95 was developed to create an abstract model for information exchange among manufacturing control functions and business functions in an enterprise.[^1] In its model of five levels, Level 3 describes manufacturing execution systems and other systems, such as supervisory control and data acquisition, that manage manufacturing operations, and Level 4 describes business planning and logistics, including enterprise resource planning.[^1] The standard primarily deals with the interface between levels 3 and 4.[^1]

## Standards

IEC 62264-1:2013 describes the manufacturing operations management domain, Level 3, and its activities, together with the interface content and transactions within Level 3 and between Levels 3 and 4.[^2] That description enables integration between the manufacturing operations and control domain, Levels 3, 2 and 1, and the enterprise domain, Level 4.[^2] A NIST report from 1999 responded to a request for information from the Object Management Group on the MES area, proposing a definition of the area with a set of functional views adapted from MESA International.[^3]

## Place among systems

Zaidi, Amanton and Sanlaville list manufacturing execution systems with warehouse and transportation systems as supply chain execution.[^4] See [[Supply Chain Execution System]] and [[Overall Equipment Effectiveness]].

## What the sources do not establish

The ISA and IEC pages say where MES sits and what the standard covers, but the opened abstracts do not state a definition, and the NIST abstract does not state its proposed one, so this page gives no list of MES functions. The IEC record is an abstract read through the Internet Archive, and the NIST report dates from 1999. The sources do not link MES to purchasing or distribution beyond placing it in the execution class.[^1][^2][^3][^4]

[^1]: International Society of Automation, “ISA-95 Standard: Enterprise-Control System Integration”. https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard
[^2]: ISO, “IEC 62264-1:2013 - Enterprise-control system integration — Part 1: Models and terminology” (catalogue record, Internet Archive copy). https://web.archive.org/web/2025/https://www.iso.org/standard/57308.html
[^3]: Edward J. Barkmeyer Jr., Peter O. Denno, Shaw C. Feng, Evan K. Wallace and Albert T. Jones, NIST Interagency/Internal Report 6397, 1999, “NIST Response to MES Request for Information”. https://www.nist.gov/publications/nist-response-mes-request-information
[^4]: Fares Zaidi, Laurent Amanton and Eric Sanlaville, “Towards a Novel Cooperative Logistics Information System Framework”, arXiv:1905.00687. https://arxiv.org/pdf/1905.00687

