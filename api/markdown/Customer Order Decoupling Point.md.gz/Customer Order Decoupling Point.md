A customer order decoupling point (CODP) is the stock point at which the forecast-driven part of a supply system meets the customer-order-driven part.[^1]

Wikner, Naim and Spiegler describe a system as usually made up of a forecast-driven subsystem in tandem with a customer-order-driven subsystem, with the interface between them represented by information flows and a stock point referred to as the CODP. They add that it may be positioned late, as in make-to-stock systems, or early, as in make-to-order systems.[^1] See [[Make-to-Stock]] and [[Make-to-Order]]. Swierczek describes the material decoupling point as the physical allocation of the goods, showing how deeply the customer order penetrates into the physical flow, and as a buffer between upstream and downstream partners.[^2] Christopher uses the related idea in his account of agility: the point at which real demand penetrates upstream may be termed the decoupling point, previously called the order penetration point. He argues that the issue is not how far the order penetrates but how far real demand is made visible.[^3]

## Information decoupling

Mason-Jones and Towill extend the traditional material decoupling point methodology to an information decoupling point, on the ground that many problems in the material flow result from the distortion of marketplace sales information as it moves upstream.[^4] Swierczek describes it as the point where information turns from high-value actual consumer demand data to distorted, magnified and delayed order data.[^2] Christopher and Towill call it the furthest point upstream to which information on real demand flows, undistorted by inventory policies such as re-order points.[^5] Wikner and colleagues report that Mason-Jones and Towill introduced the distinction between the actual driver and information about the driver, and that Wikner later renamed the concept the Demand Information Decoupling Point.[^1]

## Link to lean and agile

Christopher and Towill say that, through postponement, companies can use lean methods up to the decoupling point and agile methods beyond it.[^5] Wikner and colleagues likewise name the CODP as the interface between lean and agile in their setup.[^1] See [[Postponement]], [[Lean Supply Chain]] and [[Agile Supply Chain]].

## What the sources do not establish

None of the sources opened gives a rule for where to place the point; Wikner and colleagues say only that it may lie late or early.[^1]

[^1]: Joakim Wikner, Mohamed M. Naim and Virginia L. M. Spiegler, 19th International Working Seminar on Production Economics, 2016 (Brunel University repository), “IOBPCS Based Models and the Customer Order Decoupling Point”. https://bura.brunel.ac.uk/bitstream/2438/11956/1/Fulltext.pdf
[^2]: Artur Swierczek, POMS conference proceedings (pomsmeetings.org), “The effect of material and information decoupling points on supply chain collaboration”. https://pomsmeetings.org/ConfProceedings/043/FullPapers/FullPaper_files/043-0333.pdf
[^3]: Martin Christopher, Industrial Marketing Management, 2000 (Cranfield repository copy), “The Agile Supply Chain : Competing in Volatile Markets”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/3e60f75d-28c1-4659-a260-6608c0e863f2/content
[^4]: Rachel Mason-Jones and Denis R. Towill, Cardiff Metropolitan University research record (abstract only), “Using the Information Decoupling Point to Improve Supply Chain Performance”. https://pure.cardiffmet.ac.uk/en/publications/using-the-information-decoupling-point-to-improve-supply-chain-pe/
[^5]: Martin Christopher and Denis Towill, International Journal of Physical Distribution and Logistics Management, 2001 (Cranfield repository copy), “An Integrated Model for the Design of Agile Supply Chains”. https://dspace.lib.cranfield.ac.uk/bitstreams/db14daf6-8518-476e-9211-b6af2f1515a5/download

