A standards body is a formal organisation that develops, publishes, and maintains technical specifications, protocols, and reference implementations through structured, consensus-based processes involving multiple stakeholders. Such bodies define interoperability requirements that enable products and services from different vendors to work together reliably, and they may operate at national, regional, or international scope. Governance structures typically include member organisations, technical working groups, public review periods, and intellectual-property licensing frameworks (e.g. royalty-free or FRAND). Well-known examples include ISO, IEC, IEEE, W3C, IETF, NIST, Khronos Group, and the Open Geospatial Consortium.

### Overview

- Standards bodies exist because multi-vendor [[Interoperability]] does not emerge naturally from competitive markets — without a neutral coordinating authority, each vendor optimises for its own [[Proprietary Specification]], fragmenting ecosystems and raising switching costs.
- By convening industry, academia, and government participants under a shared governance charter, a standards body crystallises accumulated knowledge into a stable, citable [[Open Standard]] that any party may implement.
- The output is typically a combination of:
  - A normative [[Specification Document]] (requirements, semantics, syntax)
  - An informative rationale or explanatory annex
  - A [[Conformance Test Suite]] allowing implementors to verify compliance
  - Reference implementations that demonstrate feasibility
- Standards bodies sit within a broader [[Governance Ecosystem]] that also includes [[Regulatory Framework]] instruments (law/regulation) and informal community norms; they sit upstream of [[Certification Scheme]] programmes that verify product conformance.

### Key Components

- **Membership model** — most bodies admit organisations (corporations, universities, governments) rather than individuals, and tier membership by contribution level (e.g. Sponsor, Contributor, Associate). Fees fund secretariat operations.
- **[[Technical Working Group]]** — the engine of standards development; domain-specific sub-groups where engineers draft and debate normative text.
- **[[Consensus Process]]** — formal voting or rough-consensus procedures (e.g. IETF's "humming", ISO ballot rounds, W3C Candidate Recommendation transitions) that prevent capture by a single vendor.
- **[[Intellectual Property Licensing]] policy** — determines whether patents that are essential to implementing the standard must be licensed royalty-free (RF) or on FRAND terms; this single policy choice determines whether the standard can achieve broad adoption.
- **[[Specification Document]] lifecycle** — drafts pass through states (Working Draft → Last Call → Candidate Standard → Published Standard) with mandatory public review at key transitions.
- **[[Conformance Test Suite]]** — normative tests that distinguish compliant from non-compliant implementations; without these, wording ambiguity leads to incompatible products even when vendors claim compliance.
- **[[Errata]] and revision process** — mechanism for tracking and resolving defects in published standards without invalidating existing implementations.

### Mechanisms

- **Horizontal vs vertical scope** — horizontal bodies (ISO, IEEE) span many industries; vertical bodies (Khronos, 3GPP, MPEG) focus on a specific technology domain, enabling deeper technical depth and faster iteration.
- **Fast-track procedures** — allow a mature specification originating outside the body (e.g. an industry consortium draft) to be adopted with lighter-weight review, compressing the timeline from prototype to ratified standard.
- **Liaison relationships** — bodies formally link to one another (e.g. ISO/IEC JTC 1 liaisons with W3C) to prevent conflicting standards and enable cross-referencing, supporting [[Open Governance]] at the ecosystem level.
- **Appeal and antitrust safeguards** — procedural appeals and antitrust guidelines (especially in US and EU contexts) protect against anti-competitive information sharing during standards meetings.

### Applications and Use Cases

- **[[Spatial Computing]]** — [[Khronos Group]] publishes [[OpenXR]], [[Vulkan]], [[glTF]], and [[OpenCL]], enabling cross-device [[Mixed Reality]] and GPU-compute [[Interoperability]] without proprietary lock-in.
- **[[Web Platform]]** — [[World Wide Web Consortium]] specifies [[WebXR Device API]], [[WebGPU]], [[Web Audio API]], and semantic web standards ([[RDF]], [[OWL]], [[SPARQL]]) that underpin the open web stack.
- **Networking and protocols** — [[IETF]] produces RFCs governing [[TCP-IP]], [[HTTP]], [[Transport Layer Security]], and [[QUIC]]; these form the substrate of every internet application.
- **[[AI Safety Framework|AI Safety and Ethics]]** — bodies such as [[NIST]] (AI Risk Management Framework), ISO/IEC JTC 1/SC 42, and [[IEEE]] are developing frameworks for trustworthy [[Artificial Intelligence]], bridging governance and [[Machine Learning]].
- **[[Blockchain Protocol|Blockchain and distributed ledgers]]** — ISO TC 307 standardises terminology, smart contracts, and identity schemes; [[World Wide Web Consortium]] published [[Decentralised Identifier]] (DID) and [[Verifiable Credential]] specifications.
- **[[Geospatial Data]]** — [[Open Geospatial Consortium]] defines [[GeoJSON]], OGC API standards, and [[3D Tiles]], enabling interoperable [[Digital Twin]] and [[GIS]] systems.
- **Telecommunications** — [[3GPP]] specifies 4G/5G/6G radio and core network standards adopted globally by operators and device manufacturers.
- **Manufacturing and safety** — IEC 61508 (functional safety), ISO 26262 (automotive), and ISO/IEC 27001 ([[Information Security]]) provide sector-specific assurance frameworks.
- **[[Supply Chain]] and trade** — GS1 (barcodes, RFID, EDI) and ISO 28000 standardise logistics identifiers and security management, underpinning global [[Supply Chain]] visibility.

### Standards and Context

- **Key international standards bodies**
  - [[ISO]] (International Organisation for Standardisation) — 167 member countries; publishes ~25,000 active standards across all industries
  - [[IEC]] (International Electrotechnical Commission) — electrical, electronic, and related technologies; joint ISO/IEC JTC 1 covers [[Information Technology]]
  - [[IEEE]] (Institute of Electrical and Electronics Engineers) — 802.x networking, 754 floating-point arithmetic, 2030 smart-grid, P2048 [[Extended Reality]]
  - [[World Wide Web Consortium]] (World Wide Web Consortium) — web architecture, [[HTML]], [[CSS]], [[WebXR]], [[Linked Data]], [[Verifiable Credential]]
  - [[IETF]] (Internet Engineering Task Force) — open, volunteer-driven; produces RFCs governing all internet protocols
  - [[NIST]] (National Institute of Standards and Technology) — US federal standards including [[FIPS]], [[SP 800-series]] security standards, [[AI Risk Management Framework]]
- **Domain-specific bodies**
  - [[Khronos Group]] — 3D graphics, GPU compute, [[Mixed Reality]] (OpenXR, Vulkan, glTF, OpenCL, SYCL)
  - [[MPEG]] — Moving Picture Experts Group (joint ISO/IEC); video codecs (H.264/AVC, H.265/HEVC, H.266/VVC), immersive media
  - [[Open Geospatial Consortium]] — geospatial [[API Specification]], [[3D Tiles]], OGC API standards
  - [[3GPP]] — cellular radio access and core network (4G LTE, 5G NR, 6G research)
  - [[ETSI]] (European Telecommunications Standards Institute) — European telecommunications and NFV/SDN standards
  - [[OASIS]] — structured information standards including SAML, MQTT, OData, [[STIX/TAXII]] cybersecurity
  - [[GS1]] — global supply-chain identifiers (GTIN barcodes, RFID EPC, EDI messages)
- **Process standards** — ISO/IEC Directives govern how ISO and IEC committees develop standards; the W3C Process Document governs W3C Working Groups; IETF processes are documented in BCP 9 (RFC 2026) and BCP 10.
- **Intellectual property regimes** — W3C operates an RF Patent Policy; IETF requires FRAND or RF disclosure; Khronos issues royalty-free licences tied to Adopter membership; IEEE-SA maintains the IEEE-SA Patent Policy covering both RF and FRAND options.

### Provenance

