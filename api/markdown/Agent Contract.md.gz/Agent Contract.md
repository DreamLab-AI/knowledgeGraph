
An agent contract is an agreed set of terms that an AI agent exposes, declared as `Contract` in the contract module of the Agent Ontology.[^1] The Agent Ontology declares the class without a definition; this one follows from its properties. visionGraph places it under [[Api Contract]].

A contract is reached through an [[Agent Contract Set]] by the property `contract`. Its one property is `termsUri`, an `xsd:anyURI`, so a contract refers to terms held elsewhere rather than modelling clauses, parties or execution. That keeps the class light while letting an agent publish where its obligations can be read.

The word is used in the sense of an agreed set of terms. It is not a [[Smart Contract]], which is code executed on a blockchain, though the two can be related when a contract's terms are enforced on-chain. For agent-to-agent negotiation of work see [[Contract Net Protocol]].

[^1]: Semantic Agent Communication Community Group, “Contract Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/contract.ttl

