Secure Boot is a platform security mechanism that verifies the cryptographic signature of each component loaded during system start-up, allowing only software trusted by an established chain of keys to execute. By validating firmware, bootloaders, and the operating system loader before handing over control, it prevents persistent low-level malware such as bootkits from running. Secure Boot establishes a hardware-anchored chain of trust from power-on through to the operating system.

- [[Secure Boot]] is a [[Security]] mechanism that verifies the signature of each component loaded at start-up so only trusted software runs. It depends on [[Firmware]] and [[Hardware]] roots of trust, requires [[Cryptography]] and a hash such as [[SHA-256]], and implements load-time [[Authentication]] of the boot chain.

### Overview

- Secure Boot enforces that every stage of the boot sequence is signed by a key the platform trusts before it is allowed to execute.
- The chain begins with immutable code in firmware or hardware and extends through the bootloader to the operating system loader.
- Signature databases and revocation lists let platform owners control which software is accepted or blocked.
- The mechanism defends against bootkits and tampered firmware that would otherwise gain control before defences load.

### Mechanisms

- Root of trust: an immutable, hardware-anchored starting key validates the first stage.
- Signature verification: each stage checks the next stage's cryptographic signature.
- Key hierarchy: platform, key-exchange, and signature databases govern what is trusted.
- Revocation: compromised signatures can be denied via revocation lists.

### Applications

- Protecting PCs and servers against firmware and bootloader malware.
- Establishing the foundation for measured boot and remote attestation.
- Securing embedded and IoT devices from tampered firmware.
- Underpinning supply-chain integrity for platform software.

### Provenance

