Finished goods inventory is the stock of completed goods, or merchandise, held until they are sold or shipped.[^1][^2]

An open operations text lists finished goods or merchandise among the types of inventory and describes them as something we are all familiar with.[^1] An open managerial accounting text says that after each job has been completed and overhead has been applied, the product is transferred to the finished goods inventory, where it stays until it is sold.[^2] Georgia Tech class notes describe finished goods as outgoing from the organisation, the last of the stage types after raw materials and work in process.[^3]

## Why it is held

An open operations text gives protection against stockouts as a very common, probably the most common, reason for keeping inventory.[^1] MIT lecture slides define inventory in general as goods that a business holds for resale or redistribution, which is the sense in which finished goods are held.[^5]

## Scope and distinctions

Finished goods inventory is one of the stage types at [[Inventory Type]]. A review of operations and supply chain management says inventory management monitors raw materials, components and finished products across locations within the supply chain, such as warehouses and production systems, so finished goods can be held at several points rather than only at the factory.[^4] See [[Inventory Management]].

See also [[Make-to-Stock]].

## What the sources do not establish

No source gives typical levels of finished goods stock, nor guidance on where in a network it should be held, which is a network design question rather than a definition. The operations text and the accounting text define the term for different purposes, one in physical terms and one in cost terms.

[^1]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.1: Types of Inventory”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.01%3A_Types_of_Inventory
[^2]: OpenStax (Rice University), Principles of Accounting, Volume 2: Managerial Accounting, “4.3 Use the Job Order Costing Method to Trace the Flow of Product Costs through the Inventory Accounts”. https://openstax.org/books/principles-managerial-accounting/pages/4-3-use-the-job-order-costing-method-to-trace-the-flow-of-product-costs-through-the-inventory-accounts
[^3]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf
[^4]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^5]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf

