Rail freight is the carriage of goods by railway vehicle, which Eurostat classes as national, international or transit transport according to where the goods are loaded and unloaded.[^1]

Eurostat defines national rail transport as transport where the goods are both loaded and unloaded within the same reporting Member State, and transit as transport where the goods pass through the Member State without being loaded, unloaded or transshipped.[^1] The Glossary for transport statistics distinguishes types of consignment: a full train load is a consignment comprising a train transported together for one consignor from a single point of loading to a single point of unloading, and a full wagon load is a consignment of goods requiring the exclusive use of a wagon throughout its journey.[^2] It defines a rail freight terminal as a station used exclusively or predominantly for loading and unloading of goods and for formation, dispatch and reception of trains, and a railway transport operator as a licensed operator providing services for transport of goods or passengers by rail.[^2]

## Scale

In 2024 rail had 5.4% of EU freight transport performance (385 billion tonne-km), and its share was relatively stable over 2014 to 2024.[^3] In the UK rail moved 8% of domestic freight in 2024, 17 billion tonne-kilometres, and 73 million tonnes were lifted by rail, 6% more than in 2023. Goods moved by sea and rail have both generally declined over the past 10 years.[^4]

## Market structure in the EU

A European Commission item of December 2016 says more than 50% of rail freight traffic in 2014 was international, a much stronger European dimension than for passenger traffic. It says the market share of competing freight operators had more than doubled by 2014 from 15% in 2006, that rail freight was still entirely in the hands of national incumbents in Finland, Greece, Ireland, Lithuania and Luxembourg at the end of 2014, and that freight volumes dropped heavily in 2009.[^5] These figures are dated.

## Scope and distinctions

Rail Freight is a [[Freight Transport Mode]]. Related pages are [[Intermodal Transport]] and [[Road Freight]].

## What the sources do not establish

Sources opened here give no current EU market structure and no cost or emissions figures. The Commission data refer to 2014 to 2016.

[^1]: Eurostat, Statistics Explained, “Glossary:Rail freight transport”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Rail_freight_transport
[^2]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^3]: Eurostat, Statistics Explained, “Freight transport statistics - modal split”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Freight_transport_statistics_-_modal_split
[^4]: UK Department for Transport (GOV.UK), “Transport Statistics Great Britain: 2024 Freight”. https://www.gov.uk/government/statistics/transport-statistics-great-britain-2025/transport-statistics-great-britain-2024-freight
[^5]: European Commission, Mobility and Transport, “Commission releases report on the development of the rail market”, 9 December 2016. https://transport.ec.europa.eu/news-events/news/commission-releases-report-development-rail-market-2016-12-09_en

