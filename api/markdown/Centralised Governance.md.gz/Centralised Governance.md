Centralised governance is a model in which decision-making authority over a system, protocol, or organisation is concentrated in a single entity or a small controlling group. In contrast to distributed models, changes, upgrades, and policy are determined by this authority rather than by broad stakeholder consensus, which can deliver faster, more decisive action at the cost of reduced censorship resistance and a single point of control. It is the conventional baseline against which decentralised governance defines itself.

### Overview

- Under centralised governance a defined authority holds the right to set policy and execute changes without requiring distributed consensus.
- The model offers efficiency and clear accountability but introduces a single point of control and potential failure.
- It is the prevailing structure in traditional corporations and in many permissioned blockchain deployments.
- Blockchain projects often position decentralised governance explicitly in opposition to this centralised baseline.

### Key aspects

- Authority is concentrated in a single entity or small controlling group.
- Decisions can be made and enforced rapidly without broad stakeholder voting.
- Accountability is clear but censorship resistance is low.
- Contrasts directly with [[Decentralised Governance]] and [[Decentralised Autonomous Organisation]] structures.
- Aligns with conventional [[Corporate Governance]] and regulatory oversight models.

### Applications

- Permissioned blockchains where a consortium or operator controls protocol changes.
- Traditional corporate decision-making under board and executive authority.
- Regulated platforms that require an accountable controlling entity for [[Compliance]].
- Early-stage protocols retaining admin keys before progressive decentralisation.

### Provenance

