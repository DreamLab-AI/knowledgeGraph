A traceability data standard is a published specification for how information that supports traceability is structured and exchanged between organisations.[^1][^2][^3]

No opened source defines the phrase. The sources instead describe different kinds of standard that serve traceability, and they are best kept apart.[^1][^2][^4]

## Kinds of standard

A system-design standard sets principles rather than data formats. ISO 22005:2007 gives the principles and specifies the basic requirements for the design and implementation of a feed and food traceability system, which it calls a technical tool for determining the history or location of a product or its components.[^1] The record is an abstract only, since the standard itself is paywalled.[^1]

An event-data standard fixes the data and the interfaces. GS1 describes EPCIS as a traceability event messaging standard that enables supply chain visibility by sharing event data in a common language across, between and within enterprises.[^2] ISO publishes it as ISO/IEC 19987:2024, whose goal is to enable disparate applications to create and share visibility event data both within and across enterprises.[^3] See [[GS1 EPCIS]].

A credential standard fixes how claims are signed and discovered. The UN Transparency Protocol defines a suite of interoperable digital credentials and discovery mechanisms that enable verifiable supply chain transparency at scale, but its own page says the specification is suitable for pre-production pilot implementations.[^4]

## Scope and distinctions

These standards sit beside laws that require traceability records, covered at [[Traceability Regulation]], and beside identifier standards that supply the codes, covered at [[Supply Chain Identifier]]. The sources opened do not say how the three kinds of standard fit together, and they do not state which a company needs for a given regulation.[^1][^2][^4]

## What the sources do not establish

Usage bounds the term; no source defines it. Provenance models such as [[Provenance Ontology (PROV-O)]] were not part of the research for this page. No source compares the standards on coverage or adoption, and the UN specification is still work in progress.[^1][^2][^3][^4]

[^1]: ISO, “ISO 22005:2007 - Traceability in the feed and food chain — General principles and basic requirements for system design and implementation” (catalogue record). https://www.iso.org/standard/36297.html
[^2]: GS1, “EPCIS & CBV”. https://www.gs1.org/standards/epcis
[^3]: ISO, “ISO/IEC 19987:2024 - Information technology — EPC Information Services (EPCIS)” (catalogue record). https://www.iso.org/standard/85557.html
[^4]: UN Transparency Protocol, “Technical Specifications” (UNTP, work in progress). https://untp.unece.org/docs/specification/

