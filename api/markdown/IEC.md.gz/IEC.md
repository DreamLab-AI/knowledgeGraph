The International Electrotechnical Commission (IEC) is the leading global standards organisation that prepares and publishes international standards for all electrical, electronic and related technologies, collectively known as electrotechnology. Its standards cover areas such as industrial automation, machinery safety, programmable controllers and functional safety, and are frequently adopted jointly with ISO. IEC standards are widely referenced in robotics and industrial systems to ensure interoperability, safety and regulatory compliance.

### Overview

- The International Electrotechnical Commission coordinates the worldwide development of standards for electrotechnology.
- Its national-committee structure lets countries participate in consensus-based standard creation.
- Many IEC standards are published jointly with [[ISO]] where electrical and mechanical domains overlap.

### Key aspects

- Functional-safety standards define risk-reduction requirements for electrical and electronic systems.
- Programmable-controller and automation standards specify languages and interfaces for industrial equipment.
- Conformity-assessment schemes certify products against IEC requirements.
- Standards promote [[Interoperability]] and [[Compliance]] across vendors and borders.

### Applications

- Machinery and [[Robot Safety]] requirements in industrial settings.
- Specification of controllers and devices in [[IndustrialAutomation]].
- Electrical-equipment safety and performance baselines.
- Regulatory [[Compliance]] frameworks referencing IEC publications.

### Provenance

