A dry port is an inland terminal, usually rail or barge, linked to a maritime terminal by regular inland transport services.[^1]

Rodrigue and Notteboom define a dry port as a rail or barge terminal linked to a maritime terminal with regular inland transport services, and note that such places are also called inland ports.[^1] The Intergovernmental Agreement on Dry Ports uses a different, treaty-based wording: a dry port of international importance is an inland location as a logistics centre connected to one or more modes of transport for the handling, storage and regulatory inspection of goods moving in international trade and the execution of applicable customs control and formalities.[^2] The treaty definition names no seaport link; the textbook definition names no customs function.[^1][^2]

## Terminology

Rodrigue and Notteboom say there is no consensus on terminology: the terms in use include dry ports, inland terminals, inland ports, inland hubs, inland logistics centres and inland freight villages. They add that the term “dry” is open to debate, since many inland terminals are in fact wet through direct access to inland waterways.[^1] The Agreement adopts a list of dry ports as the basis for the coordinated development of important nodes in an international integrated intermodal transport and logistics system.[^2]

## Characteristics

Three characteristics recur in the textbook account: an intermodal terminal, either rail or barge, that has been built or expanded; a connection with a port terminal through rail, barge or truck services, often through a high-capacity corridor; and an array of logistical activities, often co-located with the terminal.[^1] The same chapter gives capacity as the main driver of inland port development, because a system of inland terminals increases the intermodal capacity for inland freight distribution.[^1]

## Relations

A dry port is a kind of [[Freight Node]] that extends a [[Seaport]] inland; see also [[Intermodal Transport]]. The seaport definition in the other source speaks of an interface between maritime and inland systems of circulation.[^3]

## Evidence limits

Neither source is a customs administration. The opened sources do not use the alias Inland Container Depot, so the text does not rely on it.[^1][^2]

[^1]: Jean-Paul Rodrigue and Theo Notteboom, Port Economics, Management and Policy, “Chapter 2.3 – Inland Ports / Dry Ports”. https://porteconomicsmanagement.org/pemp/contents/part2/dry-ports/
[^2]: UN Economic and Social Commission for Asia and the Pacific, “Intergovernmental Agreement on Dry Ports”. https://repository.unescap.org/bitstreams/89dfe168-8a17-472f-9bf6-12179b724714/download
[^3]: Theo Notteboom, Athanasios Pallis and Jean-Paul Rodrigue, Port Economics, Management and Policy, “Chapter 0.1 – Defining Seaports”. https://porteconomicsmanagement.org/pemp/contents/introduction/defining-seaports/

