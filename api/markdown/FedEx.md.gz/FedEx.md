FedEx is an express and parcel carrier and logistics company headquartered in Memphis, Tennessee. The European Commission described FedEx in a 2016 decision as providing customers and businesses worldwide with a broad portfolio of transportation, e-commerce and business services, listed on the New York Stock Exchange and headquartered in Memphis, Tennessee.[^1]

## What FedEx says it does

FedEx’s investor relations page carries a statement that FedEx Corporation will provide high-value-added logistics, transportation, and related end-to-end business services through a fully integrated digital and physical network.[^2] That is a statement of aims, not a description of activities, and the version of the page opened refers to fiscal 2024 material, so it is not current.[^2]

## Independent description in the ontology

The Industrial Ontologies Foundry gives FedEx as an example of an integrated carrier business organisation, defined as one created to provide different types of transportation and freight forwarding services, with UPS and DHL as the other examples, and gives the role of FedEx when it provides transportation services to its customers as its example of a logistics service provider role.[^3]

## Role in the supply chain

FedEx is placed under [[Parcel Carrier]] in this vault. The sources opened describe it as a provider of transportation, e-commerce and business services and, in the IOF, as an integrated carrier, but none uses the term parcel carrier or gives a parcel volume.[^1][^3] It is also a [[Logistics Service Provider]] in the IOF sense.[^3]

## What the sources do not establish

No source opened for this page covers the alias Federal Express. The sources give no fleet, volume or revenue figures. The company's own site returned an error page to automated requests for its about page, so the investor page is the only company statement used. The Commission's account dates from 2016.[^1][^2]

[^1]: European Commission, Case M.7630 FedEx / TNT Express, decision of 8 January 2016. https://ec.europa.eu/competition/mergers/cases/decisions/m7630_4582_4.pdf
[^2]: FedEx, Investor Relations page. https://investors.fedex.com/home/default.aspx
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

