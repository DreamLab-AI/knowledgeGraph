Sheffield is a metropolitan city in South Yorkshire, England, historically renowned as the Steel City for its dominance in cutlery, tool-making, and crucible steel production from the 18th century onwards. Today it operates as a major centre for advanced manufacturing, materials science, robotics research, and digital innovation, anchored by the University of Sheffield and Sheffield Hallam University. The city hosts the Advanced Manufacturing Research Centre (AMRC) — a globally recognised aerospace and industrial manufacturing cluster — as well as the Nuclear AMRC and a growing technology and data economy. Sheffield participates in the Northern Powerhouse initiative and is developing smart city infrastructure and innovation-district strategies aligned with Catapult programmes and UK industrial strategy.

### Overview

- Sheffield occupies the Don Valley and surrounding Pennine foothills in South Yorkshire, with a metropolitan population of around 685,000 (city proper). Its standing as the archetypal English industrial city derives from the river-powered grinding wheels and cutlery workshops of the 17th century, the invention of crucible steel by Benjamin Huntsman in the 1740s, and subsequent leadership in special steels and tooling throughout the Industrial Revolution.
- After the collapse of mass steel production in the 1980s, Sheffield undertook one of Britain's most visible industrial reinventions. The key vectors of that reinvention are:
  - **Research-led manufacturing** — the [[University of Sheffield]] and [[Sheffield Hallam University]] together form a dual-anchor research and skills base, with particular strengths in [[Materials Science]], [[Mechanical Engineering]], computer science, and [[Bioengineering]].
  - **AMRC ecosystem** — the [[Advanced Manufacturing Research Centre]] (AMRC), a Boeing-University of Sheffield joint venture founded in 2001 on the former Orgreave coking plant site, became a globally cited model for industry-academia collaboration in precision machining, composites, and aerospace manufacturing.
  - **Catapult network integration** — Sheffield hosts or co-hosts programmes linked to the [[High Value Manufacturing Catapult]], the [[Nuclear AMRC]] (for nuclear-grade component fabrication), and the [[UK Atomic Energy Authority]] supply-chain development.
  - **Digital and data economy** — the city's technology sector has grown substantially since 2010, clustering around the Kelham Island and Krynkl innovation districts, with focus on SaaS, [[Financial Technology]], creative industries, and applied [[Artificial Intelligence]].
- Sheffield's economy today spans healthcare (NHS teaching hospital), higher education, retail, logistics, and a reviving cultural and creative sector anchored by the Crucible Theatre and Off The Shelf literary festival.
- **Historical periodisation**
  - Pre-industrial (before ~1740): water-powered cutlery and grinding; cottage industry on River Sheaf tributaries.
  - First Industrial Revolution (1740–1870): Huntsman crucible steel; conversion to coke blast furnaces; population surge; Bessemer converters from 1858.
  - Second Industrial Revolution (1870–1940): special alloy steels (Hadfield's manganese steel, stainless steel co-invented at Firth Brown); engineering export dominance.
  - Post-war restructuring (1945–1980): nationalisation of steel (British Steel Corporation); gradual rationalisation; mass unemployment in 1980s closures.
  - Reinvention (1990–present): AMRC foundation; Heritage Lottery-funded Kelham Island Museum; digital corridor; Investment Zone designation; HS2/NPR connectivity debate.
- **Comparative position within UK city-regions**
  - Sheffield sits within the "core cities" network alongside [[Manchester]], [[Leeds]], [[Birmingham]], and [[Bristol]].
  - Distinguished from [[Manchester]] by its stronger manufacturing and materials research profile versus Manchester's financial services and digital media weight.
  - Distinguished from [[Leeds]] by industrial heritage and engineering depth versus Leeds's legal, financial, and retail primacy.
  - Uniquely positioned for nuclear and defence supply-chain work given Sheffield Forgemasters' forging capacity.

### Key Components

- **[[Advanced Manufacturing Research Centre]] (AMRC)**
  - Founded 2001; Boeing anchor partner; ~40 industrial partners spanning Rolls-Royce, Airbus, McLaren.
  - Core capabilities: 5-axis CNC machining, composite layup, additive manufacturing, [[Digital Twin]] process simulation.
  - Factory 2050 building: the UK's first fully reconfigurable digital manufacturing facility, embedding [[Industrial Internet of Things]] sensors and real-time process analytics.
- **[[Nuclear AMRC]]**
  - Specialises in precision manufacturing of nuclear reactor components.
  - Supports the UK civil nuclear programme and new build projects; contributes to [[Nuclear Engineering]] supply-chain qualification.
- **[[University of Sheffield]]**
  - Russell Group research university; ranked globally in materials, chemistry, and engineering.
  - Home to [[Insigneo Institute]] for in-silico medicine and the [[Royce Institute]] node for materials characterisation.
  - EPSRC-funded research in [[Machine Learning]] for materials discovery and [[Computer Vision]] for non-destructive testing.
- **[[Sheffield Hallam University]]**
  - Applied research focus; National Centre of Excellence for Food Engineering; strong in health sciences, sport technology, and creative computing.
- **Innovation Districts**
  - Heart of the City II urban regeneration scheme.
  - Kelham Island District: small-batch manufacturing, maker culture, and tech startups co-located with heritage industrial buildings.
  - Digital Campus at St Paul's Place: SaaS and digital agency cluster.
- **[[South Yorkshire Mayoral Combined Authority]]**
  - Governance body co-ordinating transport, skills, and investment across Sheffield, Rotherham, Barnsley, Doncaster.
  - Administers the South Yorkshire [[Investment Zone]] and [[Integrated Rail Plan]] connectivity funding.
- **Steel and Metals Legacy**
  - Specialist steel production continues via Outokumpu Stainless, Sheffield Forgemasters (Defence procurement supply), and Liberty Steel.
  - [[Forgemasters]] produces the UK's largest vacuum-arc-remelted steel forgings for submarine pressure hulls and nuclear reactor vessels.

### Applications and Use Cases

- **Aerospace component manufacturing** — AMRC machining cells produce critical flight-structural parts for Boeing 737/777 programmes; composite work supports Airbus A350 fuselage sections.
- **Nuclear new build supply chain** — Nuclear AMRC qualifies Sheffield-area manufacturers for Sizewell C and SMR (Small Modular Reactor) component contracts; connects to [[Nuclear Engineering]] and [[Additive Manufacturing]] for reactor internals.
- **Automotive lightweighting** — collaborations with McLaren Automotive and Sheffield-based moulding firms on carbon-fibre-reinforced polymer chassis; linked to [[Advanced Manufacturing]] and [[Material Science]] for weight-critical EV components.
- **Medical devices and in-silico medicine** — [[Insigneo Institute]] develops computational models of bone, cardiovascular tissue, and implants; [[Bioengineering]] outputs feed NHS implant procurement and EU medical-device certification.
- **Defence manufacturing** — Sheffield Forgemasters supplies high-integrity steel castings and forgings to the MoD; the city's metallurgical expertise underpins submarine and armoured-vehicle programmes.
- **Smart city pilots** — Sheffield City Council and the Combined Authority run IoT-enabled air quality, traffic, and waste monitoring networks; pilot programmes in [[Smart City Infrastructure]] and [[Open Data]] platforms.
- **Digital and creative industries** — games studios, design agencies, and music-tech startups located in Kelham Island; links to [[Creative Economy]] and [[Cultural Heritage]] digital preservation.
- **Education and skills pipeline** — the dual-university anchor and a network of further-education colleges supply skilled technicians and graduates for the AMRC partner companies; the Sheffield Digital Skills Partnership addresses [[Digital Inclusion]] gaps.

### Challenges and Transitions

- **Deindustrialisation legacy** — pockets of high deprivation persist in former steel-working wards (Burngreave, Manor, Page Hall); urban inequality is a governance challenge for the Combined Authority.
- **Skills gap** — the transition to [[Digital Manufacturing]] and [[Artificial Intelligence]]-augmented production requires retraining cohorts whose parents worked in analogue industrial trades; the Sheffield Digital Skills Partnership and AMRC Training Centre are key interventions.
- **Connectivity** — Sheffield lacks a direct mainline to London St Pancras (trains route via Midland Main Line or ECML interchange at Doncaster); the HS2/NPR debate materially affects its competitive position; the [[Integrated Rail Plan]] (2021) partially addressed this with a new Sheffield-Leeds-Manchester Transpennine route upgrade.
- **Green industrial transition** — the steel and forging sector is a significant carbon emitter; transition to hydrogen-fired electric-arc furnace steelmaking (aligned with the UK's [[Green Steel]] agenda) is a strategic priority; the AMRC is developing low-energy machining processes.
- **Ownership and supply-chain resilience** — Sheffield Forgemasters was acquired by the Ministry of Defence in 2021 to secure sovereign nuclear forging capability; Liberty Steel's financial instability demonstrated the risks of concentrated ownership in specialist metals.
- **Smart city ambitions vs. capacity** — Sheffield's smart city pilots are smaller-scale than [[Manchester]]'s CityVerve programme; limited council budgets constrain deployment of city-wide [[Internet of Things]] sensor networks and [[Open Data]] platforms.

### Standards and Context

- **UK Industrial Strategy (2017 & 2024 updates)** — Sheffield's AMRC cluster is cited as a flagship delivery mechanism for the Advanced Manufacturing sector deal.
- **[[High Value Manufacturing Catapult]]** — a consortium of seven centres including WMG Warwick and MTC Coventry; AMRC is a member centre with Innovate UK co-funding.
- **ISO 9001 / AS9100** — AMRC industrial partners operate under aerospace quality management systems; Nuclear AMRC work is subject to nuclear safety-case obligations under the ONR's LC 28 (examination, inspection, maintenance, and testing) framework.
- **UKRI / EPSRC programmes** — Future Manufacturing Research Hubs, Prosperity Partnerships, and Faraday Battery Challenge grants flow through Sheffield institutions; relevant to [[Research Funding]] and [[Open Innovation]].
- **Devolution settlements** — the South Yorkshire [[Integrated Settlement]] (from 2024 Autumn Statement context) grants the Mayoral Combined Authority greater control over skills, transport, and economic development budgets, shaping how Sheffield positions against rival city-regions.
- **[[UN Sustainable Development Goals]]** — Sheffield's industrial transition is positioned within SDG 9 (Industry, Innovation, Infrastructure), SDG 11 (Sustainable Cities), and SDG 8 (Decent Work and Economic Growth).

### Digital and Data Economy

- **Technology cluster profile**
  - Sheffield's digital economy comprises several hundred businesses ranging from startup studios in Kelham Island to established SaaS providers serving national markets.
  - Key sub-sectors: [[Financial Technology]] (payment processing, insurance technology), health tech, creative/games (Sumo Digital is the most prominent local studio), and [[EdTech]] platforms aligned with the university anchor.
  - The Sheffield Business School at Sheffield Hallam runs an accelerator programme; the AMRC's Factory 2050 hosts spin-out manufacturing-tech ventures.
- **Data infrastructure**
  - Sheffield City Region's data observatory aggregates economic, demographic, and skills data for policy planning; relevant to [[Open Data]] and [[Data Governance]].
  - The Combined Authority has begun deploying [[Internet of Things]] air quality and traffic sensors across the city-region as part of a smart-mobility study.
  - Partnerships with the Alan Turing Institute have produced projects on data-driven transport modelling and [[Predictive Analytics]] for NHS demand planning.
- **AI and machine learning applications**
  - The University of Sheffield's [[Natural Language Processing]] (NLP) group (GATE — General Architecture for Text Engineering) is internationally prominent in information extraction and biomedical text mining.
  - AMRC collaborates with deep-learning researchers to apply [[Computer Vision]] for surface defect inspection in machined aerospace parts, reducing inspection time and human error.
  - Sheffield-based SMEs are applying [[Machine Learning]] to predictive maintenance for rotating machinery, exploiting the city's industrial sensor data heritage.

### Ecosystem Relationships in Detail

- **Sheffield → AMRC → Aerospace OEMs**
  - The AMRC operates as a pre-competitive R&D buffer between Boeing, Rolls-Royce, Airbus, and the SME supply chain; discoveries move from AMRC research cells into licensed processes at tier-2 manufacturers across Yorkshire and the East Midlands.
- **Sheffield → Nuclear AMRC → Civil Nuclear Programme**
  - Nuclear AMRC qualifies suppliers against NQA-1 and nuclear-specific ASME codes; outputs directly feed into Sizewell C and UK SMR licence submissions.
- **Sheffield → Universities → Regional Skills**
  - University of Sheffield and Sheffield Hallam produce over 10,000 graduates per year; graduate retention is approximately 40%, driving the local skilled workforce pool.
  - The AMRC Training Centre at Waverley (Rotherham) is an Apprenticeship levy-funded facility delivering advanced manufacturing apprenticeships (Level 3–7) to ~500 apprentices per year.
- **Sheffield → South Yorkshire CA → National Government**
  - The Mayoral Combined Authority (MCA) acts as intermediary for UK Shared Prosperity Fund, Levelling Up Fund, and devolved skills budgets; Sheffield's economic strategy is embedded within the South Yorkshire Local Industrial Strategy.
  - The Investment Zone designation (2023 onward) offers business rate relief and planning flexibilities to attract investment in the advanced manufacturing, green energy, and digital sectors.
- **Sheffield → Northern Powerhouse → Pan-Regional Competitiveness**
  - The [[Northern Powerhouse]] framework links Sheffield to [[Manchester]], [[Leeds]], Liverpool, and Newcastle as a counterweight to London's economic gravitational pull.
  - Transport connectivity — Transpennine Express upgrades, potential HS2 Eastern Leg successor routing — is the dominant political variable in Sheffield's Northern Powerhouse positioning.

### Semantic Annotation Notes

- This concept is classified as an [[Urban Innovation Cluster]] (subClassOf) rather than simply "City" to capture its functional role as a nexus of research, manufacturing, and digital innovation within the knowledge graph.
- Sheffield's relevance to an [[Artificial Intelligence]] and [[Infrastructure]] knowledge graph derives from: (a) AMRC AI-in-manufacturing programmes; (b) GATE NLP research; (c) smart city and [[Internet of Things]] deployments; (d) [[Digital Twin]] process simulation at Factory 2050; (e) regional data observatory and predictive analytics work.
- Cross-domain bridges (bridgesTo relations) to [[Robotics]] and [[Artificial Intelligence]] reflect the AMRC's Factory 2050 robotic assembly programmes and the university's applied AI research.
- The sameAs relation to [[Steel City]] captures the well-established popular synonym used in economic geography, journalism, and policy discourse.

### Provenance

