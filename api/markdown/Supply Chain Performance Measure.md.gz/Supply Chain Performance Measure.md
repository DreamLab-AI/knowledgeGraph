A supply chain performance measure, also called a supply chain KPI or metric, is a standard for measuring the performance of a supply chain or one of its processes.[^1]

SCOR 12.0 gives a layered structure. Level-1 metrics are diagnostics for the overall health of the supply chain and are also known as strategic metrics and key performance indicators, and level-2 metrics serve as diagnostics for the level-1 metrics.[^1] Metrics are grouped under five performance attributes: reliability, responsiveness, agility, cost and asset management efficiency.[^1] Examples at level 1 include Perfect Order Fulfillment, Total Supply Chain Management Costs and Cash-to-Cash Cycle Time.[^1]

Gunasekaran, Patel and Tirtiroglu offer a different cut, by decision level. Their paper develops a framework for measuring strategic, tactical and operational performance in a supply chain, and presents a list of key performance metrics, with an emphasis on measures dealing with suppliers, delivery performance, customer service, and inventory and logistics costs.[^2]

## Scope and distinctions

SCOR lists its delivery metrics under reliability, its inventory metrics under asset management and its cost metrics under cost.[^1] The pages that follow cover [[Delivery Performance Measure]], [[Inventory Performance Measure]], [[Forecast Accuracy]], [[Overall Equipment Effectiveness]] and [[Supply Chain Cost Measure]], and the hub is [[Supply Chain Performance and Finance]].

A measure needs an agreed definition to be useful. McKinsey reports that there is no standard definition for on-time in-full, so different participants interpret the metric in significantly different ways, and that partners end up wasting time arguing over the figures rather than addressing the root causes of delivery issues.[^3] The point is made for one metric in the consumer sector, but it shows why the page treats the definition of each measure as part of the measure. See [[On-Time In-Full]].

## What the sources do not establish

No source opened here gives a canonical list of supply chain measures, and the two frameworks do not map onto each other. SCOR is cite-only and version 12.0 was read through a quick reference guide, since the current edition could not be opened. The Gunasekaran paper was read as an abstract only.[^1][^2]

[^1]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf
[^2]: A. Gunasekaran, C. Patel and E. Tirtiroglu, International Journal of Operations and Production Management 21(1-2), 2001 (Penn State record, abstract only), “Performance measures and metrics in a supply chain environment”. https://pure.psu.edu/en/publications/performance-measures-and-metrics-in-a-supply-chain-environment/
[^3]: McKinsey & Company (Alan Davies, Shruti Lal, Fernando Perez and Sanjhali Potdar), “Defining ‘on-time, in-full’ in the consumer sector”, 13 June 2019 (Internet Archive copy). https://web.archive.org/web/2024/https://www.mckinsey.com/capabilities/operations/our-insights/defining-on-time-in-full-in-the-consumer-sector

