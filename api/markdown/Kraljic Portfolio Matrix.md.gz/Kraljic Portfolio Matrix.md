The Kraljic portfolio matrix is a two-by-two classification of purchased items by strategic importance and supply risk, which gives four quadrants named non-critical, “leverage”, bottleneck and strategic.[^1]

Hesping and Schiele attribute the approach to Kraljic, citing publications from 1977 and 1983, and describe purchasing portfolio models, above all this matrix, as widely adopted to recommend generic strategies and tactics for different categories of purchases.[^1] Kraljic's article, published in the Harvard Business Review in September 1983 under the title “Purchasing Must Become Supply Management”, opens by saying that the stable way of business life many purchasing departments enjoyed had been imperilled by resource depletion, raw materials scarcity, political turbulence and intensified competition.[^2]

## Quadrants

Hesping and Schiele summarise Kraljic's recommendations. Non-critical purchases are of low strategic importance and ordered frequently from many alternative sources, so tactics focus on reducing transaction costs. “Leverage” purchases are strategically important in a large marketplace with many alternative suppliers, which allows full use of purchasing power, vendor selection and targeted pricing negotiations. Bottleneck purchases have low strategic importance and are available from few sources, so tactics focus on volume insurance, control of vendors, security of inventories and backup plans. Strategic purchases are critical for profitability and operations and can be obtained from a limited number of qualified sources, and they call for demand forecasting, market research, long-term supply relationships and make-or-buy decisions.[^1]

## Critique

Their survey of 107 sourcing projects of direct products found that the full range of tactical sourcing levers is used in each of the four quadrants, and they advocate moving away from strict adherence to a limited number of recommended tactics in each.[^1] Gelderman and van Weele presented a set of new perspectives on the approach at the 2000 IPSERA conference, which the Eindhoven University of Technology portal records without an abstract.[^3] See [[Sourcing Strategy]], [[Strategic Sourcing]] and [[Category Management]].

## What the sources do not establish

The HBR page gives only the opening of Kraljic's article, so the quadrant descriptions are Hesping and Schiele's summary of it, and the axes are described in their wording of strategic importance rather than the profit impact used in some other accounts.[^1][^2]

[^1]: Frank Henrik Hesping and Holger Schiele, International Journal of Production Economics 177, 2016 (University of Twente repository), “Matching tactical sourcing levers with the Kraljic matrix: Empirical evidence on purchasing portfolios”. https://ris.utwente.nl/ws/portalfiles/portal/6966746/Hesping_Matching%20tacticalsourcingleverswiththeKraljicmatrix.pdf
[^2]: Peter Kraljic, Harvard Business Review, September 1983 (publisher page with opening text), “Purchasing Must Become Supply Management”. https://hbr.org/1983/09/purchasing-must-become-supply-management
[^3]: C. J. Gelderman and A. J. van Weele, IPSERA 2000 proceedings (Eindhoven University of Technology research portal record), “New perspectives on Kraljic's purchasing portfolio approach”. https://research.tue.nl/en/publications/new-perspectives-on-kraljics-purchasing-portfolio-approach/

