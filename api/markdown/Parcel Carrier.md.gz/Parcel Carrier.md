A parcel carrier is a business that collects, sorts, transports and delivers parcels. European Union law defines parcel delivery services as services involving the clearance, sorting, transport and distribution of parcels, and a parcel delivery service provider as an undertaking that provides one or more of them.[^1]

## Definitions and scope

The Regulation on cross-border parcel delivery services reaches providers that use alternative business models, such as those drawing on the collaborative economy and e-commerce platforms, if they provide at least one of the steps in the postal delivery chain.[^1] Its recitals say that clearance, sorting and distribution, including pick-up services, should be considered parcel delivery services, including when express and courier service providers, as well as consolidators, provide them.[^1] Transport alone, not undertaken in conjunction with one of those steps, falls outside the scope of parcel delivery services, including when subcontractors carry it out.[^1]

The Regulation excludes undertakings established in one Member State alone that only provide domestic parcel delivery services as part of a sales contract and personally deliver the goods that are the subject of that contract.[^1]

The European Commission's logistics page names the sector in commercial terms: express, courier and parcel services are key to the e-commerce delivery business.[^2] The Industrial Ontologies Foundry gives FedEx, UPS and DHL as examples of integrated carrier business organisations, meaning organisations created to provide different types of transportation and freight forwarding services.[^3]

## Scope and distinctions

A parcel carrier is a kind of [[Freight Carrier]]. It overlaps with [[Last-Mile Delivery]], the final step of delivery to the recipient, and it serves [[E-Commerce]]. The alias courier, express and parcel operator, or CEP operator, follows the Commission's phrase express, courier and parcel service, though the sources opened do not define the abbreviation.[^2]

## What the sources do not establish

The Regulation defines parcel delivery by service and, for transport alone, assumes that the activity is part of the transport sector.[^1] The opened sources give no single line between a parcel carrier, a courier and an express operator, and no weight or speed class beyond the Regulation's own definitions. The page rests on EU material, the IOF ontology and one Commission page, and it contains no figures on volumes or market shares.

[^1]: European Parliament and Council, Regulation (EU) 2018/644 of 18 April 2018 on cross-border parcel delivery services (Official Journal text hosted by ARCEP). https://www.arcep.fr/fileadmin/reprise/textes/reglements/regulation-europe-2018-644-parcels-ENG.pdf
[^2]: European Commission, Directorate-General for Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

