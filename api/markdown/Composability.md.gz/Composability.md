Composability is the property by which independent components can be combined into larger systems whose behaviour is predictable from the behaviour of the parts. In blockchain and decentralised finance it describes how permissionless smart contracts can call and build upon one another so that protocols interlock like building blocks, often called money legos. Composability accelerates innovation but couples systems together, propagating both functionality and risk across the stack.

- [[Composability]] is the property that independent components can be combined into larger systems whose behaviour follows from the parts. In [[Blockchain]] it describes how permissionless [[Smart Contract]]s call and build on one another.
- It is the foundation of "money legos" in [[Decentralised Finance]], where protocols interlock to create new financial primitives, and it is closely tied to [[Interoperability]].

### Overview

- Composability lets developers treat deployed contracts as public infrastructure: any contract can invoke another's functions, so a new application can reuse existing liquidity, oracles and tokens rather than rebuilding them.
- This permissionless reuse is what gives DeFi its rapid, combinatorial innovation, but it also means a flaw or economic exploit in one protocol can cascade to everything that composes with it.
- Composability differs from interoperability: the former is about combining contracts within a shared execution environment, while the latter spans heterogeneous systems and chains.

### Key aspects

- Atomic composability: multiple contract calls succeed or revert together within a single transaction.
- Permissionless integration: no approval is needed to build on a public contract.
- Money legos: financial primitives stack into complex strategies.
- Shared state: contracts read and write a common ledger, enabling tight coupling.
- Risk propagation: dependencies inherit each other's failure modes.

### Applications

- Yield aggregators that route capital across lending and exchange protocols.
- Structured products assembled from primitive swaps, loans and derivatives.
- On-chain governance and treasury tools built atop token standards.
- Cross-protocol [[Decentralised Exchange]] routing and aggregation.

### Provenance

