A quorum is the minimum number or proportion of participants—nodes, validators, voters, or signers—that must concur or be present for a decision, transaction, or consensus round to be considered valid in a distributed system or governance process. In distributed computing, quorum systems are collections of node subsets with the intersection property: any two quorums share at least one member, preventing contradictory decisions across network partitions. In blockchain and DAO governance, quorum thresholds set the participation floor required before a vote or proposal carries binding weight, balancing decision liveness against resistance to minority capture. Threshold signature schemes and multi-signature wallets operationalise quorum as an m-of-n approval requirement that eliminates single points of failure in key custody.

### Overview

- Quorum is one of the oldest and most fundamental concepts in collective decision-making, formalised in distributed computing theory and adapted across [[Blockchain]], [[Distributed Database]], and [[Decentralised Governance]] contexts.
- **Why it matters**: without a well-defined quorum, a distributed system cannot guarantee safety—two disjoint subsets of nodes could simultaneously commit contradictory decisions, violating [[Linearisability]]. Quorum intersection is the mathematical invariant that prevents this.
- **Core guarantee**: any two quorums in a valid quorum system must intersect. In a majority-quorum system over n nodes, any two sets of ⌊n/2⌋+1 nodes share at least one common member. This intersection witness can detect and prevent contradictory commits.
- **Liveness vs safety trade-off**: larger quorums improve [[Safety]] (harder to corrupt the overlap) at the cost of [[Liveness]] (harder to assemble the quorum during network partitions). Smaller quorums are more responsive but more susceptible to minority takeover. This tension maps directly onto the [[CAP Theorem]]—systems choosing consistency over availability implicitly choose larger, stricter quorums.
- **Breadth of application**: quorum concepts appear in [[Consensus Algorithm]] design, [[Multi-signature Wallet]] custody, [[On-chain Governance]] proposals, [[Distributed Database]] replication, [[Oracle Network]] aggregation, and [[Threshold Signature]] cryptography.

### Key Components and Mechanisms

- **Quorum size / threshold (t)**
  - In crash fault-tolerant systems: majority quorum requires t = ⌊n/2⌋+1 nodes, tolerating f = ⌊(n-1)/2⌋ failures.
  - In [[Byzantine Fault Tolerance]] systems: quorum requires t = ⌈2n/3⌉+1 nodes, tolerating f = ⌊(n-1)/3⌋ Byzantine nodes (the 3f+1 bound).
  - In [[Proof of Stake]] blockchains: quorum is typically two-thirds of total staked weight, not raw node count.
- **Quorum intersection property**
  - The defining invariant: for any two quorums Q1 and Q2 in the quorum system, Q1 ∩ Q2 ≠ ∅.
  - This ensures that any state committed by one quorum is witnessed by at least one member of every subsequent quorum, propagating knowledge of prior commits.
- **Read/write quorums in distributed databases**
  - [[Dynamo]]-style systems use configurable read quorum R and write quorum W where R + W > n, guaranteeing at least one node in any read overlaps with the last write quorum.
  - This allows tuning between read-heavy and write-heavy workload profiles without sacrificing consistency.
- **Federated quorum systems**
  - The [[Stellar Consensus Protocol]] (SCP) and [[Federated Byzantine Agreement]] generalise quorums: each node declares its own quorum slices (subsets it trusts), and system-wide quorums emerge from the union of trust graphs. No global membership list is required.
  - This enables open membership while preserving safety for well-connected nodes, at the cost of quorum availability for poorly-connected ones.
- **m-of-n threshold quorums**
  - [[Multi-signature Wallet]] schemes implement quorum as an m-of-n requirement: m distinct signatories from a set of n must approve an action.
  - [[Threshold Signature]] schemes cryptographically distribute a private key across n parties such that any m can collaborate to produce a valid signature without reconstructing the key.
  - Used for [[Treasury Management]], oracle operator coordination, bridge operators in [[Cross-chain Bridge]] protocols, and smart-contract upgrade key custody.
- **Governance quorums**
  - In [[DAO Governance]] and [[On-chain Governance]], a governance quorum sets a minimum participation rate (e.g., 4% of total token supply must vote) before a proposal result is binding.
  - Separate from supermajority thresholds (e.g., 66% of cast votes must approve): quorum gates who participates, supermajority gates how they vote.
  - Adaptive quorum biasing (used by [[Polkadot]] and [[Kusama]]) scales the required supermajority inversely with participation—low-turnout votes require near-unanimous approval to pass.

### Applications and Use Cases

- **Blockchain consensus**
  - [[Tendermint]], [[HotStuff]], and [[PBFT]] use ⅔n+1 quorums across validator sets for BFT block finalisation.
  - [[Ethereum]] Proof of Stake uses a two-thirds supermajority of staked ETH across its validator committee for attestation finality.
  - [[Hyperledger Fabric]] uses configurable endorsement policies (a form of quorum) requiring signatures from specified organisations before a transaction is considered valid.
- **Distributed databases**
  - [[Apache Cassandra]] allows per-query quorum levels (ONE, QUORUM, ALL) letting operators trade consistency for latency.
  - [[CockroachDB]] and [[TiKV]] use Raft-based majority quorums for range replication, providing serialisable transactions across geo-distributed nodes.
  - [[etcd]] and [[ZooKeeper]] implement Raft and ZAB respectively, both requiring majority quorums for leader election and log commit.
- **DAO and protocol governance**
  - [[Compound Finance]] governance requires a quorum of 400,000 COMP tokens (approximately 4% of supply) before a proposal vote is binding.
  - [[MakerDAO]] governance uses quorum thresholds in executive votes; low participation has historically been a governance risk vector.
  - [[Uniswap]] governance employs a 40 million UNI quorum for on-chain proposals.
  - [[Polkadot]] OpenGov uses adaptive quorum biasing across multiple governance tracks with different quorum and approval curves.
- **Multi-party cryptographic operations**
  - [[Threshold Signature Scheme]] (TSS) implementations in custodial wallets and DeFi bridge operators use 5-of-9 or similar quorum structures.
  - [[Distributed Key Generation]] (DKG) protocols establish threshold quorums for key material without any single party holding the complete secret.
  - [[Oracle Network]] operators (e.g., [[Chainlink]]) aggregate data reports from a quorum of oracle nodes to filter outliers and prevent manipulation.
- **AI and distributed training** (bridging domain)
  - Federated and decentralised [[Machine Learning]] aggregation schemes borrow quorum concepts: a round of gradient aggregation may require updates from a quorum of participants before the global model is updated, providing robustness to stragglers and Byzantine workers.
  - [[Federated Learning]] secure aggregation can use threshold cryptography (quorum-based) to aggregate model updates without revealing individual gradients.

### Standards and Context

- **Classical foundations**
  - Leslie Lamport's [[Paxos]] protocol (1989/1998) formalised majority quorums as the mechanism for safe distributed consensus under crash failures.
  - [[Raft]] (Ongaro & Ousterhout, 2014) was designed as a more understandable alternative to Paxos, retaining majority quorums.
  - The theoretical lower bound for Byzantine fault tolerance (3f+1 nodes to tolerate f Byzantine failures) was established by Lamport, Shostak, and Pease in "The Byzantine Generals Problem" (1982).
- **Blockchain protocol specifications**
  - Tendermint Core specification defines ⅔ stake-weighted quorums for prevote and precommit phases.
  - Ethereum consensus layer (Beacon Chain) specs define attestation quorums as committees of validators sampled from the full validator set.
  - [[Stellar]] SCP is specified in the Stellar whitepaper by David Mazières, introducing federated quorum slices.
- **Governance frameworks**
  - [[Compound Finance]] Governor Bravo governance contract encodes quorum as a on-chain immutable parameter.
  - [[OpenZeppelin]] Governor module provides configurable quorum fraction as a percentage of total supply at proposal snapshot.
  - [[Polkadot]] OpenGov specifications define track-specific quorum and approval curves in the RFC process.
- **Cryptographic standards**
  - NIST is standardising threshold signature schemes under its post-quantum cryptography process; quorum-based key custody is expected to become a compliance baseline for custodians.
  - [[FROST]] (Flexible Round-Optimised Schnorr Threshold signatures) is an IETF draft defining a performant t-of-n signing scheme.

### Current Landscape (2026)

- Consensys Quorum has effectively converged with Hyperledger Besu: as of 2025-2026 Consensys and the ecosystem recommend Besu for all new permissioned deployments, while GoQuorum (latest release v24.4.1, June 2024) is kept in maintenance and remains in production at several major banks and financial institutions.
- QBFT (Quorum Byzantine Fault Tolerant) is now the de facto standard consensus for new permissioned Ethereum networks; the EEA finalised the QBFT specification in 2023, Besu made QBFT snap-sync default in 25.7.0 and shipped an IBFT-to-QBFT migration path in 25.3.0 plus faster quorum-recovery (early round change) since 25.2.0.
- Besu moved under Linux Foundation Decentralized Trust (LF Decentralized Trust) governance, which launched a Besu Certified Service Provider programme in June 2025 (first CSPs: Consensys, Kaleido, Cheesecake Labs, CPQD, DSR Corporation, Kerala Blockchain Academy) and reported Besu at roughly 16-18% of Ethereum mainnet execution clients.
- The classic Quorum privacy stack is being retired: LF Decentralized Trust announced the sunsetting of Tessera private transactions and smart-contract permissioning (September 2024), and native Tessera privacy was removed from Besu in release 25.6.0 (June 2025), pushing users toward application-layer privacy.
- New privacy frameworks have stepped in: Kaleido's Paladin (pluggable EVM privacy with privacy groups, private tokens and a notary system) graduated from LFDT Lab to a full project in November 2025 with central and commercial bank adopters, and the ZK-oriented Minokawa (Compact language) was contributed in September 2025.
- Besu tracked Ethereum's roadmap closely, delivering Pectra/Prague support (activated 2025-05-07, releases 25.4.0-25.5.0) and Fusaka/BPO forks across 2025, keeping permissioned Quorum-lineage networks aligned with mainnet EVM semantics.
- Adoption is being driven by real-world asset tokenisation, CBDC pilots and institutional finance (Citi joined the Besu for Financial Services working group; Deutsche Bundesbank and Bank of Korea joined LFDT), while open challenges centre on migrating legacy GoQuorum/Tessera deployments, EIP-4444 history expiry, and modularising consensus out of the core Besu monorepo.

### References

- 1. Chainlaunch (2026). QBFT in Besu: Genesis Config, Validators, and Block Time. https://chainlaunch.dev/blog/qbft-consensus-besu-guide
- 2. LF Decentralized Trust (2024). Sunsetting Tessera and Simplifying Hyperledger Besu. https://www.lfdecentralizedtrust.org/blog/sunsetting-tessera-and-simplifying-hyperledger-besu
- 3. LF Decentralized Trust / Linux Foundation (2025). LF Decentralized Trust Announces Six New Members, Expanded Certified Service Provider Program. https://www.linuxfoundation.org/press/lf-decentralized-trust-announces-six-new-members-expanded-certified-service-provider-program-1
- 4. Ledger Insights (2025). Paladin privacy framework graduates as Bank of Korea joins LF Decentralized Trust. https://www.ledgerinsights.com/paladin-privacy-framework-graduates-as-bank-of-korea-joins-lf-decentralized-trust/
- 5. LF Decentralized Trust (2025). 2025 Q2 Besu Project Update. https://lf-decentralized-trust.github.io/governance/project-updates/2025/2025-Q2-Besu/

### Provenance

