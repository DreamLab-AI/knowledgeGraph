
A resource constraint is a [[Constraint]] on a computational resource such as memory, processor time or storage. The Agent Ontology declares it as `ResourceConstraint`.[^1]

An [[Execution Environment]] reaches it through `hasResourceConstraint`. Two datatype properties describe an instance: `constraintType`, a string for which the ontology gives examples such as `max_memory_mb` and `max_cpu_percentage`, and `constraintValue`, also a string. Because both are free strings, the class fixes no vocabulary of resources, and any limit that can be named and given a value fits.

visionGraph groups the limits an environment can impose under this class. [[Execution Budget]] limits financial expenditure and [[Rate Limiting]] limits the frequency of requests; both are specialisations of the general concept. A resource constraint says how much may be used, whereas [[Resource Allocation]] says how it is shared out.

[^1]: Semantic Agent Communication Community Group, “Execution Context Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/execution-context.ttl

