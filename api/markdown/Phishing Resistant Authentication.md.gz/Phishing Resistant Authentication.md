Phishing-resistant authentication is a class of authentication methods designed so that credentials cannot be captured and replayed by an attacker who tricks a user into interacting with a fraudulent site or relay. It achieves this primarily through public-key cryptography combined with origin binding, so that a credential is cryptographically tied to the legitimate service's domain and will not authenticate to an impostor. FIDO2/WebAuthn passkeys and hardware security keys are the canonical implementations, replacing shared secrets such as passwords and one-time codes that remain vulnerable to interception.

### Overview

- Phishing-resistant authentication addresses the dominant failure mode of credential-based systems: even strong passwords and one-time codes can be harvested by convincing fake sites or real-time relay proxies. By binding a cryptographic key pair to a specific web origin, schemes like WebAuthn ensure that the authenticator refuses to produce a valid assertion for any domain other than the one for which the credential was registered. The private key never leaves the authenticator, so there is no shared secret to steal in transit or at rest on the server.

### Mechanisms

- Public-key credentials with the private key held in the authenticator
- Origin binding that scopes credentials to a specific domain
- Challenge-response signing to prevent replay
- Hardware-backed or platform-backed key storage
- User presence and verification gestures (biometric, PIN, touch)

### Applications

- Passkey sign-in for consumer and enterprise accounts
- Hardware security keys for high-assurance access
- Passwordless workforce authentication
- Protection against real-time phishing and adversary-in-the-middle attacks

### Provenance

- This class was materialised to resolve inbound references from existing classes in the knowledge graph.

