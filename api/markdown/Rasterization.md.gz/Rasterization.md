The dominant real-time rendering technique that converts 3D geometric primitives — predominantly triangles — into a 2D pixel representation by determining per-pixel coverage, depth, and colour through a GPU-accelerated pipeline of vertex processing, primitive assembly, scan conversion, fragment shading, and output merging. Rasterization trades photorealistic accuracy for deterministic, high-throughput performance suitable for interactive applications.

### Semantic Classification

### Content

#### Key Characteristics

- **Triangle-Based**: Processes geometry as discrete triangles
- **Screen-Space**: Works in 2D screen coordinates after projection
- **Per-Pixel Operations**: Determines color for each screen pixel
- **Hardware Accelerated**: Optimized for GPU parallel processing
- **Deterministic**: Same input produces identical output
  ## Rendering Pipeline Stages
  ### 1. Vertex Processing
- Transform vertices from model space to screen space
- Apply vertex shaders for position, normal, texture coordinates
- Perspective division and viewport transformation
  ### 2. Primitive Assembly
- Group vertices into triangles, lines, or points
- Perform clipping against view frustum
- Cull back-facing triangles
  ### 3. Rasterization (Scan Conversion)
- Determine which pixels are covered by each triangle
- Generate fragments for each covered pixel
- Interpolate vertex attributes across triangle surface
  ### 4. Fragment Processing
- Execute pixel/fragment shaders
- Calculate final pixel color using textures, lighting
- Apply blending and transparency
  ### 5. Output Merger
- Depth testing (z-buffer)
- Stencil testing
- Blending with framebuffer
- Write final pixel colors
  ## Definition
  Real-time rendering technique that converts 3D geometric primitives (triangles, lines, points) into a 2D pixel representation by determining pixel coverage, depth, and color through a series of GPU-accelerated stages.
  #### Related Concepts
- [[Ray Tracing]]
- [[Vertex Shader]]
- [[Pixel Shader]]
- [[Level of Detail]]
- [[3D Rendering]]
  ## Applications
- Real-time metaverse environments
- Video game rendering engines
- VR/AR head-mounted displays
- 3D web experiences (WebGL, WebGPU)
- Mobile metaverse applications
  ## Advantages
- Extremely fast for real-time rendering
- Predictable performance characteristics
- Well-optimized hardware support
- Lower power consumption than ray tracing
- Scales well with scene complexity management
  ## Limitations
- Difficult to achieve photorealistic lighting
- Hacks required for reflections/refractions
- Shadow rendering requires special techniques
- Transparent object ordering challenges
- Limited global illumination capabilities
  ## Optimization Techniques
- **Frustum Culling**: Skip objects outside view
- **Occlusion Culling**: Skip hidden objects
- **Level of Detail**: Reduce geometry based on distance
- **Instancing**: Efficient rendering of repeated objects
- **Texture Atlasing**: Reduce texture switching
  #### References
- Akenine-Möller, T. et al. (2018). *Real-Time Rendering*, 4th ed.
- Sellers, G. et al. (2016). *Vulkan Programming Guide*
- Shirley, P. & Marschner, S. (2009). *Fundamentals of Computer Graphics*
  ### Relationships

### Provenance

