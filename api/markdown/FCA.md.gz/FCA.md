The Financial Conduct Authority (FCA) is the UK's statutory conduct regulator for financial services and markets, established under the Financial Services and Markets Act 2000 and reconstituted by the Financial Services Act 2012. Operating independently of government and funded by industry fees, it authorises firms, supervises conduct across retail and wholesale markets, and enforces anti-money-laundering obligations. In the digital asset sphere the FCA registers crypto-asset businesses under the Money Laundering Regulations, regulates crypto financial promotions, and coordinates with the Bank of England and HM Treasury on emerging regulatory frameworks for stablecoins, custody, and tokenised finance.

### Overview

- The FCA is an operationally independent, non-governmental body funded entirely by fees levied on regulated firms and markets. It derives its statutory powers from primary legislation and acts under direction from Parliament, not HM Treasury (though Treasury sets the regulatory framework). It publishes rulebooks (the FCA Handbook), supervisory statements, and policy consultations.
- The FCA's significance lies in:
  - Being the gateway for any financial business to operate legally in the UK
  - Setting conduct standards across consumer credit, investment services, insurance, payment services, and digital assets
  - Exercising credible enforcement powers — including criminal prosecution, civil penalties, public censure, and withdrawal of authorisation
  - Co-ordinating with the [[Prudential Regulation Authority]] (PRA) within the Bank of England on dual-regulated systemically important firms (banks, insurers, major investment firms)
- The regulator emerged in its current form after the 2008 global financial crisis exposed serious failings in the tripartite model (FSA, Bank of England, HM Treasury) and prompted Parliament to consolidate prudential and conduct oversight into distinct but co-ordinated bodies.

### Key Components and Mechanisms

#### Authorisation and Registration

- Firms providing [[Regulated Activities]] (e.g. dealing in investments, deposit-taking, insurance distribution) require FCA authorisation under the Financial Services and Markets Act permission regime
- Separate registration track exists for [[Payment Institution]] and [[Electronic Money Institution]] under EU-derived Payment Services Regulations
- Crypto-asset businesses must register under the [[Money Laundering Regulations]] since January 2020, a distinct and narrower gateway than full authorisation — covering only AML/CFT obligations
- The FCA's Financial Services Register is the public record of all authorised and registered entities

#### Supervisory Approach

- Risk-based supervision prioritises firms and activities proportional to potential consumer harm
- Outcomes-based regulation rather than prescriptive rule compliance — emphasised in the [[Consumer Duty]] (2023), which requires firms to deliver good outcomes for retail customers across products, price, service, and communications
- [[Supervisory Review]] encompasses on-site inspections, data analytics, thematic reviews, and enforcement referrals
- The Regulatory Sandbox (FCA Innovate) allows firms to test novel products including [[Decentralised Finance]] and [[Tokenisation]] products in a controlled environment without full regulatory burden

#### Enforcement

- Powers include financial penalties, public statements (Final Notices), variation/cancellation of permissions, and criminal prosecution
- Market abuse and insider dealing are enforced under the Market Abuse Regulation (UK MAR) after Brexit
- The FCA publishes enforcement data and uses credible deterrence as a supervisory signal to the wider market

#### Digital Asset and Crypto Regulation

- Since 10 January 2020 all UK [[Crypto-Asset]] businesses are subject to UK MLR registration for AML/CFT controls
- Since 8 October 2023 financial promotions for cryptoassets require FCA approval or issuance by an FCA-authorised firm — the rules mandate fair, clear, and not misleading communications with mandatory risk warnings and a 24-hour cooling-off period for new investors
- The FCA, HM Treasury, and Bank of England have published joint consultation papers on a regulatory framework covering [[Stablecoin]] issuance, cryptoasset trading venues, custody, and lending
- The FCA participates in the Cryptoasset Taskforce (with HM Treasury and Bank of England) that sets UK digital-asset policy direction

### Applications and Use Cases

#### Firms Seeking UK Market Access

- International firms wishing to serve UK retail or professional clients must obtain FCA authorisation or rely on limited Overseas Persons exemptions
- Post-Brexit, EU passporting ceased; EU firms must now seek standalone UK authorisation
- Crypto exchanges, brokers, and custodians serving UK clients must complete MLR registration before onboarding UK clients

#### Compliance and Risk Management

- Financial institutions build [[Compliance Framework]] programmes around FCA rules (Principles for Businesses, SYSC, COND, and sector-specific sourcebooks)
- [[Know Your Customer]] and Customer Due Diligence requirements under MLR registration are enforced by the FCA with escalating penalty power
- FCA Guidance and Policy Statements shape internal [[AML/CFT]] programme design across traditional and digital finance

#### FinTech and Innovation

- The FCA Sandbox (2016–present) has enabled over 1,000 firms to test products ranging from open banking to [[Tokenisation]] of real-world assets
- The Digital Sandbox (2021) provides synthetic financial data and APIs for firms at earlier development stages
- Regulatory technology ([[RegTech]]) adoption is encouraged through FCA TechSprints and published guidance on machine-learning model risk

#### Consumer Advocacy

- The FCA's [[Consumer Duty]] (2023) is the most significant conduct reform in a generation, requiring firms to prove positive outcomes rather than merely avoid prohibited conduct
- The Financial Ombudsman Service (FOS) and Financial Services Compensation Scheme (FSCS) operate alongside the FCA as redress mechanisms, though they are separate bodies

### Standards and Context

#### Legislative Foundations

- Financial Services and Markets Act 2000 (FSMA 2000) — primary enabling legislation
- Financial Services Act 2012 — abolished FSA, created FCA and PRA
- Financial Services and Markets Act 2023 — post-Brexit regulatory reforms ("Edinburgh Reforms"), introduced [[Consumer Duty]] on statutory footing and broader crypto powers
- Money Laundering, Terrorist Financing and Transfer of Funds Regulations 2017 (MLRs) — AML/CFT obligations extended to crypto-asset businesses
- Financial Services and Markets Act 2023 (Digital Securities Sandbox) — enables real-world DLT-based securities settlement trials under temporary FCA/Bank of England oversight

#### International Co-ordination

- [[FATF]] — FCA implements FATF Recommendations, especially the Travel Rule for virtual asset service providers (VASPs)
- [[IOSCO]] — FCA is a full IOSCO member; IOSCO crypto-asset and DeFi recommendations shape FCA policy consultations
- [[Financial Stability Board]] — FSB produces global crypto regulatory frameworks (e.g. 2023 high-level recommendations) which the UK adopts as baseline
- European Securities and Markets Authority ([[ESMA]]) — former relationship under EU single-market; now arms-length co-operation post-Brexit, including information-sharing agreements
- [[Basel Committee on Banking Supervision]] — standards for bank exposures to crypto-assets implemented in UK via PRA rulebook, aligned with FCA supervisory expectations

#### Comparison with Peer Regulators

- US: Securities and Exchange Commission ([[SEC]]) and Commodity Futures Trading Commission (CFTC) exercise fragmented jurisdiction by asset type; the UK FCA has a unified conduct remit across the spectrum
- EU: [[ESMA]] co-ordinates national competent authorities under MiFID II; the EU's Markets in Crypto-Assets Regulation ([[MiCA]]) (2024) provides a model the UK is tracking but not adopting verbatim
- Singapore: Monetary Authority of Singapore (MAS) — comparable integrated regulator with a similarly active digital asset programme

#### Key FCA Publications

- FCA Handbook (online, continuously updated) — binding rules for authorised firms
- Policy Statements (PS) and Consultation Papers (CP) — public consultation and finalised policy
- Guidance on Cryptoassets — series of guidance notes covering registration, financial promotions, and forthcoming phases of the crypto framework
- Consumer Duty Guidance — FG22/5 and subsequent updates
- Annual Report and Financial Crime Data returns — aggregated compliance outcomes

### Provenance

