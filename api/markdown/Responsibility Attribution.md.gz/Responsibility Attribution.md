
A responsibility attribution is a record that assigns responsibility for an executed action to an agent or principal, on the strength of execution evidence. The Agent Ontology declares it as `ResponsibilityAttribution`.[^1]

An [[Accountability Event]] reaches it through the property `responsibility`, so each attribution belongs to the evaluation of one action. Two properties describe it. `assignedTo` names the agent that bears the responsibility, and `rationale` is a string explaining why the assignment was made. The outcome of an accountability review is therefore a named agent plus a stated reason, not a score or a status code.

Because `assignedTo` ranges over agents, the party held responsible may be the agent that performed the action or the principal that delegated it. The attribution sits alongside the [[Delegation Basis]], which records how the action was authorised, and belongs to the wider concern of [[Accountability]].

visionGraph places Responsibility Attribution under [[Accountability]] and as part of the Accountability Event it concludes.

[^1]: Semantic Agent Communication Community Group, “Accountability Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/accountability.ttl

