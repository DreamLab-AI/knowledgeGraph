A supplier code of conduct is a written statement of the social, environmental and ethical standards a buyer expects its suppliers to meet, and the sources opened here describe such codes without defining the term formally.[^1]

The UN Global Compact and BSR guide offers advice on designing a supplier code of conduct that builds from the Global Compact ten principles and other recognised international standards, and on how to put the code to use.[^1] It says that for many companies a supplier code is a natural extension of corporate values statements and is seen as an affirmation of existing expectations rather than a new set of requirements.[^1] It adds that the environmental topics most relevant vary by industry, which makes dialogue and collaboration critical to identifying which issues to cover.[^1]

## Shared codes

Industry and multi-stakeholder bodies publish codes that companies adopt or build on. The Responsible Business Alliance Code of Conduct is a set of social, environmental and ethical industry standards that reference international norms including the Universal Declaration of Human Rights, ILO standards and the OECD Guidelines for Multinational Enterprises.[^2] It originated with the electronics industry but is used by many industries, and it is updated every five years.[^2]

The Ethical Trading Initiative Base Code is founded on International Labour Organisation conventions and is an internationally recognised code of labour practice, and its provisions constitute minimum and not maximum standards.[^3] See [[Ethical Sourcing]].

## Scope and limits

A code is one instrument in [[Supply Chain Governance]] and is usually backed by audits, as with [[SA8000]]. It is also what the law may require a company to describe: see [[Supply Chain Due Diligence Instrument]]. The sources do not say how often suppliers comply, nor whether codes change conditions; the Global Compact guide is a 2010 publication, and the RBA says its code is updated every five years.

[^1]: United Nations Global Compact and Business for Social Responsibility, 2010, “Supply Chain Sustainability: A Practical Guide for Continuous Improvement”. https://www.bsr.org/reports/BSR_UNGC_SupplyChainReport.pdf
[^2]: Responsible Business Alliance, Code of Conduct. https://www.responsiblebusiness.org/code-of-conduct/
[^3]: Ethical Trading Initiative, “ETI Base Code”. https://www.ethicaltrade.org/eti-base-code

