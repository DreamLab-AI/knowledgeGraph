Friendshoring is the practice of locating supply chains in, or sourcing from, countries regarded as allies or trusted partners.[^1][^2]

The US Treasury Secretary, Janet L. Yellen, used the phrase in a speech at the Atlantic Council on 13 April 2022. She called for “friend-shoring” of supply chains to a large number of trusted countries so that market access could continue to be extended securely, and said this would lower the risks to the US economy and to its trusted trade partners.[^1] She set it within a call to build on and deepen economic integration with the countries the US knows it can count on.[^1] She gave the reason that countries should not be able to use their market position in key raw materials, technologies or products to disrupt the US economy or exercise “unwanted geopolitical leverage”.[^1] The speech states a policy preference and does not define the term.[^1]

The OECD describes friend-shoring as trading with allies or like-minded countries, one of three options for geographic de-risking alongside near-shoring and re-shoring.[^2]

## Scope and distinctions

The OECD lists friend-shoring, near-shoring and re-shoring as separate options.[^2] Friendshoring is defined by alignment with other states, whereas [[Nearshoring]] is defined by closeness and [[Reshoring]] by return to the home country.[^2][^3] See [[Supply Chain Configuration Decision]], [[Geopolitics]] and [[Supply Chain Resilience]].

## What the sources do not establish

Benson and Kapstein of the CSIS question whether the policy is a panacea, noting that even military allies can be fierce economic competitors and that the US depends on Taiwan, certainly a friend, for semiconductor chips.[^4] No source opened here defines how trust is judged or measures the effect of friendshoring on supply chain risk.[^1][^2][^4]

[^1]: US Department of the Treasury (Janet L. Yellen), press release, “Remarks by Secretary of the Treasury Janet L. Yellen on Way Forward for the Global Economy”. https://home.treasury.gov/news/press-releases/jy0714
[^2]: OECD, report on supply chain resilience, “Promoting resilience and preparedness in supply chains”. https://www.oecd.org/content/dam/oecd/en/publications/reports/2024/11/promoting-resilience-and-preparedness-in-supply-chains_c0320739/be692d01-en.pdf
[^3]: N. M. Pylypenko and T. V. Herasymenko, Economics Bulletin (Dnipro University of Technology), 2022, “Reasons and dynamics of reshoring in the European Union and USA”. https://ev.nmu.org.ua/docs/2022/4/EV20224_034-041.pdf
[^4]: Center for Strategic and International Studies (Emily Benson and Ethan B. Kapstein), “The Limits of “Friend-Shoring””. https://www.csis.org/analysis/limits-friend-shoring

