Work-in-progress inventory is the stock of semi-finished or not completely finished items found in the middle of assembly lines and manufacturing facilities.[^1]

An open operations text uses the term work in process, or WIP, for those items.[^1] An open managerial accounting text, writing about a job order cost system, says the balance in the work in process inventory account is continually updated as job costs are recorded and is the total of all unfinished jobs. It adds that as goods are produced, additional jobs are being started and finished, so the account includes the unit costs of jobs still in production at the end of the accounting period.[^2]

## Position in the flow

Georgia Tech class notes describe work in process as internal to the organisation, between incoming raw materials and outgoing finished goods.[^3] The accounting text describes the production cycle as continuous, beginning with raw materials being transferred to work in process and ending as finished goods inventory.[^2] It says that work in process involves one or more production departments and is where labour and overhead convert the raw materials into finished goods.[^4]

## Scope and distinctions

Work-in-progress inventory is one of the stage types listed at [[Inventory Type]], between [[Raw Materials Inventory]] and [[Finished Goods Inventory]]. The aliases used in this corpus, WIP inventory and work in process, are the wording the operations and accounting texts use.[^1][^2]

Accounting text measures the stock by cost of unfinished jobs, and operations text describes the physical items. Neither says how WIP is measured in a continuous process.

## What the sources do not establish

None of the sources opened here says how much WIP a system should carry. See [[Production Planning and Control]].

[^1]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.1: Types of Inventory”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.01%3A_Types_of_Inventory
[^2]: OpenStax (Rice University), Principles of Accounting, Volume 2: Managerial Accounting, “4.3 Use the Job Order Costing Method to Trace the Flow of Product Costs through the Inventory Accounts”. https://openstax.org/books/principles-managerial-accounting/pages/4-3-use-the-job-order-costing-method-to-trace-the-flow-of-product-costs-through-the-inventory-accounts
[^3]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf
[^4]: OpenStax (Rice University), Principles of Accounting, Volume 2: Managerial Accounting, “4.2 Describe and Identify the Three Major Components of Product Costs under Job Order Costing”. https://openstax.org/books/principles-managerial-accounting/pages/4-2-describe-and-identify-the-three-major-components-of-product-costs-under-job-order-costing

