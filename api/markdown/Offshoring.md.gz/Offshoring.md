Offshoring is the movement of business activities, or the purchase of goods and services, to a location in another country.[^1][^2]

Sources define it in two ways. The OECD wording, as quoted by the UN Economic and Social Commission for Western Asia, defines offshoring as companies' purchases of intermediate goods and services from foreign providers at arm's length, or the transfer of particular tasks within the firm to a foreign location, that is to foreign affiliates.[^1] Pylypenko and Herasymenko define it as the transfer of part or all of the value-added activities of a transnational company from its home country to another, with the company keeping ownership; they distinguish it from offshore outsourcing, which is purchasing from another firm overseas.[^2] The first usage includes arm's-length purchasing and the second excludes it.[^1][^2]

Eurostat does not define offshoring but defines international sourcing as sourcing to affiliated or non-affiliated enterprises located abroad. It excludes the movement of functions abroad without a reduction of activity or jobs in the enterprise concerned, for example a new production line set up abroad without reductions, and says international sourcing is sometimes called off-shoring.[^3] A European Parliament study uses the phrase “offshored/outsourced production” when discussing what could return to Europe.[^4]

## Scope and distinctions

Eurofound defines [[Reshoring]] as the relocation of previously offshored activities to an EU destination, so reshoring is defined in relation to offshoring.[^5] Eurostat lists off-shoring and near-shoring together as names sometimes given to international sourcing; see [[Nearshoring]].[^3] See [[Outsourcing]] and [[Supply Chain Configuration Decision]].

## What the sources do not establish

Sources do not agree on whether the word covers arm's-length purchasing, and none gives a distance beyond which a move counts as offshoring.[^1][^2][^3]

[^1]: United Nations Economic and Social Commission for Western Asia, sustainable development glossary (finance domain, citing the OECD), “Offshoring”. https://www.unescwa.org/sd-glossary/offshoring
[^2]: N. M. Pylypenko and T. V. Herasymenko, Economics Bulletin (Dnipro University of Technology), 2022, “Reasons and dynamics of reshoring in the European Union and USA”. https://ev.nmu.org.ua/docs/2022/4/EV20224_034-041.pdf
[^3]: Eurostat, Statistics Explained glossary entry, “Glossary:Sourcing”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Sourcing
[^4]: European Parliament, Policy Department for External Policies (study requested by the INTA committee), “Post Covid-19 value chains: options for reshoring production back to Europe in a globalised economy”. https://www.europarl.europa.eu/RegData/etudes/STUD/2021/653626/EXPO_STU(2021)653626_EN.pdf
[^5]: Eurofound, European Restructuring Monitor, “Reshoring”. https://apps.eurofound.europa.eu/restructuring-events/types/Reshoring

