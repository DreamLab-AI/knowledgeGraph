Supply chain optimisation is the use of mathematical optimisation to find the best supply chain configuration and plans, so that operations run efficiently.[^1][^2][^3]

Melo, Nickel and Saldanha da Gama write that part of supply chain management planning aims at finding the best possible supply chain configuration so that all operations can be performed efficiently, with facility location considered together with procurement, production, inventory, distribution and routing.[^1] Their review also covers supply chain performance measures and optimisation methods for solving facility location problems in a supply chain context.[^1] Jatta says optimisation of the complete supply chain is accomplished through efficient planning decisions, and gives location of facilities, chain topology and vendor selection as strategic examples.[^2]

An open operations management textbook defines linear programming as a fundamental mathematical optimisation technique to determine the best outcome, such as maximising profit or minimising cost, subject to linear constraints, and lists production planning and scheduling, transportation and logistics, and network flow optimisation among its applications.[^3] It says a linear programming problem has an objective function, decision variables and constraints, including non-negativity constraints.[^3] See [[Linear Programming]] and [[Operations Research]].

## Scope and distinctions

Kleijnen notes that, in supply chain simulation, a robustness analysis can optimise the important factors controllable by management while accounting for noise from non-controllable environmental factors.[^4] See [[Supply Chain Simulation]], [[Supply Chain Planning]] and [[Stochastic Optimisation]].

## What the sources do not establish

An earlier body of this page claimed that machine learning, reinforcement learning, predictive analytics and digital twins are increasingly used in optimisation. No opened source supports those claims, so they have been removed rather than restated.[^1][^2][^3]

[^1]: Fraunhofer ITWM (Melo, Nickel and Saldanha da Gama), report version of a review of facility location and supply chain management, “Facility Location and Supply Chain Management - A comprehensive review”. https://kluedo.ub.rptu.de/files/1985/bericht130.pdf
[^2]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content
[^3]: Operations Management open textbook, eCampusOntario Pressbooks, section 12.1, “Optimizing Resources for Business Efficiency”. https://ecampusontario.pressbooks.pub/opsmgmt/chapter/12-1-optimizing-resources-for-business-efficiency/
[^4]: J. P. C. Kleijnen, Tilburg University CentER Discussion Paper 2003-103 (research portal record with abstract), “Supply Chain Simulation: A Survey”. https://research.tilburguniversity.edu/en/publications/supply-chain-simulation-a-survey/

