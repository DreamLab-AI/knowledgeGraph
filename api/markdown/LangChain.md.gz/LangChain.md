LangChain is an open-source Python and TypeScript framework for composing Large Language Model applications as chains of modular components — prompt templates, LLM wrappers, output parsers, memory stores, retrieval augmented generation pipelines, and tool-calling agents — providing a unified ...

### Semantic Classification

### Content

LangChain was created by Harrison Chase and launched in October 2022, arriving precisely as the developer community was discovering that building useful LLM applications required more than a single API call. The first wave of use cases — document Q&A, code assistants, chatbots with context — all shared a common pattern: retrieve relevant context, inject it into a prompt, call the LLM, parse the output. LangChain codified this pattern into the Chain abstraction and provided composable building blocks (document loaders, text splitters, embedding models, vector stores, prompt templates) that could be wired together in Python. Its popularity grew rapidly, reaching 70,000 GitHub stars within six months.

#### Key Characteristics

- **LCEL (LangChain Expression Language)**: A declarative composition syntax using pipe operators (`|`) that chains components and handles streaming, async, and batch execution uniformly. `chain = prompt | llm | parser` expresses a full RAG pipeline in one line.
- **Runnable Interface**: All LangChain components implement a common `Runnable` interface with `invoke`, `stream`, `batch`, and `ainvoke` methods, making components interchangeable and enabling parallel composition.
- **Multi-Provider LLM Abstraction**: `ChatOpenAI`, `ChatAnthropic`, `ChatOllama`, and 50+ other integrations implement a common `BaseChatModel` interface, allowing applications to swap model providers without code changes.
- **Retrieval Augmented Generation (RAG)**: LangChain's retriever interface connects to vector databases (Chroma, FAISS, Pinecone, Weaviate), enabling semantic search over private document corpora. Document loaders ingest PDFs, web pages, Notion, Confluence, GitHub repositories, and more.
- **LangGraph**: An extension for stateful, graph-structured agent workflows. Unlike linear chains, LangGraph models agent state as nodes in a directed (or cyclic) graph, enabling loops (retry logic, self-reflection), branching, and parallel tool execution. It is the recommended pattern for production multi-step agents.
- **LangSmith**: An observability platform that traces every LLM call, tool invocation, and chain step, enabling debugging, evaluation, and dataset curation. Critical for production systems where prompt drift and hallucination rates must be monitored.

  #### How It Works

  A LangChain RAG pipeline begins by ingesting source documents (PDFs, web pages) through document loaders, splitting them into chunks (RecursiveCharacterTextSplitter), embedding each chunk with an embedding model (OpenAI `text-embedding-3-small`, or a local `sentence-transformers` model), and storing the embeddings in a vector store (Chroma, FAISS). At query time, the user's question is embedded and used for cosine similarity search; the top-k most relevant chunks are retrieved. A prompt template assembles the retrieved chunks and the question into a context-enriched prompt, which is sent to the LLM. The LLM's response is returned to the user.

  For agentic workflows, LangGraph models the agent as a state machine: the `call_model` node invokes the LLM with the current state (messages, retrieved context, tool results); the `tools` node executes whichever tools the LLM requested (web search, calculator, database query, [[Model Context Protocol]] tool call); edges route back to `call_model` until the LLM emits a final answer without requesting more tools. The state graph can be persisted (using Redis, PostgreSQL, or SQLite via LangGraph checkpointers), enabling long-running agents that survive restarts.

  #### Current Landscape

  LangChain 0.3 (released 2024) stabilised the LCEL interface and promoted LangGraph to the canonical agent pattern, deprecating the earlier `AgentExecutor` class. The ecosystem has matured considerably: LangSmith is used in production by over 5,000 organisations for LLM observability. Competition has emerged from alternatives (LlamaIndex for RAG, CrewAI for multi-agent, AutoGen from Microsoft), but LangChain remains the most comprehensive framework. The 2025 integration of [[Model Context Protocol]] into LangChain's tool interface — `langchain_mcp` package — is significant for [[VisionClaw Agentic Container]]: LangChain agents can now consume any MCP server's tools without per-server integration code, unifying the tool surfaces of both frameworks.

  #### Cross-Domain Applications

  In the [[Robotics Domain]], LangChain agents command [[Robot Operating System]] actions via MCP bridge servers, enabling natural-language robot task planning. In the [[NGM Domain]], [[Solid Pod]] MCP servers expose personal data as LangChain retrievers, enabling privacy-preserving personalisation. In the [[Blockchain Domain]], LangChain agents can query on-chain data and generate verifiable credential presentations via MCP tools. In the [[Metaverse Domain]], LangChain agents act as non-player character (NPC) controllers, maintaining conversational memory and spatial context within [[OpenXR]] virtual environments.

  #### Standards and References

- Chase, H. (2022). *LangChain GitHub Repository*. https://github.com/langchain-ai/langchain
- LangChain AI. (2024). *LangChain Expression Language (LCEL) Documentation*. https://python.langchain.com/docs/expression_language/
- LangChain AI. (2024). *LangGraph Documentation*. https://langchain-ai.github.io/langgraph/
- Lewis, P., et al. (2020). "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks." *NeurIPS 2020*.
- Yao, S., et al. (2023). "ReAct: Synergising Reasoning and Acting in Language Models." *ICLR 2023*.

### Provenance

