A batch number, also called a lot number, is a distinctive code that identifies a batch or lot of a product, from which the history of how that quantity was made and handled can be traced.[^1][^2]

The US Food and Drug Administration rule at 21 CFR 210.3 defines a batch as a specific quantity of a drug or other material intended to have uniform character and quality, produced according to a single manufacturing order during the same cycle of manufacture.[^1] A lot is a batch, or a specific identified portion of a batch, having uniform character and quality.[^1] A lot number, control number or batch number is any distinctive combination of letters, numbers or symbols from which the complete history of the manufacture, processing, packing, holding and distribution of a batch or lot can be determined.[^1]

Directive 2011/91/EU applies a similar idea to food. It defines a lot as a batch of sales units of a foodstuff produced, manufactured or packaged under practically the same conditions, and says the lot is determined by the producer, manufacturer or packager, or the first seller established within the Union.[^2] Its recitals say that indicating the lot is a useful source of information when foodstuffs are the subject of dispute or constitute a health hazard for consumers.[^2]

## In the GS1 system

GS1 carries the number in Application Identifier (10). The number associates an item with information that the manufacturer considers relevant for traceability, and it may be, for example, a production lot number, a shift number, a machine number, a time or an internal production code.[^3] The General Specifications add that the batch or lot number is not part of the unique identification of a trade item, and that brand owner and manufacturer are responsible for non-duplication of batch or lot numbers for a GTIN where a product is made in different places.[^3] See [[Global Trade Item Number]].

## Related uses

The US Food Traceability Rule uses a traceability lot code, a descriptor, often alphanumeric, that uniquely identifies a traceability lot within the records of the firm that assigned it.[^4] The EU rules for medicines include the batch number among the data elements of the unique identifier on a pack.[^5] See [[Product Serialisation]] and [[Traceability Regulation]].

## What the sources do not establish

The EU directive defines the lot, not the batch, and the US rule defines a lot as a batch or a specific identified portion of one. The sources cover drugs, food and the GS1 system, not other industries, and they do not settle one format for a batch number.[^1][^2][^3]

[^1]: US Food and Drug Administration, 21 CFR 210.3, “Definitions” (electronic Code of Federal Regulations). https://www.ecfr.gov/api/renderer/v1/content/enhanced/current/title-21?part=210&section=210.3
[^2]: European Parliament and Council, “Directive 2011/91/EU of the European Parliament and of the Council of 13 December 2011 on indications or marks identifying the lot to which a foodstuff belongs (codification)”, legislation.gov.uk copy. https://www.legislation.gov.uk/eudr/2011/91/data.htm?view=plain
[^3]: GS1, “GS1 General Specifications Standard”, release 26.0. https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf
[^4]: US Food and Drug Administration, “FSMA Final Rule on Requirements for Additional Traceability Records for Certain Foods”. https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-requirements-additional-traceability-records-certain-foods
[^5]: European Commission, “Commission Delegated Regulation (EU) 2016/161 of 2 October 2015 supplementing Directive 2001/83/EC of the European Parliament and of the Council by laying down detailed rules for the safety features appearing on the packaging of medicinal products for human use”, legislation.gov.uk copy. https://www.legislation.gov.uk/eur/2016/161/adopted/data.htm

