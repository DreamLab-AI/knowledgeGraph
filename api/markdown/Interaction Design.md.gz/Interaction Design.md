Interaction design (IxD) is the practice of defining and shaping the dynamic behaviour of interactive systems — determining how they respond to user inputs, communicate state and feedback, and guide users through task sequences — with the goal of creating products that are usable, efficient, and satisfying across diverse contexts. It encompasses the design of interaction flows, affordances, timing, error recovery patterns, and multi-modal input modalities across digital, physical, spatial, and conversational interfaces. Interaction design is distinguished from visual design by its focus on behaviour over time rather than static composition, and from software engineering by its concern for the human experience of system use rather than technical implementation. As interactive surfaces expand into AR, VR, voice, and AI-mediated interfaces, the field continuously develops new design vocabularies, prototyping methods, and evaluation heuristics to address emergent interaction paradigms.

### Overview

- **Historical origins** — Interaction design as a named discipline emerged from the convergence of industrial design, cognitive psychology, and software engineering in the late 1980s.
  - Bill Moggridge and Bill Verplank coined the term "interaction design" to distinguish the design of software behaviour from hardware form and graphic composition.
  - Intellectual foundations include J.J. Gibson's ecological theory of affordances (1979), which established that perceived action possibilities emerge from the relationship between an artefact and its user.
  - Don Norman's "The Design of Everyday Things" (1988) applied affordance theory to everyday objects and digital interfaces, introducing the vocabulary of mapping, constraint, and feedback.
  - Xerox PARC's research into direct manipulation interfaces, WYSIWYG editing, and gestural input during the 1970s–1980s provided the first systematic exploration of interactive software behaviour.
  - The term was formalised through Moggridge's founding of IDEO and the publication of "Designing Interactions" (2007), which documented the discipline's canonical history through practitioner interviews.
- **Scope and boundaries** — interaction design occupies a specific layer within the broader [[User Experience Design]] stack.
  - It focuses on behaviour over time: sequences of actions, state transitions, feedback loops, and error recovery — rather than visual composition or content strategy.
  - It is distinguished from [[Information Architecture]] (structural organisation of content) by its emphasis on dynamic behaviour rather than static hierarchy.
  - It is distinguished from visual or graphic design by its concern for system responsiveness and temporal dynamics rather than aesthetic composition.
  - It is distinguished from software engineering by its focus on the human experience of interaction rather than the computational mechanism.
  - In practice, interaction designers work between user researchers (who surface needs) and visual designers and engineers (who realise solutions).
- **Why it matters** — poor interaction design creates friction, cognitive overload, and error that reduce productivity, erode user trust, and drive product abandonment.
  - The cost of fixing interaction design failures in shipped software is substantially higher than catching them during iterative design and prototyping phases.
  - Safety-critical systems (medical devices, aviation interfaces, automotive controls) rely on structured [[Interaction Design]] processes mandated by regulation to prevent human error with potentially fatal consequences.
  - As digital products become the primary channel for government services, financial products, healthcare, and education, interaction design quality directly shapes equity of access and outcomes.
- **Scale of the discipline** — interaction design is practised globally across consumer technology, enterprise software, healthcare, automotive, and public sector domains.
  - The Interaction Design Association (IxDA) has tens of thousands of members across more than 100 countries.
  - Undergraduate and graduate programmes in interaction design exist at major design and technical universities worldwide (Carnegie Mellon, RCA, TU Delft, MIT Media Lab).

### Key Components

- **[[Affordance]]** — perceptual signals embedded in interface elements that communicate what actions they support (clickability, draggability, editability, swipeability).
  - Derived from Gibson's ecological psychology and operationalised for UI design by Don Norman.
  - Distinguishes perceived affordances (what the user believes is possible) from actual affordances (what the system actually supports) — misalignment between the two is a primary source of interaction error.
  - In digital interfaces, affordances are necessarily signified rather than physical: visual styling, iconography, cursor changes, and motion cues serve as signifiers of available actions.
- **[[Feedback Mechanism]]** — system responses that confirm user actions have been registered, communicate progress, and signal state changes.
  - Encompasses visual (animation, colour change, progress bars), auditory (notification sounds, voice confirmation), haptic (vibration patterns on mobile), and temporal (latency, response time) feedback modalities.
  - Absence of feedback is a leading cause of user error and repeated input: users who receive no confirmation of an action often repeat it, creating duplicate submissions or unintended state changes.
  - Feedback design must account for the latency budget: human perception of causality requires response within approximately 100ms for actions to feel instantaneous.
- **[[Interaction Flow]]** — the structured sequence of states and transitions a user moves through to accomplish a task goal.
  - Represented as state diagrams, task flows, [[User Journey]] maps, or screen-to-screen flow diagrams during the design phase.
  - Happy path flows must be complemented with exception paths: error states, empty states, loading states, and edge cases that represent the full behavioural surface of a system.
  - Flow design directly determines learnability: systems with consistent, predictable flow patterns are learned faster and retained longer.
- **[[Mental Model]]** — the user's internal representation of how a system works, formed from prior experience with analogous systems and signals from the current interface.
  - Interaction design aligns the interface's presented conceptual model with users' existing mental models to reduce learning cost and error.
  - Mental model mismatches are a primary cause of novice user difficulty: when the system behaves unexpectedly relative to the user's model, error and frustration follow.
  - Mental models are domain-specific and vary across user populations — a design that aligns with expert mental models may confuse novices and vice versa.
- **Constraints** — design elements that limit the set of possible actions at a given moment, preventing errors and guiding users toward correct interaction paths.
  - Physical constraints (greyed-out controls, disabled fields), logical constraints (form validation, step gating), semantic constraints (contextual availability of actions), and cultural constraints (convention-driven expectations).
  - Constraints encode domain rules and workflow logic into the interaction surface, reducing the cognitive burden on users to remember what is valid.
- **Mapping** — the spatial or conceptual relationship between controls and the effects they produce.
  - Natural mapping exploits users' existing spatial and causal expectations (e.g., up/down arrows increasing/decreasing a value, spatially arranged controls corresponding to spatially arranged outputs).
  - Poor mapping forces users to learn arbitrary control-effect associations, increasing cognitive load and error rate.
- **[[Error Recovery]]** — mechanisms that detect, report, and allow recovery from user errors, minimising the cost of mistakes.
  - Includes undo/redo systems, confirmation dialogs before irreversible actions, inline validation that catches errors before submission, and graceful degradation when systems are in unexpected states.
  - Design for error recovery acknowledges that errors are inevitable: the goal is to make errors detectable, understandable, and reversible rather than to prevent all error through constraint alone.
- **Timing and animation** — temporal properties of transitions, loading states, and response latency that communicate system responsiveness and guide attention between states.
  - Governed by principles from motion design, film editing, and perception psychology: easing curves, transition durations, and spatial continuity all affect perceived quality and comprehensibility.
  - Excessive animation impairs performance perception; insufficient animation creates jarring state changes that disrupt user orientation within a flow.
- **[[Wireframing]] and [[Prototyping]]** — design artefacts that externalise interaction concepts for review, testing, and handoff before engineering investment is committed.
  - Low-fidelity: paper sketches, digital wireframes (Balsamiq, Figma low-fi) — rapid, cheap, good for structural exploration.
  - High-fidelity: interactive prototypes (Figma, ProtoPie, Framer, coded React prototypes) — realistic enough to support [[Usability Testing]] with representative users.
  - Prototyping fidelity should match the evaluation question: structural questions need low fidelity; detailed interaction questions require high fidelity.

### Mechanisms and Methods

- **[[User Research]]** — the empirical foundation of interaction design practice, providing evidence about user goals, tasks, environmental constraints, and [[Mental Model]] structures.
  - Generative methods (ethnographic observation, contextual inquiry, diary studies, interviews) surface unmet needs and establish the design problem space.
  - Evaluative methods ([[Usability Testing]], A/B testing, remote unmoderated testing) validate design solutions against user behaviour.
  - Continuous discovery models integrate user research into product development cycles rather than confining it to project initiation phases.
- **[[Task Analysis]]** — systematic decomposition of user goals into the sub-tasks, decisions, and actions required to achieve them.
  - Hierarchical task analysis (HTA) produces a tree structure of goal-task-action relationships, revealing which steps require the most design attention.
  - Cognitive task analysis (CTA) — particularly the Critical Decision Method — surfaces the decision-making and knowledge structures underlying expert performance, essential for designing complex professional tools.
  - [[Task Analysis]] outputs directly inform [[Interaction Flow]] design: each task node maps to a corresponding interface state.
- **Interaction modelling** — the construction of formal or semi-formal representations of intended system behaviour.
  - State-transition diagrams represent all possible system states and the events that trigger transitions between them — essential for ensuring completeness of behavioural coverage.
  - Sequence diagrams and [[User Journey]] maps represent the temporal experience of a specific user navigating a specific task.
  - Scenario-based design (Carroll, 1995) uses narrative scenarios to ground interaction models in realistic use contexts.
- **[[Usability Testing]]** — structured evaluation sessions in which representative users attempt realistic tasks with a prototype or live system under observation.
  - Think-aloud protocol: users verbalise their reasoning as they interact, surfacing [[Mental Model]] assumptions and points of confusion.
  - Moderated (researcher present and able to probe) vs. unmoderated (remote, asynchronous, scalable) formats serve different evaluation needs.
  - Formative testing (during design) identifies problems to fix; summative testing (post-launch) benchmarks performance against standards or competitors.
- **Heuristic evaluation** — expert review of an interface against established usability principles to identify violations without requiring user participants.
  - Nielsen's 10 usability heuristics (visibility of system status, match between system and real world, user control and freedom, consistency and standards, error prevention, recognition over recall, flexibility and efficiency, aesthetic and minimalist design, help users recognise/diagnose/recover from errors, help and documentation).
  - Shneiderman's 8 golden rules of interface design provide a complementary set of principles for form-based and menu-driven systems.
  - Expert reviews are fast and inexpensive but miss user-population-specific issues that only emerge in testing with actual users.
- **Cognitive walkthrough** — structured expert analysis that walks through a task step-by-step, asking at each step whether users will know what to do, whether they will notice the correct action, whether they will understand the [[Feedback Mechanism]], and whether they can interpret progress toward their goal.
- **Eye-tracking and biometric studies** — instrumented evaluation methods capturing attention patterns, fixation duration, and physiological arousal.
  - Eye-tracking reveals which interface elements attract attention, which are missed, and how reading patterns vary by user expertise.
  - Electrodermal activity (EDA) and heart rate variability (HRV) can quantify cognitive load and stress — useful for safety-critical interaction design evaluation.
- **[[Design System]] integration** — the codification of interaction design decisions into reusable component libraries with documented behavioural specifications.
  - Interaction patterns (modal dialogs, date pickers, data tables, form validation) are specified once in the [[Design System]] and instantiated consistently across products.
  - Design tokens encode spacing, timing, and motion values that maintain behavioural consistency without requiring per-component specification.
  - Handoff documentation bridges interaction design specifications to engineering implementation, reducing interpretation gaps.

### Applications and Use Cases

- **Web and mobile applications** — the primary commercial domain of interaction design practice.
  - E-commerce checkout flows, social media feed interactions, form design, navigation patterns, and onboarding sequences are canonical interaction design problems.
  - Platform guidelines (Apple Human Interface Guidelines, Google Material Design 3, Microsoft Fluent Design System) codify platform-specific interaction conventions, creating shared expectations across applications on each platform.
  - Mobile-specific constraints — touch targets, thumb reachability zones, variable connectivity, interruption patterns — require adaptation of desktop interaction models rather than simple translation.
- **Enterprise and professional software** — complex multi-role workflows where interaction design must balance power-user efficiency with discoverability for occasional users.
  - ERP systems (SAP, Oracle), CRM platforms (Salesforce), analytics dashboards (Tableau, Looker), and developer tools (VS Code, Jira) represent the scale and complexity of enterprise interaction design.
  - Command palette patterns, keyboard shortcut systems, and progressive disclosure mechanisms allow expert users to accelerate without confusing novices.
  - Role-based interaction design addresses the fact that different user roles have different task frequencies, expertise levels, and decision-making contexts within the same system.
- **[[Conversational Interface]] and [[Natural Language Interface]]** — a rapidly expanding subfield driven by LLM-powered chatbots and voice assistants.
  - Key design challenges: communicating system uncertainty (confidence levels, hedging language), managing off-topic or ambiguous inputs, designing prompt guidance that helps users formulate effective queries, and supporting multi-turn conversation repair.
  - Intent resolution design: when user intent is ambiguous, how should the system disambiguate — by asking clarifying questions, by attempting the most probable interpretation, or by presenting alternatives?
  - Failure mode design: graceful handling of hallucination risk, refusal responses, and capability boundary communication are interaction design problems with no prior screen-UI equivalent.
- **[[Spatial User Interface]] and [[Multimodal Interaction]]** — interaction design for AR/VR and mixed-reality environments.
  - AR headsets (HoloLens 2, Apple Vision Pro, Meta Quest 3) introduce gaze-based selection, hand-tracking, pinch gestures, spatial anchoring, and the integration of virtual elements with physical environments.
  - Key constraints: field of view limitations, depth perception for 3D selection, fatigue from sustained gestural input, and the need to avoid occluding important real-world elements with virtual UI.
  - No established design canon: the field is actively developing heuristics for spatial interaction through conference research (IEEE VR, ACM CHI, ISMAR) and practitioner experimentation.
- **Automotive and embedded systems** — safety-critical interaction design under strict attentional constraints.
  - ADAS (advanced driver assistance system) interfaces must communicate system state (lane keeping, adaptive cruise, collision warnings) without demanding sustained driver attention.
  - NHTSA and UNECE regulations constrain glance duration and head-down time, imposing hard limits on [[Interaction Flow]] complexity for in-vehicle tasks.
  - Multimodal redundancy (visual + auditory + haptic) is a design requirement for safety-critical state communication.
- **Medical devices and clinical software** — interaction design under regulatory mandate.
  - IEC 62366-1 (usability engineering for medical devices) requires documented use specification, task analysis, formative and summative evaluation — a structured [[Interaction Design]] process traceable to safety evidence.
  - Clinical decision support interfaces must communicate uncertainty and evidence quality without creating alert fatigue that causes clinicians to ignore important warnings.
  - Electronic health record (EHR) systems (Epic, Cerner) have become major contexts for interaction design research, given documented links between poor EHR [[Usability]] and clinician burnout.
- **AI-augmented design tooling** — generative models applied to interaction design workflows.
  - Tools such as Figma AI, Adobe Firefly, Galileo AI, and Uizard use generative models to propose interface layouts, generate component variants, and conduct automated [[Accessibility]] audits.
  - Automated [[Usability Testing]] simulation — AI agents that navigate interfaces and report usability issues — is an emerging area that may compress the evaluation cycle.
  - The role of the interaction designer shifts toward design direction, evaluation curation, and ethical oversight rather than component-level generation.
- **Physical and tangible interaction** — interaction design at the boundary of digital and physical.
  - Tangible user interfaces (TUI) — physical objects that control digital systems — require interaction design that bridges physical manipulation affordances with digital state and feedback.
  - IoT device controls (smart home, industrial sensors) require interaction design for devices with constrained displays, limited input modalities, and intermittent connectivity.
  - Interactive installations and museum exhibits require interaction design for walk-up-and-use contexts with no prior training, extremely varied user populations, and degraded attentional contexts.

### Cognitive and Theoretical Foundations

- **Ecological psychology (Gibson, 1979)** — the theory that perception is action-oriented: organisms perceive environments in terms of the actions they afford. Applied to interaction design as the [[Affordance]] concept.
- **Activity theory (Vygotsky, Leont'ev, Engeström)** — frames human activity in terms of goals, actions, operations, and the tools and community context that mediate them. Provides a framework for analysing complex work practices that interaction design must support.
- **Distributed cognition (Hutchins, 1995)** — argues that cognitive processes are distributed across individuals, artefacts, and environments rather than residing solely in individual minds. Grounds the design of shared workspaces, dashboards, and collaborative tools.
- **Fitts' Law** — a mathematical model predicting the time to acquire a UI target as a function of target size and distance. Foundational for touch target sizing guidelines, toolbar layout, and pointing device design.
- **Hick's Law** — the time to make a decision increases logarithmically with the number of choices. Motivates progressive disclosure, contextual menus, and the reduction of concurrent options in [[Interaction Flow]] design.
- **Miller's Law (7±2)** — working memory capacity is approximately 7 items. Motivates chunking of information and the grouping of related controls in interface design.
- **Gestalt principles** — perceptual organisation principles (proximity, similarity, continuity, closure) that determine how users group interface elements into meaningful structures. Directly applied in visual [[Information Architecture]] and layout.
- **Dual-process theory (Kahneman)** — the distinction between fast, automatic System 1 processing and slow, deliberate System 2 processing. Interaction design exploits System 1 for habitual interactions and scaffolds System 2 for novel or consequential decisions.

### Standards and Context

- **ISO 9241** — foundational international standard family for ergonomics of human-system interaction.
  - Part 11: usability definitions and framework.
  - Part 110: dialogue principles (suitability for task, self-descriptiveness, conformity with user expectations, learnability, controllability, error tolerance, suitability for personalisation).
  - Part 171: guidance on software [[Accessibility]].
  - Part 210: "Human-centred design for interactive systems" (formerly ISO 13407) — the primary process standard for interaction design, defining the iterative lifecycle of user research, requirements specification, design, and evaluation.
- **IEC 62366-1:2015** — usability engineering process standard for medical devices, mandating structured interaction design and evaluation activities traceable to patient safety evidence.
- **WCAG 2.2** — Web Content [[Accessibility]] Guidelines, W3C Recommendation (October 2023), defining testable success criteria for accessible interaction behaviour across four principles: Perceivable, Operable, Understandable, Robust.
- **WCAG 3.0** — next-generation accessibility guidelines in development at W3C/WAI, introducing an outcome-based scoring model rather than binary pass/fail criteria.
- **ETSI EN 301 549** — European [[Accessibility]] standard for ICT products and services, harmonising WCAG criteria with EU procurement law and the European Accessibility Act.
- **Section 508 (US)** — US federal accessibility standard requiring that electronic and information technology procured or developed by the US government be accessible, referencing WCAG 2.0 Level AA criteria.
- **Apple Human Interface Guidelines** — platform interaction standards for iOS, iPadOS, macOS, watchOS, tvOS, and visionOS (spatial computing). De facto standards for respective ecosystems.
- **Google Material Design 3** — design system and interaction specification for Android and web, defining component behaviour, motion principles, and adaptive layout patterns.
- **Microsoft Fluent Design System** — interaction and visual design system for Windows and cross-platform Microsoft products.
- **IDEO Human-Centred Design methodology** — design thinking process framework widely used to situate interaction design within broader innovation and service design practice.
- **Design Council Double Diamond** — UK design process framework (Discover, Define, Develop, Deliver) that provides a shared vocabulary for interaction design within multidisciplinary product teams.
- **Interaction Design Association (IxDA)** — primary professional body for the discipline, organising the annual Interaction conference and maintaining the global practitioner community.
- **ACM CHI (Conference on Human Factors in Computing Systems)** — the premier academic venue for interaction design and HCI research, publishing the canonical research literature for the field.
- **Nielsen Norman Group** — research and consultancy organisation that has produced the most widely cited practitioner-facing heuristics, guidelines, and empirical studies in interaction design, including the formative work on usability heuristics, web usability, and mental models.

### Provenance

