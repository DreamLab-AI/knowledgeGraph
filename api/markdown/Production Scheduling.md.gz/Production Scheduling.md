Production scheduling is the allocation of resources to tasks over time, producing a schedule that gives the start and completion time of each task and the times when resources process tasks across the planning horizon.[^1]

A review of operations and supply chain management uses that definition and says that in most cases scheduling is a short- to mid-term planning problem.[^1] A survey published through the National Institute of Standards and Technology quotes an older definition of scheduling as the art of assigning resources to tasks in order to insure the termination of these tasks in a reasonable amount of time.[^2]

## Job shop scheduling

University of Washington lecture slides define a job shop as a work location with a number of general purpose workstations used to perform a variety of jobs, and list four factors that describe a job shop scheduling problem: the arrival pattern, the number of machines, the work sequence and the performance evaluation criterion. They give makespan, the total time to process all jobs, as the most common criterion.[^3] See [[Job Shop Production]].

That survey says mathematical programming approaches have been limited because scheduling problems belong to the class of NP-complete problems, and that dispatching rules, procedures designed to provide good solutions to complex problems in real time, have been applied consistently. It adds that the terms dispatching rule, scheduling rule, sequencing rule and heuristic are often used synonymously.[^2]

## Tools

An open textbook describes a Gantt chart as a timeline.[^4]

## Scope and distinctions

Scheduling is part of [[Production Planning and Control]]. The review notes that scheduling is also done in services such as transportation and healthcare, not only in manufacturing.[^1] This page covers production scheduling in manufacturing; it does not cover vehicle routing or workforce rostering.

## What the sources do not establish

No source recommends a particular dispatching rule or solution method, and they do not show which performs best in practice. The opened copy of the NIST survey shows no publication date, so the page does not say how current its coverage is.

[^1]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: National Institute of Standards and Technology (Albert Jones) and California Polytechnic State University (Luis C. Rabelo), “Survey of Job Shop Scheduling Techniques”. https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=821200
[^3]: University of Washington, IE 337 lecture slides, “Job Shop Scheduling”. https://courses.washington.edu/ie337/Job%20Shop%20Scheduling.pdf
[^4]: Business LibreTexts (Introduction to Business, Lumen), “12.4: Production Planning”. https://biz.libretexts.org/Bookshelves/Business/Introductory_Business/Introduction_to_Business_(Lumen)/12:_Managing_Process/12.04:_Production_Planning

