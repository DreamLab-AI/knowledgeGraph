Scalability solutions are a family of techniques, architectures, and protocols designed to increase the throughput, reduce latency, and lower transaction costs of distributed systems—especially blockchain networks—without sacrificing security or decentralisation. They span both on-chain approaches (sharding, improved consensus algorithms, data availability sampling) and off-chain or layer-2 approaches (payment channels, rollups, sidechains) that defer computation or data storage away from the base layer. The discipline also extends beyond blockchains into general distributed-systems engineering, encompassing horizontal scaling, caching strategies, and peer-to-peer load distribution. Together these mechanisms address the fundamental tension between throughput, security, and decentralisation commonly formalised as the Blockchain Trilemma.

### Overview

- Early public blockchains such as [[Bitcoin]] and [[Ethereum]] demonstrated that decentralised, permissionless ledgers could work but exposed a critical limitation: base-layer throughput measured in tens of transactions per second compared unfavourably with centralised payment networks capable of tens of thousands.
- The root cause is structural: every full node must validate every transaction, so the cost of global consensus scales linearly with the number of validators, setting an upper bound on throughput that cannot be relieved simply by increasing block size without raising hardware requirements and thereby centralising the network.
- Scalability solutions decompose this bottleneck along several axes:
  - **Vertical scaling** — more powerful base-layer consensus (e.g. BFT-class algorithms, [[Proof of Stake]] replacing [[Proof of Work]]).
  - **Horizontal / on-chain sharding** — partitioning the validator set and state so that different shards handle different subsets of transactions simultaneously, with a coordination layer ensuring cross-shard consistency.
  - **Off-chain execution** — moving transaction computation off the main chain entirely, posting only commitments, fraud proofs, or validity proofs back to layer 1.
  - **Modular architecture** — separating the execution, settlement, consensus, and data availability layers into specialist components that can each be optimised independently (see [[Modular Blockchain]]).
- The combined effect of these strategies has enabled blockchain networks to serve high-volume applications in [[Decentralised Finance]], gaming, supply-chain tracking, and digital identity.

### Key Mechanisms

#### Layer 2 Scaling

- [[Layer 2 Scaling]] encompasses any protocol that operates on top of an existing layer-1 chain and inherits its security while performing computation off-chain.
- The two principal layer-2 patterns are [[Rollups]] and [[State Channels]].

#### Rollups

- [[Rollups]] batch many transactions off-chain and post a compressed summary plus proof to the base layer.
- [[Optimistic Rollups]] (e.g. Arbitrum, Optimism) assume transactions are valid by default and allow a fraud-proof challenge window; they are simpler to implement but introduce a withdrawal delay.
- [[ZK-Rollups]] (e.g. zkSync, Starknet, Polygon zkEVM) generate a cryptographic [[Zero-Knowledge Proofs|validity proof]] for every batch, enabling near-instant finality on layer 1 at the cost of higher prover computation.
- Both rollup types reduce base-layer data load and can increase effective throughput by one to two orders of magnitude over raw layer-1 capacity.

#### State Channels

- [[State Channels]] allow two or more parties to transact off-chain by locking funds in a multi-signature contract, exchanging signed state updates peer-to-peer, and settling only the final state on-chain.
- The [[Lightning Network]] on Bitcoin is the canonical state-channel network, enabling fast and low-cost micropayments.
- State channels are optimal for repeated interactions between fixed participant sets but require liveness assumptions and cannot easily support open participation or complex smart-contract logic.

#### Sharding

- [[Sharding]] partitions global network state across multiple parallel chains (shards), each validated by a distinct subset of nodes.
- Cross-shard communication requires careful protocol design to prevent double-spend attacks across shard boundaries.
- [[Data Availability Sampling]] (DAS) is a complementary technique allowing light clients to probabilistically verify that block data is available without downloading it in full, which is essential for sharded chains.

#### Sidechains

- [[Sidechains]] are independent blockchains with their own consensus that peg to a parent chain via a two-way bridge.
- They offer greater throughput and flexibility but do not inherit the security of the parent chain directly; their security depends on the sidechain's own validator set.
- Examples include Polygon PoS (as originally designed), Gnosis Chain, and various application-specific chains.

#### Modular Blockchain Architecture

- [[Modular Blockchain]] designs separate the four functions of a blockchain—execution, settlement, consensus, and data availability—into distinct specialist layers.
- Celestia provides a dedicated data availability layer; rollups run execution on top; Ethereum acts as a settlement layer. This composable stack allows each component to scale independently.

#### On-Chain Consensus Improvements

- Switching from [[Proof of Work]] to [[Proof of Stake]] reduces the energy cost per validator and allows shorter block times, improving base-layer throughput modestly.
- BFT-derived consensus algorithms (Tendermint, HotStuff, PBFT variants) achieve instant finality with O(n²) communication that remains practical for smaller, permissioned validator sets.
- [[Directed Acyclic Graph]] (DAG)-based ledgers (e.g. Hedera Hashgraph, Aleph Zero) replace the linear chain with a directed graph of events, enabling higher parallelism at the cost of different security and decentralisation trade-offs.

### Applications and Use Cases

- **[[Decentralised Finance]] (DeFi)** — High-frequency on-chain trading, automated market makers, and lending protocols require thousands of transactions per second and sub-cent fees; layer-2 rollups make this economically viable.
- **[[Micropayments]]** — State channels (notably the Lightning Network) enable streaming money and pay-per-use micropayments that would be uneconomical on base-layer chains due to minimum fee thresholds.
- **NFT marketplaces and gaming** — Consumer applications demand low latency and low fees; sidechains and appchains (application-specific blockchains) are widely deployed for gaming economies and collectibles.
- **Cross-border payments** — Scalable payment-channel networks and compliant layer-2 networks enable near-instant settlement at low cost across jurisdictions.
- **Supply chain and enterprise** — Permissioned or hybrid layer-2 solutions allow enterprises to anchor supply-chain event records to public chains without exposing sensitive data or paying high base-layer fees.
- **[[Blockchain Interoperability]]** — Scalability solutions often incorporate bridging mechanisms that connect different layer-1 ecosystems, enabling assets and messages to move across chains.
- **[[Smart Contracts]] at scale** — Complex smart-contract logic that would be prohibitively expensive on layer 1 can execute cheaply on EVM-compatible layer-2 chains while settling proofs or fraud evidence on Ethereum.

### Standards and Context

- The [[Ethereum]] ecosystem has been the primary incubator for scalability research, with Ethereum Improvement Proposals (EIPs) formalising protocol-level enhancements.
  - EIP-4844 (Proto-Danksharding / "blobs") introduced a dedicated data blob transaction type to cheaply post rollup data to Ethereum layer 1, dramatically reducing rollup fees.
  - Full Danksharding (planned) extends blobs with data availability sampling, targeting much larger data throughput for rollup settlement.
- The [[Lightning Network]] specification (BOLT standards — Basis of Lightning Technology) governs interoperability between Lightning implementations.
- The Polygon CDK and ZK stack provide open-source frameworks for deploying [[ZK-Rollups]]-based layer-2 chains.
- The Optimism Superchain initiative and Arbitrum Orbit allow teams to launch interoperable rollup chains sharing a shared security and liquidity layer.
- Celestia's data availability layer is governed by an open protocol specification; [[Data Availability Sampling]] underpins its trust model.
- Academic foundations include the original sharding proposals from [[Ethereum]] research (Ethereum 2.0 beacon chain), the Plasma framework paper (Poon & Buterin 2017), and the ZK-SNARK and ZK-STARK cryptographic literature underpinning validity proofs.

### Provenance

