Agent memory is the structured ensemble of mechanisms by which an autonomous AI agent stores, indexes, consolidates, retrieves, and forgets information across steps, sessions, and lifetimes — enabling coherent, personalised, and long-horizon behaviour that transcends the hard limit of any single context window. It encompasses four functionally distinct tiers: working memory (active context window); episodic memory (timestamped records of prior observations, actions, and outcomes); semantic memory (declarative facts, entity relationships, and world knowledge); and procedural memory (skill programs, tool-use patterns, and reusable plan templates).

### Semantic Classification

### Content

## Compositional Relationships (Components)

```
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:hasPart ai:EpisodicMemory))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:hasPart ai:SemanticMemory))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:hasPart ai:ProceduralMemory))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:hasPart ai:WorkingMemory))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:hasPart ai:LongTermMemory))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:hasPart ai:KnowledgeGraph))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:hasPart ai:ConsolidationSchedule))
```

## Dependency Relationships

```
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:requires ai:VectorDatabase))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:requires ai:Embeddings))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:requires ai:RetrievalAugmentedGeneration))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:requires ai:ContextWindow))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:requires ai:FoundationModel))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:dependsOn ai:Embeddings))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:dependsOn ai:AttentionMechanism))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:dependsOn ai:KnowledgeGraph))
```

## Capability Relationships

```
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:enables ai:AgenticWorkflow))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:enables ai:Personalisation))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:enables ai:TaskAutomation))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:enables ai:PlanningAndScheduling))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:enables ai:SelfReflection))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:enables ai:ContinualLearning))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:supports ai:MultiAgentSystem))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:supports ai:AISafety))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:supports ai:Provenance))
```

## Implementation Relationships

```
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:implements ai:ReActPattern))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:implements ai:ReflexionPattern))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:implements ai:ChainOfThought))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:uses ai:Pinecone))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:uses ai:pgvector))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:uses ai:Weaviate))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:contrastsWith ai:InContextLearning))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:contrastsWith ai:FineTuning))
```

## Reduction Relationships

```
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:reducesTo ai:AIAgent))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:reducesTo ai:CognitiveArchitecture))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:bridgesTo ai:AgentLoop))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:bridgesTo ai:ToolUse))
SubClassOf(ai:AgentMemory
  ObjectSomeValuesFrom(ai:bridgesTo ai:ContinualLearning))
```

## About

- The central motivation for agent memory is the mismatch between two architectural facts: [[Large Language Model]] are stateless — each API call processes only what is currently in the [[Context Window]], with no automatic persistence — and the tasks being delegated to [[AI Agent]] systems are increasingly long-horizon, multi-session, and requiring [[Personalisation]] to a specific user or organisational context.
- A customer-service agent that resets its knowledge of a user at every ticket boundary cannot build the cumulative understanding needed to provide personalised service. A coding agent that cannot recall what refactoring it performed three days ago will repeat work or introduce conflicts. A research agent that cannot retain its literature review findings across a multi-week project cannot synthesise a coherent report.
- These failure modes are not hypothetical: they are the principal production blockers reported by enterprise agent deployments as of 2025, alongside latency and cost.
- The cognitive science foundation is well-established. Endel Tulving's 1972 distinction between [[Episodic Memory]] (personally experienced, time-stamped events) and [[Semantic Memory]] (general, atemporal world knowledge) was extended by Anderson's [[ACT-R]] (Adaptive Control of Thought-Rational) to include [[Procedural Memory]] (condition-action rules and skills). Norman Baddeley's 1974 working memory model maps directly onto the active [[Context Window]] as the agent's working scratchpad.
- These human memory distinctions translate to agent engineering as genuinely functional categories: [[Episodic Memory]] (log of what this agent did in session 3 on Tuesday) and [[Semantic Memory]] (user Alice prefers British English and works in financial services) serve fundamentally different retrieval patterns, update frequencies, and retention policies.
- The [[CoALA]] paper (Sumers et al., 2023/2024) formalised this mapping for language agents, providing a common vocabulary adopted by virtually all subsequent framework papers and production systems. The four-tier taxonomy (working / episodic / semantic / procedural) is now the de facto standard.
- The production landscape as of mid-2026 is dominated by four frameworks: Mem0 (48,000+ GitHub stars, $24M Series A October 2025, 92.5% on LoCoMo, 94.4% on LongMemEval at under 7,000 tokens per retrieval); Letta (the production evolution of MemGPT, treating LLM context as virtual memory analogous to OS virtual RAM); Zep (63.8% LongMemEval via temporal [[Knowledge Graph]] Graphiti engine, 90% latency reduction, SOC 2 Type 2 / HIPAA / [[GDPR]] certified); and LangMem (LangChain-native, prioritising composability).
- A 2026 benchmark across five systems found no single winner across all axes: Mem0 excels at semantic retrieval; Zep at [[Temporal Reasoning]] and relational queries; Letta at conversational coherence over very long sessions; the right choice is workload-dependent.

## Components / Architecture

- **[[Working Memory]] (In-Context Buffer)** — the active [[Context Window]] of the [[Foundation Model]], holding the system prompt, current task description, recent [[Tool Use]] outputs, retrieved memory fragments, and [[Chain of Thought]] scratchpad.
- Bounded by model context length (128k tokens in most production models as of 2026; up to 2M tokens in Gemini 1.5 Ultra, but long contexts incur quadratic [[Attention Mechanism]] cost and suffer from "lost-in-the-middle" retrieval failure).
- [[Working Memory]] is ephemeral — it ceases at session end unless explicitly serialised to long-term storage. The [[Agent Loop]] must carefully manage what occupies this buffer, evicting low-relevance content to make room for newly retrieved memories or [[Tool Use]] outputs.
- **[[Episodic Memory]] Store** — a time-ordered log of what the agent experienced: observations (tool outputs, user messages), actions taken, intermediate reasoning steps, and outcomes.
- Stored as dense vector [[Embeddings]] (typically OpenAI text-embedding-3-large, Cohere embed-v3, or open-source MiniLM-L6-v2 at 384 dimensions) in a [[Vector Database]] ([[Pinecone]], [[pgvector]], [[Weaviate]], Qdrant, Chroma).
- Retrieval is semantic similarity search (approximate nearest-neighbour via HNSW or IVF index) with optional recency weighting, importance scoring, or hybrid BM25/dense reranking.
- Key engineering challenge: memories accumulate without bound; [[Consolidation]] must periodically compress, deduplicate, and summarise older episodes.
- The [[Reflexion Pattern]]'s verbal self-reflection is a form of episodic [[Consolidation]] that boosts future performance by 20–30% (Shinn et al. 2023).
- **[[Semantic Memory]] Store** — atemporal factual knowledge about entities the agent interacts with: user profiles (name, preferences, communication style, role), project context (tech stack, constraints, history), domain facts (company org chart, product catalogue, regulatory requirements).
- Often stored as a combination of structured entity records in a [[Knowledge Graph]] (Neo4j, Kuzu, or Graphiti in Zep) plus vector-indexed summaries for fuzzy [[Information Retrieval]].
- Entities have typed properties and typed relationships, supporting multi-hop reasoning that pure vector similarity cannot (what team does this person belong to, and what are that team's coding standards?).
- **[[Procedural Memory]] Store** — encoded skills, plan templates, and [[Tool Use]]-invocation patterns that the agent has generalised from prior experience.
- May be stored as few-shot examples prepended to the system prompt; a template library in structured storage retrieved by task type; or, in the most advanced case, [[Fine-Tuning]] data derived from successful agent trajectories that updates the model's parametric memory.
- The [[Reflexion Pattern]] is an explicit procedural memory mechanism: a verbal [[Self-Reflection]] on what went wrong is stored as a structured memory retrieved at the start of future attempts at similar tasks.
- ActMem (arXiv:2603.00026) bridges memory retrieval and [[Reasoning Engine]] to make procedure selection adaptive rather than static.
- **Memory Operations** — write (new experience → episodic; distilled fact → semantic; generalised skill → procedural); read (similarity search, graph traversal, [[Temporal Reasoning]] query); consolidate (episodic → semantic summarisation; episode clustering into generalised patterns); forget (TTL expiry, importance-weighted eviction, right-to-erasure [[GDPR]] compliance).
- Live-Evo (arXiv:2602.02369) demonstrated online evolution of agentic memory from continuous user feedback, consolidating short-term episodic records into long-term semantic structure without human curation.
- **Memory Scoping and [[Agent Identity]]** — memories are scoped to principal: user-scoped (persist across all sessions for that user across all agents), session-scoped (persist for the duration of one task session), and agent-scoped (intrinsic agent capabilities persisting across all users). [[Agent Identity]] provides the indexing key ensuring the right memories are retrieved for the right principal without cross-contamination.

## Use Cases / Major Families

- **Persistent personal assistant** — An assistant remembers communication style preferences (formal/informal, British English, avoidance of certain jargon), professional context (role, organisation, projects), recurring task patterns (morning standup prep, weekly report format), and relationship network (who is Alice's manager).
- This information lives in user-scoped [[Semantic Memory]], enabling the assistant to [[Personalisation|personalise]] every response without the user re-explaining context at each session.
- A 2025 Mem0 deployment case study showed 40% reduction in user re-orientation time and 67% improvement in [[Task Automation|task completion rate]] for an enterprise personal assistant agent.
- **Long-horizon research agent** — A research agent conducting a multi-week literature review stores paper summaries, contradictions, and open questions in [[Episodic Memory]]; distils consolidated themes into [[Semantic Memory]]; and retains search strategy templates in [[Procedural Memory]].
- At each new session it retrieves relevant prior findings before continuing, avoiding repetition and building coherent synthesis. FutureHouse's PaperQA2 uses memory-augmented [[Retrieval-Augmented Generation]] to achieve expert-level literature synthesis across tens of thousands of papers.
- **Coding agent with project context** — A coding agent stores repository architecture decisions, code style conventions, known bug patterns, and prior refactoring history in project-scoped [[Semantic Memory]].
- When asked to add a new feature, it retrieves relevant prior context before generating code. SWE-Bench Verified performance above 80% in top 2025 systems correlates strongly with effective use of project-context memory.
- **Customer service agent with episode history** — A service agent recalls that user X reported the same problem three times, that the previous resolution involved a specific workaround, and that the customer expressed frustration at the last interaction.
- [[Episodic Memory]] retrieval surfaces this context before the agent responds, enabling empathetic, context-appropriate service without requiring the customer to repeat history.
- Zep's HIPAA-certified temporal [[Knowledge Graph]] stores customer interaction histories in the healthcare sector, where [[Audit Trail|audit trails]] and data retention policies are regulatory requirements.
- **[[Multi-Agent System]] shared memory** — In orchestrator-worker multi-agent architectures, shared memory provides a coordination medium: the orchestrator writes task assignments and intermediate results to a shared episodic store; workers retrieve their assignments and write back results; all agents share a common [[Semantic Memory]] of project facts.
- The PlugMem architecture (arXiv:2603.03296) demonstrated a task-agnostic plugin memory module integrating across heterogeneous LLM agent types in a shared workspace, improving coordination on 17 multi-agent benchmarks.
- **[[Self-Reflection]] and [[Continual Learning]] agent** — Agents using the [[Reflexion Pattern]] maintain an evolving library of task-specific self-critiques and improvement plans.
- The Self-Consolidation approach (arXiv:2602.01966) autonomously consolidates episodic memories into updated [[Procedural Memory]] heuristics during off-peak periods — a form of offline [[Continual Learning]] without gradient updates.
- This enables agents to genuinely improve at their tasks over time based on accumulated experience, bridging the gap between static model capabilities and adaptive behaviour.

## Academic Context

- The intellectual foundations of agent memory span cognitive science, neuroscience, and computer science.
- Endel Tulving's 1972 paper "Episodic and Semantic Memory" (in Organisation of Memory, Academic Press) introduced the distinction between personally experienced events and general world knowledge that remains the dominant taxonomy in agent memory research.
- Alan Baddeley and Graham Hitch's (1974) working memory model introduced the multicomponent view of active cognitive workspace that maps directly to the agent [[Context Window]].
- John Anderson's [[ACT-R]] architecture (1983, updated through ACT-R 7.0) added [[Procedural Memory]] as compiled condition-action rules, complementing declarative episodic and semantic stores.
- The SOAR cognitive architecture (Laird, Newell & Rosenbloom, 1987) provided a production-system implementation of [[Working Memory]] plus long-term declarative and [[Procedural Memory]] stores.
- The CLARION architecture (Sun, 2006) distinguished implicit procedural learning from explicit declarative learning, anticipating the split between weight-encoded [[Procedural Memory]] and retrieval-augmented [[Semantic Memory]] in modern agent systems.
- MINERVA-2 (Hintzman, 1988) formalised instance-based memory retrieval as activation-weighted vector similarity — a direct mathematical ancestor of embedding-based [[Episodic Memory]] retrieval via nearest-neighbour search.
- The modern LLM-agent memory literature crystallised around MemGPT (Packer et al., arXiv:2310.08560, 2023), which introduced the OS paging analogy — actively managing information in and out of the LLM [[Context Window]].
- The [[CoALA]] paper (Sumers et al., arXiv:2309.02427, 2023) provided the canonical taxonomy adopted across the field, mapping cognitive science constructs to concrete engineering primitives.
- A landmark 2025 review, "Memory in the Age of AI Agents: A Survey" (Shichun Liu et al.), catalogued 200+ papers across memory types, storage substrates, retrieval methods, and [[Consolidation]] strategies.
- Benchmarks charting the memory capability frontier include: LoCoMo (Long Context Conversations with Memory, 2024) evaluating retrieval accuracy over multi-session dialogue; LongMemEval (2024) testing factual recall, [[Temporal Reasoning]], and multi-hop reasoning over long agent histories; AMA-Bench (arXiv:2602.22769) evaluating long-horizon memory for agentic applications; and the Anatomy of Agentic Memory paper (arXiv:2602.19320) providing the first systematic empirical analysis of agent memory system limitations across six evaluation dimensions.
- The Rethinking Memory Mechanisms survey (arXiv:2602.06052) identified [[Consolidation]] — the automatic abstraction of episodic traces into semantic knowledge — as the most critical unsolved problem in production agent memory.
- Key venues: NeurIPS, ICML, ICLR for machine learning; ACL, EMNLP for NLP and dialogue; UIST, CHI for human-computer interaction; AAAI, IJCAI for AI generally; AAMAS for multi-agent systems.

## Current Landscape (2026)

- By mid-2026 the agent memory infrastructure market has stratified into a competitive commercial landscape.
- Mem0 leads in semantic and hybrid retrieval, reporting 92.5% on LoCoMo and 94.4% on LongMemEval with token-efficient [[Compression]] achieving under 7,000 tokens per call; the company raised $24M Series A in October 2025 and reports 48,000+ GitHub stars.
- Zep differentiates on [[Temporal Reasoning]] and enterprise compliance (SOC 2 Type 2, HIPAA, [[GDPR]]), with its Graphiti engine achieving 63.8% on LongMemEval via a temporal [[Knowledge Graph]] with validity-window-aware entity updates and 90% latency reduction versus full-context approaches.
- Letta (MemGPT successor) differentiates on conversational coherence over very long sessions using virtual context management, with a paid cloud service and an active open-source community.
- LangMem provides LangChain-native integration, prioritising composability over standalone performance.
- The broader technical trajectory shows three significant shifts: (1) pure [[Vector Database]] stores are giving way to hybrid architectures combining vector similarity, graph relationships, and structured key-value lookups; (2) memory [[Consolidation]] — automated compression and abstraction of episodic traces into [[Semantic Memory]] knowledge — has moved from research prototype to product feature; (3) [[Privacy]] and [[GDPR]] compliance has become a first-order engineering constraint as agent memory stores accumulate personally identifiable information.
- Gartner predicts 40% of enterprise applications will feature task-specific AI agents by 2026, up from less than 5% in 2025, with memory being one of the three principal capability gaps to be closed.
- The 2025 agent memory infrastructure market valued at USD 6.3 billion is projected to reach USD 28.5 billion by 2030 at 35% CAGR.
- The "State of AI Agent Memory 2026" report (Mem0.ai) identified cross-session continuity, [[Multi-Agent System]] shared memory, and [[Privacy]]-preserving retrieval as the three most requested enterprise features not yet fully solved.

## UK Context

- UCL's brain-inspired computing initiative (UKRI-funded, announced September 2025) is developing neuromorphic hardware for energy-efficient AI, with applications to always-on persistent memory in deployed edge agents.
- UCL's Centre for Artificial Intelligence, leading the UKRI AI Hub in Generative Models (jointly with Imperial College London, Cambridge, Oxford, Manchester, Edinburgh, Cardiff, Surrey), encompasses research into memory-augmented models and [[Retrieval-Augmented Generation]] that feeds into agent memory infrastructure.
- Professor Richard Henson (MRC Cognition and Brain Sciences Unit, Cambridge) is a leading figure in human [[Episodic Memory]] and [[Semantic Memory]], and his computational models of hippocampal memory [[Consolidation]] — specifically the complementary learning systems (CLS) theory developed with Jay McClelland — have directly influenced neural-symbolic memory architectures in AI agent systems.
- The University of Edinburgh Autonomous Agents Research Group (AARG), besides its work on multi-agent decision-making, maintains active research in state representation and memory for agents operating in partially observable environments — foundational theory for the [[Episodic Memory]] retrieval problem.
- The NeuMat network (£1.4M EPSRC-funded, co-led by Cambridge and Edinburgh) is investigating neuromorphic memory technologies that may provide power-efficient persistent storage for always-on agent memory at the edge.
- Manchester's industrial ecosystem provides practical demand drivers: financial services firms (Manchester is the UK's second financial centre) deploying trading and compliance agents require persistent [[Audit Trail|audit-trail]] memory satisfying FCA record-keeping regulations.
- Sheffield Robotics (joint University of Sheffield and Sheffield Hallam centre) works on embodied agent memory for robot navigation — maintaining persistent spatial maps (a form of [[Semantic Memory]]) and episode logs of prior [[Task Automation|task execution]].
- The Alan Turing Institute (ATI) programme on interpretable AI engages directly with agent memory explainability: if an agent's decision was influenced by a retrieved memory, which memory was it, what was its [[Provenance]], and can a human audit the chain? This addresses [[AI Safety]] and [[Human-in-the-Loop]] concerns that arise specifically from memory-augmented agent decision-making.

## Future Directions (2026-2030)

- **[[Consolidation]] as a first-class operation** — Automated offline consolidation of episodic traces into [[Semantic Memory]] and [[Procedural Memory]] knowledge, reducing storage costs and improving retrieval signal-to-noise, is the most technically important frontier.
- Research directions include contrastive consolidation (retaining discriminative rather than redundant memories), importance-weighted [[Compression]] (preserving high-surprise, high-consequence episodes), and hierarchical abstraction (episode → event → pattern → generalised heuristic).
- Live-Evo (arXiv:2602.02369) and Self-Consolidation (arXiv:2602.01966) are early demonstrations of this direction.
- **[[Privacy]]-preserving agent memory** — As agent memory accumulates personally identifiable information, techniques from differential [[Privacy]], federated learning, and secure multi-party computation will be applied to enable memory retrieval without exposing raw PII.
- [[GDPR]] Article 17 (right to erasure) requires that deletion of a user's PII from agent memory be verifiable and complete — technically non-trivial for dense vector [[Embeddings]] where PII is encoded implicitly. Machine unlearning research is converging on this problem.
- **[[Multi-Agent System]] shared memory governance** — In large-scale multi-agent deployments, shared [[Episodic Memory]] requires governance: access control (which agent can read/write what), conflict resolution (contradictory memory entries), [[Provenance]] tracking (which agent wrote this memory entry), and auditability.
- These governance requirements connect agent memory directly to [[Agent Identity]] (for attribution) and [[Provenance]] (for audit trails), forming a unified accountability layer for agentic deployments.
- **Continual weight learning from memory** — Current architectures maintain a hard boundary between retrieval-based external memory (episodic, semantic) and parametric internal memory (model weights).
- Future systems will blur this boundary: high-value episodic experiences will trigger lightweight [[Fine-Tuning]] updates (using LoRA or prefix-tuning) that encode learned [[Procedural Memory]] into model weights, creating a virtuous cycle between retrieval and learning.
- This bridges agent memory to [[Continual Learning]] and lifelong machine learning.
- **[[Temporal Reasoning]] and causal memory** — Current vector similarity retrieval is largely atemporal and acausal. Temporal [[Knowledge Graph]] architectures (Zep's Graphiti) demonstrated the value of validity windows; future systems will also represent causal relationships (action X caused outcome Y), enabling agents to reason about counterfactuals and plan more effectively.
- **Neuromorphic memory at the edge** — For always-on personal assistant agents running on device, conventional DRAM-backed [[Vector Database]] systems are prohibitively power-hungry. Neuromorphic memory technologies (Intel Loihi, IBM NorthPole, UCL brain-inspired computing initiative) may provide persistent, low-power analogue memory substrates. This is a 2027–2030 horizon technology.

## Research & Literature

- 1. Tulving, E. (1972). Episodic and Semantic Memory. In Tulving & Donaldson (Eds.), Organisation of Memory. Academic Press. [Foundational cognitive science taxonomy of episodic vs. semantic memory underpinning agent memory design.]
- 2. Baddeley, A. & Hitch, G. (1974). Working Memory. Psychology of Learning and Motivation, 8, 47–89. [Multi-component working memory model mapping to agent context window architecture.]
- 3. Anderson, J.R. (1983). The Architecture of Cognition. Harvard University Press. [ACT-R procedural + declarative memory — basis for agent procedural memory design.]
- 4. Laird, J., Newell, A. & Rosenbloom, P. (1987). SOAR: An Architecture for General Intelligence. Artificial Intelligence, 33(1), 1–64. [Cognitive architecture with production memory — precursor to agent memory systems.]
- 5. Sumers, T.R. et al. (2024). Cognitive Architectures for Language Agents. Transactions on Machine Learning Research. arXiv:2309.02427. [Canonical CoALA taxonomy: working, episodic, semantic, procedural memory for LLM agents.]
- 6. Packer, C. et al. (2023). MemGPT: Towards LLMs as Operating Systems. arXiv:2310.08560. [OS-inspired virtual context management; Letta production evolution.]
- 7. Shichun Liu et al. (2025). Memory in the Age of AI Agents: A Survey. GitHub. https://github.com/Shichun-Liu/Agent-Memory-Paper-List [200+ paper survey; canonical research map of agent memory space.]
- 8. Mem0.ai. (2026). State of AI Agent Memory 2026: Benchmarks, Architectures & Production Gaps. https://mem0.ai/blog/state-of-ai-agent-memory-2026 [Industry benchmarking report; LoCoMo 92.5%, LongMemEval 94.4% for Mem0.]
- 9. Shinn, N. et al. (2023). Reflexion: Language Agents with Verbal Reinforcement Learning. NeurIPS 2023. arXiv:2303.11366. [Episodic self-reflection stored as procedural memory; 20-30% improvement baseline.]
- 10. Park, J.S. et al. (2023). Generative Agents: Interactive Simulacra of Human Behavior. UIST 2023. arXiv:2304.03442. [Seminal multi-agent memory architecture with reflection, retrieval, and planning streams.]
- 11. Yao, S. et al. (2023). ReAct: Synergizing Reasoning and Acting in Language Models. ICLR 2023. arXiv:2210.03629. [ReAct pattern: working memory as interleaved reasoning-action-observation scratchpad.]
- 12. Anatomy of Agentic Memory. (2025). Taxonomy and Empirical Analysis of Evaluation and System Limitations. arXiv:2602.19320. [First systematic empirical analysis across six evaluation dimensions; consolidation identified as key gap.]
- 13. Rethinking Memory Mechanisms of Foundation Agents in the Second Half: A Survey. (2026). arXiv:2602.06052. [Survey identifying consolidation as most critical unsolved problem in production agent memory.]
- 14. AMA-Bench. (2026). Evaluating Long-Horizon Memory for Agentic Applications. arXiv:2602.22769. [Benchmark specifically targeting long-horizon agentic memory across multi-session tasks.]
- 15. Live-Evo. (2026). Online Evolution of Agentic Memory from Continuous Feedback. arXiv:2602.02369. [Online episodic-to-semantic consolidation without human curation.]
- 16. Self-Consolidation for Self-Evolving Agents. (2026). arXiv:2602.01966. [Offline autonomous consolidation of episodic to procedural knowledge; lifelong agent learning.]
- 17. ActMem. (2026). Bridging the Gap Between Memory Retrieval and Reasoning in LLM Agents. arXiv:2603.00026. [Adaptive procedure selection via memory-reasoning integration.]
- 18. PlugMem. (2026). A Task-Agnostic Plugin Memory Module for LLM Agents. arXiv:2603.03296. [Cross-agent shared memory module; improved coordination on 17 multi-agent benchmarks.]
- 19. Chain-of-Memory. (2026). Lightweight Memory Construction with Dynamic Evolution for LLM Agents. arXiv:2601.14287. [Efficient episodic chain construction with dynamic updating.]
- 20. Vectorize.io. (2026). Best AI Agent Memory Systems in 2026: 8 Frameworks Compared. https://vectorize.io/articles/best-ai-agent-memory-systems [Independent comparative benchmark: Mem0 vs Zep vs Letta vs LangMem vs others.]
- 21. Hintzman, D.L. (1988). Judgments of Frequency and Recognition Memory in a Multiple-Trace Memory Model. Psychological Review, 95(4), 528–551. [MINERVA-2: instance-based retrieval via activation-weighted similarity — ancestor of embedding retrieval.]
- 22. McClelland, J.L. & Rumelhart, D.E. (1986). Parallel Distributed Processing (Vol. 2). MIT Press. [Complementary learning systems theory influencing hippocampal-neocortical consolidation models in AI.]
- 23. Sun, R. (2006). The CLARION Cognitive Architecture. Cognition and Multi-Agent Interaction. Cambridge University Press. [Implicit/explicit learning distinction mapping to parametric vs. retrieval memory split.]
- 24. Digital Applied. (2026). AI Agent Memory 2026: Vector, Graph, Episodic Update. https://www.digitalapplied.com/blog/ai-agent-memory-vector-graph-episodic-2026 [Industry analysis of hybrid vector-graph architectures in enterprise deployment.]
- 25. UCL. (2025). UCL to Lead UK's Brain-Inspired Computing Push with New Innovation Centre. UCL News. https://www.ucl.ac.uk/news/2025/sep/ucl-lead-uks-brain-inspired-computing-push-new-innovation-centre [UK neuromorphic computing initiative with implications for persistent edge agent memory.]
- 26. Atlan. (2026). Best AI Agent Memory Frameworks in 2026: Compared and Ranked. https://atlan.com/know/best-ai-agent-memory-frameworks-2026/ [Framework comparison; Mem0 as most widely deployed semantic memory layer mid-2026.]
- 27. Introduction to Cognitive Artificial Intelligence. (2023). NCBI PMC. https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10239676/ [Bridge between cognitive science memory models and AI agent design; taxonomy alignment.]
- 28. Zylos Research. (2026). AI Agent Memory Architectures: From Context Windows to Persistent Knowledge. https://zylos.ai/research/2026-04-05-ai-agent-memory-architectures-persistent-knowledge/ [Production architecture patterns: pure vector vs. hybrid vector-graph vs. parametric for 2026 deployments.]

### Provenance

