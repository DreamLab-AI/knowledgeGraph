Sole sourcing is buying from one supplier because that supplier is the only one able to provide the good or service specified.[^1][^2][^3]

The Pennsylvania State University module says sole sourcing is where there is only one supplier available for the goods or services specified, and that the buying firm will often want additional sources but none are to be had, often because of the highly unique characteristics in the specification.[^1] SUNY Oswego defines sole source procurement as one in which only one supplier can provide the commodity, technology or services required, and requires an explanation of why the item is unique and how it was determined that the price is fair and reasonable.[^2]

## In public law

The United States Federal Acquisition Regulation, at 6.302-1, allows full and open competition to be waived when supplies or services are available from only one responsible source and no other type will satisfy agency requirements.[^3] UNCITRAL's Model Law allows single-source procurement in exceptional circumstances, including where the subject matter is available only from a particular supplier or that supplier has exclusive rights, so that no reasonable alternative or substitute exists.[^4]

UNCITRAL also allows single-source procurement where, owing to a catastrophic event, there is an extremely urgent need and any other method would be impractical because of the time involved.[^4]

## Scope and distinctions

See [[Single Sourcing]], [[Dual Sourcing]] and [[Sourcing Strategy]].

## What the sources do not establish

Sources use different wordings for the one-supplier situation, and the legal tests of the United States and UNCITRAL are for public buyers, so thresholds and justification rules are not described here.[^3][^4]

[^1]: Pennsylvania State University Smeal College of Business, SCM 820 course module 4, “Lesson 1: Single or Sole Sourcing”. https://courses.smeal.psu.edu/scm824fa20/scm824fa20_module_4/2011/06/SCM820-M4L1Single-or-Sole-Sourcing.html
[^2]: State University of New York at Oswego, Purchasing office, “Single and Sole Source Procurements”. https://ww1.oswego.edu/purchasing/single-and-sole-source-procurements
[^3]: US General Services Administration and Department of Defense, Federal Acquisition Regulation, acquisition.gov, “FAR 6.302-1 Only one responsible source and no other supplies or services will satisfy agency requirements.”. https://www.acquisition.gov/far/6.302-1
[^4]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf

