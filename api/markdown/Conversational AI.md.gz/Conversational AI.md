Conversational AI encompasses systems that engage in natural-language dialogue with humans, including chatbots, voice assistants, and large-language-model-powered interfaces. It applies natural language processing, language modeling, dialogue management, and speech recognition to understand intent and generate contextually appropriate responses.

### Semantic Classification

### Content

## Compositional Relationships (Components)
  ```
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:hasPart ai:DialogueSystem))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:hasPart ai:NaturalLanguageUnderstanding))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:hasPart ai:IntentRecognition))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:hasPart ai:SentimentAnalysis))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:hasPart ai:SpeechRecognition))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:hasPart ai:TextToSpeech))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:hasPart ai:Chatbot))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:hasPart ai:DialogueStateTracking))
  ```
## Dependency Relationships
  ```
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:requires ai:LanguageModeling))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:requires ai:ContextManagement))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:requires ai:KnowledgeBase))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:dependsOn ai:MachineLearning))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:dependsOn ai:SpeechProcessing))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:dependsOn ai:PretrainedLanguageModel))
  ```
## Capability Relationships
  ```
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:enables ai:VirtualAssistant))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:enables ai:CustomerServiceAutomation))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:enables ai:HumanRobotInteraction))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:enables ai:IntelligentTutoringSystem))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:enables ai:AgenticAIWorkflow))
  ```
## Implementation Relationships
  ```
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:uses ai:LargeLanguageModels))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:uses ai:TransformerArchitecture))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:uses ai:ReinforcementLearningFromHumanFeedback))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:uses ai:RetrievalAugmentedGeneration))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:uses ai:AutomaticSpeechRecognition))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:implements ai:DialogueStateTracking))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:implements ai:IntentClassification))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:implements ai:NamedEntityRecognition))
  ```
## Reduction Relationships
  ```
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:reducesTo ai:DialogueSystem))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:reducesTo ai:NaturalLanguageProcessing))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:reducesTo ai:LanguageModeling))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:reducesTo ai:MachineLearning))
  ```
## Alignment and Safety Relationships
  ```
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:requires ai:AlignmentTechnique))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:requires ai:SafetyClassifier))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:supports ai:AccessibilityTechnology))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:supports ai:MultimodalAI))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:contrasts ai:RuleBasedSystems))
  SubClassOf(ai:ConversationalAI
    ObjectSomeValuesFrom(ai:contrasts ai:FormBasedInterface))
  ```

## About
  Conversational AI has undergone a discontinuous transition since 2022 driven by the emergence of [[Large Language Model]] trained on internet-scale corpora. Where prior-generation systems — beginning with Weizenbaum's ELIZA (1966), through ALICE and AIML rule-based bots, through the retrieval-based neural dialogue systems of the 2015-2020 era — required hand-crafted dialogue flows, explicit slot-filling schemas, and narrow domain restrictions, contemporary systems built on GPT-4, Claude, Gemini, and Llama-family models engage in genuinely open-domain conversation while retaining task-completion capability. The paradigm shift rests on three technical pillars: (1) [[Transformer Architecture]] encoders and decoders with self-attention that can represent and manipulate discourse context across hundreds of turns; (2) [[Reinforcement Learning from Human Feedback]] (RLHF) and its variants (RLAIF, DPO, Constitutional AI) that align model outputs to human preferences for helpfulness, harmlessness, and honesty; (3) [[Retrieval-Augmented Generation]] (RAG), which grounds model responses in up-to-date knowledge bases rather than relying solely on parametric memory, becoming the industry standard for production deployments in 2025-2026.

  The field has simultaneously expanded into multimodal conversational interfaces that process speech audio directly through end-to-end models (e.g., GPT-4o, Gemini 2.0 Flash), bypassing the classic Automatic Speech Recognition → NLU → NLG → Text-to-Speech pipeline and reducing latency from seconds to under 200 milliseconds for voice turn-taking. An emerging paradigm — agentic conversational AI — treats the conversation not merely as an exchange of information but as the orchestration layer for tool-using agents: the user expresses high-level goals in natural language, and the system decomposes them into sub-tasks executed by web search, code execution, API calls, and specialised sub-models. McKinsey's 2025 contact centre analysis found that agentic conversational AI delivered a 50% reduction in cost per call while simultaneously improving customer satisfaction, illustrating the business transformation underway.

  Architecturally, modern conversational AI systems can be decomposed into: (a) a perception stack handling multi-modal input parsing; (b) a working memory or context window (ranging from 8K to over 1M tokens) preserving conversation history; (c) a world model (the LLM itself) performing reasoning and response generation; (d) an alignment layer enforcing safety and policy constraints; (e) a grounding layer connecting to external [[Knowledge Base]]s, APIs, and structured data via RAG or tool use; and (f) a rendering stack producing text, speech, or multimodal output. The interplay between these layers defines both capability and failure modes — context window limits, hallucination rates, latency, and safety alignment remain active research and engineering challenges as of 2026.

## System Architecture and Components

- **Perception Stack**: Multi-modal input processing. [[Automatic Speech Recognition]] for voice (Whisper-class models achieve under 5% WER on clean speech); vision encoders for image input; video understanding modules. End-to-end speech models eliminate the ASR/NLU boundary in latency-critical deployments.
- **[[Natural Language Understanding]] (NLU)**: Parsing user utterances into structured representations. Sub-tasks include:
  - [[Intent Recognition]] / [[Intent Classification]]: mapping utterances to action categories
  - Named Entity Recognition: identifying slots (locations, dates, names, product codes)
  - Coreference Resolution: linking pronouns and ellipses across turns
  - [[Sentiment Analysis]]: detecting affective valence to adapt response tone
- **[[Dialogue System]] and State Management**: The central orchestration component. Modern approaches use the LLM itself as an implicit dialogue state tracker operating over the conversational context window, replacing explicit Dialogue State Tracking modules. Task-oriented systems may still employ structured state representations (database query slots, API parameters) alongside the language model.
- **[[Retrieval-Augmented Generation]] (RAG)**: At inference time, a retrieval module (dense vector search over [[Knowledge Base]]s or document stores) fetches relevant passages that are prepended to the LLM context, grounding responses in verified and current information. [[Dense Passage Retrieval]] and hybrid BM25+dense retrieval are standard patterns.
- **Generation and Alignment**: The [[Large Language Model]] backbone generates candidate responses; post-processing filters apply safety classifiers, factuality checkers, and policy-compliance layers. [[Reinforcement Learning from Human Feedback]] shapes the underlying model to prefer aligned outputs.
- **[[Text-to-Speech]] (TTS)**: Neural TTS (WaveNet, Tacotron, VITS, Voicebox) synthesises speech from text. Latency-optimised streaming TTS allows first-packet audio in under 100ms for voice assistant applications.
- **Dialogue Flow Orchestration**: Multi-agent frameworks (LangGraph, AutoGen, CrewAI) allow conversational AI to spawn sub-agents for specialised tasks, routing sub-dialogues and aggregating results into a coherent conversational thread.

  ## Major System Families and Variants

- **Open-Domain LLM Assistants**: ChatGPT (GPT-4.5/GPT-5), Claude (Anthropic), Gemini (Google), Llama 3.x (Meta). Trained on web-scale corpora; RLHF-aligned; support multi-turn conversation with tool use.
- **Task-Oriented Dialogue Systems (TOD)**: Narrowly scoped systems for booking, scheduling, and customer service. Built on intent/slot schemas; more interpretable and controllable than open-domain LLMs; often deployed in regulated industries.
- **Voice Assistants**: Alexa, Google Assistant, Siri, Cortana. Historically pipeline-based (ASR → NLU → Dialogue → TTS); newer iterations increasingly LLM-backed with real-time voice processing.
- **Domain-Specific Conversational AI**: Clinical dialogue systems (diagnostic assistants, patient triage); legal research assistants; code assistants (GitHub Copilot Chat). Domain adaptation via fine-tuning, RAG, and prompt engineering.
- **Embodied Conversational Agents**: Conversational AI systems embedded in [[Autonomous Robot]] platforms, [[Digital Twin]] environments, and [[Spatial Computing]] interfaces, where dialogue mediates physical or virtual world manipulation.
- **Open-Source Frameworks**: Rasa (intent-slot, transformer NLU), OpenDevin, LangChain, LlamaIndex for RAG pipelines; Hugging Face Transformers for model serving.

  ## Use Cases

- **Customer Service Automation**: Automated first-line support handling 60-80% of queries without human escalation; 64% of enterprise leaders planned increased conversational AI investment in 2026.
- **Healthcare**: Clinical dialogue systems for history-taking, triage, and medication adherence. The UK NHS has active research partnerships exploring LLM-assisted triage tools. Healthcare chatbot adoption projected at 33.7% CAGR through 2028.
- **Education**: Intelligent Tutoring Systems providing Socratic dialogue, personalised feedback, and adaptive curricula. Conversational AI increasingly deployed in UK higher education for student support.
- **Financial Services**: 88-92% of top-tier North American banks have deployed AI chatbots for account management, fraud alerts, and financial guidance. UK FinTech companies including Monzo and Starling have conversational AI embedded in app interfaces.
- **Robotics and Embodied AI**: Voice-commanded robotic manipulation, conversational interfaces for [[Human Robot Interaction]], and natural-language task specification for autonomous systems.
- **Accessibility**: Screen reader integration, augmentative and alternative communication (AAC) systems, and voice-first interfaces for users with motor impairments.
- **Enterprise Productivity**: AI copilots embedded in Microsoft 365 (Copilot), Google Workspace, and Salesforce CRM use conversational interfaces to automate document drafting, meeting summarisation, and data querying.

  ## Academic Context
  The intellectual lineage of Conversational AI spans six decades. Joseph Weizenbaum's ELIZA (1966) at MIT introduced pattern-matching dialogue simulation. ALICE (2001) and AIML formalised rule-based open-domain chat. The statistical dialogue systems era (2005-2015) introduced probabilistic generative models (Levin et al., 2000; Young et al., 2013) and Partially Observable Markov Decision Processes (POMDPs) for dialogue management. The neural turn began with retrieval-based neural response selection (Lowe et al., 2015) and sequence-to-sequence generative models (Vinyals & Le, 2015). The transformer revolution (Vaswani et al., 2017) enabled GPT-2's open-domain generation capability (Radford et al., 2019) and BERT-based understanding (Devlin et al., 2019). Fine-tuning paradigms (InstructGPT, RLHF — Ouyang et al., 2022) produced the instruction-following assistants central to the 2022-2026 conversational AI wave. The Amazon Alexa Prize competition (2017-present) has been a major driver of open-domain social chatbot research, producing systems like Tartan (CMU) and Twiz.

  Research frontiers as of 2026 include: long-context coherence (maintaining consistency across 1M-token windows); grounded factual dialogue (hallucination mitigation through RAG and verification); socially-intelligent dialogue (theory of mind, empathy modelling); multilingual and cross-lingual dialogue; privacy-preserving on-device dialogue; and the alignment of agentic conversational systems that can take consequential actions in the world.

  ## Current Landscape (2026)
  The global conversational AI market reached $17.97 billion in 2026, growing at approximately 21% annually toward a projected $82.46 billion by 2034. Among Fortune 500 companies, 92% have adopted large language models in some capacity, with conversational AI interfaces being among the most visible deployments. The dominant architectural pattern for enterprise deployments is RAG-augmented LLM assistants — general-purpose models grounded in company-specific knowledge bases — replacing bespoke intent-slot chatbots that were standard prior to 2022.

  The 2025-2026 period is marked by three concurrent trends: (1) the shift from reactive chatbots to proactive agentic assistants that execute workflows and coordinate tool use; (2) multimodal voice-first interfaces where end-to-end speech models replace pipeline architectures; (3) embedded personal AI assistants integrated at the operating-system level (Apple Intelligence, Google Gemini nano, Microsoft Copilot+) that maintain persistent user context. Major model families — GPT-5 (OpenAI), Claude 4 (Anthropic), Gemini 3 (Google), Llama 3.3 (Meta), Mistral — compete on dimensions of reasoning depth, context length, latency, and cost.

  A McKinsey 2025 analysis of contact centre AI found 50% cost-per-call reduction with simultaneously improved customer satisfaction metrics, accelerating enterprise adoption. Safety concerns — hallucination, jailbreaking, data leakage, and misuse in social engineering — remain active research and regulatory attention areas, with the EU AI Act classifying high-risk conversational AI deployments (healthcare, policing) under mandatory conformity assessment requirements.

  ## UK Context
  The United Kingdom has significant academic and commercial presence in conversational AI. Cambridge University's Dialogue Systems Group (headed by Steve Young, creator of the Bayesian Update of Dialogue State framework) is one of the world's most cited research groups in dialogue systems, with seminal work on POMDP-based dialogue management. Edinburgh's Institute for Language, Cognition and Computation has active research in spoken dialogue, neural machine translation, and conversational models for low-resource languages. University College London (UCL) and Imperial College London have research groups spanning conversational agents for healthcare, affective computing in dialogue, and conversational AI for education.

  In industry, the UK hosts conversational AI deployments across public and private sectors. The Office for National Statistics (March 2026) reported AI uptake among UK firms projected to grow from 9% (2023) to 22% (end-2024), with conversational interfaces among the highest-growth applications. UK FinTech unicorns including Monzo, Revolut, and Starling have integrated LLM-backed conversational interfaces. The NHS is evaluating conversational AI for GP triage and mental health support (the NHS-AI Lab has active partnerships with Babylon Health successors and academic medical centres). The UK is projected to have a 22.8% CAGR in chatbot adoption through 2034.

  Northern English industrial context is also relevant: Yorkshire and Manchester-based manufacturing and logistics firms (e.g., ASOS, Co-op, First Group) have deployed conversational AI for customer service and internal productivity, with Manchester's digital innovation district NOMA serving as a hub for AI enterprise deployments. Leeds Digital Festival and the Sheffield City Region's advanced manufacturing cluster have explicitly engaged conversational AI for operational efficiency programmes.

  ## Future Directions (2026-2030)

- **Persistent Personal Context**: Conversational AI systems that maintain rich, longitudinal user models across sessions and devices — knowing user preferences, past decisions, goals, and relationships — enabling genuinely personalised assistance rather than per-session amnesia.
- **Agentic Orchestration**: The conversational interface evolving from question-answering to autonomous task execution — coordinating multi-step workflows across tools, APIs, databases, and sub-agents in response to natural-language directives.
- **Multimodal Native Architecture**: End-to-end audio-visual-text transformers that process any sensory input and generate any output modality, eliminating the pipeline fragmentation of current voice-first systems.
- **On-Device and Privacy-Preserving Dialogue**: Compressed models (1-7B parameters) running on smartphone and edge hardware enable private conversational AI without cloud data transmission; critical for healthcare, legal, and financial contexts.
- **Embodied Conversational Agents**: Tight integration of conversational AI with robotics, spatial computing, and digital twin platforms; the conversation becomes the primary interface for controlling physical and virtual agents in augmented and extended reality.
- **Regulation-Aware Dialogue**: EU AI Act and UK AI regulation create requirements for explainability, auditability, and human oversight in high-risk conversational AI deployments; systems will need built-in transparency and human-in-the-loop escalation mechanisms.
- **Theory of Mind and Social Intelligence**: Advancing beyond literal intent understanding toward models that reason about user beliefs, mental states, and social context — essential for naturalistic, empathic interaction in healthcare and education.

  ## Research and Literature
  1. Weizenbaum, J. (1966). ELIZA — a computer program for the study of natural language communication between man and machine. *Communications of the ACM*, 9(1), 36-45.
  2. Turing, A. M. (1950). Computing machinery and intelligence. *Mind*, 59(236), 433-460.
  3. Young, S., Gasic, M., Thomson, B., & Williams, J. D. (2013). POMDP-based statistical spoken dialogue systems: A review. *Proceedings of the IEEE*, 101(5), 1160-1179.
  4. Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, L., & Polosukhin, I. (2017). Attention is all you need. *NeurIPS 2017*.
  5. Devlin, J., Chang, M.-W., Lee, K., & Toutanova, K. (2019). BERT: Pre-training of deep bidirectional transformers for language understanding. *NAACL 2019*.
  6. Radford, A., Wu, J., Child, R., Luan, D., Amodei, D., & Sutskever, I. (2019). Language models are unsupervised multitask learners. *OpenAI Blog*.
  7. Ouyang, L., Wu, J., Jiang, X., Almeida, D., Wainwright, C., Mishkin, P., ... & Lowe, R. (2022). Training language models to follow instructions with human feedback. *NeurIPS 2022*.
  8. Lewis, P., Perez, E., Piktus, A., Petroni, F., Karpukhin, V., Goyal, N., ... & Kiela, D. (2020). Retrieval-augmented generation for knowledge-intensive NLP tasks. *NeurIPS 2020*.
  9. Bocklisch, T., Faulkner, J., Pawlowski, N., & Nichol, A. (2017). Rasa: Open source language understanding and dialogue management. *arXiv:1712.05181*.
  10. Vinyals, O., & Le, Q. (2015). A neural conversational model. *ICML 2015 Workshop*.
  11. Lowe, R., Pow, N., Serban, I., & Pineau, J. (2015). The Ubuntu dialogue corpus: A large dataset for research in unstructured multi-turn dialogue systems. *SIGDIAL 2015*.
  12. Serban, I. V., Sordoni, A., Bengio, Y., Courville, A., & Pineau, J. (2016). Building end-to-end dialogue systems using generative models. *AAAI 2016*.
  13. Henderson, M., Thomson, B., & Williams, J. (2014). The second dialog state tracking challenge. *SIGDIAL 2014*.
  14. Gao, J., Galley, M., & Li, L. (2019). Neural approaches to conversational AI. *Foundations and Trends in Information Retrieval*, 13(2-3), 127-298.
  15. Rafailov, R., Sharma, A., Mitchell, E., Ermon, S., Manning, C. D., & Finn, C. (2023). Direct preference optimization: Your language model is secretly a reward model. *NeurIPS 2023*.
  16. Wei, J., Wang, X., Schuurmans, D., Bosma, M., Ichter, B., Xia, F., ... & Zhou, D. (2022). Chain-of-thought prompting elicits reasoning in large language models. *NeurIPS 2022*.
  17. Chen, H., Liu, X., Yin, D., & Tang, J. (2017). A survey on dialogue systems: Recent advances and new frontiers. *ACM SIGKDD Explorations*, 19(2), 25-35.
  18. Thoppilan, R., De Freitas, D., Hall, J., Shazeer, N., Kulshreshtha, A., Cheng, H.-T., ... & Le, Q. (2022). LaMDA: Language models for dialog applications. *arXiv:2201.08239*.
  19. Bender, E. M., Gebru, T., McMillan-Major, A., & Shmitchell, S. (2021). On the dangers of stochastic parrots. *FAccT 2021*.
  20. Adiwardana, D., Luong, M.-T., So, D. R., Hall, J., Fiedel, N., Thoppilan, R., ... & Le, Q. (2020). Towards a human-like open-domain chatbot. *arXiv:2001.09977*.
  21. Roller, S., Dinan, E., Goyal, N., Ju, D., Williamson, M., Liu, Y., ... & Weston, J. (2021). Recipes for building an open-domain chatbot. *EACL 2021*.
  22. Wu, Y., Wu, W., Xing, C., Zhou, M., & Li, Z. (2017). Sequential matching network: A new architecture for multi-turn response selection in retrieval-based chatbots. *ACL 2017*.
  23. Konrad, A., & Maier, B. (2025). From chatbots to agents: Enterprise conversational AI survey 2025. *Gartner Research Report*.
  24. NHS-AI Lab (2024). AI in conversational healthcare: Pilot programme evaluation report. *NHSX Publication*.
  25. Office for National Statistics (2026). AI adoption in UK businesses: March 2026 bulletin. *ONS Statistical Release*.
  26. McKinsey & Company (2025). The state of AI in contact centres: 2025 global survey. *McKinsey Global Institute*.
  27. European Commission (2024). EU Artificial Intelligence Act: Official Journal of the European Union. Regulation (EU) 2024/1689.
  28. Masterofcode (2026). State of conversational AI: Trends and statistics 2026. *Industry Report*. https://masterofcode.com/blog/conversational-ai-trends

  ## Key Terminology

- **Utterance**: A single turn of spoken or written input from a user within a conversational session.
- **Intent**: The underlying goal or action a user intends to express through an utterance (e.g., BookFlight, GetWeather).
- **Slot Filling**: The process of extracting specific parameter values (slots) from utterances to complete a structured action (e.g., destination = "Manchester", date = "Monday").
- **Dialogue State**: The accumulated representation of conversational context at a given turn, encoding what has been discussed and what remains to be resolved.
- **Turn-Taking**: The mechanism by which conversational systems manage the exchange of speaking roles between user and system, including detection of end-of-utterance boundaries.
- **Grounding**: The process by which a conversational system confirms mutual understanding with the user, resolving ambiguities through clarifying questions or acknowledgements.
- **Hallucination**: The generation of plausible-sounding but factually incorrect or ungrounded statements by language model-based systems — a primary reliability challenge in conversational AI.
- **RLHF**: Reinforcement Learning from Human Feedback — the training paradigm in which human preference labels are used to train a reward model that then shapes language model outputs via reinforcement learning.
- **RAG**: Retrieval-Augmented Generation — the architectural pattern of augmenting language model generation with retrieved context from an external knowledge store.
- **Agentic AI**: Conversational AI operating in an execution loop where natural-language goals are decomposed and executed through tool calls, API invocations, and sub-agent coordination.

### Provenance

