Robot locomotion is the study and engineering of how robots move through their environment, encompassing legged walking, wheeled rolling, crawling, swimming and flight. It integrates mechanical design, control theory and sensing to generate stable, efficient and adaptive movement over varied terrain. Locomotion distinguishes itself from manipulation by focusing on whole-body displacement and dynamic balance rather than interaction with objects.

### Overview

- Locomotion spans morphologies from wheels and tracks to legs, wings and undulating bodies.
- Legged locomotion offers terrain versatility at the cost of harder dynamic balance control.
- Modern approaches combine model-based control with learned policies for robustness on rough ground.

### Key aspects

- Gait generation and phasing for legged systems.
- Dynamic balance and zero-moment-point stability criteria.
- Terrain perception and adaptive foothold selection.
- Energy efficiency and cost-of-transport optimisation.

### Applications

- Quadruped and humanoid robots for inspection and logistics.
- Search-and-rescue over rubble and stairs.
- Planetary and field robotics on unstructured terrain.

### Provenance

