Mass balance is a chain of custody model in which certified and non-certified material can be mixed, while the volume of certified material entering the chain is controlled administratively and an equivalent volume can be sold as certified.[^1][^2]

The UN Global Compact guide says that with the mass balance model certified and non-certified materials can be mixed, but the exact volume of certified material entering the value chain must be controlled, and an equivalent volume of the certified product leaving the chain can be sold as certified.[^1] It says the model is common where segregation is very difficult or impossible and that it is open to criticism for commodities where product segregation is available.[^1]

## In a certification scheme

The Roundtable on Sustainable Palm Oil describes its mass balance supply chain as certified oil from certified sources that is mixed with ordinary palm oil throughout the supply chain.[^3] Its standard says the model administratively monitors the trade of certified oil palm products throughout the chain, allows mixing of certified and non-certified products at any stage provided that overall site quantities are controlled, and rests on reconciliation between the quantity of certified products bought and the quantity sold.[^2] It adds that mass balance can only be operated at site level, so claims cannot be transferred from site to site.[^2]

## In law

Directive (EU) 2018/2001 on renewable energy requires economic operators to use a mass balance system that allows consignments of raw material or fuels with differing sustainability and greenhouse gas emissions saving characteristics to be mixed, for instance in a container, processing or logistical facility, or site.[^4] The Directive's wording also requires that the balance be achieved over an appropriate period of time.[^4]

## Scope and limits

Mass balance is one of the models at [[Chain of Custody Model]]. Because physical identity is not preserved, a mass balance claim concerns volumes and not a particular consignment. The sources are one guide, one certification standard and one directive on bioenergy, so the details of the rules differ by scheme and this page states the shared principle only.

[^1]: United Nations Global Compact and BSR, 2014, “A Guide to Traceability: A Practical Approach to Advance Sustainability in Global Supply Chains”. https://www.unglobalcompact.org/docs/issues_doc/supply_chain/Traceability/Guide_to_Traceability.pdf
[^2]: Roundtable on Sustainable Palm Oil, RSPO-STD-T05-001 V1.1, “RSPO Supply Chain Certification Standard”. https://rspo.org/wp-content/uploads/rspo-std-t05-001-v1.1-eng_scc-standard-june-2017_.pdf
[^3]: Roundtable on Sustainable Palm Oil, Supply chains. https://rspo.org/?p=135
[^4]: European Parliament and Council of the European Union, Directive (EU) 2018/2001 of 11 December 2018, “Directive (EU) 2018/2001 of the European Parliament and of the Council on the promotion of the use of energy from renewable sources”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32018L2001

