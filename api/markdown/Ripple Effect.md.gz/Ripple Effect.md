Ripple effect is the propagation of a disruption through a supply chain, so that a failure at one point spreads to others and changes how the whole chain performs.[^1]

Dolgui, Ivanov and Sokolov state that the ripple effect describes the impact of a disruption propagation on supply chain performance and on the disruption-based scope of changes in supply chain structural design and planning parameters.[^1] They say they delineate the major features of the ripple effect as compared to the bullwhip effect, which is a separate topic at [[Bullwhip Effect]].[^1] Only their abstract was opened here, so the features they set out are not reported.

## Related findings

A 2025 preprint on stress testing says that supply chains' increasing globalization and complexity have recently produced unpredictable disruptions, ripple effects and cascading resulting failures.[^2] AMRO gives an instance from shipping: delays at US ports cascaded through the entire supply chains and contributed to congestion worldwide.[^3] See [[Port Congestion]].

Dolgui and colleagues also describe a ripple effect control framework that includes redundancy, flexibility and resilience analysis, and they review reasons and mitigation strategies.[^1] The corresponding pages in this corpus are [[Supply Chain Redundancy]] and [[Supply Chain Resilience]].

## Scope and limits

Ripple effect belongs with [[Supply Chain Dynamics]]. Dolgui and colleagues compare it with the bullwhip effect, and how the two differ is not reported here because only their abstract was opened.[^1]

Propagation through tiers depends on how well the chain is known, which is the subject of [[Multi-Tier Supply Chain Mapping]]. None of the opened sources quantifies how far or how fast a ripple travels, and the 2025 preprint has not been peer reviewed.

[^1]: Alexandre Dolgui, Dmitry Ivanov and Boris Sokolov, International Journal of Production Research, 2018 (IDEAS/RePEc record, abstract only), “Ripple effect in the supply chain: an analysis and recent literature”. https://ideas.repec.org/a/taf/tprsxx/v56y2018i1-2p414-430.html
[^2]: Madison Smith, Michael Gaiewski, Sam Dulin, Laurel Williams, Jeffrey Keisler, Andrew Jin and Igor Linkov, arXiv preprint 2511.07289 (not peer reviewed), “Reverse Stress Testing for Supply Chain Resilience”. https://arxiv.org/pdf/2511.07289
[^3]: ASEAN+3 Macroeconomic Research Office (AMRO), Analytical Note, 25 July 2022, “The Great Supply Chain Disruption: What Does the Shipping Crystal Ball Foretell?”. https://amro-asia.org/wp-content/uploads/2022/07/AMRO-Analytical-Note_The-Great-Supply-Chain-Disruption_What-Does-the-Shipping-Crystal-Ball-Foretell-_July-25-2022.pdf

