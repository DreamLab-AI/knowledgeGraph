Nearshoring is the relocation of production or other value-added activities to a country that is close to the home country of the firm.[^1][^2]

Pylypenko and Herasymenko define it as positioning all or part of the value-added activities in a country that is geographically, economically and culturally close to the country of origin of the transnational company.[^1] A European Parliament study describes nearshoring as manufacturing being relocated to a country closer to home, and separates it from backshoring, which is manufacturing returning to its initial country of origin.[^2] The OECD describes near-shoring as relocating operations in nearby countries, one of three options for geographic de-risking alongside friend-shoring and re-shoring.[^3]

## Scope and distinctions

Nearshoring differs from [[Reshoring]], where the destination is the home country, and from [[Offshoring]] in general, where no closeness is implied. In a figure of equity divestment, Pylypenko and Herasymenko place nearshoring under relocation to other countries, and place reshoring under relocation to the home country.[^1] The European Parliament study suggests, for the EU, that nearshoring to the Eastern and Southern Neighbourhood could be actively supported by EU trade policy, which shows one reading of nearby in a European setting.[^2] The OECD paper notes a trend towards nearshoring in North America in the 2024 DHL Global Connectedness Index report, based on trade flows, while saying overall globalisation has not given way to regionalisation.[^3] Eurostat lists near-shoring among the names sometimes given to international sourcing.[^4] See [[Supply Chain Configuration Decision]].

## What the sources do not establish

No source opened sets a distance or a list of countries that count as near. The definitions use geographic, economic and cultural closeness, or just closer to home, and they leave the boundary to the user.[^1][^2]

[^1]: N. M. Pylypenko and T. V. Herasymenko, Economics Bulletin (Dnipro University of Technology), 2022, “Reasons and dynamics of reshoring in the European Union and USA”. https://ev.nmu.org.ua/docs/2022/4/EV20224_034-041.pdf
[^2]: European Parliament, Policy Department for External Policies (study requested by the INTA committee), “Post Covid-19 value chains: options for reshoring production back to Europe in a globalised economy”. https://www.europarl.europa.eu/RegData/etudes/STUD/2021/653626/EXPO_STU(2021)653626_EN.pdf
[^3]: OECD, report on supply chain resilience, “Promoting resilience and preparedness in supply chains”. https://www.oecd.org/content/dam/oecd/en/publications/reports/2024/11/promoting-resilience-and-preparedness-in-supply-chains_c0320739/be692d01-en.pdf
[^4]: Eurostat, Statistics Explained glossary entry, “Glossary:Sourcing”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Sourcing

