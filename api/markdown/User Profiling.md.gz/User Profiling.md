User profiling is the construction of a structured model of an individual or segment from observed attributes, behaviours and interaction history, used to predict preferences, intent or risk. Profiles aggregate explicit data such as stated preferences with implicit signals such as clicks, dwell time and purchases, and may be updated continuously as new behaviour is observed. Because profiles concern people, their construction raises consent, fairness and privacy obligations that constrain what may be collected and inferred.

### Overview

- User profiling turns a stream of interactions into a compact, queryable representation of who a user is and what they are likely to want. By combining demographic, contextual and behavioural signals, systems can tailor content, rank recommendations and segment audiences, while ethical and legal frameworks govern how far inference about individuals may go.
- It is modelled as a subclass of [[Behavioural Analytics]] within the artificial-intelligence domain.
- A central design question is whether to model users with interpretable, hand-engineered features or with learned latent representations. Interpretable profiles support auditing, explanation and regulatory compliance, whereas latent embeddings often yield stronger predictive performance but are harder to inspect and justify, which matters when decisions materially affect individuals.
- Profiles must also reconcile two timescales. Long-term preferences are relatively stable and reward accumulation of history, while session-level intent shifts rapidly and can contradict the long-term picture; effective systems blend both so that a user researching an atypical purchase is not permanently mischaracterised.

### Key aspects

- Signal sources: explicit preferences, implicit behaviour and contextual signals feed the profile.
- Representation: profiles range from interpretable feature vectors to learned latent embeddings of user state.
- Temporality: short-term session intent is balanced against long-term stable preferences.
- Governance: consent, data minimisation, fairness and the right to explanation constrain profiling.

### Applications

- Personalised recommendation and content ranking.
- Audience segmentation and targeting in marketing.
- Adaptive interfaces and risk or fraud scoring.

### Considerations

- Privacy law and consent frameworks restrict what data may be collected and what inferences may be drawn, especially for sensitive attributes.
- Profiles can encode and amplify bias, so fairness assessment and mitigation are part of responsible profiling.
- Stale or erroneous profiles degrade experience, making refresh, decay and correction mechanisms important.

### Provenance

