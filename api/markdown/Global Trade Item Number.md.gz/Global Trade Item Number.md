The Global Trade Item Number (GTIN) is the GS1 identifier for any made-to-stock product or service, and is used to support trade, meaning pricing, ordering and invoicing.[^1]

GS1 says a company can use a GTIN to uniquely identify all of its trade items, and defines trade items as products or services that are priced, ordered or invoiced at any point in the supply chain.[^2] The General Specifications give a fuller wording: a trade item is any item, product or service, for which there is a need to retrieve predefined information and that may be priced, ordered or invoiced at any point in any supply chain.[^1] The HL7 terminology service, which lists the GTIN as a naming system, describes it as a globally unique identifier of trade items in nearly the same words.[^3]

## Extensions of the number

A GTIN alone identifies a type of product. Two compound identifiers add detail. The GTIN with a batch or lot number is the GS1 identifier for a product grouped by production batch or lot.[^1] The GTIN with a serial number is the GS1 identifier for a serialised product, and a serial number combined with a GTIN uniquely identifies an individual item.[^1] The General Specifications add that a batch or lot number is not part of the unique identification of a trade item.[^1] See [[Batch Number]] and [[Product Serialisation]].

## Scope and distinctions

The GTIN is one of the keys described at [[GS1 Identification Key]]. It identifies products and services, while the [[Global Location Number]] identifies parties and locations and the [[Serial Shipping Container Code]] identifies logistics units.[^4] The General Specifications state that the combination of a GTIN and a serial number does not replace the SSCC as the identifier of a logistic unit.[^1]

## What the sources do not establish

EAN and UPC appear as aliases of this page. None of the sources opened here explains how those names relate to the GTIN, so the page makes no claim about them.[^2][^3] GS1 and the HL7 entry are not fully independent, because the HL7 entry describes the GS1 GTIN. They do show that a health-sector standards body adopts the same wording.[^3]

[^1]: GS1, “GS1 General Specifications Standard”, release 26.0. https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf
[^2]: GS1, “Global Trade Item Number (GTIN)”. https://www.gs1.org/standards/id-keys/gtin
[^3]: HL7 International, “GTIN Global Trade Item Number”, HL7 Terminology (THO) naming system. https://terminology.hl7.org/en/NamingSystem-gtin.json.html
[^4]: GS1, “GS1 identification keys”. https://www.gs1.org/standards/id-keys

