
An access control rule is a rule that permits an agent or role to perform an action on a resource.[^1] visionGraph places it under [[Access Control Policy]] and as part of an [[Execution Context]], which holds its rules through `hasAccessControlRule`.

Two string properties describe a rule. `allowedAction` names the permitted action, such as "read", "write" or "execute", and `restrictedToRole` names the role the rule applies to, such as "auditor" or "owner". Actions, roles and resources are therefore carried as plain values rather than as classes.

A rule is the fine-grained unit of an access policy: the policy states the intent, and each rule grants one action to one role. It sits beside [[Data Handling Policy]], which governs how data is processed, stored and transmitted and is attached to an execution context in the same way.

[^1]: Semantic Agent Communication Community Group, “Security Binding Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/security-binding.ttl

