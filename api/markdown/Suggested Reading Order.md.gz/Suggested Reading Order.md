Suggested Reading Order is a curated navigation guide that sequences the principal pages of the NarrativeGoldmine knowledge graph into a coherent pedagogical path. It maps the intended conceptual dependencies — from foundational web technologies through decentralisation, digital assets, spatial computing, and AI — enabling readers to build understanding progressively across the graph's interconnected topic areas.

### Semantic Classification

### Content

- I have been working on learning, and learning how to store that knowledge for myself and others since 2019 when I stopped being Technical Director of the [[Octave Immersive Research Facility]] which followed on from the [[NICVE Virtual Reality Research Centre]].
- This website contains cross linked, well annotated, deeply cited knowledge across GenAI, Telepresence, Large Scale Display Systems, Distributed Systems, LLMs, Immersive Collaborative Spaces (metaverse), Politics, Law, Social Change, [[Convergence]], [[Technology Disruption Dynamics]] , and all the other things I have [studied for decades](https://scholar.google.com/citations?user=Etx-Au4AAAAJ&hl=en).
- It is increasing in size all the time. If you want upskilling on these things then I can give a physical or remote tour through the subset of knowledge that's right for -your- company or personal research needs. Afterwards, you will get a link to a page on my website which contains the knowledge graph suitable for you to extend and build upon the presentation.
- This graph is also the engine behind another new project we're starting; avatar based conversational agents backed by this knowledgebase, under [[DreamLab Creative Technology Collective]]

# Suggested Order

- I originally started this [as a book.](https://arxiv.org/abs/2207.09460), so there **is** a natural reading order of sorts. I am still working on making this more of a "flow" so if it looks wrong just skip about. Some of these high level pages are dozens of pages each, and there are hundreds of such pages, with only a few highlighted here.
- There's possibly around 1000 book equivalent pages overall.
  - [[Introduction to me]] explains my research at a very high level
  - [[Semantic Web]]
  - [[Semantic Spatial Web Layer]]
  - [[Decentralised Web]]
  - [[AI Governance Law and Privacy]]
  - [[Blockchain]]
  - [[Ethereum]]
  - [[Bitcoin Proof-of-Work Protocol]]
  - [[Lightning and Similar L2]]
  - [[BTC Layer 3]]
  - [[RGB]]
  - [[Nostr protocol]]
  - [[Digital Asset Risks]]
  - [[NFTs]]
  - [[Digital Objects]]
  - [[Bitcoin As Money]]
  - [[Money]]
  - [[Distributed Identity]]
  - [[NFTs]]
  - [[Digital Objects]]
  - [[Metaverse and Telecollaboration]]
  - [[Definitions and frameworks for Metaverse]]
  - [[Spatial Computing Paradigm]]
  - [[Spatial Embodiment Harm Taxonomy]]
  - [[Machine Learning Techniques Survey]]
  - [[Proprietary Large Language Models]]
  - [[Proprietary Image Generation]]
  - [[Proprietary Video]]
  - [[Open Generative AI tools]]
  - [[AI Frontier Capability Survey]]
  - [[Adoption of Convergent Technologies]]
  - [[AI Capability Temporal Horizon Framework]]
- This is a very new page and will be subject to a [[Knowledge Artefact Update Cycle]] soon

## Preamble

### Web things

## Decentralisation

## Money and Value

## Identity

## Digital Objects

## Spatial

## Artificial Intelligence

### Provenance

