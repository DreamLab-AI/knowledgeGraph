Collaboration is the coordinated joint activity of two or more agents — human or artificial — working toward shared goals through negotiated division of labour, mutual adjustment, and shared artefact production. In digital and distributed settings it encompasses synchronous and asynchronous communication, collective sense-making, and structured workflows mediated by software systems that maintain shared state and contextual awareness across geographic and organisational boundaries. Effective collaboration depends on social and technical mechanisms for conflict resolution, attribution, version management, and trust; its theoretical foundations draw from Computer-Supported Cooperative Work (CSCW), distributed cognition, and organisational theory. Contemporary collaboration increasingly involves AI agents, immersive shared environments, and decentralised coordination protocols.

### Overview

- Collaboration as a formal research domain emerged with the field of [[Computer-Supported Cooperative Work]] (CSCW) in the late 1980s, which sought to understand and design software systems supporting groups of people working together. The field draws heavily on ethnographic studies of actual work practices, organisational theory, and distributed cognition.
- Why it matters:
  - Modern knowledge work is fundamentally collaborative — virtually no significant product or decision emerges from a single actor working in isolation.
  - Geographic distribution of teams, open-source communities, and cross-organisational partnerships have made digital mediation of collaboration the norm rather than the exception.
  - The emergence of AI agents as collaborative actors (see [[Multi-Agent System]] and [[Agentic AI]]) fundamentally changes the scale, speed, and nature of collaborative work.
- How it works:
  - Collaboration systems maintain a **shared information space** accessible to all participants — documents, task boards, chat histories, calendars.
  - **Awareness mechanisms** (presence indicators, activity feeds, cursor positions in shared editors) let participants know what others are doing and have done.
  - **Conflict resolution** mechanisms manage concurrent edits: [[Operational Transformation]] (OT) and [[Conflict-Free Replicated Data Type]] (CRDT) algorithms reconcile divergent states without locking.
  - Role and permission layers (see [[Access Control]]) govern who can read, write, approve, or administer shared artefacts.
  - Social protocols — turn-taking norms, meeting rituals, decision records — complement technical mechanisms.

### Key Components

- **[[Synchronous Communication]]** — real-time audio/video conferencing, shared whiteboards, live co-editing; requires low-latency infrastructure and presence signalling.
- **[[Asynchronous Coordination]]** — threaded discussions, task assignment, document review workflows; tolerates latency and supports participants across time zones.
- **[[Shared Workspace]]** — a persistent, versioned information environment (wiki, file system, project board) that is the joint product and context of collaboration.
- **[[Version Control]]** — records the history of shared artefacts, enabling attribution, rollback, and branching; exemplified by Git in software development.
- **[[Access Control]]** — role-based or attribute-based permission systems that enforce boundaries on who may perform which actions on shared resources.
- **Awareness systems** — push notifications, activity streams, and presence indicators that reduce coordination overhead.
- **[[Workflow Management]]** — structured processes (approval chains, review gates, escalation paths) that orchestrate the sequence of collaborative activities.
- **[[Conflict-Free Replicated Data Type]] (CRDT)** — data structures enabling multiple replicas to be edited concurrently and merged automatically; foundational for offline-first collaborative editors.
- **[[Operational Transformation]]** — algorithm class transforming concurrent operations on shared documents so that all participants converge to the same state.
- **Social and governance layers** — norms, codes of conduct, decision-making procedures (e.g. RFC processes, consensus rules in open-source communities).

### Mechanisms of Effective Collaboration

- **Shared mental models** — participants develop aligned understandings of goals, roles, and status; CSCW research shows misalignment is a primary failure mode.
- **Grounding** — the process by which collaborators establish and maintain mutual understanding; costly over low-bandwidth channels, critical for complex tasks.
- **Transactive memory** — the distributed cognitive system by which group members know who knows what, enabling efficient knowledge retrieval.
- **Trust and psychological safety** — willingness to take interpersonal risks; precondition for candid knowledge sharing and surfacing of errors.
- **[[Collective Intelligence]]** — emergent problem-solving capacity of a group that exceeds individual capability; influenced by communication patterns, diversity, and social sensitivity.
- **Iterative artefact production** — collaboration often proceeds through successive drafts, prototypes, and reviews rather than one-shot delivery.

### Applications and Use Cases

- **Software development** — distributed teams using Git, pull-request review, CI/CD pipelines, and instant messaging; [[Open Source Software]] communities operating globally with volunteer contributors.
- **Scientific research** — multi-institutional grant projects, preprint sharing, reproducible research pipelines, data repositories; collaboration across disciplines increasingly mediated by [[Knowledge Graph]] and [[Linked Data]] infrastructure.
- **Creative production** — co-authoring of documents, films, music, and design artefacts using platforms such as Figma, Notion, and Google Workspace.
- **Enterprise knowledge work** — project management, shared planning tools, enterprise social networks, and meeting platforms (Microsoft Teams, Slack, Zoom).
- **[[Telecollaboration]]** — real-time collaboration across geographic distance exploiting broadband networks; increasingly immersive via [[Social VR]] and [[Extended Reality]].
- **AI-assisted collaboration** — AI meeting summarisers, code completion agents, automated task routing, and document drafting tools that act as collaborative participants; leading toward [[Human-AI Teaming]].
- **Decentralised governance** — [[Decentralised Autonomous Organisation]] (DAO) structures use on-chain voting and smart contracts to enable permissionless, global collaboration on shared treasuries and codebases.
- **Crisis and emergency response** — multi-agency incident rooms, shared situational-awareness platforms, and collaborative intelligence fusion under time pressure.

### Standards and Context

- **[[W3C (World Wide Web Consortium)]]** — ActivityPub (W3C Recommendation) defines a federated social protocol enabling interoperable collaboration across independent server instances; WebRTC standardises browser-based real-time communication.
- **[[IEEE (Institute of Electrical and Electronics Engineers)]]** — IEEE 2941 (AI Model Representation Standard) and IEEE P2510 (data quality for collaborative AI) address machine-readable collaboration artefacts.
- **[[ISO (International Organization for Standardization)]]** — ISO 9241-11 (usability) and ISO 9241-210 (human-centred design) inform the design of collaborative user interfaces; ISO/IEC 25010 covers quality models applicable to groupware.
- **IETF** — RFC 7252 (CoAP), RFC 6120 (XMPP), and RFC 4880 (OpenPGP) provide protocol building blocks for secure collaboration messaging.
- **OASIS** — defines CMIS (Content Management Interoperability Services) for cross-system document collaboration; OData for shared data access.
- **Research community** — ACM CSCW and ACM CHI conferences are the primary venues for empirical and design research on collaboration systems.
- **Open-source governance models** — Apache Software Foundation, Linux Foundation, and OpenSSF define structured governance frameworks for large-scale, distributed open collaboration.

### Provenance

