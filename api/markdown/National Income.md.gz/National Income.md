National income is the total income earned by a country's residents — wages, profits, rent, and interest — from the production of goods and services over an accounting period, whether that production occurs at home or abroad. It is measured within the system of national accounts, where gross national income equals gross domestic product plus net factor income from overseas, and net national income further deducts depreciation of the capital stock, making it the income-side counterpart to output measures of economic activity.

### Semantic Classification

### Content

## Definition

**National income** is the aggregate income accruing to a country's residents from productive activity in a given period. Where [[Gross Domestic Product]] measures the value of output produced *within* a territory, national income follows the *ownership* of the factors of production: it adds income that residents earn abroad (repatriated profits, cross-border wages, investment income) and subtracts income generated domestically but paid to non-residents. The two perspectives are reconciled in the system of national accounts (SNA), the internationally standardised framework maintained by the UN, IMF, OECD, World Bank, and Eurostat.

The family of measures runs from gross to net. Gross national income (GNI, formerly GNP) equals GDP plus net primary income from the rest of the world. Deducting consumption of fixed capital yields net national income (NNI), and adjusting to factor cost — removing indirect taxes and adding subsidies — gives national income in its classical sense: the sum of wages and salaries, corporate profits, rental income, net interest, and proprietors' income. Because production, income, and expenditure are three views of the same circular flow, these accounts must balance in principle, and the statistical discrepancy between them is itself a published quality indicator.

National income matters practically as well as analytically. GNI per capita is the World Bank's criterion for classifying economies into income groups, which in turn gates concessional lending and aid eligibility; EU member-state contributions are levied partly on GNI; and the divergence between GDP and GNI is a standard diagnostic for economies with large multinational sectors, most famously Ireland, where profit-shifting by foreign-owned firms inflates GDP well above the income actually accruing to residents.

## Technical Details

Measurement proceeds by three routes that should agree: the income approach (summing factor incomes from tax and survey data), the production approach (value added by industry), and the expenditure approach (consumption, investment, government spending, net exports). Real national income is obtained by deflating nominal figures with an appropriate price index, since [[Inflation]] otherwise overstates growth in the income aggregate. Known limitations mirror those of GDP: household and informal production are undercounted, environmental depletion is not netted off (motivating adjusted measures such as green NNI and the UN's inclusive wealth accounts), and distribution is invisible in the aggregate — prompting the distributional national accounts programme, which allocates national income across the household distribution to link macro totals with inequality statistics.

## Current Landscape

- The UN Statistical Commission adopted the **2025 SNA** at its 56th session in March 2025 as the new international standard for national accounts, superseding the 2008 SNA; the formally edited publication follows in 2026, and countries are targeted to implement it within a 2029–2030 window.
- The 2025 SNA was endorsed alongside the **seventh edition of the Balance of Payments Manual (BPM7)**, keeping national accounts and external-sector statistics fully aligned worldwide.
- The revision gives greater prominence to **net income measures**: the volume change of net domestic product is identified as the conceptually preferred measure of economic growth, used alongside (not replacing) GDP — directly relevant to the gross-versus-net distinctions in the national income family.
- Distributional national accounts move into the core framework, with new standard breakdowns of disposable income, final consumption, saving, and wealth by income and wealth decile, plus new guidance on crypto-assets, non-fungible tokens, and multinationals' global production arrangements.

  **Sources**:

- https://unstats.un.org/unsd/nationalaccount/sna2025.asp
- https://ec.europa.eu/eurostat/web/products-eurostat-news/w/cn-20250409-1
- https://unstats.un.org/UNSDWebsite/statcom/session_56/documents/2025-2-NationalAccounts-E.pdf

