DAI is a decentralised stablecoin issued by the MakerDAO protocol on Ethereum that aims to hold a value close to one US dollar through collateral backing.

### Semantic Classification

### Content

- DAI is generated when users lock collateral assets in MakerDAO smart contracts and borrow DAI against them. The system uses overcollateralisation, liquidation of undercollateralised positions, and stability fees to keep the price near its dollar target.
- Originally backed only by ether, DAI later accepted a wider range of collateral including other tokens and assets connected to off-chain reserves, which broadened its backing while introducing new dependencies.

### Provenance

