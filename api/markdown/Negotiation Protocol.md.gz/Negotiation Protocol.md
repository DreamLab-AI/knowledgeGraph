A negotiation protocol is a formally specified interaction pattern governing how autonomous agents exchange proposals, counter-proposals, and commitments in order to reach agreement over resources, tasks, or joint plans. It defines the permitted message types, turn-taking rules, and termination conditions, separating the public rules of engagement from each agent's private negotiation strategy. Canonical examples include the Contract Net Protocol, alternating-offers bargaining, and the FIPA standardised interaction protocols.

### Semantic Classification

### Content

## Definition

A **negotiation protocol** is the rulebook for automated bargaining. Where [[Negotiation]] names the general activity of reaching agreement between parties with differing interests, a negotiation protocol pins that activity down formally: which messages may be sent (propose, counter-propose, accept, reject, withdraw), in what order, by whom, and under what conditions the interaction terminates with a deal, a failure, or a timeout. The classical multi-agent systems literature insists on separating the *protocol* — public, shared, enforceable — from each agent's *strategy* — private reasoning about what to offer and when to concede.

The best-known example is Smith's Contract Net Protocol (1980), in which a manager announces a task, contractors bid, and the manager awards the contract — a one-round negotiation that remains the backbone of market-based task allocation. Richer protocols include Rubinstein's alternating-offers model, which grounds bilateral bargaining in game theory; monotonic concession protocols with the Zeuthen strategy; and argumentation-based negotiation, where agents exchange justifications as well as offers. The FIPA standards ([[FIPA ACL]]) codified several interaction protocols — Request, Contract Net, English and Dutch auctions — as reusable message-flow specifications for interoperable agent platforms.

Negotiation protocols matter again in the era of LLM-based agents: when autonomous agents from different operators must agree on task hand-offs, resource prices, or API usage, an explicit protocol provides the guarantees that natural-language improvisation cannot — bounded interaction length, unambiguous commitment semantics, and auditability. They are likewise a foundation of automated [[Conflict Resolution]], turning resource contention into structured bargaining rather than deadlock.

## Technical Details

- **Protocol properties**: designers evaluate protocols for guaranteed termination, Pareto efficiency of outcomes, individual rationality, stability (incentive compatibility), simplicity, and communication complexity.
- **Game-theoretic grounding**: alternating-offers bargaining admits subgame-perfect equilibrium analysis; mechanism design asks whether truthful strategies can be made dominant.
- **Multilateral forms**: one-to-many negotiation generalises to auctions; many-to-many to markets and matching protocols.
- **Machine-readable specification**: interaction protocols are specified as finite-state machines, Petri nets, or AUML sequence diagrams, enabling conformance checking of agent implementations.

  ## Current Landscape

- A new generation of agent interaction protocols has emerged for LLM-based systems: Anthropic's **Model Context Protocol (MCP)**, introduced in November 2024, standardises agent-to-tool communication over JSON-RPC 2.0, while Google's **Agent2Agent (A2A) protocol**, released in April 2025, standardises agent-to-agent discovery and task delegation via capability-describing "Agent Cards" and a defined task lifecycle.
- A2A was donated to the **Linux Foundation in June 2025** with more than 50 partners including AWS, Microsoft, Salesforce, and SAP; IBM's Agent Communication Protocol (ACP) is under the same governance, echoing the FIPA-era ambition of vendor-neutral interaction standards.
- A May 2025 survey (arXiv:2505.02279) maps the competing stack — MCP, ACP, A2A, and the decentralised Agent Network Protocol (ANP) — and characterises 2024–2025 as the "protocol-oriented interoperability" phase of multi-agent systems.
- Research directions include negotiation layers with dynamic SLA formation (probe/bid/commit exchanges between agents) and Agent Context Protocols for structured error handling, reviving classical protocol properties — termination, commitment semantics, auditability — for LLM agents.

  **Sources**:

- https://developers.googleblog.com/en/a2a-a-new-era-of-agent-interoperability/
- https://arxiv.org/html/2505.02279v1
- https://www.ibm.com/think/topics/agent2agent-protocol

