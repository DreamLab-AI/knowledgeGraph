The Consumer Price Index (CPI) is a statistical measure that tracks the average change over time in the prices paid by households for a representative basket of consumer goods and services. It is the principal indicator used to quantify inflation, adjust wages and benefits, and inform monetary policy. The index is computed by weighting price observations according to typical household expenditure patterns and rebasing them against a reference period.

### Overview

- CPI is constructed from periodic price surveys across retail outlets and service providers, with each item weighted by its share of household spending. National statistics agencies publish CPI on a regular cadence, and the headline figure is widely reported as the rate of inflation.

### Mechanisms

- A fixed or chained basket of goods and services representing typical consumption
- Expenditure weights derived from household budget surveys
- Price collection across geographic regions and outlet types
- Periodic rebasing to a reference period to maintain comparability
- Variants such as core CPI that exclude volatile food and energy prices

### Applications

- Indexation of wages, pensions and social benefits to preserve purchasing power
- Setting and assessing central bank inflation targets
- Deflating nominal economic aggregates to derive real values
- Escalation clauses in long-term contracts and leases

### Provenance

