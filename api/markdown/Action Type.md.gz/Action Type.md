
An action type is a category of actionable execution unit, declared as `ActionType` in the intent module of the Agent Ontology.[^1] visionGraph places it under [[Schema]] and as part of [[Agent Action]].

An [[Agent Action]] is assigned a type through `hasActionType`. The class has no properties of its own and no fixed members, so it is an extension point: a deployment defines the categories of action that suit it, and agents, policies and ledgers can then group actions by type.

It sits beside [[Intent Type]], which categorises intents in the same module. An intent has an intent type and leads to an action that has an action type, so the two classifications describe the start and the end of the same chain without being the same thing.

[^1]: Semantic Agent Communication Community Group, “Intent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/intent.ttl

