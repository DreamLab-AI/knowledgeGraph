Total landed cost is the total cost of a product once it has arrived at the buyer, made up of the original price and the costs of getting the product there.[^1][^2][^3]

The US International Trade Administration defines landed cost as the total price of a product once it has arrived at the buyer's doorstep, including the original price of the product, insurance, freight, tariffs and taxes, and other fees.[^1] A Trade Talk resource guide from the Michigan State University International Business Center describes landed costs as the total cost of getting a product from the factory to a customer's door, including freight costs, customs clearance fees and insurance costs needed to cross borders.[^2] A Penn State procurement lesson quotes a longer list from a vendor glossary: brokerage and logistics fees, shipping, customs duties, tariffs, taxes, insurance, currency conversion, crating and handling, and adds that not all components are present in every shipment.[^3]

## Use in sourcing

Penn State describes total landed cost as often called dock to dock, meaning all the costs of a purchase, including the purchase price, from the supplier's shipping dock to the buyer's receiving dock.[^3] Its example is a comparison of suppliers: without landed costs purchasing might choose the Chinese supplier as lowest cost, but with them the Mexico option is preferable.[^3] The lesson sets total landed cost beside total cost of ownership and lifecycle costs as three ways to capture all procurement costs, which differ in scale, scope or timeframe.[^3] See [[Total Cost of Ownership]].

## Estimating the figure

The Trade Administration says exporters should always call these figures estimated, because tariffs and taxes can change and a customs broker or shipping company may add charges.[^1] It also notes that many importing countries base tariffs and taxes on the CIF value, where CIF is the Incoterm for cost, insurance and freight.[^1] See [[Incoterms]] and [[Supply Chain Cost Measure]].

## What the sources do not establish

No standards body or dictionary was opened that defines the term. The three lists of components differ, and none includes the cost of holding inventory, so the page does not claim that carrying cost belongs in the figure. The Michigan State guide lists US Commercial Service offices as contacts, so it is not fully independent of the Trade Administration page.[^1][^2][^3]

[^1]: US International Trade Administration, “Determine Total Export Price”. https://www.trade.gov/determine-total-export-price
[^2]: Michigan State University International Business Center and US Commercial Service, “Trade Talk Tuesday Calculate Landed Costs Resource Guide”. https://ibc-static.broad.msu.edu/sites/DEC/PDFs/TradeTalk_LandedCosts.pdf
[^3]: Penn State Smeal College of Business, “Lesson 5: Managing Procurement Costs - Three Models to Consider”, SCM 406 Module 3. https://courses.smeal.psu.edu/scm406dev/module3/2015/12/lesson-5-managing-procurement-costs-three-models-to-consider.html

