A Pedersen commitment is a cryptographic commitment scheme in which a committer binds to a secret value v by computing C = g^v * h^r, where g and h are independent group generators and r is a random blinding factor. The scheme is computationally binding under the discrete logarithm assumption and unconditionally (information-theoretically) hiding, meaning an adversary with unlimited computation cannot determine the committed value from C alone. Crucially, Pedersen commitments are additively homomorphic: the product of two commitments C(v1, r1) * C(v2, r2) equals C(v1+v2, r1+r2), enabling arithmetic on committed values without revealing them. This property makes Pedersen commitments foundational to confidential transactions, range proofs, and zero-knowledge proof systems.

### Overview

- Pedersen commitments solve a fundamental challenge in cryptographic protocols: how can a party prove they have committed to a value without yet revealing it, and how can they later prove the opened value is genuine?
- The scheme achieves this through two algebraic properties:
  - **Hiding**: the commitment C = g^v · h^r is statistically indistinguishable from a random group element when r is chosen uniformly, so C reveals no information about v whatsoever. This is unconditional — even a computationally unbounded adversary cannot recover v from C alone.
  - **Binding**: changing the committed value after publication requires finding a collision in the [[Discrete Logarithm Problem]], which is computationally infeasible for groups of cryptographic size. A committer is therefore bound to a single value once C is published.
- The scheme was proposed by Pedersen in his 1991 paper "Non-Interactive and Information-Theoretic Secure Verifiable Secret Sharing" as part of a [[Verifiable Secret Sharing]] construction.
- Unlike [[Hash Commitment]] schemes (which are computationally hiding but information-theoretically binding), Pedersen commitments swap these security levels: they are computationally binding but information-theoretically hiding. This trade-off is often preferable in protocols where hiding privacy must be preserved even against future quantum adversaries, while binding security only needs to hold computationally during the protocol's lifetime.
- The additive homomorphic property — C(v1, r1) · C(v2, r2) = C(v1+v2, r1+r2) — enables arithmetic directly on committed values without ever decrypting them, which is a cornerstone of modern privacy-preserving cryptography.

### Key Mechanisms

- **Setup (Common Reference String)**
  - Choose a prime-order group G of order q (typically derived from an [[Elliptic Curve Cryptography]] curve such as secp256k1 or Ristretto255).
  - Select two independent generators g and h such that the discrete log log_g(h) is unknown to all parties. This is critical: if any party knows log_g(h), they can break binding.
  - The pair (G, q, g, h) forms the public commitment key.
- **Commit Phase**
  - The committer selects secret value v ∈ Z_q and blinding factor r ∈ Z_q uniformly at random.
  - Computes commitment C = g^v · h^r (in multiplicative notation) or v·G + r·H (in additive [[Elliptic Curve Group]] notation).
  - Publishes C; keeps (v, r) secret.
- **Open Phase**
  - The committer reveals (v, r).
  - The verifier recomputes C' = g^v · h^r and checks C' = C.
- **Additive Homomorphism**
  - Given C1 = g^v1 · h^r1 and C2 = g^v2 · h^r2, the product C1 · C2 = g^(v1+v2) · h^(r1+r2) is a valid commitment to v1+v2.
  - This enables verifiers to check arithmetic relationships between committed values without learning the values themselves.
- **Vector Pedersen Commitments**
  - Generalise to commit to a vector (v1, …, vn) using n+1 generators: C = g1^v1 · g2^v2 · … · gn^vn · h^r. Used extensively in [[Bulletproofs]] and inner-product argument constructions.

### Applications and Use Cases

- **Confidential Transactions ([[Blockchain Privacy]])**
  - [[Confidential Transaction]] schemes (pioneered by Greg Maxwell for Bitcoin and deployed in [[Monero]] via RingCT, and in MimbleWimble-based chains like Grin and Beam) use Pedersen commitments to hide transaction amounts while allowing network validators to verify that no coins are created from nothing (sum-to-zero checks exploit the homomorphic property).
- **[[Range Proof]] Systems**
  - To prevent negative balances or overflow in confidential transactions, [[Range Proof]] protocols prove that a committed value v lies in [0, 2^n) without revealing v. [[Bulletproofs]] and Bulletproofs+ are efficient range proof constructions built directly on vector Pedersen commitments.
- **[[Zero-Knowledge Proof]] Protocols**
  - Pedersen commitments are a building block in [[Sigma Protocol]] structures, [[Non-Interactive Zero-Knowledge]] proofs via the Fiat-Shamir transform, and polynomial commitment schemes used in STARKs and zk-SNARKs.
- **[[Secure Multiparty Computation]]**
  - In MPC protocols, Pedersen commitments allow parties to commit to their secret inputs before revealing them, preventing adversarial adaptation of inputs after seeing others' commitments.
- **[[Verifiable Secret Sharing]]**
  - Feldman's and Pedersen's own VSS schemes use commitments to allow shareholders to verify their shares are consistent without revealing the secret, foundational to distributed key generation (DKG) in threshold cryptography.
- **[[Digital Signature]] Schemes**
  - The [[Schnorr Protocol]] nonce commitment step uses a Pedersen-like structure. Modern threshold Schnorr schemes (e.g. FROST) use Pedersen commitments for binding participants to their nonce contributions.
- **Anonymous Credential Systems**
  - [[Privacy-Preserving Protocol]] systems such as CL signatures and BBS+ signatures rely on Pedersen vector commitments to encode attribute sets that can be selectively disclosed in zero-knowledge.
- **Voting and Auction Protocols**
  - Electronic voting schemes use commitments to seal ballots before tallying; the homomorphic property allows encrypted votes to be tallied without decrypting individual ballots.

### Security Properties

- **Computational Binding** — security reduces to the hardness of the [[Discrete Logarithm Problem]] in the underlying group. A cheating committer who can open C to two different values (v, r) and (v', r') would know log_g(h), which is assumed infeasible.
- **Unconditional (Perfect) Hiding** — for any committed value v, there exists a blinding factor r such that C = g^v · h^r equals any target group element. The distribution of commitments is independent of v, so C reveals zero information.
- **Post-Quantum Considerations** — Pedersen commitments are insecure against a quantum adversary with access to Shor's algorithm, which solves the discrete log problem in polynomial time. Research into lattice-based commitment schemes (e.g. Ajtai commitments) explores post-quantum alternatives that preserve homomorphism.
- **Trusted Setup Requirement** — the generators g and h must be chosen such that log_g(h) is unknown. Schemes using a [[Random Oracle]] (hash-to-curve) or verifiable random beacons ensure this without a trusted third party.

### Variants and Extensions

- **Pedersen Hash** — a collision-resistant hash function C(v) = g^v · h using a fixed blinding factor, used in Zcash's Sapling circuit.
- **Vector Pedersen Commitment** — commits to a tuple of values simultaneously using multiple generators, the foundation of [[Bulletproofs]].
- **KZG Polynomial Commitment** — a pairing-based extension enabling succinct openings at arbitrary points; shares the Pedersen philosophy of hiding-then-reveal but uses bilinear pairings rather than discrete logs alone.
- **Lattice-Based Commitments** — Ajtai-style commitments over module lattices preserve additive homomorphism and are conjectured post-quantum secure, an active research direction.
- **Generalised Pedersen (GSW)** — extensions over groups with efficiently computable pairings support multiplication of committed values, bridging towards fully [[Homomorphic Encryption]].

### Standards and Context

- No single ISO or IETF RFC specifically standardises Pedersen commitments, but they appear in:
  - **IETF draft-irtf-cfrg-voprf** — verifiable oblivious PRF constructions referencing Pedersen-style binding.
  - **BIP-0340 (Schnorr/Taproot)** — Bitcoin's Schnorr signature standard uses the same discrete-log group and commitment discipline.
  - **MimbleWimble protocol specification** — defines confidential transaction rules based on Pedersen commitment balancing.
  - **Bulletproofs paper (Bünz et al., 2018)** — the canonical specification for range proofs over Pedersen vector commitments.
  - **NIST PQC standardisation** — indirectly drives research into post-quantum commitment alternatives.
- Deployed in production systems: [[Monero]] (RingCT), Grin, Beam, Liquid Network (Bitcoin sidechain), and zkVM proving systems such as RISC Zero.

### Provenance

