Incoterms are rules published by the International Chamber of Commerce (ICC) that set out internationally accepted definitions and rules of interpretation for the most common commercial terms used in contracts for the sale of goods.[^1]

The ICC says the rules were first published in 1936, that Incoterms 2020 entered into force on 1 January 2020, and that they are recognised by UNCITRAL as the global standard for interpreting the most common terms in foreign trade.[^1] It describes them as standards for international and domestic contracts, whose purpose is to avoid misunderstandings by clarifying the tasks, costs and risks in delivery from sellers to buyers.[^1]

## Structure of the 2020 rules

The US International Trade Administration describes 11 rules in Incoterms 2020, grouped into two categories reflecting modes of transport.[^2] It lists seven for any mode of transport, among them Delivered Duty Paid, and four for sea and inland waterway transport, among them Free on Board.[^2] See [[Free on Board]] and [[Delivered Duty Paid]]. Each rule states which party obtains export and import clearance, who contracts for carriage, who provides insurance, when delivery takes place and when the risk of loss or damage passes from seller to buyer.[^2]

## Scope and distinctions

Incoterms are a [[Trade Term]] family, not a customs instrument. The International Trade Administration says they do not address all the conditions of a sale, identify the goods or the price, set the method or timing of payment, or settle when title passes.[^2] They also leave documents needed for customs clearance in the buyer's country and liability for late or non-conforming delivery to the contract.[^2]

A party may still use an earlier edition by specifying it in the contract.[^2] The International Trade Administration notes that the latest version is published by the ICC and protected by copyright, so this page names and characterises the rules without reproducing them.[^2]

The International Trade Administration also says that terms of sale and Incoterms do not determine the type of export transaction under US Census Bureau foreign trade regulations, because they have no regulatory basis.[^2] The ICC is itself covered at [[International Chamber of Commerce]].

## What the sources do not establish

No opened source gives the full wording of any individual rule, since that text is ICC copyright and was not read. They also give no count of how widely each rule is used.

[^1]: International Chamber of Commerce, Incoterms rules page. https://iccwbo.org/business-solutions/incoterms-rules/
[^2]: International Trade Administration (US Department of Commerce), “Know Your Incoterms”. https://www.trade.gov/know-your-incoterms

