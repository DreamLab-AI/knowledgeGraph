Supplier relationship management (SRM) is the management of a buyer's relationships with its suppliers across the course of the relationship, treating different types of supplier differently, with the closest partners given the most collaborative treatment.[^1][^2][^3]

Moeller, Fassnacht and Klose say purchasing is the gateway between external suppliers and the internal functions that create and deliver value for customers. They propose an SRM framework adapted from customer relationship management and existing findings in the supplier management literature, noting that arm's-length collaboration suits some suppliers while others should be treated as close partners.[^1]

Klobucar and Erjavec write that appropriate supplier relationship management is important to successful supplier integration and to determining its degree. They note that scholars have developed various frameworks, that no framework suits every organisation, that adopting one guarantees no success, and they propose a three-phase framework allowing greater flexibility and faster adaptation to change, with sufficiently detailed development of selected suppliers and co-creation of value by buyer and suppliers.[^2]

## In government practice

The UK Cabinet Office Sourcing Playbook says that where a department has several important contracts with a single supplier it should adopt a strategic supplier relationship management approach, defined as the practices and behaviours adopted to engage more collaboratively with strategic suppliers to improve delivery of government objectives and increase mutual value beyond that originally contracted.[^3]

See [[Supplier Management]], [[Supplier Selection]], [[Kraljic Portfolio Matrix]] and [[Strategic Sourcing]].

## What the sources do not establish

These three definitions differ in emphasis, and the Lambert and Schwieterman macro-process account could not be opened, so this page does not describe the Global Supply Chain Forum model.[^1][^2][^3]

[^1]: Sabine Moeller, Martin Fassnacht and Sonja Klose, Journal of Business-to-Business Marketing 13(4), 2006 (Australian National University research portal record, abstract), “A framework for Supplier Relationship Management (SRM)”. https://researchportalplus.anu.edu.au/en/publications/a-framework-for-supplier-relationship-management-srm/
[^2]: Tilen Klobucar and Jure Erjavec, Poslovna izvrsnost - Business Excellence 13(2), 2019 (Hrcak record, abstract), “CONTINUOUS SUPPLIER RELATIONSHIP MANAGEMENT FRAMEWORK”. https://hrcak.srce.hr/clanak/333916
[^3]: UK Cabinet Office, Crown copyright (Open Government Licence v3.0), June 2023, “The Sourcing Playbook: Government guidance on service delivery, including outsourcing, insourcing, mixed economy sourcing and contracting”. https://assets.publishing.service.gov.uk/media/64901fcc5f7bb700127fac5e/Sourcing_Playbook_Final.pdf

