
A security context is the set of security-related constraints and guarantees in force while an action executes. The Agent Ontology declares it as `SecurityContext`.[^1]

An [[Execution Context]] reaches it through `hasSecurityContext`. Two datatype properties describe it. `usesTEE` is a boolean recording whether the run takes place inside a trusted execution environment, and `usesKeySlot` is a string naming the key slot used for signing or decryption. The first corresponds to the hardware guarantees described under [[Hardware Root of Trust]], and the second to the keys held by a [[Key Management System]].

The class records which protections apply to a run, not the run itself, and it carries no authentication or authorisation rules of its own. visionGraph therefore places Security Context under [[Security Policy]] and as part of Execution Context.

[^1]: Semantic Agent Communication Community Group, “Execution Context Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/execution-context.ttl

