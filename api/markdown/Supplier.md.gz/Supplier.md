A supplier is an organisation or individual that supplies a product or service to a buyer under an agreement. NIST's glossary gives the systems-engineering wording, taken from ISO/IEC/IEEE 15288: an “Organization or an individual that enters into an agreement with the acquirer for the supply of a product or service”.[^1]

## Definitions in the sources

A second NIST glossary wording, from SP 800-53 Rev. 5, is wider: the supplier is an organisation or individual that enters into an agreement with the acquirer or integrator, and the definition includes all suppliers in the supply chain, developers or manufacturers of systems, system components or system services, systems integrators, vendors, product resellers and third party partners.[^1] Under that wording a reseller and a manufacturer are both suppliers.

The Industrial Ontologies Foundry defines the broader supply chain agent as a person or business organisation who supplies material products or commercial services to other agents in a supply chain.[^2] Its examples treat the supplier as one side of a supply relationship: Bridgestone as supplier to Ford as customer, and engine blocks supplied to Toyota by a specified supplier for a given period, alongside an on-site jet engine inspection service provided to American Airlines by a specific contractor.[^2]

## Scope and distinctions

In this vault Supplier is the general buyer-facing role under [[Supply Chain Organisations]], and more specific roles sit beneath it, such as [[Contract Manufacturer]]. Managing suppliers is covered by [[Supplier Management]] and [[Supplier Relationship Management]]. See also [[Prime Contractor]].

Sources define the role by the agreement between two parties, not by the type of firm.[^1][^2]

## What the sources do not establish

These sources are a United States standards agency, which repeats an international systems-engineering standard, and one ontology, so the page rests on definitions framed for systems acquisition and ontology modelling. The ISO 9000 quality-management definition of supplier was not opened. The sources say nothing about supplier tiers, supplier status or the legal difference between a supplier and a vendor, although the NIST wording lists vendors within suppliers.[^1]

[^1]: NIST Computer Security Resource Center, glossary entry for supplier. https://csrc.nist.gov/glossary/term/supplier
[^2]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

