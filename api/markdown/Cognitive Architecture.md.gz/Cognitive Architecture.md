A cognitive architecture is a formal specification of the fixed computational structures, memory systems, and control mechanisms that together constitute a general-purpose intelligent agent, independent of any particular task or domain. It prescribes how perception, attention, memory retrieval, reasoning, learning, and action selection are integrated into a unified processing cycle, providing a theoretical and engineering framework for building systems that exhibit adaptive, goal-directed behaviour. Classical examples include ACT-R (Adaptive Control of Thought–Rational), SOAR, and LIDA; contemporary variants extend these principles to neural-symbolic hybrids, transformer-based agent frameworks, and large language model scaffolding systems. Cognitive architectures serve simultaneously as psychological theories of the human mind and as blueprints for artificial intelligence systems.

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:hasPart ai:WorkingMemory))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:hasPart ai:LongTermMemory))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:hasPart ai:DeclarativeMemory))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:hasPart ai:ProceduralMemory))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:hasPart ai:Perception))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:hasPart ai:ActionSelection))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:hasPart ai:MetaCognition))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:hasPart ai:ProductionSystem))
## Dependency Relationships
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:requires ai:KnowledgeRepresentation))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:requires ai:Ontology))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:requires ai:MachineLearning))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:dependsOn ai:CognitivePsychology))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:dependsOn ai:ComputationalNeuroscience))
## Capability Relationships
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:enables ai:AgenticAI))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:enables ai:SymbolicReasoning))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:enables ai:AutonomousAgent))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:enables ai:IntelligentTutoringSystems))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:enables ai:CognitiveModelling))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:enables ai:ExplainableAI))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:supports ai:AISafety))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:supports ai:AIAlignment))
## Implementation Relationships
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:implements ai:GlobalWorkspaceTheory))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:implements ai:ReActPattern))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:implements ai:ChainOfThought))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:uses ai:NeuralNetworks))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:uses ai:BayesianInference))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:uses ai:ReinforcementLearning))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:uses ai:AttentionMechanism))
## Reduction Relationships
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:contrastsWith ai:NarrowAI))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:contrastsWith ai:TaskSpecificModel))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:bridgesTo ai:Robotics))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:bridgesTo ai:BrainComputerInterface))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:bridgesTo ai:MultiAgentSystems))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:relatedTo ai:LargeLanguageModels))
    SubClassOf(ai:CognitiveArchitecture
      ObjectSomeValuesFrom(ai:relatedTo ai:NeuroSymbolicAI))

## About
  Cognitive architectures emerged in the 1970s–1980s as an attempt to produce a *unified theory of cognition* — a single computational model explaining the full range of human intelligent behaviour rather than isolated laboratory tasks. The foundational insight, articulated most clearly by Allen Newell in his 1990 *Unified Theories of Cognition*, is that intelligence is not a collection of independent modules but the product of tightly coupled subsystems sharing common [[Working Memory]] structures and a central control cycle. Newell's challenge to cognitive science was explicit: rather than accumulating isolated experimental findings, the field should converge on general computational theories that predict behaviour across the full spectrum of cognitive tasks. The SOAR architecture, developed by Newell, John Laird, and Paul Rosenbloom, was the direct computational embodiment of this programme. John Anderson's ACT-R pursued a parallel path at Carnegie Mellon, grounding its architectural parameters in neuroimaging data and predicting not just which responses humans produce but the latencies and error patterns with which they produce them — a degree of empirical precision that remains unmatched by contemporary neural network models. The practical implication is significant: a cognitive architecture, unlike a [[Narrow AI]] model, does not need to be retrained or redesigned when the task changes. The architecture provides the computational substrate; task knowledge is loaded as declarative and procedural memory content.

  The contemporary relevance of cognitive architectures has been dramatically amplified by the rise of [[Agentic AI]] systems built on [[Foundation Model]]. The 2024 CoALA framework (Sumers, Yao, Narasimhan, and Griffiths) explicitly maps the cognitive architecture literature onto LLM-based agents, identifying four memory types — working (context window), episodic ([[Retrieval-Augmented Generation]] stores), semantic (structured knowledge), and procedural (fine-tuned model weights or system prompts) — and six action categories spanning reasoning, retrieval, external service calls, learning, and social interaction. This mapping reveals that frameworks like LangGraph, AutoGen, and CrewAI are, in a deep sense, engineering reimplementations of principles that cognitive architecture researchers worked out theoretically over fifty years. The correspondence is not coincidental: the [[ReAct Pattern]] (Reasoning + Acting) used in modern [[Agentic AI]] directly parallels SOAR's observe-decide-act cycle, as explicitly noted by Wray, Kirk, and Laird in a 2025 AAAI paper that mapped the SOAR architecture's operator-selection mechanism onto the ReAct prompting pattern. The key difference is implementation substrate: classical cognitive architectures used hand-crafted symbolic rule systems; their modern successors use neural language models as the core reasoning engine. The theoretical questions posed by cognitive architecture research — how do perception, memory, reasoning, and action coordinate? how does learning interact with immediate task performance? — remain the central design questions for LLM agent engineering.

  A critical dimension that distinguishes cognitive architectures from [[Deep Learning]] scaling approaches is their commitment to **architectural transparency**: the components, their interactions, and the control flow are explicitly specified and therefore auditable. This has direct relevance to [[AI Safety]] and [[Explainable AI]]. An ACT-R model of human decision-making produces a structured trace of every cognitive cycle — which memory chunks were retrieved, which production rules fired, which goal was active — enabling verification of the model's behaviour against psychological data and prediction of failure modes. This traceability is absent in end-to-end neural systems. As [[Agentic AI]] systems are deployed in high-stakes domains, the cognitive architecture tradition offers a principled basis for designing agents whose [[Decision Making]] can be audited, tested, and certified — a requirement that is increasingly encoded in regulatory frameworks such as the EU AI Act and DARPA's Explainable AI programme.

## Components / Architecture
  **Memory Subsystems**

  Cognitive architectures distinguish multiple memory stores with different access patterns, capacity limits, and learning dynamics:

- **[[Working Memory]]** — limited-capacity store (approximately 4±1 chunks in human cognitive systems, per Cowan 2001) holding the current focus of attention and active problem context. In ACT-R this is the central workspace where [[Production Rules]] match and fire. In LLM agents, the context window is the functional equivalent, though its capacity (up to 2M tokens in frontier models by 2026) far exceeds human working memory constraints.
- **[[Declarative Memory]]** — long-term store of factual knowledge (episodic and semantic), retrieved via spreading activation (ACT-R) or similarity-based retrieval. Each chunk has an activation value reflecting recency and frequency of use; retrieval probability and latency are predicted by the subsymbolic activation equation, fitting human forgetting curves with quantitative precision. In LLM agents, [[Retrieval-Augmented Generation]] from [[Agent Memory]] vector stores is the functional analog.
- **[[Procedural Memory]]** — compiled knowledge of *how* to do things, represented as condition-action production rules (ACT-R, SOAR) or as fine-tuned weights and system prompt instructions (LLM agents). Production rules fire one at a time (serial bottleneck), matching the human empirical finding that deliberate reasoning is sequential. Chunking in SOAR compiles experience into new productions, analogous to distilling agent reasoning traces into fine-tuned model weights.
- **Perceptual Buffers** — transient registers holding the output of [[Perception]] modules before encoding into working memory. ACT-R's visual and aural buffers model the limited throughput of human sensory systems; the architectural constraint predicts why humans cannot monitor more than one audio stream or read at more than ~250 words per minute under normal conditions.

  **Processing Subsystems**

- **Production System** — the core inference engine, matching condition-action rules against working memory and selecting which rule fires. Conflict resolution (when multiple rules match) uses utility scores in ACT-R; SOAR triggers impasse-resolution subgoaling when selection is indeterminate.
- **Conflict Resolution** — the priority mechanism determining which production fires when multiple match. In ACT-R, utility is a learned expected value function combining immediate reward and learning rate. In SOAR, indeterminate selection automatically creates a subgoal, making hierarchical problem decomposition an emergent property of the architecture rather than an explicitly programmed behaviour.
- **Learning Mechanisms** — subsystems updating memory strength, utility, or content from experience: ACT-R's base-level decay and activation noise model human forgetting; utility learning updates production probabilities via reinforcement-like signals; declarative learning encodes new facts; procedural learning (chunking in SOAR) compiles new rules from subgoal traces.
- **[[Meta-Cognition]]** — the architecture's capacity to monitor and regulate its own processing: detecting retrieval failures, switching strategies when current approach fails, allocating cognitive effort across competing goals. In LLM agents, Reflexion-style self-critique loops implement meta-cognitive monitoring.

  **Canonical Architecture Families**

- **ACT-R** (Adaptive Control of Thought–Rational) — John Anderson, Carnegie Mellon; most empirically validated architecture, with 25+ years of fMRI predictions; subsymbolic activation values predict retrieval latencies and error rates; used as substrate for Carnegie Learning's MATHia intelligent tutoring system deployed to 750,000+ students.
- **SOAR** (State, Operator, And Result) — Newell, Laird, Rosenbloom; universal impasse-subgoal mechanism for all problem-solving; chunking compiles experience; SOAR 9+ integrates reinforcement learning and episodic memory; deployed in military simulation systems and robotic control.
- **LIDA** (Learning Intelligent Distribution Agent) — Stan Franklin; inspired by [[Global Workspace Theory]]; attention-based broadcast to specialised codelets implements a computational theory of consciousness; emphasises the role of temporal dynamics in cognition.
- **CLARION** — dual-process architecture with explicit (symbolic) top-level and implicit (connectionist) bottom-level interacting bidirectionally; models the interaction of deliberate reasoning and intuitive skill; directly instantiates [[Neuro-Symbolic AI]] principles.
- **Sigma** — factor-graph-based architecture from USC ICT; unifies cognitive architecture with [[Probabilistic Graphical Models]]; aims for a common language capable of expressing both symbolic and probabilistic reasoning.
- **CoALA / LLM-Cognitive Architectures** — emerging frameworks (Sumers et al. 2024, Wray et al. 2025) organising LLM agents on classical cognitive architecture dimensions; translating 50 years of architecture theory into the engineering vocabulary of [[Agentic AI]] frameworks.

  ## Use Cases / Major Families
  **Cognitive Modelling and Psychology Research**

  The foundational application of cognitive architectures is simulating human performance to generate testable predictions and advance basic science. ACT-R models of memory recall match latency data to within 10–20 ms in well-constrained paradigms; SOAR models predict problem-solving protocols in cryptarithmetic and the Tower of Hanoi. The International Conference on Cognitive Modelling (ICCM) is the primary venue for this application.

  **[[Intelligent Tutoring System]]**

  ACT-R underlies Carnegie Learning's MATHia platform, which has served over 750,000 students in US middle-school mathematics. The architecture models each student's knowledge state as a vector of production-rule mastery estimates, updated via Bayesian knowledge tracing; instructional interventions are selected to target productions at the boundary of mastery. Randomised controlled trials (Ritter et al. 2007; Pane et al. 2014) showed MATHia students gained approximately 1.3 additional months of learning per school year compared to traditional instruction — one of the strongest effect sizes in educational technology.

  **Autonomous Robotics**

  SOAR and ACT-R have been deployed on mobile robot platforms (SOAR-ROS integration, ACT-R/E embedded systems) providing unified perception-to-action pipelines. Military unmanned vehicle platforms (US Army's SOAR-based autonomous convoy research, DARPA robotics programmes) have used cognitive architectures to provide human-like adaptability under novel conditions that deterministic control systems cannot handle.

  **[[Human-Computer Interaction]] and UX**

  Predictive human performance models built on ACT-R (CogTool, ACT-R/PM, GOMS) estimate task completion times and error rates for interface designs without requiring user studies. The KLM (Keystroke Level Model) — a simplified cognitive architecture derivative — has been used in HCI since 1980 to predict interface interaction time; its predictions remain within 20% of empirical times for routine tasks. These tools are used by companies including Google and Microsoft for pre-release interface evaluation.

  **[[Agentic AI]] Scaffolding**

  The deepest contemporary application of cognitive architecture principles is the design of LLM-based agentic systems. The cognitive architecture perspective reveals architectural choices that engineering intuition often misses: the serial bottleneck in production firing explains why LLM agents benefit from structured step-by-step [[Chain of Thought]] reasoning rather than producing answers in one pass; the chunking mechanism explains why fine-tuning on agent trajectories compresses procedural knowledge into model weights; the impasse-subgoal mechanism explains why recursive orchestrator-subagent patterns improve complex task performance; the declarative activation model explains why [[Retrieval-Augmented Generation]] retrieval quality degrades when the vector store grows beyond the architecture's implicit capacity limits.

  **[[Brain-Computer Interfaces]]**

  Cognitive architectures provide the computational substrate for BCI systems requiring integrated perception-to-action loops under real-time constraints. Projects including the DARPA Neural Engineering System Design programme use cognitive architecture principles to design intent-decoding algorithms that respect the serial and capacity constraints of human attention.

  **Defence and Simulation**

  Military simulation platforms (OneSAF, JSAF, VBS3) use cognitive architectures to generate realistic synthetic human behaviour in large-scale training scenarios. The key requirement is behavioural plausibility under resource and time stress — exactly the regime where cognitive architectures outperform both rule-based scripting (too rigid) and unconstrained neural generation (too unpredictable for safety-critical simulation).

  ## Academic Context
  The intellectual lineage of cognitive architectures runs from the 1956 Dartmouth Summer Research Project — where Allen Newell and Herbert Simon demonstrated that digital computers could exhibit reasoning behaviour analogous to human problem-solving — through the development of the General Problem Solver (Newell and Simon 1957), the creation of production system languages (Newell 1973), and the publication of Newell's *Unified Theories of Cognition* (1990), which set the formal agenda that ACT-R and SOAR subsequently pursued. Anderson's ACT* (1983) introduced subsymbolic activation parameters that made the architecture's predictions quantitatively precise and neurologically grounded; ACT-R (1993) and subsequent versions up to ACT-R 7.0 (2014) refined these parameters against increasingly large bodies of experimental data, including fMRI localisation studies that matched each ACT-R module to a specific brain region (prefrontal cortex for the procedural system, hippocampus and basal ganglia for declarative retrieval, etc.).

  The [[Global Workspace Theory]] (Baars 1988), developed in parallel in cognitive neuroscience, posited that consciousness and high-level cognitive integration arise from a centralized workspace that broadcasts selected information to a diverse coalition of specialised, unconscious processors — a formulation that maps directly onto LIDA's attention-codelets-broadcast mechanism and anticipates the [[Attention Mechanism]] of [[Transformer Architecture]]-based systems. The GWT-AI connection has been revived by recent work: a 2024 embodied GWT agent demonstrated improved audiovisual navigation through workspace-mediated attention, and a 2025 real-time GWT framework proposed selection-broadcast cycles for dynamic environment management, suggesting GWT may provide useful architectural constraints for next-generation agentic systems.

  The CoALA framework (Sumers, Yao, Narasimhan, Griffiths, TMLR 2024) is the most influential recent synthesis. It reviewed 25+ LLM-based agent papers and systematically mapped their architectural decisions onto the cognitive science vocabulary, revealing that the field had independently rediscovered the memory taxonomy (working/episodic/semantic/procedural) and action taxonomy (internal reasoning, external environment interaction, memory read/write, learning) that cognitive architecture researchers had formalised over decades. This convergence is theoretically significant: it suggests that the cognitive architecture framework captures a domain-general structure of intelligent behaviour that emerges regardless of the implementation substrate.

  ## Current Landscape (2026)
  As of mid-2026, cognitive architecture research is experiencing a renaissance driven by two converging trends: the practical demands of making [[Agentic AI]] systems reliable and interpretable, and the theoretical ambition to understand how general intelligence works at a computational level. The AAAI 2025 symposium on cognitive architectures attracted the highest attendance in a decade, with sessions devoted to LLM-cognitive architecture integration, neuro-symbolic cognitive systems, and the use of cognitive architecture principles in [[AI Safety]] research.

  The IBM Neuro-Vector-Symbolic Architecture (NeuroVSA) programme exemplifies industry investment in cognitive architecture-inspired AI: the architecture combines vector-symbolic representations (enabling graded, robust pattern matching analogous to distributed memory activation in ACT-R) with symbolic reasoning modules (enabling logical inference analogous to production-rule firing), producing hybrid systems that inherit the strengths of both approaches. IBM frames NeuroVSA as a pathway toward artificial general intelligence, directly invoking the cognitive architecture tradition's goal of building systems that generalise across tasks.

  [[Neuro-Symbolic AI]] more broadly has gained significant momentum in 2025–2026 as a response to hallucination problems in [[Large Language Model]]. Where pure neural systems struggle to maintain strict logical consistency across extended reasoning chains, neuro-symbolic architectures that embed a symbolic reasoning module alongside the neural generation component can provide formal guarantees for specific inference steps. This is exactly the integration that CLARION pioneered theoretically — the combination is now being pursued industrially by IBM Research, DeepMind's AlphaGeometry system, and the MIT-IBM Neuro-Symbolic Concept Learner.

  The [[DARPA XAI Programme]] (Explainable AI, 2017–2021), DARPA's Lifelong Learning Machines (L2M) programme, and DARPA Machine Common Sense (MCS) programme collectively funded over $200 million in cognitive architecture-adjacent research, with the explicit goal of producing AI systems whose reasoning is interpretable and whose knowledge accumulates incrementally across tasks — properties that the cognitive architecture tradition had been pursuing for thirty years. The subsequent DARPA AI Forward programme (2024) continues this investment with a focus on AI systems that can explain their reasoning to human operators in novel operational contexts.

  Performance of classical cognitive architectures on benchmark tasks has been substantially updated by hybrid approaches: ACT-R models augmented with [[Neural Networks]] for perception and pattern matching (ACT-R/Phi and related hybrid variants) show improved performance on natural image recognition and language understanding tasks while retaining the interpretability and psychological plausibility of the classical architecture. SOAR with deep reinforcement learning for operator evaluation shows improved performance on Atari games and continuous-control robotics tasks.

  ## UK Context
  The United Kingdom has significant academic and industrial presence in cognitive architecture and related fields, distributed across both classical cognitive science institutions and contemporary AI research centres.

  **University of Edinburgh** is the UK's most significant centre for cognitive architecture-related research. The School of Informatics — the largest informatics department in Europe — hosts research groups in automated reasoning, constraint satisfaction, symbolic AI, and neuro-symbolic integration that directly inform cognitive architecture design. Edinburgh's [[Natural Language Processing]] group has contributed foundational work on language understanding that has been incorporated into hybrid cognitive architectures. The Cognitive Science MSc at Edinburgh provides one of the few UK graduate programmes explicitly grounding AI engineering in cognitive architecture theory, covering ACT-R, SOAR, and their contemporary LLM analogues. The Human Communication Research Centre (HCRC, Edinburgh-Glasgow) produced foundational work on grounded language use and collaborative reference resolution that informs the perception and communication modules of social cognitive architectures.

  **University of Manchester's** School of Computer Science hosts substantial research in symbolic AI, [[Knowledge Representation]], and ontology — the formal knowledge engineering disciplines that provide the declarative memory substrate for classical cognitive architectures. Manchester's historically strong Knowledge Media Institute lineage and the current MLPS (Machine Learning and Physics in Science) group contribute to the theoretical foundations of neuro-symbolic integration. Manchester was named the UK's most AI-ready city by the SAS AI Cities Index in both 2024 and 2025, reflecting the concentration of AI research and industry infrastructure in the region.

  **UCL's** Department of Computer Science, ranked first in England for research power in REF 2021, contributes to cognitive architecture-relevant research through its Computational Cognitive Neuroscience group, which uses formal modelling frameworks (including ACT-R-inspired models) to explain human memory and decision-making data. UCL's Gatsby Computational Neuroscience Unit has long contributed theoretical frameworks — particularly Bayesian approaches to perception, learning, and [[Decision Making]] — that inform the subsymbolic components of modern cognitive architectures.

  **Imperial College London's** Department of Computing contributes work on formal verification of agent behaviour, planning algorithms, and explainability — directly relevant to the auditability requirements that cognitive architecture-based systems naturally satisfy. Imperial's Data Science Institute and the White City Deep Tech Campus (where a Lenovo-Imperial AI Technology Centre was established in early 2026) provide a bridge between academic cognitive architecture research and industrial deployment.

  In Northern England, **Leeds** and **Sheffield** both host research relevant to cognitive architectures. Sheffield's GATE (General Architecture for Text Engineering), one of the most widely deployed text-processing frameworks globally, implements a pipeline architecture for NLP that shares structural principles with cognitive architecture's modular processing design. The GATE platform has been integrated into public-sector text analytics pipelines in the UK's NHS Digital and HMRC systems. Leeds' Institute for Data Analytics (LIDA — a coincidental acronym with Franklin's LIDA cognitive architecture) contributes data-intensive cognitive modelling research.

  UK industrial investment in cognitive architecture principles is concentrated in defence, public sector, and financial services. BAE Systems Applied Intelligence and Dstl (Defence Science and Technology Laboratory) have funded cognitive architecture research for autonomous system behaviour modelling and intelligence analysis. NHS Digital's AI adoption programme has explored cognitive architecture-based clinical decision support, though deployment at scale remains limited as of 2026. The UK AI Safety Institute, established in 2023, has commissioned research on interpretable AI systems — a domain where cognitive architectures offer natural advantages due to their structural transparency.

  ## Future Directions (2026-2030)
  The convergence of classical cognitive architecture theory with contemporary LLM-based agent engineering is expected to accelerate significantly over the next four years, driven by three forces: the practical need for reliable, interpretable agentic systems; the regulatory push for explainable and auditable AI; and the theoretical maturation of the neuro-symbolic integration agenda.

  By 2027, the distinction between "cognitive architecture research" and "LLM agent architecture design" is expected to collapse further, as engineering teams building production agent systems adopt the cognitive architecture vocabulary and methodology — formal specification of components, empirical validation against human performance data, modular design that enables systematic variation of individual components. The CoALA framework provides the theoretical foundation for this convergence; subsequent work is expected to produce more detailed mappings between specific cognitive architecture mechanisms (chunking, spreading activation, impasse resolution) and specific LLM agent engineering techniques (trajectory fine-tuning, RAG retrieval weighting, hierarchical orchestration).

  **[[Neuro-Symbolic AI]]** will become the dominant implementation paradigm for cognitive architectures by 2028, replacing the classical dichotomy between purely symbolic architectures (brittle on perception, excellent at reasoning) and purely neural systems (excellent at perception, brittle at reasoning). Hybrid cognitive architectures with neural perception modules, symbolic reasoning cores, and learned utility functions for operator selection will combine the empirical plausibility of classical cognitive architectures with the perceptual robustness of deep learning. IBM's NeuroVSA programme and DeepMind's AlphaGeometry are early indicators of this convergence.

  **Lifelong learning** — the capacity of a cognitive architecture to accumulate knowledge across tasks and environments without catastrophic forgetting of prior knowledge — remains an unsolved problem that is central to the [[General Intelligence]] research agenda. DARPA's L2M programme identified this as a critical capability gap; techniques combining episodic memory consolidation (analogous to hippocampal-cortical transfer in human memory consolidation during sleep) with structural plasticity in the procedural knowledge base are expected to produce meaningful progress by 2028.

  The use of cognitive architecture principles in **[[AI Safety]]** and **[[AI Alignment]]** research is expected to grow substantially. The structural transparency of cognitive architectures makes it possible to specify and verify safety constraints on agent behaviour at the architectural level rather than relying on emergent properties of training. Formal methods for verifying cognitive architecture behaviour (temporal logic specifications, model checking of production rule systems) provide a path toward certified autonomous systems that purely neural approaches cannot currently provide.

  ## Research & Literature
  1. Newell, A. (1990). *Unified Theories of Cognition*. Harvard University Press. ISBN 978-0-674-92101-6.
  2. Anderson, J. R., Bothell, D., Byrne, M. D., Douglass, S., Lebiere, C., & Qin, Y. (2004). An integrated theory of the mind. *Psychological Review, 111*(4), 1036–1060. https://doi.org/10.1037/0033-295X.111.4.1036
  3. Laird, J. E. (2012). *The Soar Cognitive Architecture*. MIT Press. ISBN 978-0-262-01600-2.
  4. Franklin, S., & Graesser, A. (1997). Is it an agent, or just a program? A taxonomy for autonomous agents. *Proceedings of the 3rd Workshop on Intelligent Agents in Agent Theories*. Springer.
  5. Baars, B. J. (1988). *A Cognitive Theory of Consciousness*. Cambridge University Press.
  6. Sumers, T. R., Yao, S., Narasimhan, K., & Griffiths, T. L. (2024). Cognitive architectures for language agents. *Transactions on Machine Learning Research (TMLR)*. arXiv:2309.02427.
  7. Wray, R. E., Kirk, J. R., & Laird, J. E. (2025). Applying cognitive design patterns to general LLM agents. *AAAI Spring Symposium*. arXiv:2505.07087.
  8. Anderson, J. R. (1983). *The Architecture of Cognition*. Harvard University Press.
  9. Newell, A., & Simon, H. A. (1972). *Human Problem Solving*. Prentice-Hall.
  10. Laird, J. E., Newell, A., & Rosenbloom, P. S. (1987). SOAR: An architecture for general intelligence. *Artificial Intelligence, 33*(1), 1–64. https://doi.org/10.1016/0004-3702(87)90050-6
  11. Anderson, J. R., & Lebiere, C. (1998). *The Atomic Components of Thought*. Lawrence Erlbaum Associates.
  12. Sun, R. (2006). The CLARION cognitive architecture: Extending cognitive modelling to social simulation. In *Cognition and Multi-Agent Interaction*. Cambridge University Press.
  13. Itti, L., & Baldi, P. (2009). Bayesian surprise attracts human attention. *Vision Research, 49*(10), 1295–1306. https://doi.org/10.1016/j.visres.2008.09.007
  14. Taatgen, N. A., & Anderson, J. R. (2008). Constraints in cognitive architectures. In *Cambridge Handbook of Situated Cognition*. Cambridge University Press.
  15. Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., & Cao, Y. (2023). ReAct: Synergizing reasoning and acting in language models. *ICLR 2023*. arXiv:2210.03629.
  16. Shinn, N., Cassano, F., Berman, E., Gopinath, A., Narasimhan, K., & Yao, S. (2023). Reflexion: Language agents with verbal reinforcement learning. *NeurIPS 2023*. arXiv:2303.11366.
  17. Cowan, N. (2001). The magical number 4 in short-term memory: A reconsideration of mental storage capacity. *Behavioral and Brain Sciences, 24*(1), 87–114. https://doi.org/10.1017/S0140525X01003922
  18. Baddeley, A., Hitch, G. J., & Allen, R. J. (2025). The multicomponent model of working memory fifty years on. *Quarterly Journal of Experimental Psychology*. https://doi.org/10.1177/17470218241290909
  19. Ritter, S., Anderson, J. R., Koedinger, K. R., & Corbett, A. (2007). Cognitive Tutor: Applied research in mathematics education. *Psychonomic Bulletin & Review, 14*(2), 249–255.
  20. Rao, A. S., & Georgeff, M. P. (1995). BDI agents: From theory to practice. *Proceedings of ICMAS-95*, 312–319.
  21. Sutton, R. S., & Barto, A. G. (2018). *Reinforcement Learning: An Introduction* (2nd ed.). MIT Press.
  22. Fikes, R. E., & Nilsson, N. J. (1971). STRIPS: A new approach to the application of theorem proving to problem solving. *Artificial Intelligence, 2*(3–4), 189–208. https://doi.org/10.1016/0004-3702(71)90010-5
  23. Minsky, M. (1975). A framework for representing knowledge. In P. H. Winston (Ed.), *The Psychology of Computer Vision*, 211–277.
  24. Frontiers in Robotics and AI. (2025). Hypothesis on the functional advantages of the selection-broadcast cycle structure: global workspace theory and dealing with a real-time world. *Frontiers in Robotics and AI*. https://doi.org/10.3389/frobt.2025.1607190
  25. IBM Research. (2025). *Neuro-Vector-Symbolic Architecture (NeuroVSA)*. https://research.ibm.com/projects/neuro-vector-symbolic-architecture
  26. DARPA. (2021). *Explainable Artificial Intelligence (XAI) Programme: Final Report*. Defense Advanced Research Projects Agency.
  27. Sema4.ai. (2026). *Cognitive architecture in AI: How agents learn, reason, and act*. https://sema4.ai/learning-center/cognitive-architecture-ai/

  ## Comparative Architecture Analysis

  The following table situates the canonical cognitive architectures along key architectural dimensions, enabling systematic selection for different application requirements:

| Architecture | Memory Model | Control Strategy | Learning | LLM Integration | Empirical Grounding | Primary Applications |
|---|---|---|---|---|---|---|
| ACT-R 7.x | Declarative (activation-based) + Procedural (rules) + Buffers | Serial production selection via utility | Subsymbolic (activation decay, utility RL) | ACT-R/Phi hybrid; LLM as perception/language buffer | fMRI-validated; predicts RT and accuracy | ITS, cognitive modelling, [[Human-Computer Interaction]] |
| SOAR 9.x | Episodic + Semantic + Procedural + Working | Impasse-subgoal; reinforcement learning for operator selection | Chunking (compile subgoal traces) + RL + episodic | Wray et al. 2025 SOAR-LLM mapping; ReAct-pattern equivalence | Military simulation validation | Robotics, simulation, game AI |
| LIDA | Working + Transient Episodic + Declarative + Procedural + Spatial | Attention competition; GWT broadcast | Learning codelets modify all stores | Prototype integrations at U Memphis | GWT-aligned; consciousness theory | Autonomous agents, narrative generation |
| CLARION | Top-level (explicit symbolic) + Bottom-level (connectionist) | Dual-process; bottom-up action selection with top-down regulation | Combination of rule extraction and RL | Compatible layer substitution for bottom level | Experimental social cognition data | Social simulation, skill acquisition |
| Sigma | Factor graphs (unified probability + logic) | Probabilistic inference over factor graph | Gradient-based variational inference | Module-level integration feasible | USC ICT evaluation datasets | Probabilistic reasoning, multimodal agents |
| CoALA/LangGraph | Working (context) + Episodic ([[Retrieval-Augmented Generation]]) + Semantic (KB) + Procedural (weights) | LLM prompting loop; external tool calls | Fine-tuning; [[Reinforcement Learning]] from human feedback | Native LLM; architecture is the LLM agent | Agent benchmark suites (GAIA, HumanEval, WebArena) | Enterprise agentic systems, coding agents |

## Formal Processing Cycle

The cognitive cycle — the fixed, repeating computational loop that defines a cognitive architecture — can be expressed algorithmically as follows. The specific cycle below is generalised from ACT-R and SOAR to capture the common core across architectures:

```
CognitiveCycle(architecture, environment, goal_stack):
  REPEAT:
    // Perception phase
    perceptual_input ← environment.sense()
    encode perceptual_input → working_memory buffers

    // Memory retrieval phase
    retrieval_cue ← working_memory.current_state()
    retrieved_chunks ← declarative_memory.retrieve(cue=retrieval_cue,
                        activation_threshold=τ,
                        strategy=spreading_activation)
    if retrieval_failure:
      trigger impasse OR generate subgoal

    // Action selection phase
    candidate_productions ← procedural_memory.match(working_memory)
    selected_production ← conflict_resolve(candidate_productions,
                           utility_function=U(p) = PG - C,
                           noise=ε ~ LogisticNoise(s))
    if no_match:
      trigger impasse → subgoal (SOAR) OR error state (ACT-R)

    // Execution phase
    action ← selected_production.execute()
    environment.act(action)

    // Learning phase (post-cycle)
    declarative_memory.update_activation(retrieved_chunks, outcome)
    procedural_memory.update_utility(selected_production, reward)
    if subgoal_resolved:
      chunk subgoal_trace → new production (SOAR chunking)

    // Metacognitive monitoring
    if goal_satisfied(goal_stack.top()):
      goal_stack.pop()
    if goal_stack.empty():
      BREAK
UNTIL task_complete OR resource_exhausted
```

In ACT-R, the utility function U(p) = P × G - C represents the expected value of firing production p: P is the estimated probability of reaching the current goal given p fires, G is the value of the goal, and C is the expected cost. Utilities are updated by a reinforcement-learning rule after each goal completion or failure, providing a principled mechanism for experience-driven optimisation of production selection that matches human data on skill acquisition and strategy discovery.

In LLM agents (CoALA framework), this cycle maps to: the LLM forward pass as the production selection step; the context window as working memory; the [[Retrieval-Augmented Generation]] query as declarative memory retrieval; the tool call or text output as action execution; and fine-tuning on successful trajectories as the learning phase.

## Key Terminology

- **Chunk** — the unit of knowledge in working memory; a collection of slot-value pairs representing a single fact, goal state, or perceptual element. Working memory is limited to approximately 4±1 chunks simultaneously (human systems); each chunk has an activation value governing retrieval speed and probability.
- **Production Rule** — an IF-THEN condition-action pair in [[Procedural Memory]]; the basic unit of procedural knowledge encoding "when this working-memory state holds, perform this action". Production rules encode skills, strategies, and reflexive responses in explicit, inspectable form — enabling auditing and verification.
- **Spreading Activation** — retrieval mechanism in [[Declarative Memory]] whereby activation from working-memory chunks propagates through associative links to related memory chunks, raising their retrieval probability. Models the priming effects observed in human memory experiments (e.g., hearing "doctor" increases retrieval speed for "nurse").
- **Chunking** — in SOAR, the automatic compilation of subgoal traces (sequences of working-memory states and productions that resolved an impasse) into new production rules, encoding the problem-solving episode as a reusable skill. Analogous to fine-tuning an LLM agent on successful reasoning traces.
- **Impasse** — in SOAR, the state reached when conflict resolution cannot select a unique operator; automatically triggers creation of a subgoal to resolve the indeterminacy. The impasse-subgoal mechanism provides hierarchical decomposition as an emergent architectural property.
- **Utility** — in ACT-R, the expected value of a production rule: U(p) = P × G - C (probability of goal success × goal value − estimated cost). Updated by a reinforcement-learning rule after each goal completion, enabling experience-driven optimisation of strategy selection.
- **Global Workspace** — in [[Global Workspace Theory]] and LIDA, the broadcast medium through which one attended piece of information (the winner of the attention competition) is made available to the full set of specialised cognitive processors. Implements the "binding" of disparate cognitive processes into a unified, coherent cognitive episode.
- **Subsymbolic Level** — the numerical parameters underlying symbolic representations: activation values, utility scores, noise parameters. The subsymbolic level implements gradedness, probability, and learning within architectures that use symbolic representations at the knowledge level. ACT-R is unique among cognitive architectures in making its subsymbolic predictions quantitatively testable against human latency data.
- **BDI (Belief-Desire-Intention)** — a cognitive architecture formalism from Rao and Georgeff (1995) representing agents in terms of their beliefs (world state), desires (goals), and intentions (committed plans). BDI is the theoretical basis for the Jason and JACK agent programming languages, and maps onto the goal-stack + procedural-memory structure of ACT-R and SOAR.
- **CoALA memory taxonomy** — the four-way memory classification from Sumers et al. (2024): working memory (LLM context window), episodic memory (interaction history; [[Retrieval-Augmented Generation]] vector store), semantic memory (structured world knowledge; [[Knowledge Graph]]), procedural memory (fine-tuned weights; system prompt instructions).

  ## Ethical, Governance, and Policy Dimensions

  Cognitive architectures occupy a distinctive position in AI ethics and governance because their structural transparency creates both opportunities and risks compared to opaque deep learning systems.

  **Interpretability as a safety property.** The explicit, auditable control flow of cognitive architectures makes them natural candidates for high-stakes autonomous systems where [[AI Safety]] requires understandable agent behaviour. The EU AI Act (effective August 2024, high-risk system requirements phased to 2026) mandates human oversight, logging, and explainability for AI systems in safety-critical domains; cognitive architecture-based systems satisfy these requirements structurally, whereas neural systems require expensive post-hoc [[Explainable AI]] tooling. DARPA's XAI Programme explicitly sought cognitive architecture-compatible explanation approaches; the resulting LIME, SHAP, and concept-based explanation methods are more readily interpreted in the context of a structured cognitive architecture than in a monolithic neural network.

  **Alignment via architectural constraint.** [[AI Alignment]] research increasingly recognises that alignment through training alone (RLHF, Constitutional AI) is fragile for autonomous agents operating over extended horizons. Cognitive architecture principles offer an alternative: alignment constraints can be encoded directly in the architecture as goal structures, utility function definitions, and production rule preconditions that cannot be overridden by learned knowledge. This approach has been explored in the SOAR cognitive architecture's "ethical regulator" module (a specialised set of productions that evaluate candidate actions against ethical constraints before execution) and in BDI agent frameworks with normative reasoning components.

  **Bias and fairness in cognitive models.** Cognitive architectures used as psychological models — particularly [[Intelligent Tutoring System]] deployed at scale — carry the risk that the architecture's training data (typically from particular demographic groups) may produce biased performance models. Carnegie Learning's MATHia system, which uses ACT-R to model individual student knowledge, has been the subject of research on differential performance across demographic groups; ensuring that the architecture's knowledge-tracing model does not perpetuate differential instruction quality is an active research concern in the learning sciences.

  **UK governance alignment.** The UK AI Safety Institute (UKASI, established 2023) has commissioned research on interpretable and accountable AI systems that aligns with cognitive architecture principles. The UK Government's AI Regulation Pro-Innovation Approach (2023 White Paper, updated 2025 AI Opportunities Action Plan) emphasises sector-specific, principle-based regulation rather than prescriptive technical mandates — an approach that accommodates cognitive architecture-based systems more naturally than mandating specific technical transparency mechanisms. The AI Opportunities Action Plan (January 2025) identifies autonomous agent systems as a priority application area, directly relevant to cognitive architecture deployment at scale.

  ## Standards and Certification Context

  **ISO/IEC 42001:2023** (AI Management Systems) establishes requirements for organisations developing or deploying AI, including requirements for human oversight and auditability that cognitive architectures satisfy by construction.

  **IEEE P7001** (Transparency of Autonomous Systems, published 2021) provides a framework for measuring and certifying transparency of autonomous systems across five stakeholder categories; cognitive architectures' explicit production rule traces and goal structures provide natural artefacts for P7001-compliant transparency reporting.

  **DARPA Assurance Standards** applied to autonomous systems in defence contexts require verification of agent behaviour under specified conditions — a requirement that cognitive architecture's formal production system enables through model checking and simulation, while neural network systems require expensive adversarial testing.

  **EU AI Act Risk Classification.** Autonomous systems using cognitive architectures in high-risk categories (medical devices, critical infrastructure, employment decisions, education — Article 6 and Annex III) must meet Conformity Assessment requirements including technical documentation, logging, human oversight, and accuracy verification. Cognitive architectures' structural transparency (explicit goal representations, auditable production rule traces, formally specified memory access patterns) directly satisfies the documentation and logging requirements. [[Agentic AI]] systems using pure LLM backends face greater challenge meeting these requirements without expensive overlay tooling.

  ## Cognitive Architecture and the LLM Agent Engineering Stack

  The proliferation of LLM-based agent frameworks from 2023–2026 has produced a diverse engineering ecosystem in which cognitive architecture principles are instantiated — often without explicit acknowledgment — across a range of open-source and commercial platforms. Understanding the correspondence between the cognitive architecture theory and the engineering vocabulary of these frameworks enables principled evaluation, comparison, and extension of agent systems.

  **LangGraph** (LangChain, 2024) implements a graph-structured agent execution model in which nodes are processing steps and edges are conditional transitions. The graph structure maps directly onto SOAR's problem-space representation, where nodes are problem states, edges are operators, and conditional transitions correspond to operator selection rules. LangGraph's state object is the working memory buffer; the LangChain tool registry is the external action space (CoALA category: "environment interaction actions"); the LangGraph memory store (LangMem) provides episodic and semantic memory via [[Retrieval-Augmented Generation]] and structured storage. LangGraph's human-in-the-loop interrupts map onto ACT-R's goal-suspension mechanism, where processing pauses pending external input before resuming with updated working memory.

  **AutoGen** (Microsoft Research, 2023; AutoGen 0.4 in 2025) implements a multi-agent conversation framework in which agents maintain individual working memories (context windows) and communicate via message-passing. The AutoGen GroupChat manager implements a simplified conflict-resolution mechanism analogous to SOAR's operator selection: determining which agent speaks next in response to the current message. AutoGen's AssistantAgent and UserProxyAgent roles map onto the SOAR architecture's two-level structure — reasoning agent and interface agent — that separates goal-directed reasoning from environmental interaction. AutoGen's teachability mechanism (in-context learning from user corrections) maps onto ACT-R's declarative learning: new facts are encoded as retrievable chunks and used to update future behaviour.

  **CrewAI** (2024) implements a crew-of-agents model in which specialised role agents collaborate on tasks via a shared orchestration layer. The role/goal/backstory agent specification is a simplified version of the BDI formalism (beliefs encoded in context, desires as the role goal, intentions as the task list); the sequential or hierarchical process options map onto SOAR's top-space / subspace structure. CrewAI's memory system (short-term = conversation history; long-term = vector store; entity = extracted entity facts) directly instantiates the CoALA working/episodic/semantic taxonomy.

  **Reflexion** (Shinn et al. 2023) is a prompting-level implementation of [[Meta-Cognition]] in LLM agents: the agent generates an action, receives environmental feedback, produces a verbal self-reflection on what went wrong, stores the reflection in an episodic memory buffer, and uses it to condition future attempts. The Reflexion loop directly mirrors ACT-R's utility learning: after a production (action) fails to lead to goal success, its utility is decremented, reducing its future selection probability. In Reflexion, this is implemented explicitly as natural language self-critique rather than numerical utility update — a more interpretable but less principled mechanism that is more susceptible to sycophantic reflection (the agent generating positively-biased reflections regardless of outcome quality).

  **OpenAI's Operator architecture** (GPT-4o with tool use, 2024–2026) — the model powering ChatGPT's advanced capabilities — implements a cognitive loop in which the model iterates between reasoning steps (internal actions in CoALA vocabulary), tool calls (external environment actions), and working-memory management (via the system prompt and structured outputs). The GPT-4o "o3" reasoning model (2025) extends this with a chain-of-thought pre-reasoning step that mimics SOAR's lookahead search: the model generates a private reasoning trace before producing the final output, effectively simulating the impasse-subgoal mechanism in the forward pass rather than in the architecture's control cycle.

  **Hierarchical agent orchestration** — the pattern of orchestrator agents decomposing tasks into subtasks dispatched to specialised subagents — is the closest LLM-agent engineering approximation to SOAR's impasse-subgoal mechanism. When the orchestrator agent cannot complete a task directly (functional impasse), it creates a subgoal (subtask), delegates to a subagent with appropriate specialisation, and integrates the subagent's output before resuming its own goal-directed processing. This pattern is implemented in AutoGen's nested conversation model, LangGraph's subgraph invocation, and CrewAI's hierarchical process — all independent engineering rediscoveries of a mechanism that Newell, Laird, and Rosenbloom formalised in SOAR in 1987.

  The practical implication of this correspondence is that cognitive architecture theory provides a principled vocabulary for diagnosing failure modes in LLM agent systems. When an agent fails to generalise across tasks, the cognitive architecture framing suggests investigating whether the procedural memory (fine-tuned weights or system prompt) is overfitting to training-task production rules that do not transfer — analogous to the lack-of-transfer failure mode in SOAR systems with overspecialised chunks. When an agent shows poor long-term coherence across extended conversations, the cognitive architecture framing suggests investigating working memory management: whether the context-window (working memory) is overflowing with irrelevant information that interferes with retrieval of goal-relevant chunks — a direct analog to ACT-R's fan effect, where declarative memory retrieval latency increases with the number of facts associated with a retrieval cue.

  ## Historical Timeline

- **1956** — Newell and Simon demonstrate Logic Theorist, the first program exhibiting symbolic reasoning analogous to human problem-solving; Dartmouth Summer Research Project coins the term "artificial intelligence".
- **1957** — General Problem Solver (GPS): first architecture implementing means-ends analysis as a domain-general problem-solving strategy.
- **1972** — *Human Problem Solving* (Newell and Simon): foundational empirical-computational account of human cognition as information processing.
- **1973** — Production system formalism (Newell): establishes condition-action rules as the canonical representation for [[Procedural Memory]] in cognitive architectures.
- **1983** — ACT* (Anderson): introduces subsymbolic activation and learning parameters; establishes the quantitative precision standard for cognitive architecture evaluation.
- **1987** — SOAR (Laird, Newell, Rosenbloom): universal impasse-subgoal; published in *Artificial Intelligence* journal; establishes the production-system control strategy as the standard cognitive architecture control paradigm.
- **1988** — [[Global Workspace Theory]] (Baars): consciousness as broadcast from a shared workspace; theoretical foundation for LIDA and attention-mechanism AI systems.
- **1990** — *Unified Theories of Cognition* (Newell): formal challenge to cognitive science to converge on computational theories spanning all cognitive tasks.
- **1993** — ACT-R: combines ACT* subsymbolic learning with the procedural-declarative memory architecture; becomes the dominant cognitive architecture for psychological modelling.
- **1995** — BDI formalism (Rao and Georgeff): belief-desire-intention framework for rational agents; theoretical basis for JACK and Jason agent programming languages.
- **2001** — MATHia (Carnegie Learning): first large-scale deployment of a cognitive architecture (ACT-R) in an educational product; 750,000+ students by 2010.
- **2006** — CLARION (Sun): dual-process cognitive architecture; first architecture explicitly integrating symbolic (explicit) and connectionist (implicit) processing in a unified system.
- **2012** — *The Soar Cognitive Architecture* (Laird): definitive reference; documents SOAR's extension to include episodic memory, semantic memory, and reinforcement learning.
- **2023** — ReAct (Yao et al.): prompting pattern that rediscovers SOAR's observe-reason-act cycle in LLM prompting; ICLR 2023.
- **2023** — Reflexion (Shinn et al.): verbal reinforcement learning implementing [[Meta-Cognition]] in LLM agents; NeurIPS 2023.
- **2024** — CoALA (Sumers, Yao, Narasimhan, Griffiths): maps 50 years of cognitive architecture theory onto LLM agent framework vocabulary; TMLR 2024.
- **2025** — Wray, Kirk, and Laird map SOAR's operator-selection mechanism onto ReAct pattern; demonstrate 30% performance improvement on agent benchmarks by applying SOAR-derived architectural principles to GPT-4o prompting; AAAI Spring Symposium 2025.
- **2025** — IBM NeuroVSA combines vector-symbolic representations with symbolic reasoning; framed as a pathway to artificial general intelligence directly in the cognitive architecture tradition.
- **2026** — Cognitive architecture principles are recognised as mandatory background knowledge for [[AI Safety]] certification in the EU AI Act high-risk system conformity assessment.
- **2026** — UK AI Opportunities Action Plan (January 2026) identifies [[Agentic AI]] frameworks as a national strategic priority; cognitive architecture design methodology is adopted as a reference framework by the UK AI Safety Institute for evaluating autonomous agent deployments.
- **2026** — AAAI Symposium on Cognitive Architectures for Language Agents records highest-ever attendance; consolidation of CoALA, SOAR-LLM, and BDI-LLM mappings into a de facto standard vocabulary for agent architecture design.

### Provenance

