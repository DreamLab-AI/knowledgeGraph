Presentation attack detection (PAD) is the set of techniques that determine whether a biometric sample is presented by a genuine, live subject or by an artefact intended to spoof the system. Attacks include printed photographs, replayed video, silicone fingerprints, and three-dimensional masks. PAD, also known as liveness or anti-spoofing analysis, is standardised under ISO/IEC 30107 and is essential to the trustworthiness of biometric authentication.

### Overview

- A biometric system is only as strong as its weakest enrolment path, and presentation attacks exploit the gap between capturing a likeness and confirming a living person. PAD methods analyse texture, motion, depth, physiological signals, and challenge-response behaviour to separate genuine presentations from artefacts. They are typically evaluated using the standardised metrics of attack presentation classification error rate and bona fide presentation classification error rate.

### Key aspects

- Passive liveness from texture, micro-movement, and reflectance cues
- Active challenge-response such as blink, smile, or head-turn prompts
- Depth and infrared sensing to defeat flat-image spoofs
- Physiological signals including remote photoplethysmography
- Standardised evaluation under ISO/IEC 30107 (APCER, BPCER)

### Applications

- Face unlock on mobile devices and laptops
- Remote identity verification for onboarding and KYC
- Border control and automated passport gates
- Fingerprint and iris systems in high-assurance access control

### Provenance

