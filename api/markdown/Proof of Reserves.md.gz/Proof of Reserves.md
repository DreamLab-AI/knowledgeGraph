Proof of reserves is a cryptographic auditing technique by which a custodial entity, such as a cryptocurrency exchange or stablecoin issuer, demonstrates that it holds sufficient assets to cover its customer liabilities. The asset side is typically attested by publishing on-chain wallet ownership, while the liability side is committed using a Merkle tree so that individual customers can verify their balance is included without exposing the full ledger. More advanced schemes combine these with zero-knowledge proofs to prove solvency while preserving the confidentiality of total liabilities and individual balances.

### Overview

- Proof of reserves lets a custodian prove it holds enough assets to back customer liabilities without requiring trust in a single auditor.
- Assets are evidenced by demonstrating control of on-chain addresses; liabilities are committed via a Merkle tree of customer balances.
- Each customer can independently confirm inclusion of their balance in the committed liability set using a Merkle proof.

### Mechanisms

- Asset attestation: signed messages or movements prove ownership of reserve wallets at a point in time.
- Liability commitment: a Merkle tree aggregates all customer balances into a single root hash published for verification.
- Inclusion proofs: a customer verifies their leaf hashes up to the published root, confirming their balance was counted.
- Privacy-preserving variants: zero-knowledge proofs can demonstrate solvency without revealing total liabilities or individual balances.

### Applications

- Stablecoin issuers demonstrating full collateral backing.
- Centralised cryptocurrency exchanges proving customer-fund solvency.
- Digital-asset custodians providing verifiable accountability.
- Regulatory and market-confidence reporting for custodial platforms.

### Provenance

