
An input state represents the inputs provided to an action.[^1]

The class is declared in the execution-context module and is reached from an [[Execution Context]] through the property `inputState`. One datatype property, `inputValue`, has it as domain, with a string as range. Its counterpart for results is [[Output State]].

The ontology records inputs as a string-valued description and gives no schema for them. The agent module separately declares an `InputSpec` class for what an agent accepts in general, which is a specification of inputs and not a record of the inputs of a particular action. visionGraph places the concept under [[Input]].

[^1]: Semantic Agent Communication Community Group, “Execution Context Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/execution-context.ttl

