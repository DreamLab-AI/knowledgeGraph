Automation is the application of technology, control systems, and software to execute processes, tasks, or workflows with minimal or no human intervention, transferring decision-making and execution from people to machines or algorithms. It encompasses industrial and manufacturing automation driven by programmable logic controllers and robotics, as well as software-driven process automation that replicates repetitive digital workflows. The primary goals are to increase throughput, reduce error rates, lower operational costs, and free human attention for non-routine judgement tasks. Automation exists on a spectrum from fixed mechanisation through programmable control, flexible automation, and fully autonomous adaptive systems.

### Overview

- Automation is one of the most foundational concepts in engineering, computing, and organisational design. Its history spans mechanical looms and steam-powered governors through relay logic and [[Programmable Logic Controllers]], to modern [[Machine Learning]]-driven intelligent pipelines. The concept unifies physical and digital domains: a factory conveyor obeying a PLC and a [[DevOps]] pipeline that compiles, tests, and deploys software are both expressions of the same underlying principle — a defined input-process-output cycle executing without per-instance human direction.
- Why it matters:
  - Enables consistent, repeatable execution at machine speed and scale.
  - Reduces variance and human error in high-volume, well-defined processes.
  - Shifts workforce activity toward exception-handling, oversight, and creative work.
  - Provides the technical substrate for [[Scalability]] — automated systems can handle orders-of-magnitude increases in load without proportional human resource increases.
- The spectrum of automation:
  - **Fixed (hard) automation** — single-purpose machinery with no reprogrammability (e.g., transfer lines).
  - **Programmable automation** — batch-reconfigurable machines controlled by [[Programmable Logic Controllers]] or numerical control (NC/CNC).
  - **Flexible automation** — software-controlled systems reprogrammable in real time, enabling mixed-model production.
  - **Intelligent automation** — systems incorporating [[Machine Learning]], [[Computer Vision]], or [[Natural Language Processing]] to handle variability and make context-sensitive decisions.

### Key Components

- **[[Sensors]]** — gather real-world state data (temperature, position, image, text) that drive automated decision logic.
- **[[Actuators]]** — translate control outputs into physical action (motors, valves, relays, API calls).
- **[[Control Systems]]** — the logic layer (PLC ladder logic, PID controllers, rule engines, ML models) that transforms sensor input into actuator commands via [[Feedback Loops]].
- **[[Feedback Loops]]** — closed-loop control compares actual system state to desired state and corrects deviations; open-loop control executes predetermined sequences without correction.
- **[[Programmable Logic Controllers]]** — ruggedised industrial computers that execute ladder or structured-text logic for factory-floor control; the backbone of [[Industrial Automation]].
- **[[Robotic Process Automation]]** — software bots that mimic human interaction with GUIs and APIs to automate repetitive digital tasks (data entry, report generation, system integration).
- **[[Workflow Automation]]** — orchestration of multi-step business or technical processes through event triggers, conditional branching, and integration connectors (e.g., Zapier, n8n, Apache Airflow).
- **[[Test Automation]]** — automated execution of software test suites within [[Continuous Integration]] pipelines, enabling rapid feedback on code quality.
- **[[Orchestration]]** — higher-order coordination of multiple automated subsystems or microservices, scheduling tasks, managing dependencies, and handling failures.

### Mechanisms

- **Event-driven execution** — automation is triggered by observable events (sensor threshold, message arrival, schedule tick, API webhook) rather than continuous human monitoring.
- **Rule-based logic** — if-then-else decision trees encode human expertise into deterministic control flows; the basis of traditional PLC programming and business rules engines.
- **Model-based control** — mathematical models of plant dynamics enable feedforward and model-predictive control, optimising trajectories before disturbances propagate.
- **Learning-based adaptation** — [[Machine Learning]] models trained on historical data allow automation to generalise to previously unseen inputs, enabling [[Autonomous Systems]] that improve with experience.
- **API integration** — modern software automation relies on standardised [[Application Programming Interfaces]] to connect disparate systems without brittle screen-scraping.
- **Declarative pipelines** — tools such as YAML-defined CI/CD pipelines (GitHub Actions, GitLab CI) describe desired outcomes; the engine resolves execution order and parallelism.

### Applications

- **[[Industrial Automation]] and manufacturing** — CNC machining centres, robotic welding cells, automated packaging lines, and quality-inspection systems driven by [[Computer Vision]] all reduce defect rates and cycle times.
- **[[Supply Chain Management]]** — automated warehousing (ASRS), demand forecasting pipelines, purchase-order generation, and carrier-booking bots reduce lead times and inventory carrying costs.
- **[[Business Process Management]]** — [[Robotic Process Automation]] handles invoice processing, customer onboarding, regulatory reporting, and HR workflows at scale in financial, healthcare, and government sectors.
- **[[DevOps]] and software delivery** — [[Continuous Integration]] and continuous delivery (CI/CD) pipelines automate build, test, security scan, and deployment, compressing release cycles from months to hours.
- **[[Internet of Things]] infrastructure** — billions of connected devices rely on automated monitoring, firmware update, anomaly detection, and self-healing logic executed without operator intervention.
- **[[Edge Computing]]** — latency-critical automation (autonomous vehicles, robotics, industrial vision) executes inference and control locally rather than round-tripping to cloud.
- **[[Intelligent Agents]] and AI pipelines** — LLM-driven agentic systems automate research, code generation, data analysis, and multi-step decision tasks, representing the frontier of cognitive automation.
- **[[Digital Twins]]** — virtual replicas of physical assets run automated simulations to predict failures, optimise setpoints, and validate control changes before deployment.

### Standards & Context

- **IEC 61131-3** — international standard for [[Programmable Logic Controllers]] programming languages (Ladder Diagram, Structured Text, Function Block Diagram, Instruction List, Sequential Function Chart); the lingua franca of industrial automation.
- **ISA-95 / IEC 62264** — standard for enterprise-control system integration, defining the interface between [[Business Process Management]] layers and manufacturing execution systems (MES).
- **ISA-88 / IEC 61512** — batch process control standard defining procedural control models widely used in pharmaceutical and food manufacturing automation.
- **OPC UA (IEC 62541)** — platform-independent, service-oriented communication protocol for industrial automation data exchange, increasingly underpinning [[Internet of Things]] integration.
- **IEEE 7010** — recommended practice for assessing the impact of autonomous and intelligent systems on human well-being, relevant to the societal dimensions of automation.
- **ISO 10218 / ISO/TS 15066** — safety standards for industrial [[Robotics]] and collaborative robots (cobots) operating alongside humans.
- **BPMN 2.0 (OMG)** — Business Process Model and Notation standard used to specify and document automated [[Business Process Management]] workflows.
- Governance bodies include the International Society of Automation (ISA), the IEC TC65 technical committee, and the IEEE Robotics and Automation Society.

### Current Landscape (2026)

- The defining shift of 2024–2026 is agentic automation: autonomous, goal-driven agents that plan, execute and adapt across whole workflows rather than running fixed scripts. Gartner's 2026 Hype Cycle places Agentic AI at the Peak of Inflated Expectations, and it forecasts that 40% of enterprise applications will embed task-specific AI agents in 2026, up from under 5% in 2025.
- Infrastructure automation is being re-architected around governed agent access. At HashiConf 2025 (25 September) HashiCorp — now an IBM company — previewed Project Infragraph, a real-time infrastructure graph for policy-aware agentic action (private beta opening December 2025), and shipped MCP servers for Terraform, Vault and Vault Radar to give agents auditable, RBAC-scoped endpoints.
- The Model Context Protocol (Anthropic) has become the connective tissue for infrastructure agents: Red Hat previewed MCP support in Ansible Lightspeed at AnsibleFest 2025 with Open Policy Agent (OPA) guardrails, and HashiCorp/GitHub wired GitHub Copilot to the Terraform MCP server at Microsoft Build 2025.
- Core IaC tooling matured in 2025: HCP Terraform Stacks reached general availability, OpenTofu (the open-source Terraform fork) gained ground and CNCF standing, and new entrants such as Formae (Platform Engineering Labs, October 2025) and Spacelift Intent pushed generative, drift-free approaches.
- Markets are scaling fast and consolidating. The agentic automation market was roughly USD 6.02bn in 2025 heading to USD 7.36bn in 2026 (Future Market Insights); AI-in-RPA is around USD 5.6bn in 2026; and Q1 2026 workflow-automation venture funding hit about USD 2.1bn. RPA is increasingly being reclassified as the reliable execution layer inside agentic platforms.
- Key players span IaC/DevOps (HashiCorp/IBM, Red Hat Ansible, Pulumi, Microsoft), agentic and RPA platforms (UiPath, Microsoft Power Automate, Automation Anywhere, ServiceNow, SS&C Blue Prism, Salesforce, SAP, Anthropic) and industrial/physical AI (NVIDIA, Siemens, Bosch, Rockwell Automation, ABB), with alliances like Siemens–NVIDIA and ABB–Microsoft co-developing full-stack systems.
- Open challenges as of 2026 centre on trust and control: proving ROI, orchestrating multi-agent systems (single-task bots are giving way to co-ordinated agents), and enforcing "governance-as-code" for security and compliance under regimes such as the EU AI Act, SOC 2 and HIPAA. Physical/embodied AI is the emerging frontier, with Capgemini reporting 79% of large organisations already engaging with it.

### References

- 1. IBM Newsroom / HashiCorp (2025). HashiCorp Previews the Future of Agentic Infrastructure Automation with Project Infragraph. https://newsroom.ibm.com/2025-09-25-hashicorp-previews-the-future-of-agentic-infrastructure-automation-with-project-infragraph
- 2. HashiCorp (2025). Scale infrastructure with new Terraform and Packer features at HashiConf 2025. https://www.hashicorp.com/en/blog/scale-infrastructure-with-new-terraform-and-packer-features-at-hashiconf-2025
- 3. DevOps.com (2025). Red Hat Previews Series of Updates to Ansible Automation Platform. https://devops.com/red-hat-previews-series-of-updates-to-ansible-automation-platform/
- 4. Future Market Insights (2026). Agentic Automation Market. https://www.futuremarketinsights.com/reports/agentic-automation-market
- 5. accio.com (2026). RPA Trends Gartner 2026: AI & Automation Insights. https://www.accio.com/business/rpa_trends_gartner
- 6. Mordor Intelligence (2025). Agentic AI in Manufacturing and Industrial Automation Market. https://www.mordorintelligence.com/industry-reports/agentic-artificial-intelligence-in-manufacturing-and-industrial-automation-market

### Provenance

