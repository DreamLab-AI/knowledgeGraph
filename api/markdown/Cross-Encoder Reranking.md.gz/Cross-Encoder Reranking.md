Cross-Encoder Reranking is a two-stage information retrieval technique in which a cross-encoder transformer model receives a query and a candidate document concatenated as a single input sequence, performs full bidirectional self-attention across both, and outputs a relevance score used to re-order an initial candidate set retrieved by a faster but less accurate first-stage retriever. It typically yields substantially higher ranking quality than bi-encoder first-stage retrieval at the cost of higher computational latency.

### Semantic Classification

### Content

## Compositional Relationships (Components)
```
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:hasPart ai:TransformerEncoder))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:hasPart ai:SelfAttentionMechanism))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:hasPart ai:RelevanceScoringHead))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:hasPart ai:QueryDocumentConcatenation))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:hasPart ai:CandidateSet))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:hasPart ai:RankingOutputLayer))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:hasPart ai:TokenisationPipeline))
```
## Dependency Relationships
```
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:requires ai:FirstStageRetriever))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:requires ai:DenseRetrieval))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:requires ai:GPUInference))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:dependsOn ai:ApproximateNearestNeighbourSearch))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:dependsOn ai:CandidateDocument))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:dependsOn ai:QueryRepresentation))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:dependsOn ai:ContrastiveLearning))
```
## Capability Relationships
```
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:enables ai:RetrievalAugmentedGeneration))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:enables ai:QuestionAnswering))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:enables ai:DocumentRetrieval))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:enables ai:KnowledgeRetrieval))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:enables ai:AgenticRAG))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:supports ai:EnterpriseSearch))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:supports ai:RAGPipeline))
```
## Implementation Relationships
```
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:implements ai:NeuralRanking))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:implements ai:TwoStageRetrieval))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:implements ai:PointwiseRelevanceScoring))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:implements ai:ProbabilityRankingPrinciple))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:implements ai:LearningToRank))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:uses ai:BidirectionalSelfAttention))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:uses ai:BERT))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:uses ai:KnowledgeDistillation))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:uses ai:HardNegativeMining))
```
## Reduction Relationships
```
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:reducesTo ai:RelevanceScoring))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:reducesTo ai:DocumentRanking))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:reducesTo ai:BinaryRelevanceClassification))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:reducesTo ai:PassageRanking))
SubClassOf(ai:CrossEncoderReranking
  ObjectSomeValuesFrom(ai:reducesTo ai:TwoStageRetrieval))
```

## About
Cross-encoder reranking is the practice of applying a transformer model that jointly processes a query and a candidate document as a single input to produce a fine-grained relevance score, which is then used to reorder the short-list of candidates returned by a faster first-stage retriever. The paradigm resolves a fundamental tension in large-scale [[Information Retrieval]]: the need to search across millions of documents in milliseconds precludes exhaustive pair-wise scoring by an accurate but expensive model, so a two-stage architecture is used. The first stage — typically [[Dense Retrieval]] with [[Approximate Nearest Neighbour Search]] over pre-computed [[Embedding Model]] vectors, or sparse [[BM25]] retrieval over an inverted index, or [[Hybrid Retrieval]] combining both — rapidly reduces the candidate set to hundreds of documents. The cross-encoder then scores each candidate against the query with full cross-attention, producing a re-ranked list whose precision typically exceeds the first-stage ranking by five to fifteen NDCG@10 points on established benchmarks including BEIR and the TREC Deep Learning Track.

The theoretical basis for the cross-encoder's superiority lies in the expressiveness of full bidirectional [[Self-Attention]]. In a bi-encoder, the query representation is fixed at query time and compared to pre-computed document representations via dot-product [[Cosine Similarity]]; the document representation cannot be conditioned on the specific query. A cross-encoder, by contrast, applies [[Attention Mechanism]] across the joint token sequence at every layer, allowing the query tokens to dynamically influence how document tokens are weighted and vice versa. This cross-attention captures query-dependent document salience, enabling the model to identify whether a document addresses the specific aspect of a topic implied by the query, rather than simply whether it is topically related. The [[BERT]] architecture — pre-trained with masked language modelling and next-sentence prediction, then fine-tuned with a relevance head on labelled query-passage pairs — was established as the canonical cross-encoder backbone by Nogueira and Cho's 2019 "Passage Re-ranking with BERT" paper, which achieved a 27% relative improvement in MRR@10 on MS MARCO over prior state of the art.

The historical lineage of cross-encoder reranking extends well before the transformer era. Learning-to-rank (LTR) methods from the mid-2000s — RankNet (Burges et al., 2005), LambdaMART (Burges, 2010), and the gradient-boosted tree models used in the Microsoft LETOR benchmark — already concatenated query and document feature vectors as a joint input for relevance scoring. These models used handcrafted features (TF-IDF, BM25 scores, anchor text statistics, document freshness) rather than learned representations, but the fundamental idea of joint query-document encoding as a precondition for accurate relevance scoring was already established. The transition from handcrafted-feature LTR to transformer cross-encoders was primarily a representation-learning advance rather than an architectural one: by replacing the manual feature engineering with contextualised token embeddings from pre-trained language models, the cross-encoder gained both the expressive power to capture long-range semantic dependencies and the ability to generalise from a relatively small labelled ranking dataset to diverse new domains.

Understanding why two-stage retrieve-and-rerank is economically justified requires analysing the computational trade-off explicitly. For a corpus of N documents and a query, a cross-encoder forward pass costs O(L² · d) per query-document pair, where L is the joint token sequence length and d is the model dimension. Performing this for all N documents would cost O(N · L² · d) per query — completely infeasible for N in the millions. By contrast, a bi-encoder or [[BM25]] first stage costs O(log N · d) per query via [[Approximate Nearest Neighbour Search]] or inverted-index lookup. The two-stage pipeline restricts cross-encoder inference to the top-k candidates (typically k = 50–200), reducing cost to O(k · L² · d), a tractable operation on a single GPU. The gain in NDCG from cross-encoder reranking over bi-encoder first-stage ordering is consistent enough across benchmarks — measured at 5–15 points on MS MARCO Passage Ranking and at 3–8 points on BEIR zero-shot tasks — that the additional latency budget (typically 100–500ms for k = 100 on a GPU) is considered acceptable for the vast majority of production RAG and [[Enterprise Search]] applications.

Training dynamics of cross-encoders are significantly influenced by the choice of negative examples. With only positive query-passage pairs and random negatives, cross-encoders learn a coarse relevance discriminator but fail to distinguish subtly relevant from irrelevant passages. Hard negative mining — retrieving top-ranked passages from [[BM25]] or a dense retriever that are labelled irrelevant — dramatically improves model quality by forcing the cross-encoder to learn fine-grained distinctions. The iterative hard negative mining process (alternating between mining new negatives with the current model and retraining on them) converges to a stable high-quality solution in two or three rounds. Knowledge distillation from a large teacher cross-encoder (e.g., a fine-tuned DeBERTa-v3-large with 435M parameters) to a smaller student (e.g., MiniLM-L-6 with 22M parameters) further enables production deployment: the student preserves within 2 NDCG@10 points of the teacher at 10–15× faster inference. This distillation pipeline is the primary approach taken by the Sentence-Transformers ms-marco-MiniLM series, which remains the most widely deployed open cross-encoder family across LangChain, LlamaIndex, and Haystack integrations.

The relationship between cross-encoder reranking and [[Retrieval-Augmented Generation]] quality deserves careful examination. In a RAG pipeline, the generator [[Large Language Model]] receives a context window containing the top-k retrieved passages. The precision of these passages — whether they actually address the user's question — directly determines both the accuracy and the hallucination rate of the generated response. Context windows filled with loosely relevant or irrelevant passages cause the generator to be distracted by noisy information, produce hedged non-answers, or confabulate details to fill the gap between what was retrieved and what was needed. A 2024 systematic study found that adding a cross-encoder reranker between the first-stage dense retriever and the generator improved downstream answer quality (measured by ROUGE-L and human evaluation) by 18–40% across diverse QA benchmarks, with the gains particularly pronounced for multi-hop questions requiring multiple independent facts to be assembled. This explains why cross-encoder reranking has become the single most recommended optimisation for production RAG systems in enterprise AI deployment guides for 2025–2026.

## Components and Architecture

- **Input Formatting**: The standard input is `[CLS] query [SEP] document [SEP]`, concatenating query and document with special separator tokens. For very long documents, passage-level chunking is applied upstream, and the cross-encoder scores each chunk independently. The maximum input length is bounded by the model's context window (typically 512 tokens for BERT-base; 4096–8192 for modern reranking models). When queries and passages exceed the context length, sliding-window passage chunking with stride overlap ensures complete document coverage.
- **Transformer Backbone**: Typically a BERT-class encoder (12–24 layers, 110M–340M parameters), though larger models (DeBERTa-v3, Qwen-2.5, NLI-fine-tuned variants) have been shown to improve ranking quality. The bidirectional [[Self-Attention]] in all layers allows complete cross-attention between query and document tokens. BERT's Next Sentence Prediction objective during pre-training implicitly primes the model for the query-document relevance task: the [CLS] token is trained to represent the coherence between two text segments, which maps directly onto relevance scoring.
- **Classification Head**: A linear projection from the `[CLS]` token representation to a scalar logit, passed through a sigmoid for binary relevance probability or used raw as a ranking score. Pointwise training maximises the probability of positive pairs; pairwise training uses margin ranking loss; listwise training (LAMBDARANK-style) optimises rank-based metrics directly. The choice of training objective has measurable impact: listwise objectives typically produce 1–2 NDCG@10 points higher than pointwise on MS MARCO, but require sorting gradients (LAMBDALOSS) or list-level normalisation that complicate implementation.
- **Hard Negative Mining**: Effective training requires negatives that are semantically close to the query but irrelevant. BM25-sampled negatives, in-batch negatives, and negatives retrieved by the current model iteration (online hard negatives) are standard. The Mixedbread mxbai-rerank-large-v2 and BGE-Reranker-v2 models use a three-stage training regime combining supervised hard negatives, [[Contrastive Learning]], and preference learning via Group Relative Policy Optimisation (GRPO). This represents the convergence of LLM alignment techniques with ranking model training.
- **[[Knowledge Distillation]]**: A large teacher cross-encoder distils soft relevance scores to a smaller student cross-encoder, preserving most ranking quality (within 2 NDCG of teacher) at 2–3× reduced latency. This is the primary route to low-latency deployment. The distillation loss is typically a combination of KL divergence between teacher and student score distributions plus a standard pointwise cross-entropy term, weighted by a temperature hyperparameter that controls how much to trust the soft teacher labels versus hard relevance annotations.
- **Serving Infrastructure**: Inference is batch-parallelised over the candidate set on GPU. FlashAttention v2/v3 and int8/fp8 quantisation reduce per-pair latency, enabling reranking of 100 candidates in under 200ms on a single A100 GPU. TorchServe, vLLM (for generative rerankers), and ONNX Runtime deployments are standard. For cloud APIs (Cohere, Voyage, Jina), the reranking call is a single HTTP endpoint invocation that accepts query + candidate list and returns a ranked list with scores, abstracting the entire infrastructure burden.
- **Context Length Handling**: Modern reranking models (BGE-Reranker-v2-m3, Jina Reranker v2) support up to 8,192 tokens per query-document pair, enabling reranking of full-page documents rather than 512-token passages. This eliminates the chunking step for shorter documents but increases per-pair inference time proportionally to sequence length squared.

  ## Major Variants and Families

- **Pointwise Reranking (standard cross-encoder)**: Scores each query-document pair independently. The most widely deployed pattern; models include ms-marco-MiniLM-L-6-v2, ms-marco-MiniLM-L-12-v2, and the BGE-Reranker series from BAAI. Inference complexity is O(k) forward passes. The pointwise objective (binary cross-entropy on positive/negative pairs) is straightforward to implement and scale, making this the standard baseline.
- **Pairwise Reranking**: Scores pairs of documents jointly, using the model to directly predict which document is more relevant. More sample-efficient from a training perspective — the model learns relative preferences rather than absolute scores — but slower at inference (O(k²) pairs for k candidates). RankNet and its derivatives provide the theoretical foundation; pairwise cross-encoders are used in legal document ranking where relative preference signals are available from case citation patterns.
- **Listwise Reranking (LLM-based)**: Uses a [[Large Language Model]] prompted with a list of passages to output a ranked ordering. RankGPT and similar approaches can achieve higher accuracy ceilings on reasoning-heavy queries but add 4–6 seconds of latency and cost one to three US cents per query at GPT-4 pricing, making them suitable only for offline or low-volume applications. The approach scales poorly with candidate set size because the entire ranked list must fit within the LLM's context window.
- **Late Interaction Models ([[ColBERT]])**: A middle ground between bi-encoder and full cross-encoder — pre-computes document token embeddings offline, performs MaxSim scoring (maximum similarity over token pairs) at query time. Two orders of magnitude faster than full cross-encoders at reranking time with nDCG within 3 points, but requiring specialised indexed storage (approximately 50–150 GB for large corpora at full precision). ColBERT bridges the retrieve-and-rerank paradigm by enabling dense token-level interaction without the full inference cost.
- **Multi-Stage Distillation Cascades**: A large cross-encoder teacher (e.g., MonoT5-3B with 3 billion parameters) distils soft relevance scores to a medium cross-encoder (e.g., DeBERTa-v3-base, 184M), which in turn distils to a bi-encoder (e.g., TAS-B, 110M), creating a three-stage cascade that balances quality and latency at each stage. Each stage processes all candidates from the previous stage, progressively narrowing the set. This cascaded distillation architecture is used in web-scale search engines where multiple stages of ranking are applied before the final cross-encoder rescoring.
- **Generative Reranking (Seq2Seq)**: Seq2Seq models (T5, LLaMA fine-tunes) that output "true" or "false" tokens given a query-document pair and derive relevance scores from the conditional probability of the "true" token. MonoT5 (Nogueira et al., 2020) and RankT5 are the canonical examples. The generative framing allows the model to leverage pre-trained generative capabilities for relevance estimation, and larger generative models (T5-3B, T5-11B) consistently outperform BERT-class cross-encoders, at the cost of 10–30× higher inference latency.
- **Multimodal Cross-Encoders**: Cross-encoder architectures adapted for image-text or table-text relevance scoring. The model receives interleaved image patch embeddings and text tokens as a joint sequence, applying cross-attention across both modalities. Used in e-commerce product search (text query vs. product image+description) and scientific document retrieval (text query vs. figure+caption).
- **Efficient Early-Exit Cross-Encoders (MICE)**: Early-exit architectures (MICE, arXiv 2602.16299, 2025) that halt inference at intermediate transformer layers when the model's confidence exceeds a threshold, reducing average FLOPs by 50% with less than 1 NDCG@10 regression. A classifier attached to each layer predicts whether the current representation is sufficient for reliable relevance scoring; easy query-document pairs exit at layer 4–6 while difficult ones run the full depth. This adaptive computation approach is particularly valuable for real-time consumer search applications with strict latency budgets.

  ## Efficiency Analysis and Latency Budget
  Production deployment of cross-encoder reranking requires careful latency analysis. The computational cost scales as:

  T_rerank = k × (L × H × d²) / (GPU_FLOPS × batch_efficiency)

  where k is the number of candidates reranked, L is the number of transformer layers, H is the number of attention heads, d is the hidden dimension, and batch_efficiency accounts for GPU occupancy. For a 12-layer, 384-hidden MiniLM cross-encoder at k=100 candidates on a single A100 GPU, typical measured latency is 80–120ms. For a 24-layer DeBERTa-v3-base at k=100, latency is 300–500ms. The smaller model sacrifices approximately 2–3 NDCG@10 points for a 3–4× latency reduction.

  The relationship between first-stage recall and cross-encoder improvement is critical for system design: if the first-stage retriever has poor recall (fails to include the relevant document in the top-k candidates), no cross-encoder can recover quality. Recall@k must be high (ideally above 95%) for reranking to be effective. This means the first-stage retriever must be tuned to retrieve a somewhat larger candidate set (often k=100–200) than the final number of documents passed to the generator (typically r=5–20), providing the cross-encoder with enough candidates to identify the genuinely relevant ones. The recall-latency trade-off dictates the optimal k: below k=50, important documents are frequently missed by the first stage; above k=200, the cross-encoder inference cost becomes prohibitive for real-time applications without batch inference infrastructure.

  Quantisation of cross-encoder weights (int8 or fp8) reduces memory bandwidth requirements by 2–4× with less than 0.5 NDCG regression for models above 100M parameters. Dynamic quantisation (quantising activations at inference time rather than static quantisation of weights only) is preferred for cross-encoders because the activation distributions vary significantly across query-document pairs. TorchServe and ONNX Runtime deployments with int8 dynamic quantisation achieve latency within 10–15% of FP16 inference while halving memory bandwidth requirements — enabling deployment on lower-cost GPU instances or even CPU for latency-tolerant applications.

  ## Use Cases and Applications

  ### Retrieval-Augmented Generation
  [[RAG Pipeline]] is the primary deployment context for cross-encoder reranking in 2025–2026. In a standard RAG architecture, the quality of the generated response is bounded by the precision of the retrieved context: if the top-k chunks passed to the [[Large Language Model]] do not contain the information needed to answer the query, no amount of model capability can produce a correct answer. Cross-encoder reranking addresses this by reordering the first-stage retrieval results before they are passed to the generator, ensuring that the most relevant passages occupy the limited context window rather than the merely topically related ones. A 2024 systematic study found that adding a cross-encoder reranker to a RAG pipeline improved answer quality (ROUGE-L and human evaluation) by 18–40% across diverse QA benchmarks, with larger gains for multi-hop questions. The RAGSmith framework (arXiv 2511.01386, 2025) confirmed that reranking is the single most impactful optimisation step in the RAG pipeline across diverse dataset types and first-stage retriever configurations.

  For clinical RAG applications targeting UK NICE guidelines, a published study (arXiv 2510.02967, 2025) demonstrated that combining BM25 sparse retrieval with Voyage-3-Large dense retrieval and Voyage Reranker-2 cross-encoder reranking achieved Recall@1 of 81% and Recall@10 of 99.1% on guideline lookup tasks — substantially outperforming single-stage retrieval. The clinical significance is substantial: NICE guidelines can exceed 100 pages and guide clinical decision-making in NHS settings where rapid, accurate information retrieval is safety-critical. Cross-encoder reranking enables clinicians to locate the specific relevant subsection of a guideline given a clinical question, rather than retrieving the entire document.

  ### Enterprise Search
  [[Enterprise Search]] applications in legal, financial, compliance, and HR domains benefit particularly from cross-encoder reranking because these domains contain large volumes of semantically similar documents (case law, regulatory filings, policy documents) that require precise relevance discrimination beyond keyword matching. A legal contract review system, for example, may retrieve dozens of documents containing the term "indemnification" in response to a query about indemnification scope in data breach scenarios; a cross-encoder that jointly encodes the full contract clause with the specific query can identify the passages that most directly address the user's concern. Enterprise RAG deployments at financial services firms (investment banks, insurance companies) and law firms have reported precision improvements of 25–40% from cross-encoder reranking over bi-encoder or BM25-only retrieval, translating directly to reduced analyst time spent filtering irrelevant results.

  ### Question Answering and Knowledge Retrieval
  Open-domain [[Question Answering]] was one of the original motivating applications for the retrieve-and-rerank paradigm. The DrQA system (Chen et al., 2017) pioneered using a TF-IDF retriever followed by a machine reading comprehension (MRC) model applied to the retrieved passages — an early two-stage architecture that prefigured modern cross-encoder reranking. The DPR (Dense Passage Retrieval, Karpukhin et al., 2020) + cross-encoder reranker pipeline became the dominant approach on Natural Questions and TriviaQA benchmarks from 2020–2022. Modern [[Knowledge Retrieval]] systems in enterprise knowledge bases and documentation search use cross-encoder reranking to surface the single most authoritative answer among multiple plausible candidates.

  ### Agentic AI and Multi-Step Retrieval
  [[Agentic RAG]] systems that execute multi-step retrieval loops — planning, tool selection, multiple retrieval calls, synthesis — face a context saturation problem: after several retrieval iterations, the context window fills with accumulated passages from previous steps, making it difficult for the agent to focus on the most recently relevant information. Cross-encoder reranking at each retrieval step prioritises which passages to retain in the working memory versus discard, enabling agents to maintain focus over long multi-step tasks. The specificity of cross-encoder scoring (conditioning document relevance on the exact current query rather than a generic topic representation) makes it particularly valuable for agentic use cases where the query evolves with each reasoning step.

  ### Scientific and Academic Search
  Biomedical literature search (PubMed, Semantic Scholar) and academic citation recommendation systems use cross-encoder reranking to distinguish between papers that cite a target paper for related but distinct reasons. In clinical drug development, literature search tools that retrieve relevant trial results, mechanism of action papers, and adverse event reports use domain-adapted cross-encoders fine-tuned on biomedical QA datasets (BioASQ, PubMedQA) to provide high-precision retrieval that reduces systematic review workload. Elsevier, Springer Nature, and Clarivate Analytics have integrated neural reranking into their academic search products.

  ## Formal Analysis of Cross-Encoder Relevance Scoring
  The mathematical formulation of cross-encoder reranking can be stated precisely. Given a query q consisting of tokens q₁, ..., q_m and a document d consisting of tokens d₁, ..., d_n, the joint input to the cross-encoder is the concatenated sequence [CLS] q₁ ... q_m [SEP] d₁ ... d_n [SEP]. The cross-encoder applies L transformer layers, each computing multi-head self-attention across all m + n + 3 tokens. At each layer l, the hidden representation h_i^(l) for token i is:

  h_i^(l) = Attention(Q^(l), K^(l), V^(l))_i + FFN(h_i^(l-1))

  where the key and value matrices are computed from all tokens in the joint sequence. The attention score between token i and token j is:

  a_{ij} = softmax((W_Q h_i) · (W_K h_j) / √d_k)

  Crucially, this attention is unrestricted: a query token q_i can attend to any document token d_j, and vice versa. The [CLS] token representation after L layers, h_[CLS]^(L), aggregates information from the entire joint sequence and is projected by a learned weight vector w to a scalar relevance score:

  score(q, d) = w^T h_[CLS]^(L)

  This score is used to sort the candidate documents; candidates are then presented to the downstream generator in ranked order, with the top-r documents (typically r = 3–10) included in the context window. The cross-entropy training objective for pointwise scoring is:

  L = -[y · log(σ(score)) + (1-y) · log(1 - σ(score))]

  where y ∈ {0, 1} is the binary relevance label and σ is the sigmoid function. The gradient of this loss with respect to the score is σ(score) - y, which is small when the model is confident and correct and large when the model is confident and wrong — a desirable property for stable training.

  Normalised Discounted Cumulative Gain at rank k is the primary evaluation metric:

  NDCG@k = DCG@k / IDCG@k

  where DCG@k = ∑_{i=1}^{k} (2^{rel_i} - 1) / log₂(i + 1), rel_i is the relevance grade of the document at rank i (0 = non-relevant, 1 = relevant, 2 = highly relevant), and IDCG@k is the maximum achievable DCG with perfect ranking. NDCG@k ∈ [0, 1], with 1 indicating perfect ranking.

  ## Academic Context
  The foundational paper for the transformer-era cross-encoder is Nogueira and Cho, "Passage Re-ranking with BERT" (arXiv 1901.04085, 2019), which established the [CLS]-head architecture and training on MS MARCO with BM25 hard negatives. The MS MARCO passage ranking dataset (Nguyen et al., 2016) and the TREC Deep Learning Track (Craswell et al., 2019–) provide the primary benchmarking infrastructure. Hofstatter et al. introduced TAS-B (Topic-Aware Sampled Bert, 2021), showing that topic-balanced batch construction substantially improves bi-encoder quality, reducing the gap with cross-encoders. The BEIR benchmark (Thakur et al., 2021) stress-tests rerankers across 18 zero-shot domains, revealing that cross-encoders generalise better than bi-encoders trained on single-domain data. ColBERT (Khattab and Zaharia, 2020) established the late-interaction paradigm as the efficiency–quality middle ground. Sun et al. "Is ChatGPT Good at Search? Investigating Large Language Models as Re-Ranking Agents" (2023) demonstrated the listwise RankGPT approach. Scaling laws for cross-encoder reranking (arXiv 2603.04816, 2025) show that ranking quality scales predictably with model parameters and training compute, with diminishing returns beyond 1B parameters for standard BEIR tasks. The MICE (Minimal Interaction Cross-Encoders) paper (arXiv 2602.16299, 2025) demonstrates early-exit cross-encoders that reduce FLOPs by 50% with less than 1 nDCG@10 regression.

  The theoretical relationship between cross-encoder scoring and the probability ranking principle (PRP, Robertson 1977) is noteworthy. The PRP states that the optimal document ranking for a query, under independence assumptions, is by descending probability of relevance P(R | d, q). Cross-encoder outputs approximate this probability directly (when trained with binary cross-entropy on relevance labels and passed through sigmoid), making them the closest modern realisation of the PRP from the neural ranker family. This theoretical alignment gives cross-encoders a principled statistical interpretation, complementing their empirical superiority on benchmarks.

  Benchmark performance as of early 2026 on standard tasks:

- MS MARCO Passage Ranking (NDCG@10, Dev Set): BM25 baseline ≈ 31; bi-encoder first stage ≈ 40–45; cross-encoder reranker ≈ 70–74 (monoBERT class); DeBERTa-v3 cross-encoder ≈ 74–76; distilled MiniLM cross-encoder ≈ 68–70
- BEIR Average NDCG@10 (zero-shot, 18 domains): BM25 ≈ 43; bi-encoder ≈ 45–48; cross-encoder ≈ 50–55
- TREC Deep Learning 2022 (NDCG@10): state-of-the-art reranker ≈ 78–82

  The RAGSmith framework (arXiv 2511.01386, 2025) systematically evaluates retrieval pipeline configurations, demonstrating that cross-encoder reranking is the single most impactful component in a RAG pipeline optimisation budget, ahead of chunking strategy, embedding model choice, and hybrid retrieval configuration.

  ## Training Methodology and Data Considerations
  The quality of a cross-encoder reranking model depends critically on the training data composition, negative sampling strategy, and fine-tuning objective. The principal training datasets are:

- **MS MARCO Passage Ranking** (Nguyen et al., 2016): approximately 530,000 queries with human-annotated relevant passages selected from Bing retrieval results. Each query has on average one relevant passage (sparse relevance labels). The training set covers queries across a wide range of information needs. BM25-sampled negatives were the original standard; current practice supplements these with hard negatives mined by the cross-encoder being trained (online hard negative mining) in iterative training rounds.
- **MSMARCO Document Ranking**: A document-level variant with full document inputs rather than passages. Training cross-encoders on document-level data requires sliding-window passage extraction during both training and inference, significantly complicating the data pipeline.
- **Natural Questions (Kwiatkowski et al., 2019)**: 300,000 factoid questions derived from Google search queries with Wikipedia paragraph annotations. Used for QA-specific fine-tuning of cross-encoders.
- **BEIR corpora**: The 18 BEIR domains (including Arguana, NFCorpus, CQADupStack, Quora, SCIDOCS, and others) are used as zero-shot evaluation targets. Fine-tuning on individual BEIR domains produces domain-adapted cross-encoders substantially outperforming the zero-shot baseline.
- **Synthetic training data**: Instruction-tuned LLMs can generate synthetic (query, relevant passage, negative passage) triples from unlabelled text corpora at scale, providing training data for domains where human-annotated relevance judgements are unavailable. GPT-4-generated synthetic training data has been used to train competitive domain-specific cross-encoders for legal and biomedical IR without any human annotation.

  Hard negative mining is the single most impactful training data decision. Three negative sampling strategies have established empirical dominance:
  1. **BM25 negatives**: Passages ranked highly by BM25 for the query but annotated as non-relevant. These are lexically similar to the query but semantically distinct — challenging for cross-encoders trained on random negatives but easier than retriever-based hard negatives.
  2. **Dense retriever negatives**: Passages ranked in positions 50–200 by a dense bi-encoder (ANN retrieval). These are semantically close to the query (the bi-encoder scores them high) but annotated non-relevant — the most challenging and most informative negatives.
  3. **Cross-encoder teacher negatives (online)**: In distillation-based training, the teacher cross-encoder generates soft relevance scores for all candidates; the student is trained to match this score distribution rather than hard binary labels. This provides richer gradient information and produces students within 2 NDCG@10 of the teacher.

  The training objective has measurable impact on final model quality:

- **Pointwise binary cross-entropy** (sigmoid on [CLS] score): Standard baseline; simple to implement; produces calibrated relevance probabilities amenable to score thresholding.
- **Pairwise margin ranking loss**: max(0, margin - score(q, d⁺) + score(q, d⁻)); directly optimises the relative ordering of positive and negative passages; typically 0.5–1.0 NDCG@10 higher than pointwise on MS MARCO.
- **Listwise LambdaLoss / LAMBDARANK**: Optimises a smooth approximation to NDCG directly; typically 1.0–2.0 NDCG@10 higher than pointwise; more complex to implement correctly (requires sorting operations in the backward pass).

  ## Current Landscape (2026)
  By mid-2026, cross-encoder reranking has become a standard component of production RAG stacks. The dominant open-source families are:

- **BGE-Reranker-v2-m3 and v2-gemma** (BAAI, Beijing Academy of Artificial Intelligence): multilingual, supports up to 8k token context, 568M parameters (v2-gemma uses Gemma-2 backbone for improved multilingual coverage). BEIR average NDCG@10 ≈ 55–57.
- **mxbai-rerank-large-v2** (Mixedbread AI): 570M parameters, three-stage training with GRPO + contrastive learning + preference learning, state-of-the-art on BEIR 2025 for open models. Multilingual support for 100+ languages.
- **Jina Reranker v2** (Jina AI): 137M parameters, 8k context window, multilingual, Apache 2.0 licence. Optimised for low-latency production deployment.
- **ms-marco-MiniLM series** (Sentence-Transformers): The original workhorse models; ms-marco-MiniLM-L-6-v2 (22M parameters) and ms-marco-MiniLM-L-12-v2 (33M parameters) remain the most widely deployed open models due to their balance of quality and inference speed.

  Commercial APIs include Cohere Rerank 3 / Rerank 3 Nimble (100+ languages, supports 4096 token documents), Voyage Rerank-2 (instruction-following, optimised for agentic and conversational use cases), Google Vertex AI Reranking API (integrated with Google Cloud RAG), and AWS Bedrock Reranking (available via Amazon Bedrock Agent frameworks). Integration into LangChain, LlamaIndex, Haystack, DSPy, and LlamaStack frameworks is native and idiomatic: a single method call wraps the entire reranking pipeline.

  The principal architectural evolution in 2025–2026 is the convergence of pointwise cross-encoder reranking with listwise LLM ranking into hybrid pipelines: a fast cross-encoder narrows the candidate set to 20–30, and a listwise LLM pass over this compact set refines the ordering for queries requiring multi-hop reasoning or nuanced preference discrimination. This hybrid approach achieves accuracy close to pure LLM listwise reranking at a fraction of the latency and cost. Efficient early-exit cross-encoders (MICE, arXiv 2602.16299, 2025) are being adopted in latency-sensitive settings where per-query budget constraints require adaptive computation. [[Agentic RAG]] pipelines increasingly use rerankers at multiple stages of multi-step retrieval loops, with the reranker serving not only as a precision-improvement step but as a relevance signal to the planning agent about which sub-queries yielded high-quality retrieved contexts and which require reformulation.

  ## UK Context
  The UK has a significant stake in neural information retrieval and reranking research, both in foundational IR theory and in applied deployment contexts.

  **Academic Research Landscape**

  The University of Glasgow's Terrier IR group, founded in the early 2000s by Professor Iadh Ounis and collaborators, is one of the oldest and most influential IR research groups globally. Terrier developed the Terrier IR platform (an open-source search engine used in TREC evaluations) and has contributed foundational work on probabilistic ranking models (PL2, DFR framework), language model-based retrieval, and neural information retrieval. The group's work on learning-to-rank with graph neural networks and their contributions to TREC evaluations directly contextualise the shift to neural cross-encoder reranking. Glasgow also hosts the ECIR (European Conference on Information Retrieval) steering committee and has significant influence on European IR research direction.

  The University of Sheffield's NLP group (including the GATE text engineering group) is active in neural IR for legal and healthcare domains, with contributions to biomedical text mining and clinical NLP that intersect with cross-encoder reranking for medical literature search. Sheffield's Information School has published extensively on user modelling and interactive information retrieval, complementing the technical reranking research with user-centred evaluation frameworks.

  King's College London (Department of Informatics, previously the Information School at the former iSchool) contributes to IR evaluation methodology and digital health information retrieval. The UCL Information Studies group and UCL CS's ML group work on embedding-based retrieval and multi-modal IR.

  **Clinical and Government Applications**

  A 2025 study (arXiv 2510.02967) applying RAG to UK NICE clinical guidelines demonstrated that a hybrid BM25 plus Voyage-3-Large pipeline with Voyage Reranker-2 achieved Recall@1 of 81% and Recall@10 of 99.1%, a substantial improvement over single-stage retrieval. This is directly relevant to NHS clinical decision support deployment: NICE guidelines govern clinical practice across the NHS, and precise retrieval of the relevant guideline subsection for a clinical query can meaningfully reduce the time clinicians spend searching, with patient safety implications if incorrect guidelines are retrieved. The iatroX clinical AI platform and Automedica SmartGuideline both deploy cross-encoder reranking in MHRA-regulated AI systems, operating under the UK Medical Devices Regulations (MDR 2002, as retained post-Brexit and amended by the UK MDR 2024 framework).

  The UK AI Opportunities Action Plan (January 2025) and the Pro-innovation Regulation of AI White Paper (2023) emphasise trustworthy, accurate AI in public sector services. Rerankers, by improving retrieval precision and reducing hallucination risk in government AI deployments, directly address the accuracy requirements cited in UK AI governance frameworks. NHS AI Lab guidance on RAG for clinical settings (published 2024) specifically cites reranking as a recommended practice for improving the safety and accuracy of clinical AI applications.

  GCHQ and the UK intelligence community have long-standing interests in high-precision information retrieval from large document corpora; while specific deployments are not public, the NCSC (National Cyber Security Centre) guidelines on AI in security-sensitive contexts are directly relevant to enterprise cross-encoder reranking deployments handling classified or sensitive enterprise data.

  **Industrial Context in Northern England**

  The Northern England digital economy — particularly in Manchester, Leeds, Sheffield, and Newcastle — includes significant enterprise software and data analytics companies for whom enterprise search is a core product. Manchester-based companies in legal tech (e.g., Weightmans, Slater Gordon's AI subsidiaries) and professional services use neural reranking for document discovery in large case file repositories. The Leeds financial services cluster (Lloyds Banking Group, First Direct, HSBC offices) uses enterprise search with reranking for regulatory compliance document retrieval. The University of Leeds and University of Manchester have active industrial partnerships through their Data Science institutes, and the Alan Turing Institute's Manchester node coordinates industrial AI research that includes information retrieval applications. Newcastle's emerging AI cluster, anchored by Sage Group's AI research arm and Newcastle University's School of Computing, has produced applied RAG systems for enterprise ERP knowledge retrieval.

  The UKRI-funded EPSRC projects on trustworthy AI and information retrieval safety have funded research into cross-encoder robustness: adversarial queries that exploit cross-encoder blind spots, out-of-distribution retrieval failure modes, and fairness in relevance scoring (whether cross-encoders systematically disadvantage certain demographic groups' query styles). This safety-oriented IR research is particularly relevant to UK public sector AI deployment contexts.

  ## Future Directions (2026–2030)

- **Learned sparse + cross-encoder hybrid scoring**: Combining SPLADE-style sparse lexical scores with cross-encoder semantic scores at training time, rather than as separate retrieval and reranking stages, may yield a single-stage system with the precision of cross-encoders at lower latency. Unified learned sparse-dense retrieval models that natively support reranking-quality scoring without a separate second-stage pass are an active research direction.
- **Speculative reranking**: Analogous to speculative decoding in generation, a small draft reranker proposes a tentative ordering that a large oracle reranker verifies only where the draft model is uncertain, reducing average compute per query while maintaining the quality of the oracle on difficult queries. Early results (unpublished 2025) suggest 30–50% FLOPs reduction with less than 0.5 NDCG regression.
- **Self-supervised reranker training from LLM preferences**: Using [[Large Language Model]] to automatically generate training signal (preferred relevance orderings) from unlabelled corpora reduces dependence on expensive human-annotated relevance judgements. Distillation-from-LLM approaches generate synthetic query-passage relevance labels at scale, enabling competitive zero-shot cross-encoders for specialised domains without any human annotation.
- **Multi-modal reranking**: Cross-encoder architectures adapted for query-image, query-table, and query-code scoring, using interleaved text-image token sequences. As RAG expands from text-only to multi-modal corpora (PDFs with figures, code repositories, scientific tables), rerankers must evaluate the relevance of heterogeneous multi-modal passages against text queries.
- **Personalised reranking**: Conditioning the cross-encoder on user interaction history or persona embeddings to produce user-adaptive relevance scores. Personalisation signals (click history, document preference patterns, organisational context) can be injected as additional tokens in the cross-encoder input or as conditioning vectors on the [CLS] representation.
- **On-device reranking**: Sub-100M parameter cross-encoders distilled for mobile and edge deployment, enabling private local RAG without cloud API calls. Models like ms-marco-MiniLM-L-6-v2 (22M parameters) can already run on-device; further quantisation (4-bit) and architectural optimisation (MobileNet-style efficient transformer blocks) will enable real-time reranking on smartphones.
- **Integrated retrieval-reranking architectures**: Research into end-to-end differentiable two-stage systems where the first-stage retriever and second-stage cross-encoder are trained jointly, with the cross-encoder's gradient signal flowing back through the retriever to improve first-stage recall for cases that the cross-encoder correctly identifies as relevant but that the retriever initially misses.
- **Conversational and session-aware reranking**: Extending cross-encoder inputs to include conversation history and previous query-passage interactions, enabling rerankers that model how the user's information need evolves across a multi-turn dialogue, providing better context-aware relevance scoring for [[Agentic RAG]] systems with persistent memory.

  ## Comparison of Reranking Approaches (2026 Summary)
  The following comparison summarises the key approaches across the accuracy-latency-cost dimensions:

| Approach | Latency | NDCG@10 (MS MARCO) | Cost/query | Use Case |
|---|---|---|---|---|
| BM25 only | <10ms | ~31 | negligible | Keyword-heavy queries, resource-constrained |
| Bi-encoder (dense) | <20ms | ~40-45 | low (GPU amortised) | General semantic search |
| [[Hybrid Retrieval]] + BM25 | <30ms | ~44-48 | low | Production first stage |
| [[ColBERT]] late interaction | 50-100ms | ~68-70 | medium | Quality-first with latency budget |
| MiniLM cross-encoder | 80-120ms | ~68-72 | medium | Standard RAG reranking |
| DeBERTa cross-encoder | 300-500ms | ~74-76 | medium-high | High-precision enterprise search |
| LLM listwise (GPT-4) | 4000-8000ms | ~76-80 | high ($0.01-0.03/query) | Offline batch, premium use cases |

This landscape illustrates the fundamental accuracy-latency Pareto frontier: more accurate approaches uniformly require more compute. Cross-encoder reranking occupies the "sweet spot" for most production applications — achieving 90%+ of LLM-quality ranking at 10–100× lower latency and cost.

## Practical Implementation Guide
Implementing cross-encoder reranking in a production RAG pipeline requires decisions across three dimensions: model selection, integration architecture, and evaluation methodology.

**Model Selection**

The choice of cross-encoder model should be driven by latency budget, language coverage, and domain specificity:

- For English-only, latency-sensitive RAG (< 150ms for k=100): ms-marco-MiniLM-L-6-v2 (22M params, ~80ms for k=100 on A100) or ms-marco-MiniLM-L-12-v2 (33M params, ~110ms)
- For multilingual RAG: BGE-Reranker-v2-m3 (568M params, 8k context) or Jina Reranker v2 (137M params, Apache 2.0)
- For maximum quality (< 500ms budget): DeBERTa-v3-large fine-tuned on MS MARCO (435M params)
- For cloud API convenience: Cohere Rerank 3 (single API call, pricing ~$0.002/search unit), Voyage Rerank-2 (instruction-following, better for conversational queries)

  **Integration Architecture**

  The standard integration pattern with LangChain or LlamaIndex:
  1. Define first-stage retriever (dense vector search via Chroma/Weaviate/Pinecone, or BM25 via Elasticsearch/OpenSearch)
  2. Retrieve top-k candidates (k = 50–200 depending on corpus quality)
  3. Apply cross-encoder reranker to score all k candidates against the original query
  4. Select top-r passages (r = 3–10) from the reranked list for the LLM context
  5. Generate response with the [[Large Language Model]] conditioned on the top-r passages

  The reranking step is typically implemented as a reranker class with a `rank(query: str, passages: List[str]) -> List[RankedResult]` interface. The Sentence-Transformers library provides `CrossEncoder.rank()` for this purpose, compatible with all ms-marco and BGE cross-encoder models.

  **Evaluation Methodology**

  Cross-encoder reranking should be evaluated both in isolation (offline ranking metrics on a labelled test set) and end-to-end (downstream RAG answer quality). Offline evaluation uses NDCG@k and MRR@k on a held-out query set with relevance labels, while end-to-end evaluation uses answer correctness metrics (Exact Match, F1, ROUGE-L) or LLM-judged correctness on a curated QA set. A common mistake is optimising offline ranking metrics without evaluating downstream RAG quality: a cross-encoder that improves NDCG@10 from 0.65 to 0.70 should ideally also improve answer F1 or correctness — if it does not, the metric improvement may be artefactual (e.g., the queries in the test set do not represent the actual user query distribution).

  Latency profiling should measure the 50th, 95th, and 99th percentile reranking times, not just mean latency, because cross-encoder inference time varies significantly with sequence length (longer queries and documents take more time). Batching k candidates into a single GPU batch is essential for efficiency: processing each candidate sequentially is 3–5× slower than batched processing.

  **Failure Modes and Mitigations**

  Common failure modes in cross-encoder reranking:

- **Domain shift**: A cross-encoder trained on general web data (MS MARCO) may underperform on specialised domains (legal, medical, financial) where terminology and relevance patterns differ substantially. Mitigation: domain-adapt with fine-tuning on 1,000–10,000 labelled domain-specific query-passage pairs.
- **Long document mismatch**: Cross-encoders trained on short passages (256 tokens) may not perform well on longer documents (1024–8192 tokens). Use models specifically trained at the target context length, or apply passage-level chunking and max-pool the chunk scores.
- **Adversarial queries**: Cross-encoders can be fooled by keyword-stuffed documents that score high despite being irrelevant. Monitoring the score distribution of reranked candidates flags unusual patterns.
- **Out-of-vocabulary terms**: Despite subword tokenisation, highly specialised technical terms (new drug names, emerging technology acronyms) may not be well-represented in the cross-encoder's pre-training vocabulary. Combining cross-encoder reranking with BM25 exact-match retrieval ensures that exact-term matches are retained.

  ## Cross-Encoder Reranking vs. Alternative Architectures: Detailed Comparison

  The cross-encoder reranking paradigm must be understood in relation to the full spectrum of neural information retrieval architectures. Each approach makes different trade-offs between offline/online computation, accuracy, and infrastructure requirements:

  **Inverted Index + BM25 (Classical IR)**

- Offline: Build inverted index from term frequencies; O(N × L) space
- Online: Score query terms against inverted index; O(|query| × k) FLOPs where k is average document frequency
- Strengths: Exact term matching; no GPU required; perfect recall for exact-match queries; highly interpretable scores
- Weaknesses: Cannot handle synonyms, paraphrases, or conceptual queries without keyword overlap; no cross-attention between query and document
- NDCG@10 on MS MARCO Passage: ~31; BEIR average: ~43

  **Bi-Encoder + [[Approximate Nearest Neighbour Search]] (Dense Retrieval)**

- Offline: Encode all documents once with a fine-tuned transformer; store in vector index (HNSW, IVF-PQ); O(N × d) space
- Online: Encode query; ANN lookup in vector index; O(log N × d) FLOPs
- Strengths: Captures semantic similarity beyond keyword overlap; fast online inference; scales to billions of documents with product quantisation
- Weaknesses: Document representation is independent of query; cannot capture fine-grained query-conditional relevance; requires GPU for encoding
- NDCG@10 on MS MARCO Passage: ~40-45; BEIR average: ~45-48

  **[[ColBERT]] Late Interaction**

- Offline: Encode all document tokens with ColBERT; store token embeddings (with optional compression); O(N × L × d) space
- Online: Encode query tokens; compute MaxSim between query and document token embeddings via ANN lookup; O(|query| × k × d) FLOPs
- Strengths: Token-level cross-attention without full cross-encoder cost; 100-1000× faster than cross-encoder at inference; near cross-encoder accuracy
- Weaknesses: Large index size (50–150 GB for 8.8M MS MARCO passages at full precision); specialised infrastructure; limited to text
- NDCG@10 on MS MARCO Passage: ~68-71; BEIR average: ~50-52

  **Cross-Encoder Reranking (Full Cross-Attention)**

- Offline: No document pre-encoding required
- Online: Joint forward pass over [CLS] query [SEP] document [SEP]; O(k × L² × d) FLOPs where k is candidate set size and L is joint sequence length
- Strengths: Full cross-attention between query and all document tokens; highest precision; can condition document salience on the specific query aspect
- Weaknesses: Cannot scale to full corpus; requires pre-retrieval stage; O(k) forward passes per query; GPU required for sub-second latency
- NDCG@10 on MS MARCO Passage: ~72-76; BEIR average: ~52-56

  **LLM Listwise Reranking (RankGPT, LLM-based)**

- Offline: None
- Online: Prompt LLM with query + list of k passages; generate ranked order; O(k × L × d_LLM) FLOPs
- Strengths: Highest accuracy ceiling (access to LLM's full reasoning capabilities); handles queries requiring multi-hop reasoning and nuanced preference discrimination
- Weaknesses: Extremely high latency (4–8 seconds) and cost ($0.01–0.05/query at GPT-4 pricing); not viable for real-time applications; candidate set limited by LLM context window
- NDCG@10 on MS MARCO Passage: ~76-80; BEIR average: ~54-58

  This comparison reveals the clear niche for cross-encoder reranking: it provides the highest accuracy achievable with sub-500ms latency, making it the optimal choice for the vast majority of production retrieval applications that require both quality and real-time response.

  ## Evaluation Metrics and Benchmarks: Detailed Reference

  Cross-encoder reranking quality is evaluated using a standardised suite of metrics and benchmarks. Understanding these is essential for comparing models and interpreting published results:

  **NDCG@k (Normalised Discounted Cumulative Gain)**
  NDCG@k is the primary metric for multi-grade relevance assessments. Given ranked list r₁, r₂, ..., rₖ with relevance grades g₁, g₂, ..., gₖ:

  DCG@k = ∑_{i=1}^{k} (2^{gᵢ} - 1) / log₂(i + 1)
  NDCG@k = DCG@k / IDCG@k

  where IDCG@k is the ideal (maximum) DCG achievable with perfect ranking. Relevance grades in TREC Deep Learning are 0 (not relevant), 1 (related), 2 (highly relevant), 3 (perfectly relevant). The logarithmic discounting (log₂(i+1)) penalises relevant documents appearing lower in the ranking. NDCG@10 is the primary metric for passage ranking comparisons.

  **MRR@k (Mean Reciprocal Rank)**
  MRR@k = (1/|Q|) ∑_{q∈Q} 1/rank(first relevant document for q, within top k)

  MRR@10 is the primary metric for MS MARCO passage ranking, where each query typically has one relevant passage. It evaluates whether the cross-encoder successfully places the relevant passage at rank 1 (reciprocal rank 1.0) versus rank 2 (0.5) versus further down (lower scores).

  **MAP (Mean Average Precision)**
  MAP = (1/|Q|) ∑_{q∈Q} AP(q), where AP(q) = (1/R) ∑_{k=1}^{n} P(k)·rel(k)

  MAP weights each relevant document by the precision at the rank it appears. Less commonly used for passage reranking (where MRR@10 and NDCG@10 dominate) but standard for document reranking evaluations.

  **Recall@k**
  Recall@k = (number of relevant documents in top-k) / (total relevant documents)

  Recall@k measures first-stage retrieval quality — whether the relevant documents are present in the candidate set that the cross-encoder reranks. Cross-encoder reranking cannot recover from first-stage recall failures. Typical targets: Recall@100 ≥ 95% for the first-stage retriever to ensure the cross-encoder has sufficient material to work with.

  **BEIR (Benchmarking IR) Benchmark Structure**
  BEIR comprises 18 datasets spanning diverse retrieval tasks:

- Argument retrieval: Arguana, Touché-2020
- Citation prediction: Scidocs, Signal-1M, TREC-News
- Duplicate question retrieval: CQADupStack, Quora
- Entity retrieval: DBPedia-Entity
- Fact checking: Climate-FEVER, FEVER, SciFact
- Question answering: FiQA-2018, NQ, HotpotQA, BioASQ
- Tweet retrieval: Signal-1M
- Other: TREC-COVID, NFCorpus, Robust04

  Zero-shot evaluation on BEIR (training on MS MARCO only, evaluation without fine-tuning) reveals generalisation quality. Cross-encoders generalise better than bi-encoders on most BEIR domains, with particular advantages on argument retrieval (Arguana) and fact-checking (Climate-FEVER) where deep semantic understanding matters more than keyword overlap.

  ## Research and Literature
  1. Nogueira, R. and Cho, K. (2019). "Passage Re-ranking with BERT." arXiv:1901.04085.
  2. Nguyen, T. et al. (2016). "MS MARCO: A Human Generated Machine Reading Comprehension Dataset." NeurIPS 2016 Workshop.
  3. Craswell, N. et al. (2020). "Overview of the TREC 2019 Deep Learning Track." TREC 2019.
  4. Thakur, N. et al. (2021). "BEIR: A Heterogeneous Benchmark for Zero-Shot Evaluation of Information Retrieval Models." NeurIPS 2021.
  5. Khattab, O. and Zaharia, M. (2020). "ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT." SIGIR 2020.
  6. Hofstatter, S. et al. (2021). "Efficiently Teaching an Effective Dense Retriever with Balanced Topic Aware Sampling." SIGIR 2021.
  7. Pradeep, R. et al. (2021). "The Expando-Mono-Duo Design Pattern for Text Ranking with Pretrained Sequence-to-Sequence Models." arXiv:2101.05667.
  8. Sun, W. et al. (2023). "Is ChatGPT Good at Search? Investigating Large Language Models as Re-Ranking Agents." EMNLP 2023.
  9. Ma, X. et al. (2024). "Fine-Tuning LLaMA for Multi-Stage Text Ranking with Combined Retrieve-and-Rerank." arXiv:2304.09542.
  10. Formal, T. et al. (2021). "SPLADE: Sparse Lexical and Expansion Model for First Stage Retrieval." SIGIR 2021.
  11. Lin, J. and Ma, X. (2021). "A Few Brief Notes on DeepImpact, COIL, and a Conceptual Framework for Information Retrieval Techniques." arXiv:2106.14807.
  12. Qu, Y. et al. (2021). "RocketQA: An Optimized Training Approach to Dense Passage Retrieval for Open-Domain Question Answering." NAACL 2021.
  13. Gao, L. et al. (2022). "Unsupervised Corpus Aware Language Model Pre-training for Dense Passage Retrieval." ACL 2022.
  14. Zhan, J. et al. (2021). "Jointly Optimizing Query Encoder and Product Quantization to Improve Retrieval Performance." CIKM 2021.
  15. Karpukhin, V. et al. (2020). "Dense Passage Retrieval for Open-Domain Question Answering." EMNLP 2020.
  16. Xiong, L. et al. (2021). "Approximate Nearest Neighbor Negative Contrastive Estimation for Dense Text Retrieval." ICLR 2021.
  17. Nguyen, K. et al. (2024). "mxbai-rerank-large-v2: Mixedbread AI Reranking Model." Technical Report. Mixedbread AI.
  18. Cohere Inc. (2024). "Rerank 3: Improved Reranking for Enterprise RAG." Technical Blog, Cohere.
  19. Voyage AI (2024). "Voyage Rerank-2: Instruction-Following Reranking." Technical Blog, Voyage AI.
  20. Li, Z. et al. (2025). "Scaling Laws for Cross-Encoder Reranking." arXiv:2603.04816.
  21. Ahmad, I. et al. (2025). "MICE: Minimal Interaction Cross-Encoders for Efficient Re-ranking." arXiv:2602.16299. (SIGIR 2025).
  22. Salemi, A. et al. (2024). "ARAGOG: Advanced RAG Output Grading." arXiv:2404.01037.
  23. Gupta, S. et al. (2025). "Grounding Large Language Models in Clinical Evidence: A RAG System for Querying UK NICE Clinical Guidelines." arXiv:2510.02967.
  24. Wang, L. et al. (2025). "Contrastive Learning Falls Short: Improving Dense Retrieval with Cross-Encoder Listwise Distillation and Synthetic Data." ECIR 2025.
  25. Robertson, S. and Zaragoza, H. (2009). "The Probabilistic Relevance Framework: BM25 and Beyond." Foundations and Trends in Information Retrieval 3(4).
  26. Reimers, N. and Gurevych, I. (2019). "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks." EMNLP 2019.
  27. Guo, J. et al. (2024). "Multi-criteria Reranking: Scaling RAG Systems with Inference-Time Compute." arXiv:2504.07104.
  28. Robertson, S. (1977). "The Probability Ranking Principle in IR." Journal of Documentation 33(4): 294–304.
  29. Burges, C. et al. (2005). "Learning to Rank using Gradient Descent." ICML 2005. (RankNet)
  30. RAGSmith Team (2025). "RAGSmith: A Framework for Finding the Optimal Composition of RAG Methods Across Datasets." arXiv:2511.01386.

  ## Connections to Related Retrieval Paradigms
  Cross-encoder reranking exists within a broader landscape of neural retrieval approaches, each occupying a distinct point in the accuracy-latency trade-off space. Understanding these connections illuminates when each approach is appropriate:

- **[[Dense Retrieval]] (bi-encoder)**: Pre-computes document embeddings offline; at query time, embeds the query and retrieves via [[Approximate Nearest Neighbour Search]]. Latency O(log N) — suitable for first-stage retrieval over millions of documents. Quality limited by the inability to condition document representation on the specific query.
- **[[BM25]] (sparse retrieval)**: Retrieves using exact lexical term matching and statistical term weighting; zero training required; excellent at rare term queries; misses paraphrase and synonymy. Still the most commonly used first-stage retriever in production systems due to its simplicity, speed, and interpretability.
- **[[Hybrid Retrieval]]**: Combines BM25 and dense retrieval via [[Reciprocal Rank Fusion]] or learned score combination. Captures both lexical precision and semantic recall. In practice, hybrid first-stage retrieval improves recall over either method alone, providing the cross-encoder with a better candidate set.
- **[[ColBERT]] (late interaction)**: Pre-computes all document token embeddings; at query time, computes MaxSim scores between query token embeddings and pre-computed document embeddings. 100–1000× faster than full cross-encoder inference; within 2–3 NDCG@10 of cross-encoder. Requires specialised vector storage (approximately 50–150 GB for 8.8M MS MARCO passages).
- **Cross-encoder reranking**: Full bidirectional cross-attention between query and document tokens; highest accuracy; no precomputation possible; O(k) forward passes at query time. Optimal for precision-critical applications with sufficient latency budget (>100ms per query).
- **LLM listwise reranking (RankGPT)**: Uses a generative LLM to directly output a ranked list; highest accuracy ceiling for reasoning-heavy queries; orders of magnitude higher latency and cost. Suitable only for offline batch reranking or very high-value, low-volume queries.

  The architectural choice should be driven by the specific application's requirements:

- Real-time consumer search (< 50ms budget): [[BM25]] or bi-encoder only
- Production RAG with 200ms budget: [[Hybrid Retrieval]] first stage + cross-encoder reranking
- High-precision enterprise search with 500ms budget: [[Hybrid Retrieval]] + large cross-encoder + optional LLM reranking for top-5 results
- Offline document ranking (no latency constraint): LLM listwise reranking over full cross-encoder candidates

  The integration of [[Knowledge Distillation]] across these paradigms has created a coherent training pipeline: a large LLM generates ranking supervision (listwise), which trains a large cross-encoder teacher, which distils to a smaller cross-encoder student, which in turn distils to a bi-encoder with dense retrieval capability. This distillation cascade transfers accuracy from the most powerful (but slowest) reranker to the most efficient (but less accurate) retriever, enabling the entire accuracy of the teacher to propagate through the retrieval stack.

  ## Security, Privacy, and Governance Considerations
  Cross-encoder reranking in production systems introduces several security and governance considerations that are increasingly important in regulated industries and public sector deployments:

  **Data Privacy in Reranking APIs**: When using cloud cross-encoder APIs (Cohere, Voyage, Jina), the query and candidate passages are transmitted to third-party servers. For UK NHS deployments, this raises ICO GDPR considerations: patient queries and clinical document excerpts may constitute personal or sensitive health data. On-premises cross-encoder deployment (self-hosted HuggingFace models) or UK-sovereign cloud deployments (Microsoft Azure UK South, AWS EU-West-2) are preferred for GDPR-compliant clinical RAG systems.

  **Adversarial Robustness**: Cross-encoder rerankers can be manipulated by adversarial document injection: an attacker who can insert a crafted document into the retrieval corpus can create it to score highly for specific queries while containing misleading content. Mitigations include access control over the document corpus, monitoring score distributions for anomalous patterns, and adversarial training on known attack patterns.

  **Fairness and Bias in Relevance Scoring**: Cross-encoders trained on web search data may encode demographic and cultural biases — for example, scoring documents in standard business English higher than those in regional dialects, even when content is equally relevant. For UK public sector applications serving linguistically diverse communities, bias testing of relevance scores across query styles is a recommended governance practice.

  **Explainability of Ranking Decisions**: The cross-encoder's relevance score is a scalar from a complex transformer computation with no direct interpretability. For regulated applications (financial advice, medical information, legal research) where retrieval decisions must be auditable, attention visualisation techniques (LIME, integrated gradients) can provide approximate explanations of which query and document tokens most influenced the relevance score.

  **Compute Cost and Carbon Footprint**: Cross-encoder inference is GPU-intensive. For large-scale deployments, the energy cost of reranking 100 candidates × millions of queries/day is substantial. Distilled small cross-encoders (MiniLM, 22M params) reduce energy consumption by 10–15× versus full DeBERTa-v3 (435M params) with acceptable quality reduction, enabling more sustainable deployment decisions.

  ## Key Terminology

- **Cross-encoder**: A transformer model that takes query and document concatenated as a single input and produces a joint representation, enabling full cross-attention between all query and document tokens.
- **Bi-encoder**: A model with two independent encoding towers (one for query, one for document) that computes relevance via dot-product between independent representations; query and document cannot attend to each other.
- **NDCG@k**: Normalised Discounted Cumulative Gain at rank k; the primary ranking quality metric, discounting gains from lower-ranked relevant items logarithmically. Higher is better; maximum value 1.0.
- **MRR@k**: Mean Reciprocal Rank at k; evaluates the rank of the first relevant result, useful when only one correct answer exists. Common in QA evaluation.
- **BEIR**: Benchmarking Information Retrieval; an 18-domain zero-shot evaluation benchmark spanning heterogeneous retrieval tasks from argument retrieval to biomedical search.
- **MS MARCO**: Microsoft MAchine Reading COmprehension; the dominant passage ranking training and evaluation dataset, derived from Bing search logs with human-annotated relevance labels; approximately 530,000 training queries.
- **Hard negatives**: Training negatives retrieved by a strong retriever (BM25 or dense retriever) that are semantically close to the query but annotated as non-relevant; more informative training signal than random negatives.
- **Listwise reranking**: A reranking approach that considers all candidates jointly and produces a ranked list output, rather than scoring each pair independently (pointwise) or each pair of documents (pairwise).
- **Two-stage retrieval**: The retrieve-then-rerank paradigm: fast first-stage (bi-encoder/BM25) followed by precise second-stage (cross-encoder).
- **Recall@k**: The fraction of relevant documents appearing in the top-k retrieved results; the primary metric for first-stage retrieval quality, as cross-encoder reranking cannot recover documents not in the candidate set.
- **TREC Deep Learning Track**: The annual TREC evaluation track for passage and document ranking, providing human-graded relevance judgements at scale (hundreds of queries × thousands of assessed documents per query).
- **MaxSim (ColBERT)**: The maximum similarity score between a query token embedding and any document token embedding; the interaction mechanism in late-interaction models.
- **LambdaRANK/LambdaLoss**: Gradient estimation methods for ranking metrics (NDCG) that are not directly differentiable; enables direct optimisation of ranking metrics in the cross-encoder training objective.
- **Probability Ranking Principle (PRP)**: Robertson's 1977 principle that the optimal document ranking is by descending probability of relevance; cross-encoder sigmoid outputs directly approximate this probability.
- **Teacher-forcing in ranking distillation**: Using soft relevance scores from a large teacher cross-encoder as training targets for a smaller student, providing richer gradient information than hard binary relevance labels.

  ## LinkResolutionAnnotations

- [[Information Retrieval]] → urn:ngm:class:information-retrieval
- [[Semantic Search]] → urn:ngm:class:semantic-search
- [[Dense Retrieval]] → urn:ngm:class:dense-retrieval
- [[BM25]] → urn:ngm:class:bm25
- [[Hybrid Retrieval]] → urn:ngm:class:hybrid-retrieval
- [[Embedding Model]] → urn:ngm:class:embedding-model
- [[BERT]] → urn:ngm:class:bert
- [[Self-Attention]] → urn:ngm:class:self-attention
- [[Attention Mechanism]] → urn:ngm:class:attention-mechanism
- [[Transformer]] → urn:ngm:class:transformer
- [[Retrieval-Augmented Generation]] → urn:ngm:class:retrieval-augmented-generation
- [[RAG Pipeline]] → urn:ngm:class:rag-pipeline
- [[ColBERT]] → urn:ngm:class:colbert
- [[Knowledge Distillation]] → urn:ngm:class:knowledge-distillation
- [[Large Language Model]] → urn:ngm:class:large-language-models
- [[Approximate Nearest Neighbour Search]] → urn:ngm:class:approximate-nearest-neighbour-search
- [[Cosine Similarity]] → urn:ngm:class:cosine-similarity
- [[Contrastive Learning]] → urn:ngm:class:contrastive-learning
- [[Reciprocal Rank Fusion]] → urn:ngm:class:reciprocal-rank-fusion
- [[Document Retrieval]] → urn:ngm:class:document-retrieval
- [[Question Answering]] → urn:ngm:class:question-answering
- [[Enterprise Search]] → urn:ngm:class:enterprise-search
- [[Natural Language Processing]] → urn:ngm:class:natural-language-processing
- [[Agentic RAG]] → urn:ngm:class:agentic-rag
- [[Dense Passage Retrieval]] → urn:ngm:class:dense-passage-retrieval
- [[Knowledge Retrieval]] → urn:ngm:class:knowledge-retrieval
- [[Neural Information Retrieval]] → urn:ngm:class:neural-information-retrieval

### Provenance

