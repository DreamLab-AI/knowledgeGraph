Credential verification is the process of cryptographically or institutionally confirming the authenticity, integrity, and current validity of a credential — such as a digital certificate, verifiable credential, or identity assertion — issued by a trusted authority about a subject, so that a relying party can grant access or trust without real-time contact with the original issuer. In decentralised identity systems it relies on public-key cryptography, digital signatures, and optionally distributed ledgers to enable privacy-preserving, tamper-evident verification. The process must also resolve issuer keys and query revocation registries (via CRL, OCSP, or on-chain status) to ensure invalidated credentials cannot be fraudulently reused. Selective-disclosure techniques, including zero-knowledge proofs and SD-JWTs, allow subjects to prove specific attributes without exposing unnecessary personal data.

### Overview

- Credential verification sits at the heart of digital trust infrastructure. Wherever a system must confirm that a party possesses a right, qualification, or attribute asserted by a third party, credential verification is the technical mechanism that makes that confirmation reliable without requiring synchronous contact with the issuer.
- The classic model is the three-party triangle: an **issuer** (e.g. a government, university, or employer) cryptographically signs a structured credential about a **subject**; the subject presents the credential (or a derived proof) to a **verifier**; the verifier checks the signature, validates the structure, and confirms revocation status.
- Historically this process was institutionally mediated — sealed letters, notarised documents, in-person checks. Digital credential verification began with X.509 certificates and the [[Public Key Infrastructure]] underpinning SSL/TLS, which enabled automated machine-to-machine trust at scale. The emergence of [[Decentralized Identity (DID)]] and the [[W3C Verifiable Credentials Data Model]] data model has extended this paradigm to person-centric credentials that individuals can carry and present across multiple services.
- Credential verification is distinct from [[Credential Issuance]] (the act of creating and signing the credential) and from [[Authentication]] in its narrow sense (proving you are who you claim to be via a secret). Verification asserts *properties about a subject* based on claims from a trusted issuer rather than relying on secrets the subject holds.

### Key Components

#### Cryptographic Proof Verification

- The verifier checks the [[Digital Signature]] (commonly EdDSA or ECDSA) or [[Zero-Knowledge Proof]] attached to the credential against the issuer's public key.
- For W3C Verifiable Credentials the proof may use [[Linked Data Proofs]] (JSON-LD canonicalisation + signature) or the more compact **JWT** or **SD-JWT** envelope.
- BBS+ signatures enable unlinkable [[Selective Disclosure]] across multiple presentations of the same credential.

#### Issuer Key Resolution

- For DID-based credentials the verifier resolves the issuer's [[Decentralised Identifier]] via a [[DID Resolver]] to retrieve the DID Document containing the verification method (public key).
- For X.509-based credentials (TLS, mDL, eIDAS) the verifier traverses a certificate chain up to a trusted [[Certificate Authority]] root.
- The [[Trust Anchor]] defines the root of the trust hierarchy; mismatches cause verification failure.

#### Schema and Semantic Validation

- The verifier checks that all mandatory claims defined by the [[Credential Schema]] are present and correctly typed.
- Presentation Exchange (PE) descriptors define what claims a verifier requires and the acceptable proof formats.
- JSON Schema or SHACL constraints enforce structural integrity.

#### Revocation Status Check

- A credential may have been validly issued but subsequently revoked (e.g. licence suspended, employee terminated).
- Mechanisms include: Certificate Revocation Lists (CRL), Online Certificate Status Protocol ([[OCSP]]), W3C Status List 2021, Bitstring Status List, and on-chain [[Smart Contract]] registries.
- Privacy-preserving revocation (e.g. accumulator-based schemes) hides *which* credentials are revoked while still enabling individual status checks.

#### Presentation Protocol

- The [[OpenID4VC]] family (OpenID for Verifiable Presentations — OID4VP; OpenID for Credential Issuance — OID4CI) standardises how presentations are requested and delivered over OAuth-style HTTP flows.
- ISO 18013-5 (mDL) uses device engagement via QR code or NFC, with a device-bound key providing holder binding.
- DIF Presentation Exchange defines the descriptor format for credential requirements.

### Mechanisms and Protocols

- **JWT-based VCs**: a compact, widely supported format; the credential payload is Base64url-encoded JSON signed with JWS. Easy to validate with standard JWT libraries.
- **SD-JWT** (Selective Disclosure JWT): extends JWT to allow holders to selectively disclose individual claims. The issuer hashes each claim separately; the holder reveals only chosen hashes plus their preimages. Adopted in EU Digital Identity Wallet (EUDI) and ISO 18013-7.
- **JSON-LD Linked Data Proofs**: semantically rich, enables interoperability across different vocabulary systems, but more complex to implement due to RDF canonicalisation.
- **BBS+ / BBS Signatures**: pairing-based signatures supporting multi-message signing with per-message selective disclosure and unlinkable proofs. Used in Hyperledger Anoncreds.
- **ISO 18013-5 (mDL)**: device-centric model where the credential is stored on a mobile device with a device key providing holder binding; verifier authenticates device and checks issuer signature on the mobile document (mdoc) format.

### Applications and Use Cases

- **Government and Civic Identity**: National digital ID wallets (EU EUDI Wallet, UK DIATF, Singapore MyInfo) issue verifiable credentials for passports, driving licences, and benefit entitlements; verifiers confirm them in real time at border control or online services.
- **Professional Licensing**: Medical councils, bar associations, and engineering bodies issue digitally signed licence credentials; employers and regulators can verify these instantly without phoning the issuing body.
- **Academic Qualifications**: Universities issue digital diplomas as [[Verifiable Credential|Verifiable Credentials]] (see MIT Digital Credentials Consortium, Open Badges v3); background-check services verify them in seconds rather than weeks.
- **Healthcare**: Clinicians' credentials (GMC registration, DEA licence) are verified before granting access to prescribing systems or medical records, often through [[Access Control]] policies.
- **Decentralised Finance KYC / AML**: [[Know Your Customer]] compliance requires verifying identity documents; reusable KYC credentials allow a subject to prove compliance to multiple DeFi platforms without re-submitting raw documents.
- **Age Verification**: Privacy-preserving age credentials prove "over 18" to content platforms without disclosing date of birth; critical for GDPR / UK Online Safety Act compliance.
- **Supply-Chain Provenance**: Organisations verify supplier certifications (ISO 9001, fair-trade, carbon offsets) using [[Distributed Ledger Technology]]-anchored credentials, reducing audit fraud.
- **Cross-Border Travel**: ICAO Digital Travel Credentials (DTC) extend passport verification to cryptographically signed mobile credentials readable at e-gates.
- **Enterprise IAM**: Employees carry portable, cryptographically bound employment credentials usable across partner organisations without central directory lookups.

### Standards and Context

- **W3C Verifiable Credentials Data Model 2.0** (2024): defines the core JSON-LD data model for credentials and presentations, including proof mechanisms and status checking.
- **OpenID4VC** (OID4VCI + OID4VP): OAuth-based protocols for credential issuance and presentation over HTTPS, widely adopted in EUDI Wallet and US mDL ecosystems.
- **ISO/IEC 18013-5** (mDL): defines the mdoc format and device engagement protocols for mobile driving licences; extended by ISO 18013-7 for online flows.
- **ISO/IEC 27001 / NIST SP 800-63-3**: broader identity assurance frameworks within which credential verification sits as a key technical control.
- **eIDAS 2.0 (EU 2024/1183)**: mandates EU member states to provide EUDI Wallets; Verifiable Credentials and SD-JWT are the prescribed credential formats.
- **DIF Presentation Exchange**: decentralised identity foundation specification for expressing verifier credential requirements and matching against holder capabilities.
- **IETF RFC 9278 (JWK Thumbprint URI)**, **RFC 8392 (CBOR Web Tokens)**, **RFC 7519 (JWT)**: foundational token standards underlying most VC proof formats.
- **Hyperledger Anoncreds**: open-source implementation of BBS+-based anonymous credential schemes with built-in revocation via cryptographic accumulators.
- **GAIN (Global Assured Identity Network)**: industry initiative to federate national identity systems using OIDC and VC-based verification.

### Security Considerations

- **Holder Binding**: a credential must be cryptographically bound to its holder to prevent replay by a different party; achieved via holder keys referenced in the credential subject or device-bound keys in mDL.
- **Replay Attacks**: presentation nonces or challenge-response mechanisms prevent a captured presentation from being reused.
- **Issuer Impersonation**: verifiers must trust only known issuer DIDs/certificate chains; open trust registries (e.g. EU Trusted Lists) enumerate legitimate issuers.
- **Linkability**: naive presentation of the same credential to multiple verifiers may allow correlation; BBS+ proofs and SD-JWT blinding factors mitigate this.
- **Clock Skew**: expiry checks depend on accurate clocks; systems must handle NTP drift and grace periods carefully.
- **Quantum Threats**: current EC-based signatures (ECDSA, EdDSA) are vulnerable to sufficiently large quantum computers; NIST PQC standards (ML-DSA, SLH-DSA) are expected to be adopted in long-lived credential ecosystems.

### Current Landscape (2026)

- On 15 May 2025 the W3C published the Verifiable Credentials 2.0 family as seven Recommendations (including Data Model v2.0, Data Integrity 1.0, EdDSA/ECDSA Cryptosuites, and Bitstring Status List), giving verifiers a stable, formally standardised basis for cryptographic credential checking.
- VC Data Model 2.0 deliberately admits multiple securing mechanisms (Data Integrity proofs, JOSE/COSE, and SD-JWT) rather than mandating one, which improves flexibility but means "supports verifiable credentials" no longer guarantees interoperability between an issuer and a verifier.
- The new specifications are explicitly "crypto-modular" to accommodate post-quantum cryptography (PQC) and zero-knowledge proofs (ZKPs), and prioritise selective disclosure so a holder can prove an attribute (e.g. being over 18) without revealing the underlying data.
- The W3C Digital Credentials API reached First Public Working Draft on 1 July 2025 in the Federated Identity Working Group, letting websites request credentials from wallets; Google and Apple are already shipping early implementations, though unlinkability and privacy issues remain unresolved.
- Under the revised eIDAS Regulation (EU 2024/1183, in force 20 May 2024), every EU member state must offer at least one certified EU Digital Identity (EUDI) Wallet by 24 December 2026, with mandatory acceptance by regulated relying parties (banks, telecoms, VLOPs) following in late 2027; W3C VCDM 2.0 is a referenced standard in the ARF alongside ISO/IEC 18013-5 mdoc and SD-JWT VC.
- Practitioner consensus in 2026 is that the December 2026 EUDI deadline will be met formally but not substantively: analysts such as Trinsic and Signicat predict only around half of member states will have fully compliant production wallets, with many launching thin shells of limited credential types until well into 2027.
- In the US, mobile driver's licences (mDLs) conforming to ISO/IEC 18013-5 continue to spread across states via Apple, Google and Samsung Wallet, but rollout is uneven, with several states (e.g. Florida, Oklahoma) having paused or pulled apps.
- The frontier challenge as of 2026 is governance rather than cryptography: relying-party registration, who is authorised to verify, cross-border reciprocity, revocation/status handling at scale, and viable business models remain the main barriers to widespread verifier adoption.

### References

- 1. W3C (2025). W3C publishes Verifiable Credentials 2.0 as a W3C Standard. https://www.w3.org/press-releases/2025/verifiable-credentials-2-0/
- 2. W3C (2025). The Verifiable Credentials 2.0 family of specifications is now a W3C Recommendation. https://www.w3.org/news/2025/the-verifiable-credentials-2-0-family-of-specifications-is-now-a-w3c-recommendation/
- 3. W3C (2025). W3C Digital Credentials API publication: the next step to privacy-preserving identities on the web. https://www.w3.org/blog/2025/w3c-digital-credentials-api-publication-the-next-step-to-privacy-preserving-identities-on-the-web/
- 4. eIDAS-Pro (2026). EU 27 EUDI Wallet Readiness Scorecard, April 2026. https://eidas-pro.com/blog/eu-27-eudi-wallet-readiness-scorecard-april-2026
- 5. Corbado (2025). Mobile Driver's License are here: ultimate Guide to mDLs. https://www.corbado.com/blog/mobile-drivers-license

### Provenance

