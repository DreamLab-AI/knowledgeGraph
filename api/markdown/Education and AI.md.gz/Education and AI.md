Education and AI (Artificial Intelligence in Education, AIED) denotes the deployment of machine-learning systems—intelligent tutoring systems (ITS) such as Carnegie Learning Mathia at 600K+ US students across + districts, ALEKS at 25M+ cumulative users Knewton (acquired Wiley 2019 for ~after rais...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:hasPart ai:IntelligentTutoringSystem))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:hasPart ai:AITutor))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:hasPart ai:AutomatedGrading))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:hasPart ai:AdaptiveLearning))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:hasPart ai:AILiteracyCurriculum))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:hasPart ai:LearningAnalytics))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:hasPart ai:KnowledgeTracing))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:hasPart ai:AIDetection))

    ## Dependency Relationships
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:requires ai:LargeLanguageModels))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:requires ai:PedagogicalTheory))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:requires ai:StudentData))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:requires ai:Curriculum))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:requires ai:TeacherOversight))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:requires ai:AssessmentFramework))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:requires ai:SafeguardingPolicy))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:dependsOn ai:CognitiveScience))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:dependsOn ai:LearningSciences))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:dependsOn ai:EducationalPsychology))

    ## Capability Relationships
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:enables ai:PersonalisedLearning))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:enables ai:MasteryLearning))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:enables ai:ScalableTutoring))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:enables ai:FormativeFeedback))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:enables ai:TeacherTimeRecovery))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:enables ai:AccessibilityProvisioning))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:enables ai:DifferentiatedInstruction))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:supports ai:Khanmigo))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:supports ai:CarnegieLearningMathia))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:supports ai:DuolingoMax))

    ## Implementation Relationships
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:implements ai:SocraticDialogue))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:implements ai:BayesianKnowledgeTracing))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:implements ai:ItemResponseTheory))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:implements ai:SpacedRepetition))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:implements ai:RetrievalPractice))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:implements ai:WorkedExampleGeneration))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:implements ai:RubricBasedAssessment))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:uses ai:GPT4))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:uses ai:Claude))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:uses ai:Gemini))

    ## Reduction Relationships
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:reduces ai:TeacherAdministrativeBurden))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:reduces ai:LearningInequity))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:reduces ai:GradingTime))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:reduces ai:OneSizeFitsAllInstruction))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:reduces ai:RemedialAccessGap))

    ## Association Relationships
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:relatedTo ai:GenerativeAI))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:relatedTo ai:ConversationalAI))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:relatedTo ai:AIEthics))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:relatedTo ai:Datafication))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:relatedTo ai:AILiteracy))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:contrastsWith ai:TraditionalClassroomInstruction))
    SubClassOf(ai:EducationAndAI
      ObjectSomeValuesFrom(ai:contrastsWith ai:BehaviouristDrillAndPractice))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ai:hasIdentifier ai:EducationAndAI "AI-1051"^^xsd:string)
    DataPropertyAssertion(ai:authorityScore ai:EducationAndAI "0.87"^^xsd:decimal)
    DataPropertyAssertion(ai:itsEffectSizeMedian ai:EducationAndAI "0.66"^^xsd:decimal)
    DataPropertyAssertion(ai:khanmigoStudents2024 ai:EducationAndAI "1000000"^^xsd:integer)
    DataPropertyAssertion(ai:squirrelAIStudents ai:EducationAndAI "5000000"^^xsd:integer)
    DataPropertyAssertion(ai:magicSchoolEducators ai:EducationAndAI "4000000"^^xsd:integer)
    DataPropertyAssertion(ai:duolingoMAU ai:EducationAndAI "113100000"^^xsd:integer)
    DataPropertyAssertion(ai:teensUsingChatGPTSchoolwork ai:EducationAndAI "0.26"^^xsd:decimal)

    ## Property Constraints
    SubClassOf(ai:EducationAndAI
      DataAllValuesFrom(ai:requiresHumanOversight xsd:boolean))
    SubClassOf(ai:EducationAndAI
      DataSomeValuesFrom(ai:targetEducationLevel xsd:string))
    SubClassOf(ai:EducationAndAI
      DataMinCardinality(1 ai:hasSafeguardingPolicy xsd:string))
    SubClassOf(ai:EducationAndAI
      DataMinCardinality(1 ai:hasAssessmentIntegrityPolicy xsd:string))

    ## Annotations
    AnnotationAssertion(rdfs:label ai:EducationAndAI "Education and AI"@en)
    AnnotationAssertion(rdfs:comment ai:EducationAndAI "Application domain encompassing intelligent tutoring systems (Mathia, ALEKS, Squirrel AI, Knewton), AI tutors built on LLMs (Khanmigo, Synthesis Tutor, MagicSchool, QANDA, Brilliant), generative AI assistants in classrooms (ChatGPT/Claude/Gemini), AI grading (Gradescope, Turnitin AI Detection v2), adaptive language learning (Duolingo Max, Speak, Babbel AI), accessibility (Immersive Reader, Live Captions), and AI literacy curricula, validated by Kulik & Fletcher 2016 d=0.66 meta-analysis and Mollick/World Bank Nigeria 2024 2-years-gains-in-6-weeks, shaped by 2023-2026 policy oscillations (NYC DOE ban/rescission, LA Unified Ed collapse, Ofqual, IB, UNESCO 2024, OECD 2025, EU AI Act Annex III), critiqued by Holmes (UCL IOE) for datafication and pedagogical reductionism."@en)
    AnnotationAssertion(dcterms:identifier ai:EducationAndAI "AI-1051"^^xsd:string)
    AnnotationAssertion(dcterms:subject ai:EducationAndAI "Applied AI, Educational Technology, Learning Sciences, AI Policy"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(ai:enables)
  AsymmetricObjectProperty(ai:implements)
  AsymmetricObjectProperty(ai:reduces)
  AsymmetricObjectProperty(ai:supports)
  TransitiveObjectProperty(ai:dependsOn)
  FunctionalDataProperty(ai:itsEffectSizeMedian)

## About Education and AI

- **Education and AI** (Artificial Intelligence in Education, AIED) is the field, practice, and infrastructure of applying machine-learning systems to teaching, learning, assessment, and the administration of education across schools, universities, vocational settings, and informal learning. As a concept it spans four decades of research originating in cognitive tutor systems at Carnegie Mellon (Anderson's ACT-R-based tutors, 1980s), expanding through adaptive learning platforms (ALEKS knowledge-space theory from Falmagne & Doignon 1985), web-scale language learning (Duolingo from 2011), and—after the November 2022 release of ChatGPT—an abrupt phase shift into generative-AI-mediated tutoring and assistance that is now embedded in tens of millions of student and teacher workflows globally.
- The fundamental tension structuring the domain is between two strong positive claims and two strong concerns. On the positive side: AI can deliver continuous, patient, individually-paced instruction approaching the effect size of one-to-one human tutoring (Bloom's 1984 "2-sigma problem"); and it can radically reduce teacher administrative load (lesson planning, marking, IEP drafting, parent communication, rubric design), liberating professional time for the relational, embodied work that AI cannot perform. On the concern side: AI is by construction a closed system mashing-up prior knowledge, raising the risk of creative narrowing and a deskilling of original thought when students offload cognition to it; and the datafication of learners produces equity, privacy, and assessment-integrity hazards that traditional schooling does not face.
- The pragmatic position emerging across the 2024-2026 literature (Ethan Mollick at Wharton; Sal Khan at Khan Academy; the OECD; the UK Department for Education; UNESCO) is that AI in education is not optional—students are already using it at scale—and the productive response is to be intentional about a hybrid model where AI provides the infinitely patient follow-up tutorial class, the formative assessment scaffolding, the differentiated worked example, and the administrative absorption, whilst human practitioners retain the social calibration, embodied modelling, ethical formation, and meta-cognitive accompaniment that AI cannot provide.
- The historical analogue invoked most frequently is the **introduction of calculators**: initial resistance gave way to broad acceptance once curricula adapted to assess problem formulation and mathematical reasoning rather than rote arithmetic. The analogy is contested (see "Calculator Analogy" debate below) but it captures the empirical reality that prohibition strategies have repeatedly failed when technology becomes pervasive, cheap, and useful. The deeper analogue may be the **printing press in the 16th century**: an information technology so disruptive to existing pedagogy and intellectual authority that the cultural and institutional response took two centuries to settle. AIED's settlement timeline is unknown but the consensus across reflective practitioners is that it will be measured in years not months.
- The page that follows surveys this terrain across seven product families (intelligent tutoring systems, generative-AI tutors, direct LLM use, grading and integrity tooling, language learning, accessibility, AI literacy curricula plus knowledge management research tools), nine recurring pedagogical patterns (Socratic dialogue, adaptive mastery sequencing, worked examples, formative feedback, spaced retrieval, administrative automation, EAL translation, SEND accessibility, cognitive mirror), the empirical evidence base (effect sizes from Kulik & Fletcher 2016, VanLehn 2011, Mollick/World Bank Nigeria 2024, Bastani Wharton 2024), the 2023-2026 policy oscillations (NYC DOE, LAUSD, Ofqual, IB, UNESCO 2024, OECD 2025, EU AI Act, UK DfE 2025), the major critical voices (Holmes UCL IOE, Watters, Williamson Edinburgh, Selwyn), the UK academic and industrial ecosystem with particular attention to MAT-mediated adoption and Northern English pilots, and the principal future trajectories through 2030. The aim is a single authoritative ontology node that the rest of the knowledge graph can reference rather than re-explaining the field at each cross-link.

### Empirical Effect Sizes: The Quantitative Case

The strongest single piece of evidence comes from the **Kulik & Fletcher (2016) meta-analysis** in *Review of Educational Research* 86(1), 42-78, which aggregated 50 controlled evaluations of intelligent tutoring systems published between 1990 and 2013 and reported a **median effect size of d = 0.66**—a "large" effect in Cohen's terms, indicating that the median ITS-instructed student outperformed roughly 75% of conventionally-instructed comparison students. ITS exceeded the effects of traditional classroom teaching, computer-assisted instruction (CAI) without intelligence, and large-group lecture; it was comparable to but slightly below one-to-one human tutoring.

**VanLehn (2011)** in *Educational Psychologist* 46(4) earlier reported d = 0.76 for ITS versus no-tutoring controls and d = 0.40 versus traditional CAI, with effect sizes approaching but not equalling the human-tutor benchmark. Critically, VanLehn argued that the "2-sigma" benchmark (Bloom 1984: d = 2.0 for one-to-one human tutoring versus conventional instruction) had rarely been replicated in subsequent studies; the realistic human-tutoring effect size is closer to d = 0.79, which ITS systems now approach.

For generative-AI tutoring specifically, the **Mollick / World Bank / EduGuard Nigeria study** (June 2024) reported that 6 weeks of after-school GPT-4 tutoring produced learning gains equivalent to **2 years of typical schooling**, an effect size outperforming approximately 80% of educational interventions surveyed in the World Bank meta-analytic database. The intervention disproportionately helped girls who were initially behind, suggesting AI tutoring functions as an equalising force in resource-constrained contexts. **Bastani and colleagues at Wharton (2024)** complicated this picture: in their controlled study, GPT-4 tutors improved performance on low-effort, immediate tasks but **reduced retention** on delayed assessments, indicating a "scaffolding dependency" risk where AI explanation substitutes for the productive struggle that drives durable learning.

The methodological reading of these conflicting findings is that AI tutoring effects depend heavily on three design variables: (i) whether the AI reveals answers or constrains itself to Socratic prompting (Khanmigo and Synthesis are explicitly designed to refuse answer-revelation, which the Bastani study suggests is critical to retention); (ii) the assessment timing (immediate-AI-assisted versus delayed-unassisted); and (iii) the baseline counterfactual (no-tutoring in low-income settings yields huge gains, well-resourced classrooms yield smaller marginal effects). The implication for practice is that AI tutoring design matters more than AI tutoring presence — a poorly designed AI tutor that gives away answers may produce worse durable learning than no tutoring at all, whereas a well-designed Socratic AI tutor approaches the effect of one-to-one human tutoring.

Beyond ITS and generative-AI tutoring proper, **Roediger & Karpicke's testing-effect** literature (2006 *Psychological Science*, 2008 *Journal of Educational Psychology*) underwrites the spaced retrieval pattern used by Tassomai, Century Tech, and Duolingo — gains here are well-established d ≈ 0.50-0.80 versus passive re-reading. **Sweller's cognitive load theory** and the worked-example effect (Sweller, Ayres, Kalyuga 2011) underwrites Mollick's worked-example pattern, with effect sizes d ≈ 0.40-0.70 versus problem-solving from scratch for novice learners. AI can generate unlimited worked examples tailored to student misconceptions, an operational scale that classroom teachers cannot match.

## Components and Major Families

AIED divides into seven principal product families, each with distinct deployment models, evidence bases, and policy positions.

### 1. Intelligent Tutoring Systems (ITS)

Pre-generative-AI adaptive learning systems built on cognitive models (ACT-R, knowledge spaces, item-response theory) that diagnose student misconceptions and select next problems by Bayesian knowledge tracing. The mature category, with 30+ years of deployment.

- **Carnegie Learning Mathia**: Direct descendant of Anderson's CMU Cognitive Tutor (1995); used by **600,000+ students annually across 1,500+ US school districts**; specialises in middle/high school Algebra; meta-analyses show 0.40-0.66 effect size versus traditional instruction.
- **ALEKS** (Assessment and LEarning in Knowledge Spaces; McGraw Hill): **25 million+ cumulative student users since 1996** across 30,000+ US schools and 6,000+ higher-ed institutions; mathematical foundation in Falmagne & Doignon's knowledge-space theory (1985).
- **Knewton**: Founded 2008 by Jose Ferreira, raised $157M, pivoted multiple times, **acquired by Wiley 2019 for ~$17M** after the original adaptive-tutoring proposition failed to scale; integrated into Wiley courseware as Knewton Alta with significant staff reductions; instructive case study in the difficulty of monetising pure adaptive engines.
- **Squirrel AI Learning** (China; founded 2014 as Yixue): **5 million+ K-12 students across 4,000+ learning centres in 700+ cities**; proprietary nano-knowledge-graph decomposing subjects into 10,000+ atomic concepts; reported 89% pass-rate gains in Wuhan municipal trial; demonstrates Chinese-market scale unavailable in fragmented Western markets.

  ### 2. Generative-AI Tutors (LLM-Based Conversational)

  Post-November-2022 category built on GPT-4-class language models with pedagogical fine-tuning, safety guardrails, and curriculum anchoring.

- **Khanmigo (Khan Academy)**: Built on GPT-4 via Microsoft Azure OpenAI partnership; **1 million+ students across 90+ school districts** by end 2024; **free to US/Canada teachers from August 2024**; $4/month for individual families; uses Socratic dialogue rather than answer-revelation; integrates with Khan Academy's 20-year corpus of practice problems and instructional videos; has guardrails for under-18s including notifying parents/teachers of safety issues and keeping conversations transparent.
- **MagicSchool AI**: **4 million+ educators across 6,000+ US schools** by end 2024; 80+ teacher-facing tools (lesson planner, IEP generator, rubric writer, parent email drafter, accommodations generator); $99/teacher/year individual licensing; one of the fastest-growing teacher SaaS products in EdTech history.
- **Synthesis Tutor** (Synthesis School; Josh Dahn, ex-SpaceX/Ad Astra): Launched 2024 maths tutor for K-8; $35/month family plan; **$35M Series A 2024 led by Andreessen Horowitz**; pedagogical lineage from Elon Musk's Ad Astra micro-school.
- **Mathpresso QANDA** (Korea): **90 million+ users across 50+ countries** by 2024; OCR photo-to-solution for maths problems; partnered KT for "QANDA-GPT" Korean-language fine-tune; 35% MAU growth 2024.
- **Brilliant.org**: **10 million+ active learners** (2024); interactive AI-explained STEM courses; ~$15/month; investors include Sundar Pichai.
- **Class Companion**: AI feedback on student writing aligned to teacher rubrics; covered by Forbes (Ravaglia 2023) as exemplar of teacher-augmenting AI design rather than student-replacing AI.

  ### 3. Generative-AI Assistants (Direct ChatGPT/Claude/Gemini Use)

  Unmediated student/teacher use of general-purpose LLMs. The most disruptive and the hardest to govern.

- **Pew Research (January 2024)**: 26% of US teens 13-17 have used ChatGPT for schoolwork (up from 13% in 2023).
- **Common Sense Media (2024)**: 70% of US teens have used generative AI tools.
- **Universities**: 7 in 10 institutions surveyed reported ChatGPT detected in submissions in 2023-2024 cycle; widespread informal student use of Claude for essay drafting, code generation, and study-question answering.
- Mollick's term **"secret cyborgs"** captures the empirical reality: AI use is pervasive, undetectable, and unacknowledged.

  ### 4. AI Grading and Integrity Tooling

- **Gradescope** (acquired by Turnitin 2018): **2,600+ universities; 100M+ submissions annually**; ML groups similar handwritten/typed answers reducing grading time by ~70%; especially deployed in STEM higher education.
- **Turnitin AI Writing Detection v2** (launched October 2024): Claims **4% document-level false positive rate** (up from claimed 1% in v1); **200M+ student submissions scanned**; faced significant criticism in 2024 with Vanderbilt, Texas A&M, and others **disabling the feature** over false-positive concerns particularly affecting non-native English writers; partial reinstatement following v2.
- **GPTZero**, **Originality.ai**, and **Copyleaks**: Competing AI-detection products with similarly contested accuracy claims.

  ### 5. Language Learning

- **Duolingo Max** (launched March 2023): GPT-4 features "Roleplay" (conversational practice) and "Explain My Answer" (formative feedback); $30/month tier; **113.1M MAU Q4 2024 (+51% YoY), 40.5M DAU, 9.5M paying subscribers**; available in 8 languages by end 2024.
- **Speak** (Speakeasy Labs): Series C **$78M October 2024 at $1B valuation** led by Accel; OpenAI Startup Fund investor since 2022; Korea/Japan-dominant; voice-AI conversational practice.
- **Babbel AI**: Adaptive grammar review and conversational practice features layered on Babbel's 2007-founded curriculum.

  ### 6. Accessibility

- **Microsoft Immersive Reader**: Embedded in Office 365 Education; phoneme highlighting, syllable splitting, picture-dictionary, line-focus, translation; deployed at scale for dyslexia, ESL, and reading-difficulty support.
- **Microsoft Live Captions**: Real-time speech-to-text for deaf and hard-of-hearing students in lectures.
- **Real-time AI translation** (Google Translate, Microsoft Translator) enabling EAL (English as Additional Language) students to follow mainstream instruction.

  ### 7. AI Literacy and Curriculum Tooling

- **UNESCO AI Education Competency Frameworks** for Students and Teachers (September 2024); four-pillar model (human-centred mindset, AI ethics, AI techniques, AI system design) translated into curriculum guidance for 200+ member states.
- **OECD/PISA AI Literacy Framework** (May 2025) for the PISA 2029 assessment cycle; 38 OECD countries; constructs assessed include understanding AI fundamentals, AI applications, data and AI, AI ethics, and AI as agent in the world.
- **BBC Bitesize AI** (UK) personalised study planner trial launched September 2024 on Microsoft Azure OpenAI Service; targets KS3-KS4 (ages 11-16) revision; 14M monthly users on parent platform during school term.
- **Code.org AI Curriculum**: AI 101 modules for K-12 reaching 90M+ students cumulatively; partnership with Amazon, Microsoft, and Google.
- **MIT RAISE** (Responsible AI for Social Empowerment and Education): K-12 AI literacy curricula; **DAILy** curriculum (Developing AI Literacy) for middle school; partnerships with Boston Public Schools and STEAM teachers worldwide.
- **Carnegie Mellon CS Academy AI**: AI module within Carnegie's free K-12 CS curriculum reaching 100,000+ students.

  ### 8. Knowledge Management and Research Tools

- **Perplexity.ai**: Cited as canonical research tool in this page's seminar material; **search-grounded LLM with inline citations** addressing hallucination by anchoring responses in verifiable sources; widely adopted in HE for student research; ~10M MAU by end 2024.
- **Elicit (Ought)**: Research assistant AI extracting structured data from academic literature; used in 1,200+ universities for systematic literature review acceleration.
- **NotebookLM (Google)**: Source-anchored AI for personal document corpora; launched 2024 with audio-overview podcast feature; rapid adoption in postgraduate research.
- **Consensus.app**: AI-powered consensus extraction from peer-reviewed literature.

## Use Cases: Pedagogical Patterns

AIED applications cluster around six recurring pedagogical patterns, each grounded in specific learning-science evidence.

### Pattern 1: Socratic Tutorial Dialogue

AI tutor poses questions, offers hints, and refuses to give direct answers, mirroring the questioning method evidenced by Chi et al. (2001) on tutorial dialogue and recently formalised in [Khanmigo's pedagogical design](https://www.khanmigo.ai/). Effective for conceptual maths/science where misconception diagnosis matters more than fact retrieval. Khanmigo and Synthesis Tutor both implement this explicitly.

### Pattern 2: Adaptive Mastery Sequencing

System tracks knowledge state (Bayesian knowledge tracing or knowledge-space theory) and routes next problem to optimise zone-of-proximal-development. ALEKS, Mathia, Squirrel AI, and Century Tech implement this. Effect-size evidence is strongest here (Kulik & Fletcher 2016 d=0.66).

### Pattern 3: Worked Example Generation

AI produces tailored worked examples illustrating a concept in a domain familiar to the student. Mollick's *Instructors as Innovators* (SSRN 4802463) catalogues prompt patterns for this. Grounded in Sweller's cognitive load theory and the worked-example effect.

### Pattern 4: Formative Feedback on Writing

AI provides rubric-aligned feedback on student writing without revealing the final answer. Class Companion, Khanmigo's writing tutor, and MagicSchool's feedback generator implement this. The evidence is mixed: feedback quality is high but ownership of the work is reduced (Lehmann et al. 2024).

### Pattern 5: Spaced Retrieval Practice

AI generates quizzes spaced across time to exploit the testing effect (Roediger & Karpicke 2006 *Ten Benefits of Testing*). Tassomai and Century Tech embed this in their UK mastery-learning products; Duolingo's whole product is spaced retrieval.

### Pattern 6: Teacher Administrative Automation

AI drafts lesson plans, IEPs, rubrics, parent emails, behaviour reports, accommodations lists, and differentiated worksheets. MagicSchool and Oak National Academy's AI assistant (UK) lead in this category. Time-savings of 5-10 hours/week per teacher are widely reported but not yet rigorously evidenced in RCTs. Education Endowment Foundation (EEF) UK is funding an RCT of MagicSchool-class tools in primary settings with 2026 readout expected.

### Pattern 7: Multilingual Real-Time Translation and EAL Support

AI enables non-native-language students to follow mainstream instruction via real-time captioning and translation (Microsoft Translator Live Presentations, Google Translate camera mode). EAL students in UK schools constitute approximately 21% of primary and 17% of secondary cohorts (DfE January 2024 census), making this pattern particularly significant in urban multi-ethnic settings (London, Birmingham, Manchester, Bradford, Leicester).

### Pattern 8: Accessibility Provisioning for SEND Learners

AI scaffolds learning for students with Special Educational Needs and Disabilities (SEND): Immersive Reader for dyslexia (phoneme highlighting, line-focus, picture-dictionary), Live Captions for deaf students, AI-text-to-speech for visually-impaired, AI-symbol-supported communication for non-verbal learners. UK SEND population is ~1.7M children (17% of school population, 2024 DfE data), representing the most legally-protected use-case under the Equality Act 2010 and SEND Code of Practice.

### Pattern 9: AI as Cognitive Mirror (Reflection Prompting)

Emerging pattern where AI prompts metacognitive reflection ("explain to me why you chose that answer", "what would you do differently next time") rather than supplying content. Aligns with self-regulated learning theory (Zimmerman, Pintrich). Implemented in some Khanmigo features and in research prototypes at UCL Knowledge Lab.

## Academic Context: Theoretical Foundations and Critical Scholarship

The intellectual lineage of AIED runs from cognitive psychology (Anderson's ACT-R, Sweller's cognitive load theory, Vygotsky's zone of proximal development) through educational data mining (Baker, Koedinger) to contemporary critical AI studies.

### Pro-AIED Lineage

- **John Anderson** (CMU): ACT-R cognitive architecture (1976-present) underpinning Carnegie Learning's tutoring engines.
- **Kenneth Koedinger** (CMU): Carnegie Mellon Cognitive Tutor evaluations; PSLC DataShop; LearnLab.
- **Sal Khan** (Khan Academy): *Brave New Words* (2024) makes the case for AI tutoring as realisation of Bloom's 2-sigma vision.
- **Ethan Mollick** (Wharton): *Co-Intelligence* (2024); *One Useful Thing* Substack; *Instructors as Innovators* (SSRN 4802463); *Using AI to Implement Effective Teaching Strategies* (SSRN 4391243).

  ### Critical AIED Lineage

- **Wayne Holmes** (UCL Institute of Education): *Artificial Intelligence in Education: Promise and Implications for Teaching and Learning* (2nd ed 2023, co-authored with Maya Bialik and Charles Fadel); **Council of Europe AI&Ed framework lead**; argues that mainstream AIED commits **pedagogical reductionism** by reducing teaching to observable, datafied behaviours optimisable by algorithms, marginalising constructivist meaning-making, social learning, embodied cognition, and ethical formation. **Holmes & Tuomi (2022)** *State of the Art Review of Generative AI in Education* (European Commission) catalogues risks of misinformation, equity gap, surveillance, and labour displacement.
- **Audrey Watters**: *Teaching Machines* (2021) history showing that "personalised learning" rhetoric has accompanied every wave of educational technology since Pressey/Skinner, with consistent failures to deliver claimed transformation.
- **Ben Williamson** (Edinburgh): Critical analysis of EdTech datafication, learning analytics surveillance, and the political economy of ed-tech.
- **Neil Selwyn** (Monash, ex-IOE): *Should Robots Replace Teachers?* (2019); systematic scepticism of AIED claims.

  ### Generative AI Education Studies (2023-2024 wave)

- **Kasneci et al. (2023)** "ChatGPT for good? On opportunities and challenges of large language models for education" *Learning and Individual Differences* — early consolidation of opportunities/risks taxonomy; 2,500+ citations in 18 months making it the most-cited paper of the generative-AI-education wave.
- **Bastani et al. (Wharton, 2024)**: Controlled study on Turkish high school maths students using ChatGPT for homework; performance improved on AI-assisted practice but **dropped 17% on the unassisted exam** versus controls — empirical demonstration of the "scaffolding dependency" risk.
- **Lehmann et al. (2024)**: GenAI for student writing improves output quality but reduces ownership and learning; aligned with desirable difficulties literature (Bjork).
- **Mollick & Mollick (SSRN 2024)**: Prompt patterns for instructors and the "AI as tutor/mentor/coach/simulator" taxonomy.
- **Tlili et al. (2023)** "What if the devil is my guardian angel: ChatGPT as a case study of using chatbots in education" *Smart Learning Environments* — early systematic SLR (Systematic Literature Review).
- **Cotton et al. (2023)** *Innovations in Education and Teaching International* on chatting and cheating with ChatGPT — assessment-integrity foundational paper.
- **Sharma et al. (2024)** on equity gaps in AI access: Pew Research and Common Sense Media show disparate AI tool access between higher-SES and lower-SES students despite high overall uptake.

  ### The "Calculator Analogy" Debate

  The most-cited rhetorical move in pro-AIED argumentation is the "calculator analogy": just as calculators were initially banned in classrooms then accepted as a tool changing what was assessed (de-emphasising arithmetic, emphasising problem formulation), AI should be integrated rather than banned. The analogy is associated with Khan, Mollick, and many ed-tech industry voices. **Critics including Holmes and Watters** argue the analogy is flawed: calculators automate a narrow, well-defined computational operation, whereas LLMs automate the entire cognitive process of producing text — the very process schooling exists to develop. A more sober analogy might be: "what if calculators could write the essay, do the experiment, and conduct the lab analysis, not just multiply two numbers". The debate remains unresolved and structures much of the policy disagreement.

## Current Landscape (2026): Policy Oscillations and Market Maturation

The 2024-2026 period has seen rapid and contradictory policy moves at every level of educational governance.

### School-Level Bans, Rescissions, and Failures

- **New York City Department of Education (largest US district, 1.1M students)**: Banned ChatGPT on school networks January 2023. Chancellor **David Banks rescinded the ban on 18 May 2023** in a *Chalkbeat* op-ed, framing the ban as a missed opportunity and launching the NYC Public Schools AI Policy Lab. The reversal became the canonical case for the "engagement over prohibition" stance.
- **Los Angeles Unified School District (2nd largest US district)**: Launched **"Ed"**, an AI chatbot, in March 2024 in partnership with vendor AllHere Education on a **$6M contract**. AllHere collapsed and laid off most staff in June 2024 amid scrutiny over data handling; the Ed project was **effectively cancelled by July 2024**. The case became a cautionary tale about vendor due diligence and procurement governance.
- **UK schools**: No system-wide ban; DfE issued generative AI policy positions in March 2023, October 2023, and **March 2025** updates, permitting use in lesson planning and marking with data-protection conditions.

  ### Examination-Body Positions

- **UK Ofqual** statement August 2023, updated 2024: AI use in unsupervised work **must be acknowledged**; unacknowledged AI-generated content in submissions assessable as malpractice; exam boards required to update guidance; AS/A-level coursework reform under consideration partly in response to AI.
- **International Baccalaureate (IB)** statement February 2023: Students may quote ChatGPT but must cite it; AI described as an "extraordinary opportunity"; not banned. Updated June 2024 with mandatory AI-use declaration on the Extended Essay.
- **GCSE/A-level** UK exam boards (AQA, OCR, Pearson, WJEC): aligned with Ofqual; physical exam venues remain AI-free by infrastructure.

  ### International Standard-Setting

- **UNESCO**: 2021 *Recommendation on the Ethics of AI* (200+ member states) extended September 2024 by the **AI Competency Frameworks for Students and Teachers** built on four pillars: human-centred mindset, ethics of AI, AI techniques and applications, AI system design.
- **OECD**: **AI Literacy Framework** published May 2025 for the **PISA 2029** cohort, covering AI fundamentals, data, ethics, and agency; 38 OECD countries participating; partnership with European Commission DG-EAC.
- **EU AI Act**: Annex III lists education-AI as **high-risk** where systems determine access to education, evaluate learning outcomes, or monitor/detect prohibited behaviour in exams; provider obligations including risk management, data governance, transparency, and human oversight apply from **2 August 2026**.

  ### Market Maturation

- **Duolingo**: 113.1M MAU Q4 2024 (+51% YoY); $748M revenue 2024; Max subscription drives ARPU growth.
- **Khan Academy**: Khanmigo free for US/Canada teachers August 2024; partnership scale with Microsoft via Azure OpenAI.
- **MagicSchool**: 4M+ educators in 18 months from launch—one of the fastest-growing teacher SaaS products in history.
- **Synthesis**: $35M Series A 2024 (a16z).
- **Knewton (cautionary)**: Failed adaptive-learning pioneer acquired by Wiley 2019 for $17M after $157M raised; instructive boundary case showing that "adaptive engine alone" without content moat doesn't sustain scale.
- **Pearson AI Study Tools**: Pearson integrated GPT-4 into MyLab and Mastering platforms 2024; **rolled out to 3M+ HE students** by end 2024.
- **McGraw Hill AI Reader and ALEKS-AI**: Generative-AI overlay on legacy adaptive learning; rollout 2024-2025.
- **Cengage**: Generative-AI tutoring features in *Cengage Infuse* 2024 launch.
- **Quizlet Q-Chat**: GPT-4 study companion launched 2023 for the platform's 60M+ MAU.

  ### Vendor Landscape Consolidation Signal

  The 2024-2025 period showed clear winners (Khan Academy, Duolingo, MagicSchool, Synthesis, Squirrel AI, Tassomai, Century Tech) and losers (AllHere, Knewton remnants). Capital deployment concentrated: MagicSchool $15M Series A (2024 GSV Ventures), Synthesis $35M Series A (a16z), Speak $78M Series C (Accel), with valuations of $300M-$1B. Public sector wariness following the LAUSD-AllHere collapse means procurement officers now demand mature operational history and named clinical/educational evidence rather than slide-deck promises.

  ### Open-Source and Self-Hostable Stack

  Counter to the SaaS concentration, an open-source AIED stack is emerging:

- **Anything LLM, LibreChat, OpenWebUI**: Self-hostable LLM front-ends behind institutional API keys, addressing data-sovereignty concerns.
- **H5P + AI plugins**: Open-source interactive content with AI question generation.
- **Moodle AI Subsystem**: Moodle 4.5 (October 2024) introduced AI Subsystem with pluggable providers (OpenAI, Azure, local Ollama); enables LMS-native AI tutoring across 200M+ Moodle users worldwide.
- **edX/Open edX AI**: 2X Learning (post-edX) integrating LLMs into open courseware.

  This stack matters particularly to European institutions facing EU AI Act and GDPR constraints on cross-border data transfer to US-hosted services.

## UK Context: Academic Leadership, Industrial Ecosystem, and Northern English Pilots

The UK has disproportionate global influence on AIED through its research universities and a mature, if comparatively small, ed-tech industry.

### Academic Leadership

- **UCL Institute of Education (IOE), UCL Knowledge Lab**: World's largest AIED research group with ~50 researchers including **Rosemary Luckin** (founder, AIED for two decades), **Wayne Holmes** (critical AIED, Council of Europe lead), **Manolis Mavrikis** (intelligent learning environments), and **Mutlu Cukurova** (learning analytics, multimodal). Holds **£6.5M EPSRC AI Hub for Schools (2024)**; partnership with **Oak National Academy** on the UK government's AI assistant beta; runs **EDUCATE Ventures Research** ed-tech accelerator (Luckin, founder).
- **University of Cambridge Faculty of Education**: AI research within Educational and Social Theory cluster; **Steve Watson** on critique of automated essay scoring; Cambridge University Press AI education book series.
- **University of Oxford / Oxford Internet Institute**: **Vili Lehdonvirta** on platform labour (including teacher labour displacement); **Felix Stein** on AI governance in schools; MSc Social Data Science includes AI ethics for education.
- **Imperial College London**: Centre for Higher Education Research and Scholarship (CHERS); EdTech research within Department of Computing; Centre for Languages, Culture and Communication AI-assisted language learning trials.
- **University of Edinburgh**: **Ben Williamson** on EdTech datafication critique; School of Informatics AI/Education research.
- **Open University Institute of Educational Technology**: long-standing distance-learning analytics expertise.

  ### Funding and Policy Bodies

- **ESRC** (Economic and Social Research Council): Funded the Knowledge Lab; supports AIED policy research.
- **UKRI EPSRC**: £6.5M AI Hub for Schools (UCL-led, 2024); ProtoAI ed-tech research.
- **Department for Education**: **March 2025 generative AI guidance** update; **£2M AI Tools for Teachers competition** won by Oak National Academy AI assistant beta; UK AI Safety Institute partnership for safe school-AI evaluation.
- **Ofqual**: Regulator of qualifications; AI guidance covered above.
- **JISC**: Higher-education sector body with AI in HE strategy and "exploring AI" guidance.

  ### UK Industry

- **Century Tech**: Founded 2013 by **Priya Lakhani OBE**; AI-personalised learning across maths/English/science KS2-A-level; **1,000+ UK schools**; international deployments in Belgium, UAE, and Lebanon (refugee education with Vodafone Foundation).
- **Tassomai**: Founded 2015 by Murray Morrison; AI-driven mastery learning for KS3-GCSE/A-level; **350,000+ students across 700+ UK schools**; BBC Bitesize partnership.
- **Oak National Academy**: Public-body curriculum provider; won DfE's AI Tools for Teachers competition 2024; **AI lesson-planning assistant beta** rolled out 2024-2025.
- **BBC Bitesize**: 14M monthly users in school term; **AI-personalised study planner trial September 2024** with Microsoft Azure OpenAI Service; Live Lessons with AI tutors.
- **Sparx Maths, Eedi, Atom Learning**: UK adaptive-learning startups in primary/secondary maths.
- **Mindstone**: Adult-learning AI platform.

  ### Northern English Schools and Multi-Academy Trusts

- **United Learning** (90+ schools): One of England's largest MATs; deploying AI marking and lesson-planning tools across secondary academies.
- **Star Academies** (Blackburn HQ, 30+ schools): Using **Century Tech** across maths/English KS3-KS4.
- **Outwood Grange Academies Trust** (Wakefield, 30+ schools across Yorkshire and Humber): AI lesson-planning pilot 2024.
- **Greater Manchester Combined Authority**: **AI in Education pilot 2024-2025 across 20+ secondary schools**; partnership with University of Manchester.
- **Innovate UK MediaCityUK** (Salford): Teacher AI training programmes 2024-2026 with BBC R&D, dock10, and the University of Salford—the funded programme referenced in this page's historical content and the work programme of which this page itself is a deliverable.
- **Sheffield Hallam Institute of Education**: Initial Teacher Training research on AI literacy for trainee teachers.
- **Newcastle University School of Education**: Digital education research; AI in Higher Education studies.
- **University of Leeds School of Education**: AI and assessment integrity research.

  ### UK Industrial Application

  The UK presents the strongest national case for the **MAT-mediated AI adoption pattern**—not classroom-by-classroom diffusion as in the US, but trust-level procurement and rollout via 1,200+ Multi-Academy Trusts covering 80%+ of secondary schools, enabling coherent governance, data protection, and teacher training at scale. This MAT-mediated model has three structural consequences: (i) procurement decisions made at trust executive level mean a single contract can deploy AI to 30-90 schools at once (the United Learning, Star Academies, Outwood Grange examples above); (ii) safeguarding, data protection, and acceptable-use policies can be developed once at trust level and applied uniformly, addressing the governance gap that plagued the LAUSD-AllHere implementation; (iii) teacher CPD (Continuing Professional Development) on AI can be coordinated at scale via trust-wide PD days rather than left to individual professional development.

  ### UK Regulatory Stance

  The UK occupies a deliberate position to the right of the EU on AI regulation:

- **No UK AI Act** (in contrast to EU AI Act); the UK White Paper "A pro-innovation approach to AI regulation" (March 2023) opted for sectoral regulator-led oversight rather than a horizontal statute. Education-AI thus falls under the existing Ofqual, Ofsted, DfE, and DPA/UK-GDPR remits.
- **DfE's March 2025 guidance** explicitly permits generative AI for teacher use in lesson planning and marking, conditional on (i) named DPIA (Data Protection Impact Assessment), (ii) no input of personal pupil data into public LLMs, (iii) human oversight of any AI-generated output going to pupils.
- **Ofsted** stance (2024-2025): does not penalise AI use; inspects governance of AI use within schools (acceptable-use policy, staff training, monitoring).
- **UK AI Safety Institute (AISI)** partnership with DfE on safe school-AI evaluation; Oak National Academy AI assistant beta passed AISI-coordinated safety review prior to wider rollout.
- **ICO (Information Commissioner's Office)**: child-data-protection guidance for ed-tech and AI; cross-references the Age-Appropriate Design Code.

  ### The MediaCityUK Salford Programme

  This page itself emerges from an **Innovate UK-funded programme at MediaCityUK Salford** developing pragmatic AI tools for teachers, delivered via short seminar series (~45-minute sessions on a weekly cadence) targeting teachers at all levels. The work programme uses the present knowledge graph as living material, with sessions covering: defining the problems of AI in educative settings (after Mollick's "Shape of the Shadow of the Thing"), Socratic uses and moral mazes, pragmatic uses and the "secret cyborg" problem, overview of specific tools, prompting techniques, diagrams-as-code workshops, and feedback/questions. The programme is funded to deliver tooling and teacher training across Greater Manchester and the wider North West; outputs disseminated through partner institutions and via the public-facing narrativegoldmine.com knowledge graph.

  ### Scotland, Wales, Northern Ireland

  Devolved education jurisdictions present three distinct positions:

- **Scotland (Education Scotland, SQA)**: SQA published AI in Assessment guidance May 2024; permissive of AI use with declaration; National 5/Higher coursework reform under SQA Qualifications Review considering AI explicitly.
- **Wales (Welsh Government, Qualifications Wales)**: Joint statement with Ofqual/SQA on AI; Welsh curriculum (Curriculum for Wales 2022 onwards) incorporates digital competence framework that 2025 update extends to AI literacy.
- **Northern Ireland (CCEA)**: Aligned with Ofqual on AI use in assessment; smaller-scale pilots.

## Future Directions (2026-2030)

Five trajectories will shape AIED through 2030.

### 1. EU AI Act Compliance Wave (2026-2028)

From 2 August 2026, education-AI providers in the EU and exporting to it (most major US/UK products) must satisfy Annex III high-risk-AI obligations: documented risk management systems, data governance audits, transparency and instructions for use, human oversight architecture, accuracy/robustness/cybersecurity testing, and post-market monitoring. Expect significant consolidation as smaller AIED vendors fail compliance; large vendors (Khan Academy, Duolingo, Pearson, McGraw Hill, MagicSchool) will absorb market share.

### 2. AI Literacy Mandates in National Curricula (2026-2029)

Following UNESCO 2024 and OECD/PISA 2025 frameworks, expect national-curriculum integration in OECD countries: AI literacy modules in secondary curricula, AI ethics in citizenship education, AI-fundamentals at primary level. **UK DfE** announced exploratory work in 2025; **Finland**, **Singapore**, and **South Korea** moving fastest.

### 3. Assessment Redesign

As Mollick has argued, traditional take-home essays and unsupervised written assignments become unreliable as assessment instruments under widespread AI access. Expect (i) growth in oral examinations and viva voce; (ii) supervised written exams reasserting primacy; (iii) process-based assessment (drafting under supervision with revision history); (iv) authentic-task assessment (presentations, projects with defence); (v) experimental "AI-allowed" exam categories with explicit acknowledgement requirements.

### 4. Hybrid Pedagogical Models

The dominant pedagogical settlement will be **AI-as-tutorial-assistant**, not AI-as-teacher-replacement. AI absorbs administrative load (40-60% of teacher non-contact time) and provides infinitely-patient one-to-one tutorial follow-up; human teachers retain whole-class instruction, social calibration, embodied modelling, ethical formation, and meta-cognitive accompaniment. This matches the "calculator analogy" repeatedly invoked by Mollick and Khan.

### 5. Equity, Privacy, and Datafication Counter-Currents

Holmes's critique will gain regulatory traction: expect rising scrutiny of student-data extraction by AIED vendors; "right to non-datafication" advocacy; UNESCO and Council of Europe frameworks emphasising human-centred AI; potential restrictions on AI use in summative high-stakes assessment in equity-conscious jurisdictions.

### 6. UK-Specific: Northern Powerhouse AI Education

Devolution of education innovation funding to Combined Authorities (Greater Manchester, West Yorkshire, Liverpool City Region, North East) is enabling regional MAT-level AI adoption programmes. Expect 2026-2028 evaluation evidence from the Greater Manchester pilot, BBC R&D MediaCityUK training cohorts, and Star Academies / Outwood Grange Century Tech deployments to materially inform national DfE policy.

### 7. Foundation-Model-Specific Pedagogies

As foundation models become commodified, expect the emergence of pedagogies specifically designed to exploit and complement particular model capabilities: prompt-engineering as a curriculum strand (already piloted at Stanford, Wharton, and selected UK independent schools), AI red-teaming as a critical thinking exercise (training students to find weaknesses in AI outputs), Socratic-protocols for using AI without it doing the thinking, and AI-augmented design-thinking for project work.

### 8. Long-Tail and Endangered-Language Pedagogy

LLMs trained on rich English/Mandarin/Spanish/Hindi corpora perform poorly on low-resource languages, which is paradoxically the strongest equity opportunity: dedicated efforts (Masakhane for African languages, Bloom Library, Common Voice) building open language data for minority and endangered languages could enable AI tutoring in Welsh, Scots Gaelic, Te Reo Māori, and indigenous Australian languages — formerly economically infeasible due to small markets.

### Risks and Counter-Scenarios

Five scenarios could derail the optimistic trajectory:

- **Major safeguarding incident**: A child-protection incident (AI advising self-harm, sexual grooming via AI chat) triggering regulatory crackdown — recall LAUSD-AllHere was effectively cancelled in part over safeguarding/data concerns.
- **Mass cheating scandal**: A high-stakes-exam mass-AI-cheating revelation (analogous to the 2002 SAT scoring scandal) triggering reactive ban policies.
- **Foundation-model commercial pivots**: OpenAI/Anthropic enterprise pricing changes pricing-out public-sector education customers (Khan Academy partnership specifically relies on subsidised Microsoft Azure OpenAI access).
- **Datafication revolt**: Privacy-conscious parents and unions winning regulatory restrictions on student-data flows to AI vendors.
- **Evidence reversal**: Multi-year longitudinal studies showing AI tutoring damages retention and critical thinking — Bastani Wharton 2024 is suggestive but not conclusive; if replicated at scale this could fundamentally reset the consensus.

## Deployment Statistics and Market Sizing (2024-2026)

Cross-cutting deployment data complementing the family-by-family descriptions above.

### Global Student Reach

Conservative aggregate of platform-disclosed and reasonably extrapolated user counts (Q4 2024 / Q1 2025):

- **Khanmigo**: 1M+ students (US/Canada) — Khan Academy public communications.
- **Carnegie Learning Mathia**: 600K+ students/year (US).
- **ALEKS**: 25M+ cumulative since 1996 (likely 3-5M annual active).
- **Squirrel AI**: 5M+ K-12 students (China).
- **Duolingo Max**: 9.5M paying subscribers, 113.1M MAU on parent platform.
- **Brilliant.org**: 10M active learners.
- **QANDA**: 90M registered users, ~30M MAU.
- **Tassomai**: 350K students (UK).
- **Century Tech**: ~500K students (UK, UAE, Belgium).
- **MagicSchool (teacher-facing)**: 4M+ educators reaching ~80M students by extension.
- **Direct generative-AI use** (ChatGPT/Claude/Gemini in schoolwork): hundreds of millions of students globally — 26% of US teens, 70%+ usage of any generative AI per Common Sense Media 2024.

  ### Market Size Estimates

- **HolonIQ AI in Education** market estimate: **$5.5B (2024) growing to $25B by 2030** (CAGR 28-35%).
- **GSV Ventures** "EdTech 2024" thesis: AI is the principal value-driver for the next decade of EdTech investment.
- **PitchBook** EdTech AI deal data: $2.5B+ venture funding into AI-EdTech 2023-2024.

  ### Equity Distribution

  Pew and Common Sense Media data show concerning disparities:

- Higher-income households (>$75K): 33% of teens use ChatGPT for schoolwork.
- Lower-income households (<$30K): 17% of teens use ChatGPT for schoolwork — a roughly 2x gap.
- Urban vs rural: gap less pronounced but exists.
- This pattern—a "second-level digital divide" not in device access but in productive use of AI tools—is the principal equity concern in 2025-2026 policy discussions.

## Research and Literature

**Foundational Meta-Analyses**:
1. Kulik, J.A., & Fletcher, J.D. (2016). Effectiveness of intelligent tutoring systems: A meta-analytic review. *Review of Educational Research*, 86(1), 42-78. DOI: 10.3102/0034654315581420 [50 ITS studies, median d=0.66]
2. VanLehn, K. (2011). The relative effectiveness of human tutoring, intelligent tutoring systems, and other tutoring systems. *Educational Psychologist*, 46(4), 197-221. DOI: 10.1080/00461520.2011.611369 [d=0.76 vs no-tutoring, d=0.40 vs CAI]
3. Bloom, B.S. (1984). The 2 sigma problem: The search for methods of group instruction as effective as one-to-one tutoring. *Educational Researcher*, 13(6), 4-16. DOI: 10.3102/0013189X013006004 [the foundational benchmark]
4. Chi, M.T.H., Siler, S.A., Jeong, H., Yamauchi, T., & Hausmann, R.G. (2001). Learning from human tutoring. *Cognitive Science*, 25(4), 471-533. [Tutorial dialogue dynamics]
5. Roediger, H.L., & Karpicke, J.D. (2006). Test-enhanced learning. *Psychological Science*, 17(3), 249-255. DOI: 10.1111/j.1467-9280.2006.01693.x [testing effect underpinning spaced retrieval]

**Critical AIED**:
6. Holmes, W., Bialik, M., & Fadel, C. (2023). *Artificial Intelligence in Education: Promise and Implications for Teaching and Learning* (2nd ed). Center for Curriculum Redesign. [Canonical critical text]
7. Holmes, W., & Tuomi, I. (2022). State of the art and practice in AI in education. *European Journal of Education*, 57(4), 542-570. DOI: 10.1111/ejed.12533
8. Selwyn, N. (2019). *Should Robots Replace Teachers? AI and the Future of Education*. Polity Press.
9. Williamson, B., & Eynon, R. (2020). Historical threads, missing links, and future directions in AI in education. *Learning, Media and Technology*, 45(3), 223-235. DOI: 10.1080/17439884.2020.1798995
10. Watters, A. (2021). *Teaching Machines: The History of Personalized Learning*. MIT Press.

**Generative AI Education Studies (2023-2024)**:
11. Kasneci, E., Sessler, K., Küchemann, S., et al. (2023). ChatGPT for good? On opportunities and challenges of large language models for education. *Learning and Individual Differences*, 103, 102274. DOI: 10.1016/j.lindif.2023.102274
12. Mollick, E.R., & Mollick, L. (2023). Instructors as innovators: A future-focused approach to new AI learning opportunities, with prompts. *SSRN Working Paper* 4802463.
13. Mollick, E.R., & Mollick, L. (2023). Using AI to implement effective teaching strategies in classrooms: Five strategies. *SSRN Working Paper* 4391243.
14. Bastani, H., Bastani, O., Sungu, A., Ge, H., Kabakcı, Ö., & Mariman, R. (2024). Generative AI can harm learning. *SSRN Working Paper* 4895486. [Wharton retention study]
15. Lehmann, M., Cornelius, P.B., & Sting, F.J. (2024). AI meets the classroom: When does ChatGPT harm learning? *arXiv:2409.09047*.

**Foundational ITS and Cognitive Science**:
16. Anderson, J.R., Corbett, A.T., Koedinger, K.R., & Pelletier, R. (1995). Cognitive tutors: Lessons learned. *Journal of the Learning Sciences*, 4(2), 167-207. DOI: 10.1207/s15327809jls0402_2
17. Koedinger, K.R., Anderson, J.R., Hadley, W.H., & Mark, M.A. (1997). Intelligent tutoring goes to school in the big city. *International Journal of Artificial Intelligence in Education*, 8, 30-43.
18. Falmagne, J.-C., & Doignon, J.-P. (1985). Spaces for the assessment of knowledge. *International Journal of Man-Machine Studies*, 23(2), 175-196. DOI: 10.1016/S0020-7373(85)80031-6 [ALEKS foundation]
19. Corbett, A.T., & Anderson, J.R. (1995). Knowledge tracing: Modeling the acquisition of procedural knowledge. *User Modeling and User-Adapted Interaction*, 4(4), 253-278. DOI: 10.1007/BF01099821

**Mollick / Public-Sphere Argumentation**:
20. Mollick, E.R. (2024). *Co-Intelligence: Living and Working with AI*. Portfolio/Penguin.
21. Mollick, E.R. (2024). Post-apocalyptic education. *One Useful Thing*. https://www.oneusefulthing.org/p/post-apocalyptic-education
22. Mollick, E.R. (2024). The shape of the shadow of the thing. *One Useful Thing*. https://www.oneusefulthing.org/p/the-shape-of-the-shadow-of-the-thing
23. Mollick, E.R. (2024). Secret cyborgs: The present disruption. *One Useful Thing*. https://www.oneusefulthing.org/p/secret-cyborgs-the-present-disruption
24. Khan, S. (2024). *Brave New Words: How AI Will Revolutionize Education (and Why That's a Good Thing)*. Viking.

**Policy and Standards (2024-2026)**:
25. UNESCO (2024). *AI Competency Framework for Students*. UNESCO Publishing. https://unesdoc.unesco.org/ark:/48223/pf0000390197
26. OECD (2025). *AI Literacy Framework for PISA 2029*. OECD Publishing.
27. UK Department for Education (2025). *Generative artificial intelligence (AI) in education* (policy paper, March 2025 update). https://www.gov.uk/government/publications/generative-artificial-intelligence-in-education
28. European Union (2024). *Regulation (EU) 2024/1689 on Artificial Intelligence* (AI Act), Annex III high-risk AI. https://eur-lex.europa.eu/eli/reg/2024/1689/oj
29. Ofqual (2024). *Ofqual's approach to regulating the use of artificial intelligence (AI) in the qualifications sector*. https://www.ofqual.gov.uk/news/ofquals-approach-to-regulating-the-use-of-artificial-intelligence-ai-in-the-qualifications-sector
30. International Baccalaureate Organisation (2023, 2024). *Statement on ChatGPT and AI in assessment and education*. https://www.ibo.org/news/news-about-the-ib/statement-from-the-ib-about-chatgpt-and-artificial-intelligence-in-assessment-and-education/

**Industry and Public-Sphere Sources**:
31. Khan Academy (2024). *Khanmigo: The future of AI-powered education*. https://www.khanmigo.ai/
32. Duolingo Inc. (2024). *Q4 2024 Shareholder Letter*. https://investors.duolingo.com/news-releases
33. Common Sense Media (2024). *The Dawn of the AI Era*. Research report. https://www.commonsensemedia.org/research/the-dawn-of-the-ai-era
34. Pew Research Center (2024, January 24). *About 1 in 5 US teens who've heard of ChatGPT have used it for schoolwork*. https://www.pewresearch.org/short-reads/2024/01/24/about-1-in-5-us-teens-whove-heard-of-chatgpt-have-used-it-for-schoolwork/
35. Chalkbeat NY (2023, May 18). *NYC schools rescind ChatGPT ban*. https://ny.chalkbeat.org/2023/5/18/23727942/chatgpt-nyc-schools-ai-ban-rescinded-david-banks
36. Los Angeles Times (2024, July 3). *LAUSD's once-celebrated AI chatbot system in jeopardy after vendor collapse*. https://www.latimes.com/california/story/2024-07-03/lausds-once-celebrated-ai-chatbot-system-in-jeopardy-after-vendor-collapse

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Phase 6 enrichment complete; production-ready
- **Verification**: Academic sources verified via DOI; deployment statistics cross-referenced against vendor press releases and *Chalkbeat*/*Brookings*/*Common Sense Media*/*Pew* reporting
- **Domain Validation**: Original frontmatter `domain:: artificial-intelligence` confirmed correct (concept sits in artificial-intelligence > applied-AI subdomain); no correction required despite worker-brief flagging possibility of infrastructure mis-classification
- **Regional Context**: UK academic institutions (UCL IOE Knowledge Lab, Cambridge, Oxford, Imperial, Edinburgh, Open University); UK industry (Century Tech, Tassomai, Oak National Academy, BBC Bitesize); Northern English MATs (United Learning, Star Academies, Outwood Grange) and Combined Authority pilots (Greater Manchester); MediaCityUK Salford Innovate UK programme detailed
- **Production-Ready**: Complete OWL formal semantics, comprehensive coverage of ITS / generative-AI tutors / direct LLM use / grading / language learning / accessibility / AI literacy; effect-size evidence base; 2023-2026 policy oscillations; critical scholarship balanced against pro-AIED case
- **Authority Score**: 0.87 (mature empirical evidence base via Kulik & Fletcher 2016; rich industrial deployment data; balanced critical and pro-AIED scholarship; UK regulatory context detailed; active 2024-2026 policy events documented)
- **Cross-References**: This page is the canonical AIED ontology node and is referenced by [[Generative AI]], [[Large Language Model]], [[Ethan Mollick]], [[AI Ethics]], [[Khanmigo]], [[Carnegie Learning Mathia]], [[ALEKS]], [[Squirrel AI]], [[Duolingo Max]], [[Khan Academy]], [[Synthesis Tutor]], [[MagicSchool]], [[Tassomai]], [[Century Tech]], [[BBC Bitesize]], [[Oak National Academy]], [[UNESCO AI Education Recommendation]], [[OECD AI Literacy Framework]], [[EU AI Act]], [[UCL Knowledge Lab]], [[Rosemary Luckin]], [[Wayne Holmes]], [[Manolis Mavrikis]], [[Mutlu Cukurova]], [[Sal Khan]], [[Audrey Watters]], [[Ben Williamson]], [[Neil Selwyn]], [[Greater Manchester AI Pilot]], [[MediaCityUK Salford]], and the broader [[Applied AI]] family. Pages on assessment integrity, AI literacy, generative AI in higher education, accessibility AI, and intelligent tutoring systems specifically should treat this node as the parent reference.
- **Limitations and Outstanding Questions**: (i) Deployment statistics for closed commercial platforms rely on vendor disclosures which are not independently audited; (ii) Effect-size meta-analyses predate the generative-AI wave so 2024-2026 RCTs are still building the equivalent evidence base; (iii) Long-term retention and creative-development effects of AI-assisted learning will not be measurable until cohort-longitudinal studies report in 2028+; (iv) Policy positions are evolving on a quarterly cadence and will date this page faster than other ontology nodes — annual refresh recommended.

### Provenance

- **domain-correction:** none (artificial-intelligence confirmed correct)

