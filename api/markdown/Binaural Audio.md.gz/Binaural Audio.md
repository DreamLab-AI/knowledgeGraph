Binaural audio is two-channel sound designed to reproduce the directional and spatial cues a listener would experience naturally, delivering an immersive three-dimensional image over headphones. It can be captured with a dummy head or in-ear microphones, or synthesised by convolving sources with head-related transfer functions. By preserving interaural time and level differences and pinna spectral cues, binaural audio conveys not just left-right panning but full surrounding placement including elevation.

### Overview

- Binaural audio aims to recreate the exact pressure signals that would reach a listener's two eardrums from a real sound scene, so that ordinary headphones produce a convincing externalised, three-dimensional image. Two production routes exist: direct capture with a dummy-head or in-ear microphones that physically embed the listener's acoustic cues, and synthesis that convolves dry sources with head-related transfer functions for the desired directions. Either way the recording preserves interaural time and level differences plus the spectral shaping of the pinna. With head tracking the scene can be rotated to remain world-stable, which is essential for virtual and augmented reality where audio must agree with the visual viewpoint.

### Key aspects

- Two-channel signal carrying full interaural and spectral localisation cues.
- Captured with dummy-head microphones or synthesised via HRTFs.
- Delivers externalised, headphone-based three-dimensional imaging.
- Combined with head tracking for world-locked immersive scenes.
- Distinct from loudspeaker surround such as ambisonics in its delivery model.

### Applications

- Immersive audio for virtual and augmented reality.
- Spatial podcasts, ASMR and narrative media.
- Gaming positional audio over headphones.
- Telepresence and remote collaboration with placed voices.

### Provenance

