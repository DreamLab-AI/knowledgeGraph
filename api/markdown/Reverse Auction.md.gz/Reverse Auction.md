A reverse auction is an auction in which suppliers bid prices downwards against each other in real time, and the buyer selects the winner.[^1][^2]

UNCITRAL defines an electronic reverse auction as an online real-time purchasing technique used by the procuring entity to select the successful submission, which involves suppliers or contractors presenting successively lowered bids during a scheduled period of time and the automatic evaluation of bids.[^1] Its glossary distinguishes an electronic reverse auction used as a separate method of procurement from one used as a phase preceding the award of the contract in another method or in a framework agreement.[^3]

The Model Law allows an electronic reverse auction as a stand-alone method where it is feasible to formulate a detailed description of the subject matter, a competitive market of qualified suppliers is anticipated so that effective competition is ensured, and the award criteria are quantifiable and can be expressed in monetary terms.[^1]

## In the European Union

Article 35 of Directive 2014/24/EU lets contracting authorities use electronic auctions in which new prices, revised downwards, and/or new values for certain elements of tenders are presented. The auction is a repetitive electronic process that follows an initial full evaluation of the tenders, enabling them to be ranked by automatic methods, and it cannot be used for contracts with intellectual performances, such as the design of works, that cannot be ranked automatically.[^2] It may precede the award in open or restricted procedures or competitive procedures with negotiation when the technical specifications can be established with precision.[^2]

## Scope and distinctions

Oracle's PeopleSoft Strategic Sourcing data sheet lists real-time auctions alongside RFx processes as functions of a sourcing system.[^4] See [[Request for Quotation]], [[Request for Proposal]] and [[Sourcing Event]].

## What the sources do not establish

The EU text is the legislation.gov.uk copy as at 2018 and does not use the word reverse; no source opened reports savings or supplier behaviour in auctions.[^2][^1]

[^1]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf
[^2]: European Parliament and Council, Directive 2014/24/EU on public procurement (legislation.gov.uk copy as at 1 January 2018), “Article 35 Electronic auctions”. https://www.legislation.gov.uk/eudr/2014/24/article/35/2018-01-01/data.htm
[^3]: United Nations Commission on International Trade Law (UNCITRAL), “Glossary of procurement-related terms used in the 2011 UNCITRAL Model Law on Public Procurement”. https://uncitral.un.org/sites/default/files/procurement/procurem/ml-procurement-2011/Glossary-e.pdf
[^4]: Oracle, PeopleSoft Strategic Sourcing data sheet (software vendor), “PeopleSoft Strategic Sourcing”. https://www.oracle.com/ae/a/ocom/docs/applications/peoplesoft/peoplesoft-strategic-sourcing.pdf

