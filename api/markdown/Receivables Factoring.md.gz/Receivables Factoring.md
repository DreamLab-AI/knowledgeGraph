Receivables factoring is a form of receivables purchase in which sellers of goods and services sell their receivables, represented by outstanding invoices, at a discount to a finance provider, commonly known as the factor.[^1]

A key differentiator in the Standard Definitions for Techniques of Supply Chain Finance is that the factor typically becomes responsible for managing the debtor portfolio and collecting the underlying receivables.[^1] Ownership of the receivable lies with the finance provider, the buyer settles the invoice with the finance provider rather than the seller, and factoring is normally disclosed to the buyer.[^1] It is provided with or without recourse depending on aspects such as credit insurance, jurisdiction and market practice.[^1]

## Treaty definition

The UNIDROIT Convention on International Factoring, of 1988 (Ottawa), defines a factoring contract as a contract between a supplier and a factor under which three conditions hold. The supplier may or will assign to the factor receivables arising from contracts of sale of goods with its customers, other than goods bought primarily for personal, family or household use. The factor is to perform at least two of four functions: finance for the supplier, maintenance of accounts relating to the receivables, collection of receivables, and protection against default in payment by debtors. Notice of the assignment is to be given to debtors.[^2] The 2016 standard cites the convention to say that factoring is traditionally associated with functions beyond pure financing.[^1]

## Scope and distinctions

Receivables discounting is described separately as a flexible form of receivables purchase in which sellers sell individual or multiple receivables at a discount.[^1] The standard lists invoice discounting among the synonyms of factoring, and also among the synonyms of receivables discounting, so the names overlap in practice.[^1] Buyer-led financing is covered at [[Reverse Factoring]], and the broader field at [[Supply Chain Finance]].

## What the sources do not establish

Sources give no market volumes, prices or default rates. The convention applies to international sales of goods between parties in different states, subject to further conditions, and the page does not claim that its definition governs domestic factoring.[^2] The standard is the 2016 first edition, and later updates were not opened.[^1]

[^1]: Global Supply Chain Finance Forum (ICC Banking Commission, BAFT, Euro Banking Association, Factors Chain International and ITFA), “Standard Definitions for Techniques of Supply Chain Finance”, 2016 (Internet Archive copy of the ICC PDF). https://web.archive.org/web/2023/https://cdn.iccwbo.org/content/uploads/sites/3/2017/01/ICC-Standard-Definitions-for-Techniques-of-Supply-Chain-Finance-Global-SCF-Forum-2016.pdf
[^2]: UNIDROIT, “UNIDROIT Convention on International Factoring (Ottawa, 28 May 1988)”. https://unidroit.org/english/conventions/1988factoring/convention-factoring1988.pdf

