ARCore is Google's software development kit for building augmented-reality applications on Android and, via web standards, the browser. It provides motion tracking, environmental understanding and light estimation by fusing camera frames with inertial sensors to anchor virtual content in the physical world. ARCore is the principal counterpart to Apple's ARKit in the mobile-AR ecosystem.

### Overview

- ARCore estimates the device's pose in real time by combining visual feature tracking with inertial measurement, a form of visual-inertial SLAM, and builds a sparse map of the surrounding scene. It detects planes and feature points onto which applications place anchors, persists those anchors for shared and cross-session experiences, and estimates ambient lighting so virtual objects render plausibly. Depth APIs add per-pixel range for occlusion and physics.

### Mechanisms

- Visual-inertial motion tracking and device pose estimation
- Plane and feature-point environmental understanding
- Anchors for persistent and shared content placement
- Light estimation for realistic rendering
- Depth API for occlusion and collision

### Applications

- Mobile AR product previews and try-on
- Indoor navigation and AR wayfinding
- Shared multi-user AR via cloud anchors
- Measurement and scene-capture utilities

### Provenance

