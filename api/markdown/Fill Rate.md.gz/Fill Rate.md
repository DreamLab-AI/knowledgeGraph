Fill rate is the long-range average fraction of demand that is delivered from inventory on the shelf.[^1] Georgia Tech course notes call it the type 2 service level, also written as the beta or P2 service level.[^1]

Columbia University notes on the newsvendor problem define the fill rate, for a single stocking decision, as the expected quantity sold divided by the expected demand, written E min(D, Q)/ED, where D is demand and Q the quantity stocked.[^2] They warn that the service level implied by the newsvendor solution should not be confused with this fraction of demand served.[^2]

## Fill rate and other service levels

The Georgia Tech notes define a different measure, the type 1 service level, as the probability of not being out of stock per replenishment cycle.[^1] It records whether a stockout occurs but not its size, whereas the fill rate considers both the probability of a stockout and the size of the backorder.[^1]

## In delivery measurement

In the consumer sector McKinsey describes a traditional case-fill rate that the industry has moved away from, adopting on-time in-full as a more rigorous delivery metric.[^3] See [[On-Time In-Full]] and [[Delivery Performance Measure]]. SCOR 12.0 lists a metric called % of Orders Delivered In Full, but the guide opened gives only its name, so this page does not equate it with the fill rate.[^4]

## What the sources do not establish

Inventory-theory definitions here come from two sets of university lecture notes, and the consumer-sector use from one consultancy article, so the sources describe at least two senses of the term. The alias Order Fill Rate is not defined in any source opened here. No source gives typical target levels.[^1][^2][^3]

[^1]: Georgia Institute of Technology (Marc Goetschalckx), “Chapter 5. Inventory Systems”, Logistics Systems Design. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf
[^2]: Columbia University (Guillermo Gallego), IEOR 4000 Production Management, “Stochastic Demand”, 2 December 2003. http://www.columbia.edu/~gmg2/4000/pdfold/lec10.pdf
[^3]: McKinsey & Company (Alan Davies, Shruti Lal, Fernando Perez and Sanjhali Potdar), “Defining ‘on-time, in-full’ in the consumer sector”, 13 June 2019 (Internet Archive copy). https://web.archive.org/web/2024/https://www.mckinsey.com/capabilities/operations/our-insights/defining-on-time-in-full-in-the-consumer-sector
[^4]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf

