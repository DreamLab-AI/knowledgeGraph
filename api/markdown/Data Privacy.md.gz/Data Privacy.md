Data Privacy is the governance and engineering discipline that ensures individuals retain meaningful control over their personal information through legal frameworks, technical safeguards, and organisational policies governing the appropriate collection, processing, storage, and sharing of personal data. It spans both the regulatory compliance dimension—expressed in instruments such as GDPR, CCPA, PIPEDA, and sector-specific regulations—and the engineering discipline of privacy-by-design that minimises data exposure through techniques such as anonymisation, pseudonymisation, differential privacy, federated learning, and consent management. As AI training practices, surveillance capitalism, and cross-border data flows intensify the stakes of personal information handling, data privacy functions as a core organisational risk management and trust-building domain. The field requires integration across legal, technical, and organisational layers to be effective, and is increasingly operationalised through dedicated Privacy-Enhancing Technologies (PETs).

### Overview

- Data privacy addresses the fundamental tension between the social and commercial value of personal information flows and the autonomy of individuals over their own data. The field emerged from 1970s computer-records legislation and crystallised into a global governance regime with the EU's [[GDPR]] (2018), which set extraterritorial precedent and severe penalties.
- Why it matters:
  - Erosion of [[Digital Trust]] has measurable commercial consequences — consumers abandon services perceived as privacy-invasive.
  - [[Data Breach]] incidents expose individuals to identity theft, financial fraud, and reputational harm.
  - AI and big-data analytics make it technically feasible to re-identify supposedly anonymous individuals at scale, raising the stakes for adequate de-identification.
  - Surveillance capitalism business models create structural incentives to collect maximal data, requiring legal and technical countermeasures.
- How it works:
  - Legal layer: statutes define lawful bases for processing, data subject rights, and enforcement mechanisms.
  - Technical layer: [[Privacy by Design]], [[Data Minimisation]], [[Data Anonymization Pipeline]], [[Differential Privacy]], and [[Federated Learning]] reduce data exposure in engineered systems.
  - Organisational layer: [[Data Governance]] frameworks, Data Protection Officers (DPOs), privacy impact assessments (PIAs/DPIAs), and vendor management programmes embed privacy accountability.

### Key Components

- **[[Privacy by Design]]** — Ann Cavoukian's seven foundational principles (proactive, not reactive; privacy as default; embedded into design; full functionality; end-to-end security; visibility and transparency; respect for user privacy) now mandated under GDPR Article 25.
- **[[Consent Management]]** — Technical platforms that capture, record, and honour individual consent choices for specific data uses; must satisfy GDPR's requirements for freely given, specific, informed, and unambiguous consent.
- **[[Data Minimisation]]** — The principle that only data strictly necessary for a specified purpose should be collected, reducing exposure in the event of breach or misuse.
- **[[Data Anonymization Pipeline]]** — Processing workflows applying k-anonymity, l-diversity, t-closeness, or suppression techniques to remove or generalise personal identifiers in datasets intended for analytics or sharing.
- **[[Differential Privacy]]** — A mathematically rigorous framework that adds calibrated statistical noise to query results or model outputs, providing provable privacy guarantees even against adversaries with auxiliary information. Deployed by Apple, Google, and the US Census Bureau.
- **[[Federated Learning]]** — A distributed machine learning paradigm in which model weights rather than raw personal data are aggregated across client devices, enabling AI training without centralising personal records. A key bridge between privacy and [[Machine Learning]].
- **[[Homomorphic Encryption]]** — Cryptographic technique enabling computation on encrypted data without decryption, allowing third parties to process sensitive information without ever seeing it in plaintext.
- **[[Pseudonymisation]]** — Replacing direct identifiers with artificial references; data remains personal under GDPR but is lower-risk; reversible with access to the key.
- **[[Data Subject Rights]]** — Legally mandated rights including access, rectification, erasure (right to be forgotten), restriction of processing, portability, and objection, enabled by [[Consent Management]] and [[Personal Data Store]] architectures.
- **[[Access Control]]** — Role-based and attribute-based policies restricting who within an organisation may view or process personal data; a prerequisite for demonstrating compliance.
- **[[Audit Logging]]** — Tamper-evident records of who accessed what personal data and when; essential for breach investigation and regulatory accountability.
- **Privacy Impact Assessment (PIA / DPIA)** — Structured processes for identifying and mitigating privacy risks before deploying new systems or data processing activities; mandatory under GDPR for high-risk processing.

### Applications and Use Cases

- **Healthcare** — Clinical records, genomic data, and wearable sensor streams require strong privacy protections; [[Federated Learning]] enables multi-hospital model training without sharing patient records; [[Homomorphic Encryption]] enables encrypted genomic analysis.
- **Financial Services** — Anti-money laundering analytics must balance fraud detection with customer data rights; [[Differential Privacy]] enables aggregate reporting without exposing individual transaction patterns.
- **Advertising Technology** — Post-GDPR ad-tech has migrated from third-party cookie tracking toward privacy-preserving measurement (Google's Privacy Sandbox, Apple's SKAdNetwork), demonstrating the commercial impact of regulatory enforcement.
- **AI and Large Language Models** — Regulators have scrutinised LLM training on web-scraped data for lawful basis issues; [[Synthetic Data]] generation is emerging as a privacy-preserving alternative training corpus; on-device inference via [[On-Device AI]] keeps sensitive prompts off cloud servers.
- **Government and Public Sector** — Census data, social benefits records, and tax data require rigorous privacy protections; the US Census Bureau deployed [[Differential Privacy]] for the 2020 Census.
- **Human Resources** — Employee monitoring, recruitment analytics, and workplace surveillance tools are subject to data privacy regulations and must comply with [[Informed Consent]] requirements in many jurisdictions.
- **Cross-border Data Transfers** — Mechanisms including EU Standard Contractual Clauses (SCCs), APEC Cross-Border Privacy Rules (CBPR), and adequacy decisions govern lawful personal data flows between jurisdictions with differing legal standards.

### Standards and Regulatory Context

- **[[GDPR]]** (General Data Protection Regulation, EU 2016/679, effective 2018) — The world's most influential data privacy statute; establishes six lawful bases for processing, eight data subject rights, mandatory DPIAs, DPO appointments, and fines up to €20 million or 4% of global annual turnover.
- **[[CCPA]]** (California Consumer Privacy Act, 2018, amended by CPRA 2020) — Grants California residents rights to know, delete, correct, and opt out of sale of their personal information; enforced by the California Privacy Protection Agency (CPPA).
- **PIPEDA** (Personal Information Protection and Electronic Documents Act, Canada) — Canada's federal private-sector privacy law; currently undergoing reform via Bill C-27 (CPPA).
- **LGPD** (Lei Geral de Proteção de Dados, Brazil, 2020) — Brazil's GDPR-inspired statute establishing ANPD as the national supervisory authority.
- **[[ISO 27701]]** — Extension to ISO 27001/27002 providing a Privacy Information Management System (PIMS) framework; certifiable against a standard aligned to GDPR concepts.
- **NIST Privacy Framework** — Voluntary US framework providing a structure for managing privacy risk through five functions: Identify-P, Govern-P, Control-P, Communicate-P, Protect-P.
- **ePrivacy Directive** (EU 2002/58/EC, pending ePrivacy Regulation reform) — Governs electronic communications privacy, cookie consent, and direct marketing in the EU; currently the subject of long-delayed reform.
- **APEC CBPR** — Asia-Pacific Economic Cooperation Cross-Border Privacy Rules system enabling certified cross-border data flows across participating economies.
- **Article 29 Working Party / EDPB** — European Data Protection Board issues binding decisions and guidelines interpreting GDPR obligations, including on topics such as consent, legitimate interests, and AI.

### Emerging Challenges

- **Generative AI and training data** — LLM training on internet-scraped corpora raises unresolved questions about lawful basis, data subject rights to erasure, and model memorisation of personal data.
- **Re-identification risks** — Advances in linkage attacks and auxiliary data availability mean that k-anonymised or aggregated datasets can be de-anonymised; privacy guarantees must be revisited.
- **[[On-Device AI]]** — Moving inference to the edge reduces cloud data exposure but shifts privacy risk to device security and local data stores.
- **[[Synthetic Data]]** — Statistically representative generated datasets that contain no real personal information are gaining traction for model training and analytics, though fidelity-privacy trade-offs remain active research.
- **Children's privacy** — COPPA (US), GDPR recital 38, and national age-appropriate design codes impose enhanced obligations for processing children's data, intersecting with social media and educational technology governance.
- **Biometric data** — Facial recognition, voice prints, and gait data are classified as special-category data under GDPR Article 9, requiring explicit consent or narrow statutory bases; enforcement against commercial biometric databases is intensifying.

### Current Landscape (2026)

- The EU Digital Omnibus and AI Omnibus proposals, published by the European Commission on 19 November 2025, mark a shift from expansion to simplification: they would narrow the GDPR definition of personal data (excluding information not reasonably linkable to an individual), clarify when pseudonymised data counts as anonymised, and ease AI-related processing, with political agreement targeted for later in 2026.
- The EU AI Act now overlaps directly with data-protection law; its Article 50 transparency obligations (AI-disclosure, synthetic-content marking, emotion/biometric notices) took effect on 2 August 2026, but the most onerous high-risk obligations were deferred to 2 December 2027 (and August 2028 for AI in regulated products) under the Omnibus, ending Europe's technology-neutral approach.
- Enforcement intensified sharply: cumulative GDPR fines passed 7.1 billion euros by early 2026 (1.2 billion in 2025 alone per DLA Piper), authorities now receive around 443 breach notifications per day (up 22% year on year), and the GDPR Procedural Regulation entered into force on 1 January 2026 to harmonise cross-border cases.
- US fragmentation deepened: twenty states now have comprehensive consumer privacy laws in effect as of 1 January 2026 (Indiana, Kentucky and Rhode Island the latest), still with no federal law, while California's CPPA automated decision-making technology (ADMT) rules begin enforcement in January 2027, making 2026 a preparation year.
- The UK diverged via the Data (Use and Access) Act 2025 (Royal Assent 18 June 2025), phasing in between August 2025 and June 2026 with recognised legitimate interests, a more permissive automated-decision regime, simplified cookie rules and expanded ICO powers.
- Privacy-enhancing technologies matured into a compositional stack (TEEs, MPC, FHE, differential privacy, ZKPs, federated learning, data clean rooms); the PET market reached roughly 2.8 billion dollars in 2025 (Gartner projecting over 25 billion by 2030), and NIST finalised SP 800-226 differential-privacy evaluation guidelines in March 2025.
- Open challenges as of 2026 centre on reconciling AI training with data minimisation, the utility-versus-privacy trade-off in differential privacy (epsilon calibration and cumulative budget depletion), gradient-leakage and model-inversion risks in federated learning, the compute overhead of FHE/MPC, and operationalising overlapping GDPR, AI Act, Data Act and 20-plus US state regimes simultaneously.

### References

- 1. OneTrust (2026). The 5 trends shaping global privacy and enforcement in 2026. https://www.onetrust.com/blog/the-5-trends-shaping-global-privacy-and-enforcement-in-2026/
- 2. Kiteworks (2026). GDPR Fines Hit 7.1 Billion Euros: Data Privacy Enforcement Trends in 2026. https://www.kiteworks.com/gdpr-compliance/gdpr-fines-data-privacy-enforcement-2026/
- 3. Al Jazeera (2026). What came into force with the EU's AI Act this week and what didn't. https://www.aljazeera.com/news/2026/8/6/what-came-into-force-with-the-eus-ai-act-this-week-and-what-didnt
- 4. Covington (Inside Privacy) (2026). What to Watch in 2026: Key EU Privacy and Cybersecurity Developments. https://www.insideprivacy.com/european-union-2/what-to-watch-in-2026-key-eu-privacy-cybersecurity-developments/
- 5. NIST (2025). NIST Finalizes Guidelines for Evaluating Differential Privacy Guarantees (SP 800-226). https://www.nist.gov/news-events/news/2025/03/nist-finalizes-guidelines-evaluating-differential-privacy-guarantees-de
- 6. StealthCloud (2026). Privacy-Enhancing Technologies: The Complete 2026 Guide. https://stealthcloud.ai/cryptography/privacy-enhancing-technologies/

### Provenance

