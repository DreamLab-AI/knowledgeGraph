Electronic data interchange (EDI) is the computer to computer interchange of data according to a message standard with a minimum of human intervention, which allows business documents such as purchase orders, invoices and customs declarations to be exchanged and processed electronically.[^1]

NIST, in a mid-1990s report, put it as the part of electronic commerce concerned with the actual interchange of business transactions.[^2] It described the two main standards, ANSI ASC X12 and UN/EDIFACT, as quite similarly organised, specifying a way to define and structure information and a standard format and syntax for structuring business information for electronic interchange.[^2]

## Standards and transport

ASC X12 says it adapts a vocabulary and language used by millions of organizations and draws on more than 40 years of cross-industry standards development.[^3] GS1 has four complementary sets of EDI standards: business terms, EANCOM, GS1 XML and GS1 UN/CEFACT XML.[^4] The AS2 specification, IETF RFC 4130, describes how to exchange structured business data securely over HTTP, and says the data may be XML, EDI in the X12 or UN/EDIFACT format, or other structured formats.[^5] See [[EDIFACT]], [[Advance Ship Notice]] and [[B2B Integration]].

## Origins

GS1 traces the origins of EDI to 1948 in Berlin, where during the Berlin Airlift logistics officers developed a standard manifest system to be transmitted by telex, radio-teletype or telephone.[^4] That is GS1's account and is not corroborated by the other sources opened.

## What the sources do not establish

UNECE says “No comprehensive information on global implementation is available”, so the page gives no adoption figures.[^1] The NIST report is from the mid-1990s and the UNECE leaflet from 2016, so both describe the standards at those dates. The sources do not compare EDI with newer approaches such as web interfaces.[^1][^2]

[^1]: UNECE and UN/CEFACT, “Executive Guide UN/EDIFACT”, 2016 (Internet Archive copy of the UNECE PDF). https://web.archive.org/web/2024/https://unece.org/sites/default/files/2023-10/ExecGuide_UNEDIFACT_Eng.pdf
[^2]: National Institute of Standards and Technology, NISTIR 5631, “Electronic Data Interchange (EDI) Standards”, analysis of ANSI ASC X12 and UN/EDIFACT. https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir5631.pdf
[^3]: ASC X12, “X12 Transaction Sets”. https://x12.org/products/transaction-sets
[^4]: GS1, “GS1 Electronic Data Interchange (EDI) - Standards”. https://www.gs1.org/standards/edi
[^5]: D. Moberg and R. Drummond, IETF RFC 4130, July 2005, “MIME-Based Secure Peer-to-Peer Business Data Interchange Using HTTP, Applicability Statement 2 (AS2)”. https://www.rfc-editor.org/rfc/rfc4130.txt

