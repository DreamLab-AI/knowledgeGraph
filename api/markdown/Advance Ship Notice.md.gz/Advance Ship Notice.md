An advance ship notice (ASN) is an electronic message that tells a receiver the contents of a shipment.[^1][^2]

No source opened uses the term, so the page describes the two message specifications that do the job. ASC X12's 856 Ship Notice/Manifest transaction set can be used to list the contents of a shipment of goods as well as related information such as order information, product description, physical characteristics, type of packaging, marking, carrier information, and configuration of goods within the transportation equipment.[^1] The sender is the organization responsible for detailing and communicating the contents of a shipment to one or more receivers.[^1]

## UN/EDIFACT equivalent

The UN/EDIFACT despatch advice message (DESADV) is a message specifying details for goods despatched or ready for despatch under agreed conditions.[^2] Its stated intent is to advise of the detailed contents of a consignment, and it relates to one seller and one buyer or their respective agents.[^2] The specification is for use in electronic data interchange between trading partners involved in administration, commerce and transport.[^2] See [[EDIFACT]].

## Link to shipping identifiers

GS1 Sweden says companies can share data electronically via EDI or EPCIS, which lets them share status information about logistic units in transit.[^3] See [[Serial Shipping Container Code]] and [[Electronic Data Interchange]].

## What the sources do not establish

Those two specifications carry different names, ship notice or manifest in X12 and despatch advice in UN/EDIFACT, and neither calls itself an advance ship notice. The page lists Despatch Advice as an alias, which fits the UN/EDIFACT name but is not stated by the sources. The sources do not say when in relation to arrival the message must be sent, or how the receiver uses it, so the page leaves out any timing rule. The DESADV text read is release D.01B of 2001.[^1][^2]

[^1]: ASC X12, “X12 Transaction Sets”. https://x12.org/products/transaction-sets
[^2]: UN/CEFACT, “UN/EDIFACT Message DESADV Release: 01B”, Despatch advice message, United Nations Trade Data Interchange Directory (Internet Archive copy). https://web.archive.org/web/2024/https://service.unece.org/trade/untdid/d01b/trmd/desadv_c.htm
[^3]: GS1 Sweden, “GS1 Package Number (SSCC)”. https://gs1.se/en/standards-and-services/serial-shipping-container-code-sscc/

