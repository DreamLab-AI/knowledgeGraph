Order fulfilment is the logistics activity of filling customers' orders; none of the sources opened for this page defines it as a process, so the page is bounded by what they say about it.[^1][^2][^3]

The Council of Supply Chain Management Professionals defines logistics management as the part of supply chain management that plans, implements and controls the forward and reverse flow and storage of goods, services and related information between the point of origin and the point of consumption in order to meet customers' requirements. It lists order fulfilment among the activities that logistics management typically includes, alongside inbound and outbound transportation management, fleet management, warehousing, materials handling, inventory management and the management of third party logistics services providers.[^1]

## Methods of fulfilment

Randall, Netessine and Rudi treat drop-shipping as a method of order fulfilment: the retailer forwards the order to a wholesaler, distributor or manufacturer, who fills it from its own inventory.[^2] They cite surveys reporting that between 23 and 33 percent of Internet retailers rely on drop-shipping as their primary method.[^2] Filling orders from a distribution centre is the other route in the sources. Bartholdi and Hackman describe an e-commerce distribution centre as typically receiving small orders from individuals by phone, fax or the Internet, to be filled and shipped immediately after receipt.[^3]

## Scope and distinctions

Order Fulfilment sits under [[Warehousing and Distribution]]. Related pages are [[Drop Shipping]], [[Omnichannel Fulfilment]], [[Fulfilment Centre]], [[Order Picking]] and [[Last-Mile Delivery]].

## What the sources do not establish

This page rests on thin evidence. The CSCMP page opened here carries its definitions of supply chain management and logistics management, not an entry for order fulfilment, and the glossary PDF itself was not opened. The sources give no agreed list of stages between receipt of an order and delivery, so the page does not set one out.

[^1]: Council of Supply Chain Management Professionals, “SCM Definitions and Glossary of Terms”. https://cscmp.org/CSCMP/CSCMP/Educate/SCM_Definitions_and_Glossary_of_Terms.aspx
[^2]: Randall, Netessine and Rudi (author copy hosted by the Wharton School), “An Empirical Examination of the Decision to Invest in Fulfillment Capabilities: A Study of Internet Retailers”. https://faculty.wharton.upenn.edu/wp-content/uploads/2012/04/RandallNetessineRudi.pdf
[^3]: Georgia Institute of Technology (Bartholdi and Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf

