
An agent decommission record is the record of an agent's retirement from service, declared as `DecommissionRecord` in the lifecycle module of the Agent Ontology.[^1] The Agent Ontology declares the class without a definition; this one follows from its position. visionGraph places it under [[Lifecycle Management]] and as part of an [[Agent Lifecycle Record]].

A lifecycle record reaches it through `decommissionRecord`. It is the closing counterpart of the [[Agent Genesis Record]]: together the two bracket an agent's existence, with the [[Health Check]] specification and the current state between them.

A decommission record is the natural place to state why and when an agent was withdrawn and what became of its credentials, such as its keys and wallets. The class itself carries no properties, so a deployment adds whichever of those fields it needs.

[^1]: Semantic Agent Communication Community Group, “Lifecycle Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/lifecycle.ttl

