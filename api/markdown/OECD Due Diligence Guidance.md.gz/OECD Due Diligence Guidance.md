The OECD Due Diligence Guidance is guidance published by the Organisation for Economic Co-operation and Development on how enterprises can carry out due diligence for responsible business conduct, and this page is written without the OECD's own text, which could not be opened, from the way other instruments describe it.[^1]

Directive (EU) 2024/1760 describes the OECD Due Diligence Guidance for Responsible Business Conduct and sectoral guidance as internationally recognised frameworks setting out practical due diligence steps to help companies identify, prevent, mitigate and account for how they address actual and potential impacts in their operations, supply chains and other business relationships.[^1] It also records that the concept of human rights due diligence was specified and further developed in the OECD Guidelines for Multinational Enterprises.[^1]

## Sector guidance on minerals

Regulation (EU) 2017/821 refers to the OECD Due Diligence Guidance for Responsible Supply Chains of Minerals from Conflict-Affected and High-Risk Areas, and notes that in May 2011 the OECD Ministerial Council recommended the active promotion of the observance of that Guidance.[^2] The European Commission says the regulation requires importers to follow a five-step framework laid out by the OECD, and lists the steps as establishing management systems, identifying and assessing risk, designing a response strategy, an independent third-party audit, and annual reporting.[^3]

## Other references

The Responsible Business Alliance Code of Conduct references the OECD Guidelines for Multinational Enterprises among the international norms behind its standards.[^4]

## Scope and limits

The Guidance supports [[Supply Chain Due Diligence]] and is referenced by [[Supply Chain Due Diligence Instrument]]s. The sources here do not give the Guidance's steps for general responsible business conduct, its date, or its annexes, and the five steps above are those the Commission attributes to the minerals guidance, not necessarily the general guidance. A reader needing the text should consult the OECD publication directly.

[^1]: European Parliament and Council of the European Union, Directive (EU) 2024/1760 of 13 June 2024, “Directive (EU) 2024/1760 of the European Parliament and of the Council on corporate sustainability due diligence”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202401760
[^2]: European Parliament and Council of the European Union, Regulation (EU) 2017/821 of 17 May 2017, “Regulation (EU) 2017/821 of the European Parliament and of the Council laying down supply chain due diligence obligations for Union importers of tin, tantalum and tungsten, their ores, and gold originating from conflict-affected and high-risk areas”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32017R0821
[^3]: European Commission, Directorate-General for Trade, “Conflict Minerals Regulation: The regulation explained”. https://policy.trade.ec.europa.eu/development-and-sustainability/conflict-minerals-regulation/regulation-explained_en
[^4]: Responsible Business Alliance, Code of Conduct. https://www.responsiblebusiness.org/code-of-conduct/

