Rules of origin are the criteria used to decide where a product was made, which defines the economic nationality of the goods.[^1][^2]

The WTO says rules of origin are needed to attribute one country of origin to each product.[^1] The European Commission stresses that origin means where goods are considered to have been produced or manufactured, not where they are shipped from.[^2] Article 1 of the WTO Agreement on Rules of Origin defines them as the laws, regulations and administrative determinations of general application applied to determine the country of origin of goods, except those related to granting tariff preferences.[^1]

## Two kinds

Non-preferential rules apply in the absence of any trade preference, that is, when trade is conducted on a most-favoured-nation basis.[^1] The Commission says they are also used to implement commercial policy measures such as anti-dumping and countervailing duties, trade embargoes, safeguard measures and quantitative restrictions or tariff quotas, and that the EU applies its own non-preferential rules, which may differ from those of other countries.[^2] Preferential rules determine whether a good qualifies as originating from a country with which a preferential arrangement exists.[^2] WTO members agreed to negotiate common non-preferential rules, but the negotiations have not concluded and not all members apply origin requirements for non-preferential purposes.[^1]

## In practice

GOV.UK says that if there is a preference agreement with the country of export, an importer may be able to reduce the duties, and that an exporter may need proof of origin where the destination applies a reduced or zero rate of duty.[^3][^4] Maersk's glossary describes the certificate of origin as a document issued by a certifying authority stating the country of origin, which can be the key document in requesting a special reduced tariff rate under programmes such as GSP.[^5] See [[Customs Duty]] and [[Tariff Classification]].

## Evidence limits

Sources report WTO, EU and UK positions. The detailed product-specific criteria, such as change of tariff heading or value-added thresholds, are not described in the passages read here.[^1][^2]

[^1]: World Trade Organization, “WTO | Trade topics - Rules of origin gateway”. https://www.wto.org/english/tratop_e/roi_e/roi_e.htm
[^2]: European Commission, “Rules of origin for goods - Taxation and Customs Union”. https://taxation-customs.ec.europa.eu/customs/rules-origin-goods_en
[^3]: HM Revenue and Customs, “Check if you can pay a reduced amount of Customs Duty - GOV.UK”. https://www.gov.uk/guidance/check-if-you-can-pay-a-reduced-rate-of-customs-duty
[^4]: HM Revenue and Customs, “Export goods from the UK: step by step - GOV.UK”. https://www.gov.uk/export-goods
[^5]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms

