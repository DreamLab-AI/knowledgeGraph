Kinematics is the branch of mechanics that studies the geometry and mathematics of motion — positions, velocities, accelerations, and trajectories of bodies — without consideration of the forces or torques that cause that motion. In robotics and spatial computing, it encompasses forward kinematics (mapping joint-space parameters to Cartesian end-effector pose via homogeneous transformation matrices and Denavit-Hartenberg conventions) and inverse kinematics (solving the reverse mapping from desired pose to joint configurations). Kinematic analysis underpins motion planning, trajectory generation, workspace characterisation, collision avoidance, and animation systems across robotics, biomechanics, computer graphics, and autonomous vehicles.

### Overview

- Kinematics is one of the oldest formal disciplines in mechanics, formalised through the work of Ampère, Reuleaux, and later Denavit and Hartenberg in the mid-20th century. Despite its classical origins, it remains a live area of engineering and computing research because:
  - Robot architectures grow more complex (parallel robots, cable-driven systems, hyper-redundant arms).
  - Real-time inverse kinematics solvers are demanded in interactive applications such as [[Computer Animation]], [[Augmented Reality]], and surgical robotics.
  - [[Digital Twin]] simulation requires high-fidelity kinematic models updated from live sensor data.
- The two canonical problems in kinematics are:
  - **Forward kinematics (FK)**: Given a vector of joint variables (angles, translations), compute the position and orientation of each link and the [[End Effector]] in the world frame. This is always unique and computationally straightforward, typically solved by composing a chain of [[Homogeneous Transformation]] matrices.
  - **Inverse kinematics (IK)**: Given a desired end-effector pose, find the joint variable vector(s) that achieve it. This is generally non-linear, may have multiple solutions, no solutions (outside the workspace), or infinitely many solutions (for redundant robots), and is the computationally harder problem.
- Kinematics feeds directly into:
  - [[Robot Dynamics]] — once joint trajectories are known, forces/torques can be computed.
  - [[Motion Planning]] — planners operate in joint space or Cartesian space using kinematic models.
  - [[Workspace Analysis]] — reachable and dexterous workspaces are derived kinematically.
  - [[Collision Avoidance]] — link geometry sweeps are computed from kinematic configurations.

### Key Components

#### Kinematic Representations

- **[[Denavit-Hartenberg Parameters]]** — the canonical four-parameter convention (link length, link twist, link offset, joint angle) for representing serial robot geometry as a product of four elementary transforms per joint. Widely used in industrial robotics and [[Robot Operating System]] (ROS) URDF files.
- **[[Homogeneous Transformation]] matrices** — 4×4 matrices encoding rotation (SO(3)) and translation in a unified framework, enabling efficient chain multiplication for FK.
- **Screw theory and product-of-exponentials (PoE)** — an alternative to DH parameters using Lie group SE(3) and the exponential map; geometrically cleaner and better suited to modern optimisation-based IK.
- **Quaternion representation** — compact, singularity-free rotation encoding used in [[Computer Animation]], [[Augmented Reality]] tracking, and IMU-based pose estimation.

#### The Jacobian in Kinematics

- The **[[Jacobian Matrix]]** relates infinitesimal joint velocities to end-effector linear and angular velocities, forming the core of [[Differential Kinematics]].
- Jacobian pseudo-inverse and damped least-squares methods underpin iterative IK solvers.
- Singularity analysis: when the Jacobian loses rank, the robot loses degrees of freedom in certain directions — critical for safety and path planning.

#### Inverse Kinematics Solution Methods

- **Closed-form (analytical)** — possible for robots satisfying the Pieper criterion (three consecutive joint axes intersect at a point); yields all solution branches efficiently.
- **Iterative numerical** — Newton-Raphson, Jacobian transpose, damped least-squares (Levenberg-Marquardt); general but require convergence management.
- **Learning-based** — neural networks (FABRIK, deep IK) approximate IK for high-DoF and hyper-redundant systems; increasingly used in [[Reinforcement Learning]]-based robot control.

#### Kinematic Chain Topologies

- **Serial (open-chain)** — each link connects to exactly one parent and one child; most industrial manipulators.
- **Parallel** — multiple kinematic chains connect base to end-effector simultaneously (e.g. Stewart platform, delta robot); higher stiffness and payload but smaller workspace.
- **Redundant** — more degrees of freedom than task constraints; enables obstacle avoidance and joint-limit avoidance via null-space motion.
- **Closed-chain** — loops within the mechanism; require constraint equations rather than simple forward-chain multiplication.

### Applications / Use Cases

#### Industrial Robotics

- [[Manipulator]] path programming in automotive assembly, welding, painting, and pick-and-place relies entirely on kinematic models to convert Cartesian task descriptions into joint commands.
- Offline programming tools (e.g. ABB RobotStudio, KUKA.Sim) use kinematic simulation to verify reach and cycle time before deployment.

#### Computer Animation and Games

- Character skeletal rigs use FK for authored motion clips and IK for procedural foot-planting, hand-reaching, and look-at behaviours in real-time engines (Unreal, Unity).
- Motion capture data is retargeted across character skeletons via kinematic solving.

#### Augmented and Virtual Reality

- [[Augmented Reality]] hand-tracking pipelines reconstruct finger joint angles from depth or RGB cameras using kinematic hand models.
- VR full-body avatars use kinematic solvers to infer elbow and hip positions from sparse tracker data (headset + controllers).
- [[Digital Twin]] industrial overlays require live kinematic state of physical machines synced to virtual counterparts.

#### Surgical and Medical Robotics

- Laparoscopic robot systems (da Vinci) rely on IK to map surgeon hand motions at the console to instrument tip motions at the patient.
- Prosthetic limb control and biomechanical gait analysis depend on kinematic modelling of human joints.

#### Autonomous Vehicles and Drones

- [[Autonomous Vehicles]] use kinematic bicycle and unicycle models for path tracking and steering control at low speeds.
- Multi-rotor UAV attitude control involves rigid-body kinematics of the vehicle frame and propeller geometry.

#### Space Robotics

- On-orbit servicing arms (Canadarm, ERA on ISS) require precise FK/IK including flexible-body corrections for micro-gravity operations.

### Standards & Context

- **ISO 9283:1998** — Manipulating industrial robots: performance criteria and related test methods; relies on kinematic definitions for pose accuracy and repeatability.
- **ROS URDF (Unified Robot Description Format)** — XML schema encoding kinematic and dynamic parameters (joint axes, limits, DH geometry) used universally in [[Robot Operating System]] ecosystems.
- **IEEE Std 1872-2015 (CORA)** — Core Ontology for Robotics and Automation; formally defines kinematic concepts including joint, link, and kinematic chain.
- **DIN ISO 8373** — Robots and robotic devices vocabulary; defines terms overlapping with kinematics (pose, dexterity, workspace).
- Theoretical foundations are codified in Craig (2005) *Introduction to Robotics*, Siciliano et al. (2009) *Robotics: Modelling, Planning and Control*, and Murray, Li & Sastry (1994) *A Mathematical Introduction to Robotic Manipulation* (open-access).

### Semantic Classification

### Provenance

