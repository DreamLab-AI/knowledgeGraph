Blended finance is the strategic use of concessional public or philanthropic capital to mobilise additional private investment toward development and sustainability goals. By absorbing early-stage or disproportionate risk, the concessional tranche improves the risk-adjusted return of a project enough to attract commercial investors who would not otherwise participate. It is widely applied to fund infrastructure, climate, and social projects in markets perceived as too risky for purely commercial capital.

### Overview

- Many high-impact projects in emerging markets are economically viable yet too risky to attract commercial capital on their own.
- Blended finance addresses this gap by layering different forms of capital with different risk and return expectations in a single structure.
- Public, development, or philanthropic funds take subordinate or first-loss positions, de-risking the investment enough for private capital to enter.
- The goal is leverage: each unit of concessional capital should mobilise several units of private investment toward measurable outcomes.

### Key aspects

- Concessional capital: below-market funding that improves project economics for others.
- Catalytic leverage: mobilising private investment that would not otherwise occur.
- Risk layering: tranches with differentiated risk-return profiles within one structure.
- Outcome orientation: alignment with development, climate, and social objectives.
- Additionality: ensuring concessional support attracts rather than displaces private capital.

### Mechanisms

- First-loss guarantees or subordinated tranches shield senior commercial investors from initial losses.
- Technical assistance and grants reduce project preparation and operational risk.
- Blended structures align returns across investors with differing mandates and risk appetites.

### Applications

- Financing infrastructure, climate, and social projects through [[Impact Investing]].
- Channelling capital toward [[Sustainable Development]] objectives.
- Supporting [[Green Finance]] and climate-aligned investment.
- Structuring funds that balance returns with [[Social Impact]] and [[ESG]] goals.

### Provenance

