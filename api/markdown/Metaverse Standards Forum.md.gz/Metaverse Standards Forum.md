The Metaverse Standards Forum (MSF) is an industry consortium hosted by the Khronos Group, founded in June 2022, that coordinates existing standards-development organisations to promote interoperability across metaverse and spatial-computing platforms rather than authoring competing specifications. With several hundred member organisations — including Meta, Microsoft, NVIDIA, Sony, Epic Games, the W3C, and ISO — it operates domain-specific working groups that identify interoperability gaps and produce exploratory prototypes whose outputs feed back into recognised bodies for normative ratification. Its model of pre-competitive alignment distinguishes it from traditional specification-writing bodies: it acts as a coordination layer, convening the standards ecosystem to prevent the fragmentation that would result from proprietary, siloed virtual worlds.

### Overview

- The MSF emerged from a widely shared diagnosis in the industry: the primary risk to an [[Open Metaverse]] is not technical impossibility but fragmentation into proprietary walled gardens where avatars, assets, and identities created on one platform cannot migrate to another. By coordinating rather than competing with existing standards bodies the Forum aims to prevent this outcome.
- Hosted by the [[Khronos Group]] — the consortium behind [[OpenXR]], [[glTF]], and [[Vulkan]] — the MSF benefits from Khronos's infrastructure and credibility while remaining open to organisations beyond the Khronos membership, including the [[World Wide Web Consortium]], [[ISO]], and independent companies of all sizes.
- Membership encompasses several hundred organisations across the spectrum: platform incumbents ([[Meta Platform]], [[Microsoft]], [[Apple]]), hardware vendors ([[NVIDIA]], [[Qualcomm]], [[Sony]]), game engine providers ([[Epic Games]], [[Unity Technologies]]), and standards bodies. This breadth is intentional; pre-competitive alignment expands the total market for all participants rather than merely redistributing share.
- The Forum's distinctive model separates gap analysis and prototyping (MSF domain working groups) from normative specification (delegated to appropriate authoring bodies). This avoids jurisdictional conflicts, reduces duplicated effort, and respects the long-standing processes of ISO, W3C, and Khronos.

### Key Components

- **Domain Working Groups** — the primary organisational unit; each targets a concrete interoperability problem
  - *3D Asset Interoperability* — alignment between [[glTF]], [[Universal Scene Description]] (Universal Scene Description), [[OpenUSD]], and [[FBX]] formats for asset portability across engines and platforms
  - *Avatar and Identity* — standards for portable [[Cross-Platform Avatar]] representations, linking to [[Decentralised Identity]] and [[Verifiable Credential]] frameworks
  - *Real-World Digital Twins* — interoperability between [[Digital Twin]] platforms and geospatial data standards such as [[OGC CityGML]] and [[IFC]]
  - *Network Scene Synchronisation* — protocols for transmitting [[Scene Description]] across networked [[Virtual World]] instances
  - *Accessibility* — ensuring [[Extended Reality]] platforms meet accessibility norms across jurisdictions
  - *Digital Fashion* — interoperable [[Wearable NFT]] and digital clothing representations across virtual environments
- **Gap Analysis Reports** — each working group publishes structured analyses identifying where missing or competing standards create fragmentation, serving as input to existing authoring bodies
- **Exploratory Prototypes** — proof-of-concept implementations demonstrating interoperability between distinct platforms; not normative but evidential, demonstrating feasibility to authoring bodies
- **Liaison Relationships** — formal links to [[World Wide Web Consortium]], [[Khronos Group]], [[ISO]], [[IEEE]], [[IETF]], [[OGC]], and national standards bodies ensuring outputs are routed to the right venue
- **Public Member Directory** — an open roster that signals the breadth of industry alignment, used as a coordination signal for enterprise procurement and regulatory engagement

### Applications and Use Cases

- **Cross-Platform Asset Portability** — a 3D garment or vehicle model created by a brand can be exported once and used across multiple social [[Virtual World]] platforms without bespoke conversion, enabled by MSF-aligned [[3D Asset Interchange]] standards such as [[glTF]] and [[OpenUSD]]
- **Portable Digital Identity** — a user's verified identity and reputation, anchored by [[Decentralised Identity]] frameworks such as [[Decentralised Identifier]] and [[Verifiable Credential]] standards, can accompany them across platforms without re-verification, reducing friction and improving safety
- **Interoperable Digital Twins** — manufacturing, urban planning, and infrastructure operators building [[Digital Twin]] systems benefit from common scene description formats ensuring that a twin built on one engine can be consumed by another, relevant to [[Industry 4.0]] and [[Smart City]] contexts
- **XR Hardware Agnosticism** — [[OpenXR]] alignment championed through MSF means that an [[Augmented Reality]] or [[Virtual Reality]] application runs across headsets from multiple vendors without hardware-specific porting, lowering developer cost
- **Regulatory Readiness** — by producing documented gap analyses and engaging with ISO and national bodies the MSF positions the industry to provide technically grounded input to immersive-technology legislation being developed in the EU, UK, and elsewhere, particularly regarding [[Data Governance]] and [[Consumer Protection]]
- **Enterprise Spatial Computing Adoption** — large enterprises evaluating [[Spatial Computing]] for training, design review, and collaboration are more likely to commit capital when open interoperability standards reduce vendor lock-in risk; the MSF directly addresses this barrier

### Standards and Context

- The MSF operates in a dense ecosystem of existing specifications that it coordinates rather than replaces:
  - [[OpenXR]] — the Khronos API standard for [[XR]] runtime access; MSF works to ensure consistent platform behaviour across headsets
  - [[glTF]] — the Khronos transmission format for [[3D Asset]], widely adopted by browsers, game engines, and AR platforms; MSF's 3D working group aligns derivative profiles
  - [[OpenUSD]] — Pixar's Universal Scene Description, adopted by [[Apple]], [[NVIDIA]], and others; MSF works toward convergence with glTF for scene-level interoperability
  - [[WebXR]] — the W3C API for browser-based XR; MSF liaises to align runtime and content interoperability across the web stack
  - [[Decentralised Identifier]] (Decentralised Identifiers) — the W3C standard underpinning portable digital identity; MSF's avatar working group evaluates its applicability to cross-platform user identity
  - [[Verifiable Credential]] — the W3C credential standard for portable, machine-verifiable attributes; relevant to avatar reputation and access control across virtual spaces
  - [[OGC CityGML]] and [[IFC]] — geospatial and built-environment standards relevant to the MSF's digital-twin working group
- The Forum co-exists with other coordination bodies including the [[Open Metaverse Alliance for Web3]] (OMA3) which focuses on [[Blockchain]]-anchored ownership and [[Smart Contract]] governance, and the [[XR Association]] which advocates on policy. MSF's distinct niche is technical interoperability at the protocol and format layer, independent of any particular blockchain or monetisation model.
- Regulatory context: the [[European Union]]'s [[Digital Markets Act]] and emerging spatial-computing regulations in the UK and South Korea reference open interoperability norms; MSF documentation is increasingly cited by policy teams as evidence of industry self-governance capacity.

### Current Landscape (2026)

- Membership has scaled past 2,500 organisations (Neil Trevett of NVIDIA/Khronos still chairing), up from 35 originating members at the June 2022 launch, now running roughly 12 active Domain Working Groups plus exploratory groups spanning 3D assets, avatars, geospatial, networking and accessibility.
- The flagship 2026 output is the Open Metaverse Browser Initiative (OMBI), created with RP1: its Sneeze browser engine was open-sourced under Apache 2.0 in June 2026, offering multi-origin 3D scene composition via a Scene Object Model, per-service WebAssembly sandboxing and proximity-based loading, and serving as a live interoperability testbed built on Khronos (OpenXR, glTF, ANARI), W3C (WebAssembly, DIDs) and OGC (GeoPose) standards.
- RP1 shipped Artemis, billed as the first native metaverse browser, on top of Sneeze (announced June 2026 around AWE 2026), letting users navigate spatial "fabrics" by URL without per-app installs.
- The Forum catalysed a glTF Gaussian splatting extension (KHR_gaussian_splatting): after Town Halls beginning January 2025, the 3D Assets Working Group moved it to release-candidate state in early 2026 with Khronos ratification expected around Q2 2026, using point-primitive fallback for renderers lacking splat support.
- The 3D Web Interoperability Working Group published the Web of Worlds (WoW) whitepaper and a Consistency of Experience use-case document (approved November 2025), framing an open metaverse built on existing web standards.
- New governance and responsible-tech tracks emerged: the Forum Labs Initiative launched with p-NET as its first Principal Lab, an AI in the Metaverse exploratory group now coordinates across SDOs, and a Responsible Data Governance (RDG) Standard for immersive and AI-integrated systems was introduced in January 2026.
- Open challenges as of 2026 centre on unresolved format tensions (notably USD versus glTF for 3D assets and Apple's XR positioning), avatar portability with competing incompatible identity/format proposals, and turning reference implementations like Sneeze into ratified, widely adopted cross-platform standards.

### References

- 1. Metaverse Standards Forum (2026). Newsroom — Sneeze open metaverse browser engine, OMBI and Accessibility WG reports. https://metaverse-standards.org/news/
- 2. RP1 / BusinessWire via YourTechDiet (2026). RP1 Launches Artemis, the World's First Native Metaverse Browser (Sneeze engine, Apache 2.0, June 2026). https://yourtechdiet.com/news/rp1-launches-artemis-the-worlds-first-native-metaverse-browser/
- 3. Metaverse Standards Forum (2026). Open Metaverse Browser Initiative (OMBI). https://metaverse-standards.org/open-metaverse-browser-initiative/
- 4. Metaverse Standards Forum / Khronos Group (2026). 3D Assets Working Group — KHR_gaussian_splatting glTF extension standardisation update (10 February 2026). https://www.youtube.com/watch?v=f7tn0MA8TXM
- 5. Metaverse Standards Forum (2026). Groups & Projects — Domain and Exploratory Working Groups. https://metaverse-standards.org/domain-groups/

### Provenance

