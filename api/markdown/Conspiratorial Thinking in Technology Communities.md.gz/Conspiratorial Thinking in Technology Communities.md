Conspiracies, in the context of technology communities, refers to the recurring pattern of conspiratorial thinking that attaches to emerging technologies such as cryptocurrency and AI. Often rooted in legitimate governance concerns, such thinking can escalate into disinformation ecosystems, creating tensions within technology policy, AI safety debates, and open-source governance.

### Semantic Classification

### Content

- Lots of the online communities that glom around the research topics of this book self identify as libertarian, mistrustful of government. To be clear, there are many specific failings they can (and do) point to. It's not the work of this knowledge base to unpick who is right and wrong here. As usual most likely there are no simple solutions, and the trust, as ever, is in the middle. With that said, there a significant pockets of outright conspiracy within these technology communities, and it makes some sense to gather them here.

# A grounding: The Paranoid Style in American Politics

- This 1964 [essay by Richard Hofstadter](https://harpers.org/archive/1964/11/the-paranoid-style-in-american-politics/) examines the "paranoid style" in American politics, a recurring phenomenon characterised by heated exaggeration, suspicion, and conspiratorial fantasy. Hofstadter argues that this style is not limited to the mentally ill, but rather a mode of expression used by "more or less normal people" to advocate for their political views.
- He traces the paranoid style through various historical episodes:
  - **The Bavarian Illuminati panic:** A fear of a secret society plotting against the United States, linked to the French Revolution and the rise of Jeffersonian democracy.
  - **Anti-Masonry:** A widespread movement accusing Freemasons of conspiring against republican government and the common man.
  - **Anti-Catholicism:** A nativist movement fearing a Catholic plot to undermine American values, often fuelled by exaggerated claims of sexual immorality and hidden agendas.
- Hofstadter then analyses the paranoid style in the context of the contemporary right wing, which he sees as feeling "dispossessed" and believing in a grand conspiracy to undermine America's values and institutions. Key elements of this contemporary paranoia include:
  - A long-running conspiracy to destroy free capitalism and install socialism or communism.
  - The infiltration of government by communist agents, leading to betrayals of national interests.
  - A widespread network of communist agents influencing education, religion, the press, and the media.
- Hofstadter argues that the paranoid style often involves:
  - **Apocalyptic thinking:** Seeing the world in terms of absolute good vs. evil, and believing in imminent threats to civilisation.
  - **Militant leadership:** Rejecting compromise and seeking total victory against the enemy, which is often perceived as inherently evil and unappeasable.
  - **Projection of self:** Attributing their own desires, fears, and failings to the enemy, who is often depicted as a powerful, sinister, and immoral force.
  - **Excessive reliance on "evidence":** Gathering seemingly factual data to support pre-existing beliefs, often ignoring contradictory evidence and exhibiting a strong resistance to enlightenment.
- Hofstadter opines that 'the paranoid style' is a persistent psychic phenomenon, fuelled by social conflict, a sense of powerlessness, and a lack of access to the political process. It is a self-perpetuating cycle that leads to distorted perceptions and a double suffering: from the real world, and from the individual's own fantasies.
- It is a seminal work in American political thought, sparking significant debate and continuing to resonate in contemporary discussions. While the essay has been lauded for its insightful observations, it also faces criticism for its limitations, particularly in terms of its historical and psychological frameworks.
  - **The Enduring Nature of the Paranoid Style:** Hofstadter accurately identified the persistent presence of conspiracy theories and paranoid thinking in American politics. This phenomenon, as evidenced by the movements he analysed (anti-Masonry, anti-Catholicism, McCarthyism), continues to manifest in contemporary political discourse, particularly on the right. As sociologist Kathleen B. Jones argues in her book "Conspiracy Theories: The Paranoid Style in American Politics," the paranoid style is a "recurring theme in American political culture," driven by anxieties about social change and perceived threats to existing power structures.
  - **The Psychological Dynamics of Paranoid Thinking:** Hofstadter astutely observed the projection of fears and anxieties onto an external enemy, the tendency towards apocalyptic thinking, and the reliance on "evidence" as a means of bolstering pre-existing beliefs. These psychological mechanisms remain relevant in understanding the motivations and behaviours of those who embrace paranoid narratives, as psychologist Daniel Goleman notes in his book "Emotional Intelligence," where he discusses the role of fear and anxiety in fostering irrational beliefs.
  - **The Role of Social Conflict:** Hofstadter's analysis highlighted how social conflict, particularly around issues of class, ethnicity, and religion, can fuel the paranoid style. His observation that this style often emerges when individuals feel "dispossessed" and shut out of the political process resonates with contemporary research on social movements and political alienation. Sociologist Michael Mann, in his book "The Dark Side of Democracy: Explaining Ethnic Cleansing," argues that feelings of marginalisation and powerlessness can drive individuals to embrace extreme ideologies and engage in violent or destructive actions.
  - **The Oversimplification of "Paranoid Style":** Critics argue that Hofstadter's concept is overly broad and simplistic. The term "paranoid style" risks pathologising political beliefs, conflating genuine anxieties with irrational fears, and failing to acknowledge the complexity of political motivations. Political scientist Jeffrey C. Goldfarb, in his article "The Paranoid Style: A Critical Reassessment," argues that Hofstadter's analysis "overlooks the historical and social context" of the beliefs he analyses, failing to adequately address the real grievances and anxieties that might fuel paranoid thinking.
  - **The Focus on Right-Wing Politics:** While Hofstadter acknowledged the paranoid style's potential for both left-wing and right-wing movements, his essay primarily focused on the latter. This focus has led some to argue that his analysis perpetuates a bias towards viewing the right as inherently more prone to irrational thinking. Within the online communities referenced in this graph there are examples of both, but it does tend to skew right. While it's true that the right has historically been associated with more conspiracy theories, this should not be seen as an inherent feature of right-wing ideology. As historian Daniel Rodgers notes in his book "Age of Fracture," conspiracy theories have emerged across the political spectrum throughout history.
  - **The Lack of Nuance in Psychological Analysis:** While Hofstadter's observations about the psychological mechanisms of paranoia are insightful, his analysis lacks the nuanced understanding of psychological complexity that has emerged in subsequent decades. While he identified common psychological features, he failed to acknowledge the intricate interplay of factors that contribute to paranoia, such as personal experiences, social conditioning, and cultural context.

# Bitcoin

- Bitcoin’s online community skews very hard toward right wing libertarianism. This isn’t to say there are no other voices, but they are certainly outnumbered. This imbalance is almost certainly a product of the ESG concerns around the technology. There has been a notable increase in diversity of thought since the evolution of the energy narrative, but it persists. This leads to a paucity of voices in policymaking circles, and in the USA a strong delineation between policymakers along party lines. This kind of thing tends to be self reinforcing, and it seems very possible that the global liberal left will swing mainly against the technology, while the neoliberal right will be attracted more to it. As tensions increase so it seems does the online rhetoric. Even scientists now seem to agree that Bitcoin investors are calculating psychopaths.[[martin2022dark]] This leads to:
- There are some powerful ‘pockets’ of fringe thinking within the [vocal, online, Bitcoincommunities](https://pourteaux.substack.com/p/bitcoin-culture-burn-it-to-the-ground?).The [mostpalatable](https://www.forbes.com/sites/peterizzo/2022/07/04/bitcoin-maximalism-is-dead-long-live-bitcoin-maximalism/?)of these are figures like [MichaelSaylor](https://www.saylor.org/about/), Elon Musk and Jack Dorsey, but there’s whole subcultural intersections around antivax, anti-woke, anti cancel culture, and fad diets. These are the so-called “[toxicmaximalists](https://blog.lopp.net/history-of-bitcoin-maximalism/)”.There are a disproportionate number of adherents of the failed global “neoliberal” economic experiment,[[va2010neoconservatism]] and not a few outright bigots. Lopp’s list linked above is an amusing roundup:
  - Carnivory
  - Laser eyes
  - Anti-woke
  - Weightlifting
  - Tradwife culture
  - Climate change denial
  - Overt Christian moralizing
  - “Have fun staying poor” retorts
  - Rejection of seed oils and sunscreen
  - Vaccine conspiracies, alt-health cure-alls
  - Contrarianism for the sake of contrarianism
  - Political populism and support of strongmen
  - “Fiat” criticism of contemporary art and architecture
- As Lopp himself points out, it’s not that these things are necessarily wrong or bad, but more that adherence to the set became a purity testf or the whole space. It might seem that this isn’t terribly important, but Bitcoin viewed though the lens of these of these communities looks pretty strange to the newcomer.

# Artificial Intelligence

- Recent years have seen the rise of "tribes of thought", especially in Silicon Valley in the USA
- The debate has intensified as AI capabilities have rapidly advanced
- Concerns about AI safety and risks have grown alongside excitement about AI's potential benefits
- Roots in long-running philosophical discussions about the risks and benefits of technological progress
- California legislators, under the influence of Effective Altruism activists, attempted to pass a disastrous bill for open-source AI and the technology industry generally. SB 1047 would have created an unaccountable Frontier Model Division staffed by EAs with police powers, and would have allowed model developers to be jailed for the thoughtcrime of doing AI research. The bill was vetoed by Governor Newsom in September 2024.
- [Call-To-Action on SB 1047 | Alliance for the Future (affuture.org)](https://www.affuture.org/post/9-context/) [[California AI bill]]
- [Vinod Khosla on X: "Open source is good for VC's and innovation. Open Source SOTA models is really bad for national security" / X (twitter.com)](https://twitter.com/vkhosla/status/1789345720706961838?t=_vgHHgmdky1nU5X5C0SQpg&s=19)

<https://twitter.com/vkhosla/status/1789345720706961838?t=_vgHHgmdky1nU5X5C0SQpg&s=19>

### Effective Altruists (EA) / AI Safety Advocates

- Tend to emphasise caution and safety considerations around AI development
- Concerned about risks of advanced AI systems causing harm or even existential catastrophe
- Argue for more research into AI safety and potentially slowing down or regulating AI development
- Associated with figures like Eliezer Yudkowsky, Paul Christiano, Nick Beckstead
- Recent appointment of "AI doomer" Paul Christiano to head US AI safety institute seen as a win for this camp
  - [Feds appoint “AI doomer” to run AI safety at US institute | Ars Technica](https://arstechnica.com/tech-policy/2024/04/feds-appoint-ai-doomer-to-run-us-ai-safety-institute/) [[AI Governance Law and Privacy]]
  - [AI Safety Is Dead, and Chuck Schumer Faces Risks - Bloomberg](https://www.bloomberg.com/opinion/articles/2024-05-21/ai-safety-is-dead-and-chuck-schumer-faces-risks) [[Safety and alignment]]
  - Note: The US AI Safety Institute was subsequently restructured by the Trump administration in early 2025 and renamed the Center for AI Standards and Innovation (CAISI), with a shift in focus away from safety regulation toward national security and competitiveness.

### Effective Accelerationists (EAcc) / AI Risk Sceptics

- Emphasise the potential benefits of rapid AI progress
- Tend to be more sceptical of AI safety concerns as blocking human advancement
- Argue that slowing down AI development could deny humanity massive benefits
- Associated with figures like "Beff Bezos" aka Guillaume Verdon, Daniel Dewey, Nick Land
- See accelerating AI as part of a broader techno-capitalist imperative to transcend human limitations

## Geographical and Cultural Factors

- Debate is especially prominent in San Francisco/Silicon Valley and Oxford/Cambridge
- EA emerged from philosophy departments, especially Oxford
- EAcc has roots in Silicon Valley startup and venture capital culture
- Both have ties to the rationalist community and "weird" ideas like thermodynamic intelligence

### Provenance

