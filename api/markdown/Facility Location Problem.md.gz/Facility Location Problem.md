In operations research, the facility location problem is the problem of deciding where to place one or more facilities, and often how many and how large, so as to optimise an objective such as total cost, given the demand they serve.[^1][^2]

A handbook chapter on operations research describes location problems as concerned with determining the location of a facility or several facilities to optimise one or more objective functions under constraints. Typical questions are how many facilities to locate, where each should go, how large each should be, and how demand should be allocated among them.[^1] The facility can be a factory, distribution centre, warehouse, cross-dock or hub.[^1] A lecture at the University of Groningen frames the same problem in supply chain terms, with the number and location of facilities as the main questions and the minimisation of facility, transport and inventory costs as the usual objective.[^2]

## Main variants

That handbook separates problems by the space in which facilities can sit. In continuous or planar problems they can be placed anywhere, and in discrete problems a finite set of candidate sites is given.[^1] The same classification appears in the Groningen lecture.[^2]

- The p-median problem opens a chosen number of facilities from a set of candidate sites so as to minimise the total transport cost of serving each demand point from its nearest facility; it is one of the most studied discrete problems.[^1] Reese's bibliography describes it as a graph theory problem originally designed for, and extensively applied to, facility location.[^3]
- The uncapacitated facility location problem, also called the simple plant location problem, drops the fixed number and instead trades the fixed cost of opening facilities against transport cost.[^1] Dinitz states the metric version as opening a set of facilities that minimises the cost of opening them plus the distance from every node to its closest open facility, and notes that this basic version is sometimes just called facility location.[^4]
- The p-centre problem locates facilities to minimise the maximum distance from a demand point to its nearest facility, and covering problems aim to cover demand points, for instance all of them at least cost in the set covering version.[^1]

Both the Groningen slides and the Johns Hopkins notes write the problem as a mathematical program with 0-1 variables for the opening decisions, and the Groningen version adds facility capacities; see [[Integer Programming]] and [[Combinatorial Optimisation]].[^2][^4]

## Scope and distinctions

It is the formal core of [[Supply Chain Network Design]], which also covers other decisions in the same network. [[Centre of Gravity Analysis]] is a simple method for the single-facility continuous case, and the handbook notes that special cases of continuous single-facility problems are well studied and have polynomial time algorithms.[^1] Location is also distinct from facility layout.[^1]

## What the sources do not establish

Evidence here is a handbook chapter, lecture notes and a bibliography record. They do not give a single agreed formulation, and the p-median and uncapacitated variants differ in assumptions. Reese's article was read as an abstract only.[^3]

[^1]: Petropoulos, Laporte and colleagues (section 3.13 by Sibel A. Alumur), arXiv, “Operational Research: Methods and Applications”. https://arxiv.org/pdf/2303.14217
[^2]: Tri M. Tran, University of Groningen, lecture slides hosted by Aalto University, “Session 9: Facility location problems”. https://mycourses.aalto.fi/pluginfile.php/2142267/mod_folder/content/0/Lecture%209%20-%2015.11./LSA%202023%20Session%209%20-%20Facility%20location%20problems.pdf
[^3]: Josh Reese, Networks, 2006 (Trinity University record, abstract only), “Solution Methods for the p-Median Problem: An Annotated Bibliography”. https://digitalcommons.trinity.edu/math_faculty/28
[^4]: Michael Dinitz, Johns Hopkins University, Approximation Algorithms course, lecture 10 notes on metric uncapacitated facility location. https://www.cs.jhu.edu/~mdinitz/classes/ApproxAlgorithms/Spring2021/Lectures/Lecture10/lecture10.pdf

