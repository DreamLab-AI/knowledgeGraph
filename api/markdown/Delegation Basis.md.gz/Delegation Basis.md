
A delegation basis is a chain of delegation evaluations supporting the legitimacy of an action, declared in the Agent Ontology as `DelegationBasis`.[^1] visionGraph places it under [[Provenance]].

An [[Accountability Event]] reaches its delegation basis through the property `delegationChain`. The basis then points outwards through `referencesDelegation`, whose range is `Delegation` in the delegation module (see [[Agent Delegation]]). This two-step structure separates the evaluation from the thing evaluated: the delegation itself is a record of authority passed from one agent to another, while the delegation basis is the accountability module's account of whether that chain supports the action under review.

The ledger module reaches the same delegation record from the other side. `LedgerEvent` has a property `delegation`, described there as the "delegation basis authorizing this event",[^2] whose range is again `Delegation`. A delegation basis is therefore a form of [[Provenance]] about authority, and it is distinct from the [[Responsibility Attribution]] that follows from it.

[^1]: Semantic Agent Communication Community Group, “Accountability Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/accountability.ttl

[^2]: Semantic Agent Communication Community Group, “Ledger Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/ledger.ttl

