Production operations is the part of an organisation that turns resources into goods, together with the decisions about how that work is organised: when production is triggered, how the process is laid out, and which management approach runs it.[^1][^2]

An open operations management text describes operations management as overseeing the process of transforming resources into goods and services, and says a company must convert resources such as materials, labour, money and information into goods or services.[^1] A review of operations and supply chain management says process design concerns the methods used to manufacture products, including the manufacturing strategies employed, the production facilities and the equipment.[^2]

## Scope and distinctions

Three groups of decision sit under this page.

- Order-trigger decisions, covered at [[Production Strategy]], settle how production relates to the customer order. The review names make-to-order, assemble-to-order and make-to-stock among the strategies.[^2]
- System decisions, covered at [[Production System Type]], settle how work flows. Georgia Tech class notes divide plant layouts into five general types according to the number of different products and the number of units of each, which they also call the batch or lot size.[^3] An open textbook classifies process types by variety and volume.[^4]
- Management approach, covered at [[Production Management Philosophy]], concerns the systems used to run production.

This page does not cover transport, warehousing or procurement, which have their own branches of the domain.

## What the sources do not establish

None of the sources opened defines production operations as a single term. The page is bounded by what the operations management texts say about the transformation of resources and about process design. The sources use the terms process type, layout and production system for overlapping ideas, and this corpus keeps them under [[Production System Type]] without claiming that one taxonomy is the standard one.[^3][^4]

In this corpus [[Mass Production]], [[Job Shop Production]] and [[Batch Production]] are filed as system types, and [[Mass Customisation]] as a production strategy; the textbook lists mass customisation among the hybrid process types.[^4]

[^1]: eCampusOntario Pressbooks (Introduction to Canadian Business), “Operations Management”. https://ecampusontario.pressbooks.pub/bus108g/chapter/opsmanagement/
[^2]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^3]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design Class Notes, Chapter 12. Manufacturing Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/Logistics%20Systems%20Design/Full%20Text%20PDF/Manufacturing%20Systems.pdf
[^4]: Business LibreTexts (Introduction to Operations Management, NWTC), “6.3: Process Types”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/06:_Process_Design/6.03:_Process_Types

