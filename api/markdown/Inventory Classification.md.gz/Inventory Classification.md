Inventory classification is the grouping of inventory items so that different levels of control can be applied to different groups.[^1][^2]

The Bazargan open textbook says the aim of the best-known scheme, ABC analysis, is to help managers identify the items that represent the large segment of the inventory costs so that different inventory management techniques can be applied to different segments.[^1] MIT lecture slides begin the question of how to control an item by asking how important the item is and refer to standard ABC analysis.[^2] See [[ABC Analysis]].

## Criteria and number of classes

That textbook says the criterion for categorisation might be delivery time as well as dollar value, and that recent researchers do not necessarily categorise the inventory of a firm into three categories, citing a four-category study of a steel mill.[^1] The MIT slides call the classifications arbitrary.[^2]

## Use in practice

A university inventory policy applies a classification to counting: items are counted by ABC class, with different intervals for each; see [[Cycle Counting]].[^3] Classification also guides how much control effort an item receives; see [[Inventory Control Practice]].[^2]

## Scope and distinctions

Inventory classification is distinct from [[Inventory Type]], which describes stock by its stage or role, such as raw materials or safety stock. Classification groups items by their importance for control, while type describes what the stock is. This corpus keeps the two apart.

## What the sources do not establish

Sources do not give a standard set of criteria or class boundaries. The textbook notes that categories are identified from the viewpoint of higher-level management, and the MIT slides call them arbitrary.[^1][^2]

[^1]: Hamid Bazargan, BCcampus Open Education, November 2021, “Classical Topics in Inventory Control”. https://opentextbc.ca/oerdiscipline/wp-content/uploads/sites/213/2018/09/Classical-Topics-in-Inventory-Control.pdf
[^2]: Chris Caplice, MIT OpenCourseWare ESD.260 Logistics Systems, October 2006, “Inventory Management: Probabilistic Demand”. https://ocw.mit.edu/courses/esd-260j-logistics-systems-fall-2006/8b53c45fd26ffff706d815131e8d177e_lect11.pdf
[^3]: The Ohio State University, “Inventory” (university policy). https://policies.osu.edu/sites/default/files/documents/2024/09/inventory-policy.pdf

