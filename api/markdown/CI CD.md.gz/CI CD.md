CI/CD (continuous integration and continuous delivery/deployment) is the software engineering practice of automatically building, testing and releasing every code change through a versioned pipeline. Continuous integration merges work into a shared trunk many times a day behind automated test gates; continuous delivery keeps the mainline permanently releasable; continuous deployment pushes each passing change to production automatically. Together they shrink feedback loops, reduce integration risk and enable progressive release strategies such as canary and zero-downtime deployments.

### Semantic Classification

### Content

## Definition

**CI/CD** is the automation backbone of modern software delivery, pairing [[Continuous Integration]] with continuous delivery or [[Continuous Deployment]]. CI, articulated by Grady Booch and popularised through Extreme Programming and Martin Fowler's writing, requires developers to merge small changes into a shared mainline frequently — at least daily — with every merge triggering an automated build and test run, so integration conflicts and regressions surface within minutes rather than at release time. Continuous delivery, codified by Jez Humble and David Farley (2010), extends the pipeline through packaging, environment provisioning and acceptance testing so the mainline is always in a deployable state, with release remaining a business decision; continuous deployment removes even that manual gate, shipping every passing change to production.

A pipeline is a directed sequence of stages defined as code alongside the application: compile and unit test, static analysis and dependency scanning, artefact build (typically a [[Container]] image), integration and end-to-end tests against ephemeral environments, then promotion through staging to production. Everything hangs off [[Version Control]] — pipeline definitions, [[Infrastructure as Code]], and the artefact versioning that makes any build reproducible and any release traceable to a commit. Deployment stages implement progressive strategies: [[Canary Deployment]] routes a small traffic slice to the new version and watches error budgets, blue-green switchovers and rolling updates achieve [[Zero Downtime Deployment]], and automated rollback closes the loop.

## Current Landscape

Dominant platforms include GitHub Actions, GitLab CI/CD, Jenkins, CircleCI, Azure DevOps and cloud-native systems such as Tekton and Argo (whose GitOps model continuously reconciles cluster state with a Git repository). DORA's research programme ties CI/CD maturity directly to organisational performance via its four key metrics — deployment frequency, lead time for changes, change failure rate and time to restore — with elite performers deploying on demand, many times a day. Current emphases are supply-chain security (artefact signing with Sigstore, SLSA provenance levels, SBOM generation in-pipeline), merge queues and test-impact analysis to keep feedback fast at monorepo scale, and increasingly AI-assisted test generation and failure triage. The practice is now table stakes: the VisionFlow corpus itself is built and republished by a CI pipeline on every push.

- **DORA 2024 (a decade of the four key metrics)**: The Accelerate State of DevOps 2024 report reframed time-to-restore as a throughput measure and added *rework rate* as a fifth metric feeding stability; it found AI adoption raised individual productivity but, at that point, was associated with an estimated 1.5% drop in delivery throughput and a 7.2% drop in delivery stability, underlining that small batches and robust testing still matter.
- **DORA 2025 (the trade-off shifts)**: With around 90% of respondents now using AI, the 2025 report found — for the first time — AI adoption linked to *higher* throughput, while instability remained elevated; platform quality emerged as the decisive amplifier of AI's benefits, with roughly 90% of organisations now running internal developer platforms.
- **Supply-chain security mainstreamed**: Sigstore signing, SLSA provenance levels and in-pipeline SBOM generation have become standard controls against build-system compromise.
- **Platform engineering** is now a first-class discipline, though DORA cautions that a new internal platform can dip performance before it matures.

  **Sources**:

- https://dora.dev/research/2024/dora-report/
- https://cloud.google.com/blog/products/devops-sre/announcing-the-2024-dora-report
- https://devops.com/dora-2025-faster-but-are-we-any-better/

