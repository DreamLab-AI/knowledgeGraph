Drop shipping is an arrangement in which a retailer takes a customer's order and forwards it to a wholesaler, distributor or manufacturer, which fills the order and ships it directly to the customer, so that the retailer does not hold the product in its own stock.[^1][^2]

Randall, Netessine and Rudi define drop-shipping as an arrangement whereby the retailer forwards customers' orders to the wholesaler, distributor or manufacturer, who fills customer orders directly from its own inventory.[^1] A conference paper from the Technical University of Cluj-Napoca describes it as a retail business model in which a seller creates an online store and receives orders for products available on the store without having them in its own stock. After the order is received, the seller forwards it to the manufacturer, wholesaler or another retailer, which is responsible for delivering the products directly to the customer.[^2]

## Division of work

The Cluj paper cites earlier work for the split of duties: the retailer is responsible for marketing and receiving customer orders, while the supplier keeps the stock and delivers the order to the customer.[^2] The retailer's role is therefore selling and order capture, and the physical handling sits upstream with the supplier.

## Adoption and results

Randall, Netessine and Rudi cite surveys reporting that only between 23 and 33 percent of Internet retailers rely on drop-shipping as their primary method of order fulfilment, and say that anecdotal evidence of retailers using a drop-shipping strategy suggests only mixed success.[^1] They give the example of the drop-shipping retailer Value America, which declared bankruptcy in late 2000, blaming in part its inability to deliver products to customers in a timely manner.[^1]

## Scope and distinctions

Drop shipping is a [[Distribution Strategy]] because it decides where goods are stored and how they reach the customer. It is one way to carry out [[Order Fulfilment]].[^1] Related pages are [[Fulfilment Centre]], [[Distribution Centre]] and [[E-Commerce]].

## What the sources do not establish

Both origins agree on the definition. One is a case study of a single online store, and the survey figures are those reported by the other paper, so the opened sources give no current share of retailers using drop shipping and no evidence on costs that would apply generally.

[^1]: Randall, Netessine and Rudi (author copy hosted by the Wharton School), “An Empirical Examination of the Decision to Invest in Fulfillment Capabilities: A Study of Internet Retailers”. https://faculty.wharton.upenn.edu/wp-content/uploads/2012/04/RandallNetessineRudi.pdf
[^2]: Technical University of Cluj-Napoca (Barcs, Pop, Toader and Ighian), 2022, “Drop-Shipping – A Business Model Without Holding Inventory: A Case Study of Online Store”. https://mpra.ub.uni-muenchen.de/118638/1/MPRA_paper_118638.pdf

