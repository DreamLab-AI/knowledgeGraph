Supply chain strategy is the set of long-lasting choices about how a supply chain is structured and run to meet the demand it faces, including its overall posture, the design of its network of facilities, and how suppliers are chosen and grouped.[^1][^2][^3]

No source opened here defines supply chain strategy as a term. This page is bounded by what the sources say about the decisions involved.

Melo, Nickel and Saldanha da Gama distinguish strategic, tactical and operational planning by time horizon, cite Simchi-Levi and colleagues for the point that strategic decisions have a long-lasting effect on the firm, and place network design at the strategic level, where decisions concern the number, location, capacity and technology of facilities.[^1] Fisher argues that the root cause of many supply chain problems is a mismatch between the type of product and the type of supply chain, which makes the choice of chain type a strategic question.[^2] Lee frames the task as first understanding the uncertainties faced by the demand and supply of a firm's products and then matching them with the right supply chain strategies, and warns that not every strategy suits every firm.[^4]

The NIST Manufacturing Extension Partnership lists procurement and supply chain management strategy as a service area, covering supplier segmentation (different strategies for the most important components and for non-critical maintenance, repair and operations items), supplier evaluation and selection, total cost of ownership and strategic supplier relationships.[^3]

## Scope and distinctions

This branch of the domain has three main parts:

- [[Supply Chain Strategy Type]] covers generic postures such as lean, agile, efficient and responsive.
- [[Supply Chain Network Design]] covers the number, location and role of facilities and the flows between them.
- [[Supply Chain Design Principle]] covers structural rules such as matching the chain to the demand pattern, segmentation by product, and postponing product differentiation.[^2][^5][^6] Fisher's comparison of chain types, for example, includes modular design to postpone product differentiation for as long as possible in the responsive chain.[^2]

Strategic decisions are distinct from tactical and operational planning, which Melo and colleagues separate from them by time horizon.[^1]

## What the sources do not establish

Fisher's and Lee's frameworks are management articles, not standards, and the NIST page describes a programme of advice rather than defining a term. Lee's article was available to this research only as an abstract, so the strategy types it proposes are not described here.[^4][^3]

[^1]: Melo, Nickel and Saldanha da Gama, Fraunhofer ITWM report 130, “Facility Location and Supply Chain Management - A comprehensive review”. https://kluedo.ub.rptu.de/files/1985/bericht130.pdf
[^2]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf
[^3]: NIST Manufacturing Extension Partnership, “Supply Chain Management”. https://www.nist.gov/mep/supply-chain
[^4]: Hau L. Lee, California Management Review, Spring 2002 (abstract page), “Aligning Supply Chain Strategies with Product Uncertainties”. https://cmr.berkeley.edu/2002/05/44-3-aligning-supply-chain-strategies-with-product-uncertainties/
[^5]: Martin Christopher and Denis Towill, International Journal of Physical Distribution and Logistics Management, 2001 (Cranfield repository copy), “An Integrated Model for the Design of Agile Supply Chains”. https://dspace.lib.cranfield.ac.uk/bitstreams/db14daf6-8518-476e-9211-b6af2f1515a5/download
[^6]: Martin Christopher, Industrial Marketing Management, 2000 (Cranfield repository copy), “The Agile Supply Chain : Competing in Volatile Markets”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/3e60f75d-28c1-4659-a260-6608c0e863f2/content

