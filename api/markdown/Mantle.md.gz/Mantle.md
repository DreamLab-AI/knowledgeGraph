Mantle is an Ethereum layer-two network that uses a rollup design to lower transaction costs and increase throughput. It separates data availability from execution.

### Semantic Classification

### Content

- Mantle is a layer-two network for Ethereum that processes transactions off the main chain and posts data so that the results can be verified. Its modular design uses a separate data availability layer to reduce costs.
- The network supports decentralised applications that benefit from lower fees than the Ethereum base layer. It is associated with a token and an on-chain treasury that funds ecosystem development.

### Provenance

