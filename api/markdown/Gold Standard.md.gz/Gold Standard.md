A monetary system in which a currency's value is legally fixed to and redeemable in a defined quantity of gold, constraining the total money supply to the size of gold reserves held by the issuing authority. Under this regime, exchange rates between participating countries are effectively fixed because each currency is independently pegged to gold at a known rate, enabling automatic balance-of-payments adjustment through the price-specie-flow mechanism. The classical gold standard operated broadly from the 1870s until the outbreak of World War I in 1914, was briefly restored in modified forms during the interwar period, and gave way to the Bretton Woods system of dollar-gold convertibility in 1944, which itself ended in 1971 when the United States suspended gold convertibility.

### Overview

- The gold standard emerged as the dominant international monetary arrangement during the nineteenth century, initially in Britain (which had operated a de facto gold standard since 1717 under Isaac Newton as Master of the Mint) and spreading to most major economies after Germany adopted it following the Franco-Prussian War indemnity of 1871.
- Its defining feature is the fixed legal parity between a unit of currency and a specified weight of gold. Because each participating country defines its currency in terms of gold, bilateral exchange rates between those currencies are effectively fixed — a property that greatly facilitated [[International Trade]] and cross-border capital flows during the era of classical globalisation.
- The system imposed automatic discipline on [[Monetary Policy]]: governments and central banks could not expand the [[Money]] supply beyond their gold reserves without risking convertibility crises. This constraint produced long-run [[Price Stability]] but limited the ability of authorities to respond to recessions, bank panics, or external shocks.
- The gold standard is now studied primarily as a historical institution and a reference point for debates about rules-based versus discretionary monetary policy, [[Currency Peg]] regimes, and the design of sound money systems.

### Key Mechanisms

#### Price-Specie-Flow Mechanism

- Articulated by philosopher and economist David Hume in 1752, this is the core automatic adjustment process of the gold standard.
- A country running a [[Balance of Payments]] deficit loses gold to trading partners; its money supply falls; domestic prices decline; exports become cheaper and imports more expensive, restoring equilibrium.
- The symmetry of the mechanism constrained surplus and deficit countries alike, unlike later systems that placed adjustment burdens asymmetrically.

#### Currency Convertibility

- [[Currency Convertibility]] — the legal right of any note-holder to exchange paper currency for the defined gold weight — was the anchor of credibility.
- Suspension of convertibility (as occurred during wartime) typically caused immediate currency depreciation and [[Inflation]].
- Central banks maintained gold reserves sufficient to honour likely conversion demands; the reserve ratio became a key indicator of monetary confidence.

#### Fixed Exchange Rates

- [[Fixed Exchange Rate]] regimes under the gold standard held bilateral rates within narrow "gold points" — the cost of physically shipping gold between financial centres.
- Within those bands, arbitrage by bullion dealers kept rates aligned with gold parities.
- The stability of exchange rates reduced transaction costs and exchange-rate risk for merchants and investors, supporting the first great wave of financial globalisation.

#### Gold Reserve Management

- [[Gold Reserve]] levels determined the ceiling on the domestic money supply.
- Central banks — most notably the Bank of England — developed techniques such as varying the Bank Rate (discount rate) to attract short-term capital flows and defend gold reserves without outright convertibility suspension.
- The asymmetry between gold-rich and gold-poor nations was a persistent structural tension.

### Historical Variants

#### Classical Gold Standard (c. 1870–1914)

- The purest form: currencies directly convertible into gold at fixed parities; international capital flows largely unrestricted; adjustment via the specie-flow mechanism.
- Britain's sterling and the Bank of England functioned as the de facto anchor and lender of last resort for the system.
- World War I disrupted gold flows, prompted belligerent nations to suspend convertibility, and effectively ended the classical era.

#### Gold Exchange Standard (1919–1939)

- Interwar reconstruction efforts (notably the Genoa Conference, 1922) produced a modified system in which countries held reserves partly in sterling or dollars (themselves convertible to gold) rather than gold alone.
- The [[Reserve Currency]] role of sterling declined as Britain's economic position weakened.
- The Great Depression exposed the deflationary rigidity of the system; countries that left gold earlier (Britain 1931, United States 1933 domestically) recovered faster.

#### Bretton Woods System (1944–1971)

- Designed at the [[Bretton Woods System]] conference, this arrangement pegged member currencies to the US dollar, which was convertible to gold for foreign central banks at $35 per troy ounce.
- The International Monetary Fund was created to manage balance-of-payments lending and oversee parities.
- The "Triffin dilemma" — the structural contradiction between the US providing global dollar liquidity and maintaining gold convertibility — ultimately caused the system to collapse when President Nixon suspended dollar-gold convertibility in August 1971 (the "Nixon Shock").

### Applications and Use Cases

#### Historical Monetary Governance

- The gold standard served as the primary framework for international monetary governance among industrialised nations for roughly a century, providing exchange-rate stability and long-run price anchoring.

#### Reference Benchmark in Policy Debate

- The gold standard is invoked in debates about sound money, currency boards, and rules-based [[Monetary Policy]] as a historical example of a credible commitment mechanism.
- Proponents argue it constrained governments from inflationary finance; critics note its deflationary bias and pro-cyclical adjustment dynamics during recessions.

#### Inspiration for Cryptocurrency Design

- [[Cryptocurrency]] systems — most prominently [[Blockchain]]-based Bitcoin — explicitly drew on gold-standard logic: a hard supply cap replaces the gold reserve constraint, and no central authority can expand supply at will.
- The analogy is a bridge between classical monetary economics and decentralised digital finance.

#### Commodity-Backed Currency Proposals

- Some contemporary proposals for monetary reform advocate a return to [[Commodity Money]] or partial gold backing for central bank reserves, drawing on gold-standard precedent.
- The IMF's Special Drawing Rights and proposals for multi-commodity baskets reflect related thinking about anchoring monetary value to real assets.

### Standards and Institutional Context

- No single international treaty formally codified the classical gold standard; it was a de facto regime sustained by national legislation and shared convention. Key reference points:
  - **UK Coinage Act 1816** — formally established gold monometallism in Britain, replacing bimetallism.
  - **Gold Standard Act 1900 (USA)** — placed the United States unambiguously on gold, resolving the bimetallist controversy of the 1890s.
  - **Genoa Conference 1922** — attempted multilateral reconstruction of a gold exchange standard after World War I.
  - **Bretton Woods Agreement 1944** — created the post-war dollar-gold system and established the [[International Monetary Fund]] and [[World Bank]].
  - **Nixon Shock, August 1971** — unilateral US suspension of dollar-gold convertibility, ending the last major gold-linked international monetary arrangement.
- The debate over the gold standard remains active in academic monetary economics, heterodox economics circles, and among advocates of hard-money cryptocurrency systems.

### Advantages and Criticisms

#### Advantages

- Long-run [[Price Stability]]: the gold standard produced low average [[Inflation]] over extended periods relative to twentieth-century fiat regimes.
- Exchange-rate certainty: [[Fixed Exchange Rate]] parities reduced transaction costs for [[International Trade]] and investment.
- Credible commitment: convertibility obligations constrained governments' ability to finance expenditure through monetary expansion.
- Automatic adjustment: the [[Specie Flow Mechanism]] provided a self-correcting balance-of-payments mechanism without requiring active policy co-ordination.

#### Criticisms

- Deflationary bias: gold supply grew slower than economic output in certain periods, creating persistent deflationary pressure that suppressed wages and activity.
- Loss of policy autonomy: [[Central Bank]] independence to stabilise output or employment was severely constrained, contributing to the severity of the Great Depression.
- Asymmetric adjustment: surplus nations faced weaker pressure to adjust than deficit nations, creating persistent imbalances.
- Gold distribution luck: the system was structurally advantaged nations holding large gold reserves, disadvantaging resource-poor economies.
- Pro-cyclicality: in downturns, capital flight drained gold reserves and forced monetary contraction precisely when expansion was needed.

### Provenance

