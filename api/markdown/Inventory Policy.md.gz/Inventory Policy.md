An inventory policy is a rule that decides when to order and how much, so that an inventory system answers the questions of when to place the order to replenish stock and how much to order.[^1]

A review of operations and supply chain management says inventory management should address where to stock the product, when to place the order and how much to order.[^1] MIT lecture slides list the fundamental questions as which items to stock, where, how much to order and when.[^2] Georgia Tech class notes say the typical decisions in traditional inventory systems involve the level of service to be provided, the frequency of or time between replenishments R, the order up to level S and the reorder point s, and that the choice of which are parameters and which are variables has created many different types of inventory control policies.[^4]

## Review type

An open operations text distinguishes two review methods: continuous review, in which the information system checks the level at all times and signals an order at the reorder point, and periodic review, or fixed order interval, in which the level is checked at fixed intervals and an order is placed for the difference to a maximum level.[^3] MIT slides ask whether review should be periodic or continuous as one of the first questions in choosing a control system.[^5] See [[Continuous Review Policy]] and [[Periodic Review Policy]].

## Scope and distinctions

Particular policies are covered at [[Reorder Point Policy]] and [[Base Stock Policy]]. Analytical models that choose their parameters, such as [[Economic Order Quantity]] and [[Newsvendor Model]], are covered separately. An inventory policy is part of [[Inventory Management]].

Notation differs between sources. Caplice defines s as the order point, S as the order-up-to level, R as the review period and Q as the order quantity.[^5]

## What the sources do not establish

No source names the best policy for a given item. Caplice gives rules of thumb by item class but heads them as no hard and fast rules, and the page does not repeat them.[^5]

[^1]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf
[^3]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.2: Inventory Management Models”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.02%3A_Inventory_Management_Models
[^4]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf
[^5]: Chris Caplice, MIT OpenCourseWare ESD.260 Logistics Systems, October 2006, “Inventory Management: Probabilistic Demand”. https://ocw.mit.edu/courses/esd-260j-logistics-systems-fall-2006/8b53c45fd26ffff706d815131e8d177e_lect11.pdf

