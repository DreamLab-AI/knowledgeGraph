Time to recover, abbreviated TTR, is the time a particular node of a supply chain takes to be back at full function after a disruption.[^1]

MIT News describes a model by David Simchi-Levi and colleagues that calculates time-to-recover alongside time-to-survive, TTS, which identifies the maximum duration that the supply chain can match supply with demand after a disruption.[^1] The article says the model focuses on the impact of disruption on the supply chain, rather than the cause of the disruption.[^1] A user of the approach is quoted saying that the company increased inventories where its time-to-recover, because of extended logistics times, exceeded its time-to-survive.[^1]

## Underlying model

The Interfaces paper by Simchi-Levi and colleagues, developed with Ford Motor Company, describes a risk-exposure model that assesses the impact of a disruption originating anywhere in a firm's supply chain.[^2] Its approach defers the need to estimate the probability of any specific disruption until the firm has learned the effect that disruption will have on its operations.[^2] Only the abstract was available, so this page does not report how the paper defines time-to-recover, and the definition above comes from the MIT News account.

## Other uses of recovery time

A 2020 paper in the International Journal of Production Economics proposes a different resilience metric that captures the time and cost of recovery after disruption events, measured as the expected increase in cost during the recovery period.[^3] The White House 100-day review defines a resilient supply chain as one that recovers quickly from an unexpected event, which makes recovery time a natural measure of resilience.[^4]

## Scope and limits

Time to recover is a property of a node in a chain described at [[Supply Chain Resilience]], and it is compared with time-to-survive when planning buffers such as those at [[Supply Chain Redundancy]]. It is used with [[Supply Chain Stress Testing]].

Evidence is thin. The definition rests on a news article about one research group, whose own full text could not be opened, and the other sources use recovery time in different ways. The sources do not say how time to recover is estimated for a given supplier or what typical values are.

[^1]: MIT News, 15 June 2022, “Companies use MIT research to identify and respond to supply chain risks”. https://news.mit.edu/2022/companies-use-mit-research-identify-respond-supply-chain-risks-0615
[^2]: David Simchi-Levi and colleagues, Interfaces, October 2015 (MIT DSpace record, abstract only), “Identifying Risks and Mitigating Disruptions in the Automotive Supply Chain”. https://dspace.mit.edu/entities/publication/d44ef29a-78b6-4ec5-a537-d6e4c4f3f55a
[^3]: International Journal of Production Economics, vol. 230, 2020 (IDEAS/RePEc record, abstract), “Stochastic optimization of disruption-driven supply chain network design with a new resilience metric”. https://ideas.repec.org/a/eee/proeco/v230y2020ics0925527320301407.html
[^4]: The White House, report under Executive Order 14017, June 2021, “Building Resilient Supply Chains, Revitalizing American Manufacturing, and Fostering Broad-Based Growth: 100-Day Reviews under Executive Order 14017”. https://bidenwhitehouse.archives.gov/wp-content/uploads/2021/06/100-day-supply-chain-review-report.pdf

