Newsvendor model is the problem of controlling the inventory of a single item with stochastic demand over a single period, deciding the size of one order before demand is observed.[^1]

Columbia University lecture notes say the problem is known as the newsvendor problem because the prototype is a newsvendor trying to decide how many newspapers to stock before observing demand. The newsvendor faces both overage and underage costs, if he orders too much or too little, and the notes call the problem particularly important for items with significant demand uncertainty and large overage and underage costs.[^1]

## Costs and the optimal order

Those notes define h as the per unit overage cost and b as the per unit underage cost.[^1] They show that the optimal order quantity increases with the underage cost b and decreases with the overage cost h.[^1] The optimum is the smallest order at which the probability that demand does not exceed it reaches a critical ratio fixed by those two costs; this page does not reproduce the critical ratio.

## Scope and distinctions

The Bazargan open textbook calls the single-period model the newsboy problem, or Christmas tree problem, and says it is used for perishable or seasonal items that are ordered once or have a short period of consumption, such as bread, flowers, fruit, vegetables, newspapers and new year cards. It states the objective as finding the level of inventory before the start of the period that maximises profit.[^2] The Columbia notes date the origin of the model to Edgeworth's 1888 paper, which was not opened here.[^1]

A newsvendor problem is a single-period [[Inventory Model]]. The Columbia and Stanford serial system paper uses one newsvendor problem per stage in its heuristic; see [[Multi-Echelon Inventory Optimisation]].

## What the sources do not establish

Those notes give the solution for a known demand distribution and do not discuss estimating it. This corpus notes only the structure of the result.

[^1]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “The Newsvendor Problem”. https://www.columbia.edu/~gmg2/4000/pdf/lect_07.pdf
[^2]: Hamid Bazargan, BCcampus Open Education, November 2021, “Classical Topics in Inventory Control”. https://opentextbc.ca/oerdiscipline/wp-content/uploads/sites/213/2018/09/Classical-Topics-in-Inventory-Control.pdf

