An exponential moving average (EMA) is a weighted moving average that applies exponentially decreasing weights to successive observations in a time series, giving greater significance to recent data than to older data. It is computed recursively as a convex combination of the current observation and the previous EMA value, governed by a smoothing factor derived from a chosen window length. In blockchain and decentralised finance contexts the EMA is widely used to smooth on-chain price feeds, dampen oracle noise, and drive technical-analysis signals and adaptive parameters in automated trading and risk systems.

### Overview

- Unlike a simple moving average, which weights every observation in its window equally, the EMA never fully discards older data; weights decay geometrically rather than dropping to zero at the window edge.
- The smoothing factor alpha = 2 / (N + 1) maps a notional period N to the decay rate, allowing intuitive parameterisation of responsiveness.
- Because the update is recursive, the EMA needs only the previous EMA value and the current observation in memory, making it efficient for streaming and on-chain computation where storage and gas costs matter.
- Lower alpha yields a smoother, slower-responding average; higher alpha tracks recent movement more closely at the cost of more noise passthrough.

### Mechanisms

#### Recursive update rule

- EMA_t = alpha * x_t + (1 - alpha) * EMA_(t-1), seeded from an initial value such as the first observation or a simple average of an initial window.
- The convex-combination form guarantees the output stays within the range spanned by the inputs and the prior state.

#### Decay and effective window

- Weights on past observations follow a geometric series, giving an effective memory roughly proportional to 1/alpha.
- Trade-off between lag and noise suppression is controlled entirely by the smoothing factor.

#### On-chain and oracle smoothing

- Time-weighted and exponentially weighted aggregation reduce the influence of single anomalous ticks, mitigating flash-manipulation of [[Oracle]] prices.
- Recursive form fits gas-constrained smart-contract execution far better than recomputing windowed averages.

### Applications

#### Decentralised finance

- Smoothing price feeds before they drive collateral valuation, liquidation thresholds, and [[Risk Management]] logic.
- Adaptive fee or interest-rate curves responding to exponentially smoothed utilisation.

#### Technical analysis and trading

- Crossover signals between fast and slow EMAs underpin many [[Algorithmic Trading]] strategies and [[Quantitative Finance]] indicators.
- MACD and similar momentum tools are built directly on EMA differences.

#### Signal processing and monitoring

- As a first-order low-pass filter, the EMA underpins [[Signal Processing]] for telemetry, latency monitoring, and anomaly detection in distributed systems.

### Provenance

