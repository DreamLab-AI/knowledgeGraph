His Majesty's Revenue and Customs (HMRC) is the non-ministerial department of the UK government responsible for the administration and collection of taxes, payment of certain state benefits, and enforcement of customs regulations. Formed in 2005 by the merger of the Inland Revenue and HM Customs and Excise, HMRC operates the UK's tax self-assessment regime, Pay As You Earn (PAYE) system, and Making Tax Digital (MTD) programme. It also issues authoritative guidance on the taxation of cryptoassets, financial instruments, and cross-border transactions, making it a central regulatory reference for UK digital finance and compliance obligations.

### Overview

- HMRC is one of the largest government departments in the United Kingdom by headcount and budget, and one of the largest operators of enterprise [[Digital Infrastructure]] in the UK public sector. Its mandate spans revenue collection, customs administration, and the enforcement of compliance with UK [[Tax Law]].
- The department collects direct taxes (income tax, capital gains tax, corporation tax), indirect taxes ([[VAT]], excise duties, stamp duties), and social contributions ([[National Insurance Contributions]]). It also administers the [[Making Tax Digital]] programme, which is progressively mandating digital [[Financial Reporting]] for businesses and sole traders.
- HMRC's guidance is legally significant: policy briefs, manuals, and technical bulletins published by HMRC constitute interpretations of statute that taxpayers, accountants, and legal advisers rely on for [[Corporate Tax Compliance Framework]] decisions.

### Key Components

#### Pay As You Earn (PAYE)

- [[Pay As You Earn]] is the UK's primary mechanism for withholding [[Income Tax]] and [[National Insurance Contributions]] at source via employers. HMRC maintains the Real Time Information (RTI) system, requiring employers to submit payroll data each pay cycle.

#### Self Assessment

- [[Self Assessment]] is the annual tax return process used by the self-employed, higher-rate taxpayers, and those with complex financial affairs. It is the main compliance channel for [[Capital Gains Tax]] and certain dividend and rental income declarations.

#### Making Tax Digital (MTD)

- [[Making Tax Digital]] is HMRC's flagship digitalisation programme, requiring businesses to maintain digital records and submit tax data via compatible software. MTD for [[VAT Administration]] was mandated from 2019; MTD for [[Income Tax]] (MTD ITSA) is being phased in.

#### Customs and Border Policy

- Post-Brexit, HMRC administers the UK Global Tariff, customs declarations, and [[Import Duty]] for goods crossing the UK border. It works alongside the [[Border Force]] and [[UK Border Agency]] to enforce customs law.

#### Cryptoasset Guidance

- HMRC has published specific guidance on the tax treatment of [[Cryptocurrency]] and other [[Cryptoasset Taxation]] including tokens, stablecoins, and NFTs. These guidance documents define which assets qualify as [[Capital Asset]] and how staking, mining, airdrops, and DeFi returns are taxed. This positions HMRC as a key reference for [[Blockchain]] sector compliance in the UK.

#### Anti-Money Laundering Supervision

- HMRC is a statutory [[Anti-Money Laundering]] supervisor for certain sectors (estate agencies, accountants, high-value dealers), operating under the Money Laundering Regulations. It conducts [[AML Compliance]] inspections and can issue civil penalties and criminal prosecutions.

### Applications and Use Cases

- **Digital Tax Filing**: Businesses and individuals use HMRC's online portals (Government Gateway, HMRC App) for digital self-assessment and VAT returns, integrating with [[Open Banking]] data feeds under MTD.
- **Crypto and DeFi Taxation**: UK holders of [[Cryptocurrency]] and participants in [[Decentralised Finance]] reference HMRC's cryptoasset manual to determine CGT and income tax obligations on trades, yields, and token receipts.
- **Corporate Compliance**: Large corporations use HMRC's published transfer pricing and permanent establishment guidance to manage international [[Corporate Tax Compliance Framework]] obligations, cross-referencing with [[OECD Tax Framework]] and BEPS rules.
- **Employment and Payroll**: HR and payroll systems integrate with HMRC's RTI APIs to comply with [[Pay As You Earn]] obligations, submit statutory sick pay, and claim employment allowances.
- **Customs Declarations**: Importers and exporters submit declarations through HMRC's Customs Declaration Service (CDS), replacing the legacy CHIEF system, a significant [[Digital Infrastructure]] migration.
- **Research and Statistics**: HMRC publishes detailed tax gap analysis and fiscal statistics, used by economists, policy researchers, and public finance bodies studying [[Public Sector]] economics.
- **International Exchange**: HMRC participates in the OECD Common Reporting Standard (CRS) and FATCA (US [[Foreign Account Tax Compliance]]), exchanging financial account information with partner jurisdictions to combat [[Tax Evasion]].

### Standards and Regulatory Context

- **OECD BEPS**: HMRC implements OECD Base Erosion and Profit Shifting (BEPS) measures, including country-by-country reporting and controlled foreign company rules, aligning UK practice with international [[OECD Tax Framework]] standards.
- **Common Reporting Standard (CRS)**: Under CRS, HMRC exchanges financial account data annually with over 100 jurisdictions, requiring UK financial institutions to carry out due diligence and report to HMRC.
- **FATCA**: The UK-US [[Foreign Account Tax Compliance]] intergovernmental agreement requires HMRC to transmit data on US persons holding UK accounts to the IRS, and vice versa.
- **Money Laundering Regulations (MLR)**: HMRC supervises designated non-financial businesses under UK MLR, a transposition of the EU's Anti-Money Laundering Directives adapted post-Brexit to UK statute.
- **UK GDPR / Data Protection Act 2018**: HMRC is a major controller of personal financial data and must comply with UK GDPR obligations, including for the transfer of taxpayer data under CRS/FATCA arrangements — intersecting with [[Data Governance]] requirements.
- **Making Tax Digital Standards**: MTD mandates use of software with HMRC-compatible APIs; HMRC publishes developer-facing API standards and sandbox environments, engaging the [[Digital Infrastructure]] and fintech community.
- **Customs Declaration Service (CDS)**: CDS replaced the CHIEF system for customs declarations, implementing the Union Customs Code-derived UK Customs Regime post-Brexit and integrating with the UK Global Tariff.

### Semantic Classification

### Provenance

