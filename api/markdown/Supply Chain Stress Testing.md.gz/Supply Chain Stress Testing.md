Supply chain stress testing is the use of a model of a supply network to apply a hypothetical shock and observe how the network responds.[^1]

A 2025 preprint by Smith and colleagues says that in this setting a stress test applies a hypothetical shock to a modeled system and measures how its components respond.[^1] It describes forward stress testing, in which threats and predicted impacts are evaluated to harden the system against the most damaging scenarios, and develops reverse stress testing, which predicts which changes across the network are most likely to cause a specified level of disruption at a specific entity.[^1] The preprint has not been peer reviewed.

## Applications

The European Commission's Single Market Economics paper by Dumont and Varela-Irimia aims to develop a proof of concept for testing the resilience of sectoral supply chain networks at firm level against an exogenous shock to critical inputs.[^2] Only the publication description was opened.

The European Central Bank reports a firm-level stress test in which sudden disruptions in the supply of critical inputs from high-risk countries would lead to significant, though very uneven, economic losses across firms, regions and sectors.[^3] The ECB also finds that critical foreign dependencies persist even though European firms are reorganising their supply chains.[^3]

## Related methods

Simchi-Levi and colleagues' risk-exposure model assesses the impact of a disruption originating anywhere in a firm's supply chain and defers probability estimates until after the effect is known.[^4] The abstract does not call it a stress test, but it shares the feature of choosing the shock first and measuring the consequence. See [[Time to Recover]].

## Scope and limits

Stress testing is a way of examining exposure as part of [[Supply Chain Risk Management]], and it uses the maps described at [[Multi-Tier Supply Chain Mapping]]. It is distinct from a bank stress test, although the ECB example is a central bank exercise on firms.

No opened source gives a standard method, a set of agreed scenarios or pass and fail thresholds for supply chain stress tests. The sources are a preprint, a description page and one central bank paper, so the technique is described as proposed and applied, not as an established standard.

[^1]: Madison Smith, Michael Gaiewski, Sam Dulin, Laurel Williams, Jeffrey Keisler, Andrew Jin and Igor Linkov, arXiv preprint 2511.07289 (not peer reviewed), “Reverse Stress Testing for Supply Chain Resilience”. https://arxiv.org/pdf/2511.07289
[^2]: European Commission, Single Market Economics Papers (Béatrice Dumont and Xosé-Luís Varela-Irimia), 5 September 2024 (publication page, description only), “Supply chain stress tests for critical inputs: a proof-of-concept”. https://single-market-economy.ec.europa.eu/publications/supply-chain-stress-tests-critical-inputs-proof-concept_en
[^3]: European Central Bank, Occasional Paper Series, “Navigating a fragmenting global trading system: insights for central banks (No 365)”. https://ecb.europa.eu/pub/pdf/scpops/ecb.op365~362d801aee.es.pdf
[^4]: David Simchi-Levi and colleagues, Interfaces, October 2015 (MIT DSpace record, abstract only), “Identifying Risks and Mitigating Disruptions in the Automotive Supply Chain”. https://dspace.mit.edu/entities/publication/d44ef29a-78b6-4ec5-a537-d6e4c4f3f55a

