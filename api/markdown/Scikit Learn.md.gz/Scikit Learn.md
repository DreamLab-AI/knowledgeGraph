Scikit-learn is an open-source Python library providing a unified, consistent API for classical machine learning algorithms covering classification, regression, clustering, dimensionality reduction and model selection. Built on NumPy and SciPy, it emphasises clean estimator interfaces, reproducible pipelines and rigorous evaluation tooling rather than deep learning. It is one of the most widely used libraries for non-neural machine learning, data science education and rapid prototyping.

### Overview

- Scikit-learn made classical machine learning broadly accessible through a single, predictable fit/predict/transform interface that composes algorithms into pipelines. It bundles preprocessing, model families, cross-validation and metrics so practitioners can move from raw data to evaluated models quickly. While it deliberately excludes GPU-accelerated deep learning, it remains the default tool for tabular and small-to-medium datasets.

### Key aspects

- Estimator API: a consistent fit/predict/transform contract across all algorithms.
- Pipelines: chaining preprocessing and modelling steps into a single reproducible object.
- Model selection: cross-validation, grid and randomised search for hyperparameter tuning.
- Algorithm coverage: linear models, support vector machines, trees, ensembles, clustering and decomposition.
- Evaluation: a comprehensive metrics module for classification, regression and clustering quality.

### Applications

- Building classifiers and regressors on tabular and structured data.
- Feature engineering and preprocessing pipelines feeding downstream models.
- Teaching machine learning fundamentals with reproducible examples.
- Rapid prototyping and baselining before investing in deep learning.

### Provenance

