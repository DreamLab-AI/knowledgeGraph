A leaderboard is a public, continuously updated ranking of systems or models against a shared benchmark dataset and fixed evaluation protocol, typically reporting standardised metrics on held-out test sets. Leaderboards make model comparison transparent and reproducible, drive competitive progress in machine learning and adjacent fields, and increasingly incorporate human preference voting — whilst also inviting over-fitting, benchmark gaming and metric myopia when rankings are treated as ends in themselves.

### Semantic Classification

### Content

## Definition

A **leaderboard** is the public face of [[Benchmark Evaluation]]: an ordered table of submissions ranked by score on a common task, with the [[Benchmark Dataset]], metrics and submission rules fixed so that entries are directly comparable. The format descends from competition science — Netflix Prize (2006), Kaggle competitions, and academic shared tasks — and was institutionalised for machine learning research by benchmarks such as ImageNet/ILSVRC, SQuAD, GLUE and SuperGLUE, whose leaderboards charted (and arguably accelerated) the field's progress from feature engineering to pre-trained transformers.

A well-run leaderboard enforces evaluation hygiene: hidden or rotated test sets to prevent training on the answers, limited submission frequency to deter test-set probing, standardised harnesses so scores are computed identically for every entrant, and provenance metadata (model size, training data, compute) so rankings can be read in context. It converts scattered claims in papers into a single, auditable record of the state of the art, and gives newcomers an unambiguous target — the essence of the [[Model Comparison]] it exists to enable.

Leaderboards also distort. Goodhart's law applies with full force: models over-fit benchmark idiosyncrasies, ensembles and prompt tricks chase decimal points that do not transfer, test-set contamination in web-scale training corpora silently inflates scores, and "SOTA-chasing" narrows research agendas. Mature practice therefore treats a leaderboard position as one signal within broader [[Model Evaluation]], not a verdict.

## Current Landscape

In the LLM era leaderboards have multiplied and diversified. Static-benchmark boards (Hugging Face Open LLM Leaderboard, HELM) aggregate suites such as MMLU, GSM8K and BIG-bench; preference-based boards, most prominently LMSYS Chatbot Arena, rank models by Elo ratings computed from millions of blind pairwise human votes, sidestepping test-set contamination at the price of popularity effects and prompt-distribution bias. Domain boards cover code (SWE-bench, LiveCodeBench), agents, safety and multilingual ability. The current frontier concerns trust: contamination detection, private held-out evaluations, statistical significance of rank differences, and disclosure standards — a recognition that leaderboards now shape procurement and investment decisions, not merely academic bragging rights.

Recent specifics:

- **Chatbot Arena is now "LMArena"**: the crowdsourced platform run by the Large Model Systems Organization was rebranded to LMArena and, by 2026, aggregates on the order of 6M+ blind pairwise user votes to compute Elo / Bradley–Terry ratings.
- **Composite indices**: contemporary boards pair the human-vote Arena score with aggregate benchmark indices (e.g. the Artificial Analysis Intelligence Index combining ~10 hard evaluations) and separate coding, vision and reasoning sub-leaderboards, encouraging triangulation rather than single-number ranking.
- **Statistical rigour**: leading boards now publish 95% confidence intervals, so top models frequently fall within a statistical tie — reinforcing the mature practice of reading rank position as one signal within broader [[Model Evaluation]].
- **Triangulation norm**: practitioners routinely cross-check Arena position against held-out coding benchmarks (SWE-bench Verified), MMLU-Pro and MATH to guard against contamination and popularity bias.

  **Sources**:

- https://openlm.ai/chatbot-arena/

