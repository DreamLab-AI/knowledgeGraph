Cross-domain authentication is the capability for a principal authenticated in one security or administrative domain to prove its identity to services in another domain without re-enrolling separate credentials. It relies on federated trust relationships and standard token exchanges so that an identity provider in one realm is accepted by relying parties in another. This underpins single sign-on across organisations and is essential to federated and distributed systems.

### Overview

- A principal trusted in its home realm is accepted across a federation via brokered trust.
- Token formats such as SAML assertions and OAuth/OIDC tokens carry the asserted identity across boundaries.
- Cross-realm Kerberos and trust anchors provide the chain of trust between administrative domains.

### Key aspects

- Establishing trust relationships and trust anchors between domains.
- Token issuance, validation and audience restriction across realms.
- Attribute and claim mapping between heterogeneous identity stores.
- Revocation, session lifetime and replay protection across boundaries.

### Applications

- Enterprise SSO across partner organisations.
- Cloud federation and B2B integrations.
- Cross-realm access in distributed and grid systems.

### Provenance

