A NoSQL database is a class of data store that departs from the rigid tabular schema and relational model of traditional SQL systems to favour flexible schemas, horizontal scalability, and high write throughput. NoSQL systems are typically organised by data model — document, key-value, wide-column, or graph — and often relax strong consistency in exchange for availability and partition tolerance. They are designed for large-scale, distributed workloads where the relational model is a poor fit.

### Overview

- NoSQL emerged to meet the scale and flexibility demands of web-scale applications that relational databases struggled to serve economically. Rather than normalising data across joined tables, NoSQL stores model data the way applications consume it — as documents, key-value pairs, column families, or graph structures. Many NoSQL systems partition and replicate data across many nodes, accepting the trade-offs articulated by the CAP theorem: under network partitions they typically choose availability and converge on eventual consistency rather than guaranteeing strong consistency.

### Key aspects

- Flexible schema: records may have differing fields, allowing rapid iteration without migrations.
- Horizontal scalability: data is sharded across commodity nodes to scale capacity and throughput linearly.
- Data-model specialisation: document, key-value, wide-column, and graph models each optimise distinct access patterns.
- Tunable consistency: many systems let operators trade consistency for availability and latency per operation.
- Denormalisation: data is duplicated and pre-joined to serve reads without expensive joins.

### Applications

- Session and cache stores using key-value engines.
- Content and catalogue management using document stores.
- Real-time analytics and IoT ingestion using time-series and wide-column stores.
- Relationship-heavy queries such as social or fraud graphs using graph databases.

### Provenance

