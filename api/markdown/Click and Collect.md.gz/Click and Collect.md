Click and collect is a retail service in which a customer buys online and collects the order from a store; the academic papers opened for this page call it buy online and pick up in store, abbreviated BOPS or BOPIS.[^1][^2][^3]

Gao and Su, in a Management Science paper, say that many retailers have recently started to offer customers the option to buy online and pick up in store.[^1] Bielozorov says that, along with home delivery, many companies also offer the option, and builds a taxonomy of the essential components of the BOPIS service from the omnichannel retail and channel integration literature.[^2] Kusuda sets out the customer's three choices once the option exists: buy directly online, buy from the retailer using BOPS, or go directly to a store without using BOPS.[^3]

## Effects on the retailer

In the Gao and Su model the BOPS option affects customer choice in two ways, by providing real-time information about inventory availability and by reducing the hassle cost of shopping.[^1] Their findings are that not all products are well suited for in-store pickup, since it may not be profitable to implement BOPS on products that sell well in stores. BOPS enables retailers to reach new customers, but for existing customers the shift from online fulfilment to store fulfilment may decrease profit margins when the latter is less cost effective.[^1] These are results of a stylised model reported in an abstract, not measured outcomes.

## Collection points other than stores

A review of alternative delivery points lists click-and-collect points among the types in the literature, together with local post offices, collection and delivery points, pick-up points such as a nearby facility like a store or library, and smart parcel lockers.[^4] Lockers are covered at [[Parcel Locker]].

## Scope and distinctions

Click and Collect is a form of [[Omnichannel Fulfilment]] and sits within [[Order Fulfilment]] and [[E-Commerce]]. Related pages are [[Last-Mile Delivery]] and [[Parcel Carrier]].

## What the sources do not establish

Papers opened here use BOPS or BOPIS as their main term and the Melbourne review uses click-and-collect for a type of collection point. The opened sources do not say which regions prefer which name, and they give no usage figures.

[^1]: University of Pennsylvania ScholarlyCommons (Gao and Su), Management Science, 2017, “Omnichannel Retail Operations with Buy-Online-and-Pick-up-in-Store” (abstract record). https://repository.upenn.edu/fnce_papers/126
[^2]: Maynooth University (Bielozorov), 2020, “Towards a Taxonomy for Buy Online Pick up in Store Service”. https://www.scitepress.org/Papers/2020/102142/102142.pdf
[^3]: arXiv (Kusuda), “Buy-Online-and-Pick-up-in-Store in Omnichannel Retailing”. https://arxiv.org/pdf/1909.00822
[^4]: University of Melbourne (Mohri and colleagues), Transportation Research Part E 192, 2024, “Contextualizing alternative delivery points in last mile delivery”. https://minerva-access.unimelb.edu.au/rest/bitstreams/a4100875-4af3-46bd-9e31-5638559a10e4/retrieve

