Cold chain logistics is the logistics of keeping a product within a specified low-temperature range from harvest or production to consumption, using a series of actions and equipment.[^1]

The International Institute of Refrigeration (IIR) and ASHRAE agreed that definition of the cold chain, and an IIR page dated 18 March 2019 says the IIR's Science and Technology Council officially endorsed it on 8 February.[^1] A glossary entry from the United Nations ESCWA, sourced to FAO/ESCWA, defines the cold chain more briefly as cold temperature maintenance of perishable products from manufacture to utilisation.[^2] The two definitions agree on continuity from origin to use and differ in detail: the IIR text speaks of actions and equipment and a specified range, while the ESCWA entry speaks of perishable products.[^1][^2]

## In medicines distribution

The World Health Organization's good distribution practices say that appropriate environmental conditions are maintained, for example by using a cold chain for thermolabile products, and that storage conditions for pharmaceutical products should be maintained within acceptable limits during transportation.[^3] The European Union's 2013 guidelines on good distribution practice for medicinal products say an initial temperature mapping exercise should be carried out on the storage area before use. They make the supplying wholesale distributor responsible for ensuring that temperature conditions are maintained within acceptable limits during transport, and require equipment that monitors temperature in vehicles and containers to be maintained and calibrated at least once a year.[^4]

## Where the cold chain is limited

A review of operations and supply chain management notes that humanitarian operations often take place in settings with limited access to power, poor transport links and a limited cold chain.[^5]

## Scope and distinctions

Cold Chain Logistics is a form of [[Sector Logistics]]. Related pages are [[Reefer Container]], [[IATA Temperature Control Regulations]], [[Pharmaceutical Logistics]], [[Cold Chain Monitoring]] and [[Food Supply Chain]].

## What the sources do not establish

Definitions opened here say a specified low-temperature range but give no values, and the WHO and EU texts opened here speak of acceptable limits without stating any. The opened sources give no figures for the size of the cold chain or for losses from breaks in it.

[^1]: International Institute of Refrigeration, “The IIR and the ASHRAE establish new definitions of five keywords in the refrigeration sector”. https://iifiir.org/en/news/the-iir-and-the-ashrae-establish-new-definitions-of-five-keywords-in-the-refrigeration-sector
[^2]: United Nations Economic and Social Commission for Western Asia, glossary entry “cold chain” (source FAO/ESCWA). https://archive.unescwa.org/cold-chain
[^3]: World Health Organization, WHO Technical Report Series No. 957, 2010, Annex 5, “WHO good distribution practices for pharmaceutical products”. https://www.who.int/docs/default-source/medicines/norms-and-standards/guidelines/distribution/trs957-annex5-who-good-distribution-practices-for-pharmaceutical-products.pdf
[^4]: European Union, Official Journal C 343/1, 2013, “Guidelines of 5 November 2013 on Good Distribution Practice of medicinal products for human use”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:52013XC1123(01)
[^5]: arXiv (Petropoulos and colleagues), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

