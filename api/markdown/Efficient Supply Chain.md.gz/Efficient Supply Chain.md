In Fisher's framework an efficient supply chain, which he calls a physically efficient chain, is one designed to supply predictable demand efficiently at the lowest possible cost, and it is the chain he matches to functional products.[^1][^2]

Fisher describes functional products as the staples that satisfy basic needs which do not change much over time, so they have stable, predictable demand and long life cycles. That stability invites competition, which often leads to low profit margins.[^1] Because demand is predictable, market mediation is easy and companies can focus almost entirely on minimising physical costs, which Fisher lists as the costs of production, transportation and inventory storage.[^1]

His comparison table characterises the physically efficient process as one that maintains a high average utilisation rate, generates high inventory turns while minimising inventory throughout the chain, shortens lead time as long as that does not increase cost, selects suppliers primarily for cost and quality, and designs products to maximise performance and minimise cost.[^1]

Mahdavi, Mahmoudzadeh and Olsen describe building efficient supply chains for functional products as half of Fisher's widely discussed guideline, the other half being responsive chains for “innovative products”.[^2]

## Scope and distinctions

Fisher's emphasis is on matching. He argues that the root cause of many supply chain problems is a mismatch between the type of product and the type of chain, and that the case for investing in responsiveness is weak for functional products.[^1] The contrasting type is the [[Responsive Supply Chain]].

An efficient chain resembles a lean one, but the sources do not equate them. Christopher and Towill say lean concepts work well where demand is relatively stable and predictable and variety is low, and that cost is the market winner for lean supply, which is close to Fisher's description of the efficient chain.[^3][^1] Fisher does pair the words once, calling a lean, efficient distribution channel exactly right for functional cars, but he does not define lean.[^1] No source opened here states that the two are the same concept. See [[Lean Supply Chain]] and [[Supply Chain Strategy Type]].

## What the sources do not establish

No opened source says how many products are in fact functional or how often a chain is efficient in practice. Fisher's article was read as a reprint hosted on a university course site, because the publisher's page showed no article text.

[^1]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf
[^2]: Mojtaba Mahdavi, Mahdi Mahmoudzadeh and Tava Lennon Olsen, International Journal of Production Economics, vol. 255 (IDEAS/RePEc record, abstract only), “Efficient vs. Responsive supplier selection for functional and innovative products: A quantitative study”. https://ideas.repec.org/a/eee/proeco/v255y2023ics0925527322002389.html
[^3]: Martin Christopher and Denis Towill, International Journal of Physical Distribution and Logistics Management, 2001 (Cranfield repository copy), “An Integrated Model for the Design of Agile Supply Chains”. https://dspace.lib.cranfield.ac.uk/bitstreams/db14daf6-8518-476e-9211-b6af2f1515a5/download

