A virtual economy is a system of economic activity that takes place within a simulated or digital environment, encompassing the production, exchange, and consumption of virtual goods, services, and currencies. These economies exhibit emergent market dynamics — including supply-demand equilibria, price discovery, and capital accumulation — that parallel real-world economic phenomena while remaining governed by platform rules rather than national jurisdictions. Virtual economies range from closed in-game markets with proprietary currencies to open metaverse ecosystems where blockchain-backed assets and decentralised finance protocols enable interoperable, user-owned value. Their study bridges game theory, monetary economics, and digital rights, making them a critical lens through which to understand the financialisation of participatory digital spaces.

### Overview

- Virtual economies first emerged within massively multiplayer online games (MMOs) such as *EverQuest*, *Ultima Online*, and *World of Warcraft*, where players spontaneously developed markets for in-game items with real exchange-rate implications.
- The concept expanded dramatically with the advent of [[Blockchain]] in 2009 and the subsequent tokenisation of digital assets, allowing truly player-owned goods that persist outside any single platform.
- Today, virtual economies underpin a diverse set of platforms:
  - Open [[Metaverse]] worlds (Decentraland, The Sandbox) where land parcels and wearables trade on secondary markets
  - [[Play-to-Earn]] ecosystems (Axie Infinity, StepN) that generate income for participants in emerging markets
  - Creator platforms (Roblox, Fortnite) with proprietary closed-loop currencies
  - Decentralised exchanges and NFT marketplaces operating as fully on-chain [[Digital Marketplace]]s
- The economic significance of virtual economies is recognised by regulators, tax authorities, and central banks, who must now account for taxable events arising from asset trades conducted entirely within synthetic spaces.

### Key Components

#### Currencies and Tokens

- [[Virtual Currency]]: the medium of exchange within a platform; may be fully custodied by the platform (Robux, V-Bucks) or decentralised ([[Blockchain]]-issued ERC-20 tokens).
- [[Non-Fungible Token]] (NFT): a cryptographic certificate of unique [[Digital Ownership]], representing art, land, game items, or identity artefacts.
- Stablecoins: price-stable tokens pegged to fiat benchmarks used to reduce volatility in [[Decentralised Finance]] transactions within virtual spaces.

#### Market Mechanisms

- [[Auction Mechanism]]s: English auctions, Dutch auctions, and sealed-bid formats used for NFT drops and land sales.
- Automated Market Makers (AMMs): [[Smart Contract]]-governed liquidity pools that enable permissionless asset swaps without a central order book.
- [[Tokenomics]]: the economic design governing token supply curves, emission schedules, staking rewards, and burn mechanisms that underpin price stability.

#### Governance Structures

- [[Decentralised Autonomous Organisation]] (DAO): a token-holder governance body that controls protocol upgrades, treasury allocation, and policy decisions within open virtual economies.
- Platform operators: centralised entities (studios, publishers) that manage closed virtual economies with full discretion over monetary policy.

#### Infrastructure

- [[Blockchain]]: the immutable ledger that records ownership transfers and enforces [[Smart Contract]] logic without trusted intermediaries.
- [[Distributed Ledger Technology]]: the broader category of consensus-based ledgers underpinning both permissioned and permissionless virtual economy backends.
- [[Interoperability]] protocols: cross-chain bridges and open metadata standards (e.g., ERC-721, ERC-1155) that allow assets to travel between virtual worlds.
- [[Identity and Access Management]]: wallet-based self-sovereign identity systems that authenticate users without centralised credentials.

### Applications / Use Cases

#### Gaming and Entertainment

- **Play-to-Earn**: players in economies like Axie Infinity earn tradeable tokens as rewards for gameplay, creating income streams especially in lower-income regions; governed via [[Play-to-Earn]] mechanics and DAO treasuries.
- **In-Game Item Markets**: skins, weapons, and cosmetics in games such as Counter-Strike and Team Fortress 2 have long commanded real monetary value, now increasingly anchored on-chain via [[Non-Fungible Token]]s.

#### Metaverse Commerce

- Virtual real estate in platforms such as Decentraland and The Sandbox is bought, developed, and leased, creating rental income streams analogous to physical property markets (see [[Metaverse Commerce]]).
- [[User-Generated Content]] creators monetise digital goods — fashion, architecture, interactive experiences — directly within virtual storefronts.

#### Decentralised Finance Integration

- [[Decentralised Finance]] protocols embedded within virtual worlds allow participants to lend, borrow, and yield-farm using in-world tokens, blurring the line between entertainment and financial markets.
- Cross-platform liquidity bridges allow capital earned in one virtual economy to be deployed in another, or cashed out to fiat via decentralised exchanges.

#### Research and Policy Simulation

- Virtual economies serve as real-world laboratories for economists testing monetary policy hypotheses, because [[Agent-Based Modelling]] can be validated against observed player behaviour at scale.
- Central bank digital currency (CBDC) pilots increasingly draw on lessons from virtual economy design to model adoption and circulation dynamics.

#### Digital Twins and Enterprise

- Enterprise [[Digital Twin]] platforms integrate virtual economy mechanics to model supply-chain incentives, resource allocation, and collaborative production within simulated factory or logistics environments.
- [[Spatial Computing]] applications in architecture and urban planning use virtual land markets to signal demand before physical construction.

### Standards & Context

- **ERC-20** — Ethereum token standard for fungible virtual currencies; the de facto baseline for on-chain monetary policy within open virtual economies.
- **ERC-721 / ERC-1155** — Ethereum standards for non-fungible and semi-fungible tokens respectively; underpin NFT ownership and composability across virtual worlds.
- **W3C Decentralised Identifiers (DID)** — provides a self-sovereign identity layer enabling portable wallet-based user identity across virtual economy platforms without central authentication.
- **Open Metaverse Interoperability (OMI) Group** — industry working group standardising avatar and asset portability, directly enabling cross-platform virtual economy flows.
- **FATF Virtual Assets Guidance** — the Financial Action Task Force's anti-money-laundering framework applied to virtual asset service providers, shaping compliance obligations for virtual economy operators.
- **IRS Notice 2014-21 / HMRC Cryptoassets Manual** — regulatory precedents establishing that virtual economy gains constitute taxable income in the United States and United Kingdom respectively.
- Regulators in the EU (MiCA), Singapore (MAS), and Japan (FSA) have enacted or proposed frameworks that directly affect how virtual economies may operate commercially, with particular attention to stablecoin issuers and [[Decentralised Finance]] integrations.
- Academic study draws on disciplines including [[Game Theory]], computational economics, and monetary theory; foundational work by Edward Castronova on EverQuest GDP estimates (2001) established the field.

### Provenance

