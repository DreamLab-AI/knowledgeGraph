Intermodal transport is the multimodal transport of goods in one and the same intermodal transport unit by successive modes of transport, without handling of the goods themselves when changing modes.[^1]

The Glossary for transport statistics defines multimodal freight transport as the transport of goods by at least two different modes, and says intermodal transport is a particular type of multimodal transport.[^1] It adds that the intermodal transport unit can be a container, swap body or a loaded vehicle travelling on another vehicle.[^1] Eurostat describes a container as a special box designed to carry freight and constituting a type of intermodal transport unit.[^2]

## Forms

Glossary entries define piggyback transport as the transport of road vehicles by rail, and unitised transport as the carriage of cargo in intermodal transport units such as containers or mobile roll-on roll-off units.[^1] In UK statistics an inter-modal road freight journey is a heavy goods vehicle journey where a different mode is used to transfer goods to or from the vehicle, and such journeys were 8% of goods lifted by domestic road freight in 2024.[^3]

## Standardisation and safety

Harvard Business School's account of Malcolm McLean says the move toward greater standardisation helped broaden the possibilities for intermodal transportation.[^4] The International Maritime Organization says the Convention for Safe Containers aims to facilitate the international transport of containers by uniform safety regulations equally applicable to all modes of surface transport.[^5]

## Scope and distinctions

Intermodal Transport is part of [[Freight Transportation]]. Related pages are [[Shipping Container]], [[Freight Containerisation]], [[Rail Freight]] and [[Road Freight]]. The ontology links it to [[Integer Programming]].

## What the sources do not establish

Sources opened here give no share of all freight that moves intermodally. The UK figure covers road journeys only, and the sources do not compare door-to-door cost with single-mode movement.

[^1]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^2]: Eurostat, Statistics Explained, “Glossary:Freight container”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Freight_container
[^3]: UK Department for Transport (GOV.UK), “Transport Statistics Great Britain: 2024 Freight”. https://www.gov.uk/government/statistics/transport-statistics-great-britain-2025/transport-statistics-great-britain-2024-freight
[^4]: Harvard Business School, Working Knowledge (Mayo and Nohria), “The Truck Driver Who Reinvented Shipping”, 2005. https://www.library.hbs.edu/working-knowledge/the-truck-driver-who-reinvented-shipping
[^5]: International Maritime Organization, “International Convention for Safe Containers (CSC)”. https://www.imo.org/en/about/Conventions/Pages/International-Convention-for-Safe-Containers-(CSC).aspx

