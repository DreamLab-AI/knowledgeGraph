Hardware Abstraction is the software engineering principle and architectural practice of interposing a uniform programmatic interface layer between high-level software and the physical characteristics of underlying hardware components, enabling software to operate independently of specific hardware implementations. The abstraction layer translates generic API calls into vendor-specific or device-specific commands, shielding operating systems, runtimes, and applications from the diversity of processor architectures, memory subsystems, I/O controllers, graphics units, and peripheral devices. This principle underpins portability, vendor independence, and long-term maintainability of system software stacks across the full spectrum of computing platforms, from embedded microcontrollers to cloud server farms to spatial-computing headsets. Hardware Abstraction Layers (HALs) are the canonical realisation of this principle in operating systems, device driver frameworks, and graphics APIs.

### Overview

- Hardware Abstraction addresses one of the oldest problems in computing: the diversity of physical hardware makes it impractical to write software that addresses each device directly. Without abstraction, every application would need to encode knowledge of specific memory addresses, bus protocols, timing constraints, and vendor extensions for every piece of hardware it might encounter.
- The solution is to define a stable, hardware-neutral interface — the abstraction layer — and implement it separately for each hardware target. Higher-level software calls the abstract interface; the layer's implementation translates those calls into device-specific operations. This separation of concerns yields:
  - **Portability**: the same [[Operating System]] or application binary runs on diverse hardware with only the HAL needing change.
  - **Maintainability**: hardware-specific complexity is localised; updating [[Device Driver]] code does not require changes to the operating system kernel or application.
  - **Security**: by controlling hardware access through a well-defined layer, operating systems can enforce access-control policies and prevent unmediated hardware access from user-space processes.
  - **Virtualisation enablement**: [[Virtualisation]] hypervisors use hardware abstraction to present virtual machine guests with a consistent view of hardware regardless of the underlying physical machine.
- Hardware Abstraction is a **mature** concept, core to every mainstream operating system and computing platform since the 1970s. [[POSIX]] standardised UNIX system call interfaces; [[Windows Hardware Abstraction Layer]] abstracted PC hardware for Windows NT; Android's HAL specification (HIDL, then AIDL HAL) abstracts mobile SoC diversity for the Android kernel and frameworks.

### Key Components

- **[[Hardware Abstraction Layer (HAL)]]** — the canonical software component that sits between the [[Operating System]] kernel (or runtime) and the physical hardware. It provides a set of functions that hardware-agnostic code calls; the HAL implementation then drives the hardware via [[Device Driver|device drivers]].
- **[[Device Driver]]** — a specialised software module that implements the HAL contract for a specific hardware device or device class. Drivers translate abstract I/O requests into device register reads/writes, DMA operations, and interrupt configurations.
- **[[Firmware Interface]]** — low-level interface exposed by firmware (BIOS, [[Unified Extensible Firmware Interface|UEFI]], embedded bootloaders) that the HAL relies on during initialisation to discover hardware topology, configure memory maps, and hand off control to the OS kernel.
- **[[Instruction Set Architecture]]** (ISA) — the ISA is itself an abstraction layer between software and microarchitecture. The same x86-64 ISA runs on Intel Raptor Lake and AMD Zen 4 despite radically different microarchitectural implementations.
- **[[Graphics API]]** — APIs such as [[Vulkan]], [[Metal]], [[DirectX]], and [[WebGPU]] abstract GPU hardware into a consistent programming model, hiding shader compiler backends, memory allocation strategies, and vendor-specific tile-based rendering.
- **[[System Call Interface]]** — the boundary between user-space applications and the OS kernel; the kernel's internal HAL further separates the kernel from physical hardware.
- **[[Firmware]]** — stores hardware initialisation sequences and exposes platform capabilities to upper layers via [[Unified Extensible Firmware Interface|UEFI]] or [[ACPI]] tables.

### Mechanisms

- **Indirection via function tables / vtables** — the classic implementation pattern where the HAL defines a struct of function pointers; each hardware implementation fills in the table with device-specific functions. The calling code dereferences the table without knowing the concrete implementation.
- **Abstract device models** — bus frameworks (PCI, USB, I2C) represent each physical device as an abstract device object. Generic subsystem code (block layer, network layer, input layer) operates on the device object; driver code implements device-object callbacks.
- **Memory-Mapped I/O abstraction** — HALs expose `ioread32`/`iowrite32`-style accessors that compile to bare memory reads on x86 but insert memory-barrier instructions on ARM or PowerPC where weakly-ordered memory models demand them.
- **Interrupt abstraction** — the HAL maps physical interrupt sources (PIC, APIC, GIC on ARM) to a uniform IRQ namespace and provides `request_irq`-style registration so device drivers never touch hardware interrupt controllers directly.
- **[[DMA]] abstraction** — the DMA mapping API (e.g., `dma_map_single` in the Linux kernel) hides IOMMU presence, cache coherency requirements, and bus address translation behind a uniform interface.

### Applications / Use Cases

- **Desktop and server operating systems** — Microsoft Windows NT HAL, Linux kernel's architecture-abstraction layer (`arch/` tree and `include/linux/io.h`), and macOS [[XNU kernel]] all use HAL principles to support dozens of hardware platforms from a single codebase.
- **Mobile platforms** — Android's HAL definition language (AIDL HAL, formerly HIDL) mandates a strict interface boundary between Google's OS frameworks and OEM/SoC vendor hardware implementations, allowing AOSP to ship generic framework binaries used across thousands of device models.
- **[[Embedded System]] and [[Real-Time Operating System|RTOSes]]** — FreeRTOS, Zephyr, and AUTOSAR all define a hardware portability layer (BSP/HAL) that application firmware calls; the BSP is the only component rewritten per MCU target.
- **[[Virtualisation]]** — VMware ESXi, KVM, and Hyper-V each present guests with a virtual hardware interface. The hypervisor's HAL translates guest hardware calls into host hardware calls (or emulates them), enabling live migration across physically different servers.
- **[[Spatial Computing]] and XR** — the [[OpenXR]] API is a hardware abstraction layer for XR runtimes, enabling applications targeting Meta Quest, Apple Vision Pro, and HTC Vive to share a single code path. Underlying rendering is further abstracted through [[Vulkan]] or [[WebGPU]].
- **[[AI Accelerator]] runtimes** — CUDA, ROCm (HIP), oneAPI, and OpenCL each provide abstraction layers over GPU and specialised AI accelerator hardware (TPUs, NPUs). Higher-level ML frameworks ([[PyTorch]], [[TensorFlow]]) rely on these as their hardware abstraction substrate, enabling the same model to target NVIDIA, AMD, and Intel hardware.
- **[[Cloud Computing]] and infrastructure-as-code** — hyperscaler infrastructure (AWS Nitro, Google Titanium) uses hardware abstraction extensively to decouple virtualised resources from physical hardware, enabling live resource rebalancing and hardware refresh without guest OS changes.
- **[[WebAssembly]] and browser runtimes** — WASM defines a portable instruction set that browser engines compile to native ISA, providing hardware abstraction at the compute model level analogous to the JVM bytecode model.
- **Automotive and industrial** — AUTOSAR Classic and Adaptive AUTOSAR's MCAL (Microcontroller Abstraction Layer) and ECU Abstraction Layers enable automotive software components to be deployed across ECUs from different silicon vendors without source changes.

### Standards & Context

- **[[POSIX]]** (IEEE Std 1003.1) — defines the system call interface that UNIX-like OS kernels expose, forming the highest-level hardware abstraction contract for portable application software.
- **[[ACPI]]** (Advanced Configuration and Power Interface) — UEFI Forum standard that abstracts hardware power management, thermal management, and device enumeration for operating systems.
- **[[Unified Extensible Firmware Interface|UEFI]]** — replaces legacy BIOS with a standardised firmware abstraction API (Boot Services, Runtime Services) that abstracts platform initialisation for OS loaders.
- **[[OpenXR]]** — Khronos Group specification for XR hardware abstraction, covering headset tracking, rendering surface management, and input across all major XR platforms.
- **[[Vulkan]]** — Khronos Group low-level graphics and compute API providing a hardware abstraction over GPU hardware with explicit control of memory and synchronisation.
- **[[WebGPU]]** — W3C specification (implemented in Chrome, Firefox, Safari) providing a web-portable hardware abstraction over Vulkan, Metal, and DirectX 12.
- **AUTOSAR MCAL** — Automotive Open System Architecture specification defining the microcontroller abstraction layer for ECU software components.
- **Android AIDL HAL** — Google's Android Interface Definition Language-based HAL specification, which mandates binary-stable interfaces between the Android framework and OEM hardware implementations, enabling Treble-based OS upgrades without OEM firmware changes.
- **OpenCL** — Khronos standard for heterogeneous parallel compute abstraction across CPUs, GPUs, FPGAs, and DSPs.
- **HIP / ROCm** — AMD's portable CUDA-compatible abstraction layer enabling GPU compute code to run on both AMD and NVIDIA hardware via a common API.

### Tradeoffs and Limitations

- **Performance overhead** — abstraction introduces indirection costs; tight inner loops that call HAL functions may incur function-call overhead. High-performance computing code sometimes bypasses abstraction layers through vendor-specific APIs or [[Bare-Metal Programming]] for maximum throughput.
- **Lowest-common-denominator risk** — a generic abstraction may not expose the full capability set of the best hardware. Vendors often extend abstract APIs with proprietary extensions (e.g., NVIDIA CUDA extensions beyond OpenCL), creating capability fragmentation despite the abstraction.
- **Abstraction leakage** — the [[Leaky Abstraction]] problem: hardware-specific behaviours (cache coherency, NUMA topology, GPU warp granularity) inevitably leak through the abstraction when performance-critical software must account for them.
- **Driver complexity** — the HAL shifts complexity from application code to driver code. Poorly written or insecure [[Device Driver|device drivers]] remain a leading source of OS instability and security vulnerabilities despite the abstraction boundary.
- **Versioning and stability** — maintaining stable HAL interfaces across hardware generations requires careful API design. Android's Project Treble demonstrated both the feasibility and the engineering cost of enforcing strict interface stability.

### Provenance

