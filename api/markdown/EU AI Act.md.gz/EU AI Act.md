The European Union's Artificial Intelligence Act (Regulation (EU) 2024/1689), the world's first comprehensive horizontal legal framework for artificial intelligence, which classifies AI systems into risk tiers — unacceptable, high, limited and minimal — and imposes proportionate obligations on providers and deployers, including conformity assessment, data governance, transparency, human oversight, robustness and post-market monitoring, with extraterritorial reach over any system placed on the EU market and penalties of up to 7% of global annual turnover.

### Semantic Classification

### Content

## Definition

The **EU AI Act** entered into force on 1 August 2024 as Regulation (EU) 2024/1689, establishing the first binding, economy-wide legal regime for artificial intelligence anywhere in the world. Its central mechanism is a risk-based pyramid: practices deemed an unacceptable risk (social scoring by public authorities, manipulative subliminal techniques, untargeted scraping of facial images, most real-time remote biometric identification in public spaces) are prohibited outright; high-risk systems (in areas such as employment, credit scoring, education, critical infrastructure, law enforcement and medical devices) must satisfy strict requirements before and after market placement; limited-risk systems carry transparency duties such as disclosing that a user is interacting with an AI; and minimal-risk systems remain unregulated.

For high-risk systems the Act mandates a quality-management system, risk management across the lifecycle, training-data governance to limit [[Algorithmic Bias]], technical documentation, record-keeping and logging, human oversight, and demonstrated accuracy, robustness and cybersecurity — obligations verified through conformity assessment and CE marking. A separate chapter added late in negotiation governs general-purpose AI (GPAI) models, imposing documentation and copyright-policy duties on all providers and additional systemic-risk obligations (model evaluation, adversarial testing, incident reporting) on models trained above a compute threshold of 10²⁵ FLOPs.

The Act applies extraterritorially: any provider placing a system on the EU market, or whose system's output is used in the Union, falls within scope regardless of establishment. Enforcement is shared between national market-surveillance authorities and the European AI Office for GPAI, with fines tiered up to €35 million or 7% of worldwide annual turnover for prohibited practices.

## Current Landscape

Application is phased, and the timeline was substantially revised in 2026. Prohibitions and AI-literacy duties applied from 2 February 2025 and GPAI obligations from 2 August 2025. The "Digital Omnibus on AI" (Regulation (EU) 1744/2026, applicable from 27 July 2026) then deferred the bulk of the high-risk regime: obligations for stand-alone Annex III high-risk systems (employment, education, biometrics, law enforcement, critical infrastructure) now apply from 2 December 2027, and those for AI embedded in regulated products under Annex I from 2 August 2028, largely because CEN-CENELEC JTC 21 harmonised standards — whose adoption gives providers a presumption of conformity — were not ready in time.

What the Omnibus did not move: Article 50 transparency duties (disclosing interaction with AI, deepfake labelling) applied on schedule on 2 August 2026 for newly placed systems, with the Article 50(2) machine-readable marking of synthetic content deferred only to 2 December 2026; and the AI Office's GPAI enforcement powers, including fines, activated on 2 August 2026. The Act continues to function as a de facto global standard through the "Brussels effect", shaping vendor compliance programmes far beyond Europe.

**Sources**:

- https://fpf.org/blog/the-ai-act-implementation-timeline-what-changes-under-the-ai-omnibus/
- https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai
- https://www.mayerbrown.com/en/insights/publications/2026/07/eu-ai-act-news-digital-omnibus-on-ai-new-guidance-on-risk-classification-gpai-and-transparency-obligations
- https://cdp.cooley.com/digital-ai-omnibus-delays-key-deadlines-introduces-new-rules/

  Within this knowledge graph the EU AI Act anchors the regulatory dimension of [[AI Governance]]: accountability, transparency and bias-mitigation practices reference it as the binding instrument that operationalises [[Risk Based Regulation]], and audit-trail and disclosure mechanisms cite it as the source of their documentation requirements.

## Merged from EU AI Act Regulatory Instrument (needs reconciliation)
The EU AI Act (Regulation (EU) 2024/1689) is the European Union's comprehensive, legally binding horizontal regulation for artificial intelligence, establishing a four-tier risk-based classification system that prohibits certain AI practices outright, imposes strict pre-market conformity obligations on high-risk AI systems, mandates transparency duties for limited-risk AI, and introduces a dedicated governance regime for general-purpose AI models. Published in the Official Journal in July 2024 and progressively entering into force through 2025–2027, it represents the world's first binding horizontal AI law and creates a de facto global compliance benchmark through its extraterritorial scope. Enforcement is shared between national market surveillance authorities, the European AI Office, and the European AI Board, with penalties reaching up to €35 million or 7% of global annual turnover.

### Overview

- The EU AI Act entered into force on 1 August 2024, following publication in the Official Journal of the European Union. It is embedded within the EU's existing [[New Legislative Framework]] for product safety and market surveillance, meaning it reuses established conformity assessment infrastructure (e.g., [[CE Marking]], [[Notified Body]] designations) rather than creating entirely new bureaucratic machinery.
- The regulation's primary policy objective is to ensure that AI systems placed on the EU market are safe, transparent, traceable, non-discriminatory, and environmentally sustainable, while preserving the Union's competitiveness by avoiding overly burdensome rules for low-risk AI.
- The [[Brussels Effect]] is a central strategic dimension: because the Act applies to any operator whose AI system affects EU residents, organisations headquartered outside Europe must comply or exit the EU market. Many global technology providers have elected to implement EU Act requirements as global baseline standards, propagating EU norms worldwide.
- The Act does not regulate AI research conducted solely in non-commercial contexts, AI systems used exclusively for military or national security purposes, or AI outputs used solely for personal non-professional activity.
- Enforcement is shared across three tiers: national [[Market Surveillance Authority]] bodies handle most product-category obligations; the [[EU AI Office]] (established within the European Commission) oversees GPAI model compliance and cross-border enforcement; the [[European AI Board]] (comprising national authority representatives) coordinates coherent interpretation across Member States.

### Key Components

#### Risk Classification System

- **Unacceptable Risk (Prohibited Practices)**: AI systems presenting an unacceptable threat to fundamental rights or safety are banned outright under Article 5. Examples include:
  - Real-time remote [[Biometric Identification]] in publicly accessible spaces by law enforcement (with narrow exceptions)
  - Social scoring systems operated by public authorities
  - Subliminal manipulation techniques exploiting persons' vulnerabilities
  - AI for predictive policing based solely on profiling without reasonable suspicion
  - Emotion recognition in workplaces and educational institutions (with limited exceptions)
  - Biometric categorisation inferring sensitive attributes (race, political opinions, sexual orientation)
- **High-Risk AI Systems**: Annex I covers AI embedded in products regulated under sector-specific EU directives (medical devices, machinery, vehicles, aviation); Annex II covers stand-alone AI in domains including critical infrastructure, education, employment, essential services, law enforcement, migration and asylum, administration of justice, and democratic processes.
  - Pre-market obligations: [[Risk Assessment]], [[Technical Documentation]], logging capability, [[Conformity Assessment]] (self-assessment or third-party via [[Notified Body]]), EU database registration
  - Post-market obligations: incident reporting to national authorities, [[Post-Market Monitoring]] plan, cooperation with market surveillance
  - Human-oversight obligations: design must permit competent operators to override, halt, or intervene in system outputs
- **Limited-Risk AI**: Systems such as chatbots, deepfake generators, and emotion-recognition tools must disclose their AI nature to interacting users ([[Transparency]] obligation under Article 50).
- **Minimal-Risk AI**: AI used in spam filters, video games, inventory management and similar applications faces no binding obligations but may voluntarily adopt codes of conduct.

#### General-Purpose AI (GPAI) Model Regime

- Introduced in Title VIII, the GPAI chapter applies to any model trained on large datasets at scale, exhibiting significant generality, and capable of performing multiple distinct tasks.
- All GPAI providers must: publish a summary of training data, comply with EU copyright law (including opting out of text-and-data mining reservations where required), and maintain technical documentation for downstream deployers.
- [[Foundation Model]] providers above a computational threshold (initially 10^25 FLOPs of training compute, used as a proxy for systemic risk) are classified as "systemic-risk GPAI models" and face additional obligations: adversarial robustness testing ([[Red Teaming]]), cybersecurity measures, serious-incident reporting to the EU AI Office, and energy-consumption disclosure.
- The EU AI Office may define further obligations via delegated acts as compute thresholds evolve with technology.

#### Governance Architecture

- **[[EU AI Office]]**: Created within the Directorate-General for Communications Networks, Content and Technology (DG CONNECT), it is the primary Union-level body for GPAI oversight and cross-border AI enforcement coordination.
- **[[European AI Board]]**: Advisory body of national authority representatives that provides opinions and guidance on consistent Act implementation; can escalate cross-border incidents.
- **Scientific Panel of Independent Experts**: Technical body advising the AI Office on GPAI classification and risk assessment.
- **National Competent Authorities**: Each Member State designates at least one national authority as market surveillance authority and as notifying authority for conformity assessment bodies.
- **[[AI Regulatory Sandbox]]**: Member States must establish at least one controlled testing environment by August 2026, allowing innovators (especially SMEs and start-ups) to develop and test innovative AI with reduced compliance burden under authority supervision.

#### Implementation Timeline

- August 2024: Regulation entered into force
- February 2025: Prohibited practices (Chapter II) applicable
- August 2025: GPAI model obligations (Title VIII) and governance provisions applicable
- August 2026: High-risk AI (Annex I sector-specific products) obligations applicable; AI Office operational; sandboxes required
- August 2027: High-risk AI (Annex II stand-alone systems) obligations applicable

#### Penalties and Enforcement

- Prohibited practice violations: up to €35 million or 7% of global annual turnover
- Other obligations violations: up to €15 million or 3% of global annual turnover
- Incorrect or misleading information to authorities: up to €7.5 million or 1% of global annual turnover
- SME-specific proportionality provisions ensure penalties are scaled appropriately for smaller operators

### Applications and Use Cases

- **Healthcare AI**: Diagnostic AI tools (e.g., medical imaging analysis for cancer detection) are classified as high-risk under Annex II if they influence clinical decisions, requiring [[Conformity Assessment]] aligned with Medical Device Regulation.
- **Employment Screening**: AI used in CV screening, interview analysis, or promotion decisions falls under high-risk Annex II obligations, requiring human oversight and transparency toward affected workers.
- **Law Enforcement**: Predictive crime-mapping systems and real-time facial recognition in public spaces face either outright prohibition or stringent high-risk obligations, reshaping how police forces procure and deploy AI tools.
- **Financial Services**: Credit-scoring AI and insurance risk-assessment tools may fall within high-risk classification if they determine access to essential services, requiring robust bias testing and [[Algorithmic Accountability]] mechanisms.
- **Education**: AI for student performance assessment, learning-path optimisation, or admissions is high-risk, requiring documentation of training data composition and human review of AI-driven decisions.
- **Autonomous Systems and Robotics**: AI components embedded in CE-marked machinery or safety-critical products (vehicles, aircraft, industrial equipment) are captured under Annex I.
- **Large Language Model Deployment**: Providers of [[Large Language Model]] services (e.g., conversational assistants, code generators) must satisfy GPAI transparency obligations and, if systemic-risk, adversarial testing requirements before making models available in the EU.
- **Public Sector Procurement**: EU institutions and Member State agencies face internal obligations under a separate regulation mirroring the Act's provisions, standardising public-sector AI use.

### Standards and Context

- The Act explicitly references harmonised standards developed by [[CEN-CENELEC]] and [[ETSI]] as mechanisms for demonstrating conformity. Operators who comply with cited harmonised standards receive a presumption of conformity with the corresponding Act requirements, reducing audit burden.
- The [[European AI Office]] maintains a mandate to develop codes of practice — co-created with industry, civil society, and academia — as interim compliance guidance during the transition period before harmonised standards are finalised.
- The Act interacts with a constellation of other EU digital regulations: [[GDPR]] (personal data processed by AI systems); the [[Digital Services Act]] (DSA — recommender systems); the [[Digital Markets Act]] (DMA — gatekeepers' AI-powered services); the [[Data Governance Act]] (DGA — data intermediaries); the [[Cyber Resilience Act]] (cybersecurity of AI-enabled products); and sector-specific regulations (Medical Device Regulation, Machinery Regulation, General Product Safety Regulation).
- ISO/IEC 42001 (AI Management System), ISO/IEC 23894 (AI Risk Management), and ISO/IEC TR 24028 (AI Trustworthiness) are expected to form the backbone of harmonised standards referenced by the Act.
- The Act is situated within the broader [[EU Digital Decade]] policy framework and aligns with the [[European AI Strategy]] (COM/2018/237) and its updated Coordinated Plan on AI (2021 revision).
- The [[OECD AI Principles]] and [[UNESCO Recommendation on AI Ethics]] (2021) are cited in the Act's recitals as international reference points, and the EU AI Office coordinates with international counterparts to promote interoperability of regulatory frameworks.
- The concept of a [[Brussels Effect]] — where unilateral EU regulation becomes the de facto global standard — is particularly potent here: most major AI providers (OpenAI, Google DeepMind, Meta, Mistral) operate in the EU market and have published conformance roadmaps, effectively exporting EU norms globally.

### Provenance

