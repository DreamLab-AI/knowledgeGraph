Supplier diversification is the practice of spreading the supply of an input across several suppliers, often in different places, so that the failure of one does not stop supply.[^1][^2]

NIST's guidance on information and communications technology supply chains says enterprises should diversify their supply base, especially for critical products and services.[^3] The White House 100-day review says the search for low-cost production, combined with the industrial policy of key nations, has led to geographic concentrations of key supply chains in a few nations, increasing vulnerabilities, that such concentration leaves companies vulnerable to disruption, and that international suppliers need to be diversified.[^1]

## Geographic spread

The UK Climate Change Committee says that for climate risks, key actions involve understanding and diversifying the geographic location of suppliers, which decreases the impact of any single region's risks.[^2] Christopher and Peck list a single source of supply with no short-term alternative as a characteristic of a critical path.[^4]

## Diversification and trade policy

The World Trade Organization says that trade contributes to economic security by enabling risk diversification, and that deep and diversified international markets helped countries cope with shortages by securing supplies from alternative sources.[^5] It argues that national resilience lies in expanding and diversifying trade, not restricting or reshoring it.[^5]

The European Central Bank reports that some EU manufacturers are shifting the sourcing of critical inputs from China to within the EU to mitigate the risk of disruptions, and that critical foreign dependencies persist.[^6] The ECB also warns that addressing foreign dependencies with broadbased protectionism is self-defeating.[^6]

## Scope and limits

Diversification is the remedy for [[Supplier Concentration Risk]] and one of the options at [[Supply Chain Resilience Strategy]]. Its regional variant is [[Supply Chain Regionalisation]]. The sources do not give a number of suppliers that is enough, nor the cost of qualifying additional suppliers, and they are recommendations or surveys, not tests of whether diversified chains fare better.

[^1]: The White House, report under Executive Order 14017, June 2021, “Building Resilient Supply Chains, Revitalizing American Manufacturing, and Fostering Broad-Based Growth: 100-Day Reviews under Executive Order 14017”. https://bidenwhitehouse.archives.gov/wp-content/uploads/2021/06/100-day-supply-chain-review-report.pdf
[^2]: UK Climate Change Committee, “Resilient Supply Chains (briefing, 2022)”. https://www.theccc.org.uk/wp-content/uploads/2022/10/Resilient-Supply-Chains-.pdf
[^3]: National Institute of Standards and Technology, NIST Special Publication 800-161r1-upd1 (May 2022, updated), “Cybersecurity Supply Chain Risk Management Practices for Systems and Organizations”. https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-161r1-upd1.pdf
[^4]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^5]: World Trade Organization, “World Trade Report 2023: Re-globalization for a secure, inclusive and sustainable future”. https://www.wto.org/english/res_e/booksp_e/wtr23_e/wtr23_e.pdf
[^6]: European Central Bank, Occasional Paper Series, “Navigating a fragmenting global trading system: insights for central banks (No 365)”. https://ecb.europa.eu/pub/pdf/scpops/ecb.op365~362d801aee.es.pdf

