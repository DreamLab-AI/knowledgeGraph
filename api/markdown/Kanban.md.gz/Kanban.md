A kanban is a signalling device that gives authorisation and instructions for the production or withdrawal of items in a pull system.[^1]

The Lean Enterprise Institute says the term is Japanese for sign or signboard. Cards are the best-known form, but kanban can also be triangular metal plates, coloured balls, electronic signals or any other device that conveys the needed information while preventing erroneous instructions.[^1] It says kanban have two functions in a production operation: they instruct processes to make products, which is production kanban, and they instruct material handlers to move products, which is withdrawal kanban.[^1]

An open operations management text describes it in similar terms: a ticket or signal given from one part of the process to another to let it know it is allowed to start its next activity. It adds that this supports pull production and avoids waste by not doing things at the time they are not needed.[^2]

## In practice

For batch operations with short cycle times and long changeover times, such as a stamping press, the Institute says a signal kanban is used to trigger production when a minimum quantity of containers is reached.[^1] The textbook places kanban inside just-in-time systems as a tool that facilitates the pull system; see [[Just-in-Time Production]].[^2]

## Scope and distinctions

Kanban as a shop-floor replenishment signal is not the same as a kanban board used for tracking work. The textbook notes that kanban is also a signboard used to organise what needs to be done, what is under way and what is done, and that this aspect has been used in Agile workflow management systems.[^2] This page is about the production signal.

It sits within [[Lean Production]]; see also [[Takt Time]].

## What the sources do not establish

The Lean Enterprise Institute is the main witness for the typology of kanban, and the textbook is the only independent origin for the definition. Neither source gives card counts or sizing rules for a kanban loop, so the page does not.

[^1]: Lean Enterprise Institute, “Kanban (Lean Lexicon)”. https://www.lean.org/lexicon-terms/kanban/
[^2]: Business LibreTexts (Introduction to Operations Management, NWTC), “10.3: Just-In-Time (JIT) Systems”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/10:_Just_in_Time_Lean_Systems/10.03:_Just-In-Time_(JIT)_Systems

