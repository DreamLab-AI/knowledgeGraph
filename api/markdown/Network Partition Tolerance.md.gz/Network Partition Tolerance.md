Network partition tolerance is the property of a distributed system that allows it to continue operating despite the network splitting into groups of nodes that cannot communicate with one another. It is one of the three properties in the CAP theorem, which states that during a partition a system must sacrifice either strong consistency or availability. In blockchain and distributed databases, partition tolerance is generally treated as non-negotiable because partitions are inevitable in real networks, forcing explicit design choices about how the system behaves when nodes are split.

### Overview

- Partition tolerance forces a fundamental trade-off articulated by Brewer's CAP theorem: when the network partitions, a system can preserve at most one of strong consistency and availability for the affected data. AP systems remain writable on both sides and reconcile later, accepting temporary divergence, while CP systems refuse operations that cannot meet quorum, sacrificing availability to avoid conflicting state. Blockchains typically prioritise eventual safety and reconciliation, using quorum-based consensus to converge once the partition heals.

### Key aspects

- Continued operation despite network splits between node groups
- CAP trade-off between consistency and availability during partitions
- Quorum requirements that prevent conflicting decisions
- Reconciliation and convergence once partitions heal
- Detection of and response to split-brain conditions

### Applications

- Blockchain networks tolerating connectivity loss
- Geo-distributed databases and replicated stores
- Highly available cloud services
- Edge and intermittently connected systems

### Provenance

- This class was materialised to resolve inbound references from existing classes in the knowledge graph.

