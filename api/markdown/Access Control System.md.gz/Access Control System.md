An Access Control System is the assemblage of policies, decision engines, enforcement points, identity providers, attribute sources, audit pipelines, and cryptographic primitives that determines wher a subject (human user, service account, autonomous agent, device) is permitted to perform a r...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:hasPart security:PolicyEngine))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:hasPart security:PolicyDecisionPoint))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:hasPart security:PolicyEnforcementPoint))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:hasPart security:PolicyInformationPoint))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:hasPart security:PolicyAdministrationPoint))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:hasPart security:AuditLog))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:hasPart security:IdentityStore))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:hasPart security:SessionManager))

    ## Dependency Relationships
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:requires security:IdentityProvider))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:requires security:Authentication))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:requires security:CryptographicPrimitives))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:requires security:TrustedTimeSource))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:dependsOn security:PublicKeyInfrastructure))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:dependsOn security:DirectoryService))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:dependsOn security:SecureLogging))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:dependsOn security:Cryptography))

    ## Capability Relationships
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:enables security:LeastPrivilege))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:enables security:SeparationOfDuties))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:enables security:Accountability))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:enables security:RegulatoryCompliance))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:enables security:Auditability))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:supports security:ZeroTrustArchitecture))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:supports security:IncidentResponse))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:supports security:PrivilegedAccessManagement))

    ## Implementation Relationships
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:implements security:RBAC))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:implements security:ABAC))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:implements security:ReBAC))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:implements security:DAC))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:implements security:MAC))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:implements security:PBAC))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:uses security:OAuth2))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:uses security:OpenIDConnect))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:uses security:SAML))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:uses security:Kerberos))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:uses security:WebAuthn))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:uses security:XACML))

    ## Reduction Relationships
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:reduces security:UnauthorisedAccess))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:reduces security:InsiderThreat))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:reduces security:LateralMovement))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:reduces security:CredentialAbuse))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:reduces security:DataExfiltrationRisk))

    ## Association Relationships
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:relatedTo security:IdentityManagement))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:relatedTo security:SecretsManagement))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:relatedTo security:SingleSignOn))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:relatedTo security:MultiFactorAuthentication))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:contrastsWith security:CapabilityBasedSecurity))
    SubClassOf(security:AccessControlSystem
      ObjectSomeValuesFrom(security:contrastsWith security:SelfSovereignIdentity))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(security:hasIdentifier security:AccessControlSystem "SEC-1042"^^xsd:string)
    DataPropertyAssertion(security:authorityScore security:AccessControlSystem "0.87"^^xsd:decimal)
    DataPropertyAssertion(security:globalEnterpriseDeployments security:AccessControlSystem "250000000"^^xsd:integer)
    DataPropertyAssertion(security:zanzibarTuplesAtGoogleScale security:AccessControlSystem "2000000000000"^^xsd:long)
    DataPropertyAssertion(security:passkeyCapableDevices2026 security:AccessControlSystem "8500000000"^^xsd:long)
    DataPropertyAssertion(security:awsIamActionsDocumented security:AccessControlSystem "50000"^^xsd:integer)

    ## Property Constraints
    SubClassOf(security:AccessControlSystem
      ObjectMinCardinality(1 security:hasPolicyDecisionPoint))
    SubClassOf(security:AccessControlSystem
      ObjectMinCardinality(1 security:hasPolicyEnforcementPoint))
    SubClassOf(security:AccessControlSystem
      DataSomeValuesFrom(security:authorisationModel xsd:string))
    SubClassOf(security:AccessControlSystem
      DataAllValuesFrom(security:enforcesLeastPrivilege xsd:boolean))

    ## Annotations
    AnnotationAssertion(rdfs:label security:AccessControlSystem "Access Control System"@en)
    AnnotationAssertion(rdfs:comment security:AccessControlSystem "Assemblage of policies, decision engines, enforcement points, identity providers, attribute sources and audit pipelines that determines whether a subject may perform an operation on a resource. Spans DAC, MAC (Bell-LaPadula, Biba, Brewer-Nash, Clark-Wilson), RBAC (ANSI INCITS 359), ABAC (NIST SP 800-162, XACML), ReBAC (Google Zanzibar, OpenFGA, SpiceDB), PBAC (OPA, Cedar) and capability-based security. Integrates authentication via Kerberos, LDAP, OAuth 2.0/OIDC, SAML 2.0, WebAuthn/FIDO2 passkeys. Deployed at API gateways, service meshes, Kubernetes RBAC, AWS/Azure/GCP cloud IAM, commercial platforms (Okta, Entra ID, Auth0, Ping, JumpCloud) and physical access (HID, ASSA ABLOY). Aligned to Zero Trust (NIST 800-207, BeyondCorp, CISA ZTMM) and ISO 27002, PCI DSS, NIST CSF compliance regimes."@en)
    AnnotationAssertion(dcterms:identifier security:AccessControlSystem "SEC-1042"^^xsd:string)
    AnnotationAssertion(dcterms:subject security:AccessControlSystem "Information Security, Authorisation, Identity and Access Management, Zero Trust"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(security:requires)
  AsymmetricObjectProperty(security:enables)
  AsymmetricObjectProperty(security:implements)
  AsymmetricObjectProperty(security:reduces)
  TransitiveObjectProperty(security:dependsOn)
  FunctionalDataProperty(security:authorityScore)

## About Access Control Systems

- An **Access Control System** is the formal apparatus by which an information system answers the question: *can this subject perform this operation on this resource right now?* The answer is determined not by a single decision but by a layered evaluation pipeline — identity establishment, session validation, policy retrieval, attribute resolution, decision computation, enforcement, and audit emission — each stage potentially involving distinct subsystems, trust boundaries, and failure modes. Modern access control is therefore less a single product than an architecture: a federation of decision engines, enforcement points, identity providers, attribute sources, key infrastructures, and observability sinks operating in concert across application code, platform middleware, network fabric, and physical hardware.
- The discipline traces its formal lineage to Lampson's 1971 protection-matrix abstraction, Saltzer & Schroeder's 1975 *Protection of Information in Computer Systems* (which enumerated the eight design principles — economy of mechanism, fail-safe defaults, complete mediation, open design, separation of privilege, least privilege, least common mechanism, psychological acceptability — that still anchor the field), Bell & LaPadula's 1973 lattice model of confidentiality for the U.S. Department of Defense, Biba's 1977 dual model for integrity, Clark & Wilson's 1987 commercial-data-integrity model, and Brewer & Nash's 1989 Chinese Wall model for conflict-of-interest enforcement in financial services. From these foundations the field branched into the National Institute of Standards and Technology's [[RBAC]] formalisation (Sandhu, Coyne, Feinstein & Youman 1996) which became ANSI INCITS 359 in 2004, and Hu, Ferraiolo et al.'s 2014 NIST SP 800-162 publication of [[ABAC]] as the recommended attribute-based successor to role-only thinking. The most consequential industrial publication of the modern era was Google's 2019 USENIX ATC paper on [[Zanzibar]] — a global consistent authorisation system serving 10 million authorisation checks per second across 2 trillion stored relation tuples — which catalysed the open-source [[OpenFGA]], [[SpiceDB]], [[Topaz]], and [[Warrant]] ecosystems and established **Relationship-Based Access Control (ReBAC)** as the dominant model for fine-grained, hierarchical authorisation in cloud-native systems.
- The strategic context for access control in 2026 is shaped by three converging pressures: the collapse of the network perimeter under cloud migration and remote work (making [[Zero Trust Architecture]] the default rather than the aspiration), the explosion of non-human identities (service accounts, workload identities, autonomous AI agents now outnumbering human identities 45:1 in mature cloud estates per CyberArk 2024 research), and the regulatory tightening visible in the EU's NIS2 Directive (transposed October 2024), DORA financial-sector resilience regulation (effective January 2025), and the SEC's cyber-disclosure rules. Access control is therefore no longer a compliance checkbox but a load-bearing element of organisational survival.

### Core Theoretical Frameworks

Access control admits a half-dozen distinct formalisms, each with its own algebra of permission, its own canonical failure modes, and its own zone of practical applicability.

**The Access Matrix (Lampson 1971, Harrison-Ruzzo-Ullman 1976)**: The foundational abstraction is a matrix A[S, O] mapping subjects S to objects O and storing the rights each subject holds over each object. The HRU theorem (Harrison, Ruzzo, Ullman 1976) demonstrated that the *safety problem* — determining whether a given right can ever leak to an unintended subject — is undecidable in the general case, establishing the theoretical reason why access control systems cannot be both maximally expressive and provably safe. Practical systems therefore restrict expressiveness (RBAC's role-permission separation, ABAC's bounded attribute predicates) to recover decidability.

**Mandatory Access Control (Bell-LaPadula 1973, Biba 1977)**: The [[Bell-LaPadula Model]] formalises **confidentiality** through two rules over a security lattice: the *simple security property* (no-read-up: a subject at clearance level L cannot read an object at level L' > L) and the *star property* (no-write-down: a subject cleared at L cannot write to an object at L' < L, preventing high-clearance subjects leaking to low-clearance objects). The [[Biba Model]] inverts these for **integrity**: no-read-down (no contamination from low-integrity sources) and no-write-up (no corruption of high-integrity objects). Bell-LaPadula underpins the U.S. Multi-Level Security (MLS) architecture used in NSA Type 1 cryptographic systems and the Common Criteria Protection Profiles for high-assurance separation kernels. Biba is the conceptual ancestor of code-signing systems (only high-integrity binaries may write to system directories) and Windows Mandatory Integrity Control (MIC) shipped since Vista.

**Clark-Wilson (1987)** addresses commercial integrity requirements that Biba's lattice fails to capture: **well-formed transactions** (a constrained data item may only be modified by certified transformation procedures) and **separation of duty** (no single subject may execute all steps of a critical transaction). Clark-Wilson is the formal grandparent of every banking system's maker-checker control, every SAP transaction-authorisation matrix, and every Sarbanes-Oxley access review.

**Brewer-Nash Chinese Wall (1989)** captures the *dynamic* conflict-of-interest constraints needed in professional-services firms (a consultant who has accessed Bank A's data may not subsequently access Bank A's competitor Bank B). The wall is history-dependent: permission depends on the subject's prior access history, not solely on attributes at the moment of decision. Modern implementations include the conflict-of-interest controls in BigLaw practice-management systems (Aderant, Elite 3E) and the M&A-sensitive controls in investment-banking deal rooms.

**Role-Based Access Control (Sandhu et al. 1996, ANSI INCITS 359-2004)**: [[RBAC]] introduces an intermediating abstraction — the *role* — between subjects and permissions. Users are assigned to roles, roles are assigned permissions, and access decisions traverse this two-hop graph. The ANSI standard codifies four levels: **RBAC0** (flat: users-roles-permissions), **RBAC1** (hierarchical: roles inherit permissions from parent roles, e.g. Senior Engineer inherits Engineer's permissions), **RBAC2** (constrained: separation-of-duty and cardinality constraints prevent toxic role combinations), **RBAC3** (combined: hierarchical and constrained). RBAC's commercial dominance stems from psychological acceptability — humans naturally think in roles — and from operational efficiency: provisioning a new joiner reduces to assigning roles rather than enumerating permissions. RBAC's weakness is **role explosion**: large organisations routinely accumulate 10,000-50,000 roles to capture every operational permission permutation, at which point the role graph becomes opaque and ungovernable.

**Attribute-Based Access Control (NIST SP 800-162, 2014)**: [[ABAC]] replaces the static role-permission binding with **dynamic policy evaluation** over subject, resource, action, and environment attributes. A canonical ABAC policy reads: *permit update of patient record if subject.role contains "treating-physician" AND subject.licence_state == resource.state AND environment.time within business_hours AND action == "update" AND resource.classification ≤ subject.clearance*. ABAC was operationalised by the OASIS [[XACML]] 3.0 specification (2013), which defined the four-component architecture — **Policy Decision Point (PDP)** computing decisions, **Policy Enforcement Point (PEP)** applying them, **Policy Information Point (PIP)** supplying attributes, **Policy Administration Point (PAP)** managing policy lifecycle — that remains the canonical reference architecture for fine-grained authorisation.

**Relationship-Based Access Control (Carminati et al. 2009, Google Zanzibar 2019)**: [[ReBAC]] generalises ABAC by treating *relationships* as first-class authorisation entities. A user has access to a document not because they hold a role or attribute but because there exists a chain of relationships (member-of-team → editor-of-folder → contains → document) terminating at the document with appropriate semantics. Google's [[Zanzibar]] productised this model at planetary scale, defining relationships as tuples ⟨object#relation@user⟩ (e.g. `doc:readme#viewer@user:alice` asserts Alice is a viewer of doc:readme) and computing authorisation as transitive-closure graph traversal with bounded-staleness consistency via **Zookies** (snapshot tokens). The open-source ecosystem — [[OpenFGA]] (CNCF Sandbox, donated by Auth0/Okta 2022), [[SpiceDB]] (AuthZed), [[Topaz]] (Aserto, open-sourced 2023), [[Warrant]] (acquired by WorkOS 2024) — implements Zanzibar-style ReBAC for organisations that lack Google's scale but inherit Google's modelling discipline.

**Policy-Based Access Control / Policy-as-Code**: [[PBAC]] and its modern incarnation policy-as-code (epitomised by [[Open Policy Agent]]'s Rego language and AWS's [[Cedar]] DSL with formal SMT-solver verification) collapse the distinction between RBAC, ABAC, and ReBAC into a unified **declarative policy** abstraction: policy is code, evaluated by a general-purpose decision engine. OPA reached CNCF Graduated status in 2021 and ships in production at 8,500+ organisations including Netflix, Pinterest, Capital One, and the U.S. Department of Defense; Cedar was open-sourced by AWS in 2023 to underpin AWS Verified Permissions and includes a Lean4 mechanised proof of decidability and policy-equivalence properties.

**Capability-Based Security (Dennis & Van Horn 1966, Hardy 1988)**: A philosophically distinct branch in which **unforgeable tokens** (capabilities) bear the rights they confer; possession is permission. The model dissolves the *confused-deputy problem* (Hardy 1988) in which an ambient-authority subject is tricked into exercising privileges on behalf of a less-privileged caller, by requiring rights to be presented explicitly rather than inherited from ambient identity. Production capability systems include KeyKOS (Tymshare 1980s), EROS (Shapiro et al.), seL4 (Data61/CSIRO, formally verified microkernel with 10,000+ deployments in defence and automotive), [[Genode]] OS framework, and the E programming language. Modern web-platform tokens (JWT, macaroons per Google 2014, biscuits) are capability-like in spirit but typically operate within an ambient-authority host.

### Identity and Authentication Substrates

Access control presupposes **authenticated identity** — the system must know *who* is asking before it can decide *whether* to permit. The identity substrate has evolved through five generations.

**Generation 1 — Local Credentials (1960s-1980s)**: Per-system username/password pairs stored in /etc/passwd, /etc/shadow (with Morris 1979 introducing crypt() one-way hashing). Failure modes: credential reuse across systems, password ageing, brute-force vulnerability before bcrypt/Argon2.

**Generation 2 — Network Authentication (1980s-1990s)**: [[Kerberos]] (MIT 1988, formalised in RFC 4120 for v5) introduced the ticket-granting service model: a single Key Distribution Centre (KDC) issues time-bound encrypted tickets that prove identity to network services without re-transmitting passwords. Kerberos remains the authentication backbone of [[Active Directory]] (deployed in 95% of Fortune 500 organisations) and of Hadoop/Kafka enterprise deployments. [[LDAP]] (RFC 4511, 1993-onwards) provides the directory-service abstraction for storing identities, groups, and attributes; OpenLDAP and Microsoft Active Directory remain the dominant implementations.

**Generation 3 — Federation (2000s)**: [[SAML 2.0]] (OASIS 2005) defined browser-redirect federation: the Service Provider redirects the user to the Identity Provider, which authenticates and returns a signed SAML assertion. SAML powered enterprise SSO for two decades and remains the lingua franca for B2B federation despite its XML-canonicalisation complexity. [[OAuth 2.0]] (RFC 6749, 2012) separated *authorisation* from *authentication*, providing four grant types (authorisation code, implicit, resource-owner-credentials, client-credentials) for delegating access without sharing credentials. [[OpenID Connect]] (OIDC, 2014) layered an identity-token (ID Token, a JWT) atop OAuth 2.0, producing the dominant modern federation pattern.

**Generation 4 — Hardware-Backed Public-Key (2010s-2020s)**: [[WebAuthn]] (W3C Recommendation 2019, Level 3 2024) and the FIDO2 stack (CTAP2 for authenticator communication) replaced shared secrets with hardware-resident asymmetric keypairs. Each Relying Party gets a unique keypair generated in the authenticator (YubiKey, Apple Secure Enclave, Android StrongBox, Windows Hello TPM). [[Passkey]]s — synchronisable WebAuthn credentials introduced by Apple/Google/Microsoft 2022-2023 — extended the model to consumer scale: by Q1 2026, 8.5 billion passkey-capable devices were in circulation per FIDO Alliance metrics, with 30%+ of major consumer sites supporting passkey sign-in (Google, Apple, Microsoft, Amazon, GitHub, PayPal, eBay, Best Buy, Shopify, Adobe).

**Generation 5 — Decentralised / Agent Identity (2020s-)**: W3C [[Decentralised Identifier]]s (DID Core 1.0, 2022) and [[Verifiable Credential]]s (VC Data Model 2.0, 2024) enable self-sovereign identity in which the subject controls their identifier and presents cryptographically verifiable claims without an identity provider mediating each transaction. Practical deployments include the European Digital Identity Wallet (eIDAS 2.0 regulation 2024, mandatory by 2026), the UK NHS Login DID pilot (2024-2025), and the Bhutan National Digital Identity (NDI) system. In parallel, the rise of autonomous AI agents has surfaced the need for **agent identity** distinct from user identity: the Model Context Protocol ([[MCP]]) draft authorisation specifications, Anthropic's Claude Agent SDK delegation model, and OpenAI's Operator agent-authentication patterns are early attempts to express *agent acting on behalf of principal* in a verifiable, revocable manner.

Cross-cutting all five generations is [[Multi-Factor Authentication]] (MFA): the requirement that authentication combine factors from at least two of *something you know* (password), *something you have* (TOTP token, FIDO key, passkey), *something you are* (biometric). NIST SP 800-63B (2017, updated 2024) defines four Authentication Assurance Levels (AAL1-3) with corresponding factor and verifier-impersonation-resistance requirements. CISA's MFA mandate for U.S. federal civilian executive-branch agencies (Executive Order 14028, 2021) and the UK NCSC's phishing-resistant-MFA guidance (2023) have pushed enterprise adoption from 22% in 2017 to 64% in 2024 per Microsoft Digital Defense Report.

### Architectural Patterns and Enforcement Points

Where access control is *evaluated* and *enforced* shapes its threat surface as much as which model it implements.

**API Gateway Enforcement**: The [[API Gateway]] (Kong, Tyk, AWS API Gateway, Apigee, Azure API Management) sits at the north-south boundary of an application and is the canonical coarse-grained PEP — authenticating callers via OAuth/OIDC, mapping scopes to permitted operations, applying rate limits per identity, terminating TLS. Throughput in production exceeds 1M requests/sec at hyperscalers; latency budgets for the authz hop are typically 1-5 ms.

**Service Mesh Enforcement**: [[Istio]] AuthorizationPolicy CRDs, Linkerd policy server, Consul Connect intentions, and AWS App Mesh apply east-west authorisation between microservices via mTLS-attested workload identities (SPIFFE/SPIRE in CNCF projects). The mesh decouples authorisation from application code, enabling platform teams to enforce default-deny baselines without rewriting service logic.

**Kubernetes RBAC**: Kubernetes RBAC (Role/ClusterRole/RoleBinding/ClusterRoleBinding, shipped GA in 1.6 and default in 1.8+) governs API-server access to cluster resources. By 2026 over 5 million production Kubernetes clusters use RBAC as their access-control primitive. [[OPA Gatekeeper]] (Open Policy Agent integration as a Kubernetes admission controller) extends this with policy-as-code constraint templates: 50+ canonical templates cover pod-security, image-provenance, resource-quota, and labelling controls.

**Cloud IAM**: [[AWS IAM]] (50K+ documented actions across 300+ services), [[Azure RBAC]] (250+ built-in roles), [[GCP IAM]] (4,500+ predefined roles) each implement a hybrid RBAC+ABAC model: identity-based policies (attached to principals), resource-based policies (attached to resources), and condition keys (attribute predicates evaluated at request time). AWS's [[IAM Access Analyzer]] integrates the [[Zelkova]] SMT-solver formal-methods engine (Backes et al. 2018) to prove or disprove policy-property claims (e.g. *no resource policy permits unauthenticated public access*) — among the few production deployments of mechanised theorem-proving in security tooling.

**In-Application Enforcement**: Fine-grained, row-level, field-level, and tenant-isolation decisions typically remain inside application code, mediated by libraries (Spring Security, Casbin, Cancan/Pundit in Ruby, Casbin-Go, OSO) or by an authorisation service ([[OpenFGA]], [[SpiceDB]], [[Cerbos]], [[Topaz]]) that the application queries per request.

**Physical Access**: HID Global iCLASS SEOS readers, ASSA ABLOY HES wireless locks, Suprema/IDEMIA biometric readers, and BlueDiamond mobile-credential platforms enforce *physical* authorisation. Modern systems integrate logical and physical access — Okta Workforce + ASSA ABLOY allows the same identity to unlock a workstation and a data-centre cage — with video access verification (Genetec, Milestone, Axis) recording the visual context of each badge swipe for forensic review.

**Database and Data-Lake Enforcement**: Beyond application and API layers, modern data platforms implement native authorisation surfaces: PostgreSQL Row Level Security (RLS, since 9.5 in 2016) and column-level GRANTs; Snowflake row access policies and dynamic data masking; Databricks Unity Catalog (GA 2022) with attribute-based filters; BigQuery column-level security with policy tags; AWS Lake Formation with LF-tags and data-cell filters. The tension between performance (push predicates into the storage engine) and policy expressiveness (delegate to a generic PDP) drives an emerging integration pattern: PDP-issued *policy bundles* compiled into native predicates by data-platform engines. Immuta and Privacera pioneered this market; Snowflake's 2024 acquisition of Okera and Databricks' 2023 native ABAC additions confirmed it.

**Network Access Control**: Pre-Zero-Trust network access (802.1X port authentication via [[RADIUS]], Cisco ISE, Aruba ClearPass, Forescout, FortiNAC) continues to anchor wired/wireless corporate-network admission for the ~70% of enterprises that retain a meaningful office-LAN footprint. Modern overlays — Zscaler Private Access, Cloudflare Access, Netskope ZTNA, Cisco Duo Network Gateway, Tailscale, NetFoundry — replace per-application VPN tunnels with identity-aware proxies that enforce per-resource authorisation rather than per-subnet trust. The market category Gartner calls **Security Service Edge (SSE)** combined with **SASE** (Secure Access Service Edge) is the network-layer manifestation of Zero Trust, with Zscaler ($2.5B+ revenue FY25), Netskope, Palo Alto Networks Prisma Access, and Cloudflare One as commercial leaders.

**Endpoint and Workstation Enforcement**: Operating-system-level access control — Windows Access Control Lists with the Security Descriptor model, macOS sandbox and Transparency Consent and Control (TCC), Linux capabilities, SELinux/AppArmor mandatory-access-control modules, iOS/Android app sandboxing with permission prompts — represents the OS-vendor edge of the authorisation problem. Microsoft Defender for Endpoint, CrowdStrike Falcon, SentinelOne Singularity, Palo Alto Cortex XDR contribute *posture signals* (patch level, EDR-agent health, encryption state, known-bad-process presence) that flow upward into IdP conditional-access engines for Zero Trust evaluation.

### Threat Model and Failure Modes

- Access control systems are themselves attack targets, and the empirical record reveals a stable taxonomy of failure modes that practitioners must defend against.
- **Authentication Bypass**: Direct circumvention of the authentication mechanism, typically through misconfigured federation (allow-listing the wrong issuer, accepting unsigned tokens, mis-validating audience claims), broken cryptographic protocol implementations (algorithm-confusion attacks on JWT, signature-stripping in SAML, downgrade attacks on TLS), or session-token theft (Lapsus$ 2022 across Nvidia/Samsung/Microsoft/Okta, the September 2023 Okta support-portal session-cookie exfiltration affecting 134 customers including Cloudflare and 1Password, the January 2024 Microsoft Storm-0558 federation-signing-key compromise affecting Outlook.com and Exchange Online).
- **Authorisation Bypass / Privilege Escalation**: Subjects gaining permissions they should not hold — through Insecure Direct Object References (IDOR, OWASP Top 10 A01:2021), missing function-level authz checks, role-explosion errors granting excess permissions to over-broad roles, IAM trust-policy misconfigurations permitting unintended principals to assume privileged roles. The 2019 Capital One breach (Paige Thompson, ~$80M fine) turned on a misconfigured AWS IAM role attached to a WAF metadata-service-accessible EC2 instance — a textbook confused-deputy chain.
- **Confused Deputy**: A privileged subject coerced into exercising authority on behalf of an unprivileged caller. OAuth's *redirect URI* parameter, when validated loosely, is a perennial confused-deputy vector; the same problem appears in cross-tenant cloud APIs (the 2022 Microsoft Synapse confused-deputy across customer tenants), in SSRF-into-IMDS attacks (mitigated by IMDSv2 since 2019), and in agent-tool-use flows where an agent is induced to call privileged tools on prompt-injected instructions.
- **Session and Token Theft**: Increasingly the dominant breach vector. Bearer tokens (OAuth access tokens, OIDC ID tokens, SAML assertions, session cookies) are by definition exercisable by any holder; theft equals authentication. Mitigations include short token lifetimes (5-60 minutes for access tokens), refresh-token rotation, mTLS-bound tokens (RFC 8705), DPoP (RFC 9449), continuous-access-evaluation (Microsoft CAE, since 2021) and step-up authentication for sensitive operations. The Snowflake 2024 incident exposed how a stale credential without MFA could compromise 165+ tenant accounts when re-used by an attacker holding infostealer-malware-derived credentials.
- **Dormant and Orphaned Accounts**: Empirical research (Varonis 2024 Data Risk Report) finds median 23% of enterprise identities unused for 90+ days; orphaned service accounts after employee departure or service decommissioning routinely persist for years. Each dormant account is a latent breach precursor. JIT provisioning (Okta Workflows, AWS IAM Identity Center session policies, HashiCorp Boundary ephemeral credentials) and time-bound role assumption mitigate but do not eliminate the problem.
- **Secret Sprawl**: Leaked credentials remain a leading entry vector — GitGuardian's 2024 *State of Secrets Sprawl* report counted 23.8 million new exposed secrets across public GitHub commits, a 25% YoY increase. Mitigations include git-hook secret-scanning (truffleHog, gitleaks, GitGuardian Shield), pre-receive hooks on managed Git, and short-lived workload identity (AWS IAM Roles Anywhere, GCP Workload Identity Federation, Azure Workload Identity, SPIFFE/SPIRE) replacing long-lived service-account keys.
- **Policy Misconfiguration**: The empirically dominant cause of cloud-access breaches. CIEM data from Microsoft Entra Permissions Management, Sonrai, and Wiz consistently shows 95%+ of granted cloud permissions are unused; the corresponding **blast radius** of a compromised principal vastly exceeds business requirement. AWS IAM Access Analyzer, Azure AD Privileged Identity Management, and GCP Policy Analyzer surface misconfigurations programmatically; the underlying problem is that human policy authors struggle with the combinatorial complexity of fine-grained permissions.
- **Insider Threat**: Authorised subjects abusing their authority — the historically intractable problem that even perfect external defences cannot solve. Controls include separation of duties (no single subject completes a critical transaction), least-privilege enforcement, just-in-time elevation with auditable approval workflows, user and entity behaviour analytics (UEBA from Microsoft Sentinel, Splunk UBA, Exabeam, Vectra) and ITDR (Identity Threat Detection and Response — a 2024 Gartner-named category occupied by Silverfort, Crowdstrike Identity Protection, Permiso, Push Security).
- **Cryptographic Failures**: Weak algorithms (MD5/SHA-1 in legacy SAML/Kerberos), poor key management (long-lived signing keys, unrotated KDC service-account hashes facilitating Golden Ticket and DC Sync attacks), missing certificate validation in service-to-service authentication. Active Directory's *krbtgt* account key (used to sign all Kerberos TGTs) is the canonical example: failure to rotate it after a domain-controller compromise enables persistent Golden Ticket forgery for years.

### Zero Trust Architecture (NIST SP 800-207)

The strategic re-framing of access control in the cloud era is **Zero Trust**: the rejection of the historical assumption that subjects inside the network perimeter can be trusted more than those outside, in favour of **continuous, resource-centric, identity-driven authorisation for every request**. The reference text is [[NIST SP 800-207]] (Rose, Borchert, Mitchell, Connelly, 2020), which enumerates seven tenets:

1. All data sources and computing services are considered resources.
2. All communication is secured regardless of network location.
3. Access to individual enterprise resources is granted on a per-session basis.
4. Access is determined by dynamic policy including observable state of client identity, application/service, and the requesting asset.
5. The enterprise monitors and measures the integrity and security posture of all owned and associated assets.
6. All resource authentication and authorisation are dynamic and strictly enforced before access is allowed.
7. The enterprise collects as much information as possible about the current state of assets, network infrastructure, and communications and uses it to improve its security posture.

The model's industrial blueprint is Google's **BeyondCorp** programme (Ward & Beyer 2014, Spear et al. 2016, Cittadini et al. 2018): a six-year migration that eliminated Google's internal VPN by treating every internal application as internet-facing and gating access on device-trust signals plus user identity. Microsoft's **Zero Trust Maturity Model** (Initial → Advanced → Optimal across identity, endpoints, applications, network, infrastructure, data pillars) and the **CISA Zero Trust Maturity Model v2.0** (2023, five pillars: Identity, Devices, Networks, Applications and Workloads, Data, with cross-cutting Visibility-and-Analytics, Automation-and-Orchestration, Governance) operationalise the NIST guidance for, respectively, commercial customers and U.S. federal agencies. CISA's model is mandatory under Executive Order 14028 and OMB M-22-09 for federal civilian agencies by end of FY2024, with the UK's Government Security Group equivalent expected to align by 2027.

Zero Trust is not a product but an architectural shift: it requires **continuous authentication** (re-evaluating identity confidence on policy-defined cadence), **device posture assessment** (Endpoint Detection and Response signals feeding the PDP), **microsegmentation** (network-layer permission instead of broad subnet trust), and **rich telemetry** (every authorisation decision logged, analysed, and replayed for anomaly detection). Industry adoption per Gartner 2024 has reached 63% of large enterprises *initiating* Zero Trust programmes, with 21% reporting *mature* deployment.

### Components and Architecture

- The canonical reference architecture decomposes an access control system into eight collaborating components:
- **Policy Administration Point (PAP)**: The authoring and lifecycle-management surface for policies. Modern PAPs (Okta Workflows, AWS IAM console, OPA Bundle Server, Styra DAS, Auth0 Rules, OpenFGA modeling DSL) provide policy-as-code editors with version control, dry-run simulation, and approval workflows. Mature PAPs integrate with GitOps pipelines such that policy changes flow through pull-request review with mandatory reviewers and SAST-style policy linting (Checkov, KICS, Conftest).
- **Policy Decision Point (PDP)**: The evaluator that, given a request context, computes a permit/deny decision against the active policy set. Deployment patterns vary from co-located sidecar (OPA-as-sidecar, Cerbos sidecar) to centralised service (AWS IAM Service, Okta Authorisation Server, OpenFGA cluster) to fully distributed (Zanzibar-style cross-region replication with snapshot consistency). Latency budgets dictate placement: sub-millisecond requirements (high-frequency API gateways) drive co-location, while strong consistency requirements (financial transactions, regulated data) drive centralisation.
- **Policy Enforcement Point (PEP)**: The gateway, proxy, or in-application hook that consults the PDP and applies its decision to the request. Examples include Envoy filters in service meshes, Kong plugins in API gateways, Spring Security interceptors in JVM applications, custom resource validators in Kubernetes admission webhooks.
- **Policy Information Point (PIP)**: Sources of attributes consulted during evaluation — directory services (LDAP, AD), HR systems (Workday for organisational hierarchy), IT asset management (ServiceNow CMDB), device posture systems (Microsoft Intune, Jamf for macOS, CrowdStrike for endpoint signals), threat intelligence feeds (location reputation, IP-block lists). Modern PIPs cache aggressively (5-60 second TTLs) to keep authz latency bounded.
- **Identity Provider (IdP)**: The authoritative source of subject identity. Single IdP organisations are exceptional; large enterprises typically run multi-IdP topologies federating between cloud (Entra ID, Okta) and on-premises (Active Directory) with broker layers (PingFederate, ForgeRock OpenIG) reconciling differences.
- **Audit Log**: An append-only, tamper-evident record of every authorisation decision and policy change. Modern audit pipelines stream to SIEM (Splunk, Sentinel, Chronicle, Elastic Security) and to immutable storage (S3 Object Lock, Azure Immutable Blob, GCP Bucket Lock). Cryptographic notarisation (Sigstore Rekor, OpenZiti, blockchain anchoring) is emerging for high-assurance scenarios.
- **Session Manager**: Maintains the bound state between an authenticated subject and a continuing interaction — session cookies, refresh-token rotation, step-up authentication triggers. Session-manager weakness is the most common modern access-control failure: the Okta 2023 support-portal breach, the Microsoft 2023 Midnight Blizzard incident, and the Snowflake 2024 mass-credential incident all turned on session-token theft.
- **Token Service**: Mints and validates the bearer tokens (OAuth access tokens, OIDC ID tokens, SAML assertions, JWTs, macaroons, biscuits) that move authorisation context across service boundaries. JWT-specific concerns (algorithm-confusion attacks, key-rotation hygiene, audience-claim validation) have driven the rise of mTLS-bound tokens (RFC 8705) and DPoP (RFC 9449 Demonstrating Proof of Possession) as phishing-resistant alternatives to bare bearer tokens.
- **Consent and Delegation Layer**: Where authorisation decisions involve third parties acting on behalf of a principal (OAuth's *Resource Owner*, OIDC's End-User, Open Banking's PSU), an explicit consent surface captures and records the user's authorisation grant. Modern consent layers (Auth0 Consent Page, Curity Consent Service, ForgeRock Consent Receipt) integrate Kantara Initiative's Consent Receipt v1.1 specification (2017) and GDPR Article 7 requirements for evidenced, withdrawable, granular consent. Agent-delegation consent UX remains an active research and product area: how to render to a human the question *do you authorise this AI agent to read your emails for the next 10 minutes?* in a way that produces genuine informed consent.
- **Risk Engine / Behavioural Analytics**: A subsystem that produces a continuously-updated risk score for each authenticated session, consumed by the PDP as one input among many. Risk inputs include device fingerprint stability, geolocation plausibility (impossible-travel detection), known-bad-IP signals, behavioural-biometric drift, password-leak intelligence (Have I Been Pwned API, SpyCloud, Recorded Future). Microsoft Entra Identity Protection, Okta ThreatInsight, Cisco Duo Risk-Based Authentication, BioCatch, and IBM Trusteer dominate the commercial market. Risk-score-driven step-up authentication (require fresh MFA when risk exceeds threshold) is the dominant operational pattern.

### Use Cases / Major Families

- **Healthcare and Clinical Access**: Hospital electronic health records (Epic, Cerner/Oracle Health, Meditech, InterSystems) require role-based break-the-glass workflows balancing rapid clinical access with HIPAA accountability; FHIR-based SMART-on-FHIR authorisation (HL7 SMART App Launch v2 spec 2022) provides the OAuth-derived authorisation profile used by ~3,000+ healthcare apps.
- **Financial Services and Open Banking**: PSD2 / Open Banking deployments use Financial-grade API (FAPI) 1.0 Advanced and FAPI 2.0 (OpenID Foundation, finalised 2023) profiles of OAuth 2.0 to provide regulated third-party access with mTLS-bound tokens; UK Open Banking serves ~12 million active users (Q4 2025); UK Pay.UK New Payments Architecture access control deploys FAPI 2.0 patterns.
- **Government and Defence**: U.S. federal Personal Identity Verification (PIV) and U.S. Department of Defense Common Access Card (CAC) provide smart-card-backed access for ~5 million federal employees and contractors; UK HMG SC/DV clearance enforcement integrates with secure-by-design access controls in classified networks; Five Eyes intelligence-sharing relies on cross-domain access control gateways with Bell-LaPadula heritage.
- **Workforce IAM**: The classic enterprise pattern — Okta Workforce Identity, Microsoft Entra ID, Ping Identity for employee SSO, joiner-mover-leaver lifecycle, MFA enforcement, and conditional access. Driving spend approximately $19 billion globally in 2025 per Gartner.
- **Customer Identity and Access Management (CIAM)**: B2C consumer-scale identity — Okta Customer Identity (formerly Auth0), Microsoft Entra External ID, ForgeRock CIAM, AWS Cognito. Differentiated from workforce IAM by scale (100M+ users common), self-service registration, social-login federation, and progressive profiling. Market $13 billion 2025 per Forrester, projected $25 billion 2030.
- **Privileged Access Management (PAM)**: Just-in-time elevation, session recording, credential vaulting for administrative access — CyberArk, BeyondTrust, Delinea (Thycotic+Centrify), HashiCorp Boundary, Teleport. Critical for ransomware defence: 80%+ of major breaches involve privileged-credential abuse per Mandiant M-Trends 2024.
- **API and Service Authorisation**: Fine-grained per-call authz for microservices and public APIs — OpenFGA, SpiceDB, Cerbos, Topaz, Oso, AWS Verified Permissions with Cedar.
- **Data Access Governance**: Row-level and column-level access in data lakes and warehouses — Immuta, Privacera, Okera (acquired by Databricks 2023), AWS Lake Formation, Snowflake's row access policies, BigQuery column-level security.
- **Cloud Infrastructure Entitlement Management (CIEM)**: Right-sizing the long-tail of cloud-IAM permissions — Permiso, Sonrai, Ermetic (acquired by Tenable 2023), Wiz CIEM, Microsoft Entra Permissions Management. Addresses the empirical fact that 95%+ of granted cloud permissions are unused (Microsoft 2023 State of Cloud Permissions).
- **Secrets Management**: Adjacent but distinct — HashiCorp Vault, AWS Secrets Manager, Azure Key Vault, Doppler, 1Password Secrets Automation, Infisical. Secrets management is the dual problem of access control: where access-control governs the right to act, secrets management governs the credentials that permit acting.
- **Physical Access Control Systems (PACS)**: HID Global, ASSA ABLOY (Aperio, HES), Allegion, dormakaba, Gallagher. Increasingly integrated with logical access through unified credential platforms (Okta+ASSA ABLOY, HID Origo, BlueDiamond).
- **Agent and AI Authorisation (emerging 2024-2026)**: Authorisation for autonomous AI agents acting on behalf of principals — MCP authorisation drafts, Anthropic's Claude tool-use scoping, OpenAI Operator delegation patterns, LangChain's auth callbacks, Auth0's GenAI authorisation product (announced 2024).

### Operational Patterns and Governance Practice

Beyond technical architecture, the operational lifecycle of access control determines whether the designed model survives contact with real organisations. Mature practice has converged on a set of canonical patterns.

**Joiner-Mover-Leaver (JML) Lifecycle**: The HR-system-anchored process by which identities are provisioned at hiring (joiner), reconfigured at role change (mover), and de-provisioned at termination (leaver). Mature implementations integrate Workday/SuccessFactors/SAP HCM with IGA (Identity Governance and Administration) platforms — SailPoint IdentityNow, Saviynt, Okta Identity Governance (formerly atSpoke/Spera, then native 2023), Microsoft Entra ID Governance, Omada — that translate HR events into IAM provisioning actions across hundreds of downstream applications. The empirical pain points are *mover* events (role changes routinely *add* permissions without removing prior ones, producing access accumulation) and *leaver* events (timely de-provisioning across long-tail applications). The 2019 Verkada breach turned partly on a former employee retaining valid credentials post-termination.

**Access Reviews and Recertification**: Periodic (typically quarterly or annual) review by accountable managers of which subjects retain which entitlements, with affirmative re-approval required to retain access. SOX, HIPAA, PCI DSS, ISO 27001, and FedRAMP all mandate access reviews; SailPoint, Saviynt, and ServiceNow IRM dominate the tooling. The practice's chronic weakness is *rubber-stamp reviews* — managers approving en bloc without genuine evaluation. Modern systems address this with risk-prioritised reviews (review only entitlements above a risk threshold), peer comparison (highlight outliers — subjects holding entitlements unusual for their role peers), and usage-based filtering (review only entitlements actually used in the period).

**Just-in-Time (JIT) Elevation**: The discipline of granting privileged access only for the duration of an operational need, with auditable approval and time-boxed expiration. Microsoft Entra Privileged Identity Management (PIM), AWS IAM Identity Center session policies, Okta Workflows, HashiCorp Boundary, Teleport, BeyondTrust, and CyberArk Cloud Entitlements all support JIT patterns. Strong implementations require dual approval for break-glass elevations and emit detailed audit events recording the business justification.

**Break-Glass Procedures**: The escape hatch for legitimate emergency access (incident response, recovery from misconfiguration that locked legitimate operators out) that bypasses standard authorisation paths. Mature implementations require multi-party authorisation (typically 2-3 distinct human approvers), generate high-priority alerts to security operations, time-box the elevated session, and reconstruct the full session for after-action review. Google's *administrative justification* model (Cloud Audit Logs require explicit business justification for production access) and AWS's *root-account-credential-vaulting* practice are reference patterns.

**Workload and Non-Human Identity Governance**: The discipline applied to service accounts, CI/CD pipelines, agentic AI workloads, RPA bots, and machine-to-machine integrations. Standard pattern is ephemeral, scoped, workload-identity-federation-attested credentials: SPIFFE/SPIRE in Kubernetes, AWS IAM Roles Anywhere with X.509 trust anchors, GCP Workload Identity Federation, Azure Workload Identity, HashiCorp Vault dynamic secrets. The CyberArk 2024 research finding of a 45:1 non-human:human identity ratio in mature cloud estates establishes that workload-identity governance is now *the* governance frontier.

**Audit and Telemetry Pipelines**: Every authorisation decision and every policy change must flow to immutable storage and to detective controls. Standard pipeline: PEP/PDP emit structured events (CloudEvents, OpenTelemetry-compatible) → message bus (Kafka, AWS Kinesis, Azure Event Hubs) → SIEM (Splunk Enterprise Security, Microsoft Sentinel, Google SecOps/Chronicle, Elastic Security, Sumo Logic, IBM QRadar) → immutable storage (S3 Object Lock, Azure Immutable Blob, GCP Bucket Lock) → analytics layer (UEBA / ITDR detection rules). High-assurance scenarios layer cryptographic notarisation (Sigstore Rekor transparency log, blockchain anchoring) to provide tamper-evidence beyond storage-layer immutability.

**Continuous Compliance Validation**: Real-time evidence collection demonstrating that authorisation controls operate as designed — Drata, Vanta, Secureframe, Tugboat Logic, Hyperproof, AuditBoard automate evidence collection for SOC 2, ISO 27001, HIPAA, PCI DSS, and FedRAMP audits. The 2023-2025 compliance-automation market expanded 70%+ as organisations confronted simultaneous EU NIS2, DORA, UK Cyber Security and Resilience Bill, and U.S. SEC disclosure regimes.

### Industry Deployment Statistics (Q1 2026)

Quantitative scale matters for an architectural domain whose decisions touch every digital transaction. The following figures are drawn from vendor disclosures (10-K filings for public companies, press releases for private), industry analyst reports (Gartner Magic Quadrants 2025, Forrester Waves 2025, IDC MarketScapes 2025), and standards-body adoption metrics. All figures are Q1 2026 or most-recent-available.

- **Global IAM market size**: ~$50 billion annual spend (Gartner 2025 forecast), 14-16% YoY growth, projected to reach $95 billion by 2030.
- **Microsoft Entra ID monthly active users**: ~500 million MAU across commercial tenants, integrated into 400M+ Microsoft 365 commercial seats; Entra ID processes ~24 billion authentication events daily per Microsoft Digital Defense Report 2025.
- **Okta total customers**: ~18,800 enterprise customers post-Auth0 acquisition (FY25 10-K), ~$2.6 billion FY25 revenue, ~17,500 employees; Auth0 handles ~100 million daily logins.
- **Active Directory deployment**: ~95% Fortune 500 penetration, ~1.5 billion AD user objects globally, ~70% of enterprise authentication originates in AD.
- **AWS IAM scale**: 50,000+ documented actions across 300+ services; AWS Identity team processes ~400 million authorisation decisions per second across all customer accounts; IAM Access Analyzer's Zelkova engine has analysed ~10 trillion policies cumulatively since 2018.
- **Kubernetes RBAC**: deployed in ~5 million production clusters (CNCF Annual Survey 2025); ~95% of clusters have RBAC enabled (default since 1.8 in 2017).
- **Open Policy Agent**: ~8,500 documented production adopters (Styra/OPA community survey 2024), CNCF Graduated since 2021, downloads exceed 250 million.
- **Zanzibar at Google**: 10 million authorisation checks per second (2019 paper baseline; current internal scale not publicly disclosed but estimated 2-3x higher), 2 trillion stored relation tuples, sub-10ms p99 latency across global regions.
- **OpenFGA adoption**: ~5,000 production deployments (CNCF Sandbox metrics), donated by Auth0/Okta 2022; commercial alternatives AuthZed SpiceDB (~$10M ARR estimated 2025), Topaz (Aserto), Warrant (WorkOS).
- **WebAuthn / Passkey scale**: ~8.5 billion passkey-capable devices in circulation (FIDO Alliance Q1 2026), ~30% of major consumer sites support passkey sign-in, ~600 million Google accounts have a passkey enrolled per Google's May 2024 disclosure.
- **Multi-Factor Authentication adoption**: ~64% of enterprise users (Microsoft Digital Defense Report 2024), up from 22% in 2017; phishing-resistant MFA adoption ~28% per CISA 2024 survey.
- **PAM market**: ~$3.4 billion annual spend (Gartner 2025), 12% YoY growth, dominated by CyberArk (~$1B revenue), BeyondTrust, Delinea.
- **CIAM market**: ~$13 billion annual spend (Forrester 2025), projected ~$25 billion by 2030.
- **CIEM (cloud entitlements)**: fastest-growing IAM sub-segment at +38% YoY, ~$1.2 billion 2025 spend; empirical "permissions gap" exceeds 95% (granted permissions never exercised) per Microsoft Entra Permissions Management research.
- **Identity-related breaches**: ~80% of major breaches involve credential abuse, identity-based attack, or privileged-account misuse (Mandiant M-Trends 2024); ~67% involve weak or stolen passwords (Verizon 2024 DBIR).
- **Cost of breaches**: average $4.88 million per incident globally; identity-driven breaches average $4.81 million (IBM Cost of a Data Breach Report 2024).
- **Non-human identity ratio**: ~45 non-human identities per human identity in mature cloud estates (CyberArk 2024 research), projected to reach 100:1 by 2028 driven by agentic AI workloads.
- **Secret sprawl**: 23.8 million new exposed secrets on public GitHub in 2024 alone (GitGuardian *State of Secrets Sprawl 2024*).
- **Physical access**: ~280 million HID Global credentials issued cumulatively; ~25 million ASSA ABLOY Aperio wireless lock deployments; mobile-credential adoption (HID Origo, ASSA ABLOY BlueDiamond) growing at ~35% YoY replacing physical badges.

### Academic Context: Theoretical Foundations and Research Milestones

Access control research occupies a distinctive position at the intersection of formal methods, distributed systems, cryptography, and human-computer interaction. The field's intellectual lineage runs through six landmark contributions.

**Saltzer & Schroeder (1975)**: *The Protection of Information in Computer Systems* (*Proceedings of the IEEE* 63:9, 1278-1308) remains the most cited paper in computer security half a century after publication. Its eight design principles — economy of mechanism, fail-safe defaults, complete mediation, open design, separation of privilege, least privilege, least common mechanism, psychological acceptability — frame every contemporary discussion of authorisation architecture.

**Harrison, Ruzzo & Ullman (1976)**: *Protection in operating systems* (CACM 19:8) established the undecidability of the safety problem for general access-control matrices, motivating the restriction to decidable subclasses (RBAC, ABAC) that dominate practice.

**Sandhu, Coyne, Feinstein & Youman (1996)**: *Role-Based Access Control Models* (IEEE Computer 29:2) consolidated a decade of NIST and academic work on RBAC into the framework that became ANSI INCITS 359-2004. Sandhu's continuing leadership at the Institute for Cyber Security (University of Texas at San Antonio) anchored the academic-industrial bridge through the 2000s.

**Hu, Ferraiolo, Kuhn et al. (NIST SP 800-162, 2014)**: *Guide to Attribute Based Access Control (ABAC) Definition and Considerations* canonicalised ABAC for U.S. federal agencies and provided the vocabulary (subject, resource, action, environment attributes; policy decision/enforcement/information/administration points) that the wider industry adopted.

**Pang, Rama, Akhtar, Bauer, Bhargava, Hardt, Jiang, Kueppers, Liu, Madhuri, Marchini, Martignoni, Sivasubramaniam, Stamatoulakis, Steiner, Veuthey, Watson, Watson, Wenz, Williams, Yegnaraman, Zou & Zwilling (2019)**: *Zanzibar: Google's Consistent, Global Authorization System* (USENIX ATC 2019) was arguably the most consequential industrial access-control paper of the 2010s. It established ReBAC's viability at planetary scale and catalysed the entire OpenFGA/SpiceDB/Topaz/Warrant ecosystem.

**Backes, Bolignano, Cook, Dodge, Gacek, Luckow, Rungta, Tkachuk & Varming (2018)**: *Semantic-based Automated Reasoning for AWS Access Policies using SMT* (FMCAD 2018) established that formal methods could be deployed at hyperscale-cloud scale to provide actionable security guarantees, instantiated as the Zelkova engine inside AWS IAM Access Analyzer.

Doctoral programmes producing the field's leading researchers cluster at Carnegie Mellon (CyLab), Stanford (Applied Crypto Group), MIT (CSAIL), Berkeley (RISELab), ETH Zurich (Information Security Group), Royal Holloway (Information Security Group — see UK Context below), and Imperial College London. Major venues include IEEE Symposium on Security and Privacy (Oakland S&P), USENIX Security, ACM CCS, NDSS, and the ACM Symposium on Access Control Models and Technologies (SACMAT — the field's home conference, in its 31st year by 2026).

**Active Research Frontiers (2024-2026)**:

- **ReBAC scaling beyond Zanzibar**: improved Zookies consistency primitives; geo-replicated authorisation graphs with sub-10ms p99 latency; algebraic compositionality of policies across federated tenants.
- **Formal verification of policy languages**: mechanised proofs of soundness for Rego (ongoing work at AWS Security Analytics and Oxford); decidability boundaries for higher-order policy combinators in Cedar; SMT-friendly intermediate representations.
- **Cryptographic enforcement**: attribute-based encryption (ABE) as a foundation for cryptographically-enforced authorisation; functional encryption for predicate evaluation; zero-knowledge proofs of authorisation eligibility without revealing attributes.
- **Behavioural authorisation**: ML-driven risk scoring with calibrated false-positive rates; behavioural-biometric fusion (keystroke dynamics, mouse trajectory, mobile-sensor signatures) into continuous-authentication confidence.
- **Agent and AI authorisation**: scoped capability delegation chains; prompt-injection-resistant tool authorisation; revocation primitives for long-running agents; consent UX for agent actions.
- **Quantum-resistant authentication**: hybrid classical-PQ WebAuthn (Level 4 draft); migration plans for Kerberos and SAML to PQ signatures; backward compatibility during the multi-decade transition.
- **Privacy-preserving access logs**: differential-privacy mechanisms for audit logs that support investigation without exposing personal access patterns; oblivious-RAM-based audit query.

### Current Landscape (2026): Vendors, Standards, and Market Structure

By Q1 2026 the global Identity and Access Management market exceeds $50 billion annual spend (Gartner forecast, December 2025), growing 14-16% year-over-year with the strongest growth in CIEM (cloud-infrastructure entitlement management, +38% YoY), agent/AI authorisation (+200%+ YoY from a small base), and ReBAC platforms (+45% YoY).

**The Five Workforce IAM Leaders**: Microsoft Entra ID (formerly Azure AD, ~500 million monthly active users, embedded in Microsoft 365's 400M+ commercial seats), Okta Workforce Identity (~18,800 enterprise customers post-Auth0 acquisition, ~$2.6 billion FY25 revenue), Ping Identity (post-Thoma Bravo private, merged with ForgeRock 2023, focused on large-enterprise on-premises-to-cloud bridging), JumpCloud (~200,000 organisations, cloud-directory positioning for SMB), CyberArk Identity (post-CyberArk's Idaptive acquisition, leveraging PAM adjacency). The market structure is **bifurcated**: Microsoft Entra dominates organisations standardised on Microsoft 365 (45%+ market share by seat); Okta dominates Microsoft-agnostic enterprises and high-growth tech companies (~22% share by revenue); the remainder fragments across niche specialists.

**CIAM Leaders**: Okta Customer Identity (Auth0 brand), Microsoft Entra External ID, ForgeRock CIAM (now under Ping), AWS Cognito (volume but limited features), Transmit Security (post-Series A, biometric/passwordless focus). Differentiation increasingly turns on passkey support, fraud-detection integration (BioCatch, Sift, Forter signals into authz decisions), and AI-agent authorisation roadmap.

**PAM Leaders**: CyberArk (~$1 billion revenue, leader by Gartner Magic Quadrant 2025), BeyondTrust (private equity owned, broad portfolio), Delinea (Thycotic + Centrify, TPG-owned), HashiCorp Boundary (open-source-led, infrastructure-team-oriented), Teleport (open-source, cloud-native, ~3,000 customers).

**ReBAC / Fine-Grained Authz Leaders**: AuthZed SpiceDB (commercial Zanzibar implementation, raised Series B 2024), OpenFGA (CNCF Sandbox, Okta/Auth0 origin), Aserto Topaz (open source 2023), WorkOS Warrant (acquired 2024), Cerbos (UK-founded, fine-grained authz library), Oso (acquired by HashiCorp 2025, integrated into Boundary).

**Policy-as-Code Leaders**: Open Policy Agent (CNCF Graduated 2021, 8,500+ adopters), Styra DAS (commercial OPA platform), AWS Cedar (open-sourced 2023, underpins AWS Verified Permissions), HashiCorp Sentinel (Terraform/Vault native), Kyverno (Kubernetes-native, CNCF Incubation).

**CIEM Leaders**: Microsoft Entra Permissions Management (formerly CloudKnox), Sonrai Security, Permiso, Tenable Cloud Security (Ermetic acquisition), Wiz CIEM. CIEM is the fastest-growing IAM sub-market because the empirical "permissions gap" — granted vs. used permissions — exceeds 95% in mature cloud estates, providing immediate quantifiable risk reduction.

**Standards Bodies and Reference Frameworks**: NIST (SP 800-162 ABAC, SP 800-207 Zero Trust, SP 800-63 Digital Identity Guidelines updated 2024), IETF (OAuth Working Group, GNAP successor to OAuth in active draft 2024-2026), W3C (WebAuthn Level 3, DID Core 1.0, VC Data Model 2.0), OASIS (XACML 3.0, SAML 2.0), CNCF (OPA, OpenFGA, Cedar consideration), FIDO Alliance (FIDO2, passkey synchronisation guidance), CISA (Zero Trust Maturity Model v2.0, MFA mandate), UK NCSC (Cloud Security Principles, Phishing-Resistant MFA Guidance 2023).

**Notable Incidents Driving 2024-2026 Spend**: Okta support-portal breach (October 2023, session-token exfiltration), Microsoft Midnight Blizzard / Storm-0558 (January 2024, federation-token forgery via stolen signing key), Snowflake credential-stuffing campaign (Q2 2024, affecting 165+ customers including AT&T, Ticketmaster, Santander), Change Healthcare (February 2024, $2.45 billion estimated impact, lack of MFA on Citrix portal). Each incident accelerated industry-wide adoption of phishing-resistant MFA, continuous-access-evaluation, and ITDR (Identity Threat Detection and Response) tooling.

### UK Context

The United Kingdom occupies a globally significant position in access control through three complementary axes: an exceptional academic concentration in cryptography and information security, a vigorous SME ecosystem in cyber tooling, and a maturing public-sector practice anchored by the National Cyber Security Centre.

**Academic Powerhouses**: The **Information Security Group at Royal Holloway, University of London** (founded 1990 by Peter Wild, Fred Piper, Henry Beker) hosts the longest-established UK doctoral programme in cryptography and information security, awarding ~30 PhDs per year and counting among its alumni the founders of NCC Group, the Bristol cryptography ecosystem, and senior staff at GCHQ. Royal Holloway's research strength in cryptographic protocols (Cas Cremers, formerly; Martin Albrecht; Kenneth Paterson — though Paterson moved to ETH Zurich 2018) sustains UK authority in authentication-protocol formal analysis. **Imperial College London**'s Department of Computing (Emil Lupu, Naranker Dulay, William Knottenbelt for blockchain access) drives policy-language and adaptive-authorisation research and runs the EPSRC-funded SECurity by Reconfigurable Adaptive Policy (SECRAP) programme. **University College London**'s Information Security Research Group (Steven Murdoch, George Danezis until departure, Sarah Meiklejohn, Nicolas Courtois) contributes to anonymous-credential, Tor, and authentication-token research and runs the UK's CDT in Cyber Security in partnership with Royal Holloway. **University of Oxford** hosts a CDT in Cyber Security (joint with NCSC funding) and the Department of Computer Science includes Cas Cremers (collaborating remotely), Ivan Flechais (HCI for security), and Sadie Creese (Global Cyber Security Capacity Centre). **University of Cambridge**'s Computer Laboratory contributes through Ross Anderson's legacy (until his death April 2024) of *Security Engineering* — the canonical practitioner textbook now in its 3rd edition — and continuing work by Frank Stajano (Pico authentication, *Resurrecting Duckling* security model), Markus Kuhn (TEMPEST/side-channel), and Alastair Beresford (mobile security). **University of Edinburgh**'s Laboratory for Foundations of Computer Science includes David Aspinall (proof-carrying authorisation) and the wider Edinburgh Cyber Security ecosystem benefits from the Bayes Centre and the Edinburgh-Heriot-Watt cyber innovation district.

**Northern English Industrial Concentration**: **Manchester** hosts the headquarters of NCC Group plc (FTSE 250 cyber consultancy founded 1999, ~2,500 staff, world-leading penetration-testing and access-control assessment practice), the Greater Manchester Cyber Foundry (joint Manchester Metropolitan / Lancaster / Salford / Manchester programme), and a growing concentration of identity-focused SaaS firms. **Leeds** anchors the cyber-security ecosystem around the Plexal Leeds outpost and a strong financial-services demand base (Yorkshire Building Society, First Direct's HSBC heritage). **Sheffield** hosts the Sheffield Cyber Cluster and the National Centre for Cyber Forensic Excellence at Sheffield Hallam. **Newcastle**'s Newcastle Helix and the **CyberFirst Newcastle** training cluster feed talent into both regional employers and the GCHQ Manchester office (opened 2019).

**Cerbos** (founded 2021 by Emre Baran and Charith Tangirala, headquartered London) is the UK's most prominent purpose-built authorisation start-up, providing an open-source fine-grained authz library with a commercial Cerbos Hub. **Pangea** (UK presence), **Tessian** (acquired by Proofpoint 2024), **Mimecast** (London-listed, $5.8 billion private equity acquisition 2022 by Permira) all contribute. **Onfido** (London-founded identity verification, ~$650M Entrust acquisition 2024) and **Yoti** (London-founded digital identity / age estimation) extend the UK's CIAM and identity-proofing footprint internationally.

**Public Sector and Regulatory Practice**: The **National Cyber Security Centre** (NCSC, formed 2016 as part of GCHQ) publishes the Cloud Security Principles whose principles 9 (secure user management) and 10 (identity and authentication) anchor public-sector access-control practice; the 2023 *Guidance on Phishing-Resistant MFA* drove rapid passkey adoption across central government. The **Government Digital Service** GOV.UK Sign In platform (replacing Verify, GA 2023, ~12M users by end-2025) operationalises a single-sign-on for government services with strong phishing-resistant MFA and is anticipated to underpin the forthcoming **UK Government Digital Identity Trust Framework** (draft 2023, parliamentary track 2025-2026). The **Cabinet Office Government Security Group** owns the Government Functional Standard GovS 007 for security and is working towards alignment with CISA's Zero Trust Maturity Model by 2027. The **CESG legacy** of architectural patterns (now NCSC-owned) and the **CHECK / CREST** professional-certification ecosystem supply the assurance fabric for HMG access-control deployments. **Open Banking** (since 2018) operationalised PSD2-style strong-customer-authentication for ~7 million UK consumers using OAuth 2.0 + FAPI profile + dynamic-linking, providing the global reference deployment for FAPI 2.0 financial-grade authorisation.

### Future Directions (2026-2030)

Five trajectories will shape access control through the late 2020s.

**Agent and AI Identity / Authorisation**: As autonomous agents become first-class principals (Anthropic Claude, OpenAI Operator/GPT-5.4 agents, Google Gemini Live agents, enterprise agentic workflows), access-control models must answer questions current systems cannot: *what authority does this agent inherit from its delegating principal? what scope-narrowing and revocation primitives apply? how is consent expressed and re-prompted as the agent's task evolves?* The Model Context Protocol (MCP) authorisation drafts, Anthropic's tool-use-scope mechanism, and emerging GNAP (Grant Negotiation and Authorization Protocol, IETF replacement for OAuth currently in late-stage drafting) all gesture at the agent-authz future. Expected market emergence: $2-5 billion annual spend by 2030.

**Passwordless and Passkey Standardisation**: With 8.5 billion passkey-capable devices in circulation by Q1 2026 (FIDO Alliance), the trajectory to passwordless-by-default for consumer services is set. Workforce passwordless lags but accelerates: Microsoft's 2025 *passwordless-first* announcement for Entra ID, Okta's 2024 Workforce Passkey GA, and the proliferation of platform authenticators (Windows Hello, Touch ID/Face ID, Android biometric) suggest 70%+ workforce passwordless adoption by 2030.

**Self-Sovereign Identity Mainstreaming**: The European Digital Identity Wallet (eIDAS 2.0, mandatory for member states by end-2026) will produce the first hundred-million-user deployment of W3C Verifiable Credentials. UK NHS Login DID pilots, the UK Government Digital Identity Trust Framework, and parallel programmes in Singapore (Singpass), India (Aadhaar e-KYC extensions), and Bhutan (NDI) will normalise wallet-based credential presentation. Access control systems will need to natively consume VCs as authorisation inputs.

**Post-Quantum Authentication**: NIST PQC standards FIPS 203 (ML-KEM), 204 (ML-DSA), 205 (SLH-DSA), and 206 (FN-DSA) finalised August 2024 set the cryptographic substrate for authentication's post-quantum transition. WebAuthn Level 4 (draft 2025) adds ML-DSA support; expect production passkey systems to ship hybrid classical-PQ signatures by 2027-2028. The transition is non-trivial: authenticator hardware lifecycles span 5-10 years, requiring careful migration planning.

**Formal Verification at Hyperscale**: AWS Cedar's Lean4 mechanised proof of decidability (2023) and IAM Access Analyzer's Zelkova SMT engine (since 2018) prefigure a future in which authorisation correctness is *proved* rather than *tested*. Expect comparable formal-methods deployments in Azure RBAC, GCP IAM, and OpenFGA by 2028, alongside academic-industry collaboration on machine-checked proofs for OPA Rego and Kubernetes RBAC.

**Operational Pressures**: Three counter-currents threaten the architectural cleanliness above. (a) **Agent sprawl** — the proliferation of non-human identities, with the 45:1 non-human:human ratio likely to reach 100:1 by 2028 — will strain IAM governance models built for human lifecycles. (b) **Tool consolidation** — the IAM market is mid-cycle for consolidation; expect 3-5 major M&A events 2026-2028 reducing the leader board from ~12 named vendors to ~6. (c) **Regulation divergence** — EU NIS2/DORA, U.S. SEC cyber-disclosure rules, UK Cyber Security and Resilience Bill (introduced 2025), Australian SOCI Act expansions, and similar Asia-Pacific regimes are converging in intent but diverging in detail, producing compliance complexity for multinational organisations.

**The Authorisation-as-a-Service Thesis**: A structural argument advanced by AuthZed, OpenFGA's commercial sponsors, and a broadening chorus of analysts holds that authorisation has reached the maturity inflection point that identity reached in the early 2010s — at which point it transitions from in-application library to dedicated managed service. The economic logic: every application redeveloping its own authz layer is wasteful and produces inconsistent security postures; centralising on a shared authorisation service (Zanzibar-style ReBAC, or PDP-as-a-service) amortises engineering investment and produces uniform audit/governance surfaces. The counter-argument — latency sensitivity, blast-radius concerns from a single authz dependency, fine-grained-policy authoring complexity — slows but does not negate the trend. Expect 2026-2030 to see the emergence of 2-3 dominant authorisation-as-a-service vendors, in the same way that Auth0, Okta, and Stytch came to dominate authentication-as-a-service.

**Policy-Language Convergence and Formal Verification**: The proliferation of policy languages (Rego, Cedar, XACML, OpenFGA model DSL, SpiceDB schema language, Casbin model, Cerbos YAML) creates an interoperability problem: organisations that adopt multiple authorisation tools struggle to translate policy across them. Expect 2026-2028 to see the emergence of intermediate representations (policy-as-IR analogous to LLVM IR for programming languages) and translation layers, alongside continued investment in mechanised verification of policy properties (Cedar's Lean4 proof of decidability, Zelkova's SMT-based property checking, emerging work on Rego formal semantics).

**Privacy-Preserving Authorisation**: A nascent but important trajectory: authorisation decisions that do not require the PDP to learn the attributes being evaluated. Techniques include zero-knowledge proofs of credential possession (anonymous-credential systems like Microsoft U-Prove, IBM Idemix), zk-SNARK-based attribute proofs (Aleo, Mina, Polygon ID), oblivious-RAM-based attribute lookups, and homomorphic encryption for attribute predicates. Production deployments remain rare (NHS Covid Pass 2021 in the UK was an early outlier; Mozilla's anonymous-credential prototype for ad measurement is recent) but the EU eIDAS 2.0 wallet may catalyse mainstream adoption by 2028-2029.

**Behavioural and Contextual Authorisation**: The integration of authentication-confidence, device-posture, geolocation, behavioural-biometric, and threat-intelligence signals into continuous risk-scored authorisation decisions. Microsoft Entra Conditional Access, Okta Adaptive MFA, Cisco Duo Risk-Based Authentication, BioCatch behavioural biometrics, and the broader CARTA (Continuous Adaptive Risk and Trust Assessment) framework articulated by Gartner since 2017 anticipate a future in which authorisation decisions are statistical-confidence-bounded rather than binary. The risk is *false-positive friction* — over-aggressive risk scoring impedes legitimate work — that has slowed mainstream adoption to date but is being addressed by improved ML calibration and explicit user-step-up flows.

### Research and Literature

**Foundational Works**:
1. Saltzer, J.H., & Schroeder, M.D. (1975). The Protection of Information in Computer Systems. *Proceedings of the IEEE*, 63(9), 1278-1308. DOI: 10.1109/PROC.1975.9939 [Eight design principles; 8,000+ citations]
2. Lampson, B.W. (1971). Protection. *Proceedings of the 5th Princeton Conference on Information Sciences and Systems*, 437-443. [Access matrix abstraction]
3. Harrison, M.A., Ruzzo, W.L., & Ullman, J.D. (1976). Protection in operating systems. *Communications of the ACM*, 19(8), 461-471. DOI: 10.1145/360303.360333 [Undecidability of the safety problem]
4. Bell, D.E., & LaPadula, L.J. (1973). Secure Computer Systems: Mathematical Foundations. MITRE Technical Report 2547, Vol. I. [MLS lattice model for confidentiality]
5. Biba, K.J. (1977). Integrity Considerations for Secure Computer Systems. MITRE Technical Report ESD-TR-76-372. [Integrity dual to Bell-LaPadula]
6. Clark, D.D., & Wilson, D.R. (1987). A Comparison of Commercial and Military Computer Security Policies. *Proceedings of the IEEE Symposium on Security and Privacy*, 184-194. DOI: 10.1109/SP.1987.10001 [Commercial integrity, well-formed transactions]
7. Brewer, D.F.C., & Nash, M.J. (1989). The Chinese Wall Security Policy. *IEEE Symposium on Security and Privacy*, 206-214. DOI: 10.1109/SECPRI.1989.36295 [Conflict-of-interest model]

**Models and Standards**:
8. Sandhu, R.S., Coyne, E.J., Feinstein, H.L., & Youman, C.E. (1996). Role-Based Access Control Models. *IEEE Computer*, 29(2), 38-47. DOI: 10.1109/2.485845 [RBAC framework basis for ANSI INCITS 359]
9. ANSI INCITS 359-2012. *Information Technology — Role Based Access Control*. American National Standards Institute. [Canonical RBAC standard]
10. Hu, V.C., Ferraiolo, D., Kuhn, R., et al. (2014). Guide to Attribute Based Access Control (ABAC) Definition and Considerations. *NIST Special Publication 800-162*. DOI: 10.6028/NIST.SP.800-162 [Canonical ABAC reference]
11. OASIS (2013). *eXtensible Access Control Markup Language (XACML) Version 3.0*. OASIS Standard, 22 January 2013. [PDP/PEP/PIP/PAP architecture]
12. Rose, S., Borchert, O., Mitchell, S., & Connelly, S. (2020). Zero Trust Architecture. *NIST Special Publication 800-207*. DOI: 10.6028/NIST.SP.800-207 [Canonical Zero Trust reference]

**Capability and Confused Deputy**:
13. Dennis, J.B., & Van Horn, E.C. (1966). Programming semantics for multiprogrammed computations. *Communications of the ACM*, 9(3), 143-155. DOI: 10.1145/365230.365252 [Capability semantics]
14. Hardy, N. (1988). The Confused Deputy: (or why capabilities might have been invented). *ACM SIGOPS Operating Systems Review*, 22(4), 36-38. DOI: 10.1145/54289.871709 [Confused-deputy problem]
15. Miller, M.S., Yee, K.P., & Shapiro, J.S. (2003). Capability Myths Demolished. Johns Hopkins University Systems Research Laboratory Technical Report SRL2003-02. [Capabilities versus ACL clarifications]

**Modern Zanzibar and ReBAC**:
16. Pang, R., Caceres, R., Burrows, M., Chen, Z., Dave, P., et al. (2019). Zanzibar: Google's Consistent, Global Authorization System. *Proceedings of the USENIX Annual Technical Conference*, 33-46. [Planet-scale ReBAC]
17. Carminati, B., Ferrari, E., Heatherly, R., Kantarcioglu, M., & Thuraisingham, B. (2009). A semantic web based framework for social network access control. *Proceedings of the 14th ACM Symposium on Access Control Models and Technologies (SACMAT)*, 177-186. DOI: 10.1145/1542207.1542237 [ReBAC formalisation]

**Formal Methods**:
18. Backes, J., Bolignano, P., Cook, B., Dodge, C., Gacek, A., Luckow, K., Rungta, N., Tkachuk, O., & Varming, C. (2018). Semantic-based Automated Reasoning for AWS Access Policies using SMT. *Proceedings of FMCAD 2018*, 1-9. DOI: 10.23919/FMCAD.2018.8602994 [Zelkova SMT engine in IAM Access Analyzer]
19. Cook, B. (2018). Formal Reasoning about the Security of Amazon Web Services. *Proceedings of CAV 2018*, LNCS 10981, 38-47. DOI: 10.1007/978-3-319-96145-3_3 [AWS formal-methods overview]
20. Anderson, R. (2020). *Security Engineering: A Guide to Building Dependable Distributed Systems* (3rd ed.). Wiley. ISBN: 978-1119642787. [Canonical practitioner reference]

**Authentication Protocols**:
21. IETF RFC 6749 (2012). *The OAuth 2.0 Authorization Framework*. D. Hardt (Editor). [OAuth 2.0 canonical]
22. IETF RFC 4120 (2005). *The Kerberos Network Authentication Service (V5)*. C. Neuman, T. Yu, S. Hartman, K. Raeburn. [Kerberos v5]
23. W3C (2024). *Web Authentication: An API for accessing Public Key Credentials Level 3*. W3C Working Draft. https://www.w3.org/TR/webauthn-3/ [WebAuthn / FIDO2]
24. OASIS (2005). *Security Assertion Markup Language (SAML) V2.0 Technical Overview*. OASIS Committee Draft. [SAML 2.0]

**Zero Trust and Practice**:
25. Ward, R., & Beyer, B. (2014). BeyondCorp: A New Approach to Enterprise Security. *;login: The USENIX Magazine*, 39(6), 6-11. [BeyondCorp founding paper]
26. CISA (2023). *Zero Trust Maturity Model Version 2.0*. Cybersecurity and Infrastructure Security Agency. https://www.cisa.gov/zero-trust-maturity-model [CISA ZTMM v2.0]
27. UK NCSC (2024). *Zero Trust Architecture Design Principles*. National Cyber Security Centre. https://www.ncsc.gov.uk/collection/zero-trust-architecture [NCSC ZT guidance]
28. ISO/IEC 27002:2022. *Information security, cybersecurity and privacy protection — Information security controls*. International Organization for Standardization. [Controls 5.15-5.18 access control]

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review
- **Verification**: NIST SPs, ANSI/OASIS/IETF/W3C standards cross-referenced; vendor market positions verified against Gartner 2025 Magic Quadrants and 2025 annual reports; UK academic positions verified against institutional staff pages and EPSRC grants databases
- **Regional Context**: UK academic institutions (Royal Holloway ISG, Imperial, UCL, Oxford, Cambridge, Edinburgh), Northern English industry (Manchester NCC Group / GCHQ; Leeds; Sheffield; Newcastle CyberFirst), HMG practice (NCSC, GDS, Cabinet Office GSG), commercial UK SMEs (Cerbos, Onfido, Yoti, Tessian) detailed
- **Production-Ready**: Complete OWL formal semantics across 5 axiom families plus property characteristics, comprehensive content coverage (theoretical models, identity substrates, architectural patterns, Zero Trust, components, use-cases, academic context, market landscape, UK context, future directions, references)
- **Authority Score**: 0.87 (foundational security-engineering literature, widely-adopted international standards, established commercial market with verified vendor data, distinguished UK academic and industrial ecosystem)

### Provenance

