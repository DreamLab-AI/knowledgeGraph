A pharmaceutical supply chain is the set of stages and organisations through which medicinal products are discovered, made, distributed and supplied to patients, and it is subject to package-level identification and verification rules in the United States and the European Union.[^1][^2][^3]

A European Parliament study divides the pharmaceutical global value chain into four key stages: discovery of new drugs through research and development, approval through clinical trials, manufacturing, and marketing and distribution. It splits manufacturing into the sourcing of key starting materials, the production of intermediates and active pharmaceutical ingredients (APIs), and the production of finished dosage forms such as pills or capsules.[^1]

## Integrity and traceability

The World Health Organization defines substandard medical products as those that do not meet quality standards and specifications, and falsified products as those that deliberately misrepresent their identity, composition or source. It says at least 1 in 10 medicines in low- and middle-income countries are substandard or falsified.[^4] The US Drug Supply Chain Security Act outlines steps to an interoperable electronic way to identify and trace certain prescription drugs at package level as they move through the supply chain, to prevent harmful drugs from entering it and to enable rapid removal if they do.[^2] In the European Union, the Falsified Medicines Directive (Directive 2011/62/EU) was published on 1 July 2011 and has applied since 2 January 2013. It requires safety features, a unique identifier and an anti-tampering device, on the outer packaging of medicines and strengthens record-keeping for wholesale distributors.[^3] The delegated Regulation (EU) 2016/161 and the medicine verification system it lays down apply from 9 February 2019.[^3]

## Supply risk

The European Parliament study says COVID-19 highlighted existing drug shortages in the EU, which have become more frequent over the last decade, and lists manufacturing problems, quality issues, unexpected spikes in demand and parallel imports and exports among their causes.[^1] The OECD reports that after the pandemic many governments adopted health resilience measures that combined monitoring, coordination, diversification and a shift to local production.[^5]

See [[Pharmaceutical Logistics]], [[Cold Chain Monitoring]], [[DSCSA Compliance]] and [[Sector Supply Chain]].

## What the sources do not establish

Opened sources do not cover serialisation data formats, RFID, blockchain verification or cold-chain monitoring, so this page leaves those to their own pages. The earlier body gave counterfeit shares and a United States implementation timetable that no opened source supports, and they have been removed.

[^1]: European Parliament, Policy Department for External Policies (study requested by the INTA committee), “Post Covid-19 value chains: options for reshoring production back to Europe in a globalised economy”. https://www.europarl.europa.eu/RegData/etudes/STUD/2021/653626/EXPO_STU(2021)653626_EN.pdf
[^2]: US Food and Drug Administration, “Drug Supply Chain Security Act (DSCSA)”. https://www.fda.gov/drugs/drug-supply-chain-integrity/drug-supply-chain-security-act-dscsa
[^3]: European Commission, Directorate-General for Health and Food Safety, “Falsified medicines”. https://health.ec.europa.eu/medicinal-products/falsified-medicines_en
[^4]: World Health Organization, fact sheet, “Substandard and falsified medical products”. https://www.who.int/news-room/fact-sheets/detail/substandard-and-falsified-medical-products
[^5]: OECD, report on supply chain resilience, “Promoting resilience and preparedness in supply chains”. https://www.oecd.org/content/dam/oecd/en/publications/reports/2024/11/promoting-resilience-and-preparedness-in-supply-chains_c0320739/be692d01-en.pdf

