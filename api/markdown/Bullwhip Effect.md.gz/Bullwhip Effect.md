Orders passed up a supply chain tend to vary more than the sales they respond to, and the distortion grows at each step upstream; this is the bullwhip effect.[^1]

Lee, Padmanabhan and Whang claim that the information transferred in the form of orders tends to be distorted and can misguide upstream members in their inventory and production decisions.[^1] They state that the variance of orders may be larger than that of sales, and that the distortion tends to increase as one moves upstream, a phenomenon they term the bullwhip effect.[^1]

## Causes proposed

Lee and colleagues analyse four sources of the effect: demand signal processing, the rationing game, order batching and price variations.[^1] They also discuss actions that can be taken to mitigate the detrimental impact of the distortion.[^1] Only the abstract was used for this page because the opened copy of the body text had its columns interleaved, so the mechanisms are named but not explained.

## Related accounts

Sterman describes a broader pattern in which many supply chains exhibit chronic instability, including oscillations, amplification as disturbances move upstream from final sales, and phase lag, and attributes it to decision-makers failing to account for time delays and for orders not yet received.[^2] That account uses different terms and a different explanation from Lee and colleagues, who focus on the distortion of order information; the two sources are not shown here to be the same thing.

The Beer Game, described by Kaminsky and Simchi-Levi, produces the pattern in a classroom: with customer demand that does not vary much, players still see wildly fluctuating inventory and backorder levels.[^3]

## Scope

Bullwhip effect belongs to [[Supply Chain Dynamics]]. The Wang and Disney review of progress on the topic was not accessible, so the empirical record, measures of the effect and its remedies are not covered here.

[^1]: Hau L. Lee, V. Padmanabhan and Seungjin Whang, Management Science, 1997 (copy on a Bilkent University course site, abstract used), “Information Distortion in a Supply Chain: The Bullwhip Effect”. https://courses.ie.bilkent.edu.tr/ie102/wp-content/uploads/sites/12/2019/02/Lee-Padmanabhan-Whang-1997-MS.pdf
[^2]: John Sterman, chapter in The Handbook of Behavioral Operations Management, Oxford University Press, 2015 (MIT DSpace record, abstract only), “Booms, Busts, and Beer: Understanding the Dynamics of Supply Chains”. https://dspace.mit.edu/handle/1721.1/121087
[^3]: Philip Kaminsky and David Simchi-Levi, Northwestern University, 1998, “A New Computerized Beer Game: A Tool for Teaching the Value of Integrated Supply Chain Management”. https://kaminsky.ieor.berkeley.edu/Reprints/PK_DSL_98b.pdf

