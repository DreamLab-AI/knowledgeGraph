Apache Flink is an open-source distributed engine for stateful computations over unbounded and bounded data streams. It provides a unified runtime that treats batch processing as a special case of streaming, with event-time semantics, sophisticated windowing, and exactly-once state consistency backed by distributed snapshots. Flink is widely used for low-latency, high-throughput stream processing in real-time analytics, event-driven applications, and continuous data pipelines.

### Overview

- Flink originated from the Stratosphere research project and became a top-level Apache project, distinguishing itself with a true streaming dataflow runtime rather than micro-batching. Its checkpointing mechanism, based on the Chandy-Lamport distributed snapshot algorithm, captures consistent global state asynchronously, enabling exactly-once processing guarantees and fast recovery. Layered APIs span low-level process functions, the DataStream API, and SQL, allowing the same engine to serve diverse workloads.

### Key aspects

- True streaming dataflow runtime with low latency
- Event-time processing with watermarks for out-of-order data
- Flexible windowing (tumbling, sliding, session)
- Exactly-once state consistency via asynchronous checkpoints
- Layered APIs from process functions to SQL

### Applications

- Real-time fraud and anomaly detection
- Continuous ETL and data pipelines
- Event-driven microservices and alerting
- Streaming analytics dashboards
- Complex event processing

### Provenance

- This class was materialised to resolve inbound references from existing classes in the knowledge graph.

