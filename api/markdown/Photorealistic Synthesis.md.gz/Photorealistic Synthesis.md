Photorealistic synthesis is the generation of images or scenes that are visually indistinguishable from real photographs. It is achieved with generative models such as diffusion networks and GANs, or with physically based rendering, that reproduce accurate lighting, materials, geometry, and texture detail. It underpins high-fidelity image generation and the creation of realistic 4D and procedural content.

### Content

- Generative approaches learn the distribution of natural images so sampled outputs exhibit plausible light transport, material response, and fine texture, while physically based renderers compute realism from explicit scene physics. The capability powers synthetic media, visual effects, and simulation, and simultaneously drives concerns about deepfakes and the need for provenance and watermarking.

