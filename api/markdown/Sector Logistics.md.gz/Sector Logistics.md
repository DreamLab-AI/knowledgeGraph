Sector logistics is logistics specialised by product or sector; none of the sources opened for this page defines the term, so the page is bounded by what they say about the sector pages beneath it.[^1]

The Council of Supply Chain Management Professionals defines logistics management as the part of supply chain management that plans, implements and controls the forward and reverse flow and storage of goods, services and related information between the point of origin and the point of consumption in order to meet customers' requirements.[^1] On the reading adopted here, sector logistics is that general activity applied to a class of goods or a setting that adds its own conditions.

## Examples in this domain

Three sector pages are covered in this corpus. In cold chain logistics, the International Institute of Refrigeration and ASHRAE define the cold chain as a series of actions and equipment applied to maintain a product within a specified low-temperature range from harvest or production to consumption.[^2] In pharmaceutical logistics, the World Health Organization says every activity in the distribution of pharmaceutical products should follow the principles of good manufacturing practice, good storage practice and good distribution practice as applicable.[^3] In humanitarian logistics, the Logistics Cluster describes its role as coordination, information management and access to common logistics services for an effective logistics response in humanitarian emergencies.[^4] The added conditions differ: a temperature range in the first, regulatory practice in the second and emergency settings in the third.

## Scope and distinctions

Sector Logistics sits under [[Warehousing and Distribution]]. Its sector pages are [[Cold Chain Logistics]], [[Pharmaceutical Logistics]] and [[Humanitarian Logistics]].

## What the sources do not establish

This page rests on thin evidence. No opened source names a general category of sector logistics or lists its members, and the three examples are those that the corpus holds, not a complete list. The opened sources do not say how sectors differ in cost or scale.

[^1]: Council of Supply Chain Management Professionals, “SCM Definitions and Glossary of Terms”. https://cscmp.org/CSCMP/CSCMP/Educate/SCM_Definitions_and_Glossary_of_Terms.aspx
[^2]: International Institute of Refrigeration, “The IIR and the ASHRAE establish new definitions of five keywords in the refrigeration sector”. https://iifiir.org/en/news/the-iir-and-the-ashrae-establish-new-definitions-of-five-keywords-in-the-refrigeration-sector
[^3]: World Health Organization, WHO Technical Report Series No. 957, 2010, Annex 5, “WHO good distribution practices for pharmaceutical products”. https://www.who.int/docs/default-source/medicines/norms-and-standards/guidelines/distribution/trs957-annex5-who-good-distribution-practices-for-pharmaceutical-products.pdf
[^4]: Logistics Cluster, “The Logistics Cluster”. https://logcluster.org/en/about-us

