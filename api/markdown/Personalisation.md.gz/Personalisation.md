Personalisation is the practice of tailoring content, recommendations, services and user experiences to the characteristics, behaviour and preferences of individual users or narrowly defined segments. It draws on collected and inferred data — profiles, interaction histories and contextual signals — to deliver differentiated outputs rather than a single uniform experience. Personalisation underpins recommendation systems, targeted marketing and adaptive interfaces, and raises associated privacy, consent and fairness considerations.

### Overview

- Personalisation systems combine explicit data (preferences a user states) with implicit data (observed behaviour) to model intent and predict relevant content. Modern implementations rely heavily on machine learning, where collaborative filtering, content-based models and contextual bandits select items likely to satisfy a given user. The discipline spans data collection, feature engineering, model serving and continuous evaluation against engagement and satisfaction metrics.

### Key aspects

- Explicit versus implicit preference signals
- Real-time versus batch personalisation
- Cold-start problem for new users and items
- Privacy, consent and data-minimisation constraints
- Segmentation versus one-to-one targeting
- Feedback loops and filter-bubble risks

### Applications

- Product and content recommendations in e-commerce
- Personalised marketing campaigns and messaging
- Adaptive user interfaces and onboarding flows
- Search ranking tuned to individual intent
- Conversational agents that retain user context

### Provenance

