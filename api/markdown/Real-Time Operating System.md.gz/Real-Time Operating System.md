A Real-Time Operating System (RTOS) is an operating system designed to service computational tasks within guaranteed, bounded time constraints, providing temporal determinism that makes it the foundational software substrate for safety-critical and time-sensitive embedded applications. RTOSes implement priority-based preemptive scheduling, bounded interrupt latency, and synchronisation primitives (semaphores, mutexes, message queues) that ensure predictable worst-case task-switching behaviour irrespective of system load. They are classified as hard real-time — where any deadline miss constitutes a system failure — or soft real-time, where occasional misses cause graceful degradation rather than catastrophic failure. Deployed in medical devices, industrial controllers, automotive electronics, avionics, and robotics, RTOSes underpin every domain in which a missed computational deadline can cause physical harm, financial loss, or mission failure.

### Overview

- An RTOS differs from a conventional OS at the architectural level. The kernel is designed to be small, predictable, and deterministic rather than feature-rich. Context-switch overhead, interrupt response latency, and scheduling jitter are first-class metrics, not afterthoughts. Every kernel path that a time-critical task might traverse is analysed for its [[Worst-Case Execution Time]] (WCET) — the longest time that path can take under any legal input or system state.
- RTOSes are classified along a hard/soft axis:
  - **Hard real-time**: any deadline miss is a system failure. Examples — aircraft flight control, pacemaker firmware, ABS brake controllers, nuclear plant control. Formal timing verification (e.g., static WCET analysis) is mandatory.
  - **Soft real-time**: occasional deadline misses cause degraded quality of service but not catastrophic failure. Examples — multimedia decoders, user-interface event loops, VoIP jitter buffers.
- A third category — **firm real-time** — allows rare misses but discards late results as worthless (e.g., financial trading engines, video frame pipelines).
- The growth of [[Edge AI]] inference and [[Cyber-Physical Systems]] is extending RTOS scope: neural network inference engines must now be schedulable within deterministic task budgets, driving new tooling around static memory allocation and worst-case inference profiling.

### Key Components

#### Task Scheduler

- The [[Task Scheduler]] is the core kernel component. It implements a ready queue sorted by task priority and performs preemptive context switches when a higher-priority task becomes runnable.
- Common scheduling algorithms: Rate-Monotonic Scheduling (RMS), Earliest-Deadline-First (EDF), Fixed-Priority Pre-emptive Scheduling (FPPS).
- Schedulability analysis (e.g., Liu & Layland utilisation bound for RMS) determines whether a given task set can always meet its deadlines.

#### Interrupt Handling

- An [[Interrupt Handler]] (ISR — Interrupt Service Routine) responds to hardware events with bounded, deterministic latency.
- RTOSes minimise ISR execution to the bare minimum — typically reading a status register and signalling a task via semaphore — deferring heavy processing to a task context (deferred interrupt handling pattern).
- Interrupt latency is a key datasheet metric for every RTOS; typical values range from hundreds of nanoseconds to a few microseconds on modern microcontrollers.

#### Synchronisation Primitives

- [[Semaphore|Semaphores]] — counting and binary — provide mutual exclusion and event signalling between tasks and ISRs.
- Mutexes with priority inheritance prevent [[Priority Inversion Prevention|priority inversion]], where a high-priority task is blocked by a low-priority task holding a shared resource.
- [[Message Queue|Message queues]] and mailboxes enable typed, buffered inter-task communication without shared memory hazards.
- Event flags and task notifications provide lightweight signalling with minimal overhead.

#### Memory Management

- RTOSes typically avoid general-purpose `malloc`/`free` in critical paths because heap fragmentation introduces non-deterministic latency.
- Alternatives: statically allocated task stacks, fixed-size memory pools, region-based allocators with O(1) allocation and deallocation guarantees.
- The [[Memory Management Unit]] (MMU) — when present — provides memory protection between tasks; in smaller microcontrollers an MPU (Memory Protection Unit) enforces per-task address boundaries.

#### Timers and Clocks

- A high-resolution hardware timer provides the RTOS tick, typically 1 ms but configurable down to sub-millisecond periods.
- High-resolution software timers (one-shot and periodic) allow task wake-up or callback execution at microsecond granularity beyond the tick resolution.
- Clock synchronisation protocols (e.g., IEEE 1588 PTP) integrate with RTOS time sources in networked real-time systems.

### Mechanisms

#### Priority-Based Preemptive Scheduling

- Each task is assigned a numerical priority. The scheduler always runs the highest-priority ready task. When a higher-priority task becomes ready (via ISR signal or timer), it immediately preempts the running task.
- Priority levels are finite (typically 8–256 levels). Tasks at the same priority may be scheduled round-robin within a configurable time slice.
- [[Deterministic Scheduling]] guarantees are proven mathematically for task sets satisfying utilisation and response-time analysis criteria.

#### Priority Inversion and Its Prevention

- Priority inversion occurs when a high-priority task waits on a mutex held by a low-priority task, while a medium-priority task preempts the low-priority task — causing unbounded blocking.
- The Mars Pathfinder mission (1997) famously exhibited priority inversion in VxWorks before priority inheritance was enabled.
- Priority Inheritance Protocol (PIP): the mutex holder temporarily inherits the priority of the highest-priority waiter.
- Priority Ceiling Protocol (PCP): each mutex is assigned the highest priority of any task that may acquire it; a task acquiring the mutex is boosted to the ceiling priority for the duration.

#### Worst-Case Execution Time Analysis

- Static WCET analysis tools (e.g., AbsInt aiT, Rapita RapiTime) use abstract interpretation or measurement-based methods to compute safe upper bounds on task execution time.
- WCET analysis must account for cache behaviour, pipeline stalls, branch prediction, and hardware interrupt latency — all sources of timing variability in modern processors.
- Certification standards (DO-178C for avionics, IEC 61508 for functional safety) mandate WCET analysis as part of the safety case.

### Applications and Use Cases

#### Aerospace and Defence

- Flight control computers (FCC) run hard real-time control loops for fly-by-wire systems, typically at 25–100 Hz with microsecond jitter budgets.
- VxWorks dominates certified avionics (DO-178C SIL A/B); LynxOS and INTEGRITY (Green Hills) are used in military aircraft and UAVs.
- [[Safety-Critical Systems]] certification requires formal WCET analysis and extensive hardware-in-the-loop testing.

#### Automotive

- AUTOSAR (Automotive Open System Architecture) defines a layered software architecture in which an RTOS (OSEK/OS or AUTOSAR OS) manages ECU (Electronic Control Unit) task scheduling.
- Applications: engine management, anti-lock braking (ABS), electronic stability control (ESC), advanced driver assistance systems ([[ADAS]]).
- QNX Neutrino is widely used in infotainment and instrument clusters; AUTOSAR OS in powertrain ECUs.

#### Medical Devices

- Pacemakers, defibrillators, infusion pumps, and ventilators run certified hard real-time firmware.
- IEC 62304 (medical device software lifecycle) and IEC 60601 (electrical safety) require demonstrable determinism and software fault containment.
- FreeRTOS and ThreadX (Azure RTOS) are frequently chosen for medical devices due to their certification artefacts (Safety Certificates, IEC 61508 SIL 3 / IEC 62304 Class C).

#### Industrial Automation and Robotics

- PLCs (Programmable Logic Controllers) and CNCs (Computer Numerical Controllers) require microsecond-precision I/O scan cycles.
- [[Robot Operating System]] (ROS 2) builds real-time capable pub/sub middleware on top of RTOSes — micro-ROS targets FreeRTOS and Zephyr for microcontroller nodes.
- EtherCAT and PROFINET IRT field buses demand sub-100 µs cycle times, achievable only with RTOS-backed network stacks.

#### Internet of Things and Edge Computing

- Zephyr RTOS targets resource-constrained IoT devices (from 8 KB RAM) with Bluetooth LE, Thread, and Wi-Fi network stacks.
- FreeRTOS runs on billions of microcontrollers in consumer and industrial IoT.
- [[Edge AI]] inference within RTOS tasks is an emerging pattern: TensorFlow Lite for Microcontrollers and CMSIS-NN provide deterministic-memory inference engines compatible with RTOS task budgets.

#### Telecommunications

- Base station DSPs and radio access network (RAN) equipment use hard real-time scheduling for sub-millisecond radio frame processing.
- 5G NR (New Radio) physical layer processing has strict 1–4 ms deadline requirements met by RTOS-managed DSP clusters.

### Standards and Context

- **POSIX.1b (IEEE Std 1003.1b)**: defines real-time extensions to POSIX including priority scheduling, semaphores, message queues, shared memory, and high-resolution timers. Many RTOSes (RTEMS, LynxOS, QNX) are POSIX-compliant to allow portable application code.
- **OSEK/VDX OS**: an automotive RTOS standard (ISO 17356) defining task management, ISR handling, alarms, and resource management for ECUs. Superseded in part by AUTOSAR OS.
- **AUTOSAR OS (Automotive Open System Architecture)**: extends OSEK with scalability classes and multiple-core support; mandates by major OEMs for ECU software.
- **DO-178C / DO-178B**: avionics software certification standard (FAA/EASA). RTOSes used in safety-critical avionics must have certified kernels (e.g., VxWorks 653, INTEGRITY-178).
- **IEC 61508**: functional safety standard for industrial systems. Defines SIL (Safety Integrity Level) 1–4. RTOS vendors supply SIL 3/4 certification packages.
- **IEC 62304**: medical device software lifecycle standard. RTOSes used in Class B/C medical devices require validated software lifecycle artefacts.
- **IEEE 1588 (PTP)**: Precision Time Protocol for sub-microsecond clock synchronisation across networked real-time nodes — foundational for distributed RTOS clusters and industrial fieldbus timing.
- **MISRA C / CERT C**: coding standards widely adopted for RTOS-hosted safety application code to prevent undefined behaviour that could violate timing guarantees.
- Notable RTOS platforms: FreeRTOS (Amazon, MIT licence), Zephyr (Linux Foundation), VxWorks (Wind River), QNX Neutrino (BlackBerry), ThreadX / Azure RTOS (Microsoft), RTEMS (open source, used in space missions), INTEGRITY (Green Hills), Nucleus (Mentor/Siemens), eCos (Red Hat, open source).

### Provenance

