Production planning and control is the set of activities that decide what a production system will do and then execute, monitor and adapt that plan.[^1]

A review of operations and supply chain management says production planning and control are often considered together but differ: planning is about allocating resources according to what is expected to happen, while control is about executing the plan, monitoring the operations, and adapting to actual conditions and unexpected changes. It adds that feedback loops between the two are often necessary and that the line between them is increasingly blurred.[^1]

## Push and pull control

According to the review, production control traditionally focuses on internal information flows and can be categorised as push, for example make-to-stock driven by demand forecast, or pull, for example make-to-order triggered by customer demand. It says hybrid systems that combine push and pull logic are often used in modern production control.[^1] See [[Make-to-Stock]] and [[Make-to-Order]].

## Material requirements planning

One planning system named in the sources is material requirements planning. Columbia University lecture notes call it a computer-based production planning and inventory control system concerned with both production scheduling and inventory control, and name its three major inputs as the master production schedule, the product structure records and the inventory status records. The notes add that it is not useful for job shops or for continuous processes that are tightly linked.[^2] An open textbook calls it a production planning, scheduling and inventory control system used to manage manufacturing processes.[^3] See [[Material Requirements Planning]] and [[Master Production Scheduling]].

## Scope and distinctions

Detailed sequencing and timing of jobs is treated at [[Production Scheduling]], and the balancing of work across stations at [[Line Balancing]]. The open textbook says that even with highly integrated planning software, operations managers still need to plan for and control inventory.[^3]

## What the sources do not establish

No source defines production planning and control as a single term with a fixed list of components, so the page is bounded by the planning and control distinction in the review and by the MRP material.

[^1]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “Material Requirements Planning (MRP)”. https://www.columbia.edu/~gmg2/4000/pdf/lect_06.pdf
[^3]: Business LibreTexts (Introduction to Business, Lumen), “12.4: Production Planning”. https://biz.libretexts.org/Bookshelves/Business/Introductory_Business/Introduction_to_Business_(Lumen)/12:_Managing_Process/12.04:_Production_Planning

