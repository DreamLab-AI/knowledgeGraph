Procure-to-pay (P2P) is the typical set of business functions used to manage business-to-business purchasing, from requisition and purchase order, through receipt of goods or services and the purchase invoice, to supplier payment and the recording of transactions in the financial accounts.[^1]

HM Revenue and Customs, in its VAT compliance controls guidance, lists control points along that cycle. Purchase orders should be placed only for approved requisitions, accurately recorded and created before receipt of supplies and invoice processing. A goods received note is raised on delivery to verify that the goods are in order, supplies are accepted only if they have valid purchase orders, and accounts payable applies a two-way match between purchase order and invoice or a three-way match that includes the goods received note.[^1] It says that large organisations with ERP systems should work towards automating the workflow as far as possible.[^1]

The State Accounting Office of Georgia gives a public-sector view: its procedures aim to ensure that only approved purchases are made, that amounts are available in the budget and approved before payment, and that payments are made efficiently. It requires purchase orders above a stated threshold and says management must ensure approvals are obtained and receipt of goods or services is verified before funds are disbursed.[^2]

## Scope and distinctions

P2P covers the transaction, whereas [[Strategic Sourcing]] and [[Category Management]] cover what is bought and from whom. See [[Procurement]], [[Sourcing and Procurement]] and [[Enterprise Resource Planning]].

## What the sources do not establish

Both sources are public-sector or tax-compliance guidance, and thresholds and controls vary by jurisdiction, so the page gives no figures.[^1][^2]

[^1]: HM Revenue and Customs, VAT compliance controls guidelines (Crown copyright), “Procure to pay (part 4)”. https://www.gov.uk/government/publications/help-with-vat-compliance-controls-guidelines-for-compliance-gfc8/procure-to-pay-part-4
[^2]: State Accounting Office of Georgia, Statewide Business Process Policy and Procedure, Business Process Reference, Disbursements and Purchases: Payment Process (revised 15 November 2022). https://sao.georgia.gov/document/document/bp-payment-process-11-15-2022/download

