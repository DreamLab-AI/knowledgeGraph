
An agent identity set is the collection of identity bindings that an agent holds at once, declared as `IdentitySet` in the agent module of the Agent Ontology under the heading "Identity Interfaces (Multi-DID)".[^1] The Agent Ontology declares the class without a definition; this one follows from its properties. visionGraph places it under [[Configuration]], with [[Identity Binding]] as its part.

An agent reaches its set through `identityInterfaces`, and the set relates to its members through `identity`. Each binding may in turn name a key management system. The purpose is to let one agent carry several identities, for example a different [[Decentralised Identifier]] for each community it participates in.

The set is distinct from a single [[Agent Identity]], the verifiable identity of an agent. The set is a configuration-level container for several such identities and is not an identity in itself.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

