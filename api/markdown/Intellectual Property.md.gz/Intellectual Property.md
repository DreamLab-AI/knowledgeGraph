A category of legally protected intangible assets arising from creations of the mind, encompassing copyright over creative works, patents over inventions, trade marks over distinctive signs, and trade secrets over confidential know-how. Intellectual property law grants creators time-limited exclusive rights to exploit their creations commercially, balancing incentives for innovation against public access, and underpins licensing, technology transfer, and the contested attribution of AI-generated content.

### Semantic Classification

### Content

## Definition

**Intellectual property** (IP) is the umbrella term for legal rights over intangible creations of the mind. The main regimes are copyright (literary, artistic, and software works), patents (novel, inventive, industrially applicable inventions), trade marks (distinctive commercial signs), registered designs, and trade secrets. Each regime grants the rights holder a bundle of exclusive rights — typically to copy, distribute, adapt, manufacture, or use — for a limited period, after which the creation passes into the public domain.

The economic rationale is an exchange: society grants a temporary monopoly to incentivise disclosure and investment in creative and inventive work. Because the rights are property, they can be assigned, mortgaged, and — most importantly for the software and media industries — licensed. Every [[Software Licence]], from proprietary EULAs to the GPL and MIT licences, is an exercise of copyright: open-source licensing works precisely because copyright gives the author the leverage to attach conditions to reuse.

Generative AI has made IP one of the most actively litigated areas of technology law. Disputes centre on two questions: whether training models on copyrighted corpora constitutes infringement or fair dealing, and whether [[Ai Generated Content]] can attract protection at all when no human author is identifiable. Jurisdictions diverge — the UK CDPA 1988 s.9(3) provides for computer-generated works, while the US Copyright Office requires human authorship — creating significant uncertainty for tools such as Adobe Firefly, which markets itself on commercially safe, licensed training data.

## Current Landscape

- **Framework treaties**: the Berne Convention (copyright), the Paris Convention (industrial property), and the WTO TRIPS Agreement set international minimum standards, administered largely through WIPO.
- **UK regime**: the Copyright, Designs and Patents Act 1988 and the Patents Act 1977, with the UK Intellectual Property Office handling registration; post-Brexit, UK and EU trade mark and design rights have diverged.
- **AI flashpoints**: In *Getty Images v Stability AI* [2025] EWHC 2863 (Ch), handed down on **4 November 2025**, the England & Wales High Court (Mrs Justice Joanna Smith) largely rejected Getty's claims — Getty had dropped its primary training/output copyright claims for lack of evidence that copying occurred in the UK, and the court held that Stable Diffusion's model weights are not an "infringing copy" under s.27 CDPA because they never stored or reproduced the training works, so secondary infringement by importation failed; only a "historic and extremely limited" trade-mark infringement (watermark generation) was found. The US *New York Times v OpenAI* litigation and UK/EU consultations on text-and-data-mining exceptions remain live.
- **Industry practice**: provenance standards such as C2PA content credentials (now aligned with ISO/IEC 21617 JPEG Trust), model training on licensed datasets, and indemnification offers from major AI vendors are emerging as commercial responses to unresolved legal questions.
- IP valuation increasingly dominates corporate balance sheets: intangible assets account for the large majority of S&P 500 market value, making IP governance a board-level concern rather than a purely legal one.

  **Sources**:

- https://www.judiciary.uk/wp-content/uploads/2025/11/Getty-Images-v-Stability-AI.pdf
- https://www.pinsentmasons.com/out-law/news/gettys-copyright-case-against-stability-ai-fails
- https://www.theguardian.com/media/2025/nov/04/stabilty-ai-high-court-getty-images-copyright

