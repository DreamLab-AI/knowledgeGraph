UN/EDIFACT (United Nations Electronic Data Interchange for Administration, Commerce and Transport) is the global electronic data interchange standard developed and maintained by the United Nations Centre for Trade Facilitation and Electronic Business (UN/CEFACT).[^1]

A 2016 UNECE leaflet says development started at the end of the 1980s and that the standard then contained 209 business messages, with updated versions published twice a year.[^1] It says UN/EDIFACT is used by most international sectors, including retail, transport and logistics, customs, healthcare, agriculture and insurance, that the standard is available free of charge on the UN/CEFACT website, and that “No comprehensive information on global implementation is available”.[^1]

## Syntax and use

ISO 9735-1:2002 specifies common syntax rules for the formatting of batch and interactive messages to be interchanged between computer application systems, and includes the terms and definitions for all parts of ISO 9735.[^2] NIST described UN/EDIFACT and ANSI ASC X12 as quite similarly organised.[^3] A US Customs and Border Protection guide of 2006 shows the standard in use at a border: the Customs Cargo message (CUSCAR) is used to submit a complete cargo manifest for a truck.[^4] The AS2 specification, IETF RFC 4130, lists UN/EDIFACT among the formats it can carry.[^5]

## Scope and distinctions

UN/EDIFACT is one family of messages within [[Electronic Data Interchange]]. The despatch advice message used for shipment notices is covered at [[Advance Ship Notice]]. The leaflet says the principle of backwards compatibility has been enforced, so users of different versions can exchange messages without problems.[^1]

## What the sources do not establish

Message count and sector statements are the 2016 leaflet's, and the CBP guide is from 2006, so the page gives no current figures. The ISO record is an abstract; the syntax text is not freely available and was not read.[^1][^2][^4]

[^1]: UNECE and UN/CEFACT, “Executive Guide UN/EDIFACT”, 2016 (Internet Archive copy of the UNECE PDF). https://web.archive.org/web/2024/https://unece.org/sites/default/files/2023-10/ExecGuide_UNEDIFACT_Eng.pdf
[^2]: ISO, “ISO 9735-1:2002 - Electronic data interchange for administration, commerce and transport (EDIFACT) — Application level syntax rules (Syntax version number: 4, Syntax release number: 1) — Part 1: Syntax rules common to all parts” (catalogue record). https://www.iso.org/standard/35032.html
[^3]: National Institute of Standards and Technology, NISTIR 5631, “Electronic Data Interchange (EDI) Standards”, analysis of ANSI ASC X12 and UN/EDIFACT. https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir5631.pdf
[^4]: US Customs and Border Protection, “Automated Commercial Environment Chapter 3: Creating EDIFACT Transactions”, 6 November 2006. https://www.cbp.gov/sites/default/files/assets/documents/2017-Oct/ACE_Chapter3_EDIFACT_November_2006.pdf
[^5]: D. Moberg and R. Drummond, IETF RFC 4130, July 2005, “MIME-Based Secure Peer-to-Peer Business Data Interchange Using HTTP, Applicability Statement 2 (AS2)”. https://www.rfc-editor.org/rfc/rfc4130.txt

