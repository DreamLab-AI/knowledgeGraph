A logistics service provider is a business that provides logistics services to other organisations. The Industrial Ontologies Foundry gives the Council of Supply Chain Management Professionals wording for the role: “Any business which provides logistics services”, adding that it “Includes those businesses typically referred to as 3PL, 4PL, LLP, etc” and that the services “may include provisioning, transport, warehousing, packaging, etc”.[^1]

## Services and customers

The European Commission describes logistics as the organisation and management of flows of goods related to purchasing, production, warehousing, distribution and the disposal, reuse and exchange of products, together with added value services.[^2] It adds that enterprises often outsource logistics activities to third party logistics providers, and that express, courier and parcel services are key to the e-commerce delivery business.[^2]

The IOF ontology illustrates the role with FedEx providing transportation services to its customers.[^1] In the United Kingdom, HM Revenue and Customs names three kinds of business that can deal with customs for a trader: freight forwarders, customs agents or brokers, and express operators.[^3]

## Kinds of provider in this vault

This vault treats the following as kinds of logistics service provider: [[Third-Party Logistics Provider]], [[Fourth-Party Logistics Provider]], [[Freight Forwarder]], [[Customs Broker]] and [[Freight Carrier]]. They overlap. A freight forwarder may also act as a carrier, and a single business may hold several roles at once.[^1][^4]

## What the sources do not establish

Evidence for this page is thin. The definition comes through the IOF ontology's quotation of CSCMP, and the CSCMP glossary itself could not be read in full. The European Commission page describes logistics and outsourcing but does not define the provider role. No opened source gives a list of the services that must be present for a business to count as a provider, so the boundary with a manufacturer or retailer that runs its own logistics is not fixed here. See also [[Logistics Management]] and [[Supply Chain Organisations]].[^1][^2]

[^1]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^2]: European Commission, Directorate-General for Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en
[^3]: HM Revenue and Customs on GOV.UK, “Get someone to deal with customs for you”. https://www.gov.uk/guidance/appoint-someone-to-deal-with-customs-on-your-behalf
[^4]: Cornell Law School Legal Information Institute, “49 U.S. Code § 13102 - Definitions”. https://www.law.cornell.edu/uscode/text/49/13102

