Digital Regulation is the body of law, policy instruments, technical standards, and enforcement mechanisms that govern the development, deployment, operation, and use of digital technologies — including artificial intelligence systems, online platforms, data-driven services, and digital communications infrastructure. It addresses algorithmic accountability, platform liability, data sovereignty, content moderation obligations, cybersecurity requirements, and cross-border regulatory harmonisation, aiming to balance innovation incentives with fundamental rights protections, market competition, and public safety objectives. Digital Regulation operates across multiple jurisdictional layers — supranational, national, and sector-specific — and increasingly relies on regulatory sandboxes, conformity assessments, and co-regulatory models that involve both government bodies and industry stakeholders. Its scope has expanded rapidly with the proliferation of AI, cloud computing, and large-scale data ecosystems, making it a central mechanism for translating societal values into enforceable technical and operational constraints.

### Overview

- Digital Regulation has evolved from early telecommunications and broadcasting law into a multidisciplinary field spanning competition law, fundamental rights, product safety, and sector-specific technical standards. Unlike analogue-era regulation, it must contend with cross-border data flows, algorithmic decision-making at scale, rapidly changing technology stacks, and asymmetric information between regulators and regulated entities.
- **Why it matters**: Digital technologies mediate access to employment, credit, healthcare, political speech, and public services. Without regulatory safeguards, algorithmic systems can entrench discrimination, erode [[Privacy]], concentrate market power, and undermine democratic institutions. Conversely, poorly designed regulation can suppress beneficial innovation, create compliance burdens that favour large incumbents, and fragment the global digital economy into incompatible jurisdictional blocs.
- **How it works**: Digital Regulation operates through a layered combination of:
  - Ex ante obligations (design requirements, conformity assessments, mandatory impact assessments before deployment).
  - Ex post enforcement (investigations, fines, injunctions, mandatory audits following harm or complaint).
  - Co-regulatory and sandbox mechanisms (industry codes of practice reviewed by regulators; controlled pilots under relaxed rules).
  - Interoperability and data-sharing mandates (requiring dominant platforms to open APIs or share data with competitors).
- **Jurisdictional landscape**: The EU has become the leading regulatory exporter via the [[General Data Protection Regulation]] (GDPR), the [[Digital Services Act]] (DSA), the [[Digital Markets Act]] (DMA), and the [[EU AI Act]]. The UK has adopted a sectoral, principles-based approach post-Brexit. The US operates a sectoral patchwork (FTC, CFPB, FCC, sector-specific agencies) with emerging federal AI legislation. China pursues a state-led model with algorithmic recommendation rules and generative AI regulations. India's Digital Personal Data Protection Act 2023 represents a significant emerging-economy framework.

### Key Components

- **[[Algorithmic Accountability]]** — requirements for transparency, explainability, and auditability of automated decision systems, particularly in high-stakes domains such as credit, employment, and law enforcement.
- **[[Platform Liability]]** — rules determining when intermediary platforms bear legal responsibility for third-party content or conduct facilitated on their services (e.g. DSA notice-and-action obligations, US Section 230 safe harbour).
- **[[Data Protection]]** and [[Data Sovereignty]] — rights of individuals over personal data collection, processing, and transfer; restrictions on cross-border data flows to jurisdictions lacking adequate protections.
- **[[Content Moderation]]** — obligations on platforms to detect, label, or remove illegal content (terrorist material, child sexual abuse material, disinformation) while protecting freedom of expression.
- **[[Cybersecurity]] requirements** — mandatory security-by-design, vulnerability disclosure, and incident reporting obligations (e.g. NIS2 Directive, DORA for financial services).
- **[[AI Governance and Ethics]]** — risk-tiered obligations for AI systems, including prohibited practices, high-risk system assessments, transparency requirements, and human oversight mandates (EU AI Act).
- **[[Market Competition]] and digital markets** — ex ante rules for "gatekeeper" platforms (DMA), merger reviews involving data-rich acquisitions, and interoperability mandates.
- **[[Intellectual Property]]** — copyright for AI-generated content, training data licensing, database rights, and the legal status of model weights.
- **[[Digital Rights]]** — enforceable entitlements of users including rights to access, rectification, portability, and explanation of automated decisions.
- **Regulatory sandboxes** — controlled testing environments where innovators can pilot products under relaxed rules with regulatory oversight, as established by the EU AI Act.

### Mechanisms and Instruments

- **Legislation and Directives** — primary law setting binding obligations (GDPR, DSA, DMA, EU AI Act, UK Online Safety Act, DPIA Directive, NIS2).
- **Technical Standards** — referenced by regulation to give concrete, implementable form to abstract legal requirements (ISO/IEC 42001 for AI management systems, NIST AI Risk Management Framework, ETSI standards for network security).
- **Conformity Assessment** — third-party audits or self-declaration processes establishing that a product or system meets regulatory requirements before or after market placement.
- **Impact Assessments** — Data Protection Impact Assessments (DPIAs), Fundamental Rights Impact Assessments (FRIAs), and AI system impact assessments mandated before high-risk deployments.
- **Regulatory Authorities** — data protection authorities (DPAs), national competent authorities for AI, competition authorities, financial regulators, and communications regulators, each with investigatory and enforcement powers.
- **Co-regulatory codes of practice** — industry-drafted codes (e.g. DSA's codes on disinformation) that acquire regulatory force once approved by the European Commission.
- **International regulatory cooperation** — bilateral mutual recognition agreements, the Global Partnership on AI (GPAI), OECD AI Principles, and G7/G20 digital economy working groups.

### Applications and Use Cases

- **AI system deployment** — organisations developing or deploying AI must classify systems by risk, conduct conformity assessments, maintain technical documentation, and implement human oversight mechanisms under the EU AI Act.
- **Online platform governance** — very large online platforms must conduct systemic risk assessments, commission independent audits, and share data with vetted researchers under the DSA.
- **Financial services digitalisation** — banks and fintechs must comply with DORA's ICT risk management and incident reporting requirements; algorithmic trading faces MiFID II transparency and circuit-breaker rules.
- **Healthcare AI** — diagnostic and clinical decision-support AI classified as medical devices faces dual regulation under the EU AI Act (high-risk) and the Medical Device Regulation.
- **Autonomous vehicles** — cross-sectoral regulation combining product liability, road traffic law, data protection, and sector-specific AI safety requirements across multiple jurisdictions.
- **[[Blockchain]] and [[Smart Contract]]s** — emerging regulatory frameworks for crypto-assets (EU MiCA regulation), stablecoins, and DeFi protocols address investor protection, anti-money laundering, and market integrity without yet resolving the governance of truly decentralised systems.
- **Generative AI and foundation models** — transparency, copyright, and systemic risk obligations for providers of general-purpose AI models under the EU AI Act's Title VIII.

### Standards and Context

- **EU AI Act (Regulation 2024/1689)** — the world's first comprehensive horizontal AI regulation, establishing a risk-tiered framework with prohibited practices, high-risk system obligations, and transparency requirements for general-purpose AI models.
- **General Data Protection Regulation (GDPR, 2016/679)** — the foundational EU data protection law, establishing principles of lawfulness, data minimisation, purpose limitation, and rights of data subjects; widely influential globally.
- **Digital Services Act (DSA, 2022/2065)** — harmonises platform liability and imposes asymmetric obligations on very large online platforms and search engines.
- **Digital Markets Act (DMA, 2022/1925)** — designates "gatekeeper" platforms and imposes ex ante interoperability, fairness, and data-sharing obligations.
- **UK Online Safety Act 2023** — places duties of care on user-to-user and search services, with Ofcom as regulator; risk-based approach covering illegal content and children's safety.
- **NIS2 Directive (2022/2555)** — expands the scope and strengthens cybersecurity obligations for essential and important entities across sectors.
- **DORA (Digital Operational Resilience Act, 2022/2554)** — ICT risk management and resilience framework for EU financial sector entities.
- **NIST AI Risk Management Framework (AI RMF 1.0, 2023)** — voluntary US framework for managing AI risks across the AI lifecycle (Map, Measure, Manage, Govern).
- **ISO/IEC 42001:2023** — international standard for AI management systems, supporting organisations in establishing governance processes around AI development and use.
- **OECD AI Principles (2019, updated 2024)** — intergovernmental principles on transparency, accountability, robustness, and human-centred values, adopted by over 40 countries.
- **EU MiCA Regulation (2023/1114)** — Markets in Crypto-Assets regulation, providing a harmonised framework for crypto-asset issuers and service providers.

### Semantic Classification

### Current Landscape (2026)

- The EU's "Digital Omnibus" package, proposed by the Commission in November 2025 (COM(2025)0836) and given a European Parliament position on 25 March 2026, restructured the AI Act timeline: high-risk Annex III obligations were pushed to 2 December 2027 and Annex I product-embedded rules to 2 August 2028, while the Commission retained discretion to accelerate by 6-12 months once harmonised standards are deemed adequate.
- Despite the delays, 2 August 2026 remains the pivotal date when the bulk of the AI Act became applicable and AI Office enforcement powers switched on, alongside Article 50 transparency duties (machine-readable marking of AI-generated content and deepfake disclosure); GPAI model obligations had already applied since 2 August 2025, backed by the voluntary GPAI Code of Practice published 10 July 2025 and a Signatory Taskforce established 2 February 2026.
- DMA enforcement moved decisively from dialogue to penalties: the Commission fined Apple 500 million euros for anti-steering breaches and Meta 200 million euros over its consent-or-pay model in 2025, and its 28 April 2026 review (COM(2026) 178) concluded the DMA is "fit for purpose" without revision while flagging AI and cloud computing as new focus areas, having opened a cloud market investigation in November 2025.
- DSA enforcement intensified through 2025 with proceedings against TikTok, AliExpress and adult platforms (Stripchat, Pornhub, XVideos), a strong focus on protecting minors and age verification, final minors-protection guidelines in July 2025, and the Data Access Portal going live in October 2025; first DSA fines are expected during 2026.
- GDPR enforcement hit records, with the EDPB's 2025 annual report (published 9 April 2026) documenting roughly 1.15 billion euros in national DPA fines and the first-ever jointly authored EDPB-Commission guidelines on the DMA-GDPR interplay (October 2025), plus DSA-GDPR guidelines adopted 11 September 2025.
- The UK diverged from the EU model: the Online Safety Act reached hard deadlines (children's risk assessments due 25 July 2025 under Ofcom's Protection of Children Codes), the Data (Use and Access) Act 2025 received Royal Assent on 19 June 2025, and the Crime and Policing Act 2026 (Royal Assent 29 April 2026) inserted a new section 216A targeting AI chatbot services, while a March 2026 DSIT/DCMS report kept commercial AI training subject to UK copyright licensing.
- US regulation stayed fragmented with no federal law: California's SB 53 frontier-model law took effect January 2026, Colorado's AI Act was repealed and re-enacted (SB 26-189, signed 14 May 2026) pushing its effective date to 1 January 2027, and Illinois amendments took effect 1 January 2026, leaving a patchwork as all 50 states pursue AI legislation.
- The frontier challenge as of 2026 is competitiveness-versus-protection tension: European leaders openly weighed AI Act "pauses" citing US and Chinese competition, standards and implementing acts (including Q2 2026 GPAI enforcement procedures) lagged behind statutory deadlines, and cross-jurisdictional interoperability via G7 Hiroshima and OECD frameworks remained aspirational.

### References

- 1. European Commission (2026). DMA Review Report, COM(2026) 178 final. https://digital-markets-act.ec.europa.eu/system/files/2026-04/DMA%20Review%20Report_COM_2026_178_1_EN.pdf
- 2. YPOG (2026). EU Digital Rulebook: A new phase of Digital Regulation. https://www.ypog.law/en/insight/eu-digital-rulebook
- 3. Centre for Future Generations (2025). Enforcement spotlight - Autumn 2025. https://cfg.eu/enforcement-spotlight-autumn-2025/
- 4. PPC Land (2026). EDPB 2025 annual report: 1.15bn in GDPR fines, new AI and DMA rules. https://ppc.land/edpb-2025-annual-report-eur1-15bn-in-gdpr-fines-new-ai-and-dma-rules/
- 5. BD Emerson (2026). AI Regulations Around the World: A 2026 Guide. https://www.bdemerson.com/article/ai-regulations-around-the-world
- 6. European Commission, Shaping Europe's Digital Future (2026). Enforcement of the AI Act. https://digital-strategy.ec.europa.eu/en/policies/enforcement-ai-act

### Provenance

