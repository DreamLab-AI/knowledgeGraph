A trade payment method is the way a buyer pays a seller for goods or services in trade, and the choice affects who carries the risk of non-payment.[^1][^2]

The US International Trade Administration says there are five primary methods of payment for international transactions: cash-in-advance, letters of credit, documentary collections, open account and consignment.[^1] It says an appropriate method must be chosen carefully to minimise the payment risk while also accommodating the needs of the buyer.[^1] The guide frames the choice as a conflict of interest: for exporters, any sale is a gift until payment is received, and for importers, any payment is a donation until the goods are received.[^1]

## Other lists

UK Government guidance for exporters gives a different list because it describes the choices open to a business: it names international bank transfers, which it calls the most common method of payment in export for business-to-business sales, together with card payments and local bank accounts, and refers to letters of credit as financial products from banks for larger payments or where more security is needed.[^2] It says that exporters choose among payment methods whether they are giving terms of credit or taking payment in advance.[^2]

## Methods with their own pages

[[Documentary Letter of Credit]] covers the bank undertaking used for higher-risk sales. The guide describes an open account sale as one where the goods are shipped and delivered before payment is due, and says the extension of credit by the seller to the buyer is more common abroad; see [[Open Account Trade]] and [[Trade Credit]].[^1] The financing techniques built on open account trade are covered at [[Supply Chain Finance]].

## What the sources do not establish

Both sources are written for exporters, one American and one British, so they speak to the seller's risk and not the buyer's view. The sources do not rank the methods by use apart from the UK statement about bank transfers, and neither gives usage figures.[^1][^2]

[^1]: US International Trade Administration, “Trade Finance Guide: A Quick Reference for U.S. Exporters”, updated 2021 (PDF). https://www.trade.gov/sites/default/files/2021-03/Trade%20Finance%20Guide%20Updated%20030421%20FINAL.pdf
[^2]: UK Government (business.gov.uk), “Getting paid: Choosing the right payment method when exporting”. https://www.business.gov.uk/export-from-uk/learn/categories/funding-financing-and-getting-paid/get-paid/payment-methods-exporters/

