An image processing operation that compresses the high dynamic range of luminance values captured or rendered in a scene into the limited range a display or print medium can reproduce, while preserving perceived contrast, detail, and colour appearance. Tone mapping operators range from simple global curves such as Reinhard and filmic ACES transforms to local, content-adaptive methods, and are a standard final stage in real-time rendering pipelines, HDR photography, and cinematic colour workflows.

### Semantic Classification

### Content

## Definition

**Tone mapping** solves a mismatch of ranges: real scenes and physically based renderers produce luminance spanning many orders of magnitude, whereas a standard display reproduces perhaps three. A tone mapping operator (TMO) is the function that maps scene-referred radiance to display-referred values, ideally so that the picture *looks* the way the scene did — retaining highlight detail, shadow separation, and stable colour, rather than clipping to white or crushing to black.

Operators divide into **global** and **local** families. Global operators apply one curve to every pixel: the Reinhard operator, exponential and logarithmic mappings, and the filmic "S-curves" (Hable/Uncharted 2, ACES RRT+ODT) that emulate the shoulder and toe response of photographic film. Local operators adapt the mapping to each pixel's neighbourhood — bilateral-filter base/detail decomposition, gradient-domain compression, or Durand-Dorsey style methods — recovering more local contrast at the risk of halo artefacts.

In this graph, tone mapping sits inside [[Colour Grading]] and [[Computational Photography]] as the stage that makes HDR capture and physically based [[Rendering]] presentable, and it is one of the quiet enablers of [[Photorealism]]: a physically correct render viewed without a filmic transform reads as flat and synthetic.

## Technical Details

- **Real-time pipelines**: modern game engines render into HDR (typically RGBA16F) buffers, apply auto-exposure (log-average luminance or histogram-based), then a filmic or ACES tonescale, followed by colour grading LUTs — usually fused into one post-process pass.
- **ACES**: the Academy Color Encoding System standardises the scene-referred to display-referred transform (RRT + ODT), giving film, VFX, and increasingly games a shared, display-agnostic tonescale.
- **HDR displays**: HDR10, Dolby Vision, and the PQ (SMPTE ST 2084) and HLG transfer functions shift rather than remove the problem — content must still be tone mapped between mastering luminance and each display's actual peak brightness.
- **Inverse tone mapping**: expands legacy SDR content toward HDR ranges, and appears inside neural rendering pipelines where training photographs are display-referred.
- **Perceptual metrics**: TMO quality is assessed with metrics such as TMQI and HDR-VDP, since simple PSNR does not capture appearance preservation.

  ## Current Landscape

- **ACES 2.0 (released 2024)** overhauled the Output Transform (RRT+ODT), improving rendering of high-saturation and wide-gamut colour over ACES 1.x — though practitioners still debate its hue transitions and note it darkens scenes versus AgX.
- **Blender 5.0 (18 November 2025)** integrated ACES 1.3 and 2.0 view transforms via OCIO, selectable in one click alongside AgX (the default since Blender 4.0) and Filmic, and added ACEScg and Linear Rec.2020 working spaces.
- **HDR is now first-class**: Blender 5.0 ships HDR view-transform variants (e.g. ACES 2.0 - HDR 1000 nits, AgX HDR) targeting Rec.2100-PQ and Rec.2100-HLG displays, so tone mapping increasingly maps between a mastering luminance and each display's peak rather than to SDR only.
- **AgX remains the pragmatic default** for many artists because its progressive desaturation-to-white avoids the "six colours" oversaturation failure of older filmic/ACES 1.x curves, while ACES is reserved for film-adjacent and HDR-master deliverables.

  **Sources**:

- https://github.com/blender/blender/blob/main/release/datafiles/colormanagement/config.ocio
- https://journal.persc.jp/blender-aces-color-management/

### Provenance

