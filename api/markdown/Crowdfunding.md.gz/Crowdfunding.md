Crowdfunding is a financing model in which a project or venture raises capital from a large number of contributors, each providing a relatively small amount, typically through an online platform. Models range from donation and reward-based campaigns to equity and debt offerings, and blockchain variants use token sales to distribute ownership or utility rights. The approach broadens access to early-stage capital while distributing risk across many backers.

### Overview

- Crowdfunding shifts capital formation from a small set of institutional investors to a distributed crowd of individuals. Reward and donation models dominate consumer products and creative work, while equity crowdfunding and token sales target ownership stakes. Blockchain-based crowdfunding lowers settlement friction and enables programmable, transferable claims through tokens.

### Key aspects

- Many small contributions aggregate into meaningful project capital
- Reward, donation, equity, and debt models serve different campaign goals
- Online platforms provide discovery, escrow, and payment processing
- Token-based variants distribute ownership or utility rights on-chain
- All-or-nothing thresholds protect backers when targets are not met

### Applications

- Early-stage funding for startups and consumer hardware products
- Community financing of creative, civic, and open projects
- Token sales distributing protocol ownership to early supporters
- Equity offerings broadening retail access to private ventures

### Provenance

