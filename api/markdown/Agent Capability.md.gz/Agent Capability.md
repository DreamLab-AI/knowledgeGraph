
An agent capability is a describable functional competence or operational capacity of an agent, or in the threat-model reading a functional ability that an agent claims or possesses.[^1][^3] visionGraph places it under the AI Research Area hub.

The capability module refines the core class into a semantic, high-level description written for natural-language understanding and fuzzy matching by language models.[^2] It carries a `capabilityExpression` string and a self-assessed `capabilityConfidence` between 0.0 and 1.0. It links to an [[Atomic Skill]] through `hasSkill`, to a [[Capability Constraint]] and to a [[Capability Provenance]]; visionGraph also relates it to [[Capability Advertisement]].

An agent has capabilities through `hasCapability`, whereas an [[Agent Task]] requires them through `requiresCapability`. The two relations are distinct: an agent is never a task, and a capability can be required without any particular agent yet holding it. A delegation's scope ranges over capabilities.

Two subclasses are declared in the security-binding module: [[Critical Capability]] and [[Restricted Capability]]. They are siblings and disjoint.

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl
[^3]: Semantic Agent Communication Community Group, “Capability Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/capability.ttl

