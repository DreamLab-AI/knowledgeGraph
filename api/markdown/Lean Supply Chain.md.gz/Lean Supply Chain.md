A lean supply chain applies lean thinking, the creation of needed value with fewer resources and less waste, across the organisations in a supply chain, and is best suited to stable, predictable demand with low variety.[^1][^2][^3]

The Lean Enterprise Institute describes lean as a way of thinking about creating needed value with fewer resources and less waste, and says that lean thinking always starts with the customer.[^1] In the supply chain literature, Christopher and Towill quote Naylor and colleagues for a working definition: leanness means developing a value stream to eliminate all waste including time, and to enable a level schedule.[^2]

Those authors report that lean concepts work well where demand is relatively stable and hence predictable and where variety is low.[^2] Mason-Jones, Naylor and Towill make the matching point in their abstract: lean manufacturing is adopted where demand is stable, and agile manufacturing where it is volatile.[^3] In a lean chain, quality, service level and lead time are market qualifiers and cost is the market winner.[^2]

## Scope and distinctions

Lean is not the same as agile. Christopher writes that lean is about doing more with less, that the term is often tied to a zero inventory, just-in-time approach, and that many companies that adopted lean manufacturing are anything but agile in their supply chain.[^4] The two can be combined: Mason-Jones and colleagues propose using “a different paradigm on either side of the material flow de-coupling point”, an approach they call the “Leagile Paradigm”.[^3] See [[Agile Supply Chain]] and [[Supply Chain Strategy Type]].

Just-in-time is a related idea. The Lean Enterprise Institute defines just-in-time as a system of production that makes and delivers just what is needed, just when it is needed and in the amount needed, and names it as one of the two pillars of the Toyota Production System.[^5] The shop-floor system is covered at [[Lean Production]]; this page concerns the chain as a whole.

The NIST Manufacturing Extension Partnership says its lean expertise can be applied across tiers in a supply chain, which supports treating lean as something extended beyond a single plant.[^6]

## What the sources do not establish

No source opened here defines lean supply chain as a fixed phrase. That definition is assembled from the Lean Enterprise Institute's account of lean and from the supply chain papers that apply it, and the two Lean Enterprise Institute pages opened say nothing about supply chains. None of the sources states measures of how lean a chain is, and none defines the relation to Fisher's physically efficient chain, although Fisher calls a lean, efficient distribution channel right for functional cars.[^1][^2][^7]

[^1]: Lean Enterprise Institute, “What is Lean?”. https://www.lean.org/explore-lean/what-is-lean/
[^2]: Martin Christopher and Denis Towill, International Journal of Physical Distribution and Logistics Management, 2001 (Cranfield repository copy), “An Integrated Model for the Design of Agile Supply Chains”. https://dspace.lib.cranfield.ac.uk/bitstreams/db14daf6-8518-476e-9211-b6af2f1515a5/download
[^3]: Rachel Mason-Jones, Ben Naylor and Denis R. Towill, International Journal of Production Research, 2000 (Cardiff Metropolitan University record, abstract only), “Lean, agile or leagile? Matching your supply chain to the marketplace”. https://pure.cardiffmet.ac.uk/en/publications/lean-agile-or-leagile-matching-your-supply-chain-to-the-marketpla/
[^4]: Martin Christopher, Industrial Marketing Management, 2000 (Cranfield repository copy), “The Agile Supply Chain : Competing in Volatile Markets”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/3e60f75d-28c1-4659-a260-6608c0e863f2/content
[^5]: Lean Enterprise Institute, “Just-in-Time Production”. https://www.lean.org/lexicon-terms/just-in-time-production/
[^6]: NIST Manufacturing Extension Partnership, “Supply Chain Management”. https://www.nist.gov/mep/supply-chain
[^7]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf

