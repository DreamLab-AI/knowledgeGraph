
An agent trigger is the condition or event that starts an agent, as part of its operational profile. The Agent Ontology declares `Trigger` without a definition; this one follows from its properties.[^1]

An [[Agent Operational Profile]] reaches its trigger through the property `trigger`, whose domain is the profile and whose range is `Trigger`. The kinds of trigger are not enumerated, so a schedule, a message or an external signal are all admissible.

Its siblings under the profile are the `InputSpec` and `OutputSpec` classes, which describe what the agent accepts and returns. visionGraph places the class under [[Event]] and relates it to [[Webhook]], one common way for an external event to reach an agent.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

