Make-to-order is a production strategy in which the customer's order is not manufactured until the order is received, which allows customisation to the exact specifications the customer requires.[^1]

An open operations management text says the strategy may also be called build-to-order and describes it as a pull system, in which work is pulled through the process when customer demand is present.[^1] Its disadvantage is time: the firm must acquire materials and components, then schedule and produce the order.[^1] Its advantage is that inventory is lower than in a typical make-to-stock system, with no uncertainty about what the customer wants and no obsolete stock to dispose of.[^1]

A second open text says the strategy is still commonly used by print or sign shops that produce low-volume, high-variety goods to customer specification, and that this level of customisation often results in a longer production and delivery cycle than other approaches.[^2] An MIT capstone calls it ideal for customised or low-volume products, minimising inventory costs but often resulting in longer lead times and planning complexity.[^3]

## Scope and distinctions

Make-to-order sits at the order-driven end of the spectrum described at [[Production Strategy]]; its counterpart is [[Make-to-Stock]]. Where the product is designed only after the order, see [[Engineer-to-Order]]. A trade glossary calls assemble-to-order a faster subset of make-to-order, because stocked components move the decoupling point down to final assembly; see [[Assemble-to-Order]].[^5]

A queueing paper notes that make-to-order systems offer more expensive products owing to the higher variety of customisation, and raises concerns about average order delay, response time and due date setting.[^4] The same paper studies a mixed arrangement in which semi-finished products are completed to stock when no customer is waiting and assigned to an order when one arrives.[^4]

## What the sources do not establish

No source gives figures for the lead time penalty, so the page does not, and none of them fixes where in the process make-to-order must begin.

[^1]: Engineering LibreTexts (Introduction to Operations Management, 1st Ed.), “6.2: Make-to-order and Make-to-stock”. https://eng.libretexts.org/Under_Construction/Purgatory/Introduction_to_Operations_Management_1st_Ed./06:_Process_Design/6.02:_Make-to-order_and_Make-to-stock
[^2]: eCampusOntario Pressbooks (Introduction to Canadian Business), “Operations Management”. https://ecampusontario.pressbooks.pub/bus108g/chapter/opsmanagement/
[^3]: MIT Center for Transportation and Logistics (Pooja Kashyap, capstone), “Optimizing Hybrid Assembly Strategies in Supply Networks: Evaluation of Make-to-Stock and Make-to-Order Models”. https://ctl.mit.edu/sites/default/files/documents/optimizing-hybrid-assembly-strategies-in-supply-networks-evaluation-of-make-to-stock-and-make-to-order-models-capstone.pdf
[^4]: Production (Associação Brasileira de Engenharia de Produção), Ghalehkhondabi and Suer, via Redalyc, “Production line performance analysis within a MTS/MTO manufacturing framework: a queueing theory approach”. https://www.redalyc.org/journal/3967/396754754007/html/
[^5]: ERP Research, “What is ATO (Assemble-to-Order)? — ERP Glossary”. https://erpresearch.com/glossary/assemble-to-order

