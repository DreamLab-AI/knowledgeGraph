Six Sigma is a process improvement methodology that aims to eliminate defects in any process.[^1]

The Lean Enterprise Institute says the goal of Six Sigma is a process so consistent and predictable that it produces a defect rate of only 3.4 defects per million opportunities.[^1] The US Environmental Protection Agency describes Six Sigma as a set of statistical methods for systematically analysing processes to reduce process variation, and says a Six Sigma quality level equates to approximately 3.4 defects per million opportunities.[^2] An Emory University article gives the same figure as no more than 3.4 defects per million opportunities.[^3]

## Method

The Agency says a sequence of steps called DMAIC, standing for Define, Measure, Analyze, Improve and Control, is typically used to guide implementation of the statistical tools and to identify process wastes and weaknesses.[^2]

## Sources disagree on origin

The Lean Enterprise Institute says Motorola first coined the name in the 1980s to describe its quality control program.[^1] The Emory article also dates the development at Motorola to the 1980s and credits the engineer Bill Smith.[^3] The Agency says Six Sigma was developed by Motorola in the 1990s, drawing on established statistical quality control techniques.[^2] The sources do not reconcile the dates. The Emory page sits on a training-programme site, so its account is treated with caution.

## Scope and distinctions

The Agency notes that not all companies using Six Sigma methods are implementing lean manufacturing systems, and that some integrate their kaizen processes with Six Sigma.[^2] The Institute calls lean and Six Sigma complementary rather than substitutive, says Six Sigma suits difficult quality control problems needing rigorous statistical analysis, and warns that its reliance on statistics limits the number of people able to practise it and that certification does not necessarily indicate capability.[^1] A review of operations and supply chain management lists Six Sigma alongside total quality management and lean as improvement initiatives.[^4] See [[Total Quality Management]], [[Lean Production]] and [[Kaizen]].

## What the sources do not establish

No source says how the 3.4 figure is derived, including the assumptions about process shift behind it, so the page does not. They offer no independent evidence of results.

[^1]: Lean Enterprise Institute, “Six Sigma - A Resource Guide”. https://www.lean.org/lexicon-terms/six-sigma/
[^2]: US Environmental Protection Agency, “Lean Thinking and Methods - Six Sigma”. https://www.epa.gov/sustainability/lean-thinking-and-methods-six-sigma
[^3]: Emory University (continuing education), blog article, “Creation of Six Sigma: Revolutionizing QA and Business Processes”. https://ece.emory.edu/articles-news/creation-six-sigma.php
[^4]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

