Mediterranean Shipping Company (MSC) is a container shipping and logistics group based in Switzerland. The European Commission described MSC Group in a 2024 decision as providing worldwide container liner shipping services and ancillary services combining shipping with rail, river and road transport, as well as container handling, terminal management services and towage services at ports.[^1]

## What MSC says it does

MSC's own site, read in a browser because it blocks automated fetching, lists a Geneva headquarters address and describes the group as family-run.[^2] It says its solutions include overland transportation, logistics and a growing portfolio of port terminal investments.[^2] The Commission's description agrees by listing terminal and inland services alongside liner shipping.[^1][^2]

## Role in the supply chain

MSC is an [[Ocean Carrier]] in this vault, and the Commission's description of container liner shipping supports that placement.[^1] The same decision records that MSC Group is also active in cruises and in passenger ferries, and gives MSC Mediterranean Shipping Company Holding S.A. as the holding company of a Swiss group.[^1] An earlier Commission decision, on terminal joint ventures, describes the terminal company TIL as indirectly jointly controlled by MSC Mediterranean Shipping Company Holding SA together with funds managed by Global Infrastructure Management, and says that TIL invests in, develops and manages container terminals around the world, often in joint ventures with other major terminal operators.[^3]

The Alphaliner operator list consolidates WEC Lines and Log-In Logistica under MSC for its fleet ranking, which shows that fleet figures for the group include more than one brand.[^4]

## What the sources do not establish

Sources give no capacity, fleet or market-share figures: the MSC page shows estimated 2024 figures that are self-reported, and the independent UNCTAD tables could not be opened and the Alphaliner page carries its ranking only as a graph. No source opened states a founding date or the ownership structure beyond the holding company named in the Commission decisions.[^2][^4]

[^1]: European Commission, Case M.11326 MSC / GIP III / Italo, decision of 27 February 2024. https://ec.europa.eu/competition/mergers/cases1/202417/M_11326_10004219_298_3.pdf
[^2]: Mediterranean Shipping Company, “About Us”. https://www.msc.com/en/about-us
[^3]: European Commission, Case M.8459 TIL / PSA / PSA DGD, decision of 31 July 2017. https://ec.europa.eu/competition/mergers/cases/decisions/m8459_152_3.pdf
[^4]: Alphaliner (AXS Marine), PublicTop100 page, consolidated operator notes. https://alphaliner.axsmarine.com/PublicTop100/

