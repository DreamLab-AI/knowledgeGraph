A wholesaler is a business that sells goods in bulk to retailers, to business users or to other wholesalers rather than to final consumers. The United Nations ISIC defines wholesale as the resale, without transformation, of new and used goods to retailers, to industrial, commercial, institutional or professional users, or to other wholesalers, and Eurostat's glossary describes wholesale trade as the sale of goods in bulk to resellers, professional users or groups who then sell the products to final consumers.[^1][^2]

## Definitions in the sources

The ISIC names the principal types of business as merchant wholesalers, meaning wholesalers who take title to the goods they sell, such as wholesale merchants or jobbers, industrial distributors, exporters, importers and cooperative buying associations.[^1] It also includes wholesale activity that involves acting as an agent or broker in buying or selling goods for such companies.[^1]

The Industrial Ontologies Foundry defines a wholesaler as a person or business organisation that buys products from distributors and resells them to retailers or other business organisations.[^3] Its explanatory note describes a wholesaler as a distributor that sells in bulk quantities to retailers, which lets the retailer take advantage of a lower price than buying single items.[^3] Its example of the role is Sysco selling food products in large quantities to out-of-home dining businesses.[^3]

## Scope and distinctions

In this vault a Wholesaler is a kind of [[Product Distributor]], because the ISIC counts industrial distributors among wholesalers, and it sits upstream of the [[Retailer]]. The IOF places wholesalers one step further down the chain than distributors, so the sources do not agree on whether a distributor sells to a wholesaler or is one; see [[Product Distributor]] for the discussion.[^3][^1] Pharmaceutical wholesale is illustrated by [[McKesson]].

## What the sources do not establish

Sources define the role by whom the goods are sold to and by the absence of transformation. They do not give a threshold quantity that separates bulk sale from retail sale, and they do not say how large the wholesale sector is. Eurostat's glossary entry names the OECD glossary, citing NACE, as its source rather than giving an independent definition, so the two statistical sources are close in substance.[^2][^1]

[^1]: United Nations Statistics Division, “International Standard Industrial Classification of All Economic Activities (ISIC), Revision 4”. https://unstats.un.org/unsd/classifications/Econ/Download/In%20Text/ISIC_Rev_4_publication_English.pdf
[^2]: Eurostat, Statistics Explained, “Glossary:Wholesale trade”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Wholesale_trade
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

