Category management is the business practice of buying common goods and services as an enterprise to eliminate redundancies, increase efficiency, and deliver more value and savings from acquisition programmes.[^1]

That is the wording of United States Office of Management and Budget memorandum M-19-13, which adds that teams of experts in each category of spending help agencies use common contract solutions and practices and align decentralised spending with agency-level and government-level spending strategies by sharing market intelligence and best practices.[^1] The Office of Federal Procurement Policy's 2016 notice describes it as a strategic practice in which federal contracting for common goods and services is managed by categories of spending across the government and supported by teams of experts.[^2]

The UK Cabinet Office takes a categorisation approach to its spend data: its Common Areas of Spend definitions say procurement spend should be captured against UNSPSC or CPV level 4 coding for product groups, so that the Government Procurement Service can map spend against the procurement categorisation structure it maintains.[^3]

That memorandum adds that, as agencies make better use of agency-wide and government-wide solutions to reduce duplicative contracts, which are expensive and time consuming to award and administer, the acquisition workforce can spend less time on repetitive needs common to all agencies and more on complex, mission-specific challenges.[^1]

## Scope and distinctions

The US sources treat category management as an enterprise-wide, government-level practice, whereas strategic sourcing is described in the same notice as an earlier set of initiatives.[^2] See [[Strategic Sourcing]], [[Spend Analysis]] and [[Procurement]].

## What the sources do not establish

Two of the three sources are United States federal documents written for public agencies, and the UK source defines spend categories rather than the practice, so the private-sector sense is not separately sourced.[^1][^2][^3]

[^1]: US Office of Management and Budget, memorandum M-19-13 (20 March 2019), “Category Management: Making Smarter Use of Common Contract Solutions and Practices”. https://www.whitehouse.gov/wp-content/uploads/2019/03/M-19-13.pdf
[^2]: Office of Federal Procurement Policy, Federal Register, 7 October 2016, “Category Management”. https://www.federalregister.gov/documents/2016/10/07/2016-24054/category-management
[^3]: UK Cabinet Office, Common Areas of Spend definitions (Crown copyright), “Common Areas of Spend Procurement Standard Definition Release 9 v1”. https://assets.publishing.service.gov.uk/media/607e85b0d3bf7f01343a06e0/Procurement_CAS_Definition_Release_9_v1__2_.pdf

