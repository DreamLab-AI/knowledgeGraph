Available-to-promise (ATP) is the uncommitted portion of inventory and planned production in the master schedule, kept to support customer order promising.[^1][^2][^3]

Infor says ATP contains on-hand inventory, scheduled receipts and reserved inventory, which lets a company give reliable delivery dates. It is calculated in periods: the first includes the current on-hand balance and extends to the first scheduled receipt, each later period begins with a scheduled delivery, and ATP is calculated by subtracting the reserved quantity from the available or on-order quantity. A negative value signals a shortage, and the calculation does not include forecasts.[^1]

Oliver Wight's glossary gives a near-identical definition: the uncommitted portion of a company's inventory or planned production, normally calculated from the master production schedule and maintained as a tool for order promising.[^2] The ASCM certification text describes how the committed portion of the master schedule, in the form of actual orders, leaves an uncommitted portion to be promised to customers who have not yet ordered, which is the ATP. It says ATP is calculated for the first period of the schedule and then for each period that has a master schedule receipt, with the first period drawing on available inventory.[^3]

## Scope and distinctions

Infor lists discrete ATP and cumulative ATP, with or without look-ahead, as calculation methods.[^1] The ASCM text mentions the same two cumulative methods but does not present them.[^3] ATP is the quantity side of [[Order Promising]]; see also [[Master Production Scheduling]].

## What the sources do not establish

These three definitions agree in substance but are close paraphrases of one industry definition, so they are not fully independent, and none is from a peer-reviewed source.[^1][^2][^3]

[^1]: Infor, Infor M3 documentation, “Available-to-promise (ATP)”. https://docs.infor.com/m3udi/16.x/en-us/m3beud/scplanhs/cts090.html
[^2]: Oliver Wight Americas, glossary, “Available-to-Promise (ATP)”. https://www.oliverwight-americas.com/glossary-terms/available-to-promise-atp/
[^3]: ASCM (APICS), CPIM Version 6.1, 2019 Edition, excerpt citing the APICS Dictionary, 15th edition, excerpt of the certification text, Section F: Master Planning. https://learningsystem.ascm.org/wp-content/uploads/2018/11/APICS_CPIM_2019_Excerpt.pdf

