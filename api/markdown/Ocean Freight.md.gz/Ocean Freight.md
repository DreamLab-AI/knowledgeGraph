Ocean freight is the carriage of goods by merchant ship on journeys undertaken wholly or partly at sea.[^1]

The Glossary for transport statistics defines sea transport as any movement of goods or passengers using merchant ships on journeys undertaken wholly or partly at sea, and scheduled sea traffic as traffic provided by sea vessels scheduled and performed according to a published timetable, or so regular or frequent as to constitute a recognisably systematic series.[^1] Scheduled container services are covered at [[Container Shipping]].

## Scale

The International Chamber of Shipping, a trade association, says the international shipping industry is responsible for the carriage of around 90% of world trade, and that without shipping, intercontinental trade and the bulk transport of raw materials would not be possible.[^2] In the EU maritime transport accounted for the largest share of freight transport performance among five modes over the last decade, 67.0% (4 753 billion tonne-km) in 2024, which was its lowest share of the decade after falling for five consecutive years.[^3] In UK domestic freight water moved 10% in 2024, 21 billion tonne-kilometres, and goods moved by sea have generally declined over the past 10 years.[^4]

## Scope and distinctions

Ocean Freight is a [[Freight Transport Mode]]. Related pages are [[Container Shipping]], [[Shipping Container]], [[Satellite Imagery]] and [[Synthetic Aperture Radar]].

## What the sources do not establish

The ICS page does not say whether its 90% figure is a share of volume or of value, and it is an industry body's own statement. The EU share is for transport performance in tonne-kilometres within the EU and the UK share is for domestic freight, so the figures are not the same measure. The UNCTAD Review of Maritime Transport could not be opened.

[^1]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^2]: International Chamber of Shipping, “Shipping and World Trade: Largest beneficial ownership countries”. https://www.ics-shipping.org/?p=3918
[^3]: Eurostat, Statistics Explained, “Freight transport statistics - modal split”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Freight_transport_statistics_-_modal_split
[^4]: UK Department for Transport (GOV.UK), “Transport Statistics Great Britain: 2024 Freight”. https://www.gov.uk/government/statistics/transport-statistics-great-britain-2025/transport-statistics-great-britain-2024-freight

