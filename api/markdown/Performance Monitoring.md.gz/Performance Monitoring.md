Performance Monitoring is the continuous collection, analysis, and visualisation of metrics describing how a system, application, or model behaves under real workloads. It tracks indicators such as latency, throughput, error rates, resource utilisation, and, for machine-learning systems, predictive quality and drift, surfacing degradation through dashboards and alerts. Performance monitoring is a core observability discipline that enables teams to detect regressions, diagnose bottlenecks, and uphold service-level objectives.

### Overview

- Performance Monitoring turns raw [[Telemetry]] into actionable insight about system health. Instrumentation emits metrics, traces, and logs that are aggregated, evaluated against thresholds, and rendered on dashboards, with [[Anomaly Detection]] surfacing deviations automatically. For machine-learning systems it extends beyond infrastructure to model accuracy, data drift, and prediction latency, making it inseparable from [[MLOps]] and [[AI Monitoring]] practice.

### Key aspects

- Continuous collection of latency, throughput, and error metrics.
- Dashboards and alerting against service-level objectives.
- [[Anomaly Detection]] to surface regressions automatically.
- Model-quality and drift tracking for ML workloads.
- Closing the [[Feedback Loop]] into operations and remediation.

### Applications

- Application performance management for web services.
- Model drift and accuracy tracking in [[MLOps]] pipelines.
- Capacity planning and bottleneck diagnosis.
- Reliability engineering and incident response.

### Provenance

