A logical clock is a mechanism for ordering events in a distributed system without relying on synchronised physical time. It assigns monotonically increasing counters to events so that causal relationships between them can be inferred, supporting the happened-before relation. Logical clocks underpin consistency, coordination and debugging in systems where no global wall-clock can be trusted.

### Overview

- Logical clocks were introduced to reason about ordering when physical clocks drift and message delays are unbounded. Lamport-style scalar clocks provide a total order consistent with causality, while vector clocks capture concurrency precisely by tracking per-process counters.

### Mechanisms

- Each process maintains a counter incremented on local events
- Counters are piggybacked on outgoing messages
- Receivers advance their counter past the received value
- The happened-before relation is preserved by counter monotonicity
- Vector clocks extend the idea to detect concurrent events

### Applications

- Event ordering in replicated databases and logs
- Detecting causal dependencies for conflict resolution
- Distributed snapshots and consistent checkpoints
- Debugging and tracing of distributed executions

### Provenance

