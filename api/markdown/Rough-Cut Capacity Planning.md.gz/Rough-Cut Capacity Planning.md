Rough-cut capacity planning (RCCP) is a check of whether a master production schedule is feasible on a few critical resources before material requirements planning is run.[^1][^2][^3]

Gallego explains that MRP implicitly assumes infinite capacity, and that RCCP addresses this by checking the capacity of a few critical resources. It uses a bill of resources for each item on the master schedule, which gives the hours needed at each critical resource to build an end item and its components, aggregates those hours over the end items in the schedule, and checks whether the available resources cover them in each time bucket.[^1] He notes that RCCP does not perform time offsets, so its time buckets must be large enough for parts and components to be completed within one bucket, which usually makes it an optimistic estimate of what can be done.[^1]

The Cambridge Institute for Manufacturing describes RCCP as an initial attempt to match the order load to the capacity available by calculating, with simplifying assumptions, the load per resource. Overloads are identified and orders can be moved to achieve a balance, which it quotes as “knocking the mountains (the overloads) into the valleys (periods of underload)”.[^2]

## In practice

Oracle's JD Edwards World documentation says to validate a master schedule after creating it to ensure there is sufficient work centre capacity. Inputs are firm and planned master schedule work orders with routing instructions, and outputs include over-capacity and under-capacity messages and work centre load.[^3] It lists the steps as identifying critical work centres, identifying their pacing resource, calculating rated capacity and calculating the master schedule load.[^3] RCCP indicates whether to revise the master schedule to create feasible work loads or improve use of limited resources.[^3] See [[Master Production Scheduling]], [[Capacity Requirements Planning]] and [[Manufacturing Resource Planning]].

## What the sources do not establish

Only one academic source describes the bill of resources, and the practical steps come from one vendor, so details differ between systems.[^1][^3]

[^1]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “Material Requirements Planning (MRP)”. http://www.columbia.edu/~gmg2/4000/pdf/lect_06.pdf
[^2]: University of Cambridge Institute for Manufacturing, Decision Support Tools, “Manufacturing Resource Planning (MRP II)”. https://www.ifm.eng.cam.ac.uk/research/dstools/mrp-ii/
[^3]: Oracle, JD Edwards World Material Planning documentation, chapter 20, “Validate Master Schedules”. https://docs.oracle.com/cd/E26228_01/doc.93/e21770/ch_validate_mstr_sched.htm

