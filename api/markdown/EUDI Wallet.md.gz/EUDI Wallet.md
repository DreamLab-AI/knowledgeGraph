The EUDI Wallet (European Digital Identity Wallet) is a mobile application framework mandated under the revised eIDAS regulation, enabling European citizens and residents to store, present, and selectively disclose identity attributes and credentials across member states. It allows holders to prove identity, sign documents, and share verifiable attestations with public and private services while retaining control over what data is revealed. The wallet is the user-facing instrument of the EU's interoperable cross-border identity scheme.

- The [[EUDI Wallet]] is the EU's regulated mobile identity wallet, standardised by [[eIDAS Regulation]], that lets holders store and selectively present [[Verifiable Credential]]. It is a concrete [[Digital Identity Wallet]] supporting cross-border [[Identity Verification]] and strong [[Privacy]] guarantees.

### Overview

- Under the revised eIDAS framework, each member state must offer at least one wallet conforming to a common technical specification, ensuring credentials issued in one country are accepted in another.
- The wallet holds attestations such as identity documents, diplomas, and entitlements, and presents them to relying parties on the holder's terms. Citizens decide which attributes to share for any given interaction.
- Privacy by design is central: [[Selective Disclosure]] and [[Zero-Knowledge Proof]] techniques let a holder prove a fact, such as being over eighteen, without revealing the underlying data, aligning with [[GDPR]].

### Mechanisms

- Credential storage: signed attestations are held securely on the holder's device.
- Selective disclosure: only the attributes required for a transaction are revealed.
- Strong authentication: cryptographic binding to the holder enables high-assurance [[Authentication]].
- Trust infrastructure: a common [[Trust Framework]] and registries of issuers and relying parties anchor verification.

### Applications

- Accessing public services and signing documents across EU member states.
- Proving age or qualifications to private services with minimal data exposure.
- Strong customer authentication for banking and regulated onboarding.
- Cross-border interoperability built on [[Decentralised Identifier]] and credential standards.

### Provenance

