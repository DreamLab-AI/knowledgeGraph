A customs broker is a person licensed to transact customs business on behalf of others. The United States regulation states that a “Customs broker” means a person who is licensed under that part to transact customs business on behalf of others, and that “Broker” means a customs broker.[^1]

## In practice

US Customs and Border Protection explains that licences are issued to persons, meaning individuals, corporations, partnerships and associations, to conduct “customs business” on behalf of other persons.[^2] The regulation describes customs business as activities involving transactions with CBP concerning the entry and admissibility of merchandise, its classification and valuation, and the payment of duties, taxes or other charges assessed or collected by CBP on merchandise by reason of its importation, together with the refund, rebate or drawback of those charges.[^1]

HM Revenue and Customs uses the wider phrase customs agents or brokers for those who make sure goods clear through customs, and lists them alongside freight forwarders and express operators as businesses a trader can hire to deal with customs.[^3] Such businesses need to be established in the UK for customs, and the guidance points traders to a register of customs agents and express operators.[^3] It adds that the trader remains responsible for due diligence for its customs declarations when it appoints someone to act.[^3]

## Scope and distinctions

A customs broker is a kind of [[Logistics Service Provider]] that works on the declaration side of trade, as in a [[Customs Declaration]]. It differs from a [[Freight Forwarder]], which arranges carriage, although HM Revenue and Customs notes that a forwarder will arrange the clearing of goods through customs, so one firm can hold both roles.[^3]

## What the sources do not establish

Evidence comes from the United States and the United Kingdom only, and the page rests on those two jurisdictions' official sources. In the United States the term is tied to a licence issued under a specific regulation, while the UK guidance page opened describes agents and brokers as a type of business and does not mention a broker licence.[^1][^3] The sources opened do not describe the position in the European Union or in other customs territories, and they give no figures on the number of brokers.

[^1]: Cornell Law School Legal Information Institute, “19 CFR § 111.1 - Definitions”. https://www.law.cornell.edu/cfr/text/19/111.1
[^2]: US Customs and Border Protection, “Customs Brokers”. https://www.cbp.gov/trade/programs-administration/customs-brokers
[^3]: HM Revenue and Customs on GOV.UK, “Get someone to deal with customs for you”. https://www.gov.uk/guidance/appoint-someone-to-deal-with-customs-on-your-behalf

