McKesson is a pharmaceutical wholesaler and healthcare distribution company. The European Commission described McKesson Corporation in a 2023 decision as a pharmaceutical wholesale and retail company providing logistics and services in the healthcare sector.[^1]

## What the sources say

McKesson's own site says that it distributes pharmaceuticals and medical supplies to healthcare settings across North America, from pharmacies and hospitals to doctors' offices and clinics.[^2] An earlier Commission decision states that McKesson operates in the distribution and delivery of pharmaceuticals and medical equipment, medical supply products, and the delivery of healthcare information technology to healthcare organisations.[^3]

In United States drug supply chain law, a wholesale distributor is a person, other than a manufacturer, a manufacturer's co-licensed partner, a third-party logistics provider or a repackager, engaged in wholesale distribution.[^4] That statutory category is the legal frame in which a pharmaceutical wholesaler operates in the United States, though none of the sources opened states which category McKesson falls into.[^4][^2]

## Role in the supply chain

McKesson is a [[Wholesaler]] in the pharmaceutical chain; see [[Pharmaceutical Supply Chain]] and [[MediLedger]]. In this vault McKesson is a class under the wholesaler role, not an individual.

## What the sources do not establish

Sources give no revenue, customer or market-share figures, and the two Commission descriptions differ in what they emphasise, wholesale and retail in one and distribution and health information technology in the other.[^1][^3] They also give no list of the countries or product lines in which McKesson operates. The link to MediLedger is a vault relation, and no source opened here describes McKesson's participation in it.

[^1]: European Commission, Case M.10404 Phoenix / McKesson, decision of 2023. https://ec.europa.eu/competition/mergers/cases1/202316/M_10404_9151122_703_3.pdf
[^2]: McKesson, About McKesson page. https://www.mckesson.com/about-mckesson/
[^3]: European Commission, Case M.7818 McKesson / UDG Healthcare (Pharmaceutical Wholesale and Associated Businesses). https://ec.europa.eu/competition/mergers/cases/decisions/m7818_331_3.pdf
[^4]: Cornell Law School Legal Information Institute, “21 U.S. Code § 360eee - Definitions”. https://www.law.cornell.edu/uscode/text/21/360eee

