The Internet Engineering Task Force (IETF) is an open, volunteer-driven standards organisation that develops and promotes the voluntary technical standards underpinning the Internet, published as Requests for Comments (RFCs). Organised into working groups by topic area, it produces core protocol specifications such as IP, TCP, HTTP, TLS and DNS through rough-consensus and running-code processes. The IETF operates under the Internet Society and coordinates with bodies like the Internet Architecture Board to maintain a coherent, interoperable Internet architecture.

### Overview

- The IETF develops the open standards that define how the Internet's protocols operate.
- Its work is published as Requests for Comments and produced by topic-focused working groups.
- The organisation favours rough consensus and running code over formal voting.

### Key aspects

- Working groups specify protocols incrementally through draft and RFC stages.
- Core specifications cover IP, TCP, [[HTTP]], [[Transport Layer Security]] and [[DNS]].
- It coordinates with the Internet Architecture Board on long-term direction.
- Open participation lets any contributor join the standards process.

### Applications

- Specification of transport and application [[Network Protocol]] standards.
- Security protocols including [[Transport Layer Security]] and authorisation frameworks like [[OAuth]].
- Naming and addressing standards such as [[DNS]].
- Foundational [[Web Standards]] enabling global [[Interoperability]].

### Provenance

