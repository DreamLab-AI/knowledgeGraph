Classifier evaluation is the set of methods and metrics used to assess how well a trained classification model performs, covering measures such as accuracy, precision, recall, specificity and area under the ROC curve, computed against held-out labelled data. Different metrics emphasise different error costs, so evaluation practice typically reports several complementary measures rather than a single figure, particularly under class imbalance. It is a specific application of the broader discipline of model evaluation to classification tasks.

### Provenance

