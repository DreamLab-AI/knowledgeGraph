A State Space Model (SSM) is a mathematical framework that represents a dynamical system through a hidden (latent) state vector whose evolution over discrete or continuous time is governed by linear or learnable recurrence equations, paired with an output equation mapping states to observations. Originally formalised in control theory and signal processing — with the Kalman filter as a canonical inference algorithm — SSMs have been re-parameterised as structured sequence layers in deep learning, enabling sub-quadratic scaling in sequence length as an alternative to self-attention. Modern deep SSM variants such as S4, Mamba, and RWKV exploit diagonal or low-rank structure in the state transition matrix to achieve hardware-efficient training and inference on long sequences.

### Overview

- State space models formalise the idea that a time-evolving system can be fully characterised by a compact internal state, regardless of how much history has elapsed. This is powerful because it decouples the complexity of the past (represented in the state) from the cost of processing new observations.
- **Classical origins**: SSMs emerged from the work of Rudolf Kálmán in the early 1960s as a general representation for linear dynamical systems. The [[Kalman Filter]] provides closed-form optimal Bayesian updates of the hidden state given noisy observations, and underpins navigation, econometrics, and engineering control loops to this day.
- **Deep learning adaptation**: Starting around 2021 with the S4 (Structured State Space for Sequences) paper, researchers discovered that SSMs could be parameterised and trained as neural layers. By constraining the state transition matrix to diagonal-plus-low-rank form and initialising it with the [[HiPPO Initialisation]] scheme (which captures polynomial projections of recent history), these layers can be efficiently implemented as a global [[Convolution]] during training and as a linear [[Recurrent Neural Network]] during inference.
- **Selective SSMs (Mamba)**: A key limitation of early SSMs was that the dynamics were input-independent — the same transition matrix applied to every token. Mamba (2023) introduced input-dependent selection, making the transition parameters functions of the current token. This added an inductive bias analogous to [[Self-Attention]]'s dynamic weighting, while retaining linear inference cost.
- **Why it matters**: The quadratic memory and compute cost of [[Self-Attention]] in [[Transformer]] models becomes prohibitive for very long sequences (DNA, audio waveforms, video, long documents). SSMs offer a path to O(L) inference at sequence length L, making them attractive for production deployment where memory footprint and latency matter.

### Key Components

- **State transition equation**: `h(t) = A·h(t-1) + B·x(t)` — the recurrence that evolves the hidden state `h` given input `x` and learned matrices `A`, `B`.
- **Output equation**: `y(t) = C·h(t) + D·x(t)` — maps the hidden state to the observable output via learned matrices `C`, `D`.
- **Discretisation**: Continuous-time SSMs are converted to discrete-time via the zero-order hold or bilinear (Tustin) transform, producing discrete matrices `Ā`, `B̄` used during forward passes.
- **[[HiPPO Initialisation]]**: A principled scheme to initialise the `A` matrix so that the hidden state captures Legendre polynomial projections of recent input history, enabling long-range recall from the start of training.
- **Structured parameterisations**: Diagonal-plus-low-rank (DPLR) or fully diagonal constraints on `A` reduce the matrix-vector products to element-wise operations, enabling efficient [[Convolution]]-based training via the Fast Fourier Transform.
- **Input-dependent gating (Mamba)**: Extends the base SSM by making `B`, `C`, and a selective scan parameter Δ functions of the input, introducing content-based routing analogous to [[Selective Attention]].
- **Parallel scan**: The linear recurrence across a batch of tokens can be computed in O(L log L) using the parallel prefix scan algorithm, enabling GPU-friendly training without sequential bottlenecks.
- **[[Probabilistic Model]] perspective**: In the Bayesian framing (classic SSMs), `A`, `B`, `C` define a Gaussian linear dynamical system; the [[Kalman Filter]] is the exact posterior inference algorithm. Deep SSMs retain this structure but train `A`-`D` with gradient descent rather than EM.

### Prominent Architectures

- **S4 (Structured State Space Sequences)**: Introduced diagonal-plus-low-rank constraints and [[HiPPO Initialisation]], achieving strong results on the Long-Range Arena benchmark. Forms the foundation for subsequent work.
- **Mamba**: Adds selective (input-dependent) scanning, using a hardware-aware algorithm (parallel scan with recomputation) to avoid materialising the expanded state. Competitive with [[Transformer]] models at moderate scale.
- **RWKV**: Reformulates the recurrence as a gated linear attention mechanism, bridging SSMs and [[Recurrent Neural Network]] architectures and deployable as both an RNN (inference) and a [[Transformer]]-style parallel model (training).
- **H3 (Hungry Hungry Hippo)**: Combines SSM layers with a single head of local [[Self-Attention]] to capture associative recall, addressing a known weakness of pure SSMs in in-context learning.
- **Jamba**: A hybrid architecture interleaving Mamba SSM blocks with [[Transformer]] attention layers, aiming to capture the strengths of both paradigms.
- **Mamba-2**: Refines the connection between SSMs and structured attention, unifying the selective SSM and linear attention under a single State Space Duality framework.

### Applications

- **[[Language Model]] pre-training**: SSM layers can replace or augment attention in LLM architectures, with Mamba-based models demonstrated at the 1B–7B parameter scale.
- **[[Audio Generation]]**: WaveNet-style autoregressive models and diffusion-based audio synthesisers benefit from SSMs' efficient long-sequence handling; SaShiMi applies SSMs to raw audio.
- **[[Time Series Forecasting]]**: Classical SSMs underpin exponential smoothing, ARIMA variants, and the Kalman smoother used in econometrics and meteorological forecasting.
- **Genomics**: SSMs process extremely long DNA sequences (tens of thousands of base pairs) where Transformer quadratic cost is prohibitive; HyenaDNA and Caduceus apply SSM principles to genomic modelling.
- **Video understanding**: Long temporal sequences in video benefit from SSM layers that propagate information efficiently across many frames.
- **[[Robotics Control]]**: Classical state-space representations are central to model predictive control (MPC) and extended Kalman filter-based state estimation in robotic systems; deep SSMs offer a data-driven extension.
- **[[Autonomous Systems]]**: Sensor fusion (LIDAR, IMU, GPS) in self-driving vehicles relies on Kalman filter variants operating as SSMs over continuous-time dynamics.
- **Medical time series**: EEG, ECG, and physiological signal processing use SSMs for filtering, anomaly detection, and causal inference.

### Standards & Context

- SSMs do not yet have a dedicated standardisation body or benchmark specification, but they are evaluated against the **Long-Range Arena (LRA)** benchmark suite, which tests sequence models on pathfinder, ListOps, text classification, retrieval, and image tasks at sequence lengths of 1,000–16,000 tokens.
- The **RWKV community** maintains an open specification for RWKV-series architectures under the Apache 2.0 licence, providing a reference implementation that bridges SSMs and [[Transformer]] tooling.
- Classical SSMs (Kalman filtering, linear-quadratic regulators) are formalised in IEEE standards for [[Control Theory]] and [[Signal Processing]], including IEEE 1588 (precision time protocol) applications in distributed control.
- The [[Deep Learning]] research community has converged on the term "structured state space model" (S4 and descendants) to distinguish deep SSMs from their classical control-theoretic ancestors, though both share the same mathematical core.
- Hugging Face Transformers library (from v4.35 onwards) includes Mamba and related SSM architectures under the `mamba`, `jamba`, and `falcon-mamba` model classes, providing de facto standardised APIs for [[Language Model]] practitioners.

### Provenance

