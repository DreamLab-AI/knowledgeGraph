Cross-docking is a warehousing practice in which goods from inbound trucks are unloaded, sorted and loaded directly onto outbound trucks, with little or no storage in between.[^1][^2][^3]

An eCampusOntario logistics text describes cross-docking as trucks that arrive at a warehouse and have their goods unloaded and, after sorting, loaded directly into another truck docked on the opposite side of the facility, and says that there is no actual storage involved.[^1] Georgia Tech's open textbook calls a crossdock a kind of high-speed warehouse in which product flows so fast that there is no point in putting it on a shelf, and says that turnover times in a high-volume crossdock may be measured in hours.[^2] A Colombian journal review presents cross-docking as a way to reduce logistics costs and customer response time by cutting storage and picking at the docks where vehicles arrive and leave.[^3]

## Why it is used

Bartholdi and Hackman give the biggest reason for a crossdock as reducing transportation costs. A crossdock receives product from many vendors, sorts it and prepares loads for each store, so that the freight bound for each store is typically enough to fill a trailer.[^2] They add two further benefits: less inventory, because all product flows right through, and less labour, because product does not have to be put away and later retrieved.[^2]

## Facility and planning

Georgia Tech's textbook adds that there is little or no storage in a crossdock because items do not stay long enough, but generally a lot of material-handling equipment such as forklifts and pallet jacks to move freight. The issues inside a crossdock are therefore those of material handling and product flow rather than location and retrieval.[^2] The Colombian review treats the combination of cross-docking and vehicle routing as a combinatorial optimisation problem classified as NP-hard, and surveys methods of solution.[^3]

## Scope and distinctions

Cross-docking is a [[Distribution Strategy]]. The eCampusOntario text lists cross-docking among common in-transit warehouse types, alongside consolidation, break-bulk, hub-and-spoke and distribution centres.[^1] Related pages are [[Warehouse Facility Type]], [[Distribution Centre]] and [[Warehousing and Distribution]].

## What the sources do not establish

Sources opened here state the benefits but give no measured savings or share of freight that is cross-docked. Their accounts of the practice agree on direct transfer and minimal storage, and the page does not go beyond them.

[^1]: eCampusOntario Pressbooks (Introduction to Logistics), “Chapter 5 – Warehousing”. https://ecampusontario.pressbooks.pub/logistics001oerfc/chapter/chapter-5-warehousing/
[^2]: Georgia Institute of Technology (Bartholdi and Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^3]: Universidad Nacional de Colombia (González-La Rotta and Becerra-Fernández), Dyna 84(200), 2017, “Cross-docking with vehicle routing problem. A state of art review”. https://www.redalyc.org/pdf/496/49650910033.pdf

