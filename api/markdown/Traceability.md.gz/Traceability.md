Traceability is the ability to trace the history, application or location of an object.[^1]

That is the wording GS1 quotes from ISO 9001:2015, and it adds that for a product or service traceability can relate to the origin of materials and parts, the processing history, and the distribution and location after delivery.[^1] The UN Global Compact guide quotes an earlier ISO definition, the ability to identify and trace the history, distribution, location and application of products, parts and materials.[^2] The two wordings differ in detail but cover the same elements.

## Legal definition for food

Regulation (EC) No 178/2002 defines traceability as the ability to trace and follow a food, feed, food-producing animal or substance intended to be, or expected to be incorporated into a food or feed, through all stages of production, processing and distribution.[^3] The Regulation requires that traceability be established at all stages, and that food or feed placed on the market be adequately labelled or identified to facilitate it.[^3]

## Purposes

In the context of sustainability, the Global Compact guide describes traceability as a tool to assure and verify sustainability claims associated with commodities and products.[^2] It states that traceability is not a substitute for due diligence or the broader scope of the corporate responsibility to respect human rights.[^2] GS1 describes its approach to enabling supply chain traceability as the use of open standards to provide visibility of objects that are relevant to supply chains.[^1]

## Scope and distinctions

Traceability applied across a chain is [[Supply Chain Traceability]], and the branch hub is [[Traceability and Product Identification]]. Related ideas are [[Supply Chain Provenance]] and [[Supply Chain Visibility]]. The sources use "trace" and "track" loosely, and GS1 says that for practical reasons "trace" or "track and trace" may be used as equivalent terms; this page does not separate them. The definitions are standards-based, and none is specific to blockchain or any one technology.

[^1]: GS1, Global Traceability Standard Release 2.0 (ratified August 2017), “GS1 Global Traceability Standard”. https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard
[^2]: United Nations Global Compact and BSR, 2014, “A Guide to Traceability: A Practical Approach to Advance Sustainability in Global Supply Chains”. https://www.unglobalcompact.org/docs/issues_doc/supply_chain/Traceability/Guide_to_Traceability.pdf
[^3]: European Parliament and Council of the European Union, Regulation (EC) No 178/2002 of 28 January 2002, “Regulation (EC) No 178/2002 of the European Parliament and of the Council laying down the general principles and requirements of food law”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32002R0178

