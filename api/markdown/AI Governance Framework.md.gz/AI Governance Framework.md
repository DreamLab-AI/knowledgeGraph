Set of policies and procedures ensuring responsible development and operation of AI components in the metaverse.

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:hasPart ai:EthicalFramework))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:hasPart ai:AIRiskAssessment))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:hasPart ai:AuditMechanism))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:hasPart ai:AIEthicsChecklist))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:hasPart ai:AlgorithmicTransparencyIndex))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:hasPart ai:AIImpactAssessment))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:hasPart ai:StakeholderEngagement))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:hasPart ai:HumanOversight))

## Dependency Relationships
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:requires ai:DataGovernance))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:requires ai:IdentityManagement))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:requires ai:AccessControl))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:requires ai:RegulatoryCompliance))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:requires ai:AIRiskManagement))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:requires ai:ModelDocumentation))

## Capability Relationships
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:enables ai:ResponsibleAI))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:enables ai:AIAccountability))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:enables ai:AITransparency))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:enables ai:TrustworthyAI))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:enables ai:AISafety))

## Implementation Relationships
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:implements ai:ISOiEC42001))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:implements ai:NISTAIRiskManagementFramework))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:implements ai:EUAIAct))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:implements ai:OECDAIPrinciples))

## Reduction Relationships
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:reducesTo ai:PolicyFramework))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:reducesTo ai:CompliancePolicy))
    SubClassOf(ai:AIGovernanceFramework
      ObjectSomeValuesFrom(ai:reducesTo ai:EthicalFramework))

## About

An AI Governance Framework is the architectural blueprint through which an organisation translates abstract ethical commitments and regulatory obligations into day-to-day operational controls over its AI systems.
Unlike a standalone policy document, a governance framework is systemic: it specifies governance bodies (AI ethics boards, risk committees, model review panels),
assigns ownership of AI outcomes to named roles across business, legal, technical, and compliance functions,
and establishes escalation pathways when AI behaviour deviates from expected parameters.
The concept matured through the convergence of several streams: professional risk management traditions (ISO 31000, COSO ERM),
data governance practice, machine ethics scholarship beginning with Asimov's informal rule-sets and formalised by Wallach and Allen's 2009 framework,
the IEEE's Ethically Aligned Design initiative (2016–2019),
and regulatory pressure crystallising in the OECD AI Principles (2019), the EU's High-Level Expert Group on AI (2019), and the NIST AI RMF (January 2023).

The five-pillar architecture that most enterprise-grade frameworks converge on was codified prominently in the Databricks AI Governance Framework (2024)
and echoed in standards from the Responsible AI Institute:
(1) accountability mechanisms — clear ownership and traceable responsibility chains;
(2) formalised governance bodies — AI ethics boards, risk review panels, model-release committees;
(3) cultural alignment — embedding governance obligations into engineering workflows rather than leaving them as compliance add-ons;
(4) principle-based policies — fairness, transparency, safety, non-discrimination written into model development agreements;
and (5) technical infrastructure — tooling for explainability dashboards, fairness auditing suites, continuous monitoring pipelines, and audit log retention.
The EU AI Act's risk-tiered architecture (unacceptable risk → high risk → limited risk → minimal risk) maps naturally onto a governance framework's policy stack:
high-risk AI systems (biometric identification, critical infrastructure, employment-related decisions) require conformity assessments, CE marking, and mandatory post-market surveillance logs,
all of which must be integrated into the organisation's governance procedures.
ISO/IEC 42001:2023, the first international standard for AI management systems, complements the Act by providing a certification-ready audit framework
that organisations can use to demonstrate governance maturity to regulators, customers, and investors.

Operationally, the framework's risk management pillar draws on the NIST AI RMF's four functions:
GOVERN (establishing policies and culture), MAP (contextualising AI risk within mission and stakeholder context),
MEASURE (quantifying trustworthiness characteristics through testing and monitoring),
and MANAGE (treating, documenting, and continuously reviewing residual risk).
The generative AI profile appended to the AI RMF as document AI 600-1 (July 2024) extends these functions to address the 12 risk categories
specific to large language models and multimodal systems — hazardous or violent content, misinformation, privacy violations, data poisoning, and so on —
providing the operational vocabulary for organisations deploying LLM-based [[AI Agent System]] architectures.

### Governance Lifecycle and Integration Points

A well-functioning AI Governance Framework is not a one-time compliance exercise but a continuous governance cycle.
The lifecycle begins at the ideation stage, where proposed AI use cases are screened against the [[AI Ethics Checklist]] and an initial [[AI Risk Assessment]] classifies the system's risk tier.
Design and development gates require documented model cards, dataset datasheets, and bias audits before code can progress to staging environments.
Pre-deployment review by the AI Ethics Board or Model Review Committee validates that residual risks are within accepted thresholds and that [[Human Oversight]] mechanisms are in place.
Post-deployment monitoring runs continuously, feeding anomaly alerts and model drift statistics into the living risk register.
Periodic [[Audit Mechanism]] reviews — typically quarterly for high-risk systems, annually for lower-risk deployments — verify that documented controls remain effective.
Finally, the decommission phase ensures that model artefacts, training data, and logs are retained per [[Data Governance]] retention schedules and regulatory requirements.

### Principle Hierarchy and Ethical Grounding

The principle layer of an AI Governance Framework typically implements a hierarchy: high-level ethical values (fairness, transparency, non-maleficence, human dignity, autonomy)
are operationalised as design requirements (bias budgets, explainability thresholds, human-in-the-loop ratios),
which in turn are enforced by technical controls (automated fairness testing pipelines, [[Algorithmic Transparency Index]] scores, [[Access Control]] policies).
The OECD's five AI principles — inclusive growth, human-centred values, transparency and explainability, robustness and security, accountability —
provide the internationally agreed values layer from which most national and organisational frameworks derive.
The EU's seven trustworthy AI requirements add the operational sub-dimension of technical robustness and environmental wellbeing,
while the NIST AI RMF's trustworthiness characteristics (valid and reliable, safe, secure and resilient, explainable and interpretable, privacy-enhanced, fair) provide quantifiable testing targets.
The convergence of these frameworks around a shared vocabulary of trustworthiness characteristics is evidence of the maturing governance consensus as of 2026.

### Risk Classification and Tiering

Risk classification is the mechanism by which governance frameworks allocate different levels of scrutiny, documentation, and oversight to different AI systems.
The EU AI Act's four-tier model is the most influential regulatory classification:
systems posing unacceptable risks (social scoring, mass surveillance) are banned outright;
Annex III high-risk systems (credit scoring, employment decisions, biometric identification, safety-critical infrastructure) face mandatory conformity assessments, registration, and post-market surveillance;
limited-risk systems (chatbots, deepfakes) face transparency obligations (disclosure to users);
minimal-risk systems (spam filters, AI-powered video games) are unregulated.
Organisations must maintain an internal AI inventory mapping every deployed system to its risk tier,
with governance obligations calibrated accordingly.
The NIST AI RMF extends this by adding impact dimensions — likelihood, severity, reversibility, breadth of effect —
enabling risk scoring on a continuous scale rather than discrete tiers.
Systems scoring above defined thresholds trigger mandatory elements of the governance framework
(mandatory ethics board review, mandatory third-party [[Audit Mechanism]], mandatory [[AI Impact Assessment]]).

### Accountability and Traceability Architecture

[[AI Accountability]] within a governance framework requires not just role assignment but traceability infrastructure:
audit logs capturing every significant model decision, data access, parameter change, and deployment action;
version control systems linking each live model version to the training data, hyperparameters, and evaluation results that produced it;
model cards and system cards documenting intended use, known limitations, and performance characteristics;
and decision records for governance choices — why a risk was accepted, why a particular mitigation was selected, who approved deployment.
This traceability infrastructure serves multiple functions: it enables post-incident investigation,
provides evidence for regulatory inspections, supports external [[Algorithmic Auditing]],
and enables the organisation to learn from near-misses and failures in a structured way.
The EU AI Act's post-market surveillance obligations for Annex III systems specifically require
that providers maintain and submit incident reports to national market surveillance authorities,
making traceability infrastructure a legal necessity rather than a best practice.

## Components / Architecture

### Governance Body Layer
The governance body layer comprises the institutional structures that make and enforce governance decisions.
The AI Ethics Board (or Responsible AI Committee) sits at the apex, with cross-functional membership spanning legal, product management, engineering, data science, affected-community representatives, and independent external experts.
The Board reviews AI systems above a defined risk threshold before deployment, reviews major model updates, responds to incidents, and reports to the board of directors or equivalent executive leadership.
A Model Review Committee operates at a more operational level, running structured review sessions for each proposed AI deployment.
The Risk Committee receives quarterly AI risk reports from the AI Ethics Board, integrating AI risk into the enterprise risk oversight function.
An AI Incident Response Team handles AI-specific failures — model degradation, bias incidents, privacy breaches, misuse — and is responsible for post-incident remediation and lessons-learned documentation.

### Policy Instrument Layer
The policy stack codifies the governance principles into enforceable rules.
The AI Acceptable Use Policy defines what AI applications are permissible, restricted, or prohibited within the organisation and for its products.
The Model Development Standard specifies mandatory documentation requirements, testing procedures, bias auditing thresholds, and review gates before a model can progress through the development lifecycle.
The Third-Party AI Supplier Code of Conduct extends governance expectations to external AI vendors and API providers, requiring them to demonstrate equivalent governance standards through contractual attestations or third-party certification.
The Incident Response Playbook for AI-specific failures defines classification criteria for AI incidents (low, medium, high, critical), escalation pathways, communication protocols, regulatory notification timelines, and remediation procedures.
The AI Transparency Policy governs what information about AI systems must be disclosed to users, regulators, and the public, and in what form.

### Risk Control Layer
The risk control layer implements the [[AI Risk Assessment]] methodology across the AI lifecycle.
Pre-deployment risk assessment uses the NIST AI RMF MAP and MEASURE functions to enumerate potential harms, assign likelihood and severity scores, and document residual risks after proposed mitigations.
For high-risk systems (as defined by the EU AI Act Annex III or equivalent internal classification), mandatory [[Red Teaming]] exercises are required before deployment.
Red teaming involves dedicated teams attempting to elicit harmful, biased, or privacy-violating outputs from the model using adversarial prompts, boundary cases, and distribution shift scenarios.
Outputs feed directly into the [[AI Risk Register]], which is reviewed quarterly.
Post-deployment monitoring tracks model performance against baseline metrics, with drift detection triggering re-assessment when performance degrades beyond defined thresholds.
High-risk systems operating in regulated sectors (healthcare, financial services, justice) may require continuous real-time monitoring with automated alerts.

### Transparency and Documentation Layer
Model cards (per Google's 2019 specification, now formalised as ISO/IEC TS 5392) document model intended use, performance characteristics, limitations, ethical considerations, and known failure modes.
Datasheets for datasets document training data provenance, collection methodology, demographic coverage, known biases, and consent and licensing information.
[[Algorithmic Transparency Index]] scores quantify the legibility of model decision processes, published to affected stakeholders in a form appropriate to their technical sophistication.
[[AI Impact Assessment]] reports — analogous to Data Protection Impact Assessments (DPIAs) under GDPR — document the anticipated societal, economic, and ethical impacts of AI deployments and are filed with regulators for EU AI Act high-risk systems.
Transparency reports, published annually, provide aggregate statistics on AI governance activity: number of systems reviewed, risk assessment outcomes, incidents handled, and governance improvements made.

### Audit and Compliance Layer
Internal [[Audit Mechanism]] procedures, aligned to ISO/IEC 42001 Clause 9, verify that governance processes are being followed and that documented controls remain effective.
External third-party audit trails — maintained as tamper-evident log archives — enable regulatory inspections without requiring governance teams to reconstruct evidence under time pressure.
[[Regulatory Compliance]] mapping documents how each governance control addresses specific regulatory requirements:
GDPR Article 22 (automated individual decision-making, including profiling),
EU AI Act Articles 9-17 (conformity assessment obligations for high-risk systems),
ICO Accountability Framework for AI, FCA's operational resilience requirements for AI-dependent systems,
and NHS Digital's Data Security and Protection Toolkit for healthcare AI.
Compliance gap analyses are run against each new regulatory instrument as it enters force, with remediation plans tracking closure of identified gaps.

### Technical Infrastructure Layer
The technical infrastructure underpins governance operations with tooling that makes governance processes feasible at the pace and scale of modern AI development.
Explainability dashboards using SHAP (SHapley Additive exPlanations), LIME (Local Interpretable Model-Agnostic Explanations), or attention visualisation techniques provide human-interpretable explanations of model predictions to reviewers and affected stakeholders.
[[Algorithmic Accountability]] logging records all significant model decisions — including decision inputs, outputs, model version, threshold values, and timestamp — in a tamper-resistant audit log.
Model version control and reproducibility tooling (ML experiment tracking platforms) link every deployed model version to the precise training data, hyperparameters, and evaluation results that produced it.
[[Access Control]] enforcement on training pipelines and model registries ensures that only authorised personnel can modify models, access sensitive training data, or approve deployments.
[[Identity Management]] systems bind AI-generated outputs to the deploying system and deployment context, enabling attribution of outputs to responsible principals.
Automated fairness testing pipelines (using toolkits such as IBM AI Fairness 360, Microsoft Fairlearn, or Google's What-If Tool) run pre-deployment bias checks and report results in standardised formats.

### Stakeholder Engagement Layer
Stakeholder engagement is the governance dimension most frequently under-resourced despite its centrality to trustworthy AI.
Public consultation protocols define when and how affected stakeholders are consulted before high-impact AI deployments — methods include public comment periods, citizen panels, focus groups with representative community members, and participatory design workshops.
Grievance and redress mechanisms provide pathways for stakeholders harmed by AI decisions to seek explanation, review, and remedy, satisfying both the GDPR right to explanation (Article 22(3)) and the EU AI Act's post-market redress requirements.
Transparency reports communicate governance activity to external stakeholders, building trust and enabling public scrutiny.
Algorithmic impact registers — mandated by the UK Algorithmic Transparency Recording Standard (ATRS) for central government from 2023 — publish structured information about which government AI systems exist, what decisions they inform, and what oversight mechanisms are in place.

## Use Cases / Major Families

**Enterprise Technology Deployment**: Large tech companies (Microsoft, Google, IBM, Meta) each maintain published AI governance frameworks that instantiate these principles. Microsoft's Responsible AI Standard (2022, v2) operationalises six principles and requires a Responsible AI Impact Assessment for any high-risk AI feature before release. Google's PAIR (People + AI Research) guidelines and IBM's AI Ethics Board represent analogous governance architectures.

**Financial Services**: UK FCA's AI Discussion Paper (DP5/22) and the Bank of England's AISP (Artificial Intelligence Public–Private Forum) report articulate governance requirements for credit scoring, fraud detection, and trading algorithms — high-risk uses requiring documented conformity assessment pathways consistent with the EU AI Act Annex III.

**Healthcare**: NHS AI Lab's AI and Digital Regulations Safety Scheme and NICE's Evidence Standards Framework for AI-enabled technologies exemplify governance frameworks tailored to clinical risk profiles, where model failure can directly harm patients. The MHRA's Good Machine Learning Practice (GMLP) guidelines for AI-as-a-medical-device provide the regulatory overlay.

**Public Sector**: The UK Government AI Playbook (2024) and the EU's guidelines on AI in public administration both mandate transparency (algorithmic registers), human oversight (final decision by a human for high-stakes determinations), and redress pathways, translating the governance framework into procurement and deployment conditions for government agencies.

**Autonomous and Agent AI Systems**: As [[AI Agent System]] deployments proliferate — autonomous agents handling multi-step tasks without per-step human approval — governance frameworks are extending to cover agent-specific risks: goal misalignment, tool misuse, emergent behaviour, and cascading failures in multi-agent pipelines. This represents the emerging frontier of AI governance framework design as of 2026.

## Academic Context

The intellectual foundations of AI governance frameworks span multiple disciplines. The foundational ethical frameworks draw on Beauchamp and Childress's four-principle bioethics (autonomy, beneficence, non-maleficence, justice) adapted to AI by Floridi, Cowls, and colleagues in "AI4People — An Ethical Framework for a Good AI Society" (2018). Joanna Bryson's "Patiency is Not a Virtue" (2018) and "AI Ethics Is Not New" (2019) established that machine ethics requires institutional, not merely technical, solutions. Allan Dafoe's "AI Governance: A Research Agenda" (Future of Humanity Institute, 2018) mapped the governance design space and influenced subsequent academic work. Virginia Eubanks' "Automating Inequality" (2018) and Safiya Umoja Noble's "Algorithms of Oppression" (2018) grounded governance necessity in documented harms from opaque systems, creating the empirical case for mandatory audit mechanisms.

The IEEE Global Initiative on Ethics of Autonomous and Intelligent Systems produced "Ethically Aligned Design" (2019), a technically detailed framework that prefigured many elements of ISO/IEC 42001. The EU's High-Level Expert Group on AI published "Ethics Guidelines for Trustworthy AI" (2019), which introduced the seven requirements — human agency and oversight, technical robustness and safety, privacy and data governance, transparency, diversity and non-discrimination, societal and environmental wellbeing, accountability — that now underpin most European governance frameworks. Tim Regan and colleagues' "Operationalising AI Governance through Ethics-Based Auditing" (2024) demonstrated the first end-to-end case study of implementing an AI governance framework in an industrial setting, finding that governance artefact production (model cards, impact assessments) added 12–18% overhead to development cycles but reduced post-deployment incident rates by 34%.

## Current Landscape (2026)

The period 2024–2026 has been the most consequential in AI governance history. The EU AI Act entered into force on 1 August 2024; by February 2025, bans on prohibited AI practices (social scoring, untargeted facial recognition scraping, emotion recognition in workplaces and schools) became enforceable. August 2025 brought operational governance infrastructure requirements and GPAI model obligations (transparency, safety testing, and systemic-risk mitigation for frontier models above 10^25 FLOPs). The European Commission begins full enforcement on 2 August 2026. The practical effect for organisations has been intense investment in governance framework documentation, conformity assessment readiness, and third-party audit capability. Certification body accreditation under ISO/IEC 42001 has grown: by mid-2025 more than 400 organisations had achieved or were pursuing certification globally, compared to fewer than 50 at end-2023.

The NIST AI RMF Generative AI Profile (AI 600-1, July 2024) added 12 LLM-specific risk categories and became the de facto baseline for US Federal agency AI governance following the White House Executive Order on AI (October 2023). The UK's AI Safety Institute (AISI) published its Frontier AI Safety Framework in 2024 and began pre-deployment evaluations of frontier models; in October 2025, DSIT opened consultation on a UK AI Growth Lab providing sandboxed regulatory modifications for experimental AI deployments. Singapore's Model AI Governance Framework for Generative AI (2024), developed with input from over 70 organisations including OpenAI, Google, Microsoft, and Anthropic, established interoperable reference assurance criteria aligned with OECD 2024 principles and the GPAI Code of Practice, enabling cross-border mutual recognition.

In enterprise adoption, a 2024 Gartner survey found 80% of large organisations claiming active AI oversight programmes, but fewer than 50% able to demonstrate measurable governance artefacts. This "governance theatre" concern has driven demand for structured [[AI Governance Maturity Model]] assessments, external audits, and independent attestations. The Responsible AI Institute's certification scheme and ISACA's CMMI AI add-on (2025) have emerged as leading third-party attestation pathways.

## UK Context

The UK has developed a distinctive AI governance posture — principles-based, sector-led, innovation-permissive — that contrasts with the EU's product-safety regulatory model. The Centre for Data Ethics and Innovation (CDEI), now within DSIT's AI Policy Directorate, has produced foundational guidance including the Algorithmic Transparency Recording Standard (ATRS, 2021, mandated for central government from 2023), the AI Assurance Roadmap (2021), and the AI Regulatory Capability Framework and Self-Assessment Tool (2024, co-developed with the Alan Turing Institute). The Alan Turing Institute published its "AI Governance around the World: Country Profile — United Kingdom" in January 2026, providing a structured overview of the UK's regulatory model, standards infrastructure, and institutional architecture as it evolved over 2024–2025. The AI Standards Hub, convening BSI, NPL, and the Turing Institute, represents the UK's technical engagement with ISO/IEC JTC 1/SC 42 standardisation activities.

In Northern England, Manchester is a notable hub: the University of Manchester's Turing Partnership (the University was one of eight founding ATI university partners in 2018) and the Manchester Institute for Innovation Research have contributed governance research particularly for healthcare and public services. The NHS Greater Manchester partnership has piloted AI Governance Framework implementations in clinical pathway AI, navigating both NHS Digital's AI and Digital Regulations Safety Scheme and the MHRA's GMLP guidance. The University of Leeds Centre for Research into Violence and Abuse has examined AI governance in safeguarding contexts, while Leeds City Council's data analytics programme has implemented the ATRS for automated decision transparency. Sheffield's Advanced Manufacturing Research Centre (AMRC) applies AI governance frameworks to industrial automation contexts, with a particular focus on ISO 42001 alignment for manufacturing AI in aerospace supply chains. Newcastle University's National Innovation Centre for Data (NICD) provides AI governance capacity-building for SMEs across the North East, particularly in energy sector AI deployments.

## Future Directions (2026–2030)

Several trajectories will shape AI governance framework evolution through 2030. First, the emergence of [[AI Agent System]] networks — multi-agent pipelines with minimal per-step human intervention — creates new governance surface area around goal alignment, tool authorisation scoping, and cascading liability. Governance frameworks will need to extend from system-level controls to agent-level behavioural constraints, creating demand for runtime policy enforcement rather than pre-deployment-only review. Second, international interoperability of governance frameworks is a pressing concern: the EU AI Act, NIST AI RMF, Singapore Model Framework, UK pro-innovation approach, and Chinese algorithm regulations create a fragmented compliance landscape for multinational AI deployers. The G7 Hiroshima AI Process reporting framework and the OECD 2024 AI Principles update represent early steps toward mutual recognition, but binding international convergence remains elusive through 2030. Third, AI-augmented governance itself — using AI systems to monitor, audit, and enforce compliance with AI governance frameworks — is emerging as a practical necessity given the scale and velocity of AI deployment. Fourth, mandatory third-party auditing, currently required under the EU AI Act only for high-risk systems, is likely to extend to a broader range of AI applications as incidents accumulate and public pressure mounts. The ISACA/CMMI Institute's AI governance audit maturity models and the Responsible AI Institute's certification infrastructure are positioning to serve this market.

## Research & Literature

1. Floridi, L., Cowls, J., Beltrametti, M., et al. (2018). "AI4People — An Ethical Framework for a Good AI Society." *Minds and Machines*, 28(4), 689–707. https://doi.org/10.1007/s11023-018-9482-5
2. Dafoe, A. (2018). *AI Governance: A Research Agenda*. Future of Humanity Institute, University of Oxford. https://www.fhi.ox.ac.uk/wp-content/uploads/GovAI-Agenda.pdf
3. Jobin, A., Ienca, M., & Vayena, E. (2019). "The Global Landscape of AI Ethics Guidelines." *Nature Machine Intelligence*, 1(9), 389–399. https://doi.org/10.1038/s42256-019-0088-2
4. EU High-Level Expert Group on AI (2019). *Ethics Guidelines for Trustworthy AI*. European Commission.
5. OECD (2019, updated 2024). *Recommendation of the Council on Artificial Intelligence*. OECD/LEGAL/0449.
6. IEEE (2019). *Ethically Aligned Design: A Vision for Prioritizing Human Well-being with Autonomous and Intelligent Systems* (1st ed.). IEEE Global Initiative on Ethics of AIS.
7. Mittelstadt, B. D. (2019). "Principles Alone Cannot Guarantee Ethical AI." *Nature Machine Intelligence*, 1(11), 501–507. https://doi.org/10.1038/s42256-019-0114-y
8. NIST (2023). *Artificial Intelligence Risk Management Framework (AI RMF 1.0)*. NIST AI 100-1. https://doi.org/10.6028/NIST.AI.100-1
9. ISO/IEC JTC 1/SC 42 (2023). *ISO/IEC 42001:2023 — Information technology — Artificial intelligence — Management system*. https://www.iso.org/standard/81234.html
10. NIST (2024). *Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile*. NIST AI 600-1. https://doi.org/10.6028/NIST.AI.600-1
11. Regan, T., et al. (2024). "Operationalising AI Governance through Ethics-Based Auditing: An Industry Case Study." *arXiv:2407.06232*. https://arxiv.org/abs/2407.06232
12. Mökander, J., Juneja, P., Watson, D. S., & Floridi, L. (2022). "The US Algorithmic Accountability Act of 2022 vs. The EU Artificial Intelligence Act." *Minds and Machines*, 32(4), 751–758.
13. Wachter, S., Mittelstadt, B., & Russell, C. (2017). "Counterfactual Explanations without Opening the Black Box." *Harvard Journal of Law and Technology*, 31(2), 841–887.
14. Kearns, M., & Roth, A. (2020). *The Ethical Algorithm: The Science of Socially Aware Algorithm Design*. Oxford University Press.
15. Cowls, J., Tsamados, A., Taddeo, M., & Floridi, L. (2021). "The AI Gambit — Leveraging Artificial Intelligence to Combat Climate Change." *AI & Society*, 36(4), 1151–1169.
16. Cath, C., Wachter, S., Mittelstadt, B., Taddeo, M., & Floridi, L. (2018). "Artificial Intelligence and the 'Good Society': The US, EU, and UK Approach." *Science and Engineering Ethics*, 24(2), 505–528.
17. Brundage, M., et al. (2018). *The Malicious Use of Artificial Intelligence: Forecasting, Prevention, and Mitigation*. Future of Humanity Institute.
18. European Parliament (2024). *EU AI Act*. Regulation (EU) 2024/1689. Official Journal of the European Union. https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32024R1689
19. Alan Turing Institute (2026). *AI Governance around the World — Country Profile: United Kingdom*. https://www.turing.ac.uk/sites/default/files/2026-01/ai_governance_around_the_world_-_uk.pdf
20. Singapore IMDA & PDPC (2024). *Model AI Governance Framework for Generative AI*. Infocomm Media Development Authority.
21. DSIT (2025). *AI Regulatory Capability Framework and Self-Assessment Tool*. Department for Science, Innovation & Technology / Alan Turing Institute.
22. CDEI (2021). *AI Assurance Roadmap*. Centre for Data Ethics and Innovation. https://www.gov.uk/government/publications/ai-assurance-roadmap
23. Dignum, V. (2019). *Responsible Artificial Intelligence: How to Develop and Use AI in a Responsible Way*. Springer. https://doi.org/10.1007/978-3-030-30371-6
24. Rahwan, I. (2018). "Society-in-the-Loop: Programming the Algorithmic Social Contract." *Ethics and Information Technology*, 20(1), 5–14.
25. Hadfield-Menell, D., & Hadfield, G. K. (2019). "Incomplete Contracting and AI Alignment." *Proceedings of the 2019 AAAI/ACM Conference on AI, Ethics, and Society*, 417–422.
26. Whittlestone, J., Nyrup, R., Alexandrova, A., & Cave, S. (2019). "The Role and Limits of Principles in AI Ethics: Towards a Focus on Tensions." *Proceedings of the 2019 AAAI/ACM Conference on AI, Ethics, and Society*, 195–200.
27. ISACA (2025). "CMMI in the AI Age." *ISACA Journal*, Volume 3. https://www.isaca.org/resources/isaca-journal/issues/2025/volume-3/cmmi-in-the-ai-age

### Provenance

