El Salvador is a Central American nation-state that in September 2021 became the first country in the world to adopt Bitcoin as legal tender alongside the United States dollar, enacting the Bitcoin Law (Ley Bitcoin). The policy required all businesses capable of providing the technology to accept Bitcoin for goods and services, deployed the government-issued Chivo Wallet to facilitate adoption, and established the Lightning Network as the primary payment rail for low-value retail transactions. El Salvador serves in this knowledge graph as a primary real-world case study for sovereign-level cryptocurrency adoption, digital-currency monetary policy, and the intersection of blockchain infrastructure with national governance.

### Overview

- El Salvador (officially the Republic of El Salvador) is the smallest and most densely populated country in Central America.
- Prior to 2021 it had been officially dollarised since 2001, operating without an independent monetary policy or central bank currency.
- The country has a large diaspora — principally in the United States — making [[Remittance]] flows a critical share of GDP, historically subject to high fees via incumbent wire-transfer operators.
- President Nayib Bukele championed [[Bitcoin]] adoption as a strategy to:
  - Lower remittance transaction costs by routing payments over the [[Lightning Network]]
  - Extend [[Financial Inclusion]] to the large unbanked population
  - Attract foreign investment and [[Crypto Tourism]]
  - Gain a degree of monetary sovereignty independent of the US Federal Reserve
- The Bitcoin Law (passed by the Legislative Assembly in June 2021, in force September 2021) required all businesses with the technological means to accept Bitcoin and guaranteed its convertibility to USD at the point of sale via the Chivo exchange buffer.
- The government distributed a USD 30 equivalent sign-up bonus in [[Chivo Wallet]] to incentivise adoption.
- El Salvador simultaneously explored [[Bitcoin Mining]] using geothermal energy from the Conchagua volcano and the Tecapa-Chinameca volcanic range, positioning itself as a green-energy mining jurisdiction.

### Key Components

#### Bitcoin Law (Ley Bitcoin)

- The legislative instrument that granted [[Bitcoin]] legal-tender status.
- Required merchants capable of accepting digital payments to receive Bitcoin.
- Mandated that tax obligations could be settled in Bitcoin.
- Provided a USD conversion guarantee to merchants uncomfortable holding [[Cryptocurrency]] balance risk.

#### Chivo Wallet

- Government-issued [[Digital Wallet]] application available on iOS and Android.
- Custodial wallet backed by a state-operated exchange buffer providing instant USD/BTC conversion.
- Integrated [[Lightning Network]] channels for low-fee micropayments.
- Used for the USD 30 onboarding incentive distributed to citizens.
- Contrasts with self-custodial wallets where users hold [[Public Key Cryptography]] key material directly.

#### Lightning Network Integration

- The [[Lightning Network]] is a Layer-2 [[Payment Channel]] protocol built atop the [[Bitcoin Proof-of-Work Protocol]].
- Enables near-instant, low-fee transactions suitable for retail and remittance use cases that on-chain Bitcoin cannot efficiently serve.
- Chivo Wallet routed small payments via Lightning, keeping the user experience comparable to mobile money systems.

#### Geothermal Bitcoin Mining

- El Salvador announced plans to use surplus geothermal electricity to power state-affiliated [[Bitcoin Mining]] operations.
- Positioned as a renewable-energy mining use case, contrasting with coal-heavy mining jurisdictions.
- Connects to broader debates around the environmental footprint of [[Proof of Work]] consensus.

#### National Bitcoin Reserve

- The Salvadoran government began accumulating a sovereign Bitcoin treasury, purchasing Bitcoin during market dips.
- Functions similarly to a sovereign wealth fund holding a digital asset, introducing exposure to [[Cryptocurrency]] price volatility at the national balance-sheet level.
- Subject to IMF scrutiny given its implications for [[Fiscal Policy]] and debt sustainability.

### Applications and Use Cases

- **Remittance corridors**: Migrant workers in the United States sending value to family in El Salvador can use Lightning-enabled apps to bypass traditional [[Remittance]] operators, reducing fees and settlement times.
- **Financial inclusion**: Citizens without bank accounts can transact via Chivo Wallet, providing access to digital payments and potentially to [[Decentralised Finance]] services.
- **Tourism and commerce**: The "Bitcoin Beach" (El Zonte) community circular economy predated the national law and served as a proof-of-concept, attracting [[Crypto Tourism]] and international media.
- **Tax and government payments**: The legal framework allows businesses to file taxes and pay government fees in Bitcoin, testing [[Smart Contract]]-adjacent compliance automation.
- **Policy laboratory**: El Salvador's experiment provides empirical data for researchers, central banks, and [[International Monetary Fund]] economists analysing sovereign [[Cryptocurrency]] adoption, informing debates around [[Central Bank Digital Currency]] design.
- **Volcano bonds**: The government proposed issuing USD-denominated "Volcano Bonds" (tokenised debt instruments) on the [[Liquid Network]] sidechain, representing an early sovereign experiment with [[Blockchain]]-native capital markets.

### Challenges and Criticisms

- **IMF conditionality**: The International Monetary Fund expressed concern that Bitcoin's [[Cryptocurrency]] volatility posed risks to financial stability, consumer protection, and fiscal integrity. Negotiations over IMF programme conditions repeatedly referenced the Bitcoin Law.
- **Adoption gap**: Independent surveys indicated low ongoing usage of Chivo Wallet beyond the initial USD 30 incentive period, suggesting the law did not generate the expected organic adoption among the general population.
- **Price volatility**: As a [[Fiat Currency]] replacement, Bitcoin's price swings introduced balance-sheet risk for merchants who held Bitcoin rather than immediately converting to USD.
- **Security and custodial risk**: Centralised custody in Chivo Wallet contradicted [[Public Key Cryptography]] self-sovereignty principles central to the [[Bitcoin Proof-of-Work Protocol]] ethos.
- **Regulatory reaction**: The move drew cautionary statements from the World Bank and inter-American development institutions regarding [[Crypto Regulation]] and anti-money-laundering compliance.
- **Contrast with CBDCs**: Critics argued that a state-issued [[Central Bank Digital Currency]] would offer monetary utility with less volatility risk, contrasting El Salvador's approach with emerging CBDC programmes elsewhere.

### Standards and Context

- **Legal**: Decreto Legislativo No. 57, Ley Bitcoin (June 2021, El Salvador Legislative Assembly) — the primary legislative instrument.
- **Financial oversight**: IMF Article IV consultations repeatedly addressed the Bitcoin Law's macro-fiscal implications; IMF staff reports are the primary international oversight record.
- **Payment standards**: [[Lightning Network]] operates on the BOLT (Basis of Lightning Technology) specification set, defined across BOLT 1–11 by the open-source community.
- **Wallet security**: Chivo Wallet's custodial model falls under Salvadoran banking supervision rather than the self-custodial norms of the [[Bitcoin Proof-of-Work Protocol]] community.
- **AML/CFT**: Businesses accepting Bitcoin must comply with Salvadoran anti-money-laundering regulations aligned with FATF Recommendation 15 on virtual assets.
- **Volcano Bonds**: Proposed under El Salvador's Digital Assets Issuance Law (Ley de Emisión de Activos Digitales, 2022), which created a regulatory sandbox for tokenised securities on [[Blockchain]] infrastructure, overseen by the Comisión Nacional de Activos Digitales (CNAD).

### Comparative Context

- El Salvador's approach differs fundamentally from the [[Central Bank Digital Currency]] model pursued by the Bahamas (Sand Dollar), Nigeria (eNaira), and Jamaica (JAM-DEX), which retain sovereign currency issuance control.
- It also differs from [[Dollarisation]] pure-play economies (Ecuador, Panama) that simply adopt USD without any digital asset dimension.
- The Central African Republic briefly followed El Salvador in adopting Bitcoin as legal tender (2022) but reversed the policy in 2023, leaving El Salvador as the sole sustained sovereign adopter.
- The experiment informed IMF policy guidance on [[Crypto Regulation]] for small open economies dependent on [[Remittance]] inflows.

### Provenance

