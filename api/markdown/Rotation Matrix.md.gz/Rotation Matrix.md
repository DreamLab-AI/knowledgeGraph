A rotation matrix is a square orthogonal matrix with determinant one that represents a rigid rotation of vectors in Euclidean space about a fixed origin. In robotics and computer graphics it encodes the orientation of one coordinate frame relative to another, mapping direction vectors from one frame into another without altering their length. Rotation matrices compose by matrix multiplication, enabling chains of rotations to be combined into a single transformation.

- A [[Rotation Matrix]] is an orthogonal matrix with determinant one that represents a rigid rotation about a fixed origin in Euclidean space.
- It rests on [[Linear Algebra]] and is applied through [[Matrix Multiplication]] to transform vectors between a [[Coordinate System]] and a reference frame.
- Rotation matrices are central to [[Kinematics]] and the broader study of robot motion.

### Overview

- A rotation matrix belongs to the special orthogonal group, meaning its columns form an orthonormal basis and its inverse equals its transpose. This property makes rotations numerically convenient: the inverse rotation is obtained for free by transposition, and lengths and angles between vectors are preserved exactly.
- In three dimensions a rotation matrix is a 3x3 array describing the orientation of a body or sensor frame relative to a world frame. Sequences of rotations are combined by multiplying matrices in order, allowing complex orientations to be built from elementary rotations about the principal axes.
- Although rotation matrices are unambiguous, they carry nine numbers to express only three degrees of freedom, so they are sometimes converted to more compact representations such as Euler angles or unit quaternions when storage or interpolation matters.

### Key aspects

- Orthonormality: rows and columns are mutually orthogonal unit vectors, guaranteeing a length-preserving transformation.
- Determinant of one: distinguishes proper rotations from reflections, ensuring handedness is preserved.
- Composition: chained rotations multiply, supporting articulated structures and transform trees.
- Inversion by transpose: the inverse rotation is computed cheaply, which matters for real-time control loops.
- Frame semantics: a single matrix can be read as rotating points within a frame or as relating two coordinate frames.

### Applications

- Encoding joint and link orientations in [[Forward Kinematics]] and [[Inverse Kinematics]] for articulated robots.
- Aligning sensor and camera frames during [[Pose Estimation]] and [[Computer Vision]] pipelines.
- Driving object transforms in [[Photorealistic Rendering]] and [[Computer Graphics]] scene graphs.
- Maintaining orientation state in [[Trajectory Planning]] and [[Motion Planning]] for manipulators.

### Provenance

