A third-party logistics provider (3PL) is an outside firm to which a company outsources part of its logistics activities. The European Commission says that enterprises often outsource their logistics activities to third party logistics providers, and estimates that long-term contractual relationships, which it calls contract logistics, make up 16% of total global logistics.[^1]

## Commercial usage

No single industry definition exists. Maersk states in a Logistics Insights article that there is “no unified, industry standard definition of these terms” for 3PL, 4PL and similar models.[^2] It describes a “traditional” 3PL model as one that can execute a variety of logistics and transportation services, such as freight transportation, booking, documentation, order fulfilment, warehousing, customs brokerage and procurement at scale, without owning assets such as trucks, rail or warehouses, and relying on 2PL providers for them.[^2] Maersk also separates other forms: a non-vessel operating common carrier, and a 3PL acting more like a 2PL, a trucker or a warehousing provider.[^2]

The Industrial Ontologies Foundry records the Council of Supply Chain Management Professionals wording for the wider logistics service provider role, which includes “those businesses typically referred to as 3PL, 4PL, LLP, etc”, but it does not define 3PL as a separate class.[^3]

## Legal definitions

United States law defines the term narrowly for product safety. The Consumer Product Safety Act describes a third-party logistics provider as a person who solely receives, holds or otherwise transports a consumer product in the ordinary course of business but who does not take title to the product, and it provides that such a provider is not treated as a manufacturer, distributor or retailer solely for doing so.[^4] That definition turns on not taking title. The commercial usage above does not mention title and describes bundles of services instead.[^4][^2]

## Scope and distinctions

A 3PL is a kind of [[Logistics Service Provider]]. The related integrator role is the [[Fourth-Party Logistics Provider]], and the sources do not agree on where the line between the two falls.[^2][^5] For automation in 3PL warehouses see [[Warehouse Robotics]].

## What the sources do not establish

Maersk's article is a company publication, so it is a practitioner view, not a neutral standard. The sources opened do not give the share of outsourced logistics by region or sector beyond the Commission's global estimate, and they do not say how the estimate was made.[^1]

[^1]: European Commission, Directorate-General for Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en
[^2]: Maersk, “The difference between 3PL vs 4PL”. https://maersk.com/insights/growth/2023/09/26/3pl-vs-4pl
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^4]: Cornell Law School Legal Information Institute, “15 U.S. Code § 2052 - Definitions”. https://www.law.cornell.edu/uscode/text/15/2052
[^5]: Logistics Management (republished by Supply Chain 24/7), “Global Logistics: Demystifying the 4PL”. https://www.supplychain247.com/article/global_logistics_demystifying_the_4pl/

