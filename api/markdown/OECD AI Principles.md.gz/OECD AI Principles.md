The OECD AI Principles are five intergovernmental policy guidelines adopted by the Organisation for Economic Co-operation and Development in May 2019 and endorsed by G20 leaders in Osaka, representing the first intergovernmental standard on AI. They address inclusive growth and sustainable development, human-centred values and fairness, transparency and explainability, robustness security and safety, and accountability. Updated in 2024 to address generative AI and foundation models, they have shaped national AI strategies, the EU AI Act, and a constellation of derivative multilateral instruments. Implementation is tracked through the OECD AI Policy Observatory, which catalogues national policies across member and partner countries.

### Overview

- The OECD AI Principles emerged from deliberations by the OECD Expert Group on AI (AIGO), comprising representatives from government, industry, civil society, and academia across member countries.
- They were adopted by the OECD Council at Ministerial level in May 2019 and endorsed by G20 leaders in Osaka in June 2019, giving them political authority beyond OECD membership.
- The principles are voluntary and aspirational in character: they carry no binding enforcement mechanism, yet their influence on binding instruments such as the [[EU AI Act]], Canada's AIDA, and the UK's pro-innovation AI framework has been decisive.
- Implementation is tracked through the [[OECD AI Policy Observatory]] (OECD.AI), which catalogues national AI policies and provides comparative analysis tools across member and partner countries.
- The 2024 update added language on systemic risk, safety evaluations, and responsibilities of developers of large-scale general-purpose AI systems, directly responding to the emergence of large language models and diffusion systems.
- The principles function as an international reference point, cited by the [[Global Partnership on AI]] (GPAI), [[UNESCO AI Ethics Recommendation]], and the Council of Europe Framework Convention on AI.

### Key Components

- **Principle 1 — Inclusive Growth and Sustainable Development**
  - AI should benefit people and the planet by driving inclusive growth, [[Sustainable Development]], and well-being, taking into account potentially disruptive impacts on labour markets and avoiding widening inequalities.
- **Principle 2 — Human-Centred Values and Fairness**
  - AI systems should respect the rule of law, [[Human Rights]], democratic values, and diversity; they should include safeguards such as human oversight and be designed to address [[Fairness]] and avoid discriminatory outcomes.
  - Links to [[Algorithmic Fairness]], [[Bias Mitigation]], and [[Human-Centred AI]].
- **Principle 3 — Transparency and Explainability**
  - AI actors should commit to [[Transparency]] and responsible disclosure proportionate to context and risk; this includes traceability, [[Explainability]], and enabling meaningful human oversight.
  - Foundational to [[Algorithmic Accountability]] and [[Interpretable Machine Learning]].
- **Principle 4 — Robustness, Security, and Safety**
  - AI systems should be robust, secure, and safe throughout their lifecycle; risks should be continually assessed and managed, and operators must ensure [[AI Safety]] and security-by-design.
  - The 2024 update extended this to systemic risks from [[Foundation Model]] and red-team [[AI Risk Management]].
- **Principle 5 — Accountability**
  - AI actors, whether individuals, organisations, or governments, should be [[Accountability|accountable]] for the proper functioning of AI systems according to these principles, with liability mechanisms commensurate with their role.
- **Implementation Recommendations**
  - Five companion recommendations address policies for national governments: investing in AI R&D, fostering inclusive digital ecosystems, shaping enabling policy environments, building human capacity, and enabling international cooperation for trustworthy AI.

### Applications and Use Cases

- **National AI Strategy Development**: Governments across OECD membership and beyond have used the principles as the normative backbone of [[National AI Strategy]] documents; the OECD.AI tracks compliance and policy uptake.
- **Regulatory Design**: The EU embedded the OECD Principles in the preamble and definitional architecture of the [[EU AI Act]] (2024), operationalising them as binding requirements for high-risk AI systems.
- **Corporate AI Governance**: Technology companies such as Google, Microsoft, and IBM have mapped their internal [[AI Ethics]] guidelines to the OECD Principles, using them as an external credibility benchmark.
- **Procurement Standards**: Public sector procurement bodies reference the principles when setting vendor requirements for AI-driven services, connecting them to [[Public Sector AI]] governance.
- **International Diplomatic Alignment**: The principles form the common reference text in G7 Hiroshima AI Process (2023) discussions and in bilateral AI dialogue frameworks between the EU, US, and Japan.
- **Audit Frameworks**: AI auditing bodies and certification schemes draw on the transparency and accountability principles to design [[AI Auditing]] criteria and conformity assessment procedures.
- **Generative AI Governance**: Following the 2024 revision, the principles now inform responsible deployment frameworks for large language models, connecting to [[Generative AI]] risk management guidance.

### Standards and Context

- **Issuing body**: Organisation for Economic Co-operation and Development (OECD), 38 member countries plus associate and partner economies, headquartered in Paris.
- **Adoption date**: 22 May 2019 (OECD/LEGAL/0449); G20 endorsement June 2019.
- **Revision**: 2024 update to address [[Foundation Model]] and generative AI; the first substantive revision since adoption.
- **Companion instruments**:
  - [[UNESCO AI Ethics Recommendation]] (2021) — broader cultural and scientific framing, 193 UNESCO member states.
  - [[Global Partnership on AI]] (GPAI) — operationalises the principles through multi-stakeholder working groups.
  - Council of Europe Framework Convention on AI — the first binding treaty instrument aligned to the OECD normative framework.
  - G7 Hiroshima AI Process — builds on OECD principles for advanced AI systems.
- **OECD.AI Policy Observatory**: The implementation and monitoring platform at oecd.ai; tracks policies, tools, and metrics for assessing [[AI Governance]] performance.
- **Relationship to ISO/IEC standards**: The principles inform but are distinct from ISO/IEC 42001 (AI Management Systems) and ISO/IEC 23894 (AI Risk Management), which translate voluntary governance commitments into auditable management system requirements.
- **Relationship to NIST AI RMF**: The US NIST [[AI Risk Management]] Framework (2023) cross-walks to the OECD Principles, creating transatlantic alignment; the GOVERN, MAP, MEASURE, MANAGE functions echo the accountability and transparency pillars.
- **Critique and limitations**: Critics note the voluntary nature, the absence of enforcement, and structural focus on OECD-member governance contexts, which may not adequately address AI development dynamics in non-member economies. The 2024 revision partially addressed this by broadening language on developer responsibilities.

### Provenance

