Layer 1 is the foundational base protocol of a blockchain network that maintains its own independently verified state, executes a native consensus mechanism, and provides cryptographically final transaction ordering without relying on any external chain. It defines the canonical ledger, enforces network rules (including token issuance schedules and validity criteria), and serves as the trust anchor from which all higher-order protocols derive their security guarantees. Notable examples include Bitcoin, Ethereum, Solana, Cardano, and Avalanche, each differing in their consensus approach, throughput characteristics, and programmability.

### Overview

- Layer 1 establishes the ground truth of a decentralised network. Every [[Validator Node]] independently executes the same rules, and the [[Consensus Protocol]] ensures that all honest nodes converge on a single canonical history without a central authority.
- The term "Layer 1" became widespread as the scaling debate in blockchain matured. Researchers and developers recognised that a single chain cannot simultaneously maximise security, decentralisation, and throughput — the [[Blockchain Scalability Trilemma]] — which motivated off-chain solutions ([[Layer 2 Networks]], [[Sidechain|Sidechains]]) that anchor back to Layer 1 for settlement.
- Layer 1 networks carry their own [[Native Token]] (e.g. BTC, ETH, SOL) used to pay transaction fees and, in [[Proof of Stake]] systems, to collateralise validators.
- Security model: every full [[Validator Node]] replays all transactions, guaranteeing that no single party can alter history without controlling a majority of the network's consensus power — whether measured in hash-rate ([[Proof of Work]]) or staked capital ([[Proof of Stake]]).

### Key Components

- **[[Consensus Protocol]]** — the algorithm by which geographically dispersed nodes agree on the next valid [[Block]] and reject invalid ones. Variants include Nakamoto-style longest-chain [[Proof of Work]], BFT-family [[Proof of Stake]], and hybrid designs.
- **[[Distributed Ledger]]** — the append-only, replicated data store whose state transitions are validated by the consensus mechanism. Each [[Block]] contains an ordered set of transactions and a reference to the previous block's hash, forming the chain.
- **[[Mempool]]** — the in-memory pool of unconfirmed transactions awaiting inclusion in the next block; nodes gossip transactions across the [[Peer-to-Peer Network]] until miners or validators select them.
- **[[Native Token]]** — the protocol-level asset whose issuance schedule and supply rules are hard-coded in the Layer 1 protocol (e.g. Bitcoin's 21 million cap). Native tokens incentivise honest participation and pay for computation.
- **[[Cryptographic Hash Function]]** — underpins block linking and Merkle tree construction, making history tamper-evident; SHA-256 is canonical for Bitcoin, Keccak-256 for Ethereum.
- **[[Validator Node]]** — full participants that store the complete ledger state, validate all transactions and blocks, and participate in consensus. The diversity and geographic distribution of validators determines decentralisation.
- **[[Finality]]** — the property by which a committed transaction becomes irreversible. Probabilistic finality (Bitcoin after six confirmations) differs from deterministic/economic finality offered by BFT-based Layer 1 systems.

### Mechanisms

- **[[Proof of Work]]** — miners compete to solve a hash-based computational puzzle; the winner appends the next block and earns the block reward. High energy expenditure is the economic guarantee against rewriting history.
- **[[Proof of Stake]]** — validators lock ([[Staking|stake]]) native tokens as collateral; a randomised (often weighted) selection process chooses the next block proposer. Slashing punishes equivocation, replacing energy cost with economic risk.
- **[[Sharding]]** — an intra-Layer-1 scaling strategy that partitions the global state into sub-chains (shards) processed in parallel; [[Cross-Shard Communication]] reintroduces complexity but raises aggregate throughput without exiting Layer 1.
- **Block time and throughput** — Layer 1 design choices (block size, block interval, execution environment complexity) determine baseline throughput. Changing these parameters involves hard forks or governance processes encoded in [[Bitcoin Improvement Proposal|BIPs]] or [[Ethereum Improvement Proposal|EIPs]].
- **[[Data Availability]]** — Layer 1 must make block data publicly available for a sufficient window so that fraud proofs and validity proofs from [[Layer 2 Networks]] can be verified by anyone, not just by the original proposer.

### Applications / Use Cases

- **[[Decentralised Finance]] (DeFi)** — Layer 1 chains host liquidity pools, lending protocols, and decentralised exchanges. Settlement finality on Layer 1 backstops the economic guarantees of all DeFi positions.
- **[[Tokenisation]]** — real-world assets (bonds, equities, real estate) are being tokenised on Layer 1 networks, with [[Smart Contract]] logic enforcing transfer restrictions and compliance.
- **[[Digital Identity]]** — self-sovereign identity schemes anchor public key registries and credential revocation lists to Layer 1, leveraging its censorship-resistance and tamper-evident history.
- **[[Non-Fungible Token|NFTs]]** — Layer 1 provides the ownership record for non-fungible tokens; on-chain provenance and transfer history are permanent once inscribed.
- **[[Data Provenance]]** — supply-chain and scientific-data applications hash datasets and commit the digest to Layer 1 to create an immutable timestamp and integrity check.
- **[[Cross-Chain Bridge|Cross-Chain Bridges]]** — bridge contracts on two Layer 1 networks lock assets on one chain while minting synthetic representations on another, enabling interoperability at the cost of added smart-contract risk.
- **Central Bank Digital Currencies (CBDCs)** — several jurisdictions are experimenting with permissioned Layer 1 networks to provide sovereign digital currency infrastructure, combining finality with regulatory controls.

### Standards & Context

- **[[Bitcoin Improvement Proposal]] (BIP)** — the process by which changes to the Bitcoin Layer 1 protocol are proposed, discussed, and ratified. Soft forks (SegWit, Taproot) and hard forks both flow through BIP-style deliberation.
- **[[Ethereum Improvement Proposal]] (EIP)** — Ethereum's analogous change-management process; EIPs govern Layer 1 parameters such as gas pricing (EIP-1559), the Merge (EIP-3675), and future [[Sharding]] milestones.
- **[[ISO TC 307]]** — the ISO technical committee for blockchain and distributed ledger technologies, producing standards relevant to Layer 1 interoperability and vocabulary.
- **[[W3C DID]] Core** — while not Layer-1-specific, Decentralised Identifiers are frequently anchored on Layer 1 networks, and W3C has published the DID Core specification as a W3C Recommendation.
- Layer 1 networks operating as financial market infrastructure in major jurisdictions are increasingly subject to regulatory frameworks: MiCA in the European Union, guidance from the SEC and CFTC in the United States, and forthcoming frameworks in the UK (FCA).

### Current Landscape (2026)

- Ethereum shipped two hard forks in 2025 — Pectra (7 May 2025), which added EIP-7702 account abstraction and raised the validator stake cap to 2,048 ETH, and Fusaka (3 December 2025), whose headline EIP-7594 PeerDAS lets validators sample blob data rather than download it in full, with Blob-Parameter-Only forks (BPO1 on 9 December 2025, BPO2 on 7 January 2026) lifting the per-block blob target/max to 14/21 and the L1 gas limit standardised at 60M.
- Ethereum's 2026 roadmap centres on Glamsterdam (mainnet targeted for the second half of 2026), introducing enshrined proposer-builder separation (ePBS) and groundwork for parallel execution, followed by Hegotá, which extends work on censorship resistance, native account abstraction and early post-quantum resilience.
- Solana's Firedancer/Frankendancer client (Jump Crypto, written in C) reached roughly 22-26% of stake by late 2025, cutting single-client risk, while the network completed its first full calendar year without downtime at ~400ms slot times on the Agave 3.0 client.
- Solana governance overwhelmingly approved Alpenglow in September 2025 — described by Anza as its biggest-ever core-protocol change — replacing TowerBFT/Proof of History with new Votor (voting) and Rotor (block propagation) components to push median finality from ~12.8 seconds toward 100-150 milliseconds, with staged rollout alongside Agave 4.x clients through late 2026.
- The base layer has specialised rather than consolidated: as of end-2025 there are 35+ active L1s securing roughly $120bn TVL, with distinct roles — Ethereum as settlement/data-availability layer, Solana and BNB Chain for high-throughput trading, plus dedicated "stablechains" optimised for stablecoin settlement and privacy-native chains (Aztec, Aleo, Namada).
- Avalanche's Etna hard fork replaced legacy subnets with sovereign Avalanche L1s, cutting the cost of launching a dedicated chain by over 99% and drawing institutional issuance such as Japan's Progmat moving billions in tokenised securities; Coinbase's Base L2 activated its Beryl hard fork in mid-2026 (B20 token standard, Reth V2, withdrawal finality cut from seven to five days).
- Open challenges into 2026 include cross-chain interoperability and intent-based routing to make fragmented L1/L2 ecosystems "feel like one chain", full Firedancer migration (1M TPS realistically a 2027-2028 target), and rising bars for institutional-grade compliance, predictable governance and eventual post-quantum security.

### References

- 1. Ethereum Foundation (2025). Fusaka Mainnet Announcement. https://blog.ethereum.org/2025/11/06/fusaka-mainnet-announcement
- 2. Ethereum.org (2026). Fulu-Osaka (Fusaka) Roadmap. https://ethereum.org/roadmap/fusaka/
- 3. Cointelegraph / TradingView (2026). The biggest blockchain upgrades still to come in 2026. https://www.tradingview.com/news/cointelegraph:d99fef4c5094b:0-the-biggest-blockchain-upgrades-still-to-come-in-2026/
- 4. Hotcoin Research (2026). The 2026 L1 Upgrade Race: Ethereum's Hard Fork Roadmap vs Solana's Consensus Overhaul. https://www.hotcoin.com/en_US/learn/article/HotcoinResearchThe2026L1UpgradeRaceEthereumsHardForkRoadmapvsSolanasConsensusOverhaulWhichChainWillAnchortheFutureofFinance/
- 5. The Block (2025). 2026 Layer 1 Outlook. https://www.theblock.co/post/382935/2026-layer-1-outlook
- 6. BlockEden (2026). Ethereum vs Solana 2026: The Battle Reshapes After Pectra and Firedancer. https://blockeden.xyz/blog/2026/01/13/ethereum-vs-solana-2026-pectra-firedancer-comparison/

### Provenance

