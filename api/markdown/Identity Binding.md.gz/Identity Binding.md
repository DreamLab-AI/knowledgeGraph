
An identity binding is a member of an agent's identity set that ties one identity to the key management arrangement behind it. In the SAC-CG Agent Ontology it is the class `IdentityBinding`, declared without a definition; this one follows from its properties.[^1] An `IdentitySet` reaches it through the `identity` property, and its declared property `keyManagementSystem` is a datatype property with a string value. The value names the [[Key Management System]] that holds the keys for the identity.

An identity binding belongs to an [[Agent Identity Set]] and concerns an [[Agent Identity]]. It should not be confused with [[Security Binding]], which is a separate class concerned with the trust chain from identifier to ledger.

The ontology is a Community Group draft (version 0.4.0 of the agent module), not a W3C Recommendation.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

