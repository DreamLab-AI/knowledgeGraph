The Confidential Computing Consortium is a Linux Foundation project that brings together hardware vendors, cloud providers and software firms to advance the adoption and standardisation of confidential computing. It defines confidential computing as protecting data in use by performing computation within a hardware-based trusted execution environment. The consortium stewards open-source projects, terminology and best practices that promote interoperable enclave technologies.

### Overview

- The Confidential Computing Consortium organises industry collaboration around protecting data while it is being processed. Its members host and govern open-source projects spanning enclave runtimes, attestation frameworks and SDKs, and it publishes a shared technical vocabulary that distinguishes data in use from data at rest and in transit. By coordinating across competing hardware platforms it aims to make confidential computing portable and verifiable.

### Key aspects

- Linux Foundation governance and neutral stewardship
- Shared definitions for data-in-use protection
- Hosting of open-source enclave and attestation projects
- Cross-vendor interoperability for trusted execution
- Best-practice guidance and a technical advisory council

### Mechanisms

- Linux Foundation governance and neutral stewardship
- Shared definitions for data-in-use protection
- Hosting of open-source enclave and attestation projects

### Applications

- Coordinating enclave runtime open-source projects
- Standardising remote attestation approaches
- Promoting confidential cloud workload patterns
- Aligning hardware vendor TEE terminology
- Educating industry on data-in-use protection

### Provenance

