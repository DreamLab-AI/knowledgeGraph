Rigid Body Dynamics is the branch of classical mechanics that models solid objects as perfectly non-deformable, computing their translational and rotational motion under applied forces and torques using Newton-Euler equations or Lagrangian formulations. It addresses the full six-degree-of-freedom motion state — position, orientation, linear velocity, and angular velocity — and resolves contact constraints through collision detection, impulse resolution, and constraint solvers. The field underpins real-time simulation in game engines, robot motion planning, spacecraft attitude control, and extended-reality environments. Key numerical methods include symplectic Euler integration, Runge-Kutta schemes, and position-based dynamics for stable, interactive-rate simulation.

### Overview

- Rigid body dynamics abstracts away material deformation, representing every solid body by its mass, centre of mass, and [[Inertia Tensor]]. This simplification makes the equations of motion computationally tractable at interactive rates.
- The state of a rigid body at any instant is fully described by six scalar quantities (three translational, three rotational) plus their time derivatives — twelve values in total. Integrating Newton's second law for both linear and angular components over time produces a trajectory.
- Contact and joint constraints couple multiple bodies; resolving these constraints is the primary computational challenge and drives the design of [[Physics Engine]] architectures.
- The field is mature: foundational equations date to the 18th century (Euler, Lagrange, d'Alembert), and robust real-time solvers have been available since the early 2000s (PhysX, Bullet, Havok, MuJoCo).

### Key Components

#### State Representation

- **Position and orientation** — typically stored as a 3-vector plus a [[Quaternion Mathematics]] (or rotation matrix) to avoid gimbal lock.
- **Linear velocity and angular velocity** — first time derivatives of position and orientation respectively.
- **[[Inertia Tensor]]** — a 3×3 symmetric positive-definite matrix encoding mass distribution; transforms angular momentum to angular velocity.

#### Equations of Motion

- **Newton-Euler equations** — $F = ma$ for translation; $\tau = I\alpha + \omega \times (I\omega)$ for rotation.
- **Lagrangian formulation** — generalised coordinates and the Euler-Lagrange equations; common in multi-link [[Kinematics]] chains.
- **d'Alembert's principle** — recasts dynamic problems as instantaneous static equilibria of virtual work.

#### [[Numerical Integration]]

- **Symplectic (semi-implicit) Euler** — first-order, energy-preserving on average; preferred for real-time game physics.
- **Runge-Kutta (RK4)** — higher accuracy for offline simulation and robotics planning.
- **[[Position-Based Dynamics]]** — directly manipulates positions rather than velocities; highly stable for interactive use (cloth, soft coupling).
- **Verlet integration** — time-reversible; popular in molecular dynamics and some game physics toolkits.

#### [[Collision Detection]]

- **Broad phase** — axis-aligned bounding box (AABB) trees or sweep-and-prune to quickly cull non-colliding pairs.
- **Narrow phase** — GJK (Gilbert-Johnson-Keerthi) and EPA (Expanding Polytope Algorithm) for exact contact manifold computation.
- **Continuous collision detection (CCD)** — tunnelling prevention for fast-moving or thin objects.

#### [[Collision Response]]

- **Impulse-based resolution** — applies instantaneous velocity changes at contact points using restitution and friction coefficients.
- **Sequential Impulse (SI) / Projected Gauss-Seidel (PGS)** — iterative constraint solver used in PhysX, Bullet, and Box2D.
- **Linear Complementarity Problem (LCP)** — exact formulation; computationally expensive but used in offline high-fidelity simulators.

#### [[Constraint Solving]]

- Joints (hinge, ball, prismatic, universal) are encoded as bilateral or unilateral constraints limiting relative motion between bodies.
- Articulated body algorithm (Featherstone) solves multi-body constraint trees in O(n) instead of O(n³).

### Applications and Use Cases

#### Game Engines and [[Spatial Computing]]

- Every major game engine integrates a rigid body solver: Unreal Engine uses Chaos Physics (natively developed); Unity uses PhysX (now transitioning to Havok). These handle thousands of interacting bodies at 60+ Hz.
- [[Extended Reality]] (XR) headsets require physics fidelity to maintain presence; virtual objects must respond to controller grabs with plausible contact and momentum transfer.
- [[Virtual Worlds]] simulations — from racing games to virtual manufacturing training — rely on rigid body dynamics for physical credibility.

#### Robotics

- [[Robot Motion Planning]] algorithms (RRT, PRM) use rigid body dynamics models to verify that planned trajectories are collision-free and dynamically feasible.
- Torque-controlled manipulators solve the inverse dynamics problem (given desired acceleration, compute joint torques) using rigid body equations.
- [[Sim-to-Real Transfer]] in [[Reinforcement Learning]] depends on accurate rigid body simulation (MuJoCo, Isaac Gym) to train policies transferable to physical hardware.

#### Engineering and Scientific Simulation

- [[Digital Twin]] platforms for machinery, bridges, and aerospace structures use rigid body models as the backbone before coupling deformable body or [[Finite Element Method]] layers.
- Spacecraft attitude determination and control — satellite reaction wheels and thruster firing are modelled as rigid body angular momentum exchanges.
- Crash simulation (automotive) uses rigid body surrogates for early-stage analysis before FEM refinement.

#### Film and Visual Effects

- [[Physics-Based Animation]] in VFX pipelines (Houdini, Maya) uses rigid body solvers to simulate debris, shatter, and prop interactions, dramatically reducing key-frame animation labour.
- Destruction simulations fracture objects at runtime using Voronoi decomposition, with each fragment becoming an independent rigid body.

### Standards and Context

- No single ISO/IEEE standard governs rigid body dynamics; practice is defined by open-source solver APIs and engine-specific documentation.
- **Bullet Physics** (open source, Pybullet) is the de facto reference implementation for research and academic benchmarking.
- **MuJoCo** (acquired by DeepMind/Google) is the standard simulator for robotics [[Reinforcement Learning]] research; its contact model combines smooth complementarity with implicit integration.
- **PhysX** (NVIDIA) is the dominant real-time solver in commercial game engines; GPU acceleration via CUDA enables large-scale scenes.
- **Havok Physics** (Microsoft) is widely used in AAA game titles and now integrates with Xbox cloud gaming infrastructure.
- **OpenUSD Physics** — Universal Scene Description includes a physics schema (`UsdPhysics`) enabling rigid body scenes to be described declaratively and exchanged between applications — increasingly relevant for [[Digital Twin]] workflows and [[Metaverse]] interoperability.
- Khronos Group's **glTF** and **OpenXR** standards intersect with rigid body state export and XR physics interoperability.

### Semantic Classification

### Provenance

