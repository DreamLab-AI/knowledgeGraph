ETSI GR MEC 032 is a Group Report published by the ETSI Industry Specification Group for Multi-access Edge Computing (ISG MEC) that addresses network slicing support and integration with MEC systems, defining how MEC platform capabilities can be exposed and leveraged across sliced 5G network infrastructure. The report analyses the relationship between Multi-access Edge Computing and Network Slicing, identifying reference architectures, use cases, and the interplay between MEC management entities and network slice management functions. It provides normative guidance for operators and vendors integrating edge computing workloads with 5G core network slicing mechanisms, covering aspects such as slice selection for MEC application placement, resource isolation guarantees, and inter-slice MEC service continuity.

### Overview

- ETSI GR MEC 032 belongs to the [[ETSI MEC Specification Series]], a body of work produced by [[ETSI ISG MEC]] since 2014 to standardise [[Edge Computing]] at or near the radio access network.
- The report specifically addresses a key architectural tension: MEC systems were designed to operate at the edge as relatively autonomous platforms, while 5G introduces [[Network Slicing]] as a method of logically partitioning the entire network end-to-end. Reconciling these two paradigms requires careful definition of management interfaces and resource exposure.
- GR MEC 032 is a Group Report (GR) rather than a Group Specification (GS). This distinction matters: GR documents present informative analysis, feasibility studies, and requirements gathering; GS documents carry normative weight. GR MEC 032 thus feeds into subsequent normative specifications by establishing the problem space and identifying solutions.
- The report is consumed primarily by network operators deploying [[5G Core]] infrastructure, vendors building [[MEC Orchestrator]] products, and application developers targeting [[Low Latency Communication]] use cases that require guaranteed resources via slices.
- Understanding GR MEC 032 requires familiarity with [[ETSI GR MEC 002]] (MEC use cases and requirements) and [[ETSI GS MEC 003]] (MEC framework and reference architecture), upon which its architectural extensions build.

### Key Components

#### Network Slicing Integration Model

- Defines the mapping between [[Network Slice]] identifiers (S-NSSAIs in 3GPP terminology) and MEC application hosting requirements.
- Introduces the concept of "slice-aware MEC" where the [[MEC Orchestrator]] consults slice information when deciding MEC host selection and application instantiation.
- Addresses how [[Resource Isolation]] guarantees from slices extend to the MEC host compute and storage layers.

#### Reference Architecture Extensions

- Extends the [[MEC Reference Architecture]] defined in GS MEC 003 by adding interfaces between the [[MEC Platform Manager]] (MEPM) and [[Network Slice Management Function]] (NSMF).
- Identifies new or extended APIs at the Mm3 and Mm4 reference points to carry slice-related parameters from the 5G management plane into the MEC management plane.
- Specifies how [[MEC Application]] lifecycle events (instantiation, migration, termination) must notify or query slice management functions.

#### Use Case Catalogue

- V2X (Vehicle-to-Everything): [[V2X Communication]] requires deterministic low-latency paths; slice-guaranteed bandwidth must extend from the radio through the MEC host to the V2X application.
- [[Industrial IoT]]: Factory automation workloads require resource isolation that prevents "noisy neighbour" effects from other tenants sharing the same MEC host.
- [[Augmented Reality]] and [[Extended Reality]]: Rendering offload and scene analysis at the edge require guaranteed compute slices aligned to the radio slice used by the headset.
- [[Content Delivery Network]] edge caching: CDN nodes instantiated as MEC applications benefit from slice-level prioritisation for content synchronisation.

#### MEC Application Placement Guidance

- [[MEC Application Placement]] decisions must incorporate slice topology: an application must be instantiated on a MEC host reachable within the slice's transport segment.
- Introduces placement constraints encoded as slice-aware descriptors within the [[MEC Application Package]].

#### Service Continuity

- [[MEC Service Continuity]] across handovers requires that the target MEC host resides in the same network slice, or that a slice handover is orchestrated in parallel with the MEC application migration.
- Defines state transfer procedures and the role of the [[MEC Application]] state replication in maintaining session continuity.

### Applications and Use Cases

- **Autonomous Vehicles and V2X**: Deterministic latency below 10 ms for safety-critical messages demands that both the radio slice and the edge compute slice are co-managed. GR MEC 032 provides the framework for this co-management.
- **Smart Manufacturing**: [[Industrial IoT]] deployments in manufacturing use private 5G networks with dedicated slices; GR MEC 032 enables the MEC-hosted control logic to inherit the isolation guarantees of those slices.
- **Remote Healthcare and Telesurgery**: Real-time haptic feedback and video over [[Ultra-Reliable Low Latency Communication]] (URLLC) slices requires the MEC processing tier to respect the same latency budget constraints defined at the slice level.
- **AR/VR Cloud Rendering**: [[Extended Reality]] applications offloading rendering to the edge benefit from slice-guaranteed uplink capacity that GR MEC 032 maps to compute resource reservations on the [[MEC Host]].
- **Public Safety Networks**: First-responder networks using dedicated slices can host [[Mission Critical Communication]] applications as MEC services with resource protection across the slice boundary.
- **Network Operator Service Assurance**: MEC-hosted probes and analytics functions, placed within monitoring slices, gain resource guarantees that prevent monitoring blind spots during high-load periods.
- **Multi-Tenant MEC Hosting**: Operators offering MEC hosting to third-party verticals can use slice-based resource guarantees as the commercial SLA foundation, with GR MEC 032 providing the technical underpinning.

### Standards and Context

- **Issuing Body**: [[ETSI]] Industry Specification Group for Multi-access Edge Computing ([[ETSI ISG MEC]]), established in 2014 as the primary standards body for MEC.
- **Document Type**: Group Report (GR) — informative, not normative. Feeds into normative GS-series specifications.
- **Relationship to 3GPP**: ETSI ISG MEC collaborates closely with [[3GPP]] which defines the [[5G Core]] and [[Network Slicing]] architecture (TS 23.501, TS 28.530–533). GR MEC 032 adopts 3GPP slice terminology (S-NSSAI, NSMF, NSSMF) and maps it to ETSI MEC management concepts.
- **Relationship to ETSI NFV**: The MEC management plane builds atop [[Network Function Virtualisation]] infrastructure defined by [[ETSI ISG NFV]], particularly the MANO framework. GR MEC 032 acknowledges that MEC hosts are often implemented as NFV workloads, so slice resource management must traverse the NFV orchestration layer.
- **Position in MEC Series**:
  - [[ETSI GR MEC 002]] — use cases and requirements (foundational)
  - [[ETSI GS MEC 003]] — framework and reference architecture
  - [[ETSI GS MEC 010]] — MEC application package and lifecycle management
  - ETSI GR MEC 032 — network slicing integration (this document)
  - [[ETSI GS MEC 011]] — MEC platform application enablement API
- **Regulatory Context**: In many jurisdictions, operators deploying 5G spectrum for industrial verticals (e.g., European 5G Action Plan, German local 5G licensing) must demonstrate resource isolation. GR MEC 032's guidance supports compliance arguments for those deployments.
- **Industry Forum Alignment**: The document aligns with work in the [[GSMA]] 5G network slicing guidelines and the [[O-RAN Alliance]] WG6 cloudification and orchestration specifications, providing a standards-level complement to those industry group deliverables.

### Semantic Classification

### Provenance

