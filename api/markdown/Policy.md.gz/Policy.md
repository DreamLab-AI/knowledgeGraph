A policy is an explicit, authoritative statement of intent that guides decisions and prescribes acceptable behaviour or actions within an organisation or system. Policies translate high-level goals into rules, principles and constraints that can be applied consistently and enforced. In computing the term also denotes machine-readable rule sets, such as access-control policies, while in reinforcement learning a policy is a mapping from states to actions.

### Overview

- Policies operate at many levels: organisational policies set behavioural expectations and risk appetite, technical policies encode enforceable rules in systems, and in machine learning a policy is the decision function an agent learns. Across these senses the common thread is that a policy is a stable, reusable specification of how to act given a situation, separating the statement of intent from the mechanisms that enforce or execute it.

### Key aspects

- Declarative intent expressed as principles, rules or constraints.
- Separation between policy definition and the enforcement mechanism.
- Enforcement and auditing ensure that stated policy is actually applied.
- Machine-readable policies allow automated decision and access control.
- In reinforcement learning, a policy maps observed states to actions.

### Applications

- Access-control and authorisation rules in security systems.
- Organisational compliance and information-governance frameworks.
- Configuration and admission control in cloud platforms.
- Decision functions for reinforcement-learning agents.

### Provenance

