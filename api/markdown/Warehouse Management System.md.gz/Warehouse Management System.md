A warehouse management system (WMS) is a large software system that coordinates the activities of a warehouse.[^1]

The Georgia Tech course text Warehouse & Distribution Science describes the work in the context of customer orders. On receipt of an order the warehouse must verify that inventory is available to ship and may need to coordinate fulfilment with other sites, then produce pick lists to guide order-picking, produce any necessary shipping documentation and schedule the order-picking and shipping.[^1] It says these activities are typically accomplished by a warehouse management system.[^1] The text adds that order-picking typically accounts for about 55% of warehouse operating costs.[^1]

## Place among systems

A Chalmers University of Technology thesis abstract says warehouse management systems have been introduced as a tool for the effective management of warehouses.[^2] In the Zaidi, Amanton and Sanlaville classification, a warehouse management system is one of three supply chain execution systems, alongside manufacturing execution systems and transportation management systems.[^3] See [[Supply Chain Execution System]] and [[Order Picking]].

## Scope and distinctions

A warehouse management system works with enterprise resource planning, which the same preprint describes as the main database for firm activity.[^3] See [[Enterprise Resource Planning]]. The course text describes a warehouse management system as one large system coordinating the activities of the warehouse.[^1]

## What the sources do not establish

The Georgia Tech text is a draft from 2002 and is about warehouse design as much as software. The sources do not describe automation or robot control, which the earlier version of this page discussed, and they give no adoption data or feature standard. The Chalmers record is an abstract of a thesis.[^1][^2][^3]

[^1]: John J. Bartholdi III and Steven T. Hackman, “Warehouse & Distribution Science”, Release 0.1.2 (Georgia Tech course text, revised 24 May 2002). https://www2.isye.gatech.edu/~spyros/courses/IE6202/Fall-2002/Bartholdi-Hackman.pdf
[^2]: Nils Persson, Chalmers University of Technology, 2024, “The effective integration and optimization of Warehouse Management Systems: A Systematic Literature Review” (repository record, abstract only). https://odr.chalmers.se/items/5d641c09-f404-4f2e-9004-5b21d72a1c17/full
[^3]: Fares Zaidi, Laurent Amanton and Eric Sanlaville, “Towards a Novel Cooperative Logistics Information System Framework”, arXiv:1905.00687. https://arxiv.org/pdf/1905.00687

