Total quality management is a management approach in which all departments, employees and managers are responsible for continuously improving quality so that products and services meet or exceed customer expectations.[^1]

An open operations management text says a company adheres to its principles by focusing on three tasks: customer satisfaction, employee involvement and continuous improvement. It says successful total quality management requires that everyone in the organisation, not only upper management, commits to satisfying the customer.[^2] A second open text calls it a “comprehensive management philosophy” focused on continuous improvement, customer satisfaction and organisational excellence, and says it integrates quality into every function and level of the organisation.[^3]

## History

The Lean Enterprise Institute says the term total quality control was coined in 1957 by the US quality expert Armand Feigenbaum, and that by the 1980s other experts including Philip Crosby, Joseph Juran, W. Edwards Deming and Kaoru Ishikawa expanded the concept into total quality management, adding the idea that quality is the responsibility of all employees. Toyota implemented total quality control in the early 1960s.[^1]

## Scope and distinctions

The Institute says total quality control relies on the plan-do-check-act cycle and statistical tools, used often by employees during kaizen activities, and forms an important subsystem of lean.[^1] See [[Kaizen]] and [[Lean Production]]. A review of operations and supply chain management lists total quality management with lean, Six Sigma and Lean Six Sigma as business improvement initiatives pursued for operational excellence, see [[Six Sigma]].[^5]

A 1999 article notes that just-in-time and total quality management are widely taught in operations management courses.[^4] The first open text uses a looser phrase, saying total quality management, or quality assurance, includes all the steps that a company takes to ensure goods or services meet or exceed customers' defined specifications.[^2]

## What the sources do not establish

Sources define the term in overlapping rather than identical words and none provides an authoritative standard definition, so this page records several. They offer no data on results.

[^1]: Lean Enterprise Institute, “Total Quality Management (Lean Lexicon)”. https://www.lean.org/lexicon-terms/total-quality-management/
[^2]: Engineering LibreTexts (Introduction to Operations Management, 1st Ed.), “5.4.1: Total Quality Management (TQM)”. https://eng.libretexts.org/Under_Construction/Purgatory/Introduction_to_Operations_Management_1st_Ed./05:_Managing_Quality/5.04:_Quality_Systems/5.4.01:_Total_Quality_Management_(TQM)
[^3]: Business LibreTexts (Operation of a Small Business for College Students, Reedley College), “9.3: Total Quality Management (TQM)”. https://biz.libretexts.org/Courses/Reedley_College/Operation_of_a_Small_Business_for_College_Students/09:_Organizational_Planning_and_Total_Quality_Management/9.03:_Total_Quality_Management_(TQM)
[^4]: Arup Mukherjee and Walter J. Wheatley, Developments in Business Simulation and Experiential Learning 26, 1999, “The ABC’s of Teaching the Theory of Constraints to Undergraduate Business Students”. https://absel-ojs-ttu.tdl.org/absel/article/view/976/945
[^5]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

