An open standard is a publicly accessible specification for a technology, protocol, format, or interface that is developed through a transparent, consensus-based process and can be implemented and used without discriminatory restrictions. Open standards enable interoperability between systems from different vendors by providing a shared, stable technical baseline. They are maintained by recognised standards bodies and are typically available royalty-free or under FRAND (Fair, Reasonable And Non-Discriminatory) licensing terms. Open standards contrast with proprietary specifications controlled by a single vendor and are foundational to open, competitive ecosystems.

### Overview

- Open standards underpin virtually every layer of modern digital infrastructure, from low-level networking ([[TCP-IP]], [[HTTP]]) to high-level application formats ([[HTML]], [[JSON]], [[glTF]]) and cross-platform runtime APIs ([[OpenXR]], [[WebXR]]).
- The defining characteristics of a genuine open standard are:
  - **Transparency**: the specification and its development history are publicly accessible.
  - **Openness**: any party may participate in or observe the standards process.
  - **Impartiality**: the governing body is not controlled by a single vendor.
  - **Consensus**: adoption of changes requires broad stakeholder agreement.
  - **Availability**: the specification can be read, implemented, and deployed without prohibitive fees.
  - **Maintenance**: a stewardship body accepts bug reports and issues revisions.
- The distinction between an open standard and [[Open Source Software]] is important: a standard is a specification (a document describing behaviour), whereas open-source software is a working implementation. The two often coexist — e.g. [[OpenXR]] is an open standard whose reference implementation is open-source.
- Open standards reduce systemic risk in critical infrastructure by ensuring that no single vendor can unilaterally withdraw access or raise prices once the ecosystem depends on the technology. This is central to [[Digital Sovereignty]] concerns in government and enterprise procurement.

### Key Components

- **Specification Document** — the normative written description of the standard, typically divided into informative background and normative requirements (using RFC 2119 language: MUST, SHOULD, MAY).
- **[[Conformance Test Suite]]** — automated or manual tests that verify whether an implementation correctly realises the specification; essential for interoperability.
- **[[Reference Implementation]]** — a canonical, often open-source, implementation that demonstrates the specification's intent and serves as a ground-truth for ambiguous cases.
- **[[Intellectual Property Policy]]** — the legal framework governing patents that read on the standard; FRAND or royalty-free (RF) policies are required for broad open adoption.
- **[[Consensus Process]]** — the governance mechanism (working groups, ballots, public review) through which changes are proposed, debated, and ratified.
- **Versioning and Errata** — a process for issuing corrections and new editions while preserving backward compatibility.
- **Namespace / Registry** — a controlled registry of identifiers (MIME types, URI schemes, codec parameters) that prevents collisions across implementations.

### Mechanisms

- **Ballot-based ratification** (ISO, IEEE): national bodies cast votes; supermajority required for approval.
- **Rough consensus** ([[IETF]]): working groups reach broad agreement documented in RFCs; no formal vote.
- **Member-driven working groups** ([[World Wide Web Consortium]], [[Khronos Group]]): member organisations contribute engineers who draft, review, and ratify specifications.
- **Community group / incubation** ([[World Wide Web Consortium]] CGs): lightweight track for early-stage exploration before formal standardisation.
- **FRAND licensing commitments**: patent holders declare they will license essential patents on FRAND terms, enabling independent implementations.
- **Royalty-free pledges**: stricter than FRAND; patent holders commit to zero royalties, enabling truly open ecosystems (common in web standards).

### Applications and Use Cases

- **[[Spatial Computing]] and the [[Metaverse]]**
  - [[glTF]] (GL Transmission Format, Khronos): royalty-free format for 3D asset transmission; the "JPEG of 3D".
  - [[Universal Scene Description]] (Universal Scene Description, Pixar/AOUSD): open format for complex scene interchange with layering and composition.
  - [[OpenXR]] (Khronos): cross-platform [[XR]] application runtime API, abstracting headsets and controllers from application code.
  - [[WebXR]] Device API (W3C): browser-native API for immersive experiences on the open web.
- **Networking and the Web**
  - [[TCP-IP]], [[HTTP]], [[Transport Layer Security]], [[DNS]]: open IETF standards underpinning internet connectivity.
  - [[HTML]], [[CSS]], [[JavaScript]]: W3C/WHATWG open standards for the web platform.
  - [[WebAssembly]] (Wasm): W3C standard for portable, near-native execution in browsers and beyond.
- **Data and [[Interoperability]]**
  - [[JSON-LD]], [[RDF]], [[OWL]]: W3C semantic web standards enabling machine-readable linked data.
  - [[OpenAPI]]: de-facto open standard for describing RESTful [[API]]s.
  - [[FHIR]] (HL7): open standard for health data exchange.
- **[[Distributed Systems]] and [[Blockchain]]**
  - [[Ethereum]] [[ERC]] token standards: community-ratified interface standards for smart contracts.
  - [[Decentralised Identifier]] (Decentralised Identifiers, W3C): open standard for self-sovereign identity.
  - [[ActivityPub]] (W3C): federated social networking protocol powering the [[Fediverse]].
- **[[Artificial Intelligence]]**
  - [[ONNX]] (Open Neural Network Exchange): open format for AI model portability across frameworks.
  - [[MLflow]] model registry schemas and [[OpenTelemetry]] for AI observability pipelines.
  - Emerging standards for [[AI Safety]] evaluation and [[Model Card]]s.

### Standards Bodies and Context

- **[[World Wide Web Consortium]]** (World Wide Web Consortium) — governs web platform standards including HTML, CSS, WebXR, JSON-LD, DID. Uses royalty-free patent policy.
- **[[IETF]]** (Internet Engineering Task Force) — governs internet protocols (TCP/IP, HTTP, TLS, DNS, QUIC) via RFC process and rough-consensus model.
- **[[ISO]]** (International Organisation for Standardisation) — ballot-based body; covers broad range including document formats (ISO 32000 for PDF), management systems, and measurement.
- **[[IEEE]]** — covers electrical engineering, wireless (802.11 Wi-Fi, 802.3 Ethernet), and computing standards.
- **[[Khronos Group]]** — member-driven industry consortium; governs OpenGL, Vulkan, OpenXR, glTF, SPIR-V. Royalty-free policy.
- **[[AOUSD]]** (Alliance for OpenUSD) — stewards the USD format for 3D scene description; includes Apple, Autodesk, NVIDIA, Pixar.
- **[[OASIS]]** — governs MQTT, STIX, SAML, AMQP and other enterprise standards.
- **[[OpenID Foundation]]** — stewards OpenID Connect and related identity federation standards.
- Regulatory relevance: EU mandates open standards via the [[European Interoperability Framework]] (EIF); the UK Government [[Open Standards Principles]] require open standards in central government procurement.

### Considerations and Tensions

- **Openness vs Quality**: consensus processes can be slow; open standards sometimes lag behind proprietary innovation.
- **Patent ambush**: undisclosed essential patents can emerge post-ratification, undermining royalty-free commitments (e.g. GIF/LZW controversy).
- **Embrace-extend-extinguish**: vendors implementing open standards may add proprietary extensions that fragment the ecosystem.
- **De-facto vs de-jure standards**: some standards (e.g. [[PDF]] before ISO adoption, [[Markdown]]) achieve broad adoption informally before or without formal ratification.
- **Standards capture**: large vendors with significant engineering resources can dominate working groups and shape standards to their advantage.
- **Versioning fragmentation**: rapid iteration (e.g. [[OpenAPI]] 2.x vs 3.x) can create incompatible islands within a nominally open ecosystem.
- **AI and open standards**: the emergence of large language model APIs raises questions about open standard governance for [[AI Model API]]s; current efforts (e.g. OpenAPI-based LLM specs) are nascent.

### Provenance

