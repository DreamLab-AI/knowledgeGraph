The WebSocket Protocol is a standardised full-duplex communication protocol defined in RFC 6455 (2011) that provides a persistent, low-latency bidirectional channel between a client and a server over a single TCP connection. It was designed to overcome the limitations of HTTP polling and long-polling by upgrading an initial HTTP handshake to a persistent framed message channel, enabling servers to push data to clients without client-initiated requests. WebSocket frames carry minimal overhead — a 2-byte header for small messages — making the protocol suitable for high-frequency data streams such as financial tickers, collaborative editing, gaming, and real-time AI agent communications. It is supported natively in all major browsers and server-side runtimes, and forms the transport layer for many higher-level protocols including STOMP, MQTT-over-WebSocket, and the OpenAI Realtime API.

### Overview

- WebSocket was created to resolve the "HTTP polling problem" that plagued early web applications requiring real-time updates. Before WebSocket, developers used short polling (repeated HTTP requests on a timer), long polling (holding a request open until the server had data), or Comet frameworks — all imposing significant overhead from repeated [[Hypertext Transfer Protocol]] headers and TCP connection establishment.
- The upgrade process reuses an existing HTTP/1.1 connection and replaces HTTP framing with WebSocket's minimal frame format for the lifetime of the connection, making it both backwards-compatible and efficient.
- WebSocket is defined by [[RFC 6455]] (October 2011), published by the [[Internet Engineering Task Force]]. It was standardised after several competing draft specifications, and its inclusion in the [[HTML5]] specification drove rapid browser adoption.
- All major browsers (Chrome, Firefox, Safari, Edge) and server-side runtimes (Node.js, Deno, Python asyncio, Java Netty, Go, Rust Tokio) support WebSocket natively, giving it ubiquitous reach across the web platform.
- The protocol is extended by [[RFC 8441]] (2018), which defines bootstrapping WebSocket from [[HTTP/2]], allowing multiplexed WebSocket streams over a single [[Transport Layer Security]] connection — a significant efficiency improvement for applications that open many simultaneous channels.

### Key Mechanisms

- **Opening Handshake**
  - The client sends an HTTP GET request with `Upgrade: websocket`, `Connection: Upgrade`, a randomly generated `Sec-WebSocket-Key` (16 bytes base64-encoded), and an optional `Sec-WebSocket-Protocol` list of requested subprotocols.
  - The server responds with HTTP 101 Switching Protocols and a `Sec-WebSocket-Accept` value computed as the base64-encoded SHA-1 of the key concatenated with a fixed GUID. This prevents cross-protocol attacks and cache poisoning by confirming the server understands the WebSocket handshake.
  - After HTTP 101, the TCP stream is no longer HTTP — both parties use the WebSocket framing format exclusively.
- **Framing**
  - WebSocket data is transmitted as frames. Each frame has a 2-byte base header containing: FIN bit (final fragment indicator), opcode (text=1, binary=2, close=8, ping=9, pong=10, continuation=0), masking bit, and a 7-bit payload length field.
  - For payloads 126–65535 bytes the header extends to 4 bytes; for larger payloads it extends to 10 bytes with a 64-bit length field. This minimal overhead — as little as 2 bytes per frame — makes WebSocket far more efficient than HTTP for high-frequency small messages.
  - Client-to-server frames must be masked with a 4-byte masking key (XOR applied to each payload byte) to prevent [[Cache Poisoning]] attacks on transparent [[HTTP Proxy]] infrastructure.
  - Large messages may be split into continuation frames, with FIN=0 on all but the last, allowing streaming of large payloads without buffering the entire message.
- **Control Frames**
  - Ping/pong frames enable keepalive and latency measurement without application-level heartbeat logic. Either party may send a ping; the recipient must reply with a pong containing the same payload.
  - The close frame initiates a graceful shutdown handshake: the sender includes an optional status code (e.g. 1000=Normal Closure, 1001=Going Away, 1011=Server Error) and an optional UTF-8 reason string. The recipient echoes a close frame and both parties then close the TCP connection.
- **Subprotocols and Extensions**
  - The `Sec-WebSocket-Protocol` header allows client and server to negotiate an application-level subprotocol (e.g. `soap`, `wamp`, `graphql-ws`, `v1.saleor`) carried over the WebSocket channel. This enables typed message framing on top of WebSocket's raw byte/text channel.
  - The `Sec-WebSocket-Extensions` header supports negotiation of protocol extensions such as `permessage-deflate`, which applies per-message compression using the [[DEFLATE]] algorithm, significantly reducing bandwidth for repetitive text payloads such as JSON.

### Security Considerations

- **Origin Policy**: Browsers enforce WebSocket origin checks via the `Origin` header sent in the opening handshake. Servers must validate this header to prevent [[Cross-Site WebSocket Hijacking]], where a malicious page on a different origin establishes a WebSocket connection using the victim's cookies.
- **Masking**: Client-to-server frame masking prevents adversarial clients from injecting data that could be misinterpreted by intermediate [[HTTP Proxy]] caches as valid HTTP responses, a class of attack known as [[Cache Poisoning]].
- **TLS Requirement (WSS)**: Production deployments must use WSS (WebSocket Secure), which tunnels the WebSocket connection over [[Transport Layer Security]], preventing eavesdropping and man-in-the-middle attacks. The WSS URI scheme uses port 443 by default.
- **Denial of Service**: WebSocket servers are susceptible to connection-exhaustion attacks; each persistent connection consumes a file descriptor and memory. Server-side connection limits, per-IP rate limiting, and authentication-before-upgrade patterns are standard mitigations.
- **Authentication**: WebSocket itself has no built-in authentication. Applications typically pass credentials in the initial HTTP handshake via cookies, query parameters, or custom headers, then validate server-side before completing the upgrade.

### Applications and Use Cases

- **Financial Data Feeds**: Stock tickers, order book updates, and trade execution notifications require sub-second delivery to browser clients; WebSocket's persistent channel eliminates the per-message HTTP overhead of polling approaches.
- **Collaborative Editing**: Tools such as Figma, Notion, and Google Docs use WebSocket (or [[WebRTC]] data channels) to synchronise document state across collaborating users in real time, enabling [[Real-Time Collaboration]] at scale.
- **Gaming**: Browser-based and mobile games use WebSocket for player state synchronisation, chat, and matchmaking, leveraging the low-latency bidirectional channel for responsive multiplayer experiences.
- **AI Streaming Interfaces**: The OpenAI Realtime API and similar [[Large Language Model]] streaming endpoints deliver token-by-token output over WebSocket, enabling streaming text and voice interfaces. The bidirectional nature allows clients to send audio input while simultaneously receiving audio output, supporting voice [[Agent Event Stream]] scenarios.
- **IoT and Telemetry**: WebSocket is used as a browser-accessible bridge for IoT sensor data, often alongside [[MQTT]] (which runs natively over WebSocket via MQTT-over-WebSocket). Devices publish to an [[MQTT]] broker; browser dashboards subscribe via WebSocket.
- **Notifications and Presence**: Chat applications, social platforms, and productivity tools use WebSocket to push notifications, typing indicators, and presence (online/offline) status to clients without polling.
- **Multi-Agent Coordination**: In [[Multi-Agent System]] architectures, WebSocket serves as the real-time coordination bus for agent orchestration layers, enabling agents to subscribe to task assignments and publish results over persistent connections.

### Comparison with Alternatives

- **[[Server-Sent Events]] (SSE)**: SSE provides unidirectional server-to-client streaming over standard HTTP, making it simpler to implement and more compatible with HTTP/2 multiplexing. WebSocket is preferred when the client also needs to send high-frequency messages. SSE auto-reconnects; WebSocket requires application-level reconnection logic.
- **[[gRPC]] / HTTP/2 Streaming**: gRPC bidirectional streaming offers strongly-typed RPC with [[Protocol Buffers]] serialisation and HTTP/2 multiplexing, making it preferable for server-to-server microservice communication. WebSocket remains dominant for browser clients where gRPC is inaccessible without a gRPC-Web proxy.
- **[[WebRTC]]**: WebRTC data channels provide peer-to-peer low-latency communication with UDP semantics, suitable for video/audio conferencing and P2P gaming. WebSocket is client-server only and uses TCP, providing reliability at the cost of head-of-line blocking.
- **[[HTTP Long Polling]]**: Long polling emulates push over HTTP by holding requests open; it introduces higher latency, greater server resource consumption, and more complex reconnection handling than WebSocket. WebSocket superseded long polling for nearly all new applications after widespread browser support arrived circa 2012.

### Standards and Context

- **[[RFC 6455]]** (October 2011): The primary specification defining the WebSocket Protocol, published by [[Internet Engineering Task Force]] Working Group HyBi (Hypertext Bidirectional).
- **[[RFC 8441]]** (September 2018): Extends WebSocket to work over [[HTTP/2]] connections using the HTTP/2 CONNECT method, enabling multiplexed WebSocket streams and reducing TLS session overhead.
- **[[HTML5]] WebSocket API**: The `WebSocket` JavaScript interface is part of the living HTML standard maintained by [[WHATWG]], enabling browser-side WebSocket connections with event-driven message handling.
- **[[IETF]] HyBi Working Group**: The working group responsible for the WebSocket specification, concluding its work after RFC 6455 was published.
- **Subprotocol Registry**: IANA maintains a registry of WebSocket subprotocol names, allowing named subprotocols to be reserved for public protocols (e.g. `soap`, `wamp.2.json`).
- **[[permessage-deflate]]**: Defined in RFC 7692, this extension compresses WebSocket message payloads using [[DEFLATE]], commonly reducing JSON payload sizes significantly in production deployments.

### Provenance

