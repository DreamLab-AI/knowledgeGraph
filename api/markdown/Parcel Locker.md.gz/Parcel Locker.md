A parcel locker is a secure collection point, managed with digital technology, at which a parcel is left for the recipient to collect, and reviews treat it as a type of alternative delivery point for last-mile delivery.[^1][^2]

A 2025 review from Cardiff University says that parcel lockers offer a promising solution by integrating digital technology with secure parcel handling, reducing delivery bottlenecks and traffic congestion while optimising personnel utilisation and improving efficiency.[^1] That is the review's description, and it is not a formal definition. The Melbourne review defines alternative delivery points as locations or facilities other than customers' primary address, where parcels can be collected and delivered, and lists smart parcel lockers, in stationary and mobile forms, among their types.[^2]

## Attended and unattended lockers

From the point of view of service interaction, the Cardiff review classifies parcel lockers as attended or non-attended systems. Attended lockers require interaction with service personnel at a designated pickup location, such as retail counters or postal agencies. Unattended lockers enable fully self-service operations, often accessible 24/7.[^1]

## What research has covered

The Cardiff review finds that most existing research on parcel locker networks is heavily concentrated on determining optimal locations and developing efficient routing strategies. It identifies gaps, such as the lack of empirical studies on mobile lockers and their integration with other urban logistics systems.[^1]

## Scope and distinctions

Parcel Locker is a form of [[Last-Mile Delivery]]. Alternative delivery points also include click-and-collect points and pick-up points in places such as a store or library, which are covered at [[Click and Collect]].[^2] A related page is [[Parcel Carrier]].

## What the sources do not establish

Neither review gives a formal definition of a parcel locker, so the definition above is drawn from their descriptions. The opened sources give no market or usage figures that this page relies on.

[^1]: Cardiff University (Zhang and Demir), Frontiers in Future Transportation 6, 2025, “Parcel locker solutions for last mile delivery: a systematic literature review and future research directions”. https://www.frontiersin.org/journals/future-transportation/articles/10.3389/ffutr.2025.1654621/pdf
[^2]: University of Melbourne (Mohri and colleagues), Transportation Research Part E 192, 2024, “Contextualizing alternative delivery points in last mile delivery”. https://minerva-access.unimelb.edu.au/rest/bitstreams/a4100875-4af3-46bd-9e31-5638559a10e4/retrieve

