Transport planning is the process of deciding how transport assets are provided and how mobile assets are used, and the opened sources define it mainly for public infrastructure.[^1]

Rodrigue, Notteboom and Slack write that transport planning focuses on the public provision and financing of transportation assets, particularly roads and public transit systems. They add that planning can also be undertaken by private transport actors such as carriers, to manage their assets at a scale beyond that of the public sector.[^1]

## Planning horizons

That text separates planning by time horizon. Strategic planning is high-level and long-term and relies on strategic plans implementing a vision. Operational planning involves decisions that solve practical problems of transport operations, usually within a year; the horizon is too short for infrastructural investment but allows the allocation of mobile assets such as vehicles.[^1]

## Freight use

Freight use of the term is spread across several sources rather than defined in one. Rodrigue says logistics enables greater efficiency of freight mobility with an appropriate choice of modes, terminals, routes and scheduling, and lists the transport modes to be used and the timing and sequencing of deliveries among the decisions involved.[^2] The operational research review by Petropoulos, Laporte and colleagues says the transport costs of delivering customer demand from distribution centres can be modelled with transportation planning software, which typically includes road maps, speed limits, tolls, congestion and methods for modelling transport costs.[^3] Routing a fleet of vehicles to a set of customers at lowest cost is treated as a separate optimisation problem, described at [[Vehicle Routing Problem]] and [[Logistics Optimisation]].[^3]

## Evidence limits

No opened source defines freight transport planning as a single term. Modes and routes are supported by the logistics chapter and the operational research review; load planning as such is not defined in any of them, although the review notes 3D container loading as a packing application.[^2][^3] For the wider freight setting see [[Freight Transportation]].

[^1]: Jean-Paul Rodrigue, Theo Notteboom and Brian Slack, The Geography of Transport Systems, “9.2 – Transport Planning and Governance”. https://transportgeography.org/contents/chapter9/transport-planning-governance/
[^2]: Jean-Paul Rodrigue, The Geography of Transport Systems, “7.4 – Logistics and Freight Distribution”. https://transportgeography.org/contents/chapter7/logistics-freight-distribution/
[^3]: Fotios Petropoulos, Gilbert Laporte and colleagues, “Operational Research: Methods and Applications”, arXiv:2303.14217. https://arxiv.org/pdf/2303.14217

