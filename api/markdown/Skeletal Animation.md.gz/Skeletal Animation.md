Skeletal animation is a character animation technique in which a hierarchical rig of joints defines the articulated structure of a character or creature, and mesh vertices are deformed by the weighted influence of surrounding joints through a process known as skinning. Artists author motion by keyframing or procedurally driving joint transforms over time; the underlying mesh deforms accordingly in real time on the GPU via linear blend skinning or dual-quaternion skinning. The approach is the dominant method for animating characters in games, virtual reality, film visual effects, and virtual avatar systems due to its runtime efficiency, compact data representation, and amenability to motion capture retargeting and machine-learning-driven synthesis.

### Overview

- Skeletal (or "rigged") animation was systematised in the computer graphics community through the 1980s–1990s, building on forward and inverse kinematics mathematics from robotics. The technique became commercially dominant with the adoption of real-time GPU vertex shaders in the early 2000s, enabling smooth per-frame deformation in hardware without pre-baking per-frame geometry. Prior to GPU skinning, characters relied on pre-baked [[Morph Target Animation]] or rigid segmented meshes.
- The core insight is that organic creatures move by rotating joints in a skeletal hierarchy. Rather than storing per-frame vertex positions for every frame of animation (which is costly in memory), the system stores only joint rotation curves; at runtime a small matrix-multiply per vertex recovers the deformed position from a compact representation.
- Skeletal animation remains the dominant character animation paradigm in AAA video games, VR/XR, film visual effects (digital doubles), architectural visualisation, social metaverse platforms, and industrial [[Digital Twin]] systems. Its longevity stems from a highly optimised GPU execution path, robust toolchain support, and natural integration with [[Motion Capture]] pipelines.

### Key Components

- **Skeleton / Rig**
  - A directed acyclic graph of joints with parent–child transform relationships
  - The root joint's world transform determines character placement in the [[Scene Graph]]
  - Authored in [[Character Rigging]] pipelines using tools such as Maya, Blender, or MotionBuilder
  - Bone orientations follow a bind pose; animation data stores deltas from this reference pose
- **Skinning**
  - Each vertex is bound to 1–4 joints with normalised blend weights (paint-weighted in rigging tools)
  - [[Linear Blend Skinning]] (LBS) is hardware-friendly but produces candy-wrapper artefacts at extreme twists
  - Dual-quaternion skinning eliminates volume loss artefacts; widely supported since the 2010s
  - Computed in [[Vertex Shader]] or [[GPU Compute]] passes using the joint palette (array of bone matrices)
- **Animation Clips**
  - Store joint rotation (and optionally translation and scale) curves at discrete keyframes
  - Runtime interpolation (slerp for quaternions) between keyframes recovers smooth motion
  - Imported from [[Motion Capture]] data or hand-authored in digital content creation (DCC) tools
  - Exported in [[glTF (3D File Format)]] or proprietary engine formats
- **Animation State Machine**
  - Selects, blends, and layers clips based on gameplay events, velocity, and physics contacts
  - [[Blend Tree]] nodes handle smooth directional or additive blending (e.g., locomotion layers)
  - [[Animation Controller]] logic drives state transitions; closely tied to game AI and physics queries
- **[[Inverse Kinematics]]**
  - Constrains end-effectors (hands, feet) to world-space contact points at runtime
  - Two-bone analytic IK (legs, arms) and iterative FABRIK solvers are common in engines
  - Enables procedural foot-planting on uneven terrain without per-surface authored clips

### Applications / Use Cases

- **Video Games** — characters, creatures, vehicles with articulated parts; real-time locomotion, combat, and cinematic sequences; supported natively by Unreal Engine, Unity, Godot, and O3DE
- **Virtual Reality & XR** — full-body [[Avatar Animation]] in social VR platforms (VRChat, Rec Room, Meta Avatars); hand and body tracking retargeted onto skeletal rigs from IMU or camera-based [[Pose Estimation]]
- **Film Visual Effects** — digital doubles and creature animation (driven by [[Motion Capture]]) composited with live-action footage; pipeline integration via USD and Alembic interchange
- **[[Virtual Production]]** — real-time motion-captured performers driving skeletal avatars on LED-wall virtual sets for live broadcast and on-set decision-making
- **Social Metaverse Platforms** — interoperable avatar rigs (e.g., VRM standard) allow skeletal assets to move between platforms with consistent [[Animation Retargeting]]
- **Healthcare & Biomechanics** — [[Biomechanical Simulation]] of gait, rehabilitation monitoring, surgical planning using skeletal models driven by clinical motion capture
- **Industrial Digital Twins** — [[Digital Twin]] ergonomic analysis of human worker postures; safety simulation for factory-floor planning
- **Broadcast & Sports Analytics** — skeleton extraction from video for performance analysis and augmented-reality overlays

### Mechanisms

- **Forward Kinematics (FK)** — each joint's world transform is computed by concatenating parent transforms down the hierarchy; intuitive for animators who rotate joints manually
- **[[Inverse Kinematics]]** — given a desired end-effector world position, compute the joint angles required; runtime IK solvers include CCD (Cyclic Coordinate Descent), FABRIK, and Jacobian-based methods
- **[[Motion Capture]] Pipeline** — optical marker or inertial sensor data is cleaned, retargeted via [[Animation Retargeting]] to match rig proportions, and imported as animation clips
- **GPU Skinning** — joint palette uploaded to GPU; vertex shader fetches up to 4 joint matrices weighted by blend weights; result is the deformed clip-space vertex position
- **Additive & Layered Animation** — additive clips (e.g., breathing, aim offset) are blended on top of base locomotion without full-body re-authoring
- **[[Neural Motion Synthesis]]** — learned models (e.g., motion VAEs, diffusion-based motion generators) synthesise novel animation clips or reactive motions from high-level goal inputs, augmenting or replacing hand-authored clips for locomotion and crowd simulation

### Standards & Context

- **glTF 2.0** — Khronos Group standard; the `animations` array with `KHR_animation_pointer` extension is the dominant interchange format for web, XR, and real-time skeletal animation data
- **VRM** — open standard built on glTF for humanoid VR avatars; defines a standardised humanoid bone mapping enabling cross-platform skeletal retargeting in social VR
- **BVH (Biovision Hierarchy)** — legacy motion capture file format; joint hierarchy with Euler-angle rotation channels; still widely supported in DCC tools
- **USD (Universal Scene Description)** — Pixar/Apple standard for complex scene interchange in film VFX pipelines; includes skeletal animation via UsdSkel schema
- **OpenXR** — Khronos standard for XR runtime interaction; body tracking extensions (XR_EXT_hand_tracking, XR_HTCX_vive_tracker_interaction) feed skeletal rigs directly
- **IEEE VR / ACM SIGGRAPH** — primary venues for advances in real-time skinning, physics-based character animation, and neural motion synthesis research

### Provenance

