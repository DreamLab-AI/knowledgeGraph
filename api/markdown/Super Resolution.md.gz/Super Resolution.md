Super-Resolution is the process of enhancing the resolution and quality of low-resolution images by predicting and synthesising high-frequency details using deep learning models.

### Semantic Classification

### Content

- Super-Resolution is the process of enhancing the resolution and quality of low-resolution images by predicting and synthesising high-frequency details using deep learning models. Single image super-resolution (SISR) networks (SRCNN, ESRGAN, Real-ESRGAN) reconstruct plausible high-resolution images from degraded inputs, enabling applications in medical imaging enhancement, satellite imagery analysis, and consumer photo enhancement.

#### Computer & Video Games

- Computer & Video games are a huge global business, exponential globalgrowth over the last 30 years has seen this grow to a point where it haseclipsed both the [global movie and North American sportsindustries](https://www.businessinsider.com/video-game-industry-revenues-exceed-sports-and-film-combined-idc-2020-12?r=US&IR=T)combined.
- A global industry with revenues over £120b, [with asciitilde half thepeople on the planet](https://www.wepc.com/news/video-game-statistics/)playing some form of games in 2021.
- As the games industry has evolved and matured over the last 40 years,secondary markets have emerged, most notably the ‘second hand’ gamesresale market. The rise of ‘retro’ gaming, has demonstrated the secondhand market is a lucrative one for private resellers, an unopened copyof Super Mario Bros for the Nintendo Entertainment System [recentlyselling for£1.5M](https://www.nytimes.com/2021/08/06/business/super-mario-bros-sale-record.html)to the extent the market has seen [speculators looking to cashin](https://www.businessinsider.com/retro-gaming-market-being-overtaken-by-speculators-2021-9?r=US&IR=T)on the huge global interest in retro/second hand games.
- Despite publishers and developers increasingly moving to non-physicaldigital only’ games, the demand for used games remains incredibly high.
- Whilst some retailers have adapted their business models to includereselling of retro/second hand games, the vast majority ofpublisher/developers/retailers aren’t able to directly benefit from theemerging retro/second hand games market. The potential of *video gamesas NFT’s* presents a huge opportunity for publishers, developers andplayers alike, offering the following advantages:

#### Computer & Video Games

- Computer & Video games are a huge global business, exponential globalgrowth over the last 30 years has seen this grow to a point where it haseclipsed both the [global movie and North American sportsindustries](https://www.businessinsider.com/video-game-industry-revenues-exceed-sports-and-film-combined-idc-2020-12?r=US&IR=T)combined.
- A global industry with revenues over £120b, [with asciitilde half thepeople on the planet](https://www.wepc.com/news/video-game-statistics/)playing some form of games in 2021.
- As the games industry has evolved and matured over the last 40 years,secondary markets have emerged, most notably the ‘second hand’ gamesresale market. The rise of ‘retro’ gaming, has demonstrated the secondhand market is a lucrative one for private resellers, an unopened copyof Super Mario Bros for the Nintendo Entertainment System [recentlyselling for£1.5M](https://www.nytimes.com/2021/08/06/business/super-mario-bros-sale-record.html)to the extent the market has seen [speculators looking to cashin](https://www.businessinsider.com/retro-gaming-market-being-overtaken-by-speculators-2021-9?r=US&IR=T)on the huge global interest in retro/second hand games.
- Despite publishers and developers increasingly moving to non-physicaldigital only’ games, the demand for used games remains incredibly high.
- Whilst some retailers have adapted their business models to includereselling of retro/second hand games, the vast majority ofpublisher/developers/retailers aren’t able to directly benefit from theemerging retro/second hand games market. The potential of *video gamesas NFT’s* presents a huge opportunity for publishers, developers andplayers alike, offering the following advantages:

### [LATTE3D](https://research.nvidia.com/labs/toronto-ai/LATTE3D/) - * LATTE3D is a novel method for generating 3D shapes represented as signed distance functions (SDFs) using a latent space.

- The learned latent space facilitates applications like shape interpolation, analogy creation, and shape completion, offering a flexible framework for 3D content creation.
- The system shows promise for applications in [[computer vision]], game development, and design, offering a controllable way to generate varied 3D assets.
- The method's reliance on signed distance functions (SDFs) allows for direct use in rendering pipelines and other geometric processing tasks.

  <iframe src="https://research.nvidia.com/labs/toronto-ai/LATTE3D/" style="width: 100%; height: 600px"></iframe>

### Existential Threat

- A superintelligent AI, in pursuing its programmed goals, could develop destructive methods that have unforeseen and devastating consequences for humanity.
- [Safe Superintelligence Inc.](https://ssi.inc/)

## Timelines and Projections

- The timeline for the arrival of ASI is uncertain, with some experts predicting it could happen in less than a decade, while others believe it is much further off.
- [Microsoft president says no chance of super-intelligent AI soon](https://www.reuters.com/technology/microsoft-president-says-no-chance-superintelligent-ai-soon-2023-11-30/)
- [Nick Bostrom: superintelligence could happen in timelines as short as a year](https://twitter.com/tsarnick/status/1784378045069217960)

## Timelines and Projections

- The timeline for the arrival of ASI is uncertain, with some experts predicting it could happen in less than a decade, while others believe it is much further off.
- [Microsoft president says no chance of super-intelligent AI soon](https://www.reuters.com/technology/microsoft-president-says-no-chance-superintelligent-ai-soon-2023-11-30/)
- [Nick Bostrom: superintelligence could happen in timelines as short as a year](https://twitter.com/tsarnick/status/1784378045069217960)
  ## Core Characteristics
- **Resolution Enhancement**: Upscaling to higher spatial resolution
- **Detail Synthesis**: Generation of plausible high-frequency content
- **Perceptual Quality**: Visually realistic detail enhancement
- **Real-Time Processing**: Efficient networks for video super-resolution
- **Multi-Scale Learning**: Progressive upsampling architectures
  ## Relationships
- **Subclass**: Computer Vision, Image Enhancement
- **Related**: Image Generation, Convolutional Neural Network
- **Models**: SRCNN, SRGAN, ESRGAN, Real-ESRGAN, SwinIR
- **Applications**: Medical Imaging, Satellite Imagery, Photo Enhancement
  ## Key Literature
  1. Dong, C., et al. (2014). "Learning a deep convolutional network for image super-resolution." *ECCV*, 184-199.
  2. Ledig, C., et al. (2017). "Photo-realistic single image super-resolution using a generative adversarial network." *CVPR*, 4681-4690.
  3. Wang, X., et al. (2021). "Real-ESRGAN: Training real-world blind super-resolution with pure synthetic data." *ICCV Workshops*.
  ## See Also
- [[Image Generation]]
- [[Convolutional Neural Network]]
- [[Computer Vision]]
  ## Core Characteristics
- **Resolution Enhancement**: Upscaling to higher spatial resolution
- **Detail Synthesis**: Generation of plausible high-frequency content
- **Perceptual Quality**: Visually realistic detail enhancement
- **Real-Time Processing**: Efficient networks for video super-resolution
- **Multi-Scale Learning**: Progressive upsampling architectures
  ## Relationships
- **Subclass**: Computer Vision, Image Enhancement
- **Related**: Image Generation, Convolutional Neural Network
- **Models**: SRCNN, SRGAN, ESRGAN, Real-ESRGAN, SwinIR
- **Applications**: Medical Imaging, Satellite Imagery, Photo Enhancement
  ## Key Literature
  1. Dong, C., et al. (2014). "Learning a deep convolutional network for image super-resolution." *ECCV*, 184-199.
  2. Ledig, C., et al. (2017). "Photo-realistic single image super-resolution using a generative adversarial network." *CVPR*, 4681-4690.
  3. Wang, X., et al. (2021). "Real-ESRGAN: Training real-world blind super-resolution with pure synthetic data." *ICCV Workshops*.
  ## See Also
- [[Image Generation]]
- [[Convolutional Neural Network]]
- [[Computer Vision]]

### Provenance

