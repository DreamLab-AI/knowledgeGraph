Supply chain organisations are the persons and business organisations that take part in a supply chain. The Industrial Ontologies Foundry calls such a party a supply chain agent and defines it as a “person or business organization who supplies material products or commercial services to other agents in a supply chain”, with a manufacturer in a supply chain and a carrier in a supply chain as examples.[^1]

## How the sources group organisations

None of the sources opened here gives a closed list of the kinds of organisation in a supply chain, so the grouping used in this vault is an editorial choice. Each source describes particular roles instead. The European Commission, for example, notes that enterprises often outsource logistics activities to third party logistics providers, and that express, courier and parcel services are key to the e-commerce delivery business.[^2] The UK tax and customs authority lists freight forwarders, customs agents or brokers and express operators as the kinds of business that can deal with customs on an importer's behalf.[^3]

Statistical classification groups firms by activity instead. The United Nations ISIC separates wholesale, which it defines as resale without transformation to retailers, business users or other wholesalers, from retailing, which it defines as resale mainly to the general public for personal or household consumption or use.[^4] It also treats an outsourcing contractor as a separate unit from the principal that hires it.[^4]

One organisation can hold more than one role. The IOF defines an integrated carrier business organisation as one created to provide different types of transportation and freight forwarding services, and gives FedEx, UPS and DHL as examples.[^1]

## Roles in this vault

Pages under this hub are roles, and named firms sit beneath the role they hold as classes, never as individuals. The roles covered are [[Supplier]], [[Contract Manufacturer]], [[Product Distributor]], [[Wholesaler]], [[Retailer]], [[Logistics Service Provider]] with its kinds ([[Third-Party Logistics Provider]], [[Fourth-Party Logistics Provider]], [[Freight Forwarder]], [[Customs Broker]], [[Freight Carrier]], [[Ocean Carrier]] and [[Parcel Carrier]]), [[Trade Body]] and [[Intergovernmental Trade Organisation]]. For rule-setting bodies see also [[Standards Body]] and [[Standards Organization]].

## What the sources do not establish

Sources describe roles by what an organisation does in relation to others, and they do not agree on a single taxonomy. The IOF ontology and the ISIC place the same kind of business in different places, as the page on [[Product Distributor]] explains.[^1][^4]

[^1]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^2]: European Commission, Directorate-General for Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en
[^3]: HM Revenue and Customs on GOV.UK, “Get someone to deal with customs for you”. https://www.gov.uk/guidance/appoint-someone-to-deal-with-customs-on-your-behalf
[^4]: United Nations Statistics Division, “International Standard Industrial Classification of All Economic Activities (ISIC), Revision 4”. https://unstats.un.org/unsd/classifications/Econ/Download/In%20Text/ISIC_Rev_4_publication_English.pdf

