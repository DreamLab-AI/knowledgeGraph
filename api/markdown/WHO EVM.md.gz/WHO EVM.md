Effective Vaccine Management (EVM) is a World Health Organization initiative and assessment tool for vaccine supply chains, built around nine global criteria.[^1][^2]

The WHO background paper from 2010 says EVM's scope and focus are based on nine global criteria, each of which must be validated against records kept over a recent 12 month period.[^1] The criteria include pre-shipment and arrival procedures that bring every shipment to the receiving store in satisfactory condition with correct paperwork, storage and distribution of all vaccines and diluents within WHO-recommended temperature ranges, and satisfactory information systems and supportive management functions.[^1] The paper calls EVM first and foremost a quality management tool that combines a structured assessment with supplementary guidance materials.[^1]

## Scoring

WHO's 2021 data analysis says an area of vaccine management is considered effective if its criterion score is greater than or equal to 80 percent.[^2] A newer assessment package, EVM2, was released in 2019, and the analysis covers EVM1 assessments only, the last of which was in 2020.[^2] In those data, the median scores were above 80 percent at all levels of the supply chain for criteria E3 and E8, the strongest, and below 80 percent at all levels for criteria E2, E7 and E9, the weakest.[^2]

## Use in practice

Osei, Ibrahim and Amenuvegbe assessed six vaccine stores in the Tolon District of northern Ghana using WHO tools. They assessed five of the nine criteria against the 80 percent target and report that none of the facilities met the WHO benchmark of 80% for all but one criteria assessed.[^3]

## Scope and distinctions

EVM scores sites against a threshold, so it is related to maturity assessment but does not use staged levels in the sources opened. See [[Supply Chain Maturity Model]], [[Cold Chain Monitoring]] and [[Standards Body]].[^2]

## What the sources do not establish

The WHO documents are slides and a background paper, so criterion definitions beyond the three quoted were not excerpted. The sources do not show how assessment results have changed investment, and the EVM2 package and portal were not opened. The Ghana study is one district and applied a subset of the criteria.[^1][^2][^3]

[^1]: World Health Organization, “Effective Vaccine Management Initiative Background”, version 1.7, September 2010. https://cdn.who.int/media/docs/default-source/immunization/supply-chain/evm-background.pdf?sfvrsn=cb12cda0_3
[^2]: World Health Organization, “Effective Vaccine Management (EVM) Global Data Analysis 2009-2020”, update of the WHO EVM1 database, July 2021. https://cdn.who.int/media/docs/default-source/immunization/supply-chain/evm-global-data-analysis-2009-2020.pdf
[^3]: Eric Osei, Mohammed Ibrahim and Gregory Kofi Amenuvegbe, Advances in Preventive Medicine, 2019, “Effective Vaccine Management: The Case of a Rural District in Ghana”. https://www.ebi.ac.uk/europepmc/webservices/rest/PMC6815627/fullTextXML

