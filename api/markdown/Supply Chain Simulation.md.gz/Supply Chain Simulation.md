Supply chain simulation is the use of simulation models to investigate supply chain problems, and the choice of simulation type depends on the managerial question to be answered.[^1][^2]

Kleijnen's survey reviews four types of simulation in supply chain management: spreadsheet simulation, system dynamics, discrete-event simulation and business games. He says which type should be applied depends on the type of managerial question, and that simulation is important because it can support quantifying the benefits of supply chain management.[^1] The survey also summarises sensitivity analysis, which yields a shortlist of the truly important factors in large models, and illustrates both analyses with a case study of a supply chain in the mobile communications industry in Sweden.[^1]

Owen, Albores, Greasley and Love write that the supply chain can be a source of competitive advantage and that simulation is an effective tool for investigating its problems. They name three main approaches, system dynamics, discrete event simulation and agent based modelling.[^2] A sample of the literature suggests that system dynamics and agent based modelling have been used for strategic and planning problems and discrete event simulation mainly for planning and operational problems, although a theoretical review suggests the scope of each technique is much wider.[^2] They add that the choice of approach appears to owe much to the background of the modeller and the techniques they know best.[^2]

## Scope and distinctions

Both sources list different sets of approaches, and the page does not equate them.[^1][^2] See [[Supply Chain Optimisation]], [[System Dynamics]], [[Agent-Based Modelling]] and [[Simulation]].

## What the sources do not establish

The Tilburg record is an abstract, and neither source reports accuracy or cost benefits of simulation across supply chains.[^1][^2]

[^1]: J. P. C. Kleijnen, Tilburg University CentER Discussion Paper 2003-103 (research portal record with abstract), “Supply Chain Simulation: A Survey”. https://research.tilburguniversity.edu/en/publications/supply-chain-simulation-a-survey/
[^2]: Chris Owen, Pavel Albores, Andrew Greasley and Doug Love, Operational Research Society Simulation Workshop 2010 (Aston University repository), “Simulation in the Supply Chain Context: Matching the Simulation Tool to the Problem”. https://publications.aston.ac.uk/id/eprint/20732/1/SW10.11.11.Owen.Albores.Greasley.Love.pdf

