Taxonomy category root for Telepresence within Distributed Collaboration. The concept itself is described at [[Telepresence]], which sits under this category; the category exists so the published graph can group its members.

