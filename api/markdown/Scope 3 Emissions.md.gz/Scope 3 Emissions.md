Scope 3 emissions are all indirect greenhouse gas emissions in a company's value chain other than those from purchased energy, and they arise from activities the reporting company does not own or control.[^1]

The GHG Protocol Corporate Standard classifies a company's direct and indirect emissions into three scopes. Scope 1 covers direct emissions from owned or controlled sources and scope 2 covers indirect emissions from the generation of purchased energy consumed by the reporting company.[^1] Scope 3 covers all other indirect emissions in the value chain.[^1] The Scope 3 Standard divides them by the reporting company's financial transactions: upstream emissions are indirect emissions related to purchased or acquired goods and services, and downstream emissions are indirect emissions related to sold goods and services.[^1]

## Reporting and importance

Under the Corporate Standard companies must report all scope 1 and scope 2 emissions, while reporting scope 3 is optional.[^1] The Scope 3 Standard says scope 3 emissions can represent the largest source of emissions for companies and present the most significant opportunities to influence emission reductions.[^1] The Science Based Targets initiative, which is a separate body, says that for most companies supply chain-related emissions represent a substantial portion of their scope 3 emissions.[^2]

## Measurement difficulty

Because the emissions come from activities outside the company's ownership or control, the standard says companies are likely to face additional challenges in collecting data and ensuring data quality.[^1] Freight is one place where this arises: the GHG Protocol notes that the Smart Freight Centre's GLEC Framework is a guide for shippers, carriers and logistics service providers on how to report emissions from logistics operations, meant to be used in conjunction with the Corporate Standard.[^3]

## Scope and limits

Scope 3 is the subject of [[Supply Chain Environmental Accounting]] and the target of [[Supply Chain Decarbonisation]]. Later revisions of the standard were not checked. The SBTi and GHG Protocol sources are guidance by standard-setting bodies, and the page makes no claims about the size of scope 3 emissions in any sector.

[^1]: World Resources Institute and World Business Council for Sustainable Development, GHG Protocol, “Corporate Value Chain (Scope 3) Accounting and Reporting Standard”. https://ghgprotocol.org/sites/default/files/standards/Corporate-Value-Chain-Accounting-Reporing-Standard_041613_2.pdf
[^2]: Science Based Targets initiative (developed by WWF), version 1.1, July 2025, “Engaging Supply Chains on the Decarbonization Journey: A Guide to Developing and Achieving Scope 3 Supplier Engagement Targets”. https://sciencebasedtargets.org/resources/files/Supplier-Engagement-Guidance.pdf
[^3]: GHG Protocol, blog post of 30 October 2019, “GLEC Framework: a universal method for logistics emissions accounting”. https://ghgprotocol.org/blog/glec-framework-universal-method-logistics-emissions-accounting

