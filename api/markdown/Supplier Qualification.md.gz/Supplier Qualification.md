Supplier qualification is the documented process of establishing that a supplier is able to meet the buyer's requirements before it is approved.[^1][^2][^3]

UNCITRAL defines pre-qualification as the procedure to identify, prior to solicitation, suppliers or contractors that are qualified, and sets criteria that include professional and technical competence, financial resources, equipment, managerial capability, reliability, experience and personnel to perform the contract.[^1]

In regulated manufacturing the practice is stricter. EU good manufacturing practice (EudraLex Volume 4, Part I, Chapter 5) says the selection, qualification, approval and maintenance of suppliers of starting materials, together with purchase and acceptance, should be documented as part of the pharmaceutical quality system, with supervision proportionate to the risks of the material, taking account of its source, manufacturing process, supply chain complexity and final use, and with supporting evidence for each approval maintained.[^2] It adds that quality requirements agreed with suppliers, covering production, testing, handling, labelling, packaging, complaints, recalls and rejection procedures, should be documented in a formal quality agreement or specification.[^2] The ICH Q7 guidance for active pharmaceutical ingredients, published by the US Food and Drug Administration, says supplier approval should include an evaluation giving adequate evidence, for example past quality history, that the manufacturer can consistently provide material meeting specifications.[^3]

## Scope and distinctions

The UK Sourcing Playbook sets technical and professional ability, covering skills, efficiency, experience and reliability, among the matters assessed when selecting bidders.[^4] See [[Supplier Selection]], [[Supplier Management]] and [[Pharmaceutical Supply Chain]].

## What the sources do not establish

ISO 9001 clause 8.4 and ISO 20400 are cite-only and were not opened, so the page does not describe them. No source gives a general qualification checklist.[^2][^3]

[^1]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf
[^2]: European Commission, EudraLex Volume 4, EU Guidelines for Good Manufacturing Practice, Part I Chapter 5, “Chapter 5: Production”. https://health.ec.europa.eu/document/download/4a1fdb4f-6f6f-49c4-b264-8056e5bbe078_en?filename=chapter_5.pdf
[^3]: US Food and Drug Administration, ICH Q7 guidance for industry, “Q7 Good Manufacturing Practice Guidance for Active Pharmaceutical Ingredients”. https://www.fda.gov/files/drugs/published/Q7-Good-Manufacturing-Practice-Guidance-for-Active-Pharmaceutical-Ingredients-Guidance-for-Industry.pdf
[^4]: UK Cabinet Office, Crown copyright (Open Government Licence v3.0), June 2023, “The Sourcing Playbook: Government guidance on service delivery, including outsourcing, insourcing, mixed economy sourcing and contracting”. https://assets.publishing.service.gov.uk/media/64901fcc5f7bb700127fac5e/Sourcing_Playbook_Final.pdf

