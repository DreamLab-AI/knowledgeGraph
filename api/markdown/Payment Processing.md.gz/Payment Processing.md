Payment processing is the sequence of operations that authorise, capture, clear and settle a monetary transaction between a payer and a payee. It coordinates merchants, payment gateways, networks and settlement institutions to verify funds, manage risk and move value reliably. Modern payment processing spans card rails, digital wallets and blockchain-based settlement, increasingly emphasising speed, fraud detection and interoperability.

### Overview

- Payment Processing is situated within the [[Payment Network]] area of the blockchain domain.
- It connects a number of established concepts in the knowledge graph, anchoring edges that previously referenced it without a defining page.

### Key aspects

- Settlement (hasPart)
- Clearing (hasPart)
- Payment Gateway (hasPart)
- Payment Network (partOf)
- Payment Rail (uses)

### Mechanisms

- Operates through its relationships with [[Payment Network]] and [[Settlement]].
- Provides capabilities consumed by dependent and enabled classes listed under Relationships.

### Applications

- Supports [[Transaction]]
- Supports [[Digital Wallet]]
- Supports [[Financial Technology]]

### Provenance

