A decision engine is a software component that encapsulates decision logic—rules, models, policies, or heuristics—and evaluates inputs against that logic to produce actionable outputs such as approvals, classifications, recommendations, or routing choices. Decision engines decouple business logic from application code, enabling non-developers to modify decision policies without code deployments, and support auditability by providing traceable reasoning paths for each decision. They range from rule-based expert systems to ML model inference services to hybrid architectures combining both. The emergence of large language model reasoning cores has extended the decision engine concept to unstructured input spaces, enabling complex multi-step decisioning with natural language explanation traces.

### Semantic Classification

### Content

## Compositional Relationships (Components)
```
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:hasPart ai:RuleEvaluator))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:hasPart ai:ModelScorer))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:hasPart ai:ExplanationModule))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:hasPart ai:AuditTrail))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:hasPart ai:DecisionModelNotation))
SubClassOf(ai:HybridDecisionEngine
  ObjectSomeValuesFrom(ai:hasPart ai:RuleEngine))
SubClassOf(ai:HybridDecisionEngine
  ObjectSomeValuesFrom(ai:hasPart ai:MLInferenceService))
SubClassOf(ai:LLMDecisionEngine
  ObjectSomeValuesFrom(ai:hasPart ai:ChainOfThoughtReasoner))
```
## Dependency Relationships
```
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:requires ai:KnowledgeRepresentation))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:requires ai:AutomatedReasoning))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:requires ai:DataGovernance))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:requires ai:AccessControl))
SubClassOf(ai:MLDecisionEngine
  ObjectSomeValuesFrom(ai:requires ai:ModelServingRuntime))
SubClassOf(ai:RuleBasedDecisionEngine
  ObjectSomeValuesFrom(ai:requires ai:PolicyEngine))
SubClassOf(ai:RegulatedDecisionEngine
  ObjectSomeValuesFrom(ai:requires ai:AuditTrail))
SubClassOf(ai:LLMDecisionEngine
  ObjectSomeValuesFrom(ai:requires ai:LargeLanguageModel))
```
## Capability Relationships
```
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:enables ai:DecisionSupport))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:enables ai:AutomatedPlanning))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:enables ai:WorkflowAutomation))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:enables ai:AutomatedDecisionMaking))
SubClassOf(ai:RealTimeDecisionEngine
  ObjectSomeValuesFrom(ai:enables ai:FraudDetection))
SubClassOf(ai:ScoringDecisionEngine
  ObjectSomeValuesFrom(ai:enables ai:CreditScoring))
SubClassOf(ai:ExplainableDecisionEngine
  ObjectSomeValuesFrom(ai:enables ai:DecisionTransparency))
```
## Implementation Relationships
```
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:implements ai:DecisionIntelligence))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:implements ai:ExplainableAI))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:implements ai:DecisionTransparency))
SubClassOf(ai:CertifiedDecisionEngine
  ObjectSomeValuesFrom(ai:implements ai:Regulation))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:implements ai:DecisionModelNotation))
```
## Reduction Relationships
```
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:reducesTo ai:PolicyEngine))
SubClassOf(ai:HybridDecisionEngine
  ObjectSomeValuesFrom(ai:reducesTo ai:RuleEngine))
SubClassOf(ai:LLMDecisionEngine
  ObjectSomeValuesFrom(ai:reducesTo ai:InferenceEngine))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:reducesTo ai:BooleanFunction))
SubClassOf(ai:ProbabilisticDecisionEngine
  ObjectSomeValuesFrom(ai:reducesTo ai:ScoringFunction))
```
## Support Relationships
```
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:supports ai:Orchestration))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:supports ai:AgenticAI))
SubClassOf(ai:ExplainableDecisionEngine
  ObjectSomeValuesFrom(ai:supports ai:FairnessAuditing))
SubClassOf(ai:HybridDecisionEngine
  ObjectSomeValuesFrom(ai:supports ai:NaturalLanguageProcessing))
SubClassOf(ai:DecisionEngine
  ObjectSomeValuesFrom(ai:supports ai:CausalReasoning))
```

## About

Decision engines are software systems that separate the logic of what a decision is from the application code that invokes it. This decoupling—placing decision logic in an externally authored, version-controlled, independently deployable, and comprehensively auditable artefact—is the foundational architectural principle distinguishing decision engines from ad-hoc conditional logic embedded in application code. The concept emerged from the expert systems tradition of the 1970s and 1980s, where domain knowledge was encoded in explicit if-then production rules evaluated by a reasoning engine such as the RETE algorithm (Forgy, 1982). RETE provides efficient incremental pattern matching over a working memory of facts by compiling the rule network into a directed acyclic graph of alpha nodes (single-condition tests) and beta nodes (cross-fact joins), achieving O(RF) time complexity where R is the number of rules and F is the number of facts in working memory, compared to O(RF^k) for naive evaluation. RETE-based engines underpin modern BRMS products including Red Hat Drools (transferred to the Apache Software Foundation as Apache KIE in 2024) and commercial platforms IBM Operational Decision Manager and FICO Blaze Advisor.

The architecture has evolved through three distinct phases. In the first phase (1980s–2000s), rule-only systems deployed in expert system shells (MYCIN, OPS5, CLIPS) were characterised by manual knowledge engineering: domain experts were interviewed by knowledge engineers who translated expertise into explicit production rules. These systems worked well in narrow, well-defined domains (medical diagnosis, configuration checking) but struggled with rule base maintenance as complexity grew—an effect sometimes called the "knowledge acquisition bottleneck." The second phase (2000s–2020s) saw BRMS platforms democratise rule authoring via business-user interfaces and decision tables, enabling actuaries, underwriters, and compliance officers to author and modify rules through web-based policy management tools (IBM ODM's Decision Center, the Decisions.com low-code platform). Simultaneously, [[Machine Learning]] scoring models—logistic regression for credit risk, gradient boosting for fraud scoring—were integrated as sub-components within rule pipelines, creating the first hybrid architectures that combined the interpretability of explicit rules with the predictive power of statistical models. Credit decisioning became the canonical use case: rule engines enforced regulatory hard constraints (minimum income thresholds, maximum debt-to-income ratios, sanctions screening) while ML scorers estimated probability of default within the population that cleared the rule guardrails. The third phase (2022–present) introduces [[Large Language Model]] as reasoning cores capable of processing unstructured inputs—contract text, clinical notes, customer communications—decomposing complex multi-step decision problems, and producing explanations in natural language, extending the decision engine concept into domains previously inaccessible to structured automation.

The governance and regulatory dimensions of decision engines have grown in importance proportional to their deployment in high-stakes domains. GDPR Article 22 (applied since 2018) gives EU data subjects the right to human review of solely automated decisions that produce significant legal effects, including credit decisions, insurance pricing, employment screening, and benefits determinations. The UK Data (Use and Access) Act 2025, which received Royal Assent in June 2025, modifies but does not eliminate these protections under UK GDPR, creating somewhat more permissive rules for commercial automated decisions while maintaining protections for sensitive processing categories. The EU AI Act (2024), which began its risk-based implementation from February 2025, classifies automated credit scoring, employment screening, education access decisions, and law enforcement risk assessments as high-risk AI, imposing conformity assessment, transparency documentation, and mandatory human oversight mechanisms before deployment. The European Court of Justice's landmark ruling in March 2025 in Case C-203/22 (Dun & Bradstreet Austria) clarified that data subjects have a genuine right to explanation of automated decision logic—specifically to "meaningful information about the logic involved"—in a ruling that directly shapes how decision engines must be designed and documented in regulated domains.

## Components / Architecture

A production decision engine comprises the following components integrated into a coherent runtime system:

- **Decision logic repository**: The externally managed store of decision logic artefacts—rule sets (in DRL, Drools Rule Language; DMN, Decision Model and Notation; or Rego for Open Policy Agent), ML model files (ONNX, PMML, POJO serialisations), or policy documents—versioned with semantic versioning and deployed independently of the calling application through a BRMS deployment pipeline. Separation of the logic repository from the runtime engine is the architectural prerequisite for non-developer policy editing.
- **Rule evaluator / inference engine**: The runtime that applies rule logic to input facts. For rule-based engines, this is typically a RETE or RETE-II network implementation (Drools/KIE, Easy Rules, Camunda DMN) that compiles the rule set into a pattern-matching network and evaluates it against a working memory populated with request facts. Conflict resolution—determining which rule fires when multiple rules' conditions are satisfied simultaneously—uses priority ordering, specificity (most-specific-first), or recency (most-recently-added-fact-first) strategies. For logic-programming systems (SWI-Prolog, Clingo), backward-chaining resolution applies.
- **ML model scorer**: An embedded or remotely called inference service that applies a trained statistical model to feature vectors derived from the input, returning a score, probability distribution, or classification. Integration with [[Model Serving Runtime]] layers (TensorFlow Serving, TorchServe, ONNX Runtime, Triton Inference Server) via REST or gRPC is standard in hybrid architectures. Model versioning must be coordinated with rule set versioning to maintain the correctness of hybrid decision logic that references model outputs in rule conditions.
- **Feature engineering pipeline**: Transforms raw input fields into model-ready feature vectors—encoding categorical variables (one-hot, target encoding, ordinal), computing derived ratios and aggregates (debt-to-income, velocity counts over time windows), normalising numeric ranges, and imputing missing values. The [[Feature Engineering]] pipeline is a critical governance surface: feature definitions must be stable and documented, as undocumented changes can silently alter model behaviour without triggering the model re-approval process.
- **Explanation module**: Generates a human-readable account of each decision, citing the specific rules that fired, the [[Audit Trail]] of working memory changes, and/or the feature importance scores from the ML component. SHAP (Shapley Additive Explanations, Lundberg & Lee, 2017) values provide mathematically rigorous attribution of model predictions to input features, satisfying efficiency, symmetry, and dummy player axioms from cooperative game theory. LIME (Local Interpretable Model-agnostic Explanations, Ribeiro et al., 2016) provides locally faithful approximations of any black-box model. Rule-based engines produce natural explanations by logging the activated rule chain and the specific facts that satisfied each condition.
- **Audit trail and immutable decision log**: An append-only log capturing the input context hash, decision output, logic version identifier, timestamps, and system identity for every decision made. In regulated domains, audit logs must be retained for defined periods (typically 5–7 years in financial services under MiFID II and FCA requirements), stored in tamper-evident formats, and made available for regulatory inspection or legal challenge. Audit trail architecture must support reconstruction of the full decision context—what information was available to the engine at decision time—not merely the output.
- **Decision Model Notation (DMN) interpreter**: The OMG standard (v1.5, 2023) for representing decision logic in a business-readable tabular format (decision tables with hit policies: UNIQUE, ANY, FIRST, PRIORITY, COLLECT) with supporting decision requirement diagrams showing information flow between sub-decisions. DMN provides a business-level abstraction over rule logic that enables non-technical stakeholders to validate and authorise decision logic without reading rule language syntax. Drools and most commercial BRMS platforms support DMN at Conformance Level 3.
- **API and integration layer**: Decision engines are exposed as microservices via REST or gRPC [[API Gateway]] endpoints, accepting structured JSON/Protocol Buffer input payloads and returning structured decision responses with output payload, explanation, and audit reference identifier. This enables integration with any calling application regardless of language or platform, while keeping decision logic isolated. Asynchronous invocation patterns (message queues, event streaming via Kafka) support high-volume decisioning workloads decoupled from request-response latency.
- **Monitoring and drift detection telemetry**: Runtime telemetry tracking decision distribution (proportion of approvals, score histograms), input feature distribution (mean, variance, quantile shifts), model performance metrics (if labels are available through feedback loops), and rule activation frequency. When distributional shift exceeds threshold—a model's calibration degrades as its training population diverges from the current request population—alerts trigger manual model review or automated recalibration. [[Model Monitoring]] is increasingly integrated into [[MLOps]] platforms (Evidently AI, WhyLogs, Arize) that provide continuous evaluation dashboards.

  ## Use Cases / Major Families

  Decision engines are deployed across a wide range of sectors and decision types, differentiated by latency requirements, explanation depth, regulatory burden, and decision complexity:

  **Financial services — credit decisioning**: Automated loan origination and credit limit assignment are the canonical BRMS use cases, combining regulatory rule evaluation (income verification, sanctions screening, identity fraud checks) with statistical credit risk models (probability of default, loss given default, exposure at default). Real-time decisioning at sub-second latency is standard for consumer credit; complex commercial lending may allow seconds to minutes. Banks including HSBC, Barclays, and Lloyds Banking Group deploy decision engines for millions of daily retail credit decisions; FICO's Blaze Advisor and IBM's Operational Decision Manager hold significant market share in UK banking.

  **Fraud detection and identity verification**: Real-time transaction scoring combining pattern-matching rule networks (velocity rules, geographic anomaly rules) with ML anomaly detection models (isolation forests, autoencoders, gradient boosted trees). Decision latency requirements are stringent—5 to 50 milliseconds per transaction—because the decision must complete before transaction authorisation timeout. Specialised platforms including Feedzai, FICO Falcon, and Kount handle billions of transactions monthly.

  **Insurance underwriting and claims processing**: Rules encoding underwriting guidelines (acceptable risk factors, exclusions, pricing adjustments) combined with actuarial risk models producing expected loss predictions. Straight-through processing—automated acceptance or rejection without manual review—for standard consumer policies is now routine. Claims processing decision engines apply eligibility rules, fraud scoring, and settlement calculation models to reduce manual adjuster involvement for straightforward claims.

  **Healthcare clinical decision support**: Rules encoding clinical guidelines (NICE clinical guidance in the UK, clinical pathways for sepsis, VTE prevention, medication dosing) combined with patient risk stratification models (NEWS2 for deterioration, Charlson Comorbidity Index). NHS deployments require compliance with the Clinical Decision Support Software classification under the MHRA's AI as a Medical Device framework. Epic, Cerner, and homegrown NHS trust systems incorporate clinical decision engines into electronic patient records.

  **Regulatory compliance and anti-money laundering**: Transaction monitoring rule engines screening for suspicious patterns (structuring, layering, unusual geographic patterns) combined with customer risk scoring models. The EU's AMLD6 directive and UK Proceeds of Crime Act 2002 impose mandatory screening and reporting obligations that decision engines must implement with complete [[Audit Trail]] documentation.

  **Marketing technology and real-time personalisation**: Offer decisioning engines selecting the optimal product, message, creative, or channel to present to a customer across web, email, and mobile touchpoints based on behavioural data, CRM attributes, and ML propensity model scores. Latency requirements of sub-100 millisecond for real-time website personalisation contrast with higher-latency batch decisioning for email campaign selection.

  **Supply chain and operational logistics**: Routing, warehouse slotting, inventory replenishment trigger, and priority allocation decisions combining constraint-satisfaction optimisation solvers with demand forecasting models and exception-handling rules. These decisions must account for real-time inventory state, carrier capacity, and customer SLA requirements.

  **LLM-powered agentic decisioning (emerging)**: Multi-step complex decisions over unstructured inputs—contract review for risk clauses, clinical note triage, regulatory enquiry routing, insurance claim narrative analysis—where [[Large Language Model]] act as decision reasoning cores. [[Chain of Thought]] reasoning provides the explanation trace; tool-calling integrations with structured data systems ground LLM reasoning in verifiable facts. Frameworks including LangGraph, Microsoft AutoGen, and Anthropic's tool-use API support this architecture. Maintaining audit trail integrity when the decision logic is a large language model's inference is an unsolved governance problem as of 2026.

  ## Formal Analysis

  The decision engine can be formalised as a computable function D: I × L → O × E, where I is the input space of contextual attributes (a finite-dimensional feature vector or an unstructured document in the case of LLM-based engines), L is the decision logic space (a rule set, a model artefact, or a composed hybrid), O is the output space (a decision outcome, a score, a distribution over outcomes), and E is the explanation space (a rule activation trace, a feature attribution vector, or a natural language chain-of-thought). The core auditability requirement corresponds to the existence of a faithful, human-intelligible projection π: E → NL mapping the explanation to natural language that correctly characterises the relationship between D(i, l) and o.

  Rule-based engines are formally characterised as production systems (Post, 1943): a set of condition-action rule pairs {(c_k, a_k)}_{k=1}^{K} evaluated against a working memory W representing the current fact base. Each condition c_k is a predicate over W (a conjunction of attribute-value constraints) and each action a_k either modifies W, asserts a new fact, or produces an output. The RETE algorithm (Forgy, 1982) computes the conflict set CS = {k : W ⊨ c_k} using a compiled network of shared test nodes, achieving incremental update time proportional to the number of facts affected by the last working memory change rather than requiring full re-evaluation of all rules on each update cycle. Conflict resolution selects one rule from CS to fire using priority ordering (highest-priority-first), specificity (most-conditions-first), or recency (most-recently-matched-fact-first) strategies.

  ML scoring components in hybrid decision engines are typically trained discriminative models f_θ: X → [0,1] producing calibrated probability estimates, where calibration means that P(Y=1 | f_θ(x) = p) ≈ p across the support of the deployment distribution. [[Bayesian Inference]] formalisations treat the decision as computing the posterior P(D | X, L) = P(X | D, L) P(D | L) / P(X | L), where D is the decision, X is the input, and L is the prior encoded in the rule set. In credit risk, D corresponds to default/non-default, X is the credit application features, and the prior P(D | L) encodes institutional risk appetite expressed through rule constraints.

  Hybrid architectures introduce a composition operator ⊕: D_rule ⊕ D_model → D_hybrid combining rule evaluation and model scoring, typically as a sequential pipeline (rule pre-filter → model scorer → rule post-filter with override capabilities). The formal challenge in hybrid systems is maintaining an integrated explanability guarantee across the composition: the explanation of D_hybrid must coherently account for both which rules fired (and why their conditions were met given the input facts) and which model features were most influential (SHAP attributions), presenting a unified narrative that satisfies the EU AI Act's Article 86 requirement for "clear and meaningful explanations of the role of the AI system in the decision-making procedure."

  The complexity of [[Constraint Satisfaction]] problems embedded in operational planning decision engines is typically NP-complete (vehicle routing is a variant of the Travelling Salesman Problem; warehouse assignment is a variant of bin packing). Practical systems use constraint programming solvers (Google OR-Tools, CPLEX, Gurobi) with time-bounded search heuristics (branch-and-bound, local search, genetic algorithms) to find good-enough solutions within operational time budgets, making the optimality guarantee probabilistic rather than absolute.

  ## Academic Context

  Decision engines draw on several distinct research traditions spanning artificial intelligence, decision theory, operations research, and software engineering:

- **Expert systems and knowledge engineering** (McCarthy, Minsky at MIT; Feigenbaum at Stanford; Shortliffe at Stanford with MYCIN; McDermott at CMU with XCON/R1): the original rule-based AI systems providing the conceptual foundation for modern rule engines. The MYCIN system (1972–1976) for antibiotic selection demonstrated that expert-level rule-based reasoning was achievable in narrow domains; XCON configured VAX computer systems using ~4,500 rules, saving Digital Equipment Corporation an estimated $40 million per year.
- **Production systems theory** (Forgy, 1982; Newell & Simon's production system cognitive model): the RETE algorithm as the efficient pattern-matching foundation for rule engines, and the broader theory of production systems as a computational model of cognition.
- **Decision theory** (von Neumann & Morgenstern, 1944; Savage, 1954; Kahneman & Tversky, 1979 Prospect Theory): formal normative frameworks for rational choice under uncertainty, and their descriptive critiques, underpinning both the design of probabilistic decision engines and the study of human decision-making biases that automated systems aim to correct or avoid.
- **Decision Model and Notation (DMN)** (OMG, 2015–2023, v1.5): the standard modelling language for business decision logic, providing decision requirement diagrams and decision tables as business-readable representations.
- **Explainable AI** (DARPA XAI programme, 2016–2021; Ribeiro et al. LIME, 2016; Lundberg & Lee SHAP, 2017; Doshi-Velez & Kim, 2017): techniques for post-hoc and inherent model explanation applicable to ML-based decision engines, providing the technical implementation of regulatory explainability requirements.
- **Neuro-symbolic AI** (Garnelo & Shanahan, 2019; Marcus, 2020; Mao et al. NS-VQA, 2019): hybrid architectures integrating neural pattern recognition with symbolic rule reasoning, providing the academic foundation for hybrid decision engines that combine ML scoring with rule-based guardrails.
- **Agentic LLM reasoning** (Wei et al. Chain-of-Thought, 2022; Yao et al. ReAct, 2023; OpenAI o1 reasoning model, 2024; Anthropic Claude extended thinking, 2025): LLM-based reasoning paradigms enabling unstructured-input decisioning with traceable chain-of-thought reasoning traces that serve as natural-language decision explanations.
- **Automated planning and scheduling** (STRIPS formal planning language, Fikes & Nilsson, 1971; PDDL; HTN planning): planning systems that extend decision engines to multi-step sequential decision problems where the decision engine must reason about action consequences over a planning horizon.

  Key research venues include AAAI, IJCAI, RuleML+RR (Rules and Reasoning Conference), KR (Knowledge Representation and Reasoning), ECML-PKDD, FAccT, and the ACM SIGKDD conference which has published extensively on decision intelligence platforms and fairness in automated decision-making.

  ## Current Landscape (2026)

  The decision engine market has undergone significant convergence with AI and large language model platforms by 2026, driven by regulatory pressure, the maturation of hybrid architectures, and the emergence of agentic AI frameworks:

  **Market maturation and vendor landscape**: Gartner's 2024 Market Guide for AI Decisioning Platforms identified 75% global enterprise adoption of decision intelligence practices expected by 2026. The vendor landscape spans rule-engine BRMS specialists (Decisions.com, InRule, FICO Blaze Advisor), BPM-integrated decision platforms (Camunda, Pega, IBM ODM), cloud provider managed services (AWS Decision Services, Azure Applied AI Services), and emerging AI-native decisioning startups (Zest AI for credit, Featurespace for fraud, Quantexa for AML). Open-source platforms—Drools/Apache KIE, Easy Rules, OpenL Tablets—provide alternatives for organisations with strong engineering capability.

  **Drools and Apache KIE transition**: In 2024, Red Hat's Drools rule engine and associated tooling transitioned to the Apache Software Foundation as Apache KIE (incubating), reflecting the community's desire for vendor-neutral governance. The Apache KIE ecosystem provides a core Business Rules Engine with RETE-II implementation, Drools Workbench for web-based rule authoring, DMN conformance at Level 3, BPMN process integration, and OptaPlanner for constraint satisfaction problems. The commercial Aletyx enterprise distribution (launched 2024) provides GenAI integration and enterprise support for Apache KIE, targeting large financial services deployments.

  **LLM integration architectures**: The dominant architectural trend in 2025–2026 is the integration of [[Large Language Model]] as reasoning sub-components within hybrid decision engines. LLMs handle natural language input parsing (extracting structured features from unstructured documents), explanation generation (converting rule activation traces into natural language narratives), and complex multi-step reasoning (chain-of-thought deliberation over ambiguous or edge-case inputs). Rule engines maintain the guardrail function—enforcing hard regulatory constraints, sanctions screening, and escalation thresholds—while LLM components handle the nuanced interpretation required for complex cases. [[Chain of Thought]] reasoning logs from LLM components serve as the audit trail for the LLM sub-component, though the regulatory acceptability of LLM reasoning chains as formal audit evidence remains an open governance question.

  **Open Policy Agent in cloud-native contexts**: OPA, using the Rego policy language, has become the de facto standard for policy-as-code in cloud-native and DevSecOps contexts—serving as the [[Policy Engine]] component for Kubernetes admission control, API gateway authorisation, and microservice access control across thousands of enterprise deployments. OPA's separation of policy from code, its declarative Rego language, and its integration with the broader cloud-native ecosystem (Istio, Envoy, Gatekeeper) make it a widely deployed sub-component of broader decision architectures.

  **Regulatory pressure accelerating adoption and documentation**: The EU AI Act's high-risk AI classification (Article 6 and Annex III) covers automated credit scoring, employment screening, education access, and law enforcement decision systems—all primary decision engine use cases—requiring CE conformity marking, technical documentation, human oversight mechanisms, and post-market monitoring as conditions for EU deployment. The UK's parallel regulatory trajectory under UK GDPR, DUAA 2025, and FCA/PRA model risk management guidance is creating comparable documentation burdens for UK-regulated financial and healthcare decision engines.

  **Convergence of BRMS with MLOps**: Decision engines and [[MLOps]] pipelines are converging into unified decisioning platforms that manage the full lifecycle of both rule artefacts and model artefacts: authoring (low-code rule editing, model training pipelines), testing (rule regression suites, model validation frameworks), deployment (rule set and model versioning, blue-green deployment, canary rollouts), and monitoring (rule activation telemetry, model performance dashboards, drift detection). Vendors including Pega, IBM, and FICO have invested heavily in this convergence; cloud-native data platforms including Databricks and Snowflake are extending their ML platforms to include rule evaluation capabilities.

  ## UK Context

  The United Kingdom has a sophisticated decision engine industry and active academic research community, shaped by its position as a global financial centre, its complex post-Brexit regulatory environment, and its significant public sector data assets:

  **Financial services regulatory leadership**: London's position as a global financial centre makes UK decision engine deployments among the most sophisticated and heavily regulated globally. The Financial Conduct Authority (FCA) published its final Guidance on AI and Machine Learning in Financial Services (FG 22/5, 2022) and has subsequently issued consultation papers and discussion papers addressing model risk management, explainability requirements in consumer credit, and fairness obligations in automated underwriting under the Consumer Duty regime (effective July 2023). The Prudential Regulation Authority (PRA) published its supervisory statement SS1/23 on model risk management (May 2023), setting expectations for model governance documentation, performance monitoring, and model change management that directly apply to ML-based decision engines in banking and insurance.

  **Credit decisioning and consumer protection**: The FCA's Consumer Duty (July 2023) requires financial firms to deliver good outcomes for retail customers, which has material implications for automated credit decision engines—firms must demonstrate that automated decisions do not produce systematically poor outcomes for vulnerable customers or protected characteristic groups. The Equality Act 2010 prohibits indirect discrimination in credit decisions, meaning that decision engines must be assessed for disparate impact across protected characteristics. The UK Government's commitments to algorithmic transparency in public sector decision-making (Algorithmic Transparency Recording Standard, CDEI/DSIT, 2021) create additional documentation obligations for decision engines deployed by government agencies.

  **Credit reference agencies and data infrastructure**: Experian (headquartered in Dublin but with major UK operations in Nottingham), Equifax UK, and TransUnion UK provide the credit data infrastructure on which most UK credit decisioning engines depend. The CRAs' credit scoring models—specifically the scores computed from bureau data, not proprietary lender scores—are subject to GDPR Article 22 protections and the right to obtain human review. Following the CJEU's March 2025 ruling, UK courts have begun interpreting UK GDPR obligations in relation to automated credit decisions more strictly than previously.

  **NHS clinical decision support deployment**: NHS England has invested in clinical decision support as part of the NHS Long Term Plan (2019) and the NHS AI Strategy (2023). The NHS AI and Digital Regulations Service (AIDR) provides a regulatory pathway for AI-powered clinical decision engines, assessing them against the MHRA's Software and AI as a Medical Device framework. NHS trusts including University College London Hospitals (UCLH), Imperial College Healthcare NHS Trust, and Leeds Teaching Hospitals NHS Trust have deployed clinical decision engines for sepsis detection, deterioration alerting, and imaging triage, with each deployment subject to clinical governance review and post-deployment audit requirements.

  **Northern England industrial decision systems**: Manufacturing and logistics operations across Manchester, Leeds, Sheffield, and Newcastle are deploying decision engines for predictive maintenance scheduling (reducing unplanned downtime), quality control gate decisions (accept/reject/rework), and supply chain routing (carrier selection, stock replenishment triggers). The Hartree Centre at Daresbury, Cheshire (Science and Technology Facilities Council) provides national HPC infrastructure and data science expertise supporting development of decision-engine-integrated ML models for industrial use cases. The Advanced Manufacturing Research Centre (AMRC) in Sheffield contributes research on decision engines for aerospace manufacturing quality control.

  **Academic research contributions**: The University of Edinburgh's Informatics School (Decision Science, Semantic Web and Knowledge Representation groups) has contributed to [[Knowledge Representation]] formalisms applicable to decision engines. UCL's Institute for Risk and Disaster Reduction and computer science department conduct research on decision-making under uncertainty in safety-critical systems. Imperial College London's Data Science Institute has produced research on algorithmic fairness in automated decision systems. The University of Manchester—with its historical leadership in description logic, OWL, and the semantic web—contributes to the knowledge representation and reasoning foundations of rule-based decision engines. The Alan Turing Institute's Trustworthy AI programme directly addresses auditability, transparency, and [[Fairness]] requirements for automated decision-making in regulated contexts.

  **Public sector algorithmic transparency**: The UK government has deployed decision engines in benefits administration (Universal Credit, HMRC tax compliance), immigration processing (visa biometric verification), and policing (predictive analytics). Each deployment has attracted scrutiny from civil society organisations (the Ada Lovelace Institute, AlgorithmWatch UK) and parliamentary committees (the Public Administration and Constitutional Affairs Committee). The Algorithmic Transparency Recording Standard (ATRS) requires central government departments to publish information about significant algorithmic tools used in decision-making, establishing a precedent for systematic public disclosure of decision engine logic.

  ## Future Directions (2026–2030)

- **Neuro-symbolic convergence and differentiable rule engines**: The boundary between rule engines and neural networks will dissolve further. Differentiable rule engines (Neural Production Systems, Differentiable Rule Learning) will allow rule weights and rule conditions to be learned from data through gradient descent while maintaining the interpretability of symbolic rule structures, enabling decision engines to adapt to distributional shift without full model retraining and maintaining compliance with rule governance processes. [[Neuro Symbolic AI]] approaches will provide the theoretical foundation.
- **[[Causal Reasoning]] integration**: Integration of Pearl's do-calculus and structural causal models (SCMs) into decision engines will enable intervention-aware reasoning—the ability to reason about the causal consequences of a decision action rather than merely the correlational structure of historical data. Causal decision engines will support counterfactual explanation ("what would need to change for this decision to be different?"), bias auditing (identifying and blocking spurious causal paths), and robust generalisation under covariate shift. This is particularly valuable for credit decisioning and clinical decision support where the causal structure of the domain is partially known.
- **Continuous self-calibrating engines**: Decision engines will incorporate real-time performance monitoring and automated recalibration as standard, using [[Model Monitoring]] telemetry and online learning techniques to detect distributional shift and trigger partial rule or model updates without manual intervention. This will reduce the governance overhead of model refresh cycles from quarterly re-validation processes to continuous monitoring with event-triggered reviews, addressing the distributional shift challenge that currently requires manual monitoring by model risk management teams.
- **Federated decision engines**: Privacy-preserving architectures enabling decision engines to aggregate signals from distributed data sources—cross-bank transaction graphs for AML, multi-hospital patient risk data for clinical decision support—without centralising sensitive data. [[Federated Learning]] and secure multi-party computation will enable federated model training; homomorphic encryption may enable federated feature computation, allowing decision engines to score applications using features derived from data sources they cannot directly access.
- **LLM audit trail standardisation**: Regulatory bodies will develop standards for what constitutes an acceptable audit trail for LLM-generated decisions, enabling broader deployment of LLM-based decision engines in regulated domains. Chain-of-thought reasoning logs, grounding citations, and structured reasoning transcripts will be formalised as audit artefacts, analogous to the rule activation logs that underpin audit compliance in BRMS-based systems.
- **Decision engine certification and ISO standardisation**: The EU AI Act's conformity assessment requirements will drive standardisation of decision engine testing protocols, documentation formats, and audit standards. ISO/IEC 42001 (AI Management System) will be extended with sector-specific decision engine conformance testing specifications covering accuracy validation, bias testing, stability testing under distribution shift, and explanation quality assessment.
- **Real-time regulatory change propagation**: Regulatory change management—updating decision engine rule sets when laws, guidelines, or tariffs change—will become increasingly automated. LLM-based regulatory change parsers will extract rule modifications from regulatory publications (FCA policy statements, PRA supervisory statements, NICE guidance updates) and generate proposed rule set modifications for human review and approval, dramatically reducing the time from regulatory publication to compliant engine update.

  ## Decision Engine Governance and Risk Management

  [[Model Risk Management]] (MRM) frameworks govern the lifecycle of ML-based decision engine components, from initial development through validation, deployment, monitoring, and retirement. The Basel Committee on Banking Supervision's SR 11-7 guidance (2011, US) and the PRA's SS1/23 (2023, UK) establish risk management expectations for model-dependent institutions, requiring independent model validation, performance benchmarking, sensitivity analysis, and ongoing monitoring with defined escalation thresholds. In practice, MRM for hybrid decision engines requires distinct governance tracks for the rule component (which changes through the BRMS change management process) and the ML model component (which changes through a model development and validation cycle), with integration testing to verify that rule-model composition behaves as expected after changes to either component.

  The validation of decision engines for high-risk regulatory contexts requires three distinct validation activities: (1) **conceptual soundness review**, assessing whether the decision logic correctly captures the domain knowledge, regulatory requirements, and intended decision policy; (2) **outcome analysis**, assessing whether the engine produces accurate, calibrated, and appropriate outputs on representative test cases including edge cases, adversarial inputs, and protected characteristic subgroups; and (3) **ongoing monitoring**, tracking production decision distributions, model performance metrics (where outcome labels are available through feedback loops), and rule activation patterns to detect drift and anomalies. Independent validation teams must be distinct from development teams to avoid validation capture—the phenomenon where validators unconsciously replicate the assumptions of the developers whose work they are assessing.

  [[Human-in-the-Loop]] design is increasingly mandated by regulation for high-stakes decision contexts. The EU AI Act requires that high-risk AI systems enable the human overseer to effectively oversee the AI system during its operation, with the ability to decide not to use the system, to override its output, or to interrupt the system. Effective human-in-the-loop design for decision engines requires presenting decision outputs with confidence indicators, key contributing factors, flagged edge cases, and escalation recommendations—not merely a binary approve/reject signal—to enable human reviewers to exercise genuine oversight rather than rubber-stamping automated decisions. Research on automation bias (Mosier & Skitka, 1996; Cummings, 2017) shows that human reviewers frequently defer to automated recommendations even when they have information suggesting the recommendation is wrong, making the design of effective override mechanisms a safety-critical engineering challenge.

  [[Fairness]] assessment is mandatory for decision engines deployed in contexts covered by equality legislation. In the UK, the Equality Act 2010 prohibits direct discrimination (treating someone less favourably because of a protected characteristic) and indirect discrimination (applying a provision, criterion, or practice that has a disproportionate adverse impact on a protected group without objective justification). For automated credit decisions, protected characteristics include race, sex, disability, and age. Fairness metrics for decision engines include demographic parity (equal approval rates across groups), equalised odds (equal true-positive and false-positive rates across groups), and individual fairness (similar individuals receive similar decisions). These metrics are mathematically incompatible with each other under general conditions (the fairness impossibility theorem, Chouldechova, 2017; Kleinberg et al., 2017), requiring explicit trade-off decisions that must be documented and defended to regulators.

  The intersection of [[Privacy]] and decision engines is a growing compliance concern. Decision engines operating on personal data must comply with GDPR data minimisation principles—the engine should not process more personal data than strictly necessary for the decision—and purpose limitation, ensuring that data collected for one decision purpose is not repurposed for another. [[Differential Privacy]] mechanisms can be applied to aggregate reporting over decision engine outcomes (e.g., approval rate statistics) to prevent inference of individual-level data. Federated decision engines where model training occurs on local data without centralisation provide architectural [[Privacy]] guarantees aligned with data sovereignty requirements.

  ## Decision Engine Integration Patterns and Operational Architecture

  Decision engines do not operate in isolation; they integrate into broader application and data architectures through well-defined patterns that balance performance, governance, and maintainability:

  **Synchronous request-response pattern**: The calling application constructs a decision request payload containing the relevant context attributes (customer data, transaction details, product parameters), sends it to the decision engine [[API Gateway]] endpoint, waits for the decision response, and proceeds based on the outcome. This is the dominant pattern for real-time consumer-facing decisioning—online credit applications, payment authorisation, insurance quote generation. Latency from the calling application's perspective includes network round-trip, request deserialisation, feature computation, rule evaluation or model scoring, explanation generation, audit logging, and response serialisation. Production targets of under 200 milliseconds for consumer-facing applications and under 50 milliseconds for payment-adjacent decisions drive architectural choices including in-memory rule execution, pre-computed feature caches, and model quantisation to reduce inference latency.

  **Asynchronous event-driven pattern**: Decision requests are enqueued in a message broker (Apache Kafka, AWS SQS, Azure Service Bus), processed by decision engine worker instances at their own pace, and outcomes written to a results topic or database. This pattern suits high-throughput decisioning workloads where immediate response is not required—batch credit limit reviews, overnight fraud scoring of the day's transactions, bulk insurance portfolio repricing. The asynchronous pattern enables horizontal scaling of decision engine workers and provides natural back-pressure handling without client-visible timeout failures.

  **Embedded library pattern**: The decision engine runtime is packaged as a library linked directly into the calling application's process, avoiding network round-trip overhead at the cost of tight coupling. This is appropriate for edge deployment scenarios (mobile applications, IoT devices, in-store terminals) where network connectivity is unreliable or where very low latency is required. Embedded ONNX Runtime models and embedded Drools/Easy Rules instances are common implementations. The governance challenge is ensuring that embedded logic versions are updated promptly when rules or models change, as embedded deployments cannot be updated independently of the calling application release cycle.

  **Batch processing pattern**: Large batches of decision requests (millions of records) are processed offline through the decision engine in bulk, typically for portfolio management, regulatory reporting, or campaign targeting. Batch processing enables more expensive decision logic—complex multi-model ensembles, graph-based lookups, extensive explanation generation—that would exceed real-time latency budgets. Apache Spark or Flink pipelines invoke decision engine logic at scale through user-defined functions or microservice calls with batched HTTP requests. [[Data Pipeline]] orchestration frameworks (Airflow, Prefect) manage scheduling and monitoring of batch decisioning workflows.

  **[[Orchestration]] pattern**: In [[Agentic AI]] architectures, the decision engine is one node in a directed graph of tool-calling steps orchestrated by an LLM reasoning agent. The [[Orchestration]] layer determines when to invoke the decision engine, what context to pass, how to interpret the output, and what to do next based on the decision. LangGraph and similar frameworks enable stateful multi-step workflows where the decision engine contributes a structured rule-based or model-based assessment that the LLM agent incorporates into its broader reasoning. This pattern is emerging for complex advisory applications—mortgage eligibility assessment with explanatory advice, clinical triage with protocol-guided recommendation, tax compliance review with regulation-grounded analysis.

  [[Knowledge Graph]] integration is increasingly important for high-context decision engines operating on entity-rich domains. Graph-based feature extraction—traversing relationship networks to compute entity-level features like total exposure across a customer group, supply chain dependency depth, or clinical contraindication chains—provides decision-relevant signals that cannot be expressed as flat feature vectors. Graph database integrations (Neo4j, Neptune, TigerGraph) enable real-time graph traversal as part of the feature computation step within the decision engine request pipeline, supporting relationship-aware decisions in fraud detection (identifying synthetic identity networks), credit risk (group-level exposure), and clinical safety (drug interaction checking through pharmacological knowledge graphs).

  ## Decision Engine Testing and Quality Assurance

  Decision engines require a distinct testing regime that addresses both the functional correctness of logic and the regulatory compliance of outputs. Unlike general software testing where test cases are derived from specifications, decision engine testing must also address statistical properties of outputs over populations and the integrity of explanation mechanisms:

  **Rule regression testing**: Rule sets are tested against suites of historical decisions with known correct outcomes, verifying that rule changes do not alter decisions on existing cases (regression prevention) and that new rules produce intended outcomes on targeted cases. Rule regression suites should include: boundary condition test cases (inputs at the exact threshold of rule conditions), negative test cases (inputs that should not trigger specific rules), combinatorial cases (interactions between multiple rules firing simultaneously), and special cases mandated by regulation (mandated accept/reject conditions, prohibited discriminatory patterns). Test suite coverage is measured both in terms of condition coverage (percentage of rule conditions exercised) and decision outcome coverage (proportion of reachable decision paths tested).

  **Statistical outcome testing**: Model components within hybrid decision engines are evaluated against holdout test datasets using appropriate performance metrics (AUC-ROC, Gini coefficient, F1 score, calibration curves). For regulated applications, test datasets must be representative of the deployment population and must include adequate representation of protected characteristic subgroups to enable disparate impact testing. Calibration testing verifies that model-assigned probabilities accurately reflect observed outcome frequencies—a model outputting a 30% default probability should observe approximately 30% actual defaults among those cases over time. Stability testing (Population Stability Index) monitors whether the distribution of model scores in the deployment population has shifted relative to the development period, triggering model review when PSI exceeds 0.25.

  **Adversarial and edge case testing**: Decision engines in high-stakes domains are subject to deliberate gaming attempts by adversarial actors—loan applicants who manipulate their application data, fraudsters who adapt behaviour to avoid detection rules, insurance claimants who exaggerate losses. Adversarial testing systematically generates inputs designed to exploit known weaknesses in decision logic, testing robustness against realistic manipulation strategies. Red-teaming—having a team attempt to find ways to obtain favourable decisions through illegitimate means—provides qualitative security assessment complementing statistical testing.

  **Explanation fidelity testing**: For decision engines subject to explainability requirements, the accuracy of explanations must be verified. SHAP explanation fidelity can be assessed by confirming that the sum of feature contributions matches the predicted probability minus the base rate (efficiency axiom) and that features with zero contribution in the model produce zero SHAP values (dummy player axiom). Rule-based explanations must be verified to correctly identify the activated rules and the specific fact values that satisfied rule conditions. Contrastive explanations ("what would need to change for a different decision?") must be verified to identify minimal and actionable changes.

  **A/B testing and champion-challenger deployment**: When a new decision engine version (challenger) is proposed to replace the current production version (champion), A/B testing allocates a small fraction of production traffic to the challenger to compare outcomes in the live environment before full rollout. This is particularly important for ML model updates where retrospective testing on historical data may not fully capture future performance. The champion-challenger framework requires infrastructure to route requests across versions, track outcomes per version, and compute statistical significance of performance differences. Minimum detectable effect sizes and required sample sizes must be computed a priori to avoid underpowered comparisons.

  **Automated regression suites in CI/CD pipelines**: Decision engine changes—rule set modifications, model retraining, feature engineering updates—should trigger automated test suite execution in continuous integration/continuous deployment (CI/CD) pipelines before promotion to production. The CI/CD pipeline should run: rule regression tests, statistical tests on validation datasets, fairness tests across protected characteristic subgroups, latency benchmarks, and integration tests with upstream feature computation and downstream workflow systems. Failures in any test category block promotion to production, ensuring that governance controls are enforced programmatically rather than relying on manual review alone.

  ## Standard Industry Implementations and Ecosystem

  The decision engine ecosystem in 2026 comprises multiple layers of tooling supporting different aspects of the decision engine lifecycle:

  **Open-source rule engines**: Apache KIE (Drools), Easy Rules, OpenL Tablets, Camunda DMN, jDMN (open-source DMN implementation). These provide the foundational rule execution runtime and are embedded or containerised for production deployment. Apache KIE's RETE-II implementation handles hundreds of thousands of rule evaluations per second on modern hardware; the Drools benchmark suite provides standardised performance characterisation.

  **Commercial BRMS platforms**: IBM Operational Decision Manager (ODM), FICO Blaze Advisor, Decisions.com, InRule, Pegasystems Decision Hub, SAS Decision Manager. These provide enterprise-grade management interfaces, deployment automation, governance workflows, version control integration, and support for large-scale regulated deployments. Pricing is typically per-core or per-decision-volume and reflects the value of the governance and compliance tooling.

  **ML model serving for decision components**: TensorFlow Serving, TorchServe, ONNX Runtime Server, NVIDIA Triton Inference Server, BentoML. These serve the ML scoring component of hybrid decision engines, providing GPU acceleration, dynamic batching, and model versioning. Integration with BRMS platforms is typically via REST/gRPC API calls from the rule engine to the model serving layer.

  **MLOps platforms integrating decision engine capabilities**: Databricks (MLflow integration, Feature Store), Snowflake (Model Registry, Cortex ML), AWS SageMaker (Model Monitor, Clarify for bias), Azure Machine Learning (Responsible AI Dashboard). These platforms provide the infrastructure for training, validating, deploying, and monitoring the ML components of hybrid decision engines within broader data platform architectures.

  **Policy-as-code and regulatory compliance tools**: Open Policy Agent (OPA/Rego), HashiCorp Sentinel, Cedar (AWS), Styra DAS. These provide cloud-native policy enforcement for infrastructure-level access decisions (Kubernetes, API gateway, service mesh) and serve as the [[Policy Engine]] component for cloud-native decision architectures where traditional BRMS overhead is inappropriate.

  **Explainability and fairness toolkits**: AI Fairness 360 (IBM), Fairlearn (Microsoft), SHAP (SML Community), LIME, InterpretML, Alibi Explain, Evidently AI. These provide the algorithmic components of the explanation module and fairness testing infrastructure, integrated into decision engine pipelines as libraries or microservices.

  ## Decision Engine Failure Modes and Mitigations

  Understanding the failure modes of decision engines is essential for designing robust, trustworthy systems. Decision engine failures fall into several distinct categories, each requiring different mitigation strategies:

  **Rule explosion and maintainability degradation**: Large rule-based decision engines can accumulate thousands of rules over years of operation, creating systems where the interaction effects between rules become difficult to predict or test. The "spaghetti rules" problem—rules that were individually correct at creation but interact unexpectedly with subsequently added rules—is a primary cause of production decision engine incidents. Mitigations include rule base refactoring (merging equivalent rules, extracting common conditions into sub-decision tables), modular rule organisation (partitioning rules into independent modules by decision domain), and automated rule conflict detection tools that identify rule combinations that can never simultaneously fire (dead rules) or that always override each other (shadowed rules).

  **Model drift and performance degradation**: ML components within hybrid decision engines degrade as the deployment population diverges from the training population. Economic cycles, product changes, competitor actions, and regulatory changes all cause the feature distributions and outcome rates that determine model performance to shift over time. Without active monitoring and recalibration, model performance can degrade from a Gini coefficient of 0.60 at deployment to below 0.40 within two to three years in dynamic environments. Mitigation requires production monitoring infrastructure, defined performance thresholds that trigger review, and a model refresh pipeline that can retrain and validate a new model version within weeks of a drift alert.

  **Automation bias and inappropriate [[Human-in-the-Loop]] design**: Human reviewers tasked with overriding automated decisions frequently fail to exercise genuine oversight, deferring to the decision engine's recommendation even when contextual information suggests the recommendation is incorrect. This automation bias effect (Mosier & Skitka, 1996) is exacerbated by volume pressure (reviewers processing hundreds of cases per day cannot devote adequate attention to each), interface design (systems that make override cumbersome), and accountability asymmetry (reviewers may be criticised for overrides that turn out poorly but not for approving automated decisions that cause harm). Mitigations include interface designs that present the decision with uncertainty and supporting evidence rather than a simple recommendation, randomised sample review to maintain human skill, and accountability structures that make inappropriate deference as visible as inappropriate override.

  **Explanation gaming and adversarial manipulation**: Published explanations of decision engine logic can be exploited by adversarial actors to reverse-engineer decision boundaries and manipulate inputs to obtain desired outcomes. Credit applicants may game feature thresholds identified through subject access request responses or through systematic experimentation. Insurance claimants may craft narratives to avoid fraud detection rules. Fraudsters adapt behaviour once specific rule triggers become known through regulatory disclosure or information asymmetry. Mitigations include explanation specificity limits (providing general factor information without exact thresholds), adversarial testing (red-teaming) to identify gaming vulnerabilities, and ensemble approaches that increase the dimensionality of the decision surface and make it harder to identify exploitable boundaries.

  **Cascading failure in orchestrated decision pipelines**: In [[Orchestration]] architectures where multiple decision engines and [[Inference Engine]] components are composed in sequence, a failure or degradation in any upstream component can propagate to downstream components and ultimately to the final decision. A feature computation service that returns stale cached values due to a data pipeline failure will cause the model scorer to receive incorrect features, producing incorrect scores, which the rule engine may then act on without detecting the anomaly. Mitigation requires circuit breaker patterns (failing fast when upstream components are unhealthy), health check propagation (upstream component health signals propagated to orchestrators), graceful degradation fallbacks (default conservative decisions when components fail), and comprehensive observability across the full decision pipeline.

  **Distributional shift between train-time and run-time feature computation**: A subtle failure mode arises when the feature engineering logic applied at training time differs from the feature engineering logic applied at inference time—the training-serving skew problem. If training features were computed with different null value handling, different aggregation windows, or different categorical encoding than inference-time features, the model will receive systematically different inputs at inference than it was trained on, degrading performance in ways that may not be detectable through standard monitoring. Mitigation requires using the same feature computation code path for both training and inference, ideally by materialising training features from a production feature store rather than computing them in a batch training-specific pipeline.

  ## Key Challenges and Open Problems

  Decision engine research and practice face several persistent unsolved problems that represent active investigation areas:

  **The interpretability-accuracy trade-off**: Simple, highly interpretable models (linear models, decision trees, rule lists) are typically less accurate than complex models (gradient boosting, deep networks) on most real-world tasks. The gap between interpretable and complex model performance varies by domain and dataset size but is typically 3–10% on standard benchmarks, representing significant business value in high-volume automated decision applications. Bridging this gap through inherently interpretable architectures (monotone networks, neural additive models, RuleFit) or through increasingly faithful post-hoc explanation methods is an active research direction. The empirical question of whether the interpretability-accuracy trade-off is fundamental or an artefact of insufficient algorithmic development remains contested.

  **The right to explanation implementation challenge**: Despite regulatory requirements for decision explanations (GDPR Article 22, EU AI Act Article 86), the technical and legal definition of what constitutes a "meaningful" explanation is contested. The CJEU's March 2025 ruling established that explanations must convey "the logic involved" and the "main features taken into account," but did not specify technical standards for what satisfies this requirement. Developing explanation methods that satisfy legal standards while remaining computationally tractable and comprehensible to non-technical recipients is an open multi-disciplinary challenge spanning computer science, law, and cognitive science.

  **Real-time causal reasoning at scale**: Incorporating [[Causal Reasoning]] capabilities—counterfactual inference, intervention reasoning, structural causal models—into real-time decision engines operating at sub-100ms latency is technically challenging. Current causal inference methods are computationally expensive (markov chain monte carlo for posterior sampling, iterative optimisation for average treatment effect estimation) and cannot be applied at the query rates required for real-time decisioning. Approximation methods, pre-computed causal graphs, and causal neural networks are partial approaches but remain research prototypes rather than production-ready components.

  ## Research & Literature

  1. Forgy, C. L. (1982). Rete: A Fast Algorithm for the Many Pattern / Many Object Pattern Match Problem. *Artificial Intelligence*, 19(1), 17–37. https://doi.org/10.1016/0004-3702(82)90020-0
  2. Shortliffe, E. H. (1976). *Computer-Based Medical Consultations: MYCIN*. Elsevier/North-Holland.
  3. Buchanan, B. G., & Shortliffe, E. H. (Eds.). (1984). *Rule-Based Expert Systems: The MYCIN Experiments*. Addison-Wesley.
  4. von Neumann, J., & Morgenstern, O. (1944). *Theory of Games and Economic Behavior*. Princeton University Press.
  5. Savage, L. J. (1954). *The Foundations of Statistics*. Wiley.
  6. Fikes, R. E., & Nilsson, N. J. (1971). STRIPS: A New Approach to the Application of Theorem Proving to Problem Solving. *Artificial Intelligence*, 2(3–4), 189–208.
  7. Object Management Group. (2023). *Decision Model and Notation (DMN) Specification v1.5*. OMG. https://www.omg.org/dmn/
  8. Lundberg, S. M., & Lee, S.-I. (2017). A Unified Approach to Interpreting Model Predictions. *NeurIPS 2017*. https://arxiv.org/abs/1705.07874
  9. Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). "Why Should I Trust You?": Explaining the Predictions of Any Classifier. *KDD 2016*. https://arxiv.org/abs/1602.04938
  10. Doshi-Velez, F., & Kim, B. (2017). Towards a Rigorous Science of Interpretable Machine Learning. *arXiv*. https://arxiv.org/abs/1702.08608
  11. Goodman, B., & Flaxman, S. (2017). European Union Regulations on Algorithmic Decision-Making and a "Right to Explanation." *AI Magazine*, 38(3), 50–57.
  12. Wachter, S., Mittelstadt, B., & Russell, C. (2017). Counterfactual Explanations without Opening the Black Box. *Harvard Journal of Law & Technology*, 31(2).
  13. Wei, J., et al. (2022). Chain-of-Thought Prompting Elicits Reasoning in Large Language Models. *NeurIPS 2022*. https://arxiv.org/abs/2201.11903
  14. Yao, S., et al. (2023). ReAct: Synergizing Reasoning and Acting in Language Models. *ICLR 2023*. https://arxiv.org/abs/2210.03629
  15. Garnelo, M., & Shanahan, M. (2019). Reconciling Deep Learning with Symbolic Artificial Intelligence. *Current Opinion in Behavioral Sciences*, 29, 17–23.
  16. Marcus, G. (2020). The Next Decade in AI: Four Steps Towards Robust Artificial Intelligence. *arXiv*. https://arxiv.org/abs/2002.06177
  17. European Parliament and Council. (2024). *Regulation (EU) 2024/1689 Laying Down Harmonised Rules on Artificial Intelligence (AI Act)*. Official Journal of the European Union.
  18. CJEU. (2025). Case C-203/22 — Dun & Bradstreet Austria GmbH. Judgment on GDPR Article 22 Rights to Explanation of Automated Decision-Making. *Court of Justice of the European Union*.
  19. UK Parliament. (2025). *Data (Use and Access) Act 2025*. https://www.legislation.gov.uk/ukpga/2025/
  20. Information Commissioner's Office. (2023). *Explaining Decisions Made with AI*. ICO. https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/explaining-decisions-made-with-ai/
  21. Financial Conduct Authority. (2022). *Guidance on AI and Machine Learning in Financial Services* (FG 22/5). FCA. https://www.fca.org.uk/
  22. Prudential Regulation Authority. (2023). *Model Risk Management Principles for Banks* (SS1/23). PRA/Bank of England.
  23. Apache KIE Project. (2024). *Apache KIE (Incubating) — formerly Red Hat Drools*. Apache Software Foundation. https://www.drools.org/
  24. Gartner. (2024). *Market Guide for AI Decisioning Platforms*. Gartner Research. [Cited via https://genixly.io/blogs/what-is-a-decision-engine-business-automation]
  25. InRule Technology. (2025). *The Future of AI Automated Decision Making: 2025 Trends to Watch*. https://inrule.com/ai-automated-decision-making-trends/
  26. Decisions.com. (2025). *The Evolving Power of Rules Engines: Trends to Watch in 2025*. https://decisions.com/the-evolving-power-of-rules-engines-trends-to-watch-in-2025/
  27. Kahneman, D., & Tversky, A. (1979). Prospect Theory: An Analysis of Decision under Risk. *Econometrica*, 47(2), 263–291.

  ## Variant Taxonomy and Major Families

  Decision engines are not a monolithic category but a family of architectures distinguished by the nature of their decision logic, their latency profile, and the type of decision they produce:

- **Pure rule engine (BRMS)**: Decision logic is entirely encoded as explicit [[Business Rules]] in a production rule language (DRL, DMN) or logic programming language. Rules are authored and maintained by domain experts through a business rule management system interface. Strengths: complete transparency, no training data required, rules directly encode regulatory constraints. Weaknesses: knowledge acquisition bottleneck, brittle under distribution shift, inability to generalise from data patterns not explicitly encoded. Examples: Drools/Apache KIE, IBM ODM, Easy Rules, Camunda DMN.
- **ML inference engine**: Decision logic is captured in a trained statistical model (gradient boosting tree, neural network, logistic regression) applied as a scoring function over feature vectors. The model's decision boundary is learned from data rather than explicitly authored. Strengths: high predictive accuracy for pattern-rich domains, ability to learn complex non-linear relationships. Weaknesses: limited interpretability (especially for deep models), requires labelled training data, subject to distributional shift, [[Explainable AI]] methods needed for regulatory compliance. Examples: scikit-learn pipeline, TensorFlow Serving, ONNX Runtime serving a trained model.
- **Hybrid decision intelligence system**: Combines rule-based guardrails with ML scoring, typically as a sequential pipeline. Rules enforce categorical constraints; ML scores provide graded risk assessment within the rule-approved population. The most common architecture in regulated financial services and insurance. Examples: credit decisioning platforms (FICO Decision Modeler, Pega Credit Risk), fraud platforms (Feedzai, Fraud.net).
- **[[Neuro Symbolic AI]] decision engine**: Emerging architecture integrating neural perception modules with symbolic reasoning components, enabling decisions that combine pattern recognition over raw data (image, audio, text) with logical inference over symbolic representations. Neural production systems (Smolensky et al., Tensor Product Representations; Garnelo's NS approach) allow rule weights to be differentiable, enabling gradient-based learning of rule parameters. Applications include visual question answering, scientific reasoning, and drug-gene interaction prediction.
- **Agentic / [[Large Language Model]] decision engine**: LLM acts as the reasoning core, receiving unstructured inputs (document text, conversation history, sensor readings) and producing structured decision outputs through tool-calling and [[Chain of Thought]] decomposition. Auditability is provided by the reasoning trace, which must be structured and preserved as an [[Audit Trail]] artefact. [[Agentic AI]] frameworks (LangGraph, AutoGen, LCEL) provide the orchestration infrastructure. This architecture is emerging for complex decisioning over heterogeneous unstructured data—legal contract review, clinical note interpretation, regulatory filing analysis.
- **Real-time decisioning engine**: Optimised for sub-millisecond to tens-of-millisecond end-to-end latency, handling very high throughput (hundreds of thousands of decisions per second). Feature computation, model scoring, and rule evaluation are co-located or tightly coupled; [[API Gateway]] integration adds minimal overhead. Examples: ad bidding decision engines (Google DV360, The Trade Desk), fraud decisioning (operating at payment network transaction speeds), and high-frequency trading risk controls.
- **Deliberative decision engine**: Accepts higher latency (seconds to minutes per decision) in exchange for more complex reasoning, evidence aggregation, and explanation depth. Invokes multiple sub-components—evidence retrieval, simulation, counterfactual analysis—and produces detailed decision reports. Used for complex insurance underwriting, lending credit committee decisions, and clinical case review support.
- **[[Federated Learning]] decision engine**: Architecture where the ML component of a hybrid decision engine is trained through federated learning across distributed data sources (multiple banks, multiple hospital trusts) without centralising sensitive data. Federated training allows cross-institutional model improvement while preserving [[Privacy]] and regulatory data sovereignty requirements. The rule component remains centralised but the model component captures distributed signal.
- **[[Bayesian Inference]] decision engine**: Models decision uncertainty explicitly through posterior probability distributions over decision outcomes, updating beliefs incrementally as new evidence arrives. Bayesian decision engines support sequential decision-making under uncertainty, expected utility maximisation, and principled uncertainty quantification. Applied in medical diagnosis (Bayesian diagnostic networks), sensor fusion, and financial portfolio optimisation. Computational challenges for large-scale Bayesian inference are addressed through variational inference and Markov chain Monte Carlo approximations.

  ## Key Terminology

- **Business Rule**: A declarative statement expressing a specific policy, guideline, constraint, or calculation that governs a business decision—e.g., "IF applicant age < 18 THEN reject; IF debt-to-income > 0.45 THEN refer to underwriter." Business rules are authored by domain experts and managed independently of application code in a BRMS.
- **BRMS (Business Rule Management System)**: A software platform providing the full lifecycle management of business rules: authoring, testing, versioning, deployment, and monitoring. Distinguished from a simple rule engine by the provision of business-user interfaces and governance tooling.
- **RETE algorithm**: The pattern-matching algorithm underlying most production rule engines, compiling rule conditions into a network of shared test nodes to achieve efficient incremental evaluation of large rule bases against a changing working memory.
- **DMN (Decision Model and Notation)**: The OMG standard for representing business decision logic in decision tables and decision requirement diagrams, providing a business-readable notation above the level of rule language syntax.
- **Working memory**: In a production rule system, the data store of currently known facts against which rule conditions are evaluated. The rule engine's inference cycle repeatedly matches rule conditions against working memory, selects a rule to fire via conflict resolution, executes its actions (which may modify working memory), and iterates until no further rules can fire (quiescence).
- **Conflict resolution**: The strategy applied when multiple rules' conditions are simultaneously satisfied, determining which rule fires first. Common strategies: priority ordering (highest explicit priority wins), specificity (most-constrained rule wins), recency (rule matching the most recently asserted fact wins), or first-match (the first matching rule in source order wins, common in decision tables with FIRST hit policy).
- **[[Decision Transparency]]**: The property of a decision engine by which the reasoning path linking inputs to outputs can be explained to affected parties and auditors in a faithful, intelligible manner. A regulatory and ethical design requirement for high-stakes automated decisions.
- **Straight-through processing (STP)**: The automated completion of a decision or transaction without manual human review, enabled by decision engines with sufficient rule and model confidence. STP rate is a key operational efficiency metric for insurance claims processing and banking transaction operations.
- **SHAP (Shapley Additive Explanations)**: A model-agnostic explanation method that assigns each input feature a contribution score for a given prediction, satisfying mathematical axioms of efficiency (contributions sum to the prediction difference from baseline), symmetry, and linearity. The standard approach for ML component explanation in hybrid decision engines.
- **Distributional shift**: The divergence between the statistical distribution of inputs the decision engine was trained or calibrated on (training distribution) and the distribution of inputs encountered in production (deployment distribution). Distributional shift causes model calibration and accuracy to degrade over time and is the primary driver of model monitoring and recalibration requirements.

  ## Decision Engine Platform Comparison (2026)

  The following table-form overview characterises the major decision engine platforms and their positioning in 2026:

  **Apache KIE (Drools):**

- Type: Open-source BRMS with DMN support
- Algorithm: RETE-II forward-chaining rule engine
- DMN Conformance: Level 3 (full)
- ML Integration: Via external REST/gRPC model serving calls
- Explanation: Rule activation chain logging; no native ML explanation
- Strengths: No licence cost, strong community, Java ecosystem
- Weaknesses: Requires engineering resource for operation; limited business-user authoring tools without commercial wrapper
- UK adoption: High in NHS, financial services engineering teams, and public sector

  **IBM Operational Decision Manager (ODM):**

- Type: Commercial enterprise BRMS
- Algorithm: RETE-based with enterprise rule management studio
- DMN Conformance: Level 3 with IBM extensions
- ML Integration: Watson Machine Learning integration; PMML model deployment
- Explanation: Rule trace with business-language explanations; model SHAP integration
- Strengths: Full enterprise governance suite, extensive financial services track record
- Weaknesses: High licence cost; complex deployment architecture; slower innovation cycle than cloud-native competitors
- UK adoption: Dominant in large UK banks (HSBC, Standard Chartered, Lloyd's of London)

  **FICO Blaze Advisor:**

- Type: Commercial decision management platform
- Algorithm: RETE with FICO proprietary optimisations
- ML Integration: FICO Platform ML integration; PMML import
- Explanation: Scored explanation with contributing factors
- Strengths: Deep credit risk and fraud domain expertise; strong regulatory track record
- Weaknesses: Expensive; vendor lock-in through proprietary rule language
- UK adoption: Major UK retail banks, building societies, and card issuers

  **Decisions.com:**

- Type: Low-code/no-code commercial BRMS
- Algorithm: Rule engine with flow-based process integration
- ML Integration: External model API integration; AutoML capabilities
- Explanation: Flow trace and decision log
- Strengths: Low-code authoring enables business users without engineering support; rapid deployment
- Weaknesses: Less suited for complex high-performance rule evaluation; newer platform with smaller enterprise track record
- UK adoption: Growing in financial services, insurance, and healthcare SME contexts

  **Camunda Platform (DMN):**

- Type: Open-source BPM+DMN platform (commercial enterprise edition)
- Algorithm: DMN decision table evaluation with FEEL expression language
- ML Integration: Via external API calls from process flow
- Explanation: Decision table result trace
- Strengths: BPMN+DMN integration for process-and-decision automation; cloud-native architecture
- Weaknesses: DMN only (no Drools-style production rules); ML integration requires custom development
- UK adoption: Growing in digital transformation contexts across financial services, insurance, and government

  **Open Policy Agent (OPA):**

- Type: Open-source policy engine (CNCF graduated project)
- Algorithm: Rego language evaluation with top-down unification-based semantics
- DMN Conformance: Not applicable (different evaluation model)
- ML Integration: Not native; typically upstream or downstream
- Explanation: Rego evaluation trace; reason annotation
- Strengths: Cloud-native; Kubernetes/service mesh native; declarative policy-as-code; CNCF ecosystem
- Weaknesses: Primarily suited to access control and authorisation decisions, not complex business decisioning
- UK adoption: Standard in Kubernetes-based financial services and government cloud deployments

  ## Glossary of Decision Engine Standards and Specifications

- **RETE algorithm** (Forgy, 1982): The pattern-matching algorithm underlying most production rule engines, compiling rule conditions into an alpha-beta network for efficient incremental evaluation.
- **RETE-II** (Doorenbos, 1995): Enhanced version of RETE with improved handling of conjunctive rules and shared conditions across multiple rule patterns.
- **DMN (Decision Model and Notation)** v1.5 (OMG, 2023): Standard for decision tables, decision requirement diagrams, and FEEL expression language.
- **FEEL (Friendly Enough Expression Language)**: The expression language embedded within DMN, providing type-safe expressions for condition and action values in decision tables.
- **BPMN (Business Process Model and Notation)** v2.0 (OMG, 2011): Complementary standard to DMN for modelling the workflow processes that invoke decision engines.
- **PMML (Predictive Model Markup Language)** v4.4 (DMG, 2016): XML-based interchange format for trained statistical models, enabling transport of logistic regression, decision tree, neural network, and other model types between training frameworks and serving runtimes.
- **XACML (eXtensible Access Control Markup Language)** v3.0 (OASIS, 2013): XML-based standard for attribute-based access control policies, commonly used in enterprise identity management and as the policy language for [[Access Control]] oriented decision engines.
- **OPA Rego**: The policy language for Open Policy Agent, providing declarative rule definitions with top-down evaluation semantics, used for cloud-native authorisation and [[Policy Engine]] implementations.
- **SR 11-7**: The Federal Reserve / OCC 2011 supervisory guidance on model risk management (US), establishing industry norms for model development, validation, and governance that have been influential globally including in UK PRA/FCA expectations.
- **SS1/23**: PRA Supervisory Statement 1/23 (2023) on model risk management for UK banks, establishing binding expectations for model governance documentation, validation, performance monitoring, and model change management directly applicable to ML-based decision engines.

  ## Decision Engine Integration with Enterprise Data Architecture

  Modern decision engines are embedded within broader [[Data Architecture]] and enterprise system landscapes, with several critical integration touchpoints that determine operational effectiveness:

  **Feature store integration**: A [[Feature Engineering]] feature store (Feast, Tecton, Hopsworks, Databricks Feature Store) provides consistent feature computation across training and serving, resolving the training-serving skew problem. The decision engine's feature computation step queries the feature store's serving layer for pre-computed entity features (customer aggregate statistics, entity risk scores, derived ratios) and combines them with request-specific context features computed inline. Feature stores maintain feature version history and support point-in-time correct feature retrieval, enabling exact reproduction of feature values at any historical decision time for audit and model validation purposes.

  **Event streaming integration**: Real-time decision engines consume input context from event streaming platforms (Apache Kafka, AWS Kinesis, Azure Event Hubs) and publish decision events to output streams. Input streams carry transaction events, application submissions, sensor readings, and other triggering events; output streams carry decision outcomes, audit records, and monitoring telemetry. Stream processing frameworks (Kafka Streams, Apache Flink) may perform pre-processing of input events before passing them to the decision engine, implementing feature computation, deduplication, and session aggregation at streaming scale.

  **[[Data Governance]] and metadata management**: Decision engine deployments must integrate with enterprise [[Data Governance]] platforms to maintain metadata about the data assets consumed (input feature definitions, reference data sources, model training datasets) and produced (decision logs, audit records) by the engine. Data lineage tracking through the decision engine—from input attribute through feature transformation to model score to decision outcome—is a regulatory requirement for high-risk AI deployments and requires integration with enterprise lineage tools (Apache Atlas, OpenMetadata, Collibra).

  **Identity and [[Access Control]] management**: Decision engines operating on sensitive personal data require integration with enterprise identity systems (Active Directory, OKTA, AWS IAM) to enforce role-based access control over decision engine administration (rule authoring, model deployment, audit log access) and to attribute administrative actions to specific authenticated users in the audit trail. API-level access control ensures that only authorised calling applications can submit decision requests, preventing unauthorised use of the decision engine's logic outside of approved workflows.

  **[[MLOps]] platform integration**: The model components of hybrid decision engines are managed through [[MLOps]] platforms that provide model registry, experiment tracking, deployment pipelines, and monitoring dashboards. MLflow (open source), SageMaker (AWS), Azure ML, and Vertex AI (Google) provide managed MLOps services that integrate with CI/CD pipelines to automate model promotion from development through staging to production following automated validation gate passage. Decision engine deployments benefit from MLOps integration for model artefact management and performance monitoring while the rule component remains managed through the BRMS lifecycle tooling.

  **[[Deep Learning]] integration**: Where deep learning models (transformer encoders for text classification, CNNs for image-based decisions, time-series networks for behavioural analysis) provide the scoring component within hybrid decision engines, their serving must meet the latency requirements of the decision engine's SLA. [[Deep Learning]] model quantisation (INT8, FP16 precision reduction), model pruning (removal of low-magnitude weights), knowledge distillation (training a smaller student model to mimic a larger teacher model), and model compilation for specific hardware (TensorRT, ONNX Runtime optimisation) are standard techniques for reducing inference latency to acceptable levels for real-time decision applications. Transformer-based [[Natural Language Processing]] models—BERT variants for text classification, RoBERTa for sentiment and entailment—are increasingly used as document understanding components within complex document-oriented decision engines, classifying the risk or intent of textual inputs to inform downstream rule evaluation.

  **[[Risk Scoring]] component design**: The risk scoring sub-component of a hybrid decision engine must satisfy several technical requirements beyond raw predictive accuracy: calibration (predicted probabilities must reflect observed outcome frequencies), stability (score distributions must not change erratically between monthly model monitoring cycles), discrimination (the model must rank high-risk cases above low-risk cases, measured by AUC-ROC and Gini coefficient), and fairness (score distributions must not show impermissible disparate impact across protected characteristic groups). Scorecard development methodology—linear models with weight-of-evidence encoded variables and population stability monitoring—remains the industry standard for credit [[Risk Scoring]] in regulated contexts because its properties satisfy all four requirements simultaneously while maintaining the interpretability required by regulation.

  **[[Automated Reasoning]] foundations**: The theoretical foundations of rule-based decision engines are directly continuous with the broader [[Automated Reasoning]] research agenda—production systems are a practical engineering realisation of first-order logic applied to enterprise knowledge. The connection between [[First-Order Logic]] and BRMS rule languages runs through the subsumption of Horn clause logic (all standard production rules are Horn clauses), which enables polynomial-time inference algorithms for the restricted language class. [[Formal Methods]] techniques including model checking, temporal logic specification, and automated theorem proving are being applied to verify properties of decision engine rule sets—proving that a given rule set can never produce a specific prohibited outcome, or that it always produces an output within a specified range of values—providing stronger assurance than empirical test suites alone.

  **[[Adaptive Systems]] and continuous learning**: The next generation of decision engines will transition from periodic batch retraining cycles to continuously learning systems that update their model components online as new labelled outcomes arrive through feedback loops. Online learning algorithms (stochastic gradient descent, Vowpal Wabbit, online random forests) update model parameters incrementally without full retraining, enabling decision engines to adapt to distributional shift in near-real-time. [[Adaptive Systems]] architectures balance adaptation speed (faster learning responds to shifts more quickly) against stability (slower learning is less susceptible to overfitting to transient anomalies or adversarial gaming). Formal guarantees of regret bounds (the cumulative performance gap between the online learner and the best static model in hindsight) provide theoretical grounding for online learning decision engines.

### Provenance

