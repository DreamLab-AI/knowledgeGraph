Steganography is the practice of concealing the existence of a message by embedding it within an innocuous carrier such as an image, audio file or text, so that only the intended recipient is aware that hidden information is present. Unlike encryption, which scrambles content but leaves it visibly protected, steganography aims to make the very presence of communication undetectable. The two techniques are complementary and are often combined for layered confidentiality.

### Overview

- Steganographic methods hide payloads in the redundancy of a cover medium, for example by altering least-significant bits of image pixels or inaudible components of audio. The goal is statistical indistinguishability between cover objects with and without a payload, so that detection (steganalysis) is infeasible. Robustness, capacity and undetectability trade off against one another, and combining steganography with encryption protects the payload even if hiding is discovered.

### Mechanisms

- **Cover medium** — images, audio, video or text that carries the hidden payload.
- **Embedding** — modifying redundant bits without perceptible change.
- **Undetectability** — resisting statistical steganalysis is the primary goal.
- **Capacity and robustness trade-offs** — more payload risks easier detection.
- **Combination with encryption** — layered protection of the hidden content.

### Applications

- Covert communication and information hiding.
- Digital watermarking and copyright marking of media.
- Embedding metadata invisibly in files.
- Privacy-preserving messaging in adversarial environments.

### Provenance

