A product distributor is a business that buys products, usually in quantity from manufacturers, and resells them without making them itself. APICS, quoted in the Industrial Ontologies Foundry ontology, calls it a “business that does not manufacture its own products, but purchases and resells these products” and that “usually maintains a finished goods inventory”.[^1]

## Definitions in the sources

The IOF defines a distributor as a person or business organisation when it purchases products from manufacturers and resells them to wholesalers.[^1] Its quotation of CSCMP adds that distributors typically purchase the goods in quantity from the manufacturer and ship to customers in smaller quantities.[^1]

The United Nations ISIC places the same kind of business in a different position. It lists industrial distributors among the merchant wholesalers, that is wholesalers who take title to the goods they sell, together with wholesale merchants, jobbers, exporters, importers and cooperative buying associations.[^2] It defines wholesale as resale without transformation to retailers, to industrial, commercial, institutional or professional users, or to other wholesalers.[^2]

## Scope and distinctions

Sources disagree on where distributors sit. In the IOF a distributor sells to wholesalers, so the distributor lies upstream of the [[Wholesaler]]. In the ISIC an industrial distributor is a kind of wholesaler. This vault records [[Wholesaler]] as a kind of Product Distributor, and uses the broader resale sense, so the IOF's narrower position of the distributor above the wholesaler is not adopted.[^1][^2]

This page is about the trade role. It is not the sense of distributor used in the European Union's artificial intelligence regulation, which is covered by [[Distributor]]. For the retail end of the chain see [[Retailer]].

## What the sources do not establish

Both sources define the term for ontology modelling and for statistical classification, and neither is a legal or contractual definition. No opened source describes exclusive distribution agreements, distributor margins or the legal position of a distributor against an agent. The ISIC also covers wholesale on a fee or contract basis, which involves acting as an agent or broker, and that is not what the IOF means by a distributor.[^2]

[^1]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^2]: United Nations Statistics Division, “International Standard Industrial Classification of All Economic Activities (ISIC), Revision 4”. https://unstats.un.org/unsd/classifications/Econ/Download/In%20Text/ISIC_Rev_4_publication_English.pdf

