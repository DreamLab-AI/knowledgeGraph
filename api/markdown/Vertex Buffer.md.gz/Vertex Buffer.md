A vertex buffer is a region of GPU-accessible memory that stores the attributes of a mesh's vertices, such as positions, normals, texture coordinates and colours, in a contiguous layout for the graphics pipeline to consume. By uploading geometry once and referencing it across many draw calls, vertex buffers minimise CPU-to-GPU transfer and enable high-throughput rendering. They are bound to the input-assembler stage and described by a vertex layout that maps buffer bytes to shader inputs.

### Overview

- Vertex buffers keep geometry resident in GPU memory across frames and draw calls.
- A separate index buffer often references the vertex buffer to avoid duplicating shared vertices.
- The vertex layout tells the pipeline how to interpret each vertex's interleaved attributes.

### Key aspects

- Interleaved versus separate attribute layouts and their cache behaviour.
- Static, dynamic and streaming usage hints for driver-managed memory.
- Binding to the input assembler and feeding the vertex shader.
- Pairing with index buffers and instancing for efficient batching.

### Applications

- Real-time game and simulation rendering.
- AR/VR scene geometry upload.
- Visualisation of meshes and point clouds.

### Provenance

