A robot actuator is an electromechanical, pneumatic, hydraulic, or shape-memory device that converts stored or supplied energy into controlled mechanical motion, forming the effector substrate through which a robotic system exerts forces and displacements on its environment. Actuators are the physical implementation layer between a robot's control system and its mechanical structure, determining the speed, force, precision, and compliance characteristics achievable by the overall system. Modern robot actuators range from high-torque servo motors and linear voice-coil drives to soft pneumatic bellows and piezoelectric micro-actuators, each presenting distinct trade-offs in power density, bandwidth, back-drivability, and safety. The selection and design of actuators is a primary determinant of robot morphology, task capability, and energy efficiency across manipulation, locomotion, and human-collaborative applications.

### Overview

- Robot actuators are the muscles of robotic systems: devices that translate energy into purposeful mechanical work under the direction of a control system. Unlike passive mechanical components, actuators are active elements capable of generating, regulating, and sustaining forces and motions in response to commanded signals.
- **Why actuators matter**: The entire sensorimotor loop of a robot — perceive, plan, act — culminates at the actuator. No matter how sophisticated the [[Robot Motion Planning]] or [[Feedback Control]] algorithms are, the robot's physical capability is bounded by what its actuators can deliver in terms of speed, force, precision, and energy efficiency.
- **Energy conversion pathways**: Actuators accept electrical, pneumatic, hydraulic, or thermal energy and convert it through electromagnetic, fluid-mechanical, piezoelectric, or thermoelastic transduction principles into rotary or linear mechanical output.
- **Control interface**: Actuators are driven by [[Motor Driver]] or valve-control electronics, receive position/velocity/torque setpoints from the [[Robot Controller]], and close the loop via [[Encoder]] or [[Position Sensor]] feedback at rates from hundreds to tens of thousands of hertz.
- **Maturity**: Electromechanical actuators (servo motors, stepper motors, linear drives) are a well-established mature technology underpinning industrial automation for decades. Emerging variants (series-elastic, hydraulic variable-stiffness, shape-memory alloy) continue to expand the design space.

### Key Actuator Technologies

- **Rotary Electric Motors**
  - Brushless DC (BLDC) motors: dominant in industrial manipulators and [[Collaborative Robot]] platforms; high power density, precise torque control via field-oriented control (FOC).
  - Permanent-magnet synchronous motors (PMSMs): used where highest torque density and efficiency are needed.
  - Stepper motors: open-loop position control for lower-cost or low-load applications; common in CNC and small service robots.
- **Gear Transmissions and Reduction**
  - [[Gear Transmission]] stages (harmonic drives, cycloidal reducers, planetary gearboxes) multiply motor torque and reduce speed to joint-level requirements.
  - Harmonic drives: extremely low backlash, high reduction ratios in compact form; dominant in precision industrial arms (e.g. KUKA, Fanuc, ABB).
  - Cycloidal reducers: higher shock-load tolerance; increasingly common in collaborative and legged robots.
  - Direct-drive: eliminates gearing entirely to maximise back-drivability and bandwidth; used in [[Direct Drive Actuation]] research platforms (MIT Cheetah, Unitree).
- **Hydraulic Actuators**
  - [[Hydraulic Cylinder]] and rotary hydraulic motors: deliver the highest force-to-weight ratio; used in heavy industrial robots, [[Exoskeleton]] platforms, and legged robots operating in unstructured terrain (Boston Dynamics Atlas historically).
  - Require hydraulic power units (HPUs), fluid lines, and sealing — adds system complexity and maintenance burden.
- **Pneumatic Actuators**
  - [[Pneumatic Actuator]]: air-driven cylinders or rotary vane motors; fast, lightweight, inherently compliant; widely used in pick-and-place gripper applications and [[Soft Robotics]] artificial muscles (McKibben actuators, bellows).
  - Compressibility of air limits stiffness and precise position control without additional sensing.
- **Piezoelectric Actuators**
  - [[Piezoelectric Actuator]]: exploit crystal deformation under applied voltage; nanometre-resolution, very high bandwidth, but extremely small stroke (micrometres); used in micromanipulation, optical alignment, and vibration cancellation.
- **Shape-Memory and Smart-Material Actuators**
  - Shape-memory alloys (SMAs), electroactive polymers (EAPs), and dielectric elastomers offer muscle-like actuation with high energy density but lower efficiency and bandwidth; active area in [[Soft Robotics]] and wearable [[Exoskeleton]] research.
- **Series Elastic Actuators (SEAs)**
  - [[Series Elastic Actuation]]: a compliant spring element is inserted in series between the motor and load, enabling accurate torque sensing and control, shock absorption, and safer [[Human Robot Interaction]]; pioneered at MIT and widely adopted in collaborative and rehabilitation robots.

### Actuator Performance Metrics

- **Torque/force density**: output torque (Nm) or force (N) per unit mass (kg); critical for mobile and aerial robots.
- **Bandwidth**: the frequency at which the actuator can faithfully track torque or position commands; limited by inertia, friction, and electronics.
- **Back-drivability**: the ease with which the load can move the actuator output; high back-drivability enables compliant, safe [[Human Robot Interaction]]; low back-drivability (harmonic drives) provides holding torque at rest.
- **Efficiency**: ratio of mechanical output to electrical input; losses arise from winding resistance, iron losses, friction, and gear mesh.
- **Repeatability and resolution**: governed by [[Encoder]] resolution and control loop latency; sub-micron resolution achievable with piezoelectric or voice-coil drives.
- **Thermal limits**: continuous and peak torque ratings constrained by motor winding temperature; thermal management is a key design constraint.

### Applications and Use Cases

- **Industrial Manipulation**
  - Six-degree-of-freedom articulated arms (KUKA, Fanuc, ABB) use harmonic-drive + BLDC actuator stacks at each joint for high-repeatability pick-and-place, welding, and assembly.
  - SCARA robots use a combination of rotary and linear actuators for fast, planar assembly tasks.
- **Collaborative Robotics (Cobots)**
  - [[Collaborative Robot]] platforms (Universal Robots UR series, Franka Emika) embed torque sensors or [[Series Elastic Actuation]] at each joint to enable compliant, force-limited [[Human Robot Interaction]] without safety cages.
- **Legged and Mobile Robots**
  - [[Robot Locomotion]] in legged robots (Boston Dynamics Spot, Unitree Go) requires high-bandwidth, back-drivable actuators capable of impact rejection; direct-drive or quasi-direct-drive designs are favoured.
  - Wheeled and tracked mobile robots use electric hub motors or differential drive actuator pairs.
- **Surgical and Medical Robotics**
  - Da Vinci surgical systems use miniaturised cable-driven actuators for tremor filtering and precise microsurgical manipulation.
  - Rehabilitation [[Exoskeleton]] devices rely on compliant actuators to assist patient-initiated movement without imposing rigid trajectories.
- **Soft Robotics and Grippers**
  - [[Soft Robotics]] grippers use pneumatic bellows or SMA wires to achieve delicate, adaptive grasping of fragile objects without rigid contact.
  - [[Robot End-Effector]] designs span rigid parallel grippers, underactuated adaptive hands, and fully soft continuum manipulators.
- **Space and Extreme Environments**
  - NASA and ESA rover actuators must operate across extreme temperature ranges (−120 °C to +70 °C on Mars surface) with radiation-hardened [[Embedded System]] and brushless motors for long service life.
- **Micro and Nano Robotics**
  - [[Piezoelectric Actuator]] stacks enable sub-micron positioning in atomic force microscopes, electron-beam lithography systems, and MEMS-scale fabrication.

### Standards and Context

- **ISO 9283** — Manipulating Industrial Robots: Performance Criteria and Related Test Methods. Defines repeatability, accuracy, and dynamic performance metrics applicable to actuated robot joints.
- **ISO 10218** — Robots and Robotic Devices: Safety Requirements for Industrial Robots. Governs actuator force and speed limits in collaborative workspaces.
- **IEC 61800** — Adjustable Speed Electrical Power Drive Systems. Covers servo drive and variable-speed motor control electronics used to command actuators.
- **IEEE RAS (Robotics and Automation Society)** — publishes *IEEE Transactions on Robotics* and hosts the ICRA and IROS conferences where actuator design research is disseminated.
- **ROS (Robot Operating System)** — the dominant middleware layer for [[Robot Controller]] software; the `ros_control` and `ros2_control` stacks provide hardware abstraction interfaces for heterogeneous actuator types, enabling [[Robot Motion Planning]] pipelines to remain actuator-agnostic.
- **URDF (Unified Robot Description Format)** — XML schema used within ROS ecosystems to specify joint actuator limits, inertia, and transmission ratios for simulation and [[Feedback Control]] tuning.
- **Machine Learning integration**: Reinforcement learning and learning-from-demonstration approaches increasingly train policies that operate directly on actuator torque commands (e.g. OpenAI / Boston Dynamics work on motor skill learning), bridging [[Machine Learning]] with low-level actuator control.

### Design Trade-offs and Emerging Directions

- **Stiffness vs. compliance**: Rigid high-reduction-ratio actuators maximise position accuracy but create safety hazards in human proximity; compliant designs ([[Series Elastic Actuation]], variable-stiffness actuators) sacrifice some precision for safer, more robust interaction.
- **Power density vs. thermal management**: Maximising torque from small motors requires high current densities that generate heat; liquid cooling, advanced winding materials, and silicon-carbide (SiC) [[Power Electronics]] are enabling higher continuous power ratings in compact form factors.
- **Proprioceptive sensing**: Direct-drive and quasi-direct-drive designs exploit motor current as a proxy for joint torque (proprioception), enabling whole-body dynamic control without external [[Position Sensor]] arrays.
- **Integrated mechatronics**: Modern actuator modules (Dynamixel, T-Motor, Myactuator) integrate motor, [[Gear Transmission]], [[Encoder]], and [[Motor Driver]] into a single compact unit with a serial bus interface, dramatically reducing integration complexity for research platforms and [[Collaborative Robot]] designs.
- **Continuum and tendon-driven systems**: Cable-driven and tendon-based transmissions decouple the motor mass from the distal link, reducing limb inertia; used in dexterous robotic hands, [[Exoskeleton]] orthoses, and surgical robots.
- **AI-driven actuator control**: [[Machine Learning]] approaches (model-based RL, neural network inverse dynamics) are beginning to replace classical [[PID Control]] for actuators operating in highly nonlinear or time-varying regimes, particularly in [[Soft Robotics]] where analytic models are intractable.

### Current Landscape (2026)

- The 2023-2026 period settled the electric-versus-hydraulic debate: Boston Dynamics, Tesla, Figure AI, Unitree and UBTECH have all standardised on electric actuation, with Boston Dynamics' fully electric Atlas Gen 2 (2023) marking the industry's clearest break from the hydraulic era.
- Quasi-direct-drive (QDD) architectures - a high-torque frameless BLDC/PMSM motor paired with a low-ratio (roughly 5:1-20:1) cycloidal or planetary gearbox plus integrated current-sensing - became the dominant commercial joint design, delivering 100-200 Nm/kg torque density and 1-2 kHz torque-control bandwidth without external force sensors.
- Actuators now dominate humanoid economics: McKinsey (April 2026) puts them at 40-60% of the bill of materials, and Tesla states around 56% of Optimus's BOM sits in its actuators; Tesla's Optimus Gen 3 (full-body production targeted for summer 2026) reportedly carries about 50 actuators, using frameless-motor + harmonic-drive rotary joints and planetary-roller-screw linear actuators.
- Supply and cost pressure intensified: Unitree's G1 listed from roughly $13,500-$16,000 (and $17,990 on Amazon US in February 2026) while shipping 5,500+ units in 2025, and on 30 July 2026 Tesla's Ashok Elluswamy revised Optimus's long-term annual capacity target to 10 million units; Unitree began its STAR Market IPO process in August 2026.
- The frameless-motor and reducer supply chain is scaling and shifting toward Chinese vendors: HDIN Research sizes the 2026 frameless-motor market at roughly $0.9-3.6bn (8-16% CAGR to 2031), while harmonic-drive makers Leaderdrive and Laifu expand capacity against Japan's Harmonic Drive Systems and Shinpo, with Suzhou Green Harmonic supplying Tesla.
- Power-electronics integration is a live 2025-2026 frontier: joint modules increasingly embed GaN or SiC field-oriented-control servo drives directly behind the motor (GaN for fingers/wrists, SiC for hip/knee/torso), with the robot servo-drive segment valued at about $1.65bn in 2024 and forecast to reach $4.39bn by 2032.
- Open challenges as of 2026: driving per-joint actuator cost below roughly $500 (from $500-2,000 today) to hit $20,000-30,000 unit economics; harmonic-drive fragility under backdriving shock loads (for example when a robot falls); rare-earth magnet supply risk ahead of a suspension expiring 10 November 2026; and battery-limited runtimes of roughly 2-8 hours.

### References

- 1. Biped.news (2026). Humanoid Robot Actuators Explained: Why Quasi-Direct Drive Won. https://biped.news/article/humanoid-robot-actuators-explained
- 2. McKinsey & Company (2026). Turning humanoid supply chain constraints into billion-dollar wins. https://www.mckinsey.com/industries/industrials/our-insights/turning-humanoid-supply-chain-constraints-into-billion-dollar-wins
- 3. Optimusk (2026). Tesla Optimus Hardware: Actuators, Hands & Sensors (2026). https://optimusk.blog/blog/tesla-optimus-hardware-specs/
- 4. Patsnap (2026). Humanoid Robots in 2026: Chips Are 5% of the Problem. https://www.patsnap.com/resources/blog/articles/humanoid-robots-in-2026-chips-are-5-of-the-problem/
- 5. WhyChips (2026). SiC Servo Drives: Shrinking Humanoid Robot Joints in 2026. https://whychips.com/sic-servo-drives-shrinking-humanoid-robot-joints-in-2026/
- 6. HDIN Research (2026). The Global Frameless Motor Market 2026. https://www.hdinresearch.com/news/991

### Provenance

