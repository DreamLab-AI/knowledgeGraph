Road freight is the carriage of goods by road in goods road vehicles, which the Glossary for transport statistics defines as road vehicles designed, exclusively or primarily, to carry goods.[^1]

That glossary treats heavy goods road vehicles as those with a gross vehicle weight above 3 500 kg, designed to carry goods, and its list of goods road vehicles also includes road tractors, trailers and semi-trailers.[^1] It defines a road goods transport enterprise as a road transport enterprise offering and performing services in the transport of goods.[^1] Eurostat defines national road freight transport as road transport between two places, a place of loading and a place of unloading, in the same country by a vehicle registered in that country, and international road freight as transport between two places in different countries irrespective of where the vehicle is registered.[^2]

## Scale

In 2024 road moved 82% of UK domestic freight, 168 billion tonne-kilometres, and 1.59 billion tonnes of goods were lifted in the UK by GB-registered heavy goods vehicles.[^3] The Department for Transport notes that a methodology change in road freight data in 2021 means data before and after 2021 should not be compared.[^3] In the EU road had 25.7% (1 821 billion tonne-km) of freight transport performance in 2024, after an increase of 0.4 percentage points on 2023.[^4]

## Links to other modes

The Department for Transport defines an inter-modal road freight journey as a heavy goods vehicle journey where a different mode of transport is used to transfer goods to or from the vehicle. Such journeys accounted for 8% (122 million tonnes) of the goods lifted by domestic road freight in 2024, and 71% of those goods were carried on journeys that began or ended at a shipping dock.[^3]

## Scope and distinctions

Road Freight is a [[Freight Transport Mode]]. Related pages are [[Intermodal Transport]], [[Autonomous Vehicle]] and [[Electric Vehicle]].

## What the sources do not establish

Sources opened here give no cost, emissions or driver-supply figures for road freight. The UK and EU shares are for different territories and scopes, and the page does not combine them.

[^1]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^2]: Eurostat, Statistics Explained, “Glossary:Road freight transport”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Road_freight_transport
[^3]: UK Department for Transport (GOV.UK), “Transport Statistics Great Britain: 2024 Freight”. https://www.gov.uk/government/statistics/transport-statistics-great-britain-2025/transport-statistics-great-britain-2024-freight
[^4]: Eurostat, Statistics Explained, “Freight transport statistics - modal split”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Freight_transport_statistics_-_modal_split

