Goods receiving is the warehouse activity of unloading inbound products from the transport carrier, recording their arrival and inspecting them for quantity or quality problems.[^1]

A literature review of order picking says the receiving activity includes the unloading of products from the transport carrier, updating the inventory record, and inspection to find whether there is any quantity or quality inconsistency.[^1] Georgia Tech's open textbook says receiving may begin with advance notification of the arrival of goods, which lets the warehouse schedule receipt and unloading. Once the product has arrived it is unloaded and possibly staged for put away, is likely to be scanned to register its arrival, and is inspected, with exceptions such as damage, incorrect counts or wrong descriptions noted.[^2]

## Examples of procedure

A Texas A&M University procedure for its central receiving office describes inspection immediately after receipt, including a careful comparison of the number of pieces received with the number listed on the freight bill, with any shortage or damage noted on the freight bill before it is signed and the carrier released.[^3] An eCampusOntario logistics text describes the Amazon steps of receive, stow, and pick: receive takes the product from suppliers, and stow scans it, checks it for damage and places it in storage.[^4]

## Scope and distinctions

Goods receiving is a [[Warehouse Operation]] and is followed by put-away and storage, covered at [[Warehouse Storage System]]. The Georgia Tech text says a storage location must be determined before put-away.[^2] The customs aspect of receiving, for goods entering a customs warehouse, is covered at [[Bonded Warehouse]].

## What the sources do not establish

Sources describe practice in one university office and one textbook; they do not show how receiving is done in different industries. The Georgia Tech textbook gives a cost share for receiving, which is not used here because it comes from older studies cited by that text.

[^1]: René de Koster, Tho Le-Duc and Kees Jan Roodbergen, European Journal of Operational Research 182(2), 2007, “Design and control of warehouse order picking: A literature review”. https://pure.eur.nl/ws/portalfiles/portal/46713708/DesignandControl_2007.pdf
[^2]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^3]: Texas A&M University, Logistics, Central Receiving, “Receiving Procedures”. https://logistics.tamu.edu/central-receiving/receiving-procedures.html
[^4]: eCampusOntario Pressbooks (Introduction to Logistics), “Chapter 5 – Warehousing”. https://ecampusontario.pressbooks.pub/logistics001oerfc/chapter/chapter-5-warehousing/

