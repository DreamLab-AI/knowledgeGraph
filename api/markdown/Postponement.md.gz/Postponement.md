Postponement is a supply chain strategy of delaying the final configuration or movement of products and services for as long as possible, until demand is known.[^1]

According to a Brazilian literature review, the term entered the marketing literature with Alderson in 1950. The review calls the delay of a product's movement time postponement and the delay of its differentiation form postponement.[^1] Yang, Burns and Backhouse review the literature and report that the need for postponement is driven by the market and business environment, yet its applications are not as widespread as expected.[^2] In a second paper they widen the concept to product development, purchasing, production and logistics postponement, and present these strategies as ways to cope with different levels of uncertainty.[^3]

## In the supply chain

Christopher and Towill describe a decoupling point created with “strategic inventory”: stock is held in generic or modular form, and final assembly or configuration is completed only when the precise customer requirement is known. They give the customised PC as an example.[^4] With postponement, they write, companies can use lean methods up to the decoupling point and agile methods beyond it.[^4] They also repeat the point of Pagh and Cooper that satisfying customer demand may require particular combinations of postponed manufacture and postponed logistics.[^4]

See [[Customer Order Decoupling Point]], [[Lean Supply Chain]], [[Agile Supply Chain]] and [[Assemble-to-Order]].

## What the sources do not establish

Two White Rose records give abstracts only, and the abstract of the review says that its applications are not as widespread as expected, so this page makes no claim about the size of any benefit.[^2] The Alderson attribution and the form and time distinction rest on one Portuguese-language review, which this page paraphrases.[^1]

[^1]: Karine Araujo Ferreira and Rosane Lucia Chicarelli Alcantara, REBRAE: Revista Brasileira de Estrategia, 2012 (PUCPR), “Postponement: an analysis based on historical perspective literature”. https://periodicos.pucpr.br/REBRAE/article/download/13793/13223
[^2]: Bo Yang, Neil D. Burns and Christopher J. Backhouse, International Journal of Operations and Production Management, 2004 (White Rose Research Online record, abstract only), “Postponement: a review and an integrated framework”. https://eprints.whiterose.ac.uk/id/eprint/6436/
[^3]: Bo Yang, Neil D. Burns and Christopher J. Backhouse, International Journal of Production Research, 2004 (White Rose Research Online record, abstract only), “Management of uncertainty through postponement”. https://eprints.whiterose.ac.uk/id/eprint/6434/
[^4]: Martin Christopher and Denis Towill, International Journal of Physical Distribution and Logistics Management, 2001 (Cranfield repository copy), “An Integrated Model for the Design of Agile Supply Chains”. https://dspace.lib.cranfield.ac.uk/bitstreams/db14daf6-8518-476e-9211-b6af2f1515a5/download

