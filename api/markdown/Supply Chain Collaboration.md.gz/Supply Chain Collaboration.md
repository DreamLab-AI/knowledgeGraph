A collaborative supply chain consists of two or more independent companies working together to plan and execute supply chain operations with greater success than when performing the same activities individually.[^1]

Marqui, de Moura and Alcantara, citing Simatupang and Sridharan, give that definition and add that collaboration is more than information exchange at the operational level, since it also requires involvement of the tactical and strategic levels across the companies.[^1] Their literature review yields a conceptual model built as a ladder of three steps, running from cooperation through coordination to collaboration, with nine characteristics of the relationship and ten behaviours that the companies should adopt.[^1]

## Elements

Simatupang's thesis offers a framework with five elements of collaboration: a collaborative performance system, information sharing, decision synchronisation, incentive alignment and “streamlined intercompany business processes”.[^2] In a later paper, Sridharan and Simatupang characterise collaborative practice by three factors, decision synchronisation, information sharing and incentive alignment, which enable the chain members to match supply with customer demand.[^3] Their survey of New Zealand companies shows significant positive impacts of these factors on operational performance.[^3] Simatupang's thesis takes supply chain collaboration between retailers and suppliers as its unit of analysis and collects data from a survey of New Zealand companies.[^2] See [[Information Sharing]], [[Collaborative Planning, Forecasting and Replenishment]] and [[Vendor-Managed Inventory]].

## What the sources do not establish

Mamad and Ouazzani, in a study of the Moroccan automotive sector, state that there is no consensus on the definition of collaboration, citing Soosay and colleagues, and that collaboration has several degrees of intensity.[^4] The framework and the survey evidence come from the same authors and from New Zealand companies, so they are one research line rather than independent confirmation.[^2][^3]

[^1]: Angela Cristina Marqui, Karina Sacilotto de Moura and Rosane Lucia Chicarelli Alcantara, Aston University repository copy, “Collaborative supply chain: a conceptual model for operationalisation”. https://publications.aston.ac.uk/id/eprint/32737/1/Collaborative_supply_chain.pdf
[^2]: Togar M. Simatupang, Massey University doctoral thesis, 2004 (Massey Research Online), “Supply Chain Collaboration”. https://mro.massey.ac.nz/server/api/core/bitstreams/51ceb2dc-55b4-47f3-bff1-35bc118f5c2b/content
[^3]: Ramaswami Sridharan and Togar M. Simatupang, Gadjah Mada International Journal of Business, 2009, “Managerial Views of Supply Chain Collaboration: An Empirical Study”. https://journal.ugm.ac.id/gamaijb/article/download/5527/4499
[^4]: Mohamed Mamad and Fatima Ouazzani Chahdi, International Journal of Academic Research in Accounting, Finance and Management Sciences, 2013, “Collaboration within the Supply Chain: Perception for the Automotive Industry in Morocco”. https://hrmars.com/papers_submitted/131/Article_25_Collaboration_within_the_Supply_Chain.pdf

