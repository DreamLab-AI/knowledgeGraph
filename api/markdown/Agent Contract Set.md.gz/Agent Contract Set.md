
An agent contract set is the collection of contracts attached to an AI agent, declared as `ContractSet` in the Agent Ontology.[^1] The Agent Ontology declares the class without a definition; this one follows from its properties. visionGraph places it under [[Configuration]], with [[Agent Contract]] as its part.

An [[Agent]] reaches its set through the agent module's `contractualInterfaces` property.[^2] The set relates to its members through `contract`, so it groups the contracts the agent exposes. The contract module describes itself as defining the contractual aspects of an AI agent, and the set is how those aspects are bound to one agent.

Structurally the class mirrors the [[Agent Wallet Set]]: both are thin containers that let an agent declare an interface bundle through a single property, in the same way that an [[Agent Identity Set]] bundles identity bindings.

[^1]: Semantic Agent Communication Community Group, “Contract Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/contract.ttl
[^2]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

