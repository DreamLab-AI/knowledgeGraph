A data exchange format is an agreed structure and encoding for representing data so that it can be reliably transmitted, stored, and interpreted between independent systems. It defines syntax, data types, and often a schema, allowing a producer and a consumer that share no internal code to exchange information without loss of meaning. Common examples include JSON, XML, CSV, and binary formats such as Protocol Buffers, each trading off readability, compactness, and parsing speed.

- A data exchange format is an agreed [[Data Format]] for encoding information so independent systems can transmit and interpret it reliably.
- It implements [[Data Serialization]] and usually carries a [[Schema]] and [[Metadata]] that define structure and meaning.
- Such formats are the substrate of [[Interoperability]] and underpin every [[API]] that moves data between services.

### Overview

- Two systems that share no internal code can still cooperate if they agree on a common exchange format.
- A format specifies syntax, data types, and encoding rules; a schema layered on top constrains valid documents and enables validation.
- Text formats such as [[JSON]] and [[XML]] favour human readability and tooling ubiquity, while binary formats such as [[Protocol Buffers]] favour compactness and parsing speed.
- The choice of format trades off readability, size, schema rigidity, and performance for a given integration.
- Standardised formats reduce bespoke integration effort and lower the cost of connecting heterogeneous systems.

### Key aspects

- Syntax — the grammar that defines well-formed documents.
- Schema — constraints on structure and types that enable validation.
- Encoding — text or binary representation affecting size and speed.
- Versioning — rules that let formats evolve without breaking consumers.
- Self-description — embedded metadata that aids interpretation.

### Applications

- Web APIs exchanging JSON payloads between clients and servers.
- Enterprise integration using XML documents and schemas.
- High-throughput services serialising with Protocol Buffers.
- Bulk tabular data transfer via CSV between analytics systems.

### Provenance

