A supply chain disruption is an event that interrupts or degrades the flow of goods, information or cash through a supply chain, and no source opened here defines the term more precisely than that.[^1][^2]

Christopher and Peck list natural disasters, industrial disputes, terrorism and war as events that have resulted in serious disruptions to supply chain activities, and say that in such situations business as usual is often not an option.[^1] Hendricks and Singhal describe the risk of supply chain disruptions as an indication of a firm's inability to match demand and supply.[^2]

## Consequences reported

Hendricks and Singhal studied 827 disruption announcements made during 1989-2000. Over the period from one year before to two years after the announcement, the average abnormal stock returns of firms that experienced disruptions were nearly -40%, and the evidence indicates that the firms did not quickly recover.[^2] This is a study of announcements by listed firms, so it says little about disruptions that firms do not announce.

The Covid-19 pandemic brought supply chain disruptions that, in the words of the Federal Reserve Bank of New York authors, were never seen before and hampered the trade of goods within and across borders.[^3] Those authors built a single indicator, the Global Supply Chain Pressure Index, because individual measures tend to focus only on selected dimensions of global supply chains.[^3] The index measures pressure on the network, not the occurrence of particular events.

AMRO describes how shipping bottlenecks, together with raw material and input shortages, disrupted trade flows and raised production costs around the world.[^4]

## Types of event

Specific events have their own pages: [[Port Congestion]], [[Chokepoint Disruption]] and [[Component Shortage]]. The causes sorted into risk categories are at [[Supply Chain Risk Type]], and the spread of an event through tiers is at [[Ripple Effect]].

## What the sources do not establish

None of the sources fixes a threshold for when a delay becomes a disruption, or separates disruption from ordinary variability. The Hendricks and Singhal result is from announcements in 1989-2000 and has not been checked here against later studies.

[^1]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^2]: Kevin B. Hendricks and Vinod R. Singhal, working paper, November 2003 (Boston University seminar page), “An Empirical Analysis of the Effect of Supply Chain Disruptions on Long-run Stock Price Performance and Equity Risk of the Firm”. https://questrompublish.bu.edu/ren/Seminar/Vinod%20Singhal/hendricks-singhal%20glitches%20long-term%20stock1.pdf
[^3]: Federal Reserve Bank of New York, Staff Reports no. 1017, May 2022 (Benigno, di Giovanni, Groen and Noble), “The GSCPI: A New Barometer of Global Supply Chain Pressures”. https://www.newyorkfed.org/medialibrary/media/research/staff_reports/sr1017.pdf
[^4]: ASEAN+3 Macroeconomic Research Office (AMRO), Analytical Note, 25 July 2022, “The Great Supply Chain Disruption: What Does the Shipping Crystal Ball Foretell?”. https://amro-asia.org/wp-content/uploads/2022/07/AMRO-Analytical-Note_The-Great-Supply-Chain-Disruption_What-Does-the-Shipping-Crystal-Ball-Foretell-_July-25-2022.pdf

