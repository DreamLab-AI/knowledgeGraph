Cryptocurrency is a class of bearer-style digital assets whose unit ownership, issuance schedule, and transaction history are jointly secured by Public-Key Cryptography and a permissionless Consensus Mechanism operated by a Peer-to-Peer Network of independent nodes, such that no centr...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:PublicKeyCryptography))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:DigitalSignature))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ConsensusMechanism))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:DistributedLedger))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:BlockHeader))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:Transaction))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:Wallet))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:Mempool))

    ## Dependency Relationships
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:requires blockchain:Blockchain))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:requires blockchain:Cryptography))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:requires blockchain:PeerToPeerNetwork))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:requires blockchain:CryptographicHashFunction))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:requires blockchain:SybilResistance))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:Internet))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:EllipticCurveCryptography))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:MiningHardware))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:NodeOperator))

    ## Capability Relationships
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:enables blockchain:PeerToPeerPayment))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:enables blockchain:CensorshipResistance))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:enables blockchain:FinancialInclusion))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:enables blockchain:ProgrammableMoney))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:enables blockchain:SelfCustody))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:enables blockchain:PermissionlessInnovation))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:enables blockchain:CrossBorderTransfer))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:supports blockchain:DecentralisedFinance))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:supports blockchain:SmartContract))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:supports blockchain:Tokenisation))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:supports blockchain:Stablecoin))

    ## Implementation Relationships
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:implements blockchain:DoubleSpendingPrevention))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:implements blockchain:TrustlessSettlement))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:implements blockchain:PredictableIssuanceSchedule))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:implements blockchain:CryptographicOwnership))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:implements blockchain:HardMoneyProperty))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:uses blockchain:SHA256))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:uses blockchain:ECDSA))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:uses blockchain:SchnorrSignature))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:uses blockchain:MerkleTree))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:uses blockchain:BIP32HDWallet))

    ## Reduction Relationships
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:reduces blockchain:CounterpartyRisk))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:reduces blockchain:CensorshipRisk))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:reduces blockchain:CapitalControlFriction))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:reduces blockchain:CrossBorderSettlementLatency))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:reduces blockchain:MonetaryDebasementExposure))

    ## Association Relationships
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:CentralBankDigitalCurrency))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:ElectronicMoney))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:BankDeposit))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:TokenisedDeposit))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:TraditionalSecurity))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:Bitcoin))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:Ethereum))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:Stablecoin))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:SpotBitcoinETF))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:MiCARegulation))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:FCACryptoassetPromotionsRegime))
    SubClassOf(blockchain:Cryptocurrency
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:FATFTravelRule))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(blockchain:hasIdentifier blockchain:Cryptocurrency "BC-0013"^^xsd:string)
    DataPropertyAssertion(blockchain:authorityScore blockchain:Cryptocurrency "0.87"^^xsd:decimal)
    DataPropertyAssertion(blockchain:genesisYear blockchain:Cryptocurrency "2009"^^xsd:integer)
    DataPropertyAssertion(blockchain:whitepaperDate blockchain:Cryptocurrency "2008-10-31"^^xsd:date)
    DataPropertyAssertion(blockchain:genesisBlockDate blockchain:Cryptocurrency "2009-01-03"^^xsd:date)
    DataPropertyAssertion(blockchain:bitcoinTerminalSupply blockchain:Cryptocurrency "21000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:totalAssetClassMarketCapUSD blockchain:Cryptocurrency "3500000000000"^^xsd:integer)

    ## Property Constraints
    SubClassOf(blockchain:Cryptocurrency
      DataMinCardinality(1 blockchain:hasTicker xsd:string))
    SubClassOf(blockchain:Cryptocurrency
      DataMinCardinality(1 blockchain:hasConsensusMechanism xsd:string))
    SubClassOf(blockchain:Cryptocurrency
      DataAllValuesFrom(blockchain:isBearerInstrument xsd:boolean))

    ## Annotations
    AnnotationAssertion(rdfs:label blockchain:Cryptocurrency "Cryptocurrency"@en)
    AnnotationAssertion(rdfs:comment blockchain:Cryptocurrency "Class of bearer-style digital assets whose ownership, issuance, and transaction history are secured by public-key cryptography and a permissionless consensus mechanism operated by a peer-to-peer network, requiring no central monetary authority. Canonical instance is Bitcoin (Satoshi Nakamoto whitepaper 31 October 2008, Genesis Block 3 January 2009), built on Hashcash proof-of-work (Adam Back 1997), b-money proposal (Wei Dai 1998), bit gold (Nick Szabo 1998-2005), and Reusable Proof of Work (Hal Finney 2004). Total asset class market capitalisation reached ~$3-4T at 2024-2025 cycle peak, with subclasses spanning store-of-value monies, smart-contract platforms, stablecoins, memecoins, privacy coins, DePIN, AI tokens, L2 scaling tokens, and DeFi governance tokens. Regulated under EU MiCA (effective 30 December 2024), UK FSMA 2023 with FCA Cryptoasset Promotions Regime (8 October 2023), Singapore MAS Payment Services Act DPT regime, Hong Kong SFC VATP regime, and post-January 2025 favourable US framework under Trump Strategic Bitcoin Reserve EO and Atkins-led SEC."@en)
    AnnotationAssertion(dcterms:identifier blockchain:Cryptocurrency "BC-0013"^^xsd:string)
    AnnotationAssertion(dcterms:subject blockchain:Cryptocurrency "Cryptocurrency, Bitcoin, Ethereum, Stablecoin, Cryptoasset, Digital Asset, Blockchain, Proof of Work, Proof of Stake, MiCA, FCA, Trump Strategic Bitcoin Reserve"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(blockchain:requires)
  AsymmetricObjectProperty(blockchain:enables)
  AsymmetricObjectProperty(blockchain:implements)
  AsymmetricObjectProperty(blockchain:contrastsWith)
  TransitiveObjectProperty(blockchain:dependsOn)
  FunctionalDataProperty(blockchain:genesisYear)
  FunctionalDataProperty(blockchain:whitepaperDate)

## About Cryptocurrency

- **Cryptocurrency** is the defining monetary innovation of the early 21st century: a class of digital bearer assets that combine the censorship-resistance of physical cash with the global reach of internet protocols, removing the requirement for trusted intermediaries — central banks, commercial banks, payment processors, custodians — to mint units, validate ownership, or settle transfers. Unlike traditional electronic money (which is a database entry at a regulated institution) or central bank digital currency (which is a database entry at a central bank), cryptocurrency units are entries on a [[Distributed Ledger]] whose canonical state emerges from cryptographic verification rules executed independently by thousands of mutually-distrusting nodes; ownership is proven by possession of a private key associated with a [[Public-Key Cryptography|public key]] hash that anchors an unspent balance, and transfer occurs by broadcasting a [[Digital Signature|digitally-signed]] transaction that the network's [[Consensus Mechanism]] orders and incorporates into the permanent ledger.
- The intellectual lineage stretches back through the **cypherpunk movement** of the late 1980s and 1990s — Eric Hughes's 1993 *A Cypherpunk's Manifesto*, the cypherpunk mailing list operated 1992-2001 — which articulated the political project of using cryptography to defend individual privacy and economic freedom from state and corporate surveillance. David Chaum's [[DigiCash]] (1989-1998) implemented blind-signature ecash with cryptographic anonymity but required a central issuer and failed commercially. Adam Back's **Hashcash** (1997) introduced [[Proof of Work]] as an anti-spam cost-imposition mechanism whose computational asymmetry — easy to verify, expensive to produce — would later anchor Bitcoin's [[Sybil Resistance|Sybil-resistant]] mining. Wei Dai's **b-money** proposal (1998) sketched a distributed electronic cash system where unforgeable computational work created new monetary units. Nick Szabo's **bit gold** (1998-2005) proposed a chain of proof-of-work computations registered in a Byzantine-tolerant property registry — directly anticipating Bitcoin's architecture but never implemented. Hal Finney's **Reusable Proof of Work (RPOW)** in 2004 implemented transferable PoW tokens running on IBM 4758 secure coprocessors. Each component existed; none combined them into a complete, deployed peer-to-peer electronic cash system.
- The synthesis arrived on **31 October 2008** when a pseudonymous author identified as Satoshi Nakamoto posted *Bitcoin: A Peer-to-Peer Electronic Cash System* to the metzdowd cryptography mailing list. The nine-page paper resolved the [[Double-Spending]] problem (how to prevent a single digital unit being spent twice without a central authority) by combining: (i) a public, append-only [[Blockchain|chain of blocks]] containing transactions; (ii) [[Hashcash]]-style proof-of-work attaching computational cost to each block; (iii) a longest-chain rule by which honest nodes converge on the most-work chain; (iv) economic incentives — block rewards and transaction fees — that reward honest mining and make attack uneconomic; and (v) [[ECDSA]] digital signatures over a [[UTXO]] (Unspent Transaction Output) ledger model. On **3 January 2009 at 18:15:05 UTC** Satoshi mined Block 0 (the **Genesis Block**) with coinbase parameter encoding the headline *"The Times 03/Jan/2009 Chancellor on brink of second bailout for banks"* — a permanent timestamp linking Bitcoin's origin to the global financial crisis. The Genesis Block's 50 BTC reward is unspendable by protocol convention. The first transaction occurred on **12 January 2009** when Satoshi sent 10 BTC to Hal Finney.
- Sixteen years later cryptocurrency has evolved from a curiosity discussed by a few hundred cryptographers into a **$3-4 trillion asset class** during late 2024 / early 2025 cycle peaks (Bitcoin alone exceeding $2T market cap at $109K+ in January 2025), regulated under increasingly comprehensive frameworks in the EU ([[MiCA]] Regulation 2023/1114), United Kingdom (FSMA 2023 + FCA Cryptoasset Promotions Regime), Singapore (MAS Payment Services Act 2019 DPT regime), Hong Kong (SFC VATP regime June 2023), and — following the January 2025 transition — the United States under the Trump administration's Strategic Bitcoin Reserve Executive Order (6 March 2025), the Atkins-led Securities and Exchange Commission, and the repeal of the punitive Staff Accounting Bulletin 121. Spot Bitcoin ETFs launched 10 January 2024 (eleven simultaneous approvals including BlackRock IBIT, Fidelity FBTC, Ark 21Shares ARKB) collectively held over 1.5M BTC by late 2025, representing the most rapid asset-class adoption in ETF history.

### Core Architectural Components

Every cryptocurrency, regardless of specific implementation, instantiates a common set of architectural primitives that collectively solve the **double-spend problem** without a trusted intermediary. The architectural unification of these primitives in Bitcoin (2008-2009) was the central conceptual breakthrough that distinguishes cryptocurrency from prior digital cash proposals — each component existed in isolation by the mid-1990s; only the combination yielded a self-sustaining permissionless monetary network.

**Cryptographic Primitives**: All cryptocurrencies rely on [[Cryptographic Hash Function|cryptographic hash functions]] (typically [[SHA-256]] for Bitcoin, Keccak-256 for Ethereum, Blake2 / Blake3 for newer chains, the Equihash memory-hard family for Zcash, RandomX for Monero) producing fixed-size pseudorandom digests for transaction identifiers, block headers, and Merkle-tree commitments. They rely on [[Elliptic Curve Cryptography]] — secp256k1 (a Koblitz curve over a 256-bit prime field) for Bitcoin/Ethereum [[ECDSA]] signatures, ed25519 (a twisted Edwards curve) for Solana/Cardano/Stellar Ed25519 signatures, BLS12-381 (a pairing-friendly curve) for Ethereum consensus aggregated signatures and zk-SNARK constructions — for [[Digital Signature|asymmetric-key signing]] of transactions and for compact signature aggregation. [[Merkle Tree|Merkle and Merkle-Patricia trees]] cryptographically commit to transaction sets and global state with logarithmic-size inclusion proofs. Hash-based commitments (Pedersen commitments, KZG polynomial commitments) underpin modern ZK rollups.

**Wallets and Key Management**: Modern wallets are organised under **BIP-32 (Hierarchical Deterministic Wallets)** generating arbitrary key trees from a single seed, **BIP-39 (Mnemonic codes)** encoding seeds as 12/24-word phrases from a standardised 2048-word list, **BIP-44 (Multi-account hierarchy)** establishing the m/44'/coin_type'/account'/change/index derivation path. Hardware wallets (Ledger, Trezor, Keystone, BitBox) store keys in secure-element hardware. Multi-signature schemes (Bitcoin n-of-m P2SH/P2WSH, Ethereum Safe formerly Gnosis Safe) require multiple signatures for transaction authorisation. Account abstraction (Ethereum ERC-4337 mainnet March 2023, EIP-7702 Pectra May 2025) decouples on-chain accounts from externally-owned-account signing constraints, enabling smart-contract wallets with custom authorisation logic.

**Ledger Models — UTXO vs Account**: Bitcoin uses the **Unspent Transaction Output (UTXO)** model where wallets hold sets of discrete unspent outputs that are consumed atomically and create new outputs; this maximises parallelism and privacy (each transaction is independent), enables straightforward SPV (Simple Payment Verification) light-client design, and constrains programmability to predicate scripts (Script in Bitcoin, Plutus in Cardano, Aiken). Ethereum uses the **account model** where each address maintains a mutable balance and a nonce, mutated by transactions; this simplifies smart-contract state and global reasoning, supports natural-language balance queries, but introduces transaction-ordering dependencies and replay-protection complexity. Solana uses a hybrid account model with rent accounting and parallel transaction execution via Sealevel. Cardano uses the **Extended UTXO (EUTXO)** model attaching datum/redeemer fields to enable smart contracts while preserving UTXO determinism and pre-execution validation.

**Consensus Mechanisms**: [[Proof of Work]] (PoW) — used by Bitcoin, Litecoin (Scrypt PoW), Dogecoin (Scrypt, merge-mined with Litecoin), Monero (RandomX CPU-bound PoW), Ethereum Classic (Etchash), Kaspa (kHeavyHash), Bitcoin Cash, Bitcoin SV — secures the ledger by requiring miners to solve a computational puzzle (find a nonce such that block-header hash falls below a target), with the heaviest-cumulative-work chain winning ties (the *Nakamoto consensus* rule). [[Proof of Stake]] (PoS) — used by Ethereum since The Merge (15 September 2022, transitioning from Ethash PoW), Solana (PoH+Tower BFT hybrid), Cardano (Ouroboros family designed by Aggelos Kiayias at Edinburgh, formally verified in the 2017 IACR paper), Avalanche (Snow family), BNB Chain (PoSA), Polkadot (Nominated PoS / NPoS), Cosmos (Tendermint BFT), Tezos (Liquid PoS), Algorand (Pure PoS with cryptographic sortition), Aptos and Sui (DiemBFT/Narwhal-Bullshark variants) — replaces computation with economic capital staked as collateral subject to slashing for malicious behaviour. Other variants include Delegated PoS (EOS, Tron), Proof of Authority (private chains), Proof of History (Solana clock), and Proof of Space-Time (Filecoin, Chia).

**Difficulty Adjustment and Issuance Schedule**: Bitcoin's difficulty adjusts every **2016 blocks (~14 days)** to maintain 10-minute average block time, computed from the time taken to mine the previous 2016 blocks. Block subsidy halves every **210,000 blocks (~4 years)**: 50 BTC (2009-2012), 25 BTC (2012-2016), 12.5 BTC (2016-2020), 6.25 BTC (2020-2024), 3.125 BTC (April 2024-2028), with terminal supply ~21M coins reached approximately year 2140 after which miners are compensated solely by transaction fees. Ethereum issuance post-Merge is determined by validator participation rate (target ~0.5-1.0% annual issuance), often **net-deflationary** post-EIP-1559 (1 August 2021 London hard fork) which introduced base-fee burning where the base fee paid by transaction senders is destroyed rather than paid to validators.

**Mempool and Transaction Lifecycle**: Pending transactions accumulate in each node's **mempool** (memory pool) awaiting inclusion. Miners/proposers select transactions by fee priority (Bitcoin: sat/vByte; Ethereum: priority fee tip in gwei). Post-Merge Ethereum introduced **MEV-Boost** and **proposer-builder separation (PBS)** mechanisms allowing block builders to construct profit-maximising blocks (extracting Maximal Extractable Value through arbitrage, liquidations, and sandwich attacks) and proposers to merely select the most-profitable builder bid. MEV extraction reached approximately $700M cumulative on Ethereum mainnet by 2024.

### Categories / Major Families

Cryptocurrency has functionally diversified into at least eleven principal subclasses, each serving distinct economic or technical use cases:

**1. Store-of-Value Monies**: [[Bitcoin Proof-of-Work Protocol]] (BTC) dominates this category with ~50-60% of total cryptocurrency market capitalisation throughout 2024-2025. Bitcoin's value proposition rests on its hard-capped 21M supply, predictable disinflationary issuance schedule, and the highest cumulative proof-of-work security budget of any cryptocurrency (~150-180 exahash/second network hashrate 2024-2025 representing approximately $25-30B in annual mining infrastructure economics). Saifedean Ammous's *The Bitcoin Standard* (2018) formalised the intellectual case for Bitcoin as the apex monetary commodity superior to gold under Austrian School analysis.

**2. General-Purpose Smart-Contract Platforms**: [[Ethereum]] (ETH, market cap ~$300-450B 2024-2025) pioneered Turing-complete on-chain computation via the Ethereum Virtual Machine (EVM); the **Dencun upgrade** (March 2024, EIP-4844 proto-danksharding) introduced blob space dramatically reducing rollup data-availability costs; **Pectra** (May 2025, EIP-7702 account abstraction + EIP-7251 validator effective balance increase) further expanded capability. [[Solana]] (SOL, ~$80-100B) optimises for throughput with ~3,000 effective TPS, parallel execution via Sealevel, and the Firedancer validator client (2025) targeting 1M+ TPS theoretical capacity. [[Cardano]] (ADA) runs the formally-verified [[Ouroboros]] family of PoS protocols designed by Aggelos Kiayias at the University of Edinburgh (chief scientist at IOG). Avalanche introduces the subnet architecture for application-specific chains. BNB Chain provides EVM compatibility under Binance ecosystem. Tron dominates USDT volume (low fees, EVM-like). NEAR provides sharding. Aptos and Sui descend from Diem's Move smart-contract language. TON (Telegram Open Network) leverages Telegram's ~900M users. Internet Computer (ICP) implements full-stack on-chain hosting via reverse-gas model.

**3. Stablecoins**: Pegged to fiat reference assets, providing crypto-native dollar exposure with avoided crypto-asset volatility. [[Tether]] USDT (~$130B+ market cap late 2024/2025, Bitfinex-affiliated issuer with Cantor Fitzgerald custody relationship and NYDFS-regulated USDT0 separate issuance for institutional flows) dominates global stablecoin supply, particularly on Tron and Ethereum. [[Circle USDC]] (~$40B+, post-IPO June 2025 NYSE:CRCL) emphasises regulatory compliance and audited reserves at BlackRock-managed Treasury portfolio. [[Ethena]] USDe implements a delta-hedged synthetic dollar via perpetual basis trading. [[MakerDAO]] DAI (transitioning to USDS under the Endgame plan / Sky brand) provides crypto-collateralised decentralised stablecoin. [[PayPal PYUSD]] launched August 2023 on Ethereum (issued by Paxos). [[Ripple RLUSD]] launched December 2024 on Ethereum and XRP Ledger.

**4. Memecoins**: Cultural/attention-driven tokens with minimal underlying technical innovation. [[Dogecoin]] (DOGE, the original 2013 Litecoin fork by Billy Markus and Jackson Palmer, supported by Elon Musk advocacy 2020-2025), [[Shiba Inu]] (SHIB), [[Pepe]] (PEPE), dogwifhat (WIF), Bonk (BONK), Official Trump ($TRUMP, launched 17 January 2025 three days before Trump's inauguration, peaked at ~$73B fully-diluted valuation within 48 hours), Melania ($MELANIA, launched 19 January 2025). The Solana memecoin launchpad **pump.fun** democratised token creation with graduation thresholds to Raydium AMM liquidity, generating ~$500M+ cumulative fee revenue 2024-2025.

**5. Privacy Coins**: [[Monero]] (XMR) uses ring signatures + RingCT (Ring Confidential Transactions) + Stealth Addresses + optional Tor/I2P transport to provide default-on transaction privacy unlinkable to specific senders, receivers, or amounts. [[Zcash]] (ZEC) uses zk-SNARK shielded pools (Sapling upgrade October 2018, Halo Arc 2022) for optional shielded transactions; ZEC underwent its first halving in November 2024 with Zcash Community Grants (ZCG) replacing the founders' reward. Privacy coins have been progressively delisted from major exchanges under FATF Travel Rule pressure.

**6. DePIN (Decentralised Physical Infrastructure Networks)**: Tokens that incentivise provision of real-world infrastructure. [[Render Network]] (RENDER, token migrated from RNDR on Ethereum to RENDER on Solana 2023) coordinates distributed GPU rendering. [[Filecoin]] (FIL) incentivises decentralised storage with verifiable proofs (PoSt — Proof of Spacetime, PoRep — Proof of Replication). [[Helium]] (HNT) initially built LoRaWAN IoT network, pivoted to mobile (Helium Mobile) in 2023 via partnership with T-Mobile. IoTeX (IOTX) provides DePIN middleware. Akash (AKT) decentralises GPU and CPU compute. Hivemapper (HONEY) crowdsources street-imagery mapping. DIMO incentivises connected-vehicle data. Geodnet provides decentralised RTK GNSS positioning.

**7. AI Tokens**: Tokens associated with AI / machine-learning protocols. [[Bittensor]] (TAO) operates a subnet incentive market where validators score model outputs and miners stake to provide inference services. Fetch.ai (FET), SingularityNET (AGIX), and Ocean Protocol (OCEAN) announced merger into the **Artificial Superintelligence Alliance (ASI)** in March 2024 (voted April 2024) though final consolidation was partially restructured. Worldcoin (WLD, by Sam Altman's Tools for Humanity) uses biometric iris-scanning orbs to issue proof-of-personhood credentials.

**8. Gaming and Metaverse Tokens**: Axie Infinity (AXS) pioneered play-to-earn gaming during 2021 with peak Philippines/Vietnam grass-roots adoption. The Sandbox (SAND), Decentraland (MANA), Immutable (IMX), and Beam provide gaming-specific L1/L2 infrastructure.

**9. L2 Scaling Tokens**: Tokens of layer-2 scaling solutions inheriting security from Ethereum (or other L1s). [[Polygon]] (POL, completed migration from MATIC September 2024 to support multi-chain Polygon 2.0 vision), [[Optimism]] (OP, Optimism Stack underpins Coinbase Base, Worldcoin, and the Superchain), [[Arbitrum]] (ARB, largest Ethereum L2 by TVL throughout 2024-2025), [[Starknet]] (STRK, Cairo-based ZK rollup by StarkWare), [[zkSync]] (ZK token issued June 2024), Base (Coinbase L2, notably has no native token), Scroll, Linea (ConsenSys), Mantle (MNT), and Blast (BLAST).

**10. Liquid-Staking and Restaking Tokens**: Lido (LDO governance, stETH liquid-staked Ether) dominates Ethereum staking with ~28-30% of staked ETH. Rocket Pool (RPL, rETH). EigenLayer enables **restaking** — reusing staked ETH economic security to validate additional protocols (Actively Validated Services / AVSs), pioneering a major 2024 primitive. EtherFi (ETHFI), Renzo (REZ), Kelp DAO (KEP) provide liquid restaking tokens (LRTs).

**11. DeFi Governance Tokens**: Uniswap (UNI, governance of largest decentralised exchange protocol, Uniswap V4 January 2025 with hooks architecture), Aave (AAVE, lending protocol, founder Stani Kulechov UK-based), Curve (CRV, stable-asset AMM), Compound (COMP), Maker / Sky (MKR / SKY), Synthetix (SNX). Hyperliquid (HYPE) airdropped November 2024 became one of largest perp-DEX token launches.

### Market Structure

Cryptocurrency markets operate across three distinct venue categories with progressively different regulatory treatment:

**Centralised Exchanges (CEX)**: Custodial venues operating order books with fiat on/off ramps. [[Binance]] (largest by spot volume globally, Changpeng Zhao guilty plea November 2023, $4.3B US settlement, Richard Teng appointed CEO; Binance withdrew UK retail October 2023 following FCA action against Binance Markets Limited June 2021), [[Coinbase]] (NASDAQ:COIN, listed April 2021, ~$400B quarterly volume Q4 2024, dominant US-regulated CEX, custodies ~85-90% of US spot Bitcoin ETF holdings via Coinbase Custody), Kraken (US-headquartered, IPO speculation 2025), OKX, Bybit (suffered $1.4B Lazarus Group hack February 21 2025 — largest crypto exchange theft in history), Upbit (Korea dominant by domestic volume), KuCoin, Bitget, Gate.io, MEXC.

**Decentralised Exchanges (DEX)**: Smart-contract-based venues with non-custodial settlement. **Uniswap** V4 launched January 2025 introducing hooks (custom logic at swap/liquidity events), maintains dominant Ethereum AMM share. **Curve Finance** specialises in stable-asset and like-asset pools. **Jupiter** aggregates Solana DEX liquidity (Raydium, Orca, Meteora). **Raydium** operates Solana AMM with concentrated liquidity. **Aerodrome** (Velodrome fork on Base) dominates Coinbase L2 liquidity. **dYdX v4** migrated to Cosmos sovereign chain for perpetual futures. **Hyperliquid** (HYPE token) emerged as leading on-chain perp DEX through 2024-2025.

**Derivatives Venues**: CME Group (largest regulated Bitcoin/Ether futures and options venue serving US institutional clients), Binance Futures, OKX, Bybit, Deribit (dominant crypto options), and on-chain perpetual venues (dYdX, Hyperliquid, Aevo, Drift, GMX).

**Custody**: Coinbase Custody (NYDFS-regulated trust, dominant US-regulated institutional custodian), [[Anchorage Digital]] (first OCC national trust charter for crypto January 2021), [[Fireblocks]] (MPC-based custody, ~$8B Series E valuation 2022), [[BitGo]], BNY Mellon Digital Asset Custody (launched 2022), [[Standard Chartered Zodia]] (UK-headquartered crypto custodian, JV with SBI Holdings and Northern Trust), [[Komainu]] (Nomura JV with Ledger and CoinShares). UK-incorporated **Copper.co** provides institutional custody and ClearLoop off-exchange settlement.

**Market Makers and OTC Desks**: Jump Crypto (Jump Trading subsidiary), Wintermute (London-headquartered, founded by Evgeny Gaevoy), Cumberland (DRW), GSR Markets (London), Flow Traders (Amsterdam, listed Euronext), B2C2 (London, acquired by SBI Holdings 2020), Galaxy Digital (Mike Novogratz), Falcon X, Genesis Trading (Chapter 11 January 2023 subsequently restructured), Amber Group, FalconX. London is one of two global centres (alongside New York) for institutional crypto OTC trading, with Wintermute, GSR, B2C2 and Galaxy UK constituting a meaningful concentration.

**Indices and Benchmarks**: CoinDesk Indices (formerly TradeBlock), Bloomberg Galaxy Crypto Index (BGCI), CME CF Bitcoin Reference Rate (BRR — the NY-time settlement rate referenced by CME futures and many ETFs), Compass Crypto indices, MarketVector, Bitwise indices. Pricing aggregators CoinGecko (Singapore-based) and CoinMarketCap (acquired by Binance 2020) provide widely-referenced free pricing data.

### Regulatory Landscape

The 2023-2025 period saw the most significant cryptocurrency regulatory consolidation since the 2017 ICO era, transitioning the asset class from a regulatory grey zone to comprehensive legal frameworks across major jurisdictions:

**European Union — Markets in Crypto-Assets Regulation (MiCA)**: Regulation (EU) 2023/1114 of 31 May 2023 establishes the world's first comprehensive cryptocurrency regulatory framework. Titles III and IV (covering Asset-Referenced Tokens / ART and E-money Tokens / EMT — i.e. stablecoins) became applicable on **30 June 2024**, requiring stablecoin issuers to maintain 1:1 reserves, redemption rights, and obtain authorisation in an EU member state. Titles I-II and V-VII (covering crypto-asset service providers — CASPs — and other crypto-assets) became applicable on **30 December 2024**. The Title V CASP authorisation regime covers ten distinct services: custody, exchange, execution, portfolio management, advice, transfer, placement, reception/transmission, trading, and exchange against fiat. A transitional regime extends to 1 July 2026 for incumbents transitioning from national regimes. National competent authorities including BaFin (Germany), AMF (France), CSSF (Luxembourg), Banco de España, and CONSOB (Italy) handle authorisations.

**United Kingdom — FSMA 2023, FCA Cryptoasset Promotions Regime, Crypto Roadmap**: The **Financial Services and Markets Act 2023** received Royal Assent on 29 June 2023; Section 22(1A) extends the FCA regulatory perimeter to cryptoassets, enabling future designated activities. The **FCA Cryptoasset Financial Promotions Regime** went live on 8 October 2023 — qualifying cryptoassets became controlled investments under FSMA 2000 Section 21, requiring promotions to retail UK consumers to be issued or approved by an FCA-authorised firm (or fall under specific exemptions). FCA Consumer Duty applies to crypto firms in scope. **FCA Discussion Paper DP23/4** (November 2023) and **Consultation Paper CP24/4** (July 2024) established the framework for UK fiat-backed stablecoin regulation. The **FCA Crypto Roadmap** published November 2024 sequences delivery of the UK comprehensive crypto regime targeting full Designated Activities Regime implementation across 2025-2026 covering CASPs, stablecoins, lending, staking, and market abuse rules.

**United States — Post-January 2025 Transition**: **SEC Chair Gary Gensler resigned 20 January 2025** ending the enforcement-led approach that produced 80+ crypto enforcement actions 2021-2024. **Paul Atkins** confirmed as SEC Chair April 2025, generally crypto-favourable. The Trump administration issued the **"Strengthening American Leadership in Digital Financial Technology"** Executive Order on 23 January 2025 and the **Strategic Bitcoin Reserve and US Digital Asset Stockpile** Executive Order on 6 March 2025 (consolidating ~200K forfeited BTC into a permanent strategic reserve, plus other forfeited assets — ETH, XRP, SOL, ADA — into a Digital Asset Stockpile). **SEC Staff Accounting Bulletin 121** (which had required custodied crypto to be reported on bank balance sheets at fair value with corresponding liability) was effectively repealed in January 2025 via SAB 122, restoring the off-balance-sheet treatment normal for custodied securities. **David Sacks** appointed White House AI and Crypto Czar (December 2024). **Senator Cynthia Lummis (R-WY)** and others advanced legislative proposals (Bitcoin Strategic Reserve Act, GENIUS Act stablecoin framework, FIT 21 / Clarity for Payment Stablecoins Act).

**Singapore — MAS Payment Services Act 2019**: Digital Payment Token (DPT) regime regulates exchanges, wallet providers, and OTC desks. **MAS Notice PSN02** (anti-money laundering / countering financing of terrorism) applies. Restrictions on retail crypto marketing in force from 2022. Dominant Asia-Pacific institutional hub.

**Hong Kong — SFC VATP Regime**: Virtual Asset Trading Platform regime under the Securities and Futures Commission live June 2023, licensed VATPs (OSL, HashKey, etc.) serve retail and professional investors. Hong Kong spot Bitcoin and Ether ETFs launched April 2024 (the first in Asia).

**Other Jurisdictions**: Switzerland (FINMA DLT Act, BX Swiss Digital Exchange), UAE (VARA in Dubai, FSRA in Abu Dhabi Global Market), Japan (FSA, JVCEA self-regulatory body, JPYC fiat-backed stablecoin), Korea (FSC Virtual Asset User Protection Act July 2024), Brazil (CVM and BCB joint framework), Australia (ASIC AFSL framework, Treasury crypto licensing reforms 2024-2025).

**FATF Travel Rule (Recommendation 16)**: Cross-jurisdictional requirement that Virtual Asset Service Providers (VASPs) transmit sender/recipient identity for crypto transfers over USD/EUR 1,000 threshold. Implemented via Sumsub, Notabene, Veriscope, and TRP travel-rule networks.

### Key Historical Events

Cryptocurrency's sixteen-year history clusters around several pivotal events that materially shaped the asset class trajectory:

**2008-2009 Genesis**: Satoshi Nakamoto whitepaper 31 October 2008; Bitcoin Genesis Block 3 January 2009; first transaction Satoshi → Hal Finney 12 January 2009.

**2010 First Commercial Transaction**: 22 May 2010 Laszlo Hanyecz purchases two Papa John's pizzas for 10,000 BTC (commemorated annually as Bitcoin Pizza Day). At early 2025 prices those pizzas cost approximately $1B.

**2013-2014 Mt. Gox**: First major exchange collapse. Mt. Gox (Tokyo, operated by Mark Karpelès) at peak ~70% of global Bitcoin volume; collapsed February 2014 after disclosure of 850,000 BTC theft. Rehabilitation distributions resumed in 2024.

**2017 ICO Bubble and Bitcoin First ATH**: Initial Coin Offering (ICO) wave funded ~$30B+ in token sales (EOS $4.1B raised June 2017-June 2018, Telegram Open Network $1.7B subsequently refunded, Tezos $232M July 2017). Bitcoin first ATH ~$19,800 December 2017. ICO bubble collapsed during 2018 "crypto winter" alongside SEC enforcement (DAO Report July 2017 establishing securities-law applicability to most ICOs).

**2020 DeFi Summer and MicroStrategy**: Compound launches COMP governance token June 2020 catalysing DeFi summer (Uniswap UNI airdrop September 2020, Yearn YFI launch July 2020). [[MicroStrategy]] announces first $250M Bitcoin treasury purchase on 11 August 2020, becoming the first publicly-traded operating company to adopt Bitcoin as primary treasury reserve asset — initiating the corporate Bitcoin treasury template subsequently replicated by 120+ companies.

**2021 Cycle Peak**: Bitcoin first crosses $30K January 2021, $40K, $50K, $60K through Q1 2021. Coinbase direct listing on NASDAQ 14 April 2021 (COIN). El Salvador adopts Bitcoin as legal tender 7 September 2021 (President Nayib Bukele, Bitcoin Beach community origin). Bitcoin ATH **$69,000** on 10 November 2021. NFT market peaks Q4 2021 (CryptoPunks, Bored Ape Yacht Club, Beeple's *Everydays: The First 5000 Days* sold at Christie's for $69.3M March 2021).

**2022 Terra-Luna and FTX Cascade**: **May 2022** Terra UST algorithmic stablecoin de-pegged 9-14 May 2022 (de-peg trigger: Curve 4pool migration, large UST sales, reflexive LUNA hyperinflation), destroying ~$60B in UST+LUNA combined market cap. **June 2022** Three Arrows Capital (3AC, Su Zhu and Kyle Davies) liquidated. **July 2022** Voyager Digital Chapter 11 (5 July), Celsius Network Chapter 11 (13 July). **November 2022** FTX collapse — Alameda Research balance sheet leaked 2 November (FTT-heavy), CZ Binance tweet 6 November triggered run, Chapter 11 filed 11 November 2022 ($8B+ customer fund shortfall). Sam Bankman-Fried convicted on seven counts 2 November 2023, sentenced 25 years 28 March 2024. **November-January 2023** BlockFi (28 November 2022) and Genesis Trading (19 January 2023) Chapter 11. **March 2023** Silvergate Bank voluntary liquidation (8 March), Silicon Valley Bank failure (10 March), Signature Bank failure (12 March) — the major US crypto-friendly banking infrastructure collapsed in a single week.

**2024 Spot Bitcoin ETF and Halving**: SEC approved 11 spot Bitcoin ETFs on **10 January 2024** following the August 2023 *Grayscale v. SEC* DC Circuit ruling (which held the SEC's denial of Grayscale's spot ETF conversion was "arbitrary and capricious"). BlackRock IBIT became fastest ETF to $50B AUM in ETF history. **April 2024** Bitcoin fourth halving (12.5 → 6.25 → 3.125 BTC block subsidy at block 840,000). **May 2024** SEC approved spot Ether ETFs. **August 2024** Bitcoin breaks previous ATH peaking $73,737.

**2025 Trump Era**: Bitcoin crosses $100K (early December 2024), $108K (mid-December 2024), $109K+ (January 2025). Trump inauguration 20 January 2025, $TRUMP memecoin launched 17 January 2025. Strategic Bitcoin Reserve EO 6 March 2025. Bybit Lazarus Group hack 21 February 2025 ($1.4B). Stargate AI infrastructure announcement coincides with crypto-favourable policy turn. White House Crypto Summit 7 March 2025 hosting Saylor, CZ, Brian Armstrong (Coinbase), and other industry leaders. David Sacks installed as White House AI and Crypto Czar. SEC drops or pauses multiple ongoing enforcement actions (Coinbase, Robinhood, Uniswap Labs, Consensys cases dismissed or settled). FASB ASU 2023-08 effective fiscal year 2025 onwards, ending impairment-only accounting for corporate Bitcoin holders. Circle (USDC issuer) IPO on NYSE June 2025 (ticker CRCL).

**Notable Failures and Recoveries**: Mt. Gox creditors began receiving partial Bitcoin distributions July 2024 following decade-long civil rehabilitation. FTX bankruptcy estate distributed ~119% recovery (in USD terms) to most creditors by 2024-2025 — counter-intuitive consequence of dollar-denominated claims fixed at November 2022 BTC prices vs subsequent BTC appreciation. Celsius distributions completed 2024. Mt. Gox, FTX, and Genesis Trading collectively distributed approximately $25-30B in customer recoveries 2023-2025, putting historical "lost coins" claims back into circulation.

### Contrasts with Adjacent Monetary Forms

Cryptocurrency's category is sharpened by contrast with adjacent monetary technologies that share some properties but differ in critical respects:

**vs Central Bank Digital Currency (CBDC)**: A [[Central Bank Digital Currency]] is a digital liability of the central bank — operationally a database entry maintained directly or indirectly by the central bank, settled in a permissioned system, with full identity disclosure to issuing authorities and enforcement of capital controls, sanctions, and AML rules. CBDCs contrast with cryptocurrency along five axes: (i) **issuer** (central bank vs network protocol), (ii) **permissioning** (permissioned vs permissionless), (iii) **privacy** (mandatory KYC vs pseudonymous), (iv) **issuance** (discretionary monetary policy vs algorithmic protocol rule), (v) **censorship resistance** (revocable vs cryptographically enforced). Wholesale CBDCs (institutional, e.g. Project Agorá, Project mBridge, Project Mariana) coexist with cryptocurrency in tokenisation pipelines; retail CBDCs (e.g. eCNY, digital euro under design, digital pound under BoE consultation, Sand Dollar Bahamas, eNaira Nigeria, Drex Brazil) compete with cryptocurrency for retail payment use cases.

**vs Electronic Money (E-money)**: [[Electronic Money]] under the EU E-Money Directive (2009/110/EC) and UK Electronic Money Regulations 2011 is a prepaid stored-value claim against an authorised E-money issuer (PayPal Europe, Revolut, Wise, Stripe). Like cryptocurrency, e-money is digitally native; unlike cryptocurrency, it is a regulated liability of a specific issuer with capital adequacy, reserve safeguarding, redemption-at-par, and consumer-protection obligations. Most fiat-backed **stablecoins** would technically fall under e-money rules in EU/UK if not subject to a dedicated regime — and indeed under MiCA Title IV they are classified as E-money Tokens (EMTs) when pegged 1:1 to a single fiat currency.

**vs Bank Deposit and Tokenised Deposit**: A [[Bank Deposit]] is a credit claim against a commercial bank, settled via the central-bank reserve system (RTGS, Fedwire, CHAPS, TARGET2) and protected by deposit-insurance schemes (FDIC US, FSCS UK £85K, EU deposit guarantee €100K). A **[[Tokenised Deposit]]** wraps a bank deposit claim in a blockchain token (J.P. Morgan JPM Coin / Kinexys USD, Citi Token Services, HSBC Orion deposit tokens) preserving the regulated-bank-liability nature while gaining blockchain settlement properties. Tokenised deposits contrast with stablecoins by remaining bank-money (subject to fractional reserve, deposit insurance, banking regulation) rather than fully-reserved e-money or unbacked cryptocurrency.

**vs Traditional Security**: A traditional security (equity share, bond, fund unit) is a legally-defined financial instrument issued by an identifiable entity under securities regulation. Most jurisdictions apply the **Howey test** (or equivalent) — investment of money in a common enterprise with expectation of profits from the efforts of others — to determine whether a cryptoasset is a security. Bitcoin is universally recognised as a commodity (CFTC view, post-2025 US SEC view). Ethereum was declared a non-security by SEC officials (Hinman 2018 speech) and CFTC oversees Ether futures. Most ICO-era tokens issued 2017-2018 were found to be securities under SEC enforcement actions (Telegram TON 2020, Kik 2020, Ripple XRP partial ruling 2023). The 2025 US legislative trajectory (Clarity Act, FIT 21) intends to provide statutory criteria for distinguishing digital commodities from digital securities.

### Use Cases and Functional Roles

Cryptocurrency serves distinct economic and technical functions across user segments:

- **Store of Value / Inflation Hedge**: Bitcoin as digital gold, attractive in jurisdictions with currency debasement (Argentina, Turkey, Lebanon, Venezuela, Zimbabwe) and to institutional treasuries adopting the Saylor framework (MicroStrategy, Metaplanet, Semler Scientific, Trump Strategic Bitcoin Reserve).
- **Cross-Border Payment / Remittance**: Stablecoins (USDT on Tron particularly) enable near-instant cross-border value transfer at fractions of traditional remittance corridor costs. The Western Union/MoneyGram corridor average cost of ~6-7% compares with sub-1% on Tron-USDT for emerging market remittances.
- **Censorship-Resistant Payment**: Cryptocurrency enables payments resistant to government or platform censorship — used by Ukrainian government for war-fund donations (~$100M+ 2022-2024), by Russian citizens evading sanctions, by Iranian dissidents, by Hong Kong protestors, by WikiLeaks following PayPal/Visa/Mastercard 2010 blockade.
- **Programmable Money / Smart Contracts**: ETH and other smart-contract platform tokens enable composable DeFi (lending, AMM trading, derivatives), DAOs (Decentralised Autonomous Organisations), prediction markets (Polymarket reached $9B+ 2024 US election cycle volume), gaming, identity, and tokenisation use cases.
- **Permissionless Capital Formation**: Token issuance enables global capital formation outside traditional securities regulation (subject to applicable laws). ICO era (2017-2018) raised ~$30B+; subsequent fairer launchpad mechanisms (Initial DEX Offerings, Liquidity Bootstrapping Pools, fair launches, airdrops, points systems).
- **Self-Custody and Sovereign Wealth**: Private-key custody enables true self-sovereign asset ownership without intermediary risk. Hardware wallets (Ledger, Trezor) and emerging account-abstraction solutions (smart-contract wallets with social recovery) lower self-custody barriers.
- **Institutional Reserve Asset**: Bitcoin as treasury reserve (MicroStrategy, 120+ corporate adopters) and sovereign reserve (US Strategic Bitcoin Reserve March 2025, El Salvador since September 2021, Bhutan accumulated via hydro-mining).
- **Speculation and Trading**: Most cryptocurrency volume is speculative — derivatives volume exceeded $4T monthly during 2024 peaks across Binance, OKX, Bybit, CME, Deribit, and on-chain perpetual venues.

### Tokenisation and Real-World Asset Integration

Cryptocurrency infrastructure has progressively been adopted by traditional financial institutions to **tokenise real-world assets (RWA)** — wrapping ownership claims to off-chain assets (Treasuries, money market funds, real estate, private credit, equities) as on-chain tokens that inherit blockchain settlement properties. This bridge between traditional finance and crypto-native infrastructure has emerged as the dominant 2024-2025 institutional crypto narrative:

- **BlackRock BUIDL** (BlackRock USD Institutional Digital Liquidity Fund): Launched 20 March 2024 on Ethereum via Securitize. Tokenised cash management fund holding US Treasuries, cash, and repos. AUM exceeded $2.4B by mid-2025, becoming the largest tokenised Treasury product. Investors include Ondo Finance, Ethena, and major DeFi protocols using BUIDL as the reserve asset for synthetic dollars.
- **Ondo Finance OUSG and USDY**: Ondo Short-Term US Government Treasuries token (~$650M AUM by 2025) and USDY yield-bearing dollar token, both backed by short-duration Treasuries.
- **Franklin Templeton FOBXX (BENJI)**: OnChain US Government Money Fund, first SEC-registered tokenised money market fund using a public blockchain (Stellar / Polygon).
- **J.P. Morgan Onyx / Kinexys / JPM Coin**: Permissioned blockchain for institutional repo, FX, and deposit-token settlement. Cumulative intraday repo volume exceeded $1.5T by 2024. Onyx rebranded to **Kinexys** in November 2024.
- **Citi Token Services**: Cash management and trade finance tokenisation for Citi corporate clients.
- **Goldman Sachs Digital Asset Platform (DAP)**: Tokenised bond issuance platform (European Investment Bank tokenised bonds 2023-2024).
- **HSBC Orion**: London-based tokenised bond platform, issued Hong Kong sovereign tokenised green bonds.
- **Mastercard Multi-Token Network (MTN)**: Cross-bank tokenised settlement infrastructure.
- **BIS Project Agorá**: Bank for International Settlements multi-currency tokenised cross-border settlement project with seven central banks (NY Fed, BoE, BoJ, Bank of Mexico, BoK, SNB, BdF) plus 41 private-sector participants, announced April 2024.

### Academic Context

Cryptocurrency has generated a substantial multidisciplinary academic literature spanning cryptography, distributed systems, monetary economics, financial economics, and law. The field sits at the intersection of theoretical computer science, applied cryptography, mechanism design, and political economy.

**Foundational Cryptography**: Diffie-Hellman (1976) *New Directions in Cryptography* established public-key cryptography. RSA (Rivest-Shamir-Adleman 1978) and elliptic curve cryptography (Koblitz 1987, Miller 1985) provide asymmetric signing primitives. Merkle trees (Merkle 1979) enable efficient set-commitments. Lamport-Shostak-Pease *The Byzantine Generals Problem* (1982) formalised the consensus problem cryptocurrency solves probabilistically. Dwork-Naor (1992) introduced the proof-of-work concept for spam prevention later adapted by Hashcash.

**Bitcoin Foundational**: Nakamoto (2008) *Bitcoin Whitepaper*. Garay, Kiayias, Leonardos (2015) *The Bitcoin Backbone Protocol: Analysis and Applications* (Eurocrypt) — formal security analysis of Bitcoin under the honest-majority assumption, foundational paper for Aggelos Kiayias's subsequent Ouroboros work at Edinburgh. Pass, Seeman, Shelat (2017) on Bitcoin under asynchronous networks. Eyal, Sirer (2014) *Majority is Not Enough: Bitcoin Mining is Vulnerable* introduced the selfish-mining attack.

**Proof of Stake**: Kiayias, Russell, David, Oliynykov (2017) *Ouroboros: A Provably Secure Proof-of-Stake Blockchain Protocol* (IACR eprint 2017/963, CRYPTO 2017) — the formally-verified PoS family underpinning Cardano. David, Gazi, Kiayias, Russell (2018) *Ouroboros Praos*. Buterin, Hertzog *Casper FFG* (2017) and the Gasper finality gadget underpinning Ethereum post-Merge. Daian, Pass, Shi (2019) on snow-white and longest-chain PoS protocols.

**Cryptocurrency Economics**: Yermack (2015) *Is Bitcoin a Real Currency?* (early skepticism). Böhme, Christin, Edelman, Moore (2015) *Bitcoin: Economics, Technology, and Governance* (Journal of Economic Perspectives 29(2)). Liu and Tsyvinski (2021) *Risks and Returns of Cryptocurrency* (Review of Financial Studies 34(6)) demonstrating crypto returns constitute a distinct asset class not explained by traditional Fama-French risk factors. Makarov and Schoar (2020) *Trading and Arbitrage in Cryptocurrency Markets* (Journal of Financial Economics) on cross-exchange arbitrage and market integration. Sockin and Xiong (2020) *A Model of Cryptocurrencies* on platform economics.

**DeFi and Smart Contracts**: Daian et al. (2020) *Flash Boys 2.0: Frontrunning, Transaction Reordering, and Consensus Instability in Decentralized Exchanges* introduced MEV. Adams et al. (2020-2024) on Uniswap V1/V2/V3/V4 AMM design. Werner, Perez, Gudgeon, Klages-Mundt, Harz, Knottenbelt (2022) *SoK: Decentralized Finance (DeFi)* — Imperial College survey.

**Cypherpunk and Cryptocurrency Intellectual History**: Chaum (1983) *Blind Signatures for Untraceable Payments*. Hughes (1993) *A Cypherpunk's Manifesto*. Szabo (1997) *Formalizing and Securing Relationships on Public Networks*. Back (2002) *Hashcash — A Denial of Service Counter-Measure*. Narayanan, Bonneau, Felten, Miller, Goldfeder (2016) *Bitcoin and Cryptocurrency Technologies* (Princeton University Press), the canonical academic textbook.

**Monetary Theory and Austrian Economics**: Mises (1912) *Theory of Money and Credit*; Hayek (1976) *Denationalisation of Money*; Rothbard (1963) *What Has Government Done to Our Money?* — Austrian School monetary theory directly invoked by Bitcoin maximalist intellectual tradition. Ammous (2018) *The Bitcoin Standard* extends this lineage explicitly to cryptocurrency.

### Risk Factors and Limitations

Despite institutional integration, cryptocurrency retains structural risks that distinguish it from traditional financial assets:

**Volatility**: Bitcoin annualised volatility has ranged 55-85% across 2020-2025, several times higher than major equity indices (S&P 500 ~15-25%) and gold (~12-18%). Memecoins routinely exhibit 200-500% annualised volatility with 50-90% drawdowns within weeks of launch.

**Custody and Key Loss**: Estimated 3-4M BTC are permanently lost (lost private keys, deceased holders without succession, forgotten passwords). Self-custody errors are irreversible — unlike traditional banking, no chargeback or recovery mechanism exists. The 2014 Mt. Gox collapse, 2016 Bitfinex hack (120K BTC), 2025 Bybit Lazarus hack ($1.4B) illustrate exchange-custody risk.

**Regulatory Risk**: Despite the 2024-2025 regulatory consolidation, fragmentation persists across jurisdictions. Hostile-jurisdiction risk (China's 2021 mining ban, 2017 ICO ban; India's tax regime; potential future hostile regimes) remains material. Privacy coins face progressive delisting under FATF Travel Rule pressure.

**Smart-Contract Risk**: DeFi protocols have suffered cumulative losses exceeding $10B through 2024 from smart-contract bugs, oracle manipulation, flash-loan attacks, and economic exploits. Notable failures include Wormhole bridge ($325M February 2022), Ronin bridge ($625M March 2022), Nomad bridge ($190M August 2022), Euler Finance ($197M March 2023, partly recovered).

**Stablecoin Reserve Risk**: Stablecoin pegs depend on issuer reserve quality and redemption mechanics. USDC briefly de-pegged to $0.88 during March 2023 Silicon Valley Bank failure when $3.3B of Circle reserves were temporarily frozen. UST/Luna algorithmic stablecoin catastrophically failed May 2022.

**Environmental Concerns**: Bitcoin mining consumes ~150-180 TWh annually (CCAF estimate), comparable to mid-sized industrialised nations. Mining migration toward renewable energy (Texas wind/solar, Quebec/Norway hydro) and flared-gas capture has improved the emissions profile but environmental criticism remains material. PoS chains (Ethereum post-Merge) reduced energy consumption by ~99.95%.

**Concentration**: Bitcoin is held by a relatively small number of large holders ("whales" + exchanges + ETFs). Top 100 addresses hold ~15-18% of supply. MicroStrategy alone holds ~2.3%. Institutional accumulation through ETFs (~1.7M BTC by late 2025) reduces the practically-trading float.

**Quantum Computing**: Post-quantum threats to ECDSA/Ed25519 are theoretical but represent a long-term tail risk. NIST PQC standards (CRYSTALS-Dilithium, CRYSTALS-Kyber, SPHINCS+) provide post-quantum migration path; cryptocurrency implementations are early-stage. Quantum threat estimates suggest 10-20 year migration window.

**Operational Concentration**: Despite cryptography's decentralisation promise, operational dependencies concentrate: Coinbase Custody for ~85-90% of US spot Bitcoin ETF holdings, AWS for many node operators' infrastructure, Cloudflare for many RPC endpoints, Lido for ~28-30% of staked ETH.

### Stock-to-Flow, Halvings, and Bitcoin Monetary Properties

Bitcoin's monetary properties are characterised by an algorithmically-enforced disinflationary issuance schedule that distinguishes it from all prior monetary systems:

**Halving Cycles**: Bitcoin block subsidy halves every 210,000 blocks (~4 years), creating discrete supply-shock events. The four completed halvings are documented (November 2012, July 2016, May 2020, April 2024); the fifth is anticipated approximately March-April 2028 reducing subsidy to 1.5625 BTC per block. Empirically, Bitcoin price cycles have correlated with the halving cycle, peaking 12-18 months after each halving (December 2013, December 2017, November 2021, anticipated 2025-2026 cycle peak).

**Stock-to-Flow Model**: PlanB's 2019 stock-to-flow model (and 2020 S2FX extension) proposed mapping Bitcoin's stock-to-flow ratio (existing supply / annual issuance) to predicted price, fitting historical data well through 2021 but diverging during 2022-2024. Academic critique (Bhambhwani 2023, others) demonstrates the model is statistically over-fit and lacks predictive power for individual cycles, though the underlying monetary-scarcity dynamic remains real.

**Terminal Supply and Fee Market**: Bitcoin's terminal supply of approximately 20,999,999.97 BTC will be reached around year 2140. Beyond terminal supply, miner compensation derives entirely from transaction fees. The economic sustainability of post-terminal-supply mining depends on a robust on-chain fee market — the Bitcoin Ordinals/Inscriptions/Runes phenomenon (2023-2024) demonstrated meaningful fee generation from non-monetary transactions.

**Monetary Velocity and Hodling**: Bitcoin's monetary velocity has been declining as long-term holders ("HODLers", a term originating from a 2013 BitcoinTalk forum typo of "holding") progressively accumulate. The "long-term holder supply" metric (UTXOs aged 155+ days) reached ~75-80% of supply by late 2024.

### Current Landscape (2026)

As of May 2026, cryptocurrency exists as an institutionally-integrated asset class with comprehensive regulatory frameworks across major jurisdictions:

**Market Capitalisation**: Total cryptocurrency market cap fluctuating $3-4T range across 2025-2026, with Bitcoin alone representing ~$2-2.5T at BTC prices $100K-$130K. Spot Bitcoin ETFs cumulatively held ~1.7M BTC (~8% of total supply) by late 2025, plus ~$80B+ aggregate AUM. MicroStrategy/Strategy alone holds ~478-490K BTC (~2.3% of supply).

**Stablecoin Market**: Aggregate stablecoin supply exceeded **$200B** during 2025, with USDT ~$130B+, USDC ~$45B, USDe ~$8B, DAI/USDS ~$5B, PYUSD ~$2B, RLUSD ~$1B. Stablecoin annualised payment volume exceeded $10T during 2024, comparable to Visa+Mastercard combined retail volume.

**DeFi TVL**: Total value locked across DeFi protocols ~$100-150B during 2025-2026, dominated by Lido staking, EigenLayer restaking, Aave lending, Uniswap liquidity, and Maker/Sky.

**Institutional Integration**: Major banks (Goldman Sachs, Morgan Stanley, JPMorgan, BlackRock, Fidelity, BNY Mellon, State Street) offer crypto custody, prime brokerage, or asset management. Spot Bitcoin/Ether ETFs in US, EU (under MiCA), Hong Kong, Brazil, Australia, Canada. CME Group dominant US-regulated derivatives venue.

**Tokenised Assets**: Tokenised RWAs (Treasuries, money-market funds, private credit, real estate) exceeded $20B by 2025, growing 4-5x year-over-year. BlackRock BUIDL alone exceeded $2.4B AUM.

**Memecoin Cycle**: The 2024-2025 memecoin cycle (TRUMP, MELANIA, dogwifhat, Bonk, Bonk-related Solana pump.fun launchpad activity) accelerated and decelerated rapidly, with most launches producing -90%+ drawdowns within months. pump.fun graduated approximately 2-3% of launched tokens to Raydium AMM liquidity.

**DePIN and AI Sectors**: Render Network, Filecoin, Helium, Akash, Bittensor, Fetch.ai have grown into multi-billion-dollar token-economy sectors aligned with the broader AI and infrastructure investment thesis. Bittensor in particular has emerged as the most credible AI-aligned cryptocurrency with subnet incentive markets producing genuine economic activity around model training, inference, and validation. The TAO token reached $20B+ market cap during 2024-2025.

**Regulatory Status by Region**:

- **EU**: Full MiCA implementation across 2024-2026; CASP authorisations granted by national competent authorities; stablecoin issuers (Circle EUR, Quantoz EURQ) authorised under Title IV
- **UK**: Cryptoasset Promotions Regime operational since October 2023; FCA Crypto Roadmap delivery in progress; comprehensive Designated Activities Regime expected 2026
- **US**: Spot Bitcoin and Ether ETFs trading since 2024; Strategic Bitcoin Reserve established March 2025; SAB 122 superseded SAB 121; Atkins-led SEC; comprehensive market structure legislation in advanced consideration
- **Asia-Pacific**: Singapore MAS PSA DPT regime mature; Hong Kong SFC VATP regime live; Korea Virtual Asset User Protection Act July 2024; Japan FSA regulated yen-stablecoin (JPYC) live
- **Latin America**: El Salvador legal tender Bitcoin since 2021; Brazil Drex CBDC + crypto framework; Argentina widespread USDT adoption amid peso inflation
- **Africa**: Nigeria SEC framework + eNaira CBDC; South Africa FSCA crypto FSP regime; Kenya pending framework

  **Industry Workforce**: Estimated 200,000-300,000 employed globally in cryptocurrency-native firms (exchanges, protocols, infrastructure, custody) by 2025, with major concentrations in US (~30%), UK (~10%), Singapore (~8%), Switzerland (~5%), UAE (~5%), Hong Kong (~5%), and Korea (~4%).

  **Insurance and Risk Transfer**: Crypto-specific insurance capacity at Lloyd's of London and global specialty insurance markets grew from <$200M aggregate by 2020 to ~$4-5B by 2025, driven by ETF custody mandates (BlackRock IBIT, Fidelity FBTC custody insurance requirements), corporate-treasury demand (MicroStrategy and copycats), and institutional adoption. Major underwriters include Lloyd's syndicates, Aon, Marsh, AXA XL, Munich Re, and the dedicated crypto insurer Evertas. Coverage includes hot/cold wallet theft, internal fraud, key compromise, and physical-loss components.

  **On-Chain Analytics and Compliance**: Chainalysis (US), Elliptic (UK, founded by Tom Robinson and James Smith), TRM Labs, CipherTrace (Mastercard), Crystal Blockchain, Coinfirm provide transaction analytics, sanctions screening, AML compliance, and law-enforcement investigative tooling. Elliptic in particular represents a leading UK crypto-compliance technology export.

### UK Context: Academic Research, Industry Leaders, and Regulatory Framework

The United Kingdom hosts world-leading cryptocurrency academic research and a distinctive industry ecosystem combining London-headquartered crypto-native firms, AIM/LSE-listed Bitcoin treasury experiments, and enterprise blockchain platforms — all operating under the FCA's progressive regulatory perimeter:

#### UK Academic Research Centres

**Imperial College London — Centre for Cryptocurrency Research & Engineering (CCRE)**: Founded by William Knottenbelt (Professor of Applied Quantitative Analysis, Department of Computing), the CCRE has built one of the world's leading academic cryptocurrency research groups. Key academics include Catherine Mulligan (Visiting Researcher, formerly UN Sustainable Development Goals digital finance lead, now at Newcastle), Alexei Zamyatin (XCC/Interlay co-founder, Bitcoin/Polkadot cross-chain bridge research), Daniel Perez (DeFi security research), Lewis Gudgeon (DeFi economic security), Dominik Harz (cross-chain protocols), and Andreea Minca (financial network economics). Imperial hosts the **DLT Science Foundation** and the **Imperial Blockchain Forum**.

**University College London (UCL) — Centre for Blockchain Technologies (CBT)**: Founded 2015 by Paolo Tasca, with approximately 30 affiliated researchers spanning Computer Science, Economics, and Law departments. UCL CBT publishes the *DLT Talks* annual conference series and hosts cross-disciplinary research on stablecoins, CBDCs, DeFi microstructure, and corporate crypto adoption. Affiliates include Geoffrey Goodell (DLT for democratic governance), Carsten Maple (cybersecurity).

**University of Cambridge — Cambridge Centre for Alternative Finance (CCAF)**: Founded 2015 at Cambridge Judge Business School by Bryan Zhang. Authoritative empirical research centre publishing the annual *Global Cryptoasset Benchmarking Study* (since 2017), the *Cambridge Bitcoin Electricity Consumption Index (CBECI)* maintained by Michel Rauchs (the canonical citation source for Bitcoin energy estimates used by IPCC, OECD, and central banks globally), and the *Cambridge Cryptoasset Mining Map* tracking global hashrate distribution. Material funding from Mastercard Foundation, Visa, EY, INVESCO.

**University of Edinburgh — Blockchain Technology Laboratory**: Led by **Aggelos Kiayias** (Chair of Cybersecurity & Privacy, also Chief Scientist at IOG — Input Output Global, the company building Cardano). Kiayias's group designed the **Ouroboros family** of formally-verified proof-of-stake protocols (Classic 2017, Praos 2018, Genesis 2018, Hydra L2 2020, Leios 2024) underpinning Cardano. Garay-Kiayias-Leonardos *The Bitcoin Backbone Protocol* (Eurocrypt 2015) remains a foundational paper. Edinburgh is the leading UK academic centre for formal proof-of-stake cryptography.

**University of Manchester — FinTech and Blockchain Research**: Cross-Faculty Blockchain Special Interest Group with research spanning Computer Science, Alliance Manchester Business School, and Manchester Law School. Manchester has hosted the Manchester Centre for Digital Trust and Society.

**University of Leeds — Centre for Decentralised Digital Economy**: Leeds University Business School research on cryptoasset markets, CBDC design, and decentralised finance under Daniel Broby and colleagues.

**University of Sheffield — School of Law / Information School**: Research on cryptoasset regulation and decentralised governance. Sheffield is part of the **Information Commissioner's Office** advisory network on emerging digital asset privacy.

**Newcastle University — Centre for Distributed Ledgers**: Newcastle Computer Science research on DLT scalability and applied cryptocurrency. Catherine Mulligan (formerly Imperial) joined Newcastle as Professor focused on AI/blockchain governance.

**King's College London — Centre for Cryptocurrencies and Blockchain Technology**: Cross-disciplinary research at KCL spanning Law, Informatics, and Business School.

**Oxford University — Oxford Future of Finance Initiative / Saïd Business School**: Research on stablecoins, CBDCs, and corporate digital-asset treasury under Bige Kahraman and the Oxford Future of Finance Programme.

**London Business School — Institute of Finance and Accounting**: Elroy Dimson and Paul Marsh's *Global Investment Returns Yearbook* (post-Credit Suisse, now UBS-sponsored) incorporates Bitcoin as a recognised asset class. Christopher Hennessy on capital structure and digital assets.

#### UK Industry Ecosystem

**R3 (London + NYC headquartered)**: Enterprise DLT consortium founded 2014 by David E. Rutter, developing Corda — a permissioned distributed ledger underpinning regulated financial market infrastructure for J.P. Morgan, HSBC, Goldman Sachs, Bank of England, SDX, and many CSDs and central banks globally. While not strictly "cryptocurrency," R3 represents the UK's flagship enterprise blockchain export.

**Quant Network (London, AQSE:QNT)**: Founded by Gilbert Verdian, building Overledger interoperability infrastructure. Participated in BIS multi-CBDC pilots including Project Rosalind (BoE retail CBDC API standards) and Project mBridge.

**Aave Companies Limited (London)**: Stani Kulechov founded ETHLend in 2017, rebranded to Aave 2018. Aave Protocol (AAVE governance token) is the largest decentralised lending protocol globally with ~$20-30B TVL. Aave V3 launched March 2022, GHO stablecoin launched July 2023, Aave V4 announced 2024.

**Argo Blockchain plc (LON:ARB, NASDAQ:ARBK)**: London-headquartered listed Bitcoin mining company. Operations include Helios facility in Dickens County, Texas (200 MW capacity). Hybrid mining-treasury model exposing investors to BTC price plus mining economics.

**KR1 plc (AQSE:KR1)**: London-listed crypto investment company founded 2016 by George McDonaugh and Keld van Schreven. Historical focus on early-stage protocol investments (Polkadot, Cosmos, Acala, Moonbeam validators, Argent, Layer Zero). ~£25-40M market capitalisation. One of the earliest and longest-running public crypto investment vehicles globally.

**Coinbase UK**: Coinbase's UK subsidiary, FCA-registered as a cryptoasset business under the MLRs since 2021. Operates Coinbase Custody services through Coinbase Custody International Limited (Ireland) for UK and EU institutional clients.

**Binance UK**: Binance Markets Limited (BML) received an FCA consumer warning June 2021 and subsequently wound down UK-regulated derivatives operations. Binance withdrew UK retail services in October 2023 following FCA financial promotions regime enforcement. Continues offshore operations.

**Copper.co**: London-headquartered institutional digital asset custodian (NYDFS-equivalent regulated structure via overseas subsidiaries). Provides custody, ClearLoop off-exchange settlement, and prime brokerage. Series C funding led by Tiger Global 2022 at ~$3B valuation.

**Zodia Custody (London)**: Standard Chartered subsidiary providing institutional crypto custody, with JV partners SBI Holdings (Japan) and Northern Trust (US).

**Komainu (London)**: Nomura JV with Ledger and CoinShares providing institutional custody.

**Aztec Network (London)**: Zero-knowledge rollup specialising in privacy-preserving Ethereum L2 (Aztec Protocol). Founded by Zac Williamson and Joe Andrews.

**Polygon Labs UK**: UK presence for Polygon (POL) L2/sidechain protocol.

**Chainlink Labs UK**: UK presence for Chainlink oracle network.

**Smarter Web Company plc (AQSE:SWC)**: London-listed digital marketing SME that pivoted in 2024 to explicit "Bitcoin treasury micro-strategy" branding, becoming the first UK AIM/AQSE adoption of the MicroStrategy template.

**Vinanz Limited (LON:BTC)**: AIM-listed Bitcoin mining and treasury company (acquired the BTC ticker).

**Coinsilium Group (AQSE:COIN)**: Blockchain venture-builder and crypto-treasury hybrid founded 2014.

**Bluebird Mining Ventures (LON:BMV)**: Junior mining company pivoting toward Bitcoin treasury strategy 2024.

**Hut 8 (LSE-listed predecessor, now Nasdaq:HUT)**: Originally Canadian, with London listing history.

#### UK Northern English Industrial Cluster

Beyond London, **Manchester** hosts a growing fintech/crypto cluster anchored by the Manchester Digital Trade Show, Pragmatic Coders, and AMBS research, with Manchester-headquartered fintechs (AccessPay, Funding Circle Northern hub) increasingly engaging with stablecoin payment rails. **Leeds** is home to the UK Centre for Digital Built Britain, the Northern fintech accelerators, and growing crypto-tax and compliance specialist firms serving the broader Northern Powerhouse. **Sheffield** combines academic research at the University of Sheffield Information School with cryptography start-ups and the Yorkshire AI cluster. **Newcastle** anchors a North-East distributed-ledger and AI cluster including Catherine Mulligan's research group, Atom Bank's digital-first banking infrastructure, and Newcastle's leading position in UK applied AI and blockchain research. **Edinburgh** (Scotland) hosts the IOG/Cardano R&D presence alongside Aggelos Kiayias's University of Edinburgh Blockchain Technology Laboratory, making Edinburgh the highest concentration of formally-verified-PoS expertise globally.

#### London's Position as a Global Crypto Hub

London serves as one of the world's three or four leading crypto-finance centres alongside New York, Singapore and Hong Kong. The UK's strengths derive from (i) the established financial services ecosystem with deep capital markets and legal expertise (magic-circle law firms, Big Four professional services, world-leading insurance market at Lloyd's), (ii) world-class universities producing crypto-native engineering and research talent (Imperial, UCL, Cambridge, Edinburgh, Oxford), (iii) a relatively progressive FCA regulatory stance compared to the pre-2025 hostile US enforcement environment, and (iv) the English language plus English law as the global preferred contract jurisdiction. UK-headquartered or UK-significant-presence crypto firms include R3 (Corda enterprise DLT), Quant Network (interoperability), Aave Companies (DeFi protocol governance), Copper.co (custody), Zodia Custody (Standard Chartered), Komainu (Nomura), Wintermute (market making), GSR (market making), B2C2 (market making, SBI subsidiary), Argo Blockchain (listed mining), KR1 plc (listed investment company), Aztec Network (ZK rollup), Polygon Labs UK, Chainlink Labs UK, and Coinbase UK.

#### Northern Powerhouse Crypto-Aligned Industrial Capability

The Northern English engineering, software, energy and materials base provides distinctive industrial capabilities relevant to cryptocurrency:

- **Mining-Related Hardware and Energy**: Manchester and Leeds engineering supply chains support immersion-cooling, power-distribution, and data-centre construction for mining and AI compute (the same hardware stack and cooling technology serves both)
- **Compliance and Fintech**: Manchester and Leeds compliance technology vendors increasingly support stablecoin issuers, exchanges, and tokenisation platforms
- **AI and Compute**: Sheffield (Sheffield AI Research Centre) and Newcastle compute clusters increasingly intersect with crypto-AI tokens (Bittensor, Render Network) and decentralised compute markets
- **Tax and Audit Practice**: Big Four firms maintain substantial crypto practice in Northern offices (KPMG Manchester, EY Leeds, PwC Newcastle, Deloitte Manchester)

  #### UK Regulatory Framework Summary

- **FSMA 2023 Section 22(1A)**: Extends FCA perimeter to cryptoassets, foundation for designated activities regime
- **FCA Cryptoasset Promotions Regime PS23/6** (October 2023): Marketing of cryptoassets to UK retail subject to FSMA Section 21 controls
- **FCA Money Laundering Regulations (MLRs) Cryptoasset Business Registration**: Mandatory since January 2020 for UK-incorporated crypto firms
- **FCA Consumer Duty**: Applies to crypto firms in scope
- **FCA DP23/4 + CP24/4 + PS24/X on Stablecoins**: UK fiat-backed stablecoin regulatory framework
- **FCA Crypto Roadmap (November 2024)**: Sequenced delivery of comprehensive UK crypto regime targeting full implementation 2026
- **HM Treasury Future Financial Services Regulatory Regime for Cryptoassets** (consultations 2023-2025): Designated activities regime for CASPs, lending, staking, market abuse
- **Bank of England Digital Pound Discussion Paper (February 2023)** + ongoing CBDC consultation: UK CBDC ("Britcoin") under design, no decision before 2026
- **Property (Digital Assets etc) Bill** (introduced 2024): Statutory recognition of digital assets as a third category of personal property under English law (distinct from choses in action and choses in possession)

### Future Directions (2026-2030)

Cryptocurrency's evolution through 2026-2030 is shaped by four converging vectors:

**1. Regulatory Maturation**: EU MiCA fully bedded in across 2025-2026 with full CASP authorisations replacing transitional national regimes by 1 July 2026. UK FCA Designated Activities Regime fully operational by 2026-2027 covering CASPs, stablecoins, lending, staking. US comprehensive market structure legislation (Clarity Act, FIT 21, GENIUS Act stablecoin framework) likely passing 2025-2027. IFRS update mirroring FASB ASU 2023-08 fair-value crypto accounting expected by 2027. Global stablecoin frameworks (BIS-coordinated standards, FSB recommendations) likely converging on 1:1 reserve requirements and qualified custody.

**2. Institutional Integration**: Spot Bitcoin and Ether ETFs proliferate globally; spot Solana, XRP, and multi-asset basket ETFs likely approved 2025-2027. Major asset managers (BlackRock, Fidelity, Vanguard, State Street, Schwab) extend crypto product suites. Bank tokenised-deposit and tokenised-cash systems (JPMorgan Kinexys, Citi Token Services, HSBC Orion, Goldman DAP, Mastercard MTN) scale into trillions of dollars annual volume. Tokenised Treasury and money-market funds (BUIDL, OUSG, FOBXX) reach $100B+ aggregate AUM.

**3. Technical Maturation**: Ethereum further scales via danksharding, account abstraction (EIP-7702 post-Pectra), and proliferation of ZK and optimistic L2s. Solana achieves 1M+ TPS via Firedancer client. Cross-chain interoperability matures via LayerZero, Wormhole, Axelar, Chainlink CCIP. Privacy improves via zk-SNARK/STARK applications (Aztec, Aleo, zkPass). Quantum-resistant cryptography (lattice-based signatures, hash-based signatures) prepared for eventual post-quantum migration.

**4. Macro / Sovereign Adoption**: Bitcoin as sovereign reserve asset accelerates: US Strategic Bitcoin Reserve established March 2025, potentially expanded to additional G7/G20 nations (El Salvador, Bhutan precedents, rumoured Gulf sovereign wealth fund interest). Corporate Bitcoin treasury template (MicroStrategy precedent) scales to 300-500 listed companies globally by 2030 with aggregate corporate Bitcoin holdings of $200-400B. CBDC pilots (eCNY in China, digital euro under ECB design, digital pound under BoE consultation, Drex Brazil, eNaira Nigeria, Sand Dollar Bahamas) reach production deployment in multiple jurisdictions, coexisting with — not displacing — private cryptocurrency.

**5. Risks and Tail Scenarios**: Tail risks include catastrophic stablecoin failure (broader UST-style depeg in major USDT or USDC), exchange concentration failure (post-FTX repeat with major venue), regulatory reversal in major jurisdictions (hostile-government action), quantum computing breakthrough invalidating ECDSA before post-quantum migration, or environmental/energy backlash constraining PoW mining. None appears likely but each represents material asset-class tail risk.

**6. Bitcoin Maturation Trajectory**: By 2030 Bitcoin total market cap projections range $5-15T (bear-to-bull, BTC $250K-$700K). Spot Bitcoin ETF AUM likely exceeds $200-500B globally. Corporate Bitcoin treasury holdings reach $200-400B across 300-500 listed adopters. Sovereign Bitcoin reserve adoption spreads to additional G7/G20 nations following US precedent. Bitcoin-denominated bond and equity issuance experiments emerge (theoretically possible but speculative).

**7. Ethereum Roadmap**: Vitalik Buterin's roadmap (Merge / Surge / Verge / Purge / Splurge phases) continues: full danksharding expected 2026-2027 enabling rollup data availability at ~10MB/slot; Verkle trees enabling stateless clients; account abstraction maturation; PeerDAS sampling. Layer-2 ecosystem consolidates around 3-5 dominant rollups capturing majority of activity.

**8. Smart-Contract Platform Competition**: Solana, Aptos, Sui, TON, Hyperliquid challenge Ethereum's smart-contract dominance through superior UX, throughput, or distribution. Multi-chain reality persists with cross-chain interoperability (LayerZero, Wormhole, Axelar, Chainlink CCIP) abstracting individual chain choice from application developers.

**9. Privacy and Compliance Tension**: Default-on transaction privacy (Monero, Zcash shielded) faces continued regulatory pressure. Selective-disclosure technologies (zk-SNARK identity, Aleo, Aztec) may reconcile privacy and compliance through view keys and proof-of-innocence schemes. The EU's pseudonymous-wallet restrictions under AMLR (anti-money laundering regulation, taking effect 2027) test the regulatory tolerance for non-custodial privacy.

### Research and Literature

**Foundational Cryptocurrency**:
1. Nakamoto, S. (2008). *Bitcoin: A Peer-to-Peer Electronic Cash System*. https://bitcoin.org/bitcoin.pdf [Foundational paper, 31 October 2008]
2. Back, A. (2002). *Hashcash — A Denial of Service Counter-Measure*. http://www.hashcash.org/papers/hashcash.pdf [Proof-of-work for spam, foundational to Bitcoin mining]
3. Dai, W. (1998). *b-money*. http://www.weidai.com/bmoney.txt [Distributed electronic cash proposal cited in Bitcoin whitepaper]
4. Szabo, N. (1998-2005). *Bit Gold*. https://nakamotoinstitute.org/bit-gold/ [Chained proof-of-work registry proposal]
5. Finney, H. (2004). *Reusable Proofs of Work (RPOW)*. https://nakamotoinstitute.org/finney/rpow/ [Transferable PoW tokens on IBM 4758 coprocessor]
6. Chaum, D. (1983). Blind Signatures for Untraceable Payments. *Advances in Cryptology — CRYPTO '82*, Springer, 199-203. [Foundational ecash cryptography]
7. Hughes, E. (1993). *A Cypherpunk's Manifesto*. [Political foundation for cypherpunk movement]

**Formal Analysis of Bitcoin and Proof of Stake**:
8. Garay, J., Kiayias, A., Leonardos, N. (2015). The Bitcoin Backbone Protocol: Analysis and Applications. *EUROCRYPT 2015*, LNCS 9057, 281-310. [Foundational formal analysis of Bitcoin]
9. Kiayias, A., Russell, A., David, B., Oliynykov, R. (2017). Ouroboros: A Provably Secure Proof-of-Stake Blockchain Protocol. *CRYPTO 2017*, IACR eprint 2017/963. [Formally-verified PoS underpinning Cardano]
10. Buterin, V., Hertzog, V. (2017). *Casper the Friendly Finality Gadget*. arXiv:1710.09437. [Ethereum PoS finality]

**Cryptocurrency Economics**:
11. Yermack, D. (2015). Is Bitcoin a Real Currency? An Economic Appraisal. *Handbook of Digital Currency*, Elsevier, 31-43. [Early academic skepticism]
12. Böhme, R., Christin, N., Edelman, B., Moore, T. (2015). Bitcoin: Economics, Technology, and Governance. *Journal of Economic Perspectives*, 29(2), 213-238. DOI:10.1257/jep.29.2.213
13. Liu, Y., Tsyvinski, A. (2021). Risks and Returns of Cryptocurrency. *Review of Financial Studies*, 34(6), 2689-2727. DOI:10.1093/rfs/hhaa113 [Crypto as distinct asset class]
14. Makarov, I., Schoar, A. (2020). Trading and Arbitrage in Cryptocurrency Markets. *Journal of Financial Economics*, 135(2), 293-319.
15. Ammous, S. (2018). *The Bitcoin Standard: The Decentralized Alternative to Central Banking*. Wiley. ISBN 978-1-119-47386-2.
16. Narayanan, A., Bonneau, J., Felten, E., Miller, A., Goldfeder, S. (2016). *Bitcoin and Cryptocurrency Technologies: A Comprehensive Introduction*. Princeton University Press. [Canonical academic textbook]

**Regulatory and Accounting**:
17. European Parliament and Council (2023). *Regulation (EU) 2023/1114 on Markets in Crypto-Assets (MiCA)*. Official Journal of the European Union, 9 June 2023. https://eur-lex.europa.eu/eli/reg/2023/1114/oj
18. UK Financial Conduct Authority (2023). *Policy Statement PS23/6: Financial Promotion Rules for Cryptoassets*. https://www.fca.org.uk/publications/policy-statements/ps23-6-financial-promotion-rules-cryptoassets
19. UK Financial Conduct Authority (2024). *Crypto Roadmap*. November 2024.
20. UK Parliament (2023). *Financial Services and Markets Act 2023*. Royal Assent 29 June 2023.
21. Financial Accounting Standards Board (2023). *Accounting Standards Update 2023-08: Intangibles—Goodwill and Other—Crypto Assets (Subtopic 350-60)*.
22. The White House (2025). *Establishment of the Strategic Bitcoin Reserve and United States Digital Asset Stockpile*. Executive Order, 6 March 2025.

**UK Academic and Industry**:
23. Cambridge Centre for Alternative Finance (2024). *Global Cryptoasset Benchmarking Study*. University of Cambridge Judge Business School.
24. Cambridge Centre for Alternative Finance. *Cambridge Bitcoin Electricity Consumption Index (CBECI)*. Maintained by Michel Rauchs.
25. Imperial College Centre for Cryptocurrency Research & Engineering (CCRE). Selected working papers, Imperial College London Department of Computing.
26. Tasca, P., Liu, S., Hayes, A. (2018). The Evolution of the Bitcoin Economy: Extracting and Analyzing the Network of Payment Relationships. *Journal of Risk Finance*, 19(2), 94-126. [UCL CBT]
27. Bank of England (2023). *The Digital Pound: A New Form of Money for Households and Businesses?* Consultation Paper, February 2023.

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review during Phase 6 enrichment sprint (worker: claude-opus-4-7, post-rate-limit retry)
- **Verification**: Genesis date, halving block heights, and consensus parameters verified against Bitcoin Core source and Bitcoin Whitepaper; MiCA regulation dates verified against Official Journal of the European Union; FCA dates verified against PS23/6 and FCA Crypto Roadmap November 2024; US executive orders verified against whitehouse.gov; market-cap figures cross-referenced against CoinGecko, CoinMarketCap, and CCAF Global Cryptoasset Benchmarking Study 2024; UK academic centres verified against institutional websites (Imperial CCRE, UCL CBT, CCAF, Edinburgh BTL)
- **Regional Context**: UK academic ecosystem detailed (Imperial CCRE, UCL CBT, Cambridge CCAF, Edinburgh BTL/Kiayias, Manchester, Leeds, Sheffield, Newcastle, King's, Oxford Saïd, LBS); UK industry leaders covered (R3 Corda, Quant Network, Aave Companies, Argo Blockchain, KR1 plc, Copper.co, Zodia Custody, Komainu, Aztec Network, Polygon Labs UK, Chainlink Labs UK, Coinbase UK, Smarter Web Company, Vinanz, Coinsilium, Bluebird Mining); UK regulatory framework summarised (FSMA 2023, FCA PS23/6, MLRs, Consumer Duty, DP23/4 + CP24/4 stablecoins, Crypto Roadmap November 2024, Property (Digital Assets etc) Bill, Bank of England digital pound)
- **Production-Ready**: Complete OWL formal semantics (58 SubClassOf axioms across compositional/dependency/capability/implementation/reduction/association families plus data property assertions, annotation assertions, and property characteristic declarations), comprehensive content coverage (origin and intellectual lineage from cypherpunk through Hashcash to Satoshi, architectural components including cryptographic primitives + ledger models + consensus mechanisms + difficulty adjustment + mempool/MEV, eleven major families spanning store-of-value through DeFi governance, market structure CEX/DEX/derivatives/custody/market-makers/indices, regulatory landscape across EU/UK/US/Singapore/Hong Kong/APAC/LATAM/Africa, key historical events 2008-2025 covering genesis, Mt. Gox, 2017 ICO, 2020 DeFi summer + MicroStrategy, 2021 cycle peak, 2022 Terra-FTX cascade, 2024 spot Bitcoin ETF + halving, 2025 Trump era + Strategic Bitcoin Reserve, tokenisation and RWA integration with BUIDL/OUSG/Kinexys/Onyx/Citi/HSBC/Mastercard/BIS Agorá, academic context across cryptography + Bitcoin foundations + PoS + DeFi + cryptoeconomics + cypherpunk lineage, current landscape 2026, UK context with academic detail across Imperial/UCL/Cambridge/Edinburgh/Oxford/LBS/Manchester/Leeds/Sheffield/Newcastle/KCL plus industry detail across R3/Quant/Aave/Argo/KR1/Copper/Zodia/Komainu/Wintermute/GSR/B2C2/Aztec/Polygon/Chainlink/Coinbase UK plus Northern industrial capability, contrasts with CBDC/E-money/Bank Deposit/Tokenised Deposit/Traditional Security, use cases across SoV/payments/programmable money/permissionless capital/self-custody/institutional reserve, future directions 2026-2030 across nine vectors), 27 academic and primary-source citations
- **Authority Score**: 0.87 (defining cryptoasset class concept, $3-4T market capitalisation, comprehensive regulatory frameworks live across major jurisdictions, foundational role for entire blockchain ontology branch)

### Provenance

- **naming-note:** "Cryptocurrency" is the predominant term in regulatory and academic usage; "cryptoasset" preferred by UK FCA and EU MiCA for broader scope including stablecoins, NFTs, and utility tokens; "digital asset" used in US Trump administration framework (Strategic Bitcoin Reserve EO, Digital Asset Stockpile)

