A private smart contract is a smart contract whose inputs, state or logic are concealed from public view while still being verifiably executed and settled on a blockchain. It typically relies on zero-knowledge proofs or confidential computing so that correctness can be checked without revealing the underlying data. Private smart contracts let parties transact programmable agreements with confidentiality comparable to traditional finance while retaining the auditability and finality of public ledgers.

### Overview

- A private smart contract preserves the programmability and trustless settlement of ordinary smart contracts while hiding sensitive details. Two broad approaches dominate. In the zero-knowledge model, a party executes the contract logic off-chain and submits a succinct proof that the transition was valid, so the chain verifies correctness without learning the inputs or state; protocols such as Aztec apply this to confidential transfers and programmable logic. In the confidential-computing model, execution happens inside trusted hardware enclaves or under encryption schemes such as homomorphic encryption. Both let regulated finance, supply-chain settlement and identity workflows move on-chain without exposing positions, counterparties or personal data, at the cost of additional proving or attestation overhead.

### Mechanisms

- Hides inputs, state or logic while keeping execution verifiable.
- Zero-knowledge proofs attest to correct state transitions without revealing data.
- Confidential computing executes logic in enclaves or under encryption.
- Settles on a public ledger to retain auditability and finality.
- Trades extra proving or attestation cost for confidentiality.

### Applications

- Confidential decentralized-finance trading and lending.
- Private payroll, invoicing and B2B settlement.
- Regulated asset issuance with selective disclosure.
- Identity and credential workflows preserving personal data.

### Provenance

