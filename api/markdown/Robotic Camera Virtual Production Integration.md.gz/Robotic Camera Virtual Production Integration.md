The VP Robotics Project (VisionFlow) is a feasibility study investigating the integration of robotic camera control with machine learning and virtual production workflows. It inverts conventional pre-visualisation pipelines by deriving scene-driven camera motion from AI-generated content, combining open-source robotics software with parallax-plates-as-a-service delivery for the film and television industry.

### Semantic Classification

### Content

- automatically published
- https://docs.google.com/presentation/d/1DQcc9ybYcozzT6ROX8X0nKhKHzx4e_sQrJ452vLXF4E/edit?usp=sharing

# New submission for Creative Catalyst?

- [Creative Catalyst 2024
  - GOV-UK Find a grant (find-government-grants.service.gov.uk)](https://find-government-grants.service.gov.uk/grants/creative-catalyst-2024-1)
  - Partners: SM Robotics Ltd (Lead), Flossverse Ltd.
  - Competition: Feasibility studies for AI solutions.
  - Application Name: VisionFlow.
  - Duration: 5 months, starting 11 September 2023.
  - Research Category: Feasibility studies.
  - Summary: VisionFlow aims to develop pre-visualization workflows integrating machine learning and robot control software for virtual production.
  - VisionFlow will develop innovative workflows for the virtual production industry.
  - It inverts existing workflows, focusing on scene-driven camera motion.
  - Key features include the use of open-source AI and a simpler interface for non-artists to create 3D environments.
  - The project will build upon the open-source Flossverse telecollaboration stack.
  - Aligns with the competition's focus on integrating machine learning in video production.
  - Assessor Feedback: Generally considered in scope, but involvement of a video production company could strengthen alignment.
  - The project addresses the reluctance in the film industry to adopt AI and ML technologies due to tight margins and complexity.
  - VisionFlow introduces "parallax plates as a service", integrating robotics with ML-based video generation.
  - Key benefits include increased productivity in pre-visualization and improved collaboration.
  - Assessor Feedback: Positive recognition of the project's potential to improve productivity in video content production. However, a closer association with a video production company could enhance the application's relevance and impact.
  - VisionFlow will integrate AI-generated video with robotics for innovative virtual production.
  - Plans to develop new tele-collaboration technologies for virtual production.
  - Focus on disrupting traditional workflows with more efficient solutions.
  - Assessor Feedback: The approach is plausible but lacks detailed deliverables and milestones for monitoring progress. A more comprehensive analysis of the competitive landscape is suggested.
  - Dr. Sean Chase Mandrake Hill and Dr. John O'Hare lead the project with significant expertise in robotics and tele-collaboration.
  - Potential collaborations with G6Moco and Pathway XR Innovation Lab.
  - Assessor Feedback: The team is well-qualified but would benefit from direct involvement with a video production company.
  - The project targets the rapidly growing virtual production market.
  - Potential for significant savings in both small and large-scale virtual production facilities.
  - Assessor Feedback: Good market understanding but requires further research on barriers to entry and secondary markets.
  - Focuses on demonstrating cost savings and efficiency in virtual production.
  - Plans to engage with early adopters and expand to global markets.
  - Assessor Feedback: Credible route to market but needs more detailed financial projections and dissemination plans.
  - **Economic Benefits**:
  - Potential savings for virtual production facilities, reducing costs.
  - End-users benefit from reduced production costs.
  - Drives innovation in virtual production, encouraging market growth.
  - Contributes to UK's economic growth by attracting investments and creating jobs.
  - **Impact on Government Priorities**:
  - Supports government focus on creative industries and digital technologies.
  - **Environmental Impacts**:
  - Positive: Reduces film industry's ecological footprint.
  - Negative: Potential increase in energy consumption due to digital technologies.
  - **Regional Impacts and Job Creation**:
  - Supports regional virtual production hubs in the UK.
  - Encourages job creation and fosters creative communities.
  - **Diversity and Social Inclusion**:
  - Democratizes access to virtual production tools, promoting diversity in film and media.
  - **Health, Safety, and Quality of Life**:
  - Improves safety in film production by reducing on-location shoot risks.
  - Integration challenges, limitations of AI, compatibility issues.
  - Market adoption uncertainty, competition, monetization challenges.
  - Collaboration efficiency, scope and timeline management, expertise recruitment.
  - Data protection and AI risk analysis.
  - Dedicate resources for testing and refining, focus on achievable goals, conduct market analysis, establish clear communication, and management practices.

## Old Pitch Deck

## **Project Details**:

## **Project Summary and Public Description**:

## **InnovateUK Feedback**:

## **Need or Challenge**:

## **Approach and Innovation**:

## **Team and Resources**:

## **Market Awareness**:

## **Outcomes and Route to Market**:

## **Wider Impacts**:

## **Risks**:

### *Technical Risks*:

### **Commercial Risks**:

### **Managerial Risks**:

### **Legal Risks**:

### **Mitigation Strategies**:

### Provenance

