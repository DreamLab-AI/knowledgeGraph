FIPA, the Foundation for Intelligent Physical Agents, is a standards body — now an IEEE Computer Society standards committee — that produced specifications for interoperable software agents and multi-agent systems. Its best-known output is FIPA-ACL, an agent communication language with formally defined performatives and interaction protocols. FIPA standards enable heterogeneous agents from different developers to discover, communicate, and coordinate with one another.

### Overview

- FIPA was founded in 1996 to promote agent-based technology through open specifications and transferred its work to the IEEE in 2005. Its specification suite covers agent management, the FIPA-ACL communication language, content languages, ontology services, and a library of standard interaction protocols such as Contract Net and request-response. FIPA-ACL builds on speech-act theory, framing messages as performatives — inform, request, propose, agree — with a defined semantics, so that agents share a common pragmatics for negotiation, delegation, and information exchange across platform boundaries.

### Key aspects

- Agent communication language: FIPA-ACL performatives grounded in speech-act theory.
- Interaction protocols: reusable conversation patterns such as Contract Net for task allocation.
- Agent management: directory facilitator and agent management system services for discovery and lifecycle.
- Content and ontology layers: separating message envelope, content language, and shared domain ontology.
- Interoperability: platform-neutral specifications allowing agents from different vendors to interact.

### Applications

- Interoperable multi-agent platforms such as JADE built on FIPA specifications.
- Automated negotiation and task allocation between distributed agents.
- Service-discovery and brokering among heterogeneous software agents.
- Coordination of distributed simulations and industrial automation agents.

### Provenance

