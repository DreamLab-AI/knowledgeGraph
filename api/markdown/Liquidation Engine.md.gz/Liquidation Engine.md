A liquidation engine is the component of a decentralised lending or derivatives protocol that detects under-collateralised positions and forcibly closes or partially repays them to keep the system solvent. It continuously evaluates position health against collateral values supplied by price oracles, and when a position breaches its maintenance threshold it triggers liquidation, typically auctioning or selling collateral and rewarding external liquidators or keepers who execute the transaction. By enforcing collateralisation guarantees on-chain, the liquidation engine is central to risk management in DeFi lending, perpetual-futures, and collateralised-debt systems.

### Overview

- DeFi credit is over-collateralised: borrowers lock [[Collateral]] worth more than they borrow, and the liquidation engine enforces that buffer when prices move against them.
- Position health is summarised by a factor comparing collateral value (often haircut by a liquidation ratio) to outstanding debt; below the threshold the position becomes liquidatable.
- Execution is usually permissionless: external liquidators or keeper bots monitor positions and call the [[Smart Contract]] liquidation function, repaying debt in exchange for discounted collateral.
- Design choices around liquidation penalties, auction mechanisms, and partial versus full liquidation balance liquidator incentives, borrower fairness, and systemic resilience under volatility.

### Mechanisms

#### Health monitoring

- Per-position health computed from oracle-priced [[Collateral]] versus debt, updated on price changes and user actions.
- Maintenance and liquidation thresholds defined per asset to reflect volatility and liquidity.

#### Trigger and execution

- When health breaches the threshold the position is opened to liquidation by any caller.
- The [[Liquidation Engine]] repays debt and transfers discounted collateral to the liquidator, or runs a collateral auction.

#### Liquidator incentives

- A liquidation bonus or penalty spread compensates keepers for gas and price risk, ensuring positions are closed promptly.
- Competitive keeper networks and MEV searchers race to capture this spread.

#### Oracle dependence and risk

- Accurate, manipulation-resistant [[Oracle]] feeds are critical; stale or manipulated prices can cause wrongful or missed liquidations and bad debt.

### Applications

#### Money markets

- Enforcing solvency in over-collateralised lending pools as collateral prices fluctuate.

#### Perpetual and margin trading

- Closing under-margined [[Perpetual Futures]] positions, often interacting with an insurance fund to absorb residual losses.

#### Collateralised stable assets

- Liquidating vaults backing collateralised-debt-position stablecoins to defend the peg.

### Provenance

