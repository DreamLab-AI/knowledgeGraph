A supply chain maturity model is a staged model for benchmarking how mature a firm's supply chain practices are relative to best practice.[^1]

Netland, Alfnes and Fauske say a maturity model aims to aid companies in benchmarking the maturity of their operations relative to industry best practice.[^1] They quote Fraser and colleagues for six typical attributes: a number of maturity levels, typically three to six, a descriptive name and a generic description for each level, a number of dimensions or process areas, elements or activities for each area, and a description of each activity at each level.[^1]

## Limits of earlier models

That paper reports that Srai and Gregory (2005) reviewed twenty existing maturity models and found that they often lacked a supply chain perspective, were more or less single-function oriented, dominated by financial measures, not linked to overall business strategy, and mainly directed towards specific industries, making cross-industry comparison difficult.[^1]

## Examples

Netland and colleagues present a test of 50 stated best practices, each scored on a five-point scale from “Never or does not exist” to “Always or definitely exist”, where the highest maturity level corresponds to world best practice.[^1] In SCOR, process or practice maturity is a reference tool for evaluating how well supply chain processes and practices incorporate accepted best-practice process models, and it is one of three elements of performance evaluation alongside attributes and metrics.[^2] The SCOR 12.0 quick reference guide also describes the concept of process and practice maturities.[^3]

## Scope and distinctions

A maturity model grades practices on a scale. The WHO assessment described at [[WHO EVM]] instead scores criteria against an 80 percent standard.[^4] See [[Supply Chain Performance Framework]] and [[SCOR Model]].

## What the sources do not establish

The Lockamy and McCormack (2004) model, widely cited in this literature, could not be opened, so the page does not give its stage names. The Netland paper is a conference paper and its test is a proposal, not a validated standard in the sources opened.[^1]

[^1]: Torbjorn H. Netland, Erlend Alfnes and Hakon Fauske, “How mature is your supply chain? A supply chain maturity assessment test” (SINTEF, 2007). https://www.sintef.no/globalassets/project/smartlog/publikasjoner/2007/netland-et-al-_2007_-how-mature-is-your-supply-chain.pdf
[^2]: ASCM, “SCOR Digital Standard”, introduction and front matter, SCOR Version 14.0, 2025 (Internet Archive copy). https://web.archive.org/web/2025/https://www.ascm.org/globalassets/ascm_website_assets/docs/scor/intro-and-front-matter-scor-digital-standard-2025.pdf
[^3]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf
[^4]: World Health Organization, “Effective Vaccine Management (EVM) Global Data Analysis 2009-2020”, update of the WHO EVM1 database, July 2021. https://cdn.who.int/media/docs/default-source/immunization/supply-chain/evm-global-data-analysis-2009-2020.pdf

