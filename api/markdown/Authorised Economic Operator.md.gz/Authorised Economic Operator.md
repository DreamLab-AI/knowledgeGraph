An Authorised Economic Operator (AEO) is, in the World Customs Organization (WCO) definition, a party involved in the international movement of goods in whatever function that a national customs administration has approved, or that has been approved on its behalf, as complying with WCO or equivalent supply chain security standards.[^1][^2]

The WCO SAFE Framework adds that AEOs may include manufacturers, importers, exporters, brokers, carriers, consolidators, intermediaries, ports, airports, terminal operators, integrated operators, warehouses, distributors and freight forwarders.[^1] The WCO introduced its AEO programme in 2007 as the customs-business partnership programme of the Framework, and describes it as a means to secure and facilitate global trade by giving incentives to customs and to traders that work in partnership.[^2] See [[WCO SAFE Framework]].

## National schemes

The European Union, under Articles 38 and 39 of the Union Customs Code, lets an operator established in the customs territory that meets the criteria apply for status as an authorised economic operator. There are two types, for customs simplifications and for security and safety, and both may be held at once.[^3] The Commission calls them AEOC and AEOS and says the programme is open to all supply chain actors regardless of role.[^4] Status granted by one Member State is recognised by the customs authorities in all Member States, and holders enjoy more favourable treatment in customs controls, including fewer physical and document-based controls.[^3][^4]

The UK programme is based on the WCO SAFE Framework standards. HM Revenue and Customs says it is not mandatory, that it offers AEOC and AEOS status, and that it is open to all economic operators, including sole traders and small and medium businesses involved in the international supply chain.[^5]

## In the WTO agreement

The WTO Agreement on Trade Facilitation uses the term authorised operator. Members shall provide additional trade facilitation measures to operators who meet specified criteria, which relate to compliance or the risk of non-compliance.[^6] The criteria may include a record of compliance with customs and other laws, a system of managing records, financial solvency and supply chain security.[^6] The measures must include at least three from a list that covers a low rate of physical inspections, rapid release time and deferred payment of duties, taxes, fees and charges, among others.[^6] Members must also give other Members the possibility of negotiating mutual recognition of authorised operator schemes.[^6]

## Scope and distinctions

The AEO is a form of [[Trade Facilitation]]. Mutual recognition means an authorisation properly granted by one customs administration is accepted by another.[^2] A [[Customs Broker]] can itself be an AEO, since the SAFE list of possible AEOs includes brokers.[^1]

## What the sources do not establish

No opened source gives the number of AEOs worldwide or the monetary value of the benefits. The schemes differ in name, criteria and benefits between jurisdictions, and only the WCO, EU, UK and WTO texts were opened.

[^1]: World Customs Organization, “SAFE Framework of Standards 2021”. https://www.wcoomd.org/-/media/wco/public/global/pdf/topics/facilitation/instruments-and-tools/tools/safe-package/safe-framework-of-standards.pdf
[^2]: World Customs Organization, AEO programme About page. https://aeo.wcoomd.org/about
[^3]: European Union, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^4]: European Commission, Taxation and Customs Union, Authorised Economic Operator programme page. https://taxation-customs.ec.europa.eu/customs/authorised-economic-operator/programme_en
[^5]: HM Revenue and Customs (GOV.UK), “Authorised Economic Operator (AEO) - Introduction”. https://www.gov.uk/guidance/customs-technical-handbook-authorised-economic-operator-aeo/introduction
[^6]: World Trade Organization, “Agreement on Trade Facilitation”. https://www.wto.org/english/docs_e/legal_e/tfa-nov14_e.htm

