The Chapman-Kolmogorov Equation is a fundamental identity in probability theory and stochastic processes that expresses the consistency condition for transition probabilities of a Markov chain or continuous stochastic process. It states that the probability of moving from state i to state j in n+m steps equals the sum over all intermediate states k of the product of the n-step and m-step transition probabilities. This equation is the cornerstone of Markov chain analysis and underlies key algorithms in machine learning, Bayesian inference, and diffusion modelling.

### Semantic Classification

### Content

## Compositional Relationships (Components)

```
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:hasPart math:FokkerPlanckEquation))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:hasPart math:KolmogorovBackwardEquation))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:hasPart math:TransitionKernel))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:hasPart math:TransitionMatrix))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:hasPart math:MarkovSemigroup))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:hasPart math:StationaryDistribution))
```

## Dependency Relationships

```
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:requires math:MarkovProperty))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:requires math:ProbabilityMeasure))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:requires math:MeasureTheory))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:requires math:LinearAlgebra))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:dependsOn math:SigmaAlgebra))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:dependsOn math:ConditionalProbability))
```

## Capability Relationships

```
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:MarkovChainMonteCarlo))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:BayesianInference))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:HiddenMarkovModel))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:KalmanFilter))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:DiffusionModel))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:ValueFunction))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:ReinforcementLearning))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:UncertaintyQuantification))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:supports math:ProbabilisticProgramming))
```

## Implementation Relationships

```
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:implements math:MarkovChain))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:implements math:StochasticDifferentialEquation))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:implements math:ForwardBackwardAlgorithm))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:implements math:BellmanEquation))
```

## Reduction Relationships

```
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:reducesTo math:MatrixPowerIdentity))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:contrastsWith math:NonMarkovianProcess))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:contrastsWith math:FractionalBrownianMotion))
```

## About

The Chapman-Kolmogorov Equation is one of the most pervasive identities in all of applied mathematics, serving as the algebraic heart of the theory of Markov processes. Its origins lie at the intersection of physics and rigorous probability theory. Sydney Chapman, the British applied mathematician and geophysicist, derived the relation in 1928 while studying the statistical mechanics of Brownian motion and the diffusion of colloidal particles in non-uniform fluids. Chapman's approach was primarily physical, establishing that the probability of a displacement over a composite time interval factors through the integral over all intermediate positions. Three years later, Andrey Kolmogorov — working in Moscow to place probability theory on firm measure-theoretic foundations — derived the same identity as part of his monumental 1931 paper "Uber die analytischen Methoden in der Wahrscheinlichkeitsrechnung" ("On Analytical Methods in the Theory of Probability"). Kolmogorov used the Chapman-Kolmogorov identity as the foundational constraint from which he differentiated to obtain what are now called the Kolmogorov forward equation (already known in physics as the Fokker-Planck equation after Adriaan Fokker and Max Planck, who derived it heuristically in 1914 and 1917 respectively) and the Kolmogorov backward equation, which was genuinely new. William Feller extended the framework in 1949 within his influential semigroup-theoretic treatment, providing the modern functional-analytic language for Markov process generators.

The importance of the Chapman-Kolmogorov identity for modern machine learning cannot be overstated. It encodes precisely what it means for a random process to have no memory beyond the present state — the Markov property — and provides the composition law for transition kernels that makes all multi-step probabilistic predictions tractable. For a time-homogeneous Markov chain with transition matrix P, the identity is equivalent to the statement that P^(n+m) = P^n · P^m: matrix powers compose correctly. This apparently simple observation has profound algorithmic consequences. It implies that repeated matrix multiplication can be used to compute long-run transition probabilities, that eigenvectors of P correspond to invariant (stationary) distributions, and that the spectral gap of P governs mixing time — the number of steps required before the chain's distribution is indistinguishable from the stationary distribution. Mixing time analysis is directly relevant to the convergence guarantees of [[Markov Chain Monte Carlo]] algorithms.

In continuous state space and continuous time, the Chapman-Kolmogorov framework generates the Fokker-Planck PDE for the evolution of probability densities under drift vector field b(x) and diffusion tensor D(x): ∂_t p(x,t) = -∇·(b(x)p(x,t)) + ∇²·(D(x)p(x,t)). The backward (Kolmogorov) equation governs the evolution of expected values of observables. These PDEs are the continuous limits of the discrete Chapman-Kolmogorov recursion and connect the probabilistic framework to the theory of partial differential equations, enabling the rich toolkit of PDE analysis (maximum principles, energy methods, spectral theory) to be applied to stochastic systems. Physics-informed neural networks (PINNs) now solve these high-dimensional Fokker-Planck equations using deep learning, circumventing the curse of dimensionality that plagues traditional numerical PDE solvers.

## Extended OWL Axioms: Additional Semantic Relationships

```
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:BrownianMotion))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:WienerProcess))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:GaussianProcess))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:BellmanEquation))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:MarkovDecisionProcess))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:ScoreBasedGenerativeModel))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:VariationalInference))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:enables math:OptimalTransport))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:supports math:MolecularDynamics))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:supports math:FinancialMathematics))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:supports math:ClimateModelling))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:supports math:EpidemiologyModelling))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:EntropyProduction))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:FluctuationTheorem))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:contrastsWith math:LongRangeMemoryProcess))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:SpectralGap))
SubClassOf(math:ChapmanKolmogorovEquation
  ObjectSomeValuesFrom(math:relatedTo math:MixingTime))
```

## Formal Statement and Variants

**Discrete-time, discrete-state (Markov chain):**
Let {X_n} be a Markov chain with state space S and transition probabilities p_{ij}^{(n)} = P(X_{n+k} = j | X_k = i). Then:
p_{ij}^{(n+m)} = Σ_{k ∈ S} p_{ik}^{(n)} · p_{kj}^{(m)}  for all n, m ≥ 0, i, j ∈ S.
In matrix form: P^(n+m) = P^n · P^m.

**Continuous-time, discrete-state (continuous-time Markov chain):**
For transition functions P_{ij}(t) = P(X(t+s) = j | X(s) = i):
P_{ij}(t+s) = Σ_k P_{ik}(t) · P_{kj}(s).
Differentiating at t=0 yields Kolmogorov's forward and backward equations involving the generator matrix Q (with Q_{ij} being the rate from state i to state j).

**Continuous-time, continuous-state (diffusion processes):**
For transition density p(y,t | x,s):
p(y,t | x,s) = ∫ p(y,t | z,r) p(z,r | x,s) dz  for s < r < t.
Differentiation with respect to t yields the Fokker-Planck (forward) equation; differentiation with respect to s yields the Kolmogorov backward equation.

**Time-inhomogeneous generalisation:**
The identity holds for time-inhomogeneous processes by tracking both times explicitly: p(y,t|x,s) = ∫ p(y,t|z,r) p(z,r|x,s) dz. This is the form required for [[Diffusion Model]] forward processes where the noise schedule varies with timestep.

## Use Cases and Major Families

- **Hidden Markov Models (HMMs) and Speech Recognition**: HMMs represent sequences where hidden states follow a Markov chain and produce observable outputs probabilistically. The forward-backward (Baum-Welch) algorithm applies the Chapman-Kolmogorov recursion to compute the probability of an observation sequence in O(T · |S|²) time, where T is sequence length and |S| is the state space size. HMMs underpinned all commercial speech recognition systems from the 1980s to the emergence of deep neural network approaches around 2012 (Hinton et al.), and remain widely used in genomic sequence modelling, part-of-speech tagging, and financial regime detection.
- **Markov Chain Monte Carlo (MCMC)**: [[Markov Chain Monte Carlo]] algorithms (Metropolis-Hastings, Gibbs sampling, Hamiltonian Monte Carlo, No-U-Turn Sampler) construct Markov chains whose stationary distributions equal the target posterior. The Chapman-Kolmogorov identity guarantees that the chain's multi-step distributions converge to the stationary distribution provided the chain is ergodic (irreducible + aperiodic) and satisfies detailed balance. Spectral gap analysis via the Chapman-Kolmogorov composition gives mixing time bounds. MCMC is the workhorse of [[Bayesian Inference]] in probabilistic programming frameworks (Stan, PyMC, NumPyro).
- **Reinforcement Learning and Bellman Equations**: The Bellman equation for the value function V^π in an MDP is a specific instantiation of the Chapman-Kolmogorov recursion: V^π(s) = Σ_a π(a|s) Σ_{s'} P(s'|s,a) [R(s,a,s') + γ V^π(s')]. The transition probability P(s'|s,a) is a one-step Chapman-Kolmogorov kernel. Q-learning, SARSA, and policy gradient methods all operate on this Markov assumption. Continuous-time [[Reinforcement Learning]] in stochastic control uses the Kolmogorov backward equation as the Hamilton-Jacobi-Bellman PDE for the value function.
- **Kalman Filter and State Estimation**: The Kalman filter for linear-Gaussian state-space models applies the Chapman-Kolmogorov equation in the prediction step: the predicted state distribution p(x_t | y_{1:t-1}) is obtained by marginalising over x_{t-1} via the state transition kernel p(x_t | x_{t-1}) — a Chapman-Kolmogorov integration. For nonlinear systems, the Extended Kalman Filter (EKF) and Unscented Kalman Filter (UKF) approximate this integration. Particle filters (Sequential Monte Carlo) perform it by weighted Monte Carlo summation.
- **Score-Based Generative Models and Diffusion Models**: The [[Diffusion Model]] framework (Ho et al. 2020; Song et al. 2021) defines a forward noising process as a discrete-time Markov chain x_0, x_1, ..., x_T where each step adds Gaussian noise according to a schedule β_t: q(x_t | x_{t-1}) = N(x_t; √(1-β_t) x_{t-1}, β_t I). The Chapman-Kolmogorov identity immediately gives the closed-form marginal: q(x_t | x_0) = N(x_t; √(ᾱ_t) x_0, (1-ᾱ_t) I) with ᾱ_t = Π_{s=1}^t (1-β_s). Song et al. (2021) unified this into a continuous SDE framework where the forward process is an Itô SDE and the reverse process — used for generation — satisfies the reverse-time SDE derived via the score function ∇_x log p_t(x). The Chapman-Kolmogorov consistency is the mathematical guarantee that this reverse process is well-defined.
- **Gaussian Processes**: [[Gaussian Process]] regression and classification over temporal data exploit the Chapman-Kolmogorov identity through the Markov structure of certain covariance functions (e.g., Matérn kernels with half-integer smoothness). State-space formulations of GPs (Solin & Sarkka 2014) convert GP inference into a Kalman filtering problem, with the Chapman-Kolmogorov prediction step forming the core of the forward pass.
- **Financial Mathematics and Risk Modelling**: The Black-Scholes equation for option pricing is the Kolmogorov backward equation for a geometric Brownian motion model of asset prices. Credit risk models (Jarrow-Turnbull, reduced-form models) use Markov chains with Chapman-Kolmogorov transition matrices to model credit rating migration. The Chapman-Kolmogorov test — testing whether a stochastic process is Markovian by checking whether estimated multi-step transition probabilities are consistent — is applied in financial econometrics and neuroscience.
- **Genomics and Bioinformatics**: Probabilistic models of DNA sequence evolution (Jukes-Cantor, Kimura, GTR models) are time-homogeneous Markov chains on the nucleotide alphabet {A, C, G, T}. The Chapman-Kolmogorov identity governs how substitution probabilities compose over evolutionary time, enabling phylogenetic inference via likelihood computation. Hidden Markov models for gene prediction (e.g., CpG island detection) apply the forward-backward algorithm directly.

## Formal Mathematical Derivations and Key Theorems

Understanding the Chapman-Kolmogorov equation deeply requires tracking how the identity is used to derive the core equations of stochastic analysis and how those equations are connected to modern machine learning algorithms.

**Derivation of the Fokker-Planck (Forward Kolmogorov) Equation:**
Start from the continuous Chapman-Kolmogorov identity:
p(y, t+dt | x, s) = ∫ p(y, t+dt | z, t) p(z, t | x, s) dz

For a diffusion process X(t) satisfying the Itô SDE dX = b(X,t)dt + σ(X,t)dW, the short-time transition kernel has the Gaussian approximation:
p(y, t+dt | z, t) ≈ N(y; z + b(z,t)dt, σ(z,t)σ(z,t)^T dt)

Substituting into the Chapman-Kolmogorov identity and expanding in dt using Taylor series, then taking dt → 0, yields the Fokker-Planck equation:
∂_t p(x,t) = -Σ_i ∂_{x_i}[b_i(x,t) p(x,t)] + (1/2) Σ_{i,j} ∂²_{x_i x_j}[(σσ^T)_{ij}(x,t) p(x,t)]

This PDE describes how the probability density of X(t) evolves over time under drift b and diffusion σσ^T.

**Derivation of the Kolmogorov Backward Equation:**
For the expected value f(x,t) = E[g(X(T)) | X(t) = x] (backward problem), applying Itô's lemma and taking expectations gives:
∂_t f + b(x,t)·∇_x f + (1/2) tr(σ(x,t)σ(x,t)^T ∇²_x f) = 0
with terminal condition f(x,T) = g(x).

This is the Kolmogorov backward equation, fundamental to option pricing (Black-Scholes), reinforcement learning value functions (Hamilton-Jacobi-Bellman), and exit time problems.

**Connection to the Bellman Equation:**
In discrete-time [[Reinforcement Learning]] with MDP (S, A, P, R, γ), the value function V^π satisfies:
V^π(s) = Σ_a π(a|s) [R(s,a) + γ Σ_{s'} P(s'|s,a) V^π(s')]

The term Σ_{s'} P(s'|s,a) V^π(s') is precisely the Chapman-Kolmogorov one-step marginalisation: it computes the expected value at the next state by integrating over the transition kernel. The Bellman equation is thus a dynamic programming recursion built on the Chapman-Kolmogorov semigroup structure.

**Score-Based Generative Model via Reverse SDE:**
In the continuous diffusion framework (Song et al. 2021), the forward process is:
dX = f(X,t)dt + g(t)dW  (Itô SDE)
The Chapman-Kolmogorov identity guarantees that marginal densities p_t(x) evolve via the Fokker-Planck equation. The key insight is that the reverse-time SDE (Anderson 1982):
dX = [f(X,t) - g(t)² ∇_x log p_t(X)] dt + g(t) dW̄
is also a valid diffusion process with the same marginals run in reverse time. Learning the score function s_θ(x,t) ≈ ∇_x log p_t(x) via denoising score matching therefore enables sampling by running the reverse SDE from p_T ≈ N(0,I) back to p_0 (the data distribution). The Chapman-Kolmogorov consistency of both forward and reverse processes is the mathematical guarantee that this procedure generates samples from the correct distribution.

## Algorithm Families and Computational Methods

The Chapman-Kolmogorov equation is the mathematical substrate for a large family of algorithms across machine learning, statistics, and scientific computing. Each algorithm exploits the Markov semigroup structure in a different way:

**MCMC Algorithms (Markov chain stationarity):**

- Metropolis-Hastings: Constructs a reversible Markov chain with desired stationary distribution π by accepting/rejecting proposals according to the Metropolis ratio. The Chapman-Kolmogorov identity ensures that detailed balance with respect to π implies π is stationary.
- Gibbs Sampling: A special case of Metropolis-Hastings that draws each variable from its full conditional distribution, always accepting. Provably converges by the Chapman-Kolmogorov recursion.
- Hamiltonian Monte Carlo (HMC): Augments the state space with auxiliary momentum variables and simulates Hamiltonian dynamics using the leapfrog integrator. The Chapman-Kolmogorov identity at the augmented level guarantees the target measure is preserved, while the Hamiltonian dynamics provide long-range moves that reduce autocorrelation.
- No-U-Turn Sampler (NUTS): Automatically adapts the trajectory length in HMC to avoid unnecessary backtracking, making HMC practical without manual tuning. Implemented in Stan, PyMC, and NumPyro; the convergence guarantee rests on the Chapman-Kolmogorov property of the base HMC kernel.

  **Filtering and Smoothing Algorithms (Chapman-Kolmogorov prediction step):**

- Kalman Filter: For linear-Gaussian state-space models, the prediction step p(x_t | y_{1:t-1}) = ∫ p(x_t | x_{t-1}) p(x_{t-1} | y_{1:t-1}) dx_{t-1} is a Chapman-Kolmogorov integration that has an exact closed-form Gaussian solution via matrix operations.
- Particle Filter (Sequential Monte Carlo): Approximates the Chapman-Kolmogorov prediction integral by propagating weighted particles through the transition kernel, then re-weighting by the likelihood of new observations. Used in robotics localisation, object tracking, and financial state estimation.
- Forward-Backward Algorithm (HMM): Computes the total probability of an observation sequence by dynamic programming on the Chapman-Kolmogorov recursion: α_t(i) = Σ_j α_{t-1}(j) P_{ji} b_i(O_t) where α_t(i) is the probability of being in state i at time t having generated observations O_{1:t}.

  **Deep Learning Algorithms (Chapman-Kolmogorov as generative backbone):**

- DDPM Sampling: Iteratively runs the reverse Markov chain x_T → x_{T-1} → ... → x_0 where each step uses the learned denoising network to estimate p_{θ}(x_{t-1} | x_t). The full chain is a Chapman-Kolmogorov consistent Markov process.
- DDIM (Denoising Diffusion Implicit Models): A non-Markovian generalisation of DDPM that uses a deterministic implicit sampler to reduce the number of steps from T (typically 1000) to 20–50, trading sampling speed for mild quality loss. While non-Markovian, it preserves the Chapman-Kolmogorov marginals by construction.
- Flow Matching (Lipman et al. 2022): Parameterises a vector field v_θ(x,t) that transforms the noise distribution into the data distribution via an ODE. The probability path p_t(x) connecting noise to data satisfies the continuity equation ∂_t p_t + ∇·(v_θ p_t) = 0, which is the deterministic (zero-diffusion) limit of the Fokker-Planck equation.

## Academic Context

The equation bears the names of two figures who approached probability from very different traditions. Sydney Chapman (1888–1970) was a British applied mathematician whose primary contributions lay in atmospheric physics, geophysics, and the kinetic theory of gases; his derivation of the Chapman-Kolmogorov relation arose from gas dynamics and Brownian motion. Andrey Kolmogorov (1903–1987) was among the greatest mathematicians of the twentieth century, responsible for the axiomatic foundations of modern probability theory (Grundbegriffe der Wahrscheinlichkeitsrechnung, 1933), turbulence theory, algorithmic complexity (Kolmogorov complexity), and topology. His 1931 paper placed the relation on rigorous analytical footing and derived the forward and backward equations as consequences.

The theoretical study of Chapman-Kolmogorov equations intersects with functional analysis through the theory of strongly continuous semigroups (C₀-semigroups) of operators, where the transition semigroup (P_t)_{t≥0} satisfies P_{t+s} = P_t ∘ P_s — the semigroup property that is exactly the operator form of the Chapman-Kolmogorov identity. The generator A of this semigroup (A = lim_{t→0} (P_t - I)/t) gives the infinitesimal rate of change and corresponds to the second-order differential operator appearing in the Fokker-Planck and backward equations. This connection to semigroup theory was developed by Feller (1949, 1952), Hille and Phillips, and Yosida, forming the mathematical core of modern stochastic analysis.

Contemporary research on Chapman-Kolmogorov equations in machine learning includes: physics-informed neural networks for solving high-dimensional Fokker-Planck equations (Zhai et al., 2022; MLSYS 2022); distributional RL that maintains full distributions over returns using Chapman-Kolmogorov-consistent updates (Bellemare et al., 2017; Dabney et al., 2018 with QR-DQN, IQN); and the Chapman-Kolmogorov test for detecting memory in coupled stochastic processes (Nature Scientific Reports, 2025). The 2025 Bidirectional Diffusion Bridge paper (arXiv:2502.09655) explicitly invokes the Chapman-Kolmogorov identity to derive bridging distributions between two data distributions.

## Key Terminology

- **Markov Property**: The property that future states of a stochastic process depend only on the current state, not on the history of past states. The Chapman-Kolmogorov equation is the consistency condition implied by this property.
- **Transition Kernel (Transition Probability)**: A function P(x, A) giving the probability of moving from state x to a set A in one step. The Chapman-Kolmogorov equation specifies how kernels compose over multiple steps.
- **Transition Matrix**: The finite-state analogue of the transition kernel: a matrix P with P_{ij} = P(X_{n+1} = j | X_n = i), P^n_{ij} = P(X_{n+k} = j | X_k = i) by the Chapman-Kolmogorov identity.
- **Stationary Distribution**: A probability distribution π satisfying π = πP (for discrete chains) or the Fokker-Planck equation with ∂_t p = 0 (for diffusions). The unique limit of P^n as n→∞ for ergodic chains.
- **Ergodicity**: The property that a Markov chain mixes to its unique stationary distribution from any starting state. Requires irreducibility (all states communicating) and aperiodicity (no cyclic deterministic trajectories).
- **Detailed Balance (Reversibility)**: Condition π_i P_{ij} = π_j P_{ji}: the probability flux from i to j equals that from j to i at stationarity. Sufficient for π to be stationary; exploited in Metropolis-Hastings.
- **Fokker-Planck Equation**: The Kolmogorov forward equation for continuous diffusion processes: ∂_t p = -∇·(bp) + (1/2)∇²:(Dp). Describes how the probability density of the process evolves over time.
- **Kolmogorov Backward Equation**: The adjoint of the Fokker-Planck equation governing the evolution of expected values of observables backward in time. Equivalent to Hamilton-Jacobi-Bellman PDE in stochastic control.
- **Semigroup Property**: The operator form of Chapman-Kolmogorov: P_{t+s} = P_t ∘ P_s. The generator L of this semigroup is the infinitesimal rate operator (second-order differential operator for diffusions).
- **Spectral Gap**: The difference between the largest (1) and second-largest eigenvalue of the transition matrix, governing the exponential rate of convergence to stationarity. Critical for MCMC mixing time analysis.
- **Mixing Time**: The number of steps T_mix(ε) required for the Markov chain's distribution to be within ε (in total variation) of the stationary distribution. Scales as O(spectral gap⁻¹ · log ε⁻¹).
- **Score Function**: The gradient of the log-density ∇_x log p_t(x), used in score-based diffusion models to parameterise the reverse-time SDE. Learning the score function is equivalent to learning the transition kernel of the reverse Markov chain.
- **Forward-Backward Algorithm**: Dynamic programming algorithm for HMMs that computes marginal state probabilities using the Chapman-Kolmogorov recursion in both the forward (α) and backward (β) directions.
- **Bellman Equation**: The dynamic programming recursion for value functions in MDPs, structurally equivalent to a one-step Chapman-Kolmogorov marginalisation of the next-state distribution.
- **Schrödinger Bridge**: The minimum-entropy Markov process connecting two prescribed marginal distributions at times 0 and T, defined via the Chapman-Kolmogorov constraint. Generalises optimal transport to stochastic dynamics.
- **DDPM**: Denoising Diffusion Probabilistic Model; a deep generative model whose forward process is a Chapman-Kolmogorov consistent Markov chain adding Gaussian noise and whose reverse process is a learned denoising chain.
- **Flow Matching**: A generative modelling approach parameterising a deterministic vector field to transform noise into data, representing the zero-diffusion limit of the Fokker-Planck / Chapman-Kolmogorov framework.

## Current Landscape (2026)

By 2026, the Chapman-Kolmogorov framework is experiencing a renaissance driven by the explosion of [[Diffusion Model]] research. Every major image, video, audio, and molecular generation system — Stable Diffusion (Stability AI), DALL-E 3 (OpenAI), Sora (OpenAI), AudioLDM 2, RFDiffusion (protein design) — relies on the mathematical framework of Markov chain forward processes and their Chapman-Kolmogorov-consistent reversals. The continuous SDE formulation of Song et al. (ICLR 2021 Oral) has become the canonical mathematical treatment, and the 2025 Physics-Informed Diffusion Models paper (ICLR 2025) extends this to ensure generated samples satisfy physical conservation laws — an important development for scientific AI applications.

In reinforcement learning, continuous-time RL formulations that use the Kolmogorov backward equation as the value function PDE are seeing renewed interest (arXiv:2504.01482, 2025), driven by the need for reliable control in continuous physical systems (robotics, autonomous vehicles). The connection between the Chapman-Kolmogorov equation and the Bellman equation is being exploited in distributional RL (C51, QR-DQN, IQN, IDAC), where the full distribution of returns — not just its expectation — is maintained and updated according to Chapman-Kolmogorov-consistent distributional Bellman operators.

In [[Bayesian Inference]], the Hamiltonian Monte Carlo sampler (specifically the No-U-Turn Sampler implemented in Stan, PyMC, and NumPyro) has become the industry standard for probabilistic programming, and its theoretical convergence guarantees rest directly on Chapman-Kolmogorov-based mixing time analysis. The computational efficiency of MCMC at scale is an active research area, with methods such as subsampling MCMC and parallel tempering addressing the practicalities of posterior inference over large datasets.

The Chapman-Kolmogorov test for detecting non-Markovian memory has been applied to cryptocurrency data (Scientific Reports, 2025), demonstrating ongoing relevance in financial econometrics. Quantum extensions of the Chapman-Kolmogorov identity — quantum master equations satisfying or violating the quantum Chapman-Kolmogorov identity — are an active research area in quantum open systems relevant to quantum machine learning.

## Applications in Scientific Simulation and Engineering

Beyond machine learning, the Chapman-Kolmogorov framework underpins a vast range of simulation and engineering applications where uncertainty must be propagated over multiple time steps or spatial scales:

**Molecular Dynamics and Drug Discovery**: Molecular dynamics (MD) simulations model the time evolution of protein, ligand, and solvent molecules under classical or quantum mechanical force fields. The configurational space evolution is approximately Markovian at sufficiently coarse time resolution, enabling Markov State Models (MSMs) — a Chapman-Kolmogorov–based framework for analysing protein folding and conformational dynamics. Noé and colleagues (2019) demonstrated that deep learning can learn MSM transition matrices from MD trajectory data, and the resulting Markov models obey the Chapman-Kolmogorov identity by construction. These MSMs accelerate drug discovery by predicting binding kinetics, allosteric pathways, and ligand unbinding timescales that are too slow to observe in direct MD simulation.

**Climate and Weather Modelling**: Ensemble weather forecast systems represent forecast uncertainty via stochastic Markov processes over atmospheric state variables. The Chapman-Kolmogorov equation governs how ensemble members propagate in time, and ensemble Kalman filters (EnKF) use the Chapman-Kolmogorov prediction step to propagate ensemble covariances. For climate projections, stochastic parameterisation schemes model sub-grid scale processes (turbulence, convection, clouds) as Markov processes whose statistics are calibrated to high-resolution simulations.

**Finance: Option Pricing and Risk Management**: The Black-Scholes partial differential equation for European option pricing is formally the Kolmogorov backward equation for a geometric Brownian motion model of the underlying asset price. The price of an option with payoff g(S_T) at time T, given asset price S_t = s at time t, satisfies V(s,t) = E_s[g(S_T)], which by the Feynman-Kac formula satisfies the backward PDE ∂_t V + rS ∂_S V + (σ²S²/2) ∂²_{SS} V = rV. For American options and exotic contracts, the Chapman-Kolmogorov equation underlies Monte Carlo pricing methods (least-squares Monte Carlo, Longstaff-Schwartz) and finite difference schemes for the backward PDE. Credit risk models (CreditMetrics, KMV) use Markov transition matrices calibrated to historical default and migration data — matrices that must satisfy the Chapman-Kolmogorov consistency condition when composed over multiple periods.

**Telecommunications and Queuing Theory**: The Markovian queuing model M/M/k (Erlang queuing formula) uses the Chapman-Kolmogorov equation for continuous-time Markov chains to compute steady-state queue length distributions, service rates, and blocking probabilities. These results underpin the dimensioning of telecommunications networks, call centre staffing, and internet packet routing. The generalisation to non-Markovian service times (M/G/k) requires going beyond the standard Chapman-Kolmogorov framework, but the Markovian baseline remains the analytical starting point.

**Epidemiology and Compartmental Models**: The SIR, SEIR, and related compartmental models for infectious disease spread can be formulated as continuous-time Markov chains on population state vectors. The Chapman-Kolmogorov equations give the time evolution of the probability distribution over infection states, and the Fokker-Planck limit yields deterministic ODEs when population sizes are large. Stochastic extensions are critical for modelling outbreak dynamics in small populations where demographic noise matters. During the COVID-19 pandemic (2020–2022), MCMC-based Bayesian inference over SIR model parameters from case data used Chapman-Kolmogorov–grounded forward simulation as the likelihood model.

**Robotics and Autonomous Systems**: Robot state estimation (SLAM — Simultaneous Localisation and Mapping) applies Kalman filtering and particle filtering — both Chapman-Kolmogorov-based algorithms — to fuse noisy sensor data (LiDAR, camera, IMU) with motion models to maintain a probabilistic map and robot position estimate. Probabilistic roadmap planners and Rapidly-exploring Random Tree (RRT) algorithms plan under uncertainty using Markov models of robot dynamics. Model Predictive Control (MPC) with uncertainty propagates state distributions via the Chapman-Kolmogorov prediction step to plan robust trajectories under uncertain dynamics.

## UK Context

The UK has a distinguished tradition in stochastic analysis and the mathematical fields underlying the Chapman-Kolmogorov equation. Cambridge University's Department of Pure Mathematics and Mathematical Statistics (DPMMS) and the Statistical Laboratory have long been central to stochastic process theory; Andrey Kolmogorov's visit to Cambridge in the 1930s reinforced transatlantic mathematical exchange. David Williams (then at Cambridge, later Wales) contributed foundational monographs on diffusions, Markov processes, and martingales that shaped UK probability education. The Probability Laboratory at the University of Warwick Mathematics Institute is one of Europe's leading centres for the theory of stochastic processes, with faculty including figures such as Martin Hairer (Fields Medal 2014 for regularity structures, directly connected to stochastic PDEs and the Fokker-Planck framework) and Roger Tribe. Oxford's Mathematical Institute has strong stochastic analysis groups; Terry Lyons' rough paths theory (developed at Oxford) provides an alternative analytical framework for stochastic differential equations that complements and extends the Chapman-Kolmogorov viewpoint.

For machine learning applications, Edinburgh's School of Informatics houses groups working on Gaussian process methods (Neil Lawrence's group, now partly at Cambridge), which exploit state-space formulations grounded in Chapman-Kolmogorov prediction steps. The Alan Turing Institute brings together probabilistic modelling researchers from across the UK, including Bayesian inference and MCMC experts. Bristol's Computational Statistics and Machine Learning group and Warwick's Statistics department maintain active MCMC convergence research programmes.

In Northern England, the University of Leeds' Statistics department and Manchester's School of Mathematics contribute to stochastic process theory. The University of Sheffield has historical strength in Bayesian methodology. Newcastle University's School of Mathematics, Statistics and Physics applies stochastic methods to environmental modelling, climate science, and biomedical data — all areas where the Chapman-Kolmogorov framework is foundational for state estimation and uncertainty quantification.

Sydney Chapman himself worked at the University of Manchester (1919–1924) as Beyer Professor of Mathematics before moving to Imperial College London (1924–1953), making the equation's British connection explicit. The Manchester tradition in applied mathematics and physics continues to apply probabilistic and stochastic methods across engineering and physical sciences.

## Quantum and Non-Classical Extensions

The classical Chapman-Kolmogorov framework assumes that probabilities are non-negative real numbers and that conditional probabilities multiply in the classical Bayesian way. Quantum mechanics violates both of these assumptions: quantum states are described by density matrices (positive semi-definite complex matrices of trace 1), and quantum conditional probabilities are not simply products of marginal probabilities due to interference and entanglement. This has motivated the development of quantum analogues of the Chapman-Kolmogorov equation.

For an open quantum system (a quantum system interacting with an environment), the state evolves via a quantum dynamical map Λ_t satisfying Λ_{t+s} = Λ_t ∘ Λ_s — the quantum Chapman-Kolmogorov (semigroup) equation. This is the quantum analogue of the classical Markov semigroup property. When this equation is satisfied (together with complete positivity and trace preservation), the system is Markovian in the quantum sense, and the evolution is governed by the Lindblad master equation:
dρ/dt = -i[H,ρ]/ℏ + Σ_k (L_k ρ L_k† - (1/2)(L_k†L_k ρ + ρ L_k†L_k))

Many real quantum systems are non-Markovian — their evolution depends on memory of past states — which violates the quantum Chapman-Kolmogorov equation. Detecting and quantifying quantum non-Markovianity (Rivas et al. 2014; Breuer et al. 2016) is an active research area, as quantum memory effects can be exploited for quantum computing and quantum communication. The violation of the quantum Chapman-Kolmogorov identity serves as a witness for non-Markovian dynamics, with applications to quantum noise characterisation in quantum processors and quantum error correction protocol design.

Quantum machine learning (QML) attempts to exploit quantum hardware to accelerate machine learning algorithms. Quantum MCMC (Szegedy 2004; Wocjan & Abeyesinghe 2008) proposes quantum speedups for mixing Markov chains via quantum walks, potentially achieving quadratic speedup in mixing time for certain chain families. The quantum Chapman-Kolmogorov equation is the theoretical underpinning of quantum Markov chain mixing analysis, and quantum algorithms for solving Fokker-Planck equations (Liu et al. 2021) exploit quantum linear systems algorithms to achieve exponential speedup over classical finite difference methods for specific problem classes.

## Numerical Methods and Software Ecosystems

The practical application of Chapman-Kolmogorov–based algorithms requires robust numerical methods and software implementations. Several ecosystems have developed around different application domains:

**Probabilistic Programming Languages (PPLs)**: Stan (Carpenter et al. 2017), PyMC (Salvatier et al. 2016), NumPyro (Bingham et al. 2019), and Pyro (Bingham et al. 2019) provide declarative languages for specifying probabilistic models and automatically applying MCMC or variational inference. The NUTS sampler implemented in Stan and PyMC relies on HMC with automatic step-size and trajectory-length adaptation, with theoretical convergence guarantees resting on the Chapman-Kolmogorov Markov property of HMC transitions. These tools have become standard in Bayesian data analysis across social science, ecology, and medicine.

**Deep Learning Frameworks for Diffusion Models**: HuggingFace Diffusers, JAX/FLAX implementations, and PyTorch-based libraries (Denoising Diffusion PyTorch, Score SDE PyTorch) provide standardised implementations of DDPM, DDIM, and score-based generative models. The Chapman-Kolmogorov noise schedule computation (closed-form marginals q(x_t | x_0)) is typically implemented as a precomputed lookup table of α_t and σ_t values.

**Filtering and State Estimation Libraries**: FilterPy (Python), the Julia BayesFilters.jl ecosystem, and MATLAB's Control System Toolbox provide Kalman filter, Extended Kalman Filter, Unscented Kalman Filter, and Particle Filter implementations. These are used in robotics (ROS navigation stack), aerospace (INS/GPS integration), and finance (regime-switching model estimation).

**Markov State Modelling for Molecular Dynamics**: PyEMMA (Scherer et al. 2015) and MSMBuilder provide tools for constructing, validating, and analysing Markov State Models from molecular dynamics trajectory data. The Chapman-Kolmogorov test — comparing estimated multi-step transition matrices against compositions of one-step matrices — is a standard validation procedure implemented in these libraries. Models that fail the Chapman-Kolmogorov test indicate insufficient lag time (the process is not yet Markovian on the chosen timescale) and require longer lag times or finer state decomposition.

**Reinforcement Learning Toolkits**: OpenAI Gymnasium (formerly Gym), Stable-Baselines3, and RLlib provide MDP environment interfaces and RL algorithm implementations that implicitly rely on the Markovian structure (transition probability kernel) of the environment for correctness of Q-learning, policy gradient, and actor-critic algorithms.

## Related Equations and Mathematical Hierarchy

The Chapman-Kolmogorov equation sits at the centre of a hierarchy of equations in probability theory and stochastic analysis. Understanding the relationships between these equations clarifies the equation's role in the broader mathematical landscape:

- **Chapman-Kolmogorov equation** (parent): The consistency condition P(n+m) = P(n) · P(m) for all n, m. Holds for any Markov process by definition of the Markov property.
- **[[Fokker-Planck Equation]]** (derived): The forward PDE ∂_t p = L*p obtained by differentiating the Chapman-Kolmogorov integral equation with respect to t. Describes density evolution under drift and diffusion.
- **Kolmogorov Backward Equation** (derived): The backward PDE ∂_t f = Lf obtained by differentiating with respect to s. Governs expected values of terminal functionals.
- **[[Bellman Equation]]** (special case): Discrete-time dynamic programming recursion; a one-step Chapman-Kolmogorov marginalisation for the value function under the reward-augmented transition kernel.
- **Hamilton-Jacobi-Bellman (HJB) Equation** (continuous limit): The PDE V_t + L V = -r obtained as the continuous-time limit of the Bellman equation. Central to stochastic optimal control.
- **Kolmogorov Forward Equation for Densities on Graphs** (graph generalisation): For Markov chains on finite graphs, the Chapman-Kolmogorov matrix recurrence plus the stationary distribution eigenvector equation π P = π. Used in PageRank, spectral clustering, and graph neural diffusion.
- **Quantum Lindblad Master Equation** (quantum generalisation): The open quantum system analogue ρ̇ = -i[H,ρ]/ℏ + D(ρ) where D is the dissipator. Satisfies quantum Chapman-Kolmogorov when the process is Markovian in the quantum sense.
- **Boltzmann Equation** (kinetic theory ancestor): The physical precursor studied by Chapman; the Boltzmann equation's collision integral, in the diffusion limit, yields the Fokker-Planck equation via the Chapman-Kolmogorov framework.
- **Smoluchowski Equation** (overdamped limit): The Fokker-Planck equation for overdamped Brownian motion in a potential V: ∂_t p = ∇·(∇V p + k_BT ∇p). Foundational to protein dynamics and colloid physics.
- **Continuity Equation / Liouville Equation** (zero-diffusion limit): When diffusion vanishes (σ → 0), the Fokker-Planck reduces to the continuity equation ∂_t p = -∇·(b p), governing deterministic density transport. The basis of [[Flow Matching]] generative models.

## Worked Example: Diffusion Model Noise Schedule via Chapman-Kolmogorov

A concrete illustration of the Chapman-Kolmogorov equation in modern machine learning is the derivation of the closed-form marginal distribution in [[Diffusion Model]] forward processes. This example demonstrates how the identity enables efficient training of denoising neural networks:

- **Step 1 — Define the forward one-step kernel**: For Denoising Diffusion Probabilistic Models (DDPM, Ho et al. 2020), the one-step transition is q(x_t | x_{t-1}) = N(x_t; √(1-β_t) x_{t-1}, β_t I) where β_t ∈ (0,1) is the noise schedule.
- **Step 2 — Apply Chapman-Kolmogorov recursively**: By the Markov property, the two-step marginal is q(x_2 | x_0) = ∫ q(x_2 | x_1) q(x_1 | x_0) dx_1. Since both kernels are Gaussian and their composition is Gaussian (closed under convolution), this integral can be computed analytically.
- **Step 3 — Compute the composition**: q(x_2 | x_0) = N(x_2; √(1-β_2)√(1-β_1) x_0, [β_2 + (1-β_2)β_1] I) = N(x_2; √(ᾱ_2) x_0, (1-ᾱ_2) I) where ᾱ_t = Π_{s=1}^t (1-β_s).
- **Step 4 — Generalise to t steps by induction**: The Chapman-Kolmogorov identity guarantees that this composition formula generalises to all t steps: q(x_t | x_0) = N(x_t; √(ᾱ_t) x_0, (1-ᾱ_t) I).
- **Training benefit**: This closed form allows training the denoising network ε_θ(x_t, t) directly on (x_0, t) pairs without simulating the full t-step chain. For any x_0 and noise level t, we sample x_t = √(ᾱ_t) x_0 + √(1-ᾱ_t) ε, ε ~ N(0,I) in one operation, then train ε_θ to predict ε.
- **Chapman-Kolmogorov as computational shortcut**: Without the Chapman-Kolmogorov identity, training would require sequential simulation of all t steps for each training example, making it computationally prohibitive for large t (typically t = 1000). The identity reduces this to O(1) computation.
- **Generalisation to continuous time**: Song et al. (2021) unified this by replacing the discrete recursion with a continuous Itô SDE dX = f(X,t)dt + g(t)dW, for which the Chapman-Kolmogorov identity becomes the Fokker-Planck PDE for marginal densities, enabling arbitrary continuous noise schedules.

## Probabilistic Programming and Software Ecosystem Details

The practical impact of the Chapman-Kolmogorov equation in modern data science is mediated primarily through probabilistic programming languages and machine learning libraries that implement its derived algorithms:

**Stan (2012–present)**: A probabilistic programming language developed at Columbia University (Andrew Gelman, Bob Carpenter et al.). Users write model specifications in the Stan language; Stan automatically differentiates the log-posterior and runs the NUTS sampler. Stan underpins Bayesian data analysis across epidemiology (COVID-19 models), ecology, psychology, and social science. The NUTS convergence guarantee rests on the HMC Chapman-Kolmogorov Markov property.

**PyMC (formerly PyMC3, 2012–present)**: Python-based probabilistic programming built on Theano (PyMC3) then PyTensor (PyMC v4+). Implements NUTS, Metropolis, ADVI (variational inference), and Gaussian process models. The `pm.sample()` call internally runs the Chapman-Kolmogorov consistent MCMC chain.

**NumPyro and Pyro (2017–present)**: JAX-based (NumPyro) and PyTorch-based (Pyro) probabilistic programming. Both implement the NUTS sampler and variational inference. NumPyro's JAX backend enables vectorised MCMC chains on GPU/TPU, dramatically accelerating Chapman-Kolmogorov–based inference for large-scale Bayesian models.

**HuggingFace Diffusers (2022–present)**: The dominant library for [[Diffusion Model]] inference. Implements DDPM, DDIM, Score SDE, LCM (Latent Consistency Model), and flow matching schedulers. All schedulers implement some variant of the Chapman-Kolmogorov noise schedule and reverse denoising process.

**PyEMMA (2015–present)**: Software for Markov state modelling of molecular dynamics trajectories. Implements MSM construction, the Chapman-Kolmogorov test for validation, spectral analysis for implied timescales, and transition path theory for pathway analysis.

**FilterPy (2015–present)**: Python library implementing Kalman filter, Extended Kalman Filter, Unscented Kalman Filter, and particle filter. Each filter implements a version of the Chapman-Kolmogorov prediction step for state distribution propagation.

**RLlib (2017–present) and Stable-Baselines3 (2020–present)**: Reinforcement learning libraries implementing Q-learning, PPO, SAC, TD3, and other algorithms that operate on Markovian MDP environments with Chapman-Kolmogorov transition dynamics.

## Future Directions (2026–2030)

- **High-Dimensional Fokker-Planck Solvers**: Physics-informed neural networks and neural operator methods are progressively unlocking the ability to solve the [[Fokker-Planck Equation]] in 100+ dimensional spaces, critical for [[Molecular Dynamics]], protein folding energy landscapes, and turbulent fluid simulations. Deep learning–based PDE solvers exploit the Chapman-Kolmogorov structure for efficient training signal generation.
- **Non-Markovian Generalisations**: Many real systems (financial markets with memory, anomalous diffusion in biological cells, correlated noise in materials) are not strictly Markovian. Generalisations including [[Fractional Brownian Motion]], rough volatility models, and the path-dependent SDEs of Terry Lyons' [[Rough Paths Theory]] are extending the Chapman-Kolmogorov framework to systems where the full path history matters. The Chapman-Kolmogorov test (Scientific Reports, 2025) provides empirical tools to detect memory.
- **Quantum Chapman-Kolmogorov Equations**: Quantum open systems satisfying or violating the quantum Chapman-Kolmogorov identity (Lindblad master equations vs non-Markovian quantum dynamics) are a frontier of quantum machine learning. Developing efficient quantum algorithms for solving quantum Fokker-Planck equations could accelerate molecular simulation.
- **Continuous-Time [[Reinforcement Learning]] at Scale**: Applying Kolmogorov backward equation–based value function representations to large-scale robotics and autonomous vehicle control, beyond the current discrete-time MDP approximations used in most deep RL systems.
- **Diffusion Bridge Models**: The 2025 Bidirectional Diffusion Bridge paper and related work on [[Schrödinger Bridge]] problems use the Chapman-Kolmogorov identity to define transport maps between arbitrary distributions, with applications to domain translation (image-to-image, molecule-to-molecule), cell trajectory inference in single-cell genomics, and unpaired data transformation.
- **Certified [[Uncertainty Quantification]]**: Using Chapman-Kolmogorov–based analysis of [[Markov Chain]] mixing to provide rigorous statistical guarantees (PAC-Bayes bounds, conformal prediction) on uncertainty estimates from [[Bayesian Inference]] deep learning, addressing safety requirements for medical and autonomous driving AI systems.
- **Learning Transition Kernels from Data**: Neural network–parameterised transition kernels that satisfy the Chapman-Kolmogorov constraint by construction, enabling data-driven stochastic process discovery for dynamical systems modelling without requiring an explicit mechanistic model.
- **Flow Matching and Conditional Transport**: The 2022–2025 wave of [[Flow Matching]] models (Lipman et al., Albergo et al., Liu et al.) provides a deterministic-ODE perspective on Chapman-Kolmogorov transport that achieves similar generative quality to [[Diffusion Model]] methods with fewer neural function evaluations, potentially replacing diffusion models in high-throughput generation applications.
- **Tensor Network Methods for High-Dimensional Markov Chains**: Tensor train (TT) decompositions and matrix product states (MPS) from quantum physics are being adapted to represent and compute with high-dimensional transition matrices that would be intractable to store densely, enabling Chapman-Kolmogorov recursions in molecular simulation and combinatorial optimisation.

## Connections to Deep Learning and Neural Network Theory

The Chapman-Kolmogorov framework connects to deep learning theory through multiple channels, many of which have become practically important in the design and analysis of modern [[Neural Network]] architectures. The most direct connection is through [[Diffusion Model]]s, as detailed in the Use Cases section, but the framework also influences our understanding of stochastic optimisation, [[Uncertainty Quantification]], and generative modelling more broadly.

In stochastic gradient descent (SGD) and its variants (Adam, AdaGrad, RMSProp), the parameter update sequence constitutes a discrete-time Markov chain in weight space. The Chapman-Kolmogorov equation governs the evolution of the distribution over parameters as training progresses, and the continuous-time limit yields a Fokker-Planck equation describing how the probability density over weights changes under the combined action of gradient drift and stochastic noise from mini-batch sampling. This connection has been used to derive learning rate schedules, understand generalisation via the flatness of the loss landscape at convergence, and analyse the implicit regularisation effects of SGD — the tendency of stochastic optimisers to converge to solutions with broad, flat minima that generalise better than sharp ones. Ma et al. (2019) provided rigorous convergence analysis using Fokker-Planck–based techniques.

[[Variational Inference]] — the approach of approximating an intractable posterior distribution with a simpler variational family by minimising the KL divergence — can be connected to the Chapman-Kolmogorov framework through the theory of diffusion bridges and Schrödinger bridges. The Schrödinger bridge problem asks: given two marginal distributions at times 0 and T, what is the most likely Markov process (measured by relative entropy against a reference process) that has these marginals? This is a continuous-time variational problem with the Chapman-Kolmogorov consistency as a fundamental constraint, and its solution has been applied to optimal transport, trajectory inference in single-cell sequencing, and unpaired image-to-image translation. The connection between variational inference and optimal transport via Schrödinger bridges was exploited in DiffuSE (De Bortoli et al. 2021) and Flow Matching (Lipman et al. 2022), both active research areas in 2025–2026.

In [[Reinforcement Learning]], the distributional Bellman equation — used in C51 (Bellemare et al. 2017), QR-DQN (Dabney et al. 2018), and IQN (Dabney et al. 2018) — extends the classical Bellman backup to maintain full return distributions rather than expected returns. The distributional Bellman operator is provably a contraction under a suitable probability metric precisely because the underlying transition kernel satisfies the Chapman-Kolmogorov property: the multi-step return distribution decomposes correctly via the chain rule of conditional probabilities. This distributional approach yields substantially better performance on exploration-sensitive tasks and provides richer uncertainty information for risk-sensitive decision making.

[[Gaussian Process]] regression, a fundamental tool in [[Bayesian Inference]] for function approximation, can be reformulated as exact Kalman filtering and smoothing when the GP's covariance function has a Markovian structure — specifically when it can be expressed as the covariance of a linear stochastic differential equation (SDE). Solin and Sarkka (2014) established this connection, showing that Matérn-class GPs with half-integer smoothness parameter correspond to specific SDEs whose forward simulation is a Chapman-Kolmogorov recursion. This gives O(n) Gaussian process inference algorithms (versus O(n³) for the standard GP) and connects non-parametric Bayesian methods to the classical filtering literature.

Neural ordinary differential equations (Neural ODEs, Chen et al. 2018) parameterise the continuous-time dynamics of a hidden state with a neural network, and the state distribution evolves according to a Fokker-Planck equation in the stochastic version. The FFJORD (Grathwohl et al. 2019) and CNFM (Lipman et al. 2022) models build on this to create efficient continuous normalising flows, connecting the Chapman-Kolmogorov dynamical framework to likelihood-based generative modelling.

## Mathematical Properties and Convergence Theory

The Chapman-Kolmogorov equation's mathematical richness extends well beyond the basic identity into questions of existence, uniqueness, and convergence of Markov processes. Several key properties are directly relevant to machine learning applications:

**Ergodicity and Mixing**: A Markov chain is ergodic if it is irreducible (any state can be reached from any other) and aperiodic (the chain does not cycle). For ergodic chains, the Chapman-Kolmogorov identity implies that P^n → 1π^T as n → ∞, where π is the unique stationary distribution and 1 is the all-ones vector. The rate of convergence is governed by the spectral gap: gap(P) = 1 - |λ_2(P)|, where λ_2 is the second-largest eigenvalue of P in absolute value. The mixing time T_mix(ε) = O(gap(P)^{-1} log(ε^{-1})) quantifies how many steps are needed to reach within ε of stationarity in total variation distance. This is the formal basis for [[Markov Chain Monte Carlo]] convergence guarantees.

**Detailed Balance**: A Markov chain satisfies detailed balance (reversibility) if π_i P_{ij} = π_j P_{ji} for all states i, j. Detailed balance is sufficient (but not necessary) for π to be the stationary distribution. The Metropolis-Hastings algorithm is designed specifically to construct transition kernels satisfying detailed balance with respect to the target distribution, guaranteeing correctness of the resulting MCMC sampler via the Chapman-Kolmogorov recursion.

**Semigroup Property**: In continuous time, the Chapman-Kolmogorov identity P(t+s) = P(t)P(s) defines a semigroup of operators on the space of probability measures (or bounded continuous functions, for the dual action on observables). This semigroup has a generator L = lim_{t→0} (P(t) - I)/t, which is a second-order differential operator for diffusion processes: L = b(x)·∇ + (1/2)σ(x)σ(x)^T:∇². The Fokker-Planck equation is ∂_t ρ = L*ρ (adjoint of L acting on densities) and the backward equation is ∂_t f = Lf (L acting on observables). Hille-Yosida theorem guarantees the existence of the semigroup given mild conditions on L.

**Perron-Frobenius Theory**: For finite-state Markov chains with irreducible transition matrix P, the Perron-Frobenius theorem guarantees a unique largest eigenvalue 1 with a strictly positive eigenvector (the stationary distribution). All other eigenvalues have absolute value strictly less than 1 for aperiodic chains, ensuring exponential mixing. Cheeger's inequality relates the spectral gap to geometric properties of the state space graph, enabling mixing time analysis from the structure of the problem rather than direct spectral computation.

**Continuous-State Convergence**: For continuous-state Markov chains (as in [[Diffusion Model]]s and stochastic control), convergence theory requires more sophisticated tools. The Dobrushin contraction coefficient, coupling methods, and Wasserstein metric convergence have all been applied to establish convergence of Markov chains on infinite state spaces. The theory of optimal transport provides geometric tools for measuring distances between probability measures that are compatible with the Chapman-Kolmogorov dynamics.

## The Chapman-Kolmogorov Test for Non-Markovianity

A particularly practical application of the Chapman-Kolmogorov equation is as a statistical test for verifying whether a discretised stochastic process is truly Markovian — a prerequisite for correctly applying Markov chain algorithms. The test compares empirically estimated n-step transition matrices against the prediction of the Chapman-Kolmogorov identity: if a process is Markovian, then P̂^(n+m) should equal P̂^n · P̂^m (within sampling error). Systematic deviations indicate either non-Markovian dynamics (memory effects) or insufficient state-space discretisation (the Markovian structure requires finer time or state resolution to manifest).

In molecular dynamics and Markov State Modelling (MSM), the Chapman-Kolmogorov test is performed as a standard validation step: for a range of lag times τ, one estimates the one-step matrix P̂(τ) and multistep matrices P̂(kτ) directly from trajectory data, then checks whether P̂(kτ) ≈ [P̂(τ)]^k across multiple values of k. If convergence holds for lag times τ ≥ τ_Markov, the process is considered Markovian at that time resolution. PyEMMA and MSMBuilder implement this test as a core validation tool.

In financial econometrics, Zhao and Qiu (2025) published a generalised Chapman-Kolmogorov test for coupled stochastic processes that estimates memory length — the minimal lag time beyond which the Chapman-Kolmogorov identity holds. Applied to Bitcoin price data and cross-asset correlations, the test revealed non-Markovian memory structures at short timescales (minutes to hours) that dissipate over longer periods (days), informing the appropriate timescale for Markovian models in cryptocurrency market prediction.

In neuroscience, the Chapman-Kolmogorov test has been used to characterise neuronal spike train statistics: whether the firing of a neuron depends only on its current state (membrane potential) or on the history of recent spikes. Non-Markovian spike train models (refractoriness, adaptation) require extended state representations that absorb the memory into an augmented state space, restoring the Markov property at the cost of higher dimensionality.

The test's power and sample efficiency have been studied theoretically (Metzner et al. 2009), with recommendations for the number of trajectory observations required to reliably detect violations at a given significance level. Bootstrap resampling methods provide confidence intervals on the Chapman-Kolmogorov test statistics, enabling rigorous inference in finite-sample settings.

## Connections to Information Theory and Thermodynamics

The Chapman-Kolmogorov equation connects deeply to information theory and statistical thermodynamics through the theory of entropy production and the arrow of time:

**Relative Entropy and Markov Chains**: The relative entropy (KL divergence) D_KL(μ || π) between a non-stationary distribution μ and the stationary distribution π of a Markov chain is monotonically non-increasing along the Chapman-Kolmogorov dynamics: D_KL(μ P || π) ≤ D_KL(μ || π). This is a form of the Second Law of Thermodynamics for Markov chains and has deep connections to the Fokker-Planck H-theorem for continuous diffusions. The rate of entropy decrease is governed by the spectral gap.

**Entropy Production and Non-Equilibrium Markov Processes**: For non-reversible Markov chains (violating detailed balance), the entropy production rate σ = Σ_{i,j} (π_i P_{ij} - π_j P_{ji}) log(π_i P_{ij} / π_j P_{ji}) ≥ 0 quantifies the irreversibility of the process. This connects the Chapman-Kolmogorov framework to non-equilibrium statistical mechanics and fluctuation theorems (Jarzynski equality, Crooks fluctuation theorem). In machine learning, the distinction between reversible and non-reversible Markov chains is relevant for designing faster-mixing MCMC algorithms: non-reversible chains (using skew-detailed balance rather than detailed balance) can exhibit faster convergence while maintaining the correct stationary distribution.

**Free Energy and Variational Inference**: The variational inference objective — minimising the evidence lower bound (ELBO) — can be reformulated as minimising the KL divergence between the approximate posterior and the true posterior. The Fokker-Planck equation describes the gradient flow of the KL divergence in the Wasserstein metric, connecting variational inference to the Chapman-Kolmogorov dynamics of diffusion processes. This perspective underlies Stein Variational Gradient Descent (Liu and Wang 2016) and other particle-based variational inference methods that transport particles along the Chapman-Kolmogorov dynamics of the variational posterior.

**Maximum Entropy Markov Models**: The principle of maximum entropy, applied to Markov chains, generates the maximum entropy Markov model (MEMM) — a transition model that satisfies the Chapman-Kolmogorov equation while maximising entropy subject to feature constraints. MEMMs are a precursor to Conditional Random Fields (CRFs) and other structured prediction models used in [[Natural Language Processing]] sequence labelling tasks. The connection between maximum entropy and Markov chains runs through the Donsker-Varadhan theory of large deviations for Markov processes.

## Benchmark Datasets and Evaluation Contexts

While the Chapman-Kolmogorov equation is a mathematical identity rather than an empirical claim, its applications are evaluated through benchmark datasets and performance metrics in each application domain:

**MCMC Benchmarks**: The PosteriorDB database (Magnusson et al. 2022) provides a collection of probabilistic models and reference posterior samples for comparing MCMC algorithms. Benchmarks assess convergence speed (effective sample size per second), mixing quality (R̂ convergence diagnostic), and robustness to poorly conditioned posteriors. The NUTS sampler's efficiency on high-dimensional Bayesian models demonstrates the practical relevance of Chapman-Kolmogorov–based mixing time analysis.

**Diffusion Model Image Generation**: ImageNet 256×256 and 512×512 FID (Fréchet Inception Distance) benchmarks track the quality of generative models including diffusion models. Progression from DDPM (FID ~3.17 on CIFAR-10 at NeurIPS 2020) through improved score-based models (FID 2.20, Song et al. ICLR 2021) to DiT-based models (FID < 2.0, Peebles & Xie 2022) documents the field's rapid advancement, all building on the Chapman-Kolmogorov diffusion framework.

**Markov State Model Validation (MD)**: WW domain β-hairpin folding, Alanine dipeptide conformational dynamics, and BPTI (bovine pancreatic trypsin inhibitor) folding have served as benchmark systems for MSM development and validation. The Chapman-Kolmogorov test pass/fail rates at various lag times characterise model quality. The HTMD platform and Folding@home distributed computing project have contributed large trajectory datasets for MSM development.

**Reinforcement Learning Benchmarks**: Atari 100K (data-efficient), MuJoCo locomotion tasks, DM Control Suite, and NetHack challenge all evaluate RL algorithms whose theoretical foundations rest on the Markovian MDP assumption and Chapman-Kolmogorov transition dynamics. Deviations from Markovian assumptions (partial observability, history-dependent optimal policies) motivate POMDP extensions and memory-augmented RL architectures.

**HMM-Based Speech Recognition**: The TIMIT phoneme recognition dataset and LibriSpeech (960 hours of English speech) served as historical benchmarks for HMM-based and later HMM-DNN hybrid speech recognisers. Modern end-to-end models (Wav2Vec 2.0, Whisper) supersede classical HMMs, but the fundamental Chapman-Kolmogorov consistency that made HMM training stable remains relevant for understanding the theoretical basis of sequence-to-sequence models.

## Research and Literature

1. Chapman, S. (1928). "On the Brownian Displacements and Thermal Diffusion of Grains Suspended in a Non-Uniform Fluid." *Proceedings of the Royal Society A*, 119(781), 34–54.
2. Kolmogorov, A.N. (1931). "Über die analytischen Methoden in der Wahrscheinlichkeitsrechnung." *Mathematische Annalen*, 104(1), 415–458.
3. Feller, W. (1949). "On the Theory of Stochastic Processes, with Particular Reference to Applications." *Proceedings of the First Berkeley Symposium on Mathematical Statistics and Probability*, 403–432.
4. Feller, W. (1968). *An Introduction to Probability Theory and Its Applications*, Volume II. Wiley.
5. Kolmogorov, A.N. (1933). *Grundbegriffe der Wahrscheinlichkeitsrechnung* (Foundations of the Theory of Probability). Springer.
6. Gardiner, C.W. (2004). *Handbook of Stochastic Methods for Physics, Chemistry and the Natural Sciences*, 3rd edition. Springer.
7. Risken, H. (1989). *The Fokker-Planck Equation: Methods of Solution and Applications*, 2nd edition. Springer.
8. Norris, J.R. (1997). *Markov Chains*. Cambridge University Press. (Core UK textbook, Cambridge Statistical and Probabilistic Mathematics.)
9. Williams, D. (1979). *Diffusions, Markov Processes, and Martingales*, Volume 1: Foundations. Wiley.
10. Rogers, L.C.G., Williams, D. (1994). *Diffusions, Markov Processes, and Martingales*, Volume 2: Itô Calculus. Cambridge University Press.
11. Ho, J., Jain, A., Abbeel, P. (2020). "Denoising Diffusion Probabilistic Models." *NeurIPS 2020*, arXiv:2006.11239.
12. Song, Y., Sohl-Dickstein, J., Kingma, D.P., Kumar, A., Ermon, S., Poole, B. (2021). "Score-Based Generative Modeling through Stochastic Differential Equations." *ICLR 2021 (Oral)*, arXiv:2011.13456.
13. Rabiner, L.R. (1989). "A Tutorial on Hidden Markov Models and Selected Applications in Speech Recognition." *Proceedings of the IEEE*, 77(2), 257–286.
14. Bellman, R. (1957). *Dynamic Programming*. Princeton University Press.
15. Metropolis, N., Rosenbluth, A.W., Rosenbluth, M.N., Teller, A.H., Teller, E. (1953). "Equation of State Calculations by Fast Computing Machines." *Journal of Chemical Physics*, 21(6), 1087–1092.
16. Hastings, W.K. (1970). "Monte Carlo Sampling Methods Using Markov Chains and Their Applications." *Biometrika*, 57(1), 97–109.
17. Geman, S., Geman, D. (1984). "Stochastic Relaxation, Gibbs Distributions, and the Bayesian Restoration of Images." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, 6(6), 721–741.
18. Neal, R.M. (2011). "MCMC Using Hamiltonian Dynamics." In *Handbook of Markov Chain Monte Carlo*, Chapman & Hall/CRC.
19. Hoffman, M.D., Gelman, A. (2014). "The No-U-Turn Sampler: Adaptively Setting Path Lengths in Hamiltonian Monte Carlo." *Journal of Machine Learning Research*, 15(1), 1593–1623.
20. Hairer, M. (2014). "A Theory of Regularity Structures." *Inventiones Mathematicae*, 198(2), 269–504. (Fields Medal work on stochastic PDEs.)
21. Bellemare, M.G., Dabney, W., Munos, R. (2017). "A Distributional Perspective on Reinforcement Learning." *ICML 2017*, arXiv:1707.06887.
22. Song, Y., Ermon, S. (2019). "Generative Modeling by Estimating Gradients of the Data Distribution." *NeurIPS 2019*, arXiv:1907.05600.
23. Zhai, R., Bao, F., Chen, X., Shang, Y., Pan, X., Zhang, X. (2022). "A Deep Learning Method for Solving Fokker-Planck Equations." *PMLR 145*, Proceedings of Mathematical and Scientific Machine Learning.
24. Zhao, J., Qiu, H. (2025). "Chapman-Kolmogorov Test for Estimating Memory Length of Two Coupled Processes." *Scientific Reports*, 15, 8372. https://www.nature.com/articles/s41598-025-92238-8
25. Shi, Y., De Bortoli, V., Campbell, A., Doucet, A. (2025). "Bidirectional Diffusion Bridge Models." arXiv:2502.09655.
26. Dhariwal, P., Nichol, A. (2021). "Diffusion Models Beat GANs on Image Synthesis." *NeurIPS 2021*, arXiv:2105.05233.
27. Karras, T., Laine, S., Aila, T. (2019). "A Style-Based Generator Architecture for Generative Adversarial Networks." *CVPR 2019*. (GAN baseline context for diffusion model advances.)
28. Lyons, T.J. (1998). "Differential Equations Driven by Rough Signals." *Revista Matematica Iberoamericana*, 14(2), 215–310. (Rough paths foundation, related to non-Markovian extensions.)

## Visualisation and Interpretability of Markov Chain Dynamics

Understanding the behaviour of Markov chains described by the Chapman-Kolmogorov equation often requires visualisation tools that can surface the structure of transition dynamics in an interpretable form:

**Spectral Decomposition Visualisation**: For finite-state chains, the eigenvalues and eigenvectors of the transition matrix P reveal the time scales of different relaxation processes. Slow relaxation processes (eigenvalues close to 1) correspond to long-lived metastable states that are often the most scientifically interesting. In protein folding MSMs, spectral analysis reveals folding pathways and intermediate conformations. The implied timescale t_i = -τ / log(λ_i) converts eigenvalue λ_i at lag time τ into the corresponding relaxation time in physical units.

**Transition Path Sampling and Committor Functions**: The committor function q(x) gives the probability of reaching state B before state A starting from configuration x, and is a solution to the Kolmogorov backward equation with boundary conditions q(A) = 0, q(B) = 1. Committor functions provide a non-parametric reaction coordinate that is theoretically grounded in the Chapman-Kolmogorov dynamics of the process. Visualising the committor surface reveals the structure of the transition state ensemble and the bottlenecks in rare event pathways.

**Network Visualisation of Transition Matrices**: For discretised Markov chains, the transition matrix can be represented as a weighted directed graph where edge weight represents transition probability. Network analysis tools (PageRank, community detection algorithms, centrality measures) applied to this graph reveal the kinetic organisation of the state space — metastable communities, hub states, and bottleneck transitions. The Markov State Model framework for molecular dynamics relies extensively on graph-based visualisation of Chapman-Kolmogorov transition networks.

**Diffusion Maps and Manifold Learning**: The eigenvectors of a diffusion operator (the Markov chain defined by a kernel function on data points) provide a non-linear dimensionality reduction that preserves the geometric structure of the data manifold as defined by the Chapman-Kolmogorov diffusion dynamics. Diffusion maps (Coifman and Lafon 2006) have been applied to single-cell RNA sequencing data (Wishbone, PHATE methods), materials science descriptor learning, and anomaly detection in high-dimensional time series.

**Wasserstein Distance Tracking**: For distribution-valued processes (particle systems, ensemble forecasting), tracking the evolution of the probability distribution using Wasserstein distances provides a geometrically meaningful measure of how the ensemble changes over time according to Chapman-Kolmogorov dynamics. Wasserstein barycentre computations provide aggregate representations of ensemble uncertainty, visualisable as probability density plots or contour maps.

## Cross-Domain Unification: The Markov Property as Universal Modelling Assumption

The Chapman-Kolmogorov equation's ubiquity across seemingly unrelated fields reflects the universality of the Markov property as a modelling assumption. Any dynamical system whose future behaviour depends only on its present state — and not on how it arrived there — is a Markov process, and the Chapman-Kolmogorov identity is the algebraic expression of this memorylessness. This is why the equation appears in such different contexts:

- In **physics**: molecular collisions in gas theory occur so rapidly that subsequent states depend only on the current velocity and position distribution, not on historical trajectories. Brownian motion arises from the central limit theorem applied to many rapid collisions, and the Chapman-Kolmogorov equation governs the resulting diffusion.
- In **biology**: evolutionary substitution in DNA sequences occurs through point mutations where each nucleotide position evolves according to a substitution rate that depends only on its current nucleotide identity, not on ancestral history (under many models). The Chapman-Kolmogorov equation governs how substitution probabilities compose over evolutionary time.
- In **economics and finance**: the efficient market hypothesis asserts (in its semi-strong form) that all publicly available information is already incorporated into asset prices, making price changes depend only on new information rather than history — a form of the Markov property for price processes.
- In **computer science and operations research**: queuing systems, Markov chains underlying PageRank computation, and Markov decision processes in planning all exploit the Markov property to make multi-step prediction tractable.
- In **machine learning**: the Markov property is built into the fundamental assumptions of most sequential decision-making frameworks (MDPs), many generative models (diffusion, autoregressive language models with fixed context windows), and Bayesian filtering algorithms.

  This cross-domain universality makes the Chapman-Kolmogorov equation one of the most important mathematical identities in applied science, comparable in significance to the central limit theorem or Bayes' theorem. Understanding it deeply is prerequisite to rigorous work in probabilistic modelling, stochastic simulation, Bayesian inference, reinforcement learning, and generative AI.

## Cross-Reference Index: Key Ontology Connections

This section documents the primary ontological relationships of the [[Chapman-Kolmogorov Equation]] to other concepts in the knowledge graph:

- **Mathematical Foundations**: The [[Chapman-Kolmogorov Equation]] is grounded in [[Probability Theory]], specifically the [[Markov Property]] and [[Conditional Probability]]. It requires [[Measure Theory]] for rigorous formulation and [[Linear Algebra]] for the discrete matrix form. [[Sigma Algebra]] formalises the event space over which probabilities are defined. [[Real Analysis]] underpins the convergence theory of the semigroup.
- **Core Stochastic Process Types Using Chapman-Kolmogorov**:
  - [[Markov Chain]]: discrete-time, discrete-state; transition matrix P, Chapman-Kolmogorov as P^(n+m) = P^n · P^m.
  - [[Continuous-Time Markov Chain]]: discrete-state, continuous-time; generator matrix Q.
  - [[Brownian Motion]] / [[Wiener Process]]: continuous-state, continuous-time; Gaussian transition kernel.
  - [[Diffusion Process]]: general continuous-state SDE; Chapman-Kolmogorov generates Fokker-Planck.
  - [[Jump Process]] (Lévy process): continuous-time with discontinuous paths; Feller's generalisation.
  - [[Hidden Markov Model]]: latent Markov chain with observed emissions; forward-backward algorithm.
- **Derived Equations and Algorithms**:
  - [[Fokker-Planck Equation]] (Kolmogorov forward equation): PDE for probability density evolution.
  - [[Kolmogorov Backward Equation]]: PDE for expected observables, value functions.
  - [[Bellman Equation]]: discrete Chapman-Kolmogorov recursion for [[Reinforcement Learning]] value functions.
  - [[Hamilton-Jacobi-Bellman Equation]]: continuous-time PDE limit of the Bellman equation.
  - [[Forward-Backward Algorithm]]: dynamic programming on Chapman-Kolmogorov for [[Hidden Markov Model]] inference.
  - [[Kalman Filter]]: closed-form Chapman-Kolmogorov integration for linear-Gaussian systems.
- **Machine Learning Algorithm Dependents**:
  - [[Markov Chain Monte Carlo]] (MCMC): constructs chains with target stationary distribution.
  - [[Hamiltonian Monte Carlo]]: long-range MCMC moves via Hamiltonian dynamics.
  - [[No-U-Turn Sampler]] (NUTS): adaptive trajectory-length HMC; Stan, PyMC.
  - [[Gibbs Sampling]]: full-conditional sequential updates; a Metropolis-Hastings special case.
  - [[Particle Filter]] / Sequential Monte Carlo: discrete approximation of Chapman-Kolmogorov integration.
  - [[Diffusion Model]]: DDPM, DDIM, score-based models; forward/reverse Markov chains.
  - [[Score-Based Generative Model]]: learns the score function of marginals defined by Chapman-Kolmogorov forward process.
  - [[Flow Matching]]: deterministic ODE limit of Chapman-Kolmogorov continuous diffusion.
- **Domain Application Areas**:
  - [[Bayesian Inference]]: posterior computation via MCMC.
  - [[Probabilistic Programming]]: Stan, PyMC, NumPyro use MCMC.
  - [[Reinforcement Learning]]: MDP transition kernel; Bellman operators.
  - [[Time-Series Analysis]]: state-space models, HMM.
  - [[Gaussian Process]]: state-space GP reformulation as Kalman filter.
  - [[Financial Mathematics]]: Black-Scholes (Kolmogorov backward); credit rating migration.
  - [[Molecular Dynamics]]: Markov State Models for protein folding.
  - [[Speech Recognition]]: HMM-based acoustic models.
  - [[Genomics]]: DNA substitution models; sequence alignment probabilistic models.
  - [[Epidemiology]]: SIR/SEIR stochastic compartmental models.
  - [[Robotics]]: SLAM (localisation and mapping); particle filter state estimation.
- **Contrasting Mathematical Frameworks**:
  - [[Non-Markovian Process]]: memory-dependent dynamics violating Chapman-Kolmogorov identity.
  - [[Fractional Brownian Motion]]: long-range correlated increments; non-Markovian.
  - [[Rough Paths Theory]] (Lyons): alternative framework for non-Markovian SDEs.
  - [[Long-Range Memory Process]]: financial and physical systems with power-law correlations.
  - [[Quantum Non-Markovian Process]]: violates quantum Chapman-Kolmogorov (Lindblad) equation.
- **Historical and Theoretical Figures**:
  - [[Sydney Chapman]]: British mathematician; 1928 diffusion derivation.
  - [[Andrey Kolmogorov]]: Soviet mathematician; 1931 rigorous derivation + forward/backward equations.
  - [[William Feller]]: generalisation to jump processes and semigroup theory (1949, 1952).
  - [[Martin Hairer]]: Fields Medal 2014; regularity structures for stochastic PDEs.
  - [[Terry Lyons]]: Oxford; rough paths theory extending Chapman-Kolmogorov to non-Markovian SDEs.

## Semantic Classification Detail: OWL Role Assignments

- **owl-key-variants:** discrete-time matrix form, continuous-time generator form, diffusion SDE form, quantum Lindblad form, time-inhomogeneous generalisation, graph Markov chain form
- **owl-test-method:** Chapman-Kolmogorov test (compare P̂^(n+m) vs P̂^n · P̂^m empirically); used in MSM validation, financial econometrics, neuroscience
- **owl-violations-indicate:** non-Markovian memory effects; insufficient state-space resolution; quantum entanglement (quantum case)
- **owl-connects-to-complexity:** The spectral gap of the transition matrix determines mixing time; Cheeger's inequality relates spectral gap to geometric bottlenecks
- **owl-physical-interpretation:** encodes the Second Law of Thermodynamics for Markov systems (entropy decreases toward stationarity); entropy production rate characterises irreversibility

### Provenance

