
An agent personality is a stable behavioural schema for an agent that shapes decision preference, risk style, response architecture and interaction patterns.[^1] visionGraph places it under [[Persona]] and as part of an [[Agent Profile]], to which it is attached by `hasPersonality`.

The property describes behavioural bias patterns that shape interaction and task choices. A personality records tendencies and does not prescribe rules, so it is a descriptor and not executable semantics: two agents with different personalities can follow the same policy and still differ in how cautious or direct they are.

The other two components of the profile are [[Tone Model]], which covers pragmatic modulation, and [[Language Preference]], which covers linguistic parameters. A personality is a kind of [[Persona]] in the sense of a described character, applied to an agent's behavioural biases rather than to a role or a fictional figure.

[^1]: Semantic Agent Communication Community Group, “Agent Profile Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent-profile.ttl

