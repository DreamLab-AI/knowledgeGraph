A hidden Markov model (HMM) is a probabilistic model for sequences in which an unobserved Markov chain of discrete states generates observable outputs, one per state, according to state-dependent emission distributions. The model is defined by transition probabilities between hidden states and emission probabilities for observations, plus an initial state distribution. HMMs support efficient inference for filtering, decoding, and learning over sequential data.

### Overview

- An HMM combines a Markov chain over hidden states with an emission model that maps each state to a distribution over observations. Three classical problems define its use: evaluating the likelihood of an observation sequence with the forward algorithm, decoding the most probable hidden state sequence with the Viterbi algorithm, and learning the parameters from data with the Baum-Welch algorithm, an instance of expectation-maximisation. As a latent-variable sequence model it powered decades of speech and language processing before deep sequence models became dominant.

### Mechanisms

- A hidden Markov chain governs transitions between discrete states.
- State-dependent emission distributions produce observations.
- The forward-backward algorithm computes likelihoods and posteriors.
- The Viterbi algorithm decodes the most probable state sequence.
- Baum-Welch training fits parameters via expectation-maximisation.

### Applications

- Speech recognition and acoustic modelling.
- Part-of-speech tagging and sequence labelling.
- Bioinformatics, including gene and protein sequence analysis.
- Gesture and activity recognition.
- Time-series segmentation and regime detection.

### Provenance

