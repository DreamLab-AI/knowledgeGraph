A real-time rendering technique that fakes fine surface detail by storing perturbed surface normals in a texture and using them, rather than the interpolated geometric normals, during per-pixel lighting. Detail sculpted on a high-polygon model is baked into a tangent-space normal map applied to a low-polygon mesh, so bumps, scratches, and seams respond correctly to moving lights without adding geometry — a cornerstone of the game-asset pipeline and physically based rendering.

### Semantic Classification

### Content

## Definition

**Normal mapping** is the standard trick for making low-polygon surfaces look richly detailed under dynamic lighting. Lighting calculations depend on the [[Surface Normal]] at each shaded point; if the normal is perturbed per pixel, the lighting responds as though the geometry itself were bumpy. A normal map is a texture whose RGB channels encode the XYZ components of a unit normal (remapped from [−1, 1] to [0, 255], which produces the characteristic lavender-blue appearance, since the "flat" normal (0, 0, 1) encodes as (128, 128, 255)). During shading, the [[Pixel Shader]] samples this texture and substitutes the decoded normal into the lighting equation.

The technique descends from Blinn's 1978 bump mapping, which perturbed normals from a height field; storing the normals directly (Cohen et al.'s appearance-preserving simplification and Cignoni et al.'s work, 1998) made the perturbation cheaper and more expressive. The dominant variant is **tangent-space** normal mapping: normals are stored relative to a per-vertex basis (tangent, bitangent, normal) aligned with the mesh's [[Uv Mapping]], so the map survives mesh deformation and can be reused across meshes. Object-space maps trade that flexibility for cheaper shading on rigid objects.

In the production pipeline, artists sculpt a multi-million-polygon model in ZBrush or Blender, build a low-polygon game mesh, and **bake** the difference: rays cast from the low-poly surface sample the high-poly normals into the map. Correctness depends on consistent tangent-space conventions — MikkTSpace is the de facto standard — and on the Y-channel handedness (OpenGL-style +Y versus DirectX-style −Y), the source of the perennial "inverted bumps" bug. Normal mapping cannot change silhouettes or produce self-occlusion; parallax occlusion mapping, displacement with tessellation, and virtualised geometry (Nanite) address those limits, yet normal maps remain in every PBR material stack.

## Technical Details

- **Encoding**: unit vector per texel; two-channel formats (BC5/EAC RG) store X and Y and reconstruct Z = √(1 − x² − y²), giving better quality per bit than compressing all three channels.
- **Shading**: the TBN matrix transforms the sampled normal from tangent space to world space (or the light vector the other way); normalisation and careful mip-mapping matter because averaging normals shortens them, which specular models such as LEAN/Toksvig mapping compensate for.
- **Baking tools**: Substance 3D Painter/Designer, Marmoset Toolbag, xNormal, and Blender's Cycles baker; cage meshes control ray projection to avoid skewed or missed details.
- **PBR integration**: glTF 2.0, USD, and every major engine (Unreal, Unity, Godot) treat the tangent-space normal map as a core material input alongside base colour, roughness, and metallic maps.

  ## Current Landscape

- **Nanite virtualised geometry** (Unreal Engine 5.x) removes the low-poly-plus-bake constraint for hero assets — full-resolution source meshes can be imported directly, and Nanite does not even store per-vertex tangents, deriving tangent space in the pixel shader instead; its offline adaptive tessellator adds displacement-map-driven detail on top. Normal maps nonetheless remain in every PBR material stack for micro-detail and for the vast majority of non-Nanite platforms (mobile, VR, web).
- The **glTF 2.0 specification** continues to recommend MikkTSpace tangent generation when tangents are absent; ecosystem experience shows assets must embed explicit tangents to guarantee identical normal-map rendering across viewers, since runtimes otherwise reconstruct tangent frames by differing methods (including screen-space derivatives).
- Production renderers have converged on discarding stored bitangents and reconstructing them as cross(normal, tangent.xyz) * tangent.w; active engineering work (e.g. Kapoulkine's April 2026 analysis of quantised tangent frames) focuses on compressing tangent-frame data for bandwidth-bound GPU pipelines.
- Bake tooling remains centred on Substance 3D Painter/Designer and Marmoset Toolbag, with MikkTSpace still the cross-tool tangent-space convention and the OpenGL(+Y)/DirectX(−Y) green-channel split still the leading cause of inverted-bump artefacts.

  **Sources**:

- https://dev.epicgames.com/documentation/en-us/unreal-engine/nanite-virtualized-geometry-in-unreal-engine
- https://github.com/KhronosGroup/glTF/issues/1252
- https://zeux.io/2026/04/30/quantizing-tangent-frames/
- https://www.magnopus.com/blog/unreal-engine-5-and-nanite-virtualized-geometry

