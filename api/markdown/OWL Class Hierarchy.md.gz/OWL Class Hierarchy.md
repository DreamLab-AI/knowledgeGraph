The OWL Class Hierarchy is the directed acyclic graph (DAG) of named and anonymous classes connected via rdfs:subClassOf axioms within a Web Ontology Language (OWL) ontology, imposing a partial order on the class extension lattice. It provides the primary vehicle for monotonic inheritance of properties and restrictions, enabling description-logic reasoners such as HermiT, Pellet, and FaCT++ to classify individuals, detect unsatisfiable classes, and compute implicit subsumption relationships that are not asserted explicitly. The hierarchy is closed under the OWL semantics of the chosen profile (OWL 2 DL, EL, QL, or RL), constraining the decidability and computational complexity of reasoning tasks performed over it. Well-engineered class hierarchies underpin interoperability across domains including biomedical ontologies (GO, SNOMED CT), geospatial standards, and knowledge-graph schemas.

### Overview

- The OWL Class Hierarchy formalises how concepts in an [[OWL Ontology]] relate to one another through generalisation and specialisation. Unlike a simple tree, the hierarchy is a DAG because a class may have multiple direct superclasses (multiple inheritance), though the semantics enforce coherence via the [[Open World Assumption]].
- **Why it matters:**
  - It is the primary mechanism for representing taxonomic knowledge in [[Formal Ontology]].
  - It enables deductive inference — a reasoner can discover that an individual belonging to class C also belongs to all superclasses of C without explicit assertion.
  - It supports [[Ontology Alignment]] and reuse: shared superclasses bridge independently developed vocabularies.
  - It underpins interoperability standards in domains ranging from [[Biomedical Ontology]] (GO, SNOMED CT, ChEBI) to geospatial schemas and industrial IoT.
- **How it works:**
  - Developers assert `owl:Class` declarations and `rdfs:subClassOf` axioms in [[Turtle Syntax]], [[Manchester Syntax]], or OWL/XML.
  - A reasoner computes the full transitive closure of subClassOf, yielding a classified hierarchy.
  - Equivalent class axioms (using `owl:equivalentClass`) allow two classes to be defined as having identical extensions, acting as cross-links in the DAG.
  - Disjointness axioms (`owl:disjointWith`, `owl:AllDisjointClasses`) constrain the hierarchy, enabling the detection of logical contradictions.

### Key Components

- **[[OWL Class]]** — a named or anonymous set of individuals; the node type in the hierarchy.
- **[[SubClass Axiom]]** (`rdfs:subClassOf`) — the directed edge asserting that every member of the subclass is also a member of the superclass.
- **[[Equivalent Class Axiom]]** (`owl:equivalentClass`) — bidirectional subclassing; two classes share identical extensions.
- **[[Disjoint Classes Axiom]]** (`owl:disjointWith`) — asserts that two classes share no members; essential for catching modelling errors.
- **Anonymous Classes (Class Expressions)** — complex classes formed from [[OWL Restrictions]] (someValuesFrom, allValuesFrom, hasValue, cardinality), Boolean constructors (intersection, union, complement), and enumeration (`owl:oneOf`). These form the bodies of defined classes in the hierarchy.
- **Primitive vs Defined Classes** — primitive classes have only necessary conditions (subClassOf); defined classes have necessary and sufficient conditions (equivalentClass) and are fully classifiable by a reasoner.
- **[[Upper Ontology]]** — the top of the hierarchy is often anchored to an upper ontology such as BFO, DOLCE, or SUMO, ensuring cross-domain compatibility.
- **OWL Profiles and Hierarchy Complexity:**
  - OWL 2 EL — polynomial reasoning; suited for large biomedical hierarchies.
  - OWL 2 QL — logspace query answering; maps to relational databases.
  - OWL 2 RL — rule-based reasoning; compatible with RDF triple stores.
  - OWL 2 DL — full SHOIQ(D) expressivity; EXPTIME-complete classification.
  - OWL Full — no decidability guarantee; not suitable for automated reasoning.

### Mechanisms

- **[[Ontology Classification]]** — the process by which a reasoner computes every implicit subClassOf relationship across the hierarchy. The result is the inferred hierarchy, distinct from the asserted hierarchy written by the modeller.
- **[[Consistency Checking]]** — the reasoner verifies that no class is simultaneously required to be both populated and empty (unsatisfiable). Unsatisfiable classes typically indicate modelling errors such as contradictory restrictions combined via owl:intersectionOf.
- **[[Knowledge Inference]]** — individuals classified under a leaf class inherit all restrictions of ancestor classes, enabling property propagation without explicit axiom duplication.
- **Monotonicity** — OWL DL semantics are monotonic: adding axioms can only entail more facts, never fewer. This property is critical for safe ontology merging and [[Ontology Alignment]].
- **[[Open World Assumption]]** — unlike relational databases, absence of a fact does not imply falsity. The hierarchy is interpreted under OWA, meaning individuals not explicitly excluded from a class may still belong to it.
- **[[Automated Reasoning]]** algorithms — tableau-based algorithms (used by HermiT) and consequence-based algorithms (used by ELK for OWL 2 EL) traverse the class hierarchy axioms to materialise entailments.

### Applications / Use Cases

- **[[Biomedical Ontology]]** — the Gene Ontology (GO) hierarchy of ~50,000 classes, SNOMED CT's clinical hierarchy of ~350,000 concepts, and ChEBI's chemical hierarchy all rely on OWL class hierarchies for consistent classification and interoperability.
- **[[Knowledge Graph]] schema definition** — large-scale knowledge graphs such as Wikidata, DBpedia, and enterprise graphs use OWL class hierarchies to define their type systems, enabling [[SPARQL Query Language]] queries that exploit subsumption.
- **[[Semantic Web]] application integration** — agents traversing [[Linked Data]] use class hierarchies to reason about resource types, enabling polymorphic data consumption without hard-coded type checks.
- **Industrial and IoT standards** — the W3C SOSA/SSN ontology for sensors, the IFC building information model, and PDDL-derived planning ontologies all encode domain taxonomies as OWL class hierarchies.
- **[[Natural Language Processing]]** — word-sense disambiguation and entity typing systems use OWL hierarchies as the backbone for semantic similarity computation and type-consistent entity linking.
- **Regulatory compliance** — pharmaceutical and financial regulators increasingly mandate machine-readable concept hierarchies (e.g., ISO 11179 data elements, FDA drug classification) encoded in OWL, enabling automated conformance checking.
- **[[Ontology-Driven Information Extraction]]** — NLP pipelines extract entities typed against an OWL class hierarchy, allowing subsumption-based query expansion (searching for "medication" returns instances of all subclasses).
- **AI/ML feature engineering** — class membership vectors derived from an OWL hierarchy provide structured priors for [[Machine Learning]] classifiers operating on typed entities.

### Standards & Context

- **W3C OWL 2 Recommendation (2012)** — the normative specification defining OWL 2 DL and its four profiles (EL, QL, RL, Full). Published by the W3C OWL Working Group; supersedes OWL 1 (2004).
- **[[RDF Schema]] (RDFS)** — provides the `rdfs:subClassOf` predicate reused by OWL; OWL extends RDFS with richer class-expression constructors.
- **[[Description Logic]] family** — OWL 2 DL corresponds to SHOIQ(D) in the description logic landscape; OWL 2 EL corresponds to EL++.
- **[[Protege]]** — the canonical open-source ontology editor (Stanford) that visualises and edits OWL class hierarchies; integrates HermiT and FaCT++ as plug-in reasoners.
- **OBO Foundry** — a community of biomedical ontologies committed to shared upper-level structure and consistent use of OWL class hierarchies for interoperability across research data.
- **[[Ontology Design Patterns]] (ODP)** — community best-practice patterns (content ontology design patterns, structural patterns) that guide principled construction of OWL class hierarchies to avoid common anti-patterns such as deep monolithic hierarchies and property abuse.
- **ISO 25964** — thesaurus standard that maps to OWL class hierarchies for vocabulary interoperability in information retrieval systems.
- **[[SPARQL Query Language]] 1.1** — the query language for RDF/OWL data; SPARQL inference profiles determine how class hierarchy subsumption is applied during query evaluation.

### Semantic Classification

### Provenance

