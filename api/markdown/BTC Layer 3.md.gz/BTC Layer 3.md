Layer 3 (Bitcoin Layer 3) designates the application-layer stratum of the Bitcoin protocol stack — a collection of protocols, virtual machines, asset-issuance systems, and programmability frameworks constructed atop Layer 2 scaling networks (principally the Lightning Network and emerging

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:RGBProtocol))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:TaprootAssets))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:BitVM))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:StacksSmartContractPlatform))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:Rootstock))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:OrdinalProtocol))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:RunesProtocol))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:DiscreetLogContracts))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:Citrea))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:MerlinChain))

    ## Dependency Relationships
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:requires blockchain:LightningNetwork))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:requires blockchain:Bitcoin))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:requires blockchain:TaprootUpgrade))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:requires blockchain:UTXOModel))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:requires blockchain:BitcoinScript))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:requires blockchain:CryptographicCommitments))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:Bitcoin))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:SegWit))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:SchnorrSignatures))

    ## Capability Relationships
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:enables blockchain:SmartContractsOnBitcoin))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:enables blockchain:TokenIssuance))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:enables blockchain:DecentralisedFinance))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:enables blockchain:NonFungibleTokens))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:enables blockchain:StablecoinsOnBitcoin))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:enables blockchain:AtomicSwaps))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:enables blockchain:TrustlessBridges))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:enables blockchain:AIAgentSmartContracts))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:supports blockchain:BitcoinDeFi))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:supports blockchain:BitcoinScalability))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:supports blockchain:CrossChainInteroperability))

    ## Implementation Relationships
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:implements blockchain:ClientSideValidation))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:implements blockchain:OptimisticRollup))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:implements blockchain:ZeroKnowledgeRollup))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:implements blockchain:FraudProofs))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:implements blockchain:ProofOfTransfer))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:implements blockchain:MergedMining))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:uses blockchain:ZeroKnowledgeProofs))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:uses blockchain:TaprootWitnesses))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:uses blockchain:UTXOCommitments))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:uses blockchain:HashTimeLockContracts))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:uses blockchain:PointTimeLockContracts))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:uses blockchain:MerkleProofs))

    ## Reduction Relationships
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:reduces blockchain:BitcoinScriptLimitations))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:reduces blockchain:BitcoinBaseLayerBlockspacePressure))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:reduces blockchain:SmartContractInteroperabilityFriction))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:reduces blockchain:CrossChainBridgeTrustAssumptions))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:EthereumLayer2))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:EthereumSmartContracts))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:Bitcoin))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:LightningNetwork))
    SubClassOf(blockchain:BTCLayer3
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:BitcoinStandard))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(blockchain:hasIdentifier blockchain:BTCLayer3 "BC-1109"^^xsd:string)
    DataPropertyAssertion(blockchain:authorityScore blockchain:BTCLayer3 "0.87"^^xsd:decimal)
    DataPropertyAssertion(blockchain:ecosystemGrowthCAGR blockchain:BTCLayer3 "0.25"^^xsd:decimal)
    DataPropertyAssertion(blockchain:enterpriseAdoptionGrowth2025 blockchain:BTCLayer3 "0.45"^^xsd:decimal)

    ## Property Constraints
    SubClassOf(blockchain:BTCLayer3
      DataMinCardinality(1 blockchain:hasProtocolFamily xsd:string))
    SubClassOf(blockchain:BTCLayer3
      DataAllValuesFrom(blockchain:requiresBitcoinAnchor xsd:boolean))
    SubClassOf(blockchain:BTCLayer3
      DataSomeValuesFrom(blockchain:programmabilityApproach xsd:string))

    ## Annotations
    AnnotationAssertion(rdfs:label blockchain:BTCLayer3 "BTC Layer 3 (Bitcoin Application Layer)"@en)
    AnnotationAssertion(rdfs:comment blockchain:BTCLayer3 "The application-layer stratum of the Bitcoin protocol stack, encompassing protocols built atop Layer 2 networks (Lightning Network, rollups) to provide smart contracts, token issuance, DeFi, NFTs, and complex financial instruments on Bitcoin without modifying base-layer consensus. Five major families: RGB Protocol (client-side-validated smart contracts, mainnet November 2025 with Tether USDT), Taproot Assets (Lightning Labs multi-asset protocol, v0.7 December 2025), BitVM/BitVM2 (optimistic fraud-proof computation, mainnet 2025), Stacks (Nakamoto upgrade October 2024, sBTC December 2024), and Ordinals/Runes (inscription NFTs and fungible tokens, Runes launched April 2024 halving). Bitcoin ZK-rollups (Citrea mainnet January 2026) represent the frontier. Ecosystem growing at 25% CAGR since 2023."@en)
    AnnotationAssertion(dcterms:identifier blockchain:BTCLayer3 "BC-1109"^^xsd:string)
    AnnotationAssertion(dcterms:subject blockchain:BTCLayer3 "Bitcoin Layer 3, RGB Protocol, Taproot Assets, BitVM, Stacks, Ordinals, Runes, Smart Contracts, DeFi, Bitcoin Scalability, Lightning Network, ZK Rollups"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(blockchain:requires)
  AsymmetricObjectProperty(blockchain:enables)
  AsymmetricObjectProperty(blockchain:implements)
  AsymmetricObjectProperty(blockchain:contrastsWith)
  TransitiveObjectProperty(blockchain:dependsOn)
  FunctionalDataProperty(blockchain:programmabilityApproach)

## About BTC Layer 3

- **BTC Layer 3** is the collective designation for application-layer protocols and execution environments anchored to the [[Bitcoin Proof-of-Work Protocol]] blockchain through the intermediary of [[Layer 2 Solutions]] — principally the [[Lightning Network]], [[state channels]], [[sidechains]], and [[rollups]].
- The defining characteristic of a Bitcoin Layer 3 system: it extends Bitcoin's programmability without requiring changes to Bitcoin's consensus rules, preserving the security and decentralisation guarantees of the base layer whilst enabling substantially richer application logic than [[Bitcoin Script]] natively supports.
- The intellectual lineage of Bitcoin Layer 3 runs through the same cryptographic traditions as Bitcoin itself: the application of [[zero-knowledge proofs]], [[hash functions]], [[Schnorr signatures]], and [[Merkle trees]] to create verifiable off-chain state machines whose security ultimately reduces to Bitcoin's [[proof-of-work]] security.
- This is philosophically distinct from competing blockchain ecosystems such as [[Ethereum]], where base-layer programmability is treated as a design goal, at the cost of more complex consensus and larger attack surfaces.
- Bitcoin Layer 3 advocates argue that separating concerns — keeping Layer 1 simple and secure, using Layer 2 for scaling, and using Layer 3 for application logic — produces a more robust and sustainable long-term architecture, analogous to the Internet's OSI model where HTTP runs over TCP/IP without changing Ethernet.
- The transformation of Bitcoin from a pure payment network into a programmable financial infrastructure substrate began in earnest with the 2017 [[SegWit]] upgrade, which fixed transaction malleability and enabled the [[Lightning Network]], and accelerated dramatically with the 2021 [[Taproot]] upgrade (BIP-341/342, activated November 2021).
- [[Taproot]] introduced [[Schnorr signatures]], MAST (Merkelised Abstract Syntax Trees via Tapscript), and crucially the ability to embed larger witness data at discounted cost — creating the technical substrate for [[Taproot Assets]], [[RGB Protocol]], [[Ordinals]], and the [[BitVM]] paradigm.
- The 2023 Ordinals explosion demonstrated mass-market appetite for Bitcoin-native digital ownership, generating over 70 million inscriptions and $300M+ in cumulative miner fees by 2024.
- This established a viable developer and user community for Bitcoin application-layer innovation and validated the market hypothesis that users would pay significant fees for Bitcoin-secured digital ownership primitives even before mature application-layer infrastructure existed.
- The subsequent launch of [[BRC-20]] tokens and then the more efficient [[Runes Protocol]] at the April 2024 halving demonstrated iterative protocol improvement within a competitive ecosystem driven by developer creativity rather than committee process.
- Bitcoin Layer 3 differs fundamentally from [[Ethereum Layer 2]] solutions in its philosophical orientation:
  - Ethereum Layer 2 systems (Arbitrum, Optimism, zkSync, StarkNet) are optimisations of a base layer that already supports Turing-complete smart contracts; they inherit Ethereum's account-based model and EVM semantics
  - Bitcoin Layer 3 systems must construct programmability from scratch, working within or around Bitcoin Script's intentional limitations, and anchoring to a UTXO-based settlement layer with no native concept of contract state
  - This harder engineering challenge produces systems with fundamentally different security trade-offs and privacy properties
  - [[RGB Protocol]]'s client-side validation is radically more private than any Ethereum Layer 2 system, because no contract state is published to any shared ledger
  - [[BitVM]]'s fraud-proof adjudication is more conservative and trust-minimised than optimistic rollup systems that assume Ethereum's full programmability as their dispute mechanism

## Components / Architecture

- The Bitcoin Layer 3 protocol landscape encompasses seven major technological families, each addressing the programmability-security trade-off through a distinct architectural strategy. Understanding the trade-offs between these families is essential for developers, institutions, and researchers choosing protocols for specific applications.
- **Architectural strategy summary**:
  - [[RGB Protocol]]: client-side validation — maximum privacy, no on-chain data, Turing-complete AluVM, most complex implementation
  - [[Taproot Assets]]: Lightning-integrated asset issuance — simplest developer experience, Lightning Labs commercial backing, focus on stablecoins
  - [[BitVM]] / BitVM2: optimistic off-chain computation — fraud-proof adjudication in Bitcoin Script, trust-minimised bridges, challenge period required
  - [[Stacks]]: anchored state machine — Clarity smart contracts, Proof of Transfer, dedicated DeFi ecosystem, mature production deployment
  - [[Rootstock]] RSK: EVM-compatible sidechain — Solidity smart contracts, merge-mined security, largest EVM-Bitcoin developer crossover
  - [[Ordinals]] / [[Runes Protocol]]: inscription-based assets — simplest model, no smart contracts, Bitcoin-native provenance, UTXO-native token design
  - [[Discreet Log Contracts]]: conditional payments — privacy-preserving financial derivatives, oracle-attested outcomes, no on-chain contract state
  - Bitcoin ZK-rollups ([[Citrea]], Merlin, Alpen): validity proofs — strongest security model, immediate finality, most computationally demanding
- The seven families are not mutually exclusive — many Bitcoin Layer 3 applications combine multiple protocols (e.g., [[Taproot Assets]] stablecoins routed over [[Lightning Network]] channels secured by [[BitVM2]] bridges, with [[DLC]]-based hedging contracts providing collateral protection).
- **Protocol maturity assessment (2026)**:
  - [[Stacks]] + sBTC: most mature production DeFi ecosystem; Nakamoto upgrade complete; 100+ dApps; $208M TVL
  - [[Rootstock]] RSK: most mature EVM-compatible Bitcoin sidechain; multi-year production track record; Sovryn DeFi
  - [[Ordinals]] + [[Runes Protocol]]: largest user base; 70M+ inscriptions; $300M+ fees; active NFT and token markets
  - [[Taproot Assets]]: v0.7 production release; USDT/USDC live; commercial wallet integrations; rapid stablecoin adoption
  - [[Bitlayer]] BitVM Bridge: first production BitVM2 bridge; YBTC live; DeFi applications launching
  - [[Citrea]]: newest production ZK-rollup; launched January 2026; 30+ applications at launch; ctUSD stablecoin
  - [[RGB Protocol]]: mainnet November 2025; Tether USDT integration; complex implementation; privacy-focused niche
  - [[Discreet Log Contracts]]: production-ready infrastructure; Liquidium commercial deployment; institutional interest growing
- The competitive dynamics across protocol families will likely consolidate over 2026-2030 as specific use-case winners emerge: [[Taproot Assets]] for mainstream stablecoin payments; [[RGB Protocol]] for privacy-sensitive institutional asset issuance; [[BitVM2]] bridges for trust-minimised BTC access to any Layer 2; [[Stacks]] for the most mature Bitcoin DeFi ecosystem; [[Citrea]] and [[Merlin Chain]] for ZK-rollup-based EVM applications on Bitcoin.
- Interoperability between protocol families remains an open engineering challenge that the Bitcoin developer community and standards bodies (LNP/BP Standards Association, Bitcoin Optech) are beginning to address through cross-protocol specification work.

### RGB Protocol — Client-Side-Validated Smart Contracts

- **[[RGB Protocol]]** is a Turing-complete, privacy-preserving [[smart contract]] system for [[Bitcoin Proof-of-Work Protocol]] and the [[Lightning Network]], developed by the LNP/BP Standards Association (led by Maxim Orlovsky). RGB operates through a principle of **client-side validation**: contract logic, state transitions, and asset balances are validated locally by the parties involved in a transaction, rather than by Bitcoin miners or full nodes. Only cryptographic commitments — hash digests anchoring contract state to specific Bitcoin UTXOs — are published on-chain, meaning that RGB contract execution generates zero blockchain bloat: the Bitcoin base layer carries no application data beyond the ~32-byte commitment hash embedded in a [[Taproot]] output.
- The RGB architecture comprises three main components: (1) the **RGB Core** library implementing the contract validation engine (written in Rust, open-sourced under Apache 2.0); (2) **RGB Standard Library** providing ready-made contract schemas including RGB20 (fungible tokens, analogous to ERC-20) and RGB21 (non-fungible assets, analogous to ERC-721); and (3) the **Storm** transport and storage layer for exchanging contract data off-chain between counterparties. RGB contracts are expressed in a domain-specific language called **AluVM**, a register-based virtual machine specifically designed for client-side validation contexts, enabling Turing-complete contract logic without any on-chain execution overhead.
- **Mainnet status (2025)**: The BitMask wallet launched RGB20 and RGB21 mainnet support on 21 November 2025, following four years of protocol and infrastructure development. The mainnet release includes an on-chain [[atomic swap]] protocol and orderbook enabling trustless exchange between fungible and non-fungible RGB assets and native Bitcoin — meaning for the first time, users can swap between fungible and non-fungible assets on Bitcoin and view transaction confirmations through standard Bitcoin blockchain explorers such as mempool.space. Tether announced USDT integration with RGB, bringing the world's largest stablecoin (processing more daily volume than Visa) to Bitcoin's infrastructure. RGB contracts can route payments over the [[Lightning Network]], inheriting Lightning's theorised up-to-40-million-TPS throughput ceiling for micro-payments — making RGB theoretically the most scalable smart-contract framework in the Bitcoin ecosystem.
- RGB's **privacy properties** are substantially stronger than any on-chain alternative: since contract state is held client-side, observers of the Bitcoin blockchain see only opaque UTXO commitments with no visible contract semantics, asset amounts, counterparty identities, or contract conditions. This aligns with [[Confidential Transactions]] principles (originally proposed by Gregory Maxwell) and positions RGB as the smart-contract framework of choice for financial privacy use cases, institutional asset issuance requiring confidentiality, and applications in jurisdictions with strong data-protection requirements such as GDPR in the [[European Union]]. The selective-disclosure design also enables regulatory compliance: an issuer can disclose RGB contract details to a regulator without those details being visible to arbitrary on-chain observers.
- The [[LNP-BP Standards Association]] that stewards RGB has also developed companion protocols including [[Storm]] (decentralised data storage and messaging) and [[Bifrost]] (a proposed extension to the Lightning Network protocol enabling RGB asset routing), creating a layered ecosystem of Bitcoin application protocols built on common foundations. The association operates as a non-profit focused on open standards development, with contributions from developers across Europe, North America, and Asia, and is distinct from corporate-controlled protocol development teams.

### Taproot Assets — Multi-Asset Lightning Protocol

- **[[Taproot Assets]]** (formerly Taro) is a protocol developed by [[Lightning Labs]] enabling the issuance of digital assets on the Bitcoin blockchain that can be transferred over the [[Lightning Network]] at Lightning's characteristic instant, low-fee settlement rates. Taproot Assets exploits the [[Taproot]] upgrade's expanded witness capacity and key-aggregation properties (Schnorr/MAST) to embed asset metadata compactly in Bitcoin outputs without bloating the UTXO set, and has evolved from an experimental asset-issuance protocol into a production multi-asset payment network carrying USDT, USDC, and regional stablecoins by 2025.
- The Taproot Assets protocol architecture includes four core components: (1) the **tapd** daemon — the primary client implementation managing asset issuance, transfer, and channel operations; (2) the **Universe protocol** — a distributed registry system for asset proofs-of-issuance and proofs-of-transfer, enabling light-client verification without full blockchain history, analogous to a decentralised asset registry anchored to Bitcoin; (3) **multi-asset channels** — Lightning payment channels that carry multiple asset types (Bitcoin, stablecoins, tokenised commodities) within a single UTXO, enabling atomic exchange of heterogeneous assets over Lightning routing paths; and (4) **asset-aware routing** — modifications to the Lightning Network routing protocol enabling payments denominated in non-Bitcoin assets to be routed over the Lightning Network, with automatic conversion at edge nodes using liquidity providers who hold both Bitcoin and the target asset.
- **Version timeline**: Mainnet alpha launched October 2023 (on-chain asset issuance only); Lightning Network transfer integration completed July 2024 (tapd v0.4, enabling multi-asset Lightning channels); v0.6 "Bitcoin's Decentralised FX Network" released June 2025 — the first production multi-asset Lightning protocol enabling stablecoins to be minted on Bitcoin and transferred via [[Lightning Network]] instantly for low fees, with USDT ([[Tether]]) and USDC ([[Circle]]) available as bridged USD stablecoins alongside DePix (Brazilian real stablecoin) and a GBP stablecoin through applications including Speed Wallet, LnFi, and Joltz; v0.7 "Set-and-Forget Asset Layer for Lightning" released December 2025, simplifying operational complexity for [[Lightning Network]] node operators running multi-asset channels.
- **Stablecoin integration** represents the primary commercial driver for Taproot Assets adoption: [[Lightning Labs]] CEO Elizabeth Stark and Tether CEO Paolo Ardoino jointly announced USDT on Bitcoin via Taproot Assets in 2024, with operational deployment through Speed Wallet, LnFi, Joltz, and additional wallet integrations during 2025. The macro thesis — enabling USD-pegged [[stablecoins]] to flow over the globally-accessible, low-cost Lightning Network to unbanked and underbanked populations in the Global South — positions Taproot Assets as a potential competitor to SWIFT and conventional [[remittance]] corridors for cross-border payment rails. A user in El Salvador receiving a Lightning-routed USDT payment over Taproot Assets infrastructure pays sub-cent fees versus the 5-8% fee charged by legacy remittance operators on the same corridor.
- **Competitive positioning versus RGB**: Taproot Assets and RGB Protocol are both Bitcoin Layer 3 asset-issuance frameworks competing for the same developer and issuer base, but with different architectural philosophies. Taproot Assets is a Lightning Labs commercial product with strong engineering resources, tighter integration with the LND (Lightning Network Daemon) implementation, and a simpler developer experience. RGB Protocol is an open-standards project with stronger privacy guarantees, more expressive smart-contract semantics (AluVM vs. Taproot Assets' more limited script-like functionality), and a more complex implementation architecture. The two protocols may coexist serving different market segments (Taproot Assets for mainstream stablecoin payments; RGB for privacy-sensitive institutional asset issuance and complex contracts).

### BitVM and BitVM2 — Trustless Bitcoin Computation

- **[[BitVM]]** is a computation paradigm proposed by Robin Linus (ZeroSync) in October 2023 enabling arbitrary program execution on Bitcoin through an **optimistic verification** scheme that requires no consensus changes to Bitcoin. The BitVM model works as follows: a Prover asserts a claim about the output of a computation — for example, "this ZK proof is valid," or "this bridge peg is correctly collateralised"; the claim is assumed valid unless challenged within a defined dispute window; if a Challenger disputes the claim, a bisection protocol iteratively narrows the dispute to a single computation step that is then adjudicated by a Bitcoin Script transaction on-chain — Bitcoin's existing scripting system serves as the final arbitrator of computational disputes. Honest provers cannot be penalised if they behave correctly; dishonest provers are economically penalised when a valid challenge succeeds.
- The BitVM paradigm's insight is that [[Bitcoin Script]] — despite being intentionally non-Turing-complete for on-chain execution — is sufficient as a *dispute adjudicator* for arbitrary off-chain computation, because verifying the correctness of a single computation step is a much simpler operation than executing an arbitrary program. This mirrors the design of [[Optimistic Rollup]] systems on [[Ethereum]] (Optimism, Arbitrum) but adapted to Bitcoin Script's more constrained scripting language, requiring a more complex bisection protocol to reduce disputes to Bitcoin-verifiable steps.
- **BitVM2** (formalised in the 2025 paper "Bridging Bitcoin to Second Layers via BitVM2," IACR ePrint 2025/1158) advances the original BitVM model by reducing the trust assumption during the bridge setup phase from an honest-majority threshold (t-of-n) to **existential honesty** (1-of-n) — meaning only a single honest party among the setup committee is needed to guarantee bridge security, regardless of what other committee members do. This is a significant reduction in trust requirement enabling smaller, more practical committee sizes and lowering the barriers to deploying trust-minimised BTC bridges for new Layer 2 systems. BitVM2 also reduces the on-chain footprint of dispute transactions substantially versus the original BitVM.
- Research beyond BitVM2 continues actively: Alpen's "Glock" construction claims hundreds-of-x efficiency improvements over BitVM2 using garbled locks plus a designated-verifier SNARK, potentially enabling dispute resolution that is dramatically cheaper in on-chain fees. This ongoing research trajectory suggests that BitVM-family constructions will continue improving in efficiency and practicality through 2026-2028 as the underlying cryptographic techniques mature.
- **Ecosystem deployments by 2025-2026**: Bitlayer's BitVM Bridge launched mainnet in July 2025 — the first production trust-minimised BTC bridge, with YBTC (1:1 BTC peg) enabling BTC holders to access DeFi without federations or custodians; [[BOB Protocol]] deployed BitVM bridge on testnet with mainnet expected Q4 2025; Citrea's Clementine bridge (BitVM2-based) launched on Citrea mainnet January 2026, expressing a ZK-STARK proof verifier in Bitcoin Script to enable trust-minimised verification of zero-knowledge proofs on Bitcoin without consensus changes; [[Babylon Protocol]] integrated BitVM constructions for [[Bitcoin Staking]] security proofs. The **BitVM Alliance** — comprising Babylon, Bitlayer, BOB, Citrea, Merlin, Fiamma, and affiliated teams — coordinates cross-team development, shared security analysis, and research on bridge implementations, with academic collaborations at Stanford University's Applied Cryptography Group and TU Vienna's Security and Privacy group.
- The strategic significance of BitVM for the Bitcoin Layer 3 ecosystem is that it enables a "free market of second layers" in which any Layer 2 system — rollup, sidechain, state channel network, application-specific chain — can connect to [[Bitcoin Proof-of-Work Protocol]] in a trust-minimised way without requiring Bitcoin miners to validate Layer 2 logic, and without any modification of Bitcoin's consensus rules. This resolves the "sovereign bridge" problem that plagued earlier Bitcoin Layer 2 systems: the Liquid Network's federation and Rootstock's PowPeg both require trusting a fixed set of federation members to control the BTC peg, creating centralisation and counterparty risk that BitVM2 substantially mitigates.

### Stacks — Bitcoin-Anchored Smart Contract Platform

- **[[Stacks]]** (STX) is a Layer 2 smart-contract platform providing [[Clarity]] smart contracts and **[[Proof of Transfer]]** (PoX) consensus, in which Stacks miners compete to win STX block rewards by committing Bitcoin (BTC) to a designated PoX address — a mechanism that cryptographically links Stacks block production to Bitcoin's [[proof-of-work]] security without requiring Bitcoin miners to change their behaviour. The Clarity smart-contract language is intentionally non-Turing-complete (decidable) for security reasons, enabling static analysis of contract behaviour before deployment — a deliberate contrast with Solidity's Turing-completeness, which has historically enabled numerous catastrophic [[smart contract]] exploits.
- **Nakamoto Upgrade (29 October 2024)**: The Nakamoto hard fork fundamentally transformed Stacks' security and performance model across multiple dimensions. Stacks blocks are now produced approximately every 6 seconds (versus ~10-minute Bitcoin block intervals), dramatically improving user experience and enabling applications requiring faster finality. Stacks blocks are cryptographically bound to Bitcoin blocks such that reverting a confirmed Stacks block requires reverting the corresponding Bitcoin block — making Stacks effectively **Bitcoin-reorg-proof** and allowing developers to treat Stacks transactions as having the same finality as Bitcoin transactions once included in a Bitcoin block. The Nakamoto upgrade also structurally limits Miner Extractable Value (MEV) extraction opportunities, improving transaction ordering fairness for application users.
- **sBTC (launched 16 December 2024)**: sBTC is a decentralised [[Bitcoin Proof-of-Work Protocol]]-pegged asset secured by the Bitcoin network and managed by a rotating set of Stacks network signers using threshold multi-signature cryptography. sBTC enables Bitcoin holders to use their BTC in Stacks [[Decentralised Finance]] applications — lending via [[Zest Protocol]], liquidity provision on [[Velar]] and [[BitFlow]] DEX, yield strategies on other Stacks-native protocols — without selling Bitcoin or relying on centralised custodians. The peg mechanism involves signer committees holding the BTC collateral on Bitcoin mainchain via multi-sig, with sBTC minted 1:1 on Stacks when BTC is deposited. **sBTC Cap-3** (5,000 BTC maximum capacity) filled within hours of launch in May 2025, demonstrating strong organic demand. The planned **Satoshi upgrades** (2025-2026) target fully trustless sBTC with a reduced and more decentralised signer committee.
- **Active DeFi ecosystem on Stacks (2025)**: Stacks hosts over 100 decentralised applications as of 2025, representing the most mature Bitcoin-native [[Decentralised Finance]] ecosystem. Key protocols include: [[Zest Protocol]] (Bitcoin-collateralised lending enabling users to earn BTC yield without selling Bitcoin); [[Velar]] (multi-feature DeFi platform combining automated market maker, perpetual contracts, and limit-order functionality); [[BitFlow]] (native STX/BTC DEX with concentrated liquidity modelled on Uniswap v3 mechanics); and [[Asigna]] (Bitcoin Multisig v2 treasury management infrastructure, having raised $3M in funding). [[Wormhole]] cross-chain messaging integration enables multichain sBTC and STX transfers to [[Aptos]] and [[Solana]] networks, extending Stacks' DeFi composability into the broader multi-chain ecosystem while maintaining Bitcoin as the underlying settlement asset.
- Stacks secures over $208M in total value locked (TVL) as of mid-2025 with the STX token trading at ~$0.63 and a market capitalisation above $1.1B. The Stacks ecosystem demonstrates that a dedicated Bitcoin-anchored smart-contract platform with a dedicated developer community and commercially-incentivised protocol development can build a sustainable Bitcoin DeFi ecosystem — a model that newer Bitcoin Layer 3 entrants (Citrea, BOB) are attempting to replicate with different technical approaches.

### Rootstock (RSK) — EVM-Compatible Bitcoin Sidechain

- **[[Rootstock]]** (RSK) is a Bitcoin sidechain providing [[Ethereum Virtual Machine]] (EVM) compatibility and [[Solidity]] smart contract execution, secured through **merge-mining** with Bitcoin in which RSK blocks are mined simultaneously with Bitcoin blocks by Bitcoin miners who opt into RSK block production. Approximately 60% of Bitcoin hashrate participates in RSK merge-mining as of 2025, providing RSK with substantial [[proof-of-work]] security (comparable to a large independent blockchain) without requiring dedicated RSK mining infrastructure or a separate security budget.
- RSK uses a **two-way peg** (the "PowPeg") connecting BTC on Bitcoin mainchain to RBTC (1:1 BTC equivalent) on the RSK sidechain. The PowPeg is managed by a federation of hardware-security-module (HSM) operators whose custody authority is enforced through [[Bitcoin Script]] multi-signature conditions and time-locked release mechanisms, with hardware attestation preventing operators from accessing the BTC private keys in software. Block times of approximately 30 seconds provide substantially faster confirmation than Bitcoin base layer whilst maintaining the security inherited from Bitcoin's hashrate through merge-mining.
- EVM compatibility enables [[Solidity]] developers to deploy [[Ethereum]] smart contracts on RSK with minimal code changes, accessing Bitcoin's liquidity and security model whilst using familiar development tooling (Hardhat, Foundry, MetaMask). RSK hosts the [[Sovryn]] protocol (decentralised Bitcoin lending and trading, one of the most mature Bitcoin DeFi applications in production), along with growing token and DeFi applications leveraging RBTC as native collateral. RSK's strategic niche is serving EVM-experienced development teams who want Bitcoin security guarantees without learning new smart-contract programming paradigms or starting from scratch with a Bitcoin-native language like Clarity.

### Ordinals and Runes — Bitcoin-Native Digital Assets

- **[[Ordinals]]** is a protocol developed by Casey Rodarmor, launched January 2023, implementing a numbering and tracking system for individual satoshis (the smallest Bitcoin unit, 10^-8 BTC) based on their mining order — "ordinal theory." Ordinal theory assigns a unique number to each satoshi in the order it was mined, enabling individual satoshis to be tracked through Bitcoin transactions and "inscribed" with arbitrary data (text, images, audio, video, application code) stored in [[Taproot]] witness data. This creates **Bitcoin-native NFTs** (Ordinal Inscriptions) stored entirely on-chain within the Bitcoin blockchain, without requiring a separate smart contract platform, oracle service, or off-chain storage infrastructure such as IPFS.
- Ordinals do not require any Bitcoin consensus changes — they exploit the existing Bitcoin Script, SegWit witness data capacity (with [[Taproot]] enabling larger witness sizes at a discounted fee rate under the witness discount introduced by SegWit). By 2024, over 70 million Ordinal inscriptions had been created generating $300M+ in cumulative [[miner]] fees, demonstrating extraordinary demand for Bitcoin-native digital ownership. Collections including Ordinal Punks (replicating the CryptoPunks cultural moment on Bitcoin), Bitcoin Frogs, and NodeMonkes achieved market capitalisations of tens of millions of dollars, establishing a thriving market for Bitcoin-secured digital collectibles with provenance guaranteed by Bitcoin's [[proof-of-work]] chain.
- The Ordinals ecosystem spawned **[[BRC-20]] tokens** (March 2023, created by pseudonymous developer "Domo") — a JSON-based experimental fungible-token standard using Ordinal inscriptions to track token minting and transfer operations. Despite technical inefficiencies (BRC-20 creates "junk UTXOs" and produces high transaction fees through inscription overhead), BRC-20 tokens achieved significant trading volume and developer activity, with tokens such as ORDI reaching market capitalisations of hundreds of millions of dollars. BRC-20 demonstrated that there was substantial demand for fungible-token primitives on Bitcoin even before a UTXO-native design existed.
- **[[Runes Protocol]]** (launched 20 April 2024, timed to coincide with the Bitcoin halving block): Casey Rodarmor designed Runes as a UTXO-native, more efficient alternative to BRC-20 for fungible-token issuance on Bitcoin. Runes leverages Bitcoin's existing UTXO model without creating unnecessary data overhead — Rune balances are tracked in OP_RETURN outputs attached to standard Bitcoin transactions, with no separate inscription data required and no creation of junk UTXOs. Nearly 7,000 Rune tokens were minted within two days of the protocol's launch. The Runes ecosystem includes lending platforms ([[Liquidium]], using [[Discreet Log Contracts]] for Runes-collateralised Bitcoin loans), wallets ([[Xverse]]), and trading platforms ([[Odin.fun]]), demonstrating the rapid ecosystem formation around a well-designed Bitcoin-native token standard.

### Discreet Log Contracts — Bitcoin Financial Derivatives

- **[[Discreet Log Contracts]]** (DLCs), proposed by Thaddeus Dryja (MIT Digital Currency Initiative) in 2018 and extended by numerous contributors through the Bitcoin Optech community and the DLC Working Group, enable two or more parties to enter financial contracts whose outcome depends on real-world events — asset prices, sports results, weather data, election outcomes, commodity indices — without introducing a central point of failure or trusted escrow custodian. The "discreet" in DLC refers to the cryptographic property that the contract's existence and terms are visible only to the parties and the oracle, not to arbitrary blockchain observers — a privacy property that is valuable for institutional applications where counterparties do not wish to disclose their financial positions publicly.
- DLCs use [[Blockchain Oracle]] attestations — cryptographic signatures from designated data-publishing entities over specific event outcomes — combined with [[Schnorr signatures]] and **[[Point Time-Locked Contracts]]** (PTLCs) to create trustless conditional payment scripts. The oracle's attestation key is used with adaptor signatures to lock contract collateral: when the oracle attests an outcome, its signature enables the correct counterparty to claim the locked Bitcoin, whilst the other party's collateral is returned. If neither party claims within a timeout, the contract self-resolves through a pre-agreed fallback. The Bitcoin blockchain records only the funding transaction (indistinguishable from a 2-of-2 multisig) and the settlement transaction (indistinguishable from a standard payment) — revealing nothing about the contract terms or the oracle identity to external observers.
- DLC applications as of 2025-2026 include: [[Liquidium]] (Bitcoin-collateralised lending where borrowers lock [[Ordinals]] or [[Runes]] as collateral in DLC escrows, receiving BTC loans without any centralised custodian); [[DLC.Link]] (Bitcoin oracle infrastructure enabling DLC-based deposits in DeFi protocols on [[Ethereum]] and [[Stacks]], allowing DeFi protocols to accept Bitcoin as collateral trustlessly); and bilateral financial derivatives for institutions wanting Bitcoin-settled forwards, options, and structured products without counterparty credit risk.

### ZK-Rollups — Bitcoin Validity Proofs

- **Bitcoin ZK-rollups** represent the technical frontier of Bitcoin Layer 3, applying zero-knowledge proof systems (ZK-STARKs, ZK-SNARKs) to compress arbitrary computation into compact validity proofs posted to Bitcoin L1. Unlike optimistic rollups (BitVM-family), ZK-rollups provide **immediate finality** once a validity proof is verified on Bitcoin — no challenge period, no assumption of an honest challenger, no economic deposit at risk during a dispute window. The cryptographic guarantee of a ZK proof means that any verified state transition is provably correct under the security assumptions of the underlying proof system.
- **[[Citrea]]** launched mainnet on 27 January 2026 as Bitcoin's first production-grade ZK-rollup. Citrea executes transactions in an EVM-compatible environment (enabling Solidity smart contracts), proves computation correctness with ZK-STARKs via a zkVM built on RISC Zero, and posts compressed state diffs plus proofs directly to Bitcoin L1 using the Taproot witness data capacity. The **Clementine bridge** — Citrea's BitVM2-based bridge design — optimistically verifies ZK proofs on Bitcoin using Bitcoin Script as the fraud-proof adjudicator, achieving trust minimisation without consensus changes. The design is novel: Clementine expresses a ZK-STARK verifier inside the BitVM2 bisection protocol, meaning Bitcoin Script adjudicates not arbitrary computation but specifically the correctness of a zero-knowledge proof verification step.
- Citrea's mainnet launched with over 30 Bitcoin-secured applications including DEXs, liquidity tools, lending protocols, and privacy-focused services. Native assets include **ctUSD** (a Bitcoin-native stablecoin issued by MoonPay, built on M0's open stablecoin infrastructure) and **cBTC** (a Bitcoin-backed asset created through the Clementine bridge). [[Merlin Chain]] surpassed $1.7B TVL by August 2025, positioning itself as the largest Bitcoin ZK-rollup by total value locked. Research networks including [[Alpen]] (using garbled locks plus designated-verifier SNARKs for substantially more efficient dispute resolution than standard BitVM2) represent the next wave of Bitcoin cryptographic research.

## Use Cases / Major Families

### Stablecoin Infrastructure

- The largest commercial use case for Bitcoin Layer 3 in 2025-2026 is **stablecoin rails** — enabling USD-pegged and other fiat-equivalent assets to flow over Bitcoin and [[Lightning Network]] infrastructure at the speed and cost of Lightning payments rather than traditional banking channels.
- [[Tether]] (USDT) integration with both [[Taproot Assets]] (v0.6, June 2025) and [[RGB Protocol]] (mainnet November 2025) establishes Bitcoin as a third major stablecoin settlement network alongside [[Ethereum]] and [[Tron]], with the critical differentiation that Bitcoin-native stablecoins can flow over [[Lightning Network]] channels with near-zero fees and sub-second settlement — uniquely suited to high-frequency micropayment use cases.
- [[Circle]] (USDC) has also integrated with Taproot Assets, making both major USD stablecoins natively available on the Bitcoin-Lightning payment network, representing a significant vote of confidence in Bitcoin as stablecoin infrastructure from the two largest stablecoin issuers globally.
- The macro argument driving stablecoin adoption on Bitcoin Layer 3 is straightforward: billions of people in the [[Global South]] already use mobile phones capable of running a Lightning wallet but lack access to banking infrastructure or stable local currencies.
- Bitcoin-native USD stablecoins routed over the [[Lightning Network]] using [[Taproot Assets]] infrastructure provide dollar-denominated digital payments without correspondent bank accounts, without SWIFT fees, and without the 5-8% remittance charges extracted by Western Union and similar operators.
- The corridors from Mexico to the United States, Nigeria to the United Kingdom, and the Philippines to Europe represent trillion-dollar-per-year remittance flows that are structurally accessible through Bitcoin-native stablecoin infrastructure operating over the [[Lightning Network]].
- Regional stablecoin innovation has accompanied USD stablecoin launches: DePix (Brazilian real stablecoin) and GBP stablecoin are live on [[Taproot Assets]], demonstrating that Bitcoin-Lightning stablecoin infrastructure is not limited to USD and can support any fiat currency with sufficient liquidity provision at the edge-node level.

### Bitcoin DeFi (BTCFi)

- **Bitcoin DeFi** (BTCFi) encompasses [[lending]], [[borrowing]], [[liquidity provision]], and [[yield generation]] using [[Bitcoin Proof-of-Work Protocol]] as the primary collateral or settlement asset.
- The core thesis of BTCFi: the world's most widely held and most trusted digital asset should earn yield in productive DeFi applications without requiring holders to bridge to [[Ethereum]] or other networks, sacrificing Bitcoin's security and custody guarantees.
- This thesis has driven billions of dollars in total value locked across Bitcoin Layer 3 protocols by 2025, with institutions seeking Bitcoin yield pathways that preserve BTC custody and settlement finality.
- **Active BTCFi applications (2025-2026)**:
  - [[Zest Protocol]] on [[Stacks]] — Bitcoin-collateralised lending with BTC yield, allowing institutions to earn returns on BTC holdings without selling or bridging
  - [[Sovryn]] on [[Rootstock]] — decentralised Bitcoin lending and trading, one of the most battle-tested Bitcoin DeFi applications in production since 2020
  - [[Velar]] on [[Stacks]] — multi-feature DeFi platform with AMM, perpetual contracts, and limit-order book functionality
  - [[BitFlow]] on [[Stacks]] — concentrated liquidity DEX (Uniswap v3-style mechanics) for STX/BTC trading pairs
  - [[Babylon Protocol]] — enabling Bitcoin holders to stake BTC as economic security for other [[proof-of-stake]] blockchains, generating yield without bridging BTC off-chain
  - [[DLC.Link]] — DLC oracle infrastructure enabling DeFi protocols on [[Ethereum]] and [[Stacks]] to accept Bitcoin as collateral trustlessly
- The [[sBTC]] mechanism on [[Stacks]] provides the most mature model for Bitcoin yield without custodial risk: BTC is locked in a Bitcoin multi-sig controlled by decentralised Stacks signers, sBTC is minted 1:1 on Stacks, and the sBTC can be deployed in Stacks DeFi protocols to earn yield, with redemption back to BTC available when the user chooses.
- The entire sBTC flow is secured by Bitcoin's [[proof-of-work]] hashrate at the settlement layer and by Stacks' Nakamoto-upgraded security at the execution layer, providing a security model substantially more robust than wrapped-BTC alternatives on other chains.
- [[Babylon Protocol]]'s Bitcoin staking represents a distinct BTCFi primitive: BTC holders provide economic security to [[Proof of Stake]] chains (Cosmos appchains, Polygon, EigenLayer AVS systems) via UTXO locking on Bitcoin mainchain, earning yield denominated in the target chain's native token without any cross-chain bridge or custodian.

### Bitcoin NFTs and Digital Ownership

- [[Ordinal]] inscriptions establish a digital-ownership primitive requiring no smart-contract platform, no oracle service, no off-chain storage system such as IPFS, and no trust in any issuer beyond Bitcoin's consensus.
- If an inscription exists on-chain in a valid Bitcoin block, its provenance is cryptographically guaranteed to the full depth of Bitcoin's accumulated [[proof-of-work]] security — currently representing approximately 700 exahashes per second of computational effort securing every inscription.
- Collections including Ordinal Punks, Bitcoin Frogs, and NodeMonkes achieved market capitalisations of tens of millions of dollars, establishing a collector community focused specifically on Bitcoin-secured digital ownership as distinct from [[Ethereum]]-based NFTs that rely on external storage and contract infrastructure.
- The cultural argument for Ordinals resonates particularly strongly with Bitcoin-maximalist collectors who view Bitcoin's [[proof-of-work]] security as fundamentally superior to [[proof-of-stake]] chains for long-term provenance guarantees.
- [[DLCs]] via [[Liquidium]] enable Ordinals-collateralised lending — an Ordinals holder can lock their Bitcoin-native NFT as collateral in a DLC escrow and receive BTC without selling the NFT, with the DLC mechanism ensuring the lender claims the NFT if the loan is not repaid — without requiring any custodian or trusted third party.
- [[Runes Protocol]] provides a more UTXO-efficient fungible-token layer for community currencies, gaming tokens, meme tokens, and utility tokens on Bitcoin, with a design that integrates cleanly with Bitcoin's existing transaction model without creating the junk UTXOs that degraded the [[BRC-20]] user experience.

### Cross-Chain Trustless Bridges

- BitVM2-based bridges represent the first trust-minimised BTC bridges not requiring a federation of custodians — a significant security improvement over all prior Bitcoin bridge designs.
- Previous BTC bridge designs all require trusting a committee of signers: the [[Liquid Network]] uses an 11-member federation of Bitcoin exchanges and companies; Rootstock's PowPeg uses an HSM-based federation of operators; Wrapped BTC on [[Ethereum]] uses BitGo as sole custodian.
- BitVM2 reduces the trust requirement to existential honesty (1-of-n), meaning BTC collateral is safe as long as any single participant in the setup committee is honest — a dramatically weaker assumption than requiring a majority honest federation.
- Bitlayer's BitVM Bridge (mainnet July 2025, YBTC token), Citrea's Clementine bridge (mainnet January 2026, cBTC token), and BOB Protocol's forthcoming BitVM bridge represent the first generation of production BitVM2-based trust-minimised bridges.
- The long-term vision articulated by the BitVM Alliance is a "free market of Layer 2 solutions" where any Bitcoin-secured rollup or sidechain can offer competitive bridge solutions to BTC holders without requiring trust in any specific operator set, enabling genuine competition among Layer 2 systems on technical merit rather than on the trustworthiness of their bridge federation.
- **Bridge security comparison**:
  - Liquid Network: 11-of-15 federation trust, 1-minute block time, functionally centralised
  - RSK PowPeg: HSM-based federation trust, 30-second blocks, hardware-attested
  - BitVM2 bridges: existential honesty (1-of-n), challenge period of ~1 week, cryptographic guarantees
  - ZK bridges (Citrea Clementine): existential honesty + ZK validity proof, strongest security model

### AI Agent Execution Environments

- Bitcoin Layer 3 protocols provide infrastructure for **autonomous AI agent** operation — an emerging use case as AI agent frameworks integrate Bitcoin [[Lightning Network]] micropayment capabilities.
- The combination of [[Lightning Network]] instant micropayments with Layer 3 programmability creates machine-economy payment primitives not achievable with conventional banking infrastructure: AI agents can pay for computation resources, API access, data feeds, and inference services in real-time Bitcoin-denominated micropayments with sub-cent fees, without requiring bank accounts, payment processor relationships, or minimum transaction sizes.
- [[BitVM]] and ZK-rollups enable **verifiable computation** — AI agents can prove the correct execution of computational workloads via zero-knowledge or fraud-proof mechanisms, enabling trustless markets for AI inference where a buyer can verify they received correct computation output without trusting the provider.
- [[Stacks]] Clarity smart contracts support deterministic AI agent logic with Bitcoin-final settlement, enabling autonomous agents to hold and deploy BTC-denominated assets without human intervention whilst providing an auditable record of all decisions.
- [[RGB Protocol]] enables privacy-preserving AI agent asset management where the agent's portfolio and transaction history are not visible to blockchain observers — important for competitive AI trading agents operating in markets where portfolio disclosure would be exploited.
- The ElizaOS open-source AI agent framework has demonstrated technical integration of [[Lightning Network]] micropayment capabilities, allowing AI agents to autonomously pay for API access and computational services — a foundational capability for a Bitcoin-native machine economy.
- The combination of [[Taproot Assets]] stablecoin payments (enabling USD-denominated AI service fees) and [[RGB Protocol]] privacy (enabling confidential AI agent portfolios) with [[BitVM]] verifiable computation (enabling trustless AI inference markets) represents a converging set of Layer 3 primitives sufficient for sophisticated AI agent financial applications by 2027-2028.

## Academic Context

- Bitcoin Layer 3 systems engage several active academic research traditions spanning cryptography, distributed systems, formal verification, and economics. The combination of novel cryptographic constructions (BitVM fraud proofs, ZK-STARK Bitcoin rollups, DLC adaptor signatures) with complex economic systems (Bitcoin blockspace markets, Lightning routing game theory, DeFi token economics) has generated a rich interdisciplinary research landscape.

### Client-Side Validation Theory (RGB)

- Client-side validation (the theoretical foundation of [[RGB Protocol]]) was formalised by Maxim Orlovsky and the LNP/BP Standards Association in a series of technical specifications drawing on Pedersen commitments, Storm message passing, and the AluVM virtual machine architecture.
- The fundamental security guarantee: no party can forge a valid RGB state transition without knowledge of the previous UTXO owner's private key, because the state commitment is cryptographically anchored to a specific Bitcoin UTXO.
- Security analysis focuses on whether a dishonest counterparty can deceive a validating node about contract state — the conclusion from independent cryptographer review is that this is infeasible given correct implementation of the commitment scheme.
- The relationship between RGB client-side validation and [[Confidential Transactions]] (Gregory Maxwell, 2015) is significant: both protocols use Pedersen commitments to hide asset amounts from on-chain observers, but RGB extends this to the full contract state rather than just payment amounts.
- AluVM's design as a decidable, non-Turing-complete virtual machine for client-side contexts is itself a research contribution — it provides the expressiveness of a register machine (enabling arbitrary computation) whilst being analysable for termination and resource bounds, properties important for contracts that must be validated by potentially resource-constrained counterparties.

### BitVM and Optimistic Computation on Bitcoin

- Robin Linus's original BitVM paper (October 2023) and the BitVM2 formalisation (IACR ePrint 2025/1158) establish the formal security model for optimistic computation on Bitcoin in terms of cryptographic game-based security definitions.
- The key theoretical contribution of BitVM is proving that [[Bitcoin Script]] — despite being intentionally limited — is sufficient as a dispute-resolution mechanism for arbitrary off-chain computation. The insight is that verifying the correctness of a single computation step is far simpler than executing an arbitrary program, and Bitcoin Script can verify single-step correctness.
- Stanford University's Applied Cryptography Group conducted independent security analysis of BitVM constructions, examining the bisection protocol's security under various adversarial models including Byzantine Prover, colluding Challengers, and network-partition adversaries.
- TU Vienna's Security and Privacy group contributed to formal verification of the bisection protocol's correctness, establishing that the protocol terminates and correctly identifies computational errors under standard cryptographic assumptions.
- The relationship between BitVM and classical complexity theory is deep: the bisection protocol for identifying a computation error is essentially a binary search in computation trace space, analogous to the PCP theorem's verification of NP proofs through random spot-checks. BitVM's dispute protocol is related to the SNARK "IOP" (Interactive Oracle Proof) paradigm but constrained to the expressiveness of Bitcoin Script.
- **Alpen's Glock construction** (2025): represents a significant theoretical advance beyond BitVM2, using garbled circuits (Yao's garbled circuits, 1982) combined with a designated-verifier SNARK to reduce dispute resolution costs by orders of magnitude versus BitVM2. This suggests that the theoretical limits of Bitcoin-native verifiable computation have not yet been reached.

### ZK-Proof Systems Applied to Bitcoin

- [[Citrea]]'s use of RISC Zero's zkVM and ZK-STARK proof systems for Bitcoin rollups draws on rapidly advancing proof generation technology, where proof generation times have dropped from hours (2022) to seconds (2025).
- Key algorithmic advances enabling this speedup: Plonky2 (2022), Plonky3 (2023), Boojum (2023), and FRI-based recursive SNARKs that enable proofs to be recursively composed without trusted setups.
- The fundamental Bitcoin-specific challenge is that [[Bitcoin Script]] has no native opcode for verifying ZK proofs (unlike [[Ethereum]] post-EIP-4844 / EIP-196/197 for BN254-based SNARKs), requiring BitVM-style bisection to adjudicate ZK proof verification disputes.
- This is dramatically more complex than adding a ZK-verification opcode: instead of one Script operation, the Clementine bridge implements the entire ZK-STARK verifier as a target for the BitVM2 bisection protocol, requiring careful engineering to ensure the verifier circuit compiles correctly to the bisection-compatible format.
- Post-quantum security considerations are relevant for long-duration Bitcoin Layer 3 applications: ZK-STARKs are post-quantum secure (relying only on hash functions), while ECDSA/Schnorr signatures used for Bitcoin UTXOs are vulnerable to quantum adversaries. Long-term Bitcoin Layer 3 security research must address the transition to post-quantum signature schemes.
- **Recursive ZK proofs** enable proof aggregation — a single ZK-STARK can prove the correctness of thousands of prior ZK-STARK computations, enabling proof chains that verify the entire history of a rollup's state transitions in a single verifiable artifact. This property is important for Bitcoin rollup light clients that cannot store full proof histories.

### Discreet Log Contracts — Academic Foundations

- DLCs were introduced by Thaddeus Dryja (MIT Digital Currency Initiative, 2018) with the insight that [[Blockchain Oracle]] attestations using adaptor signatures enable conditional Bitcoin payments without any on-chain contract state.
- Lloyd Fournier's extension ("One-Time Verifiably Encrypted Signatures for PTLCification of DLCs," 2020) enabled DLCs to be routed over the [[Lightning Network]] using [[Point Time-Locked Contracts]] (PTLCs), turning DLCs from bilateral on-chain contracts into off-chain routable financial instruments.
- Chris Stewart and Ben Carman at Suredbits implemented the first production DLC infrastructure, contributing the DLC specification to the Bitcoin Optech community and demonstrating practical deployment in Bitcoin mainnet contracts.
- Academic analysis of **oracle incentive design** — how to prevent oracles from lying about event outcomes — has produced multi-oracle aggregation schemes requiring independent attestation from multiple oracles before a DLC can settle, reducing the trust in any single oracle to a weaker threshold-honesty assumption.
- **DLC privacy analysis**: the cryptographic privacy properties of DLCs — specifically the proof that a settled DLC transaction is computationally indistinguishable from a standard Bitcoin payment to an external observer — have been formally analysed using game-based security definitions, confirming the privacy guarantee under standard ECDLP hardness assumptions.
- Economic research on DLC-based **prediction markets** (using DLCs to implement binary outcome markets where the oracle attests the outcome) has examined whether oracle equilibrium can be maintained in adversarial settings where manipulation profits may exceed reputation costs — an open problem with practical implications for DLC-based financial instruments.

### Ordinal Theory, Inscription Economics, and Blockspace Markets

- Casey Rodarmor's ordinal theory, while not initially peer-reviewed, sparked significant academic analysis at the intersection of digital art provenance, NFT market microstructure, and Bitcoin blockspace economics.
- **Blockspace market research**: economists analysed the Ordinals-driven fee spike in late 2023, when inscription activity temporarily increased Bitcoin transaction fees by 3-5x, as a natural experiment in Bitcoin's fee market dynamics. The episode validated the prediction that non-financial uses of Bitcoin blockspace would generate substantial miner fee revenue, with implications for Bitcoin's long-run security budget as block subsidies decline toward zero.
- **Fee market equilibrium**: research questions include whether Bitcoin's blockspace market will reach equilibrium with sufficient fee revenue for security without Ordinals activity causing sustained fee spikes that crowd out financial transactions. Game-theoretic models of Bitcoin miner revenue maximisation under the Ordinals/Runes regime are an active area of investigation.
- **Provenance and digital art markets**: art market researchers have analysed Ordinals as a provenance mechanism, comparing the security guarantees of Bitcoin-inscribed provenance to other digital art authentication systems. The conclusion — that Bitcoin's [[proof-of-work]] provides the strongest available timestamp guarantee for digital art provenance — has attracted attention from auction houses and digital art institutions.
- **Runes UTXO economics**: the Runes Protocol's UTXO-native design is itself a contribution to the Bitcoin protocol design literature, demonstrating that fungible token balances can be tracked efficiently in OP_RETURN outputs without creating UTXO set inflation — an important property for Bitcoin's long-term scalability.

## Current Landscape (2026)

- As of May 2026, the Bitcoin Layer 3 ecosystem has evolved from experimental research and early testnets to a multi-protocol production landscape with measurable economic activity, institutional stablecoin adoption, and a clear competitive dynamic between the five major protocol families.
- **Protocol milestones timeline (2023-2026)**:
  - January 2023: [[Ordinals]] protocol launch by Casey Rodarmor; first Bitcoin-native NFTs inscribed on satoshis
  - March 2023: [[BRC-20]] experimental fungible token standard emerges; ORDI token achieves $100M+ market cap
  - October 2023: [[BitVM]] paradigm proposed by Robin Linus (ZeroSync); [[Taproot Assets]] mainnet alpha launches (asset issuance only)
  - Early 2024: Bitcoin Layer 3 ecosystem investment accelerates as BTC price approaches all-time highs
  - April 2024: [[Runes Protocol]] launches at Bitcoin halving block — 7,000 Runes minted within two days
  - July 2024: [[Taproot Assets]] Lightning Network transfer integration (tapd v0.4) — multi-asset Lightning channels operational
  - October 2024: Stacks [[Nakamoto upgrade]] activated — 6-second blocks, Bitcoin-reorg-proof finality, MEV-resistant
  - November 2024: IACR ePrint 2025/1158 (BitVM2) submitted, formalising existential-honesty trust reduction
  - December 2024: [[sBTC]] launched on Stacks — Bitcoin-pegged asset enabling Bitcoin DeFi
  - June 2025: [[Taproot Assets]] v0.6 "Decentralised FX Network" — USDT, USDC, DePix, GBP stablecoins on Lightning
  - July 2025: Bitlayer [[BitVM Bridge]] mainnet launch — first production trust-minimised BTC bridge (YBTC token)
  - August 2025: [[Merlin Chain]] surpasses $1.7B TVL — largest Bitcoin ZK-rollup by total value locked
  - November 2025: [[RGB Protocol]] mainnet with BitMask wallet — RGB20/RGB21 + Tether USDT integration announced
  - December 2025: [[Taproot Assets]] v0.7 "Set-and-Forget Asset Layer" — simplified multi-asset Lightning node operations
  - January 2026: [[Citrea]] ZK-rollup mainnet — Bitcoin's first production ZK-rollup, 30+ applications, ctUSD stablecoin
- **Total value locked (TVL) hierarchy (mid-2025)**:
  - [[Merlin Chain]]: $1.7B+ TVL — ZK-rollup, largest Bitcoin L2/L3 by TVL, strong DeFi and gaming ecosystem
  - [[BOB Protocol]]: $1.2B+ TVL, 90+ protocols, 100,000+ community members — EVM-compatible hybrid Bitcoin-Ethereum rollup
  - [[Stacks]]: $208M+ TVL — Nakamoto-era DeFi ecosystem with sBTC, Zest Protocol, Velar, BitFlow
  - [[Rootstock]]: $100M+ TVL — mature EVM-compatible Bitcoin sidechain, Sovryn DeFi
  - [[RGB Protocol]] + [[Taproot Assets]]: multi-hundred-million in tokenised assets, growing rapidly with stablecoin integration
  - Total Bitcoin L2/L3 TVL exceeded $3B by mid-2025, compared to below $500M in early 2024 — a 6x+ expansion in 18 months
- **Institutional adoption signals**:
  - [[Tether]] (USDT) integration with both [[Taproot Assets]] and [[RGB Protocol]] — first tier-1 stablecoin issuer treating Bitcoin as a production asset-issuance network alongside [[Ethereum]] and [[Tron]]
  - [[Circle]] (USDC) on [[Taproot Assets]] — second major USD stablecoin natively available on Bitcoin-Lightning payment network
  - MoonPay's ctUSD on [[Citrea]] — fiat-backed stablecoin issuance directly on a Bitcoin ZK-rollup, by a regulated fiat on-ramp company
  - [[Lightning Labs]] commercial partnerships with Speed Wallet, LnFi, Joltz for stablecoin remittance corridors — commercial deployment at scale
  - [[Babylon Protocol]] Bitcoin staking — attracting institutional BTC holders seeking yield without relinquishing custody; significant TVL from institutional sources
  - [[Sovryn]] on [[Rootstock]] — multi-year production track record as a decentralised Bitcoin lending protocol
  - BitVM Alliance formation — nine companies (including funded startups with institutional backing) coordinating Bitcoin bridge infrastructure
- **Research frontier — Bitcoin covenant proposals**: The most actively debated development in the Bitcoin developer community as of 2026 is whether to activate covenant-enabling soft forks, with direct implications for Layer 3 capabilities.
  - **OP_CHECKTEMPLATEVERIFY (BIP-119, Jeremy Rubin)**: Enables congestion-control templates and covenant trees for efficient channel creation without pre-signing; would enable CTV-based payment pools dramatically reducing channel-opening on-chain costs
  - **OP_VAULT (BIP-345, James O'Beirne)**: Enables self-custodied institutional Bitcoin storage with revocation ("vault") capabilities; would allow institutions to hold Bitcoin with recovery paths without relying on hardware security modules alone
  - **OP_CAT (BIP-347)**: Enables hash-chain contracts, Merkle tree traversal in Script, and composable covenant primitives; broader covenant expressiveness enabling new Layer 3 application classes
  - **Community dynamics**: Soft-fork activation requires rough social consensus across miners, node operators, and developers — historically a multi-year deliberative process. The Bitcoin developer community as of 2026 is cautiously supportive of limited, well-specified proposals but deeply sceptical of changes that materially increase protocol complexity

## UK Context (Imperial / Edinburgh / UCL / Cambridge / Manchester)

- The United Kingdom hosts world-class academic research on Bitcoin Layer 3 protocols and a small but active ecosystem of industry practitioners, startups, and regulatory engagement relevant to the Bitcoin application-layer landscape.

### UK Academic Research on Bitcoin Layer 3

#### Imperial College London — Cryptography, Routing, and Protocol Design

- **Imperial College London** (Department of Computing and Centre for Cryptocurrency Research and Engineering, CCRE) hosts one of the UK's strongest cryptography and distributed-systems research groups.
- Research on [[Lightning Network]] payment routing — game-theoretic analysis of fee market equilibria in routing (Stefanos Leonardos and colleagues) — is directly relevant to multi-asset routing that [[Taproot Assets]] and [[RGB Protocol]] require for production stablecoin payments.
- Formal verification of smart-contract protocols and security analysis of Layer 2/3 systems — with relevance to both RGB client-side validation security proofs and BitVM bisection protocol correctness.
- Imperial CCRE bridges computer science and finance research with direct relevance to Bitcoin Layer 3 protocol design and economic security analysis of DeFi applications on Bitcoin Layer 3.

#### University of Edinburgh — Formal Methods and Post-Quantum Security

- **University of Edinburgh** (School of Informatics, Blockchain Technology Laboratory led by Professor Aggelos Kiayias) brings formal verification expertise to Bitcoin Layer 3 protocol analysis.
- Edinburgh's formal methods and UTXO model expressiveness research enables rigorous security proofs for DLC adaptor-signature constructions and BitVM bisection protocols.
- Post-quantum cryptography research (lattice-based signatures, hash-based signatures) is directly relevant to future-proofing Bitcoin Layer 3 protocols — Layer 3 constructions relying on ECDSA/Schnorr signatures are vulnerable to future large-scale quantum computers.
- The Edinburgh team's work on proof systems and zero-knowledge arguments has application to the ZK-STARK constructions used in [[Citrea]]'s Bitcoin rollup and Alpen's designated-verifier SNARK for dispute resolution.

#### UCL Centre for Blockchain Technologies — Expressiveness, Privacy, and Policy

- **UCL Centre for Blockchain Technologies (CBT)**, founded 2015 by Paolo Tasca, has ~30 affiliated researchers across UCL Computer Science, Economics, and Law.
- Research on smart-contract expressiveness in UTXO-model blockchains — comparing [[Clarity]] (Stacks), RGB AluVM, and Bitcoin Script expressiveness — provides analytical foundations for understanding the design trade-offs across Layer 3 protocol families.
- DLC security model analysis under oracle-collusion scenarios examines the boundary conditions for DLC security, with practical implications for protocol design in adversarial real-world oracle environments.
- Privacy properties of client-side validation systems — mapping RGB's privacy guarantees against GDPR data minimisation principles — is an emerging area relevant to European institutional adoption.
- UCL CBT's annual DLT Talks conference has hosted LNP/BP Standards Association presentations on RGB Protocol, connecting academic analysis with protocol development.

#### Cambridge Centre for Alternative Finance — Empirical Data and Benchmarking

- **Cambridge Centre for Alternative Finance (CCAF)** (Judge Business School) produces the most authoritative industry-wide empirical surveys of Bitcoin L2/L3 activity.
- The 2024 Global Cryptoasset Benchmarking Study documented 312 listed companies with Bitcoin treasury holdings globally and provided detailed breakdowns of Layer 2/3 protocol usage by geography and use case — the primary empirical data source for industry analysis.
- CCAF's methodology for measuring Bitcoin L2/L3 TVL, developer activity, and node counts has become the reference standard used by regulators, investors, and protocol developers for ecosystem assessment.
- Cambridge Computer Laboratory research on Byzantine fault tolerance, distributed ledger protocols, and cryptographic protocol analysis provides theoretical tools directly applicable to Bitcoin Layer 3 security model analysis.

#### University of Manchester — Distributed Systems and Fintech Commercialisation

- **University of Manchester** (Department of Computer Science) conducts peer-to-peer network security research with relevance to Bitcoin Lightning Network routing and Layer 3 message-passing protocols (Storm, Bifrost).
- Alliance Manchester Business School supports early-stage Bitcoin Layer 3 startup commercialisation, with connections to the Manchester fintech cluster (Tech Manchester, Manchester Digital) and Northern England financial services sector.
- Manchester's strong industry linkages — including the Co-operative Bank, Manchester-headquartered fintech companies, and the Northern Powerhouse investment framework — provide channels for Bitcoin Layer 3 technology transfer into regional financial services.

#### King's College London — Smart Contract Law and Financial Regulation

- **King's College London** (Informatics and King's Centre for Law, Economics and Society) conducts research at the intersection of smart-contract law and Bitcoin Layer 3 protocols.
- Legal research on the enforceability of DLC-based financial derivatives under English law — specifically how adaptor-signature-based conditional payments interact with the English law concepts of consideration, certainty, and enforceability — is increasingly relevant as institutional DLC adoption grows.
- The intersection of UK FCA financial promotion rules, the emerging UK crypto regulation framework (HMT 2024-2025 consultations), and novel Bitcoin Layer 3 constructions (RGB smart contracts, Taproot Assets stablecoins) represents an important open question for institutional adopters that KCL legal researchers are beginning to address.
- Oracle liability under English law — specifically whether an oracle provider bears legal responsibility for incorrect attestations that cause DLC contract mis-settlements — is an emerging legal research question with substantial commercial implications.

### UK Industry and Regulatory Context

#### Financial Conduct Authority (FCA) and HMT Regulatory Framework

- The FCA's cryptoasset promotions regime (Policy Statement PS23/6, effective October 2023) regulates marketing of crypto investments to UK retail investors but does not restrict UK development or use of Bitcoin Layer 3 protocols.
- The FCA Digital Sandbox and Regulatory Sandbox have hosted Bitcoin Layer 3 startups testing novel payment and asset-issuance applications under regulatory supervision with FCA guidance.
- HMT's forthcoming comprehensive crypto regulation (consultation responses 2024-2025, implementation expected 2026-2027) will determine the regulatory treatment of:
  - Tokenised assets issued via [[Taproot Assets]] and [[RGB Protocol]] on Bitcoin — whether these constitute "investment tokens" requiring FCA authorisation
  - [[Stablecoins]] on [[Taproot Assets]] — whether Bitcoin-Lightning-routed USD stablecoins constitute e-money under the UK E-Money Regulations
  - [[DLC]]-based financial derivatives — whether DLCs constitute "investments" under FSMA 2000, triggering conduct-of-business regulation for DLC counterparties
- The Bank of England's Financial Policy Committee has flagged systemic-risk concerns for banks holding crypto but explicitly distinguished non-bank corporate Bitcoin Layer 3 activity as low systemic risk at current scale.

#### UK Bitcoin Layer 3 Startups and Investment Ecosystem

- [[Fulgur Ventures]] (Bitcoin Layer 2/3 focused venture fund, based in London and Europe) is one of the most active institutional investors in the Bitcoin application-layer ecosystem.
- Fulgur investments include Synonym (Lightning + Hypercore decentralised storage, relevant to Storm message-passing underlying RGB Protocol) and Tao (Lightning wallet infrastructure for emerging market stablecoin payments).
- London-based developers contribute to Lightning Network implementations (LND, Core Lightning, Eclair) that form the Layer 2 substrate for [[Taproot Assets]] and [[RGB Protocol]].
- The UK Bitcoin developer community participates in the Bitcoin Optech community, DLC Working Group, and LNP/BP Standards Association — contributing to the open-source standards underlying Bitcoin Layer 3 protocols.
- UK-based institutional investors (family offices, crypto-native hedge funds, fintech VCs based in London) have provided capital to Bitcoin Layer 3 projects including [[Stacks]] ecosystem teams and [[Citrea]] founding investors.

#### Northern England Industrial and Fintech Applications

- **Leeds** (legal and general insurance, First Direct, Yorkshire Building Society) — potential early adopters of Bitcoin-native stablecoin payment rails for cross-border premium collection and claims payment in markets where [[Taproot Assets]] USD stablecoin routes are operational.
- **Manchester** (Tech Manchester, Manchester Digital, Co-operative Bank, AJ Bell, Moneysupermarket) — fintech cluster with growing awareness of Bitcoin Layer 3 applications in SME cross-border payment and insurance product tokenisation.
- **Sheffield** (manufacturing, steel, Forgemasters) — explored tokenised commodity certificates (steel grade certifications, environmental compliance tokens, carbon certificates) as a potential Bitcoin Layer 3 use case via [[RGB Protocol]] non-fungible asset issuance (RGB21 standard).
- **Newcastle** (SAGE Group, Dynamo North East tech cluster, Atom Bank) — growing technology sector providing developer talent for Bitcoin Layer 3 protocol development, with fintech companies exploring Lightning Network payment integration for SME banking products.
- The Northern Powerhouse investment framework and Levelling Up agenda provide institutional context for Bitcoin Layer 3 technology adoption in Northern English industrial SMEs seeking lower-cost cross-border payment rails and supply-chain financing instruments.

## Future Directions (2026-2030)

- The Bitcoin Layer 3 ecosystem trajectory for 2026-2030 will be shaped by four primary drivers: (1) Bitcoin covenant soft-fork proposals potentially enabling native on-chain programmability; (2) ZK-proof system maturation continuing to reduce proof generation costs; (3) stablecoin regulatory clarity enabling large-scale institutional deployment of Bitcoin-native payment rails; and (4) BitVM2 and successor constructions enabling larger and more complex trust-minimised bridge architectures at production scale.
- **Bitcoin covenants (2026-2030 horizon)**: Covenant-enabling soft fork proposals would significantly expand Layer 3 capabilities if activated through the Bitcoin network's social-consensus process.
  - OP_CTV (BIP-119) enables congestion-control templates and covenant trees for efficient payment channel creation without the current requirement for pre-signed transaction sets
  - OP_VAULT (BIP-345) enables self-custodied institutional Bitcoin storage with revocation capabilities — a "vault" that can recover funds if a private key is compromised before a time-lock expires
  - OP_CAT (BIP-347) enables hash-chain contracts, Merkle tree traversal in [[Bitcoin Script]], and composable covenant primitives — the broadest increase in Layer 3 application expressiveness of the three proposals
  - Current community consensus (2026): cautiously supportive of limited proposals but deeply sceptical of broader scripting changes; the Bitcoin soft-fork activation process is deliberately conservative and multi-year
  - If any covenant proposal activates, it would enable a new generation of Layer 3 applications without requiring BitVM-style off-chain computation frameworks, reducing trust assumptions for applications currently requiring Layer 2/3 construction
- **ZK-proof system maturation (2026-2030)**:
  - Proof generation times for ZK-STARKs and recursive SNARKs continue to decrease exponentially through algorithmic improvements (Plonky3, Boojum, FRI-based recursion, RISC-V zkVMs) and hardware acceleration
  - FPGA-based proof acceleration is already reducing [[Citrea]] block proof generation from minutes to seconds in 2026, with custom ASIC development likely by 2028
  - By 2028, real-time ZK proof generation for Bitcoin rollup state transitions projected to be feasible on commodity server hardware, removing proof-generation latency as a user-experience obstacle
  - Client-side ZK proof generation (on mobile devices) projected to be feasible for lightweight proofs by 2029-2030 through hardware acceleration in mobile SoCs, enabling truly decentralised ZK-rollup applications
- **Stablecoin mass adoption on Bitcoin (2026-2030)**:
  - Regulatory frameworks (US GENIUS Act 2025, EU MiCA, UK HMT proposals 2026-2027) will determine whether [[Taproot Assets]] and [[RGB Protocol]] are used for large-scale regulated stablecoin issuance
  - If major regulated issuers (bank-issued stablecoins, e-money institutions) choose Bitcoin [[Lightning Network]] as a settlement rail, the addressable market expands dramatically from crypto-native users to mainstream financial services
  - The critical regulatory question is whether Bitcoin-Lightning stablecoin transfers constitute "payment services" under EU PSD2 / UK PSR frameworks, and whether [[Taproot Assets]] asset issuers require e-money authorisation
  - Multi-trillion-dollar global [[remittance]] markets represent the most immediate commercial opportunity if regulatory clarity is achieved
- **Bitcoin DeFi maturation (2026-2030)**:
  - The BTCFi ecosystem — currently $3B+ TVL — is projected to reach tens of billions in TVL by 2028 as [[sBTC]], [[Citrea]], [[Babylon Protocol]], and successor protocols mature
  - Institutional Bitcoin holders with tens of billions in BTC AUM represent potential BTCFi customers seeking yield without relinquishing custody — the total addressable market is the entire institutional Bitcoin holdings universe
  - The combination of [[Babylon Protocol]] (BTC staking for external chain security), [[Stacks]] sBTC lending, and [[Citrea]] DeFi applications creates a multi-protocol BTCFi landscape with complementary risk profiles
  - Convergence between BTCFi protocols and traditional finance (prime brokers offering BTC-collateralised credit against DLC-secured positions) is a plausible trajectory by 2028-2030
- **AI-Bitcoin integration (2026-2030)**:
  - AI agents capable of autonomous micropayment negotiation over the [[Lightning Network]], with complex conditional payments via [[DLCs]] or [[RGB Protocol]] smart contracts, enable machine-economy business models not possible with conventional payment infrastructure
  - ElizaOS (open-source AI agent framework with Lightning Network integration) has demonstrated AI agents that autonomously pay for API access and computational services in real-time Bitcoin micropayments
  - [[BitVM]] and ZK-rollups enable **verifiable inference** — trustless markets for AI computation where buyers cryptographically verify correct computation without trusting the provider
  - The long-term convergence of AI agent networks and Bitcoin Layer 3 payment/settlement infrastructure represents one of the most significant potential applications of both technologies
- **Protocol convergence and interoperability (2028-2030)**:
  - Current Bitcoin Layer 3 landscape is fragmented across five protocol families that are largely non-interoperable
  - Cross-protocol bridges and shared standards may enable [[Taproot Assets]] assets to be deposited as [[RGB Protocol]] contracts, [[sBTC]] to flow into [[Citrea]] DeFi applications, and [[Ordinals]] to collateralise [[DLC]] loans
  - Shared technical foundations — [[Bitcoin Script]], [[Lightning Network]], [[Taproot]], [[Schnorr signatures]] — across all Layer 3 protocol families suggest standardisation is feasible
  - The LNP/BP Standards Association and Bitcoin Optech community represent the institutional capacity for developing cross-protocol interoperability standards analogous to ERC-20 on [[Ethereum]]

## Research and Literature

- **Primary Protocol Sources**:
- 1. Linus, R. (2023). BitVM: Compute Anything on Bitcoin. Whitepaper, October 2023. https://bitvm.org/bitvm.pdf
- 2. Linus, R., et al. (2025). Bridging Bitcoin to Second Layers via BitVM2. IACR ePrint 2025/1158. https://eprint.iacr.org/2025/1158
- 3. Lightning Labs (2024). Taproot Assets on Lightning: The Global Financial Interoperability Layer. Blog post, July 2024. https://lightning.engineering/posts/2024-07-23-taproot-assets-LN/
- 4. Lightning Labs (2025). Announcing Taproot Assets v0.6: Bitcoin's Decentralised FX Network. Blog post, June 2025. https://lightning.engineering/posts/2025-6-24-tapd-v0.6-launch/
- 5. Lightning Labs (2025). Announcing Taproot Assets v0.7: The Set-and-Forget Asset Layer for Lightning. Blog post, December 2025. https://lightning.engineering/posts/2025-12-16-tapd-0.7-launch/
- 6. LNP/BP Standards Association (2024-2025). RGB Protocol Technical Specifications: RGB Core, RGB Standard Library, AluVM, Storm. https://rgb.tech/
- 7. Rodarmor, C. (2023). Ordinal Theory Handbook. https://docs.ordinals.com/ [Protocol creator's primary documentation for ordinal theory and inscription standard]
- 8. Nakamoto, S. (2008). Bitcoin: A Peer-to-Peer Electronic Cash System. https://bitcoin.org/bitcoin.pdf
- **Academic and Research Papers**:
- 9. Dryja, T. (2018). Discreet Log Contracts. MIT Digital Currency Initiative. [Foundational DLC paper introducing oracle-based conditional Bitcoin contracts]
- 10. Fournier, L. (2020). One-Time Verifiably Encrypted Signatures for PTLCification of DLCs. DLC Working Group. [DLC extension enabling Lightning Network routing via PTLC adaptor signatures]
- 11. Wuille, P., et al. (2020). BIP-340: Schnorr Signatures; BIP-341: Taproot; BIP-342: Tapscript. Bitcoin Improvement Proposals. [Taproot upgrade enabling Taproot Assets, RGB, and Ordinals]
- 12. Poon, J., and Dryja, T. (2016). The Bitcoin Lightning Network: Scalable Off-Chain Instant Payments. https://lightning.network/lightning-network-paper.pdf
- 13. Rubin, J. (2019). BIP-119: CHECKTEMPLATEVERIFY. Bitcoin Improvement Proposal. https://github.com/bitcoin/bips/blob/master/bip-0119.mediawiki
- 14. O'Beirne, J. (2023). BIP-345: OP_VAULT. Bitcoin Improvement Proposal. https://github.com/bitcoin/bips/blob/master/bip-0345.mediawiki
- 15. Back, A., et al. (2014). Enabling Blockchain Innovations with Pegged Sidechains. Blockstream. [Foundational sidechain paper enabling Rootstock and Liquid Network architectures]
- 16. ScienceDirect (2025). Programming on Bitcoin: A Survey of Layer 1 and Layer 2 Technologies in Bitcoin Ecosystem. Science of Computer Programming, 2025. DOI:10.1016/j.scico.2025.003
- **Industry Analysis and Reports**:
- 17. Cambridge Centre for Alternative Finance (2024). Global Cryptoasset Benchmarking Study 2024. University of Cambridge Judge Business School.
- 18. CoinLaw (2025). Layer 3 Blockchain Growth Statistics 2026. https://coinlaw.io/layer-3-blockchain-growth-statistics/
- 19. Bitlayer (2025). First BitVM Bridge Use Case Successfully Executed on Bitcoin Mainnet. Medium, June 2025. https://medium.com/@Bitlayer
- 20. BitVM Alliance (2025). BitVM2: Bridging Bitcoin to Second Layers. Technical whitepaper. https://bitvm.org/bitvm_bridge.pdf
- 21. Stacks (2024). Finally, Finality: Nakamoto Upgrade Sets the Stage for sBTC. https://stacks.org/nakamoto-is-here
- 22. Citrea (2026). Citrea Mainnet: Bitcoin's First ZK-Rollup with ctUSD Stablecoin. Blog post, January 2026. https://www.blog.citrea.xyz/countdown-to-citrea-mainnet/
- 23. GlobeNewswire (2025). RGB20: BitMask Goes Mainnet with RGB Smart Contracts as Tether Prepares to Issue Stablecoins on Bitcoin. 27 November 2025. https://www.globenewswire.com/
- 24. Fairgate Newsletter (2025). Computing on Bitcoin #45: BitVM2 Powers Trustless Bitcoin Bridges with Mainnet Verification. https://www.fairgate.io/newsletter/45/
- 25. Rootstock Foundation (2025). RSK: EVM-Compatible Bitcoin Sidechain — 2025 Ecosystem Update. https://www.rsk.co/
- 26. Bitcoin Optech (2024). Discreet Log Contracts. https://bitcoinops.org/en/topics/discreet-log-contracts/
- 27. hozk (2026). Bitcoin L2s in 2026: A Reality Check. https://www.hozk.io/articles/bitcoin-l2s-in-2026-a-reality-check

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review during Phase 6 enrichment sprint
- **Verification sources**:
  - LNP/BP Standards Association RGB documentation (rgb.tech) — RGB Protocol specifications and AluVM architecture
  - Lightning Labs official blog posts (lightning.engineering/posts) — Taproot Assets v0.4, v0.6, v0.7 announcements
  - BitVM.org whitepaper repository (bitvm.org) and IACR ePrint 2025/1158 — BitVM and BitVM2 specifications
  - Stacks official announcements (stacks.org) — Nakamoto upgrade October 2024, sBTC December 2024
  - Citrea blog (blog.citrea.xyz) and Tapbit analysis — Citrea mainnet January 2026, Clementine bridge architecture
  - Bitcoin Optech topics index (bitcoinops.org) — DLC, PTLC, BIP-119, BIP-345, BIP-347 technical summaries
  - CoinDesk, The Block, Bitcoin Magazine industry reporting — mainnet deployment dates and TVL figures
  - MIT DCI publications, Bitcoin Improvement Proposal index (bips.dev), ScienceDirect — academic citation verification
- **Regional Context covered**:
  - Imperial College CCRE (Lightning routing game theory, formal verification of Layer 2/3)
  - University of Edinburgh BTL (formal methods, post-quantum cryptography, UTXO model analysis)
  - UCL Centre for Blockchain Technologies (smart-contract expressiveness, DLC security models, DLT Talks)
  - Cambridge CCAF (annual benchmarking study, empirical TVL and developer data)
  - University of Manchester (distributed systems, peer-to-peer network security, fintech commercialisation)
  - King's College London (smart-contract law, oracle liability, FCA regulatory analysis)
  - Northern England: Leeds financial services, Manchester fintech cluster, Sheffield manufacturing, Newcastle Dynamo
  - UK regulatory: FCA PS23/6 cryptoasset promotions regime, FCA Digital Sandbox, HMT consultation 2024-2025
- **Domain Correction**: None required — domain correctly set to `blockchain`; legacy-term-id BC-1109 added (following BC-1108 MicroStrategy in sequence); IRI and URI updated to match blockchain ontology pattern.
- **OWL Formal Semantics**: 54 SubClassOf axioms across compositional (10), dependency (9), capability (11), implementation (12), reduction (6) families, plus data property assertions (4), property constraints (3), property characteristics (6), and OWL annotations (4) — 58 total semantic assertions in formal OWL Manchester syntax.
- **Protocol Coverage**: All five major Bitcoin Layer 3 protocol families covered (RGB Protocol, Taproot Assets, BitVM/BitVM2, Stacks, Ordinals/Runes), plus DLCs, Rootstock RSK, and ZK-rollups (Citrea, Merlin Chain, BOB, Alpen) — comprehensive cross-protocol coverage with verified 2024-2026 milestones.
- **Authority Score**: 0.87 — active multi-protocol Bitcoin application layer spanning RGB mainnet November 2025 with Tether USDT integration, Taproot Assets v0.7 December 2025, BitVM2 mainnet fraud-proof verification 2025, Stacks Nakamoto upgrade October 2024 and sBTC December 2024, Citrea ZK-rollup mainnet January 2026, Ordinals ecosystem 70M+ inscriptions $300M+ fees, Runes Protocol April 2024 halving launch.

### Provenance

