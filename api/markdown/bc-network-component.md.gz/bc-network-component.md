Taxonomy category root for Network Component within Blockchain. The concept itself is described at [[Network Component]], which sits under this category; the category exists so the published graph can group its members.

