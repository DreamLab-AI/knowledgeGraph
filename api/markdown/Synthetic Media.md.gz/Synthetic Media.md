Synthetic Media refers to audio, video, image, and text content that is wholly generated or substantially manipulated by computational systems — primarily AI models — rather than captured directly from reality. It encompasses outputs from generative adversarial networks, diffusion models, large language models, neural text-to-speech systems, and neural rendering pipelines, including deepfakes, AI-generated images, cloned voices, and fully synthetic video sequences. The concept spans both creative and malicious applications, from cinematic visual effects and interactive media to disinformation campaigns and identity fraud, making detection, provenance tracking, and regulatory disclosure central concerns. Synthetic media sits at the convergence of generative AI capability, content authenticity infrastructure, and digital governance.

### Overview

- Synthetic media emerged as a distinct concept when generative models reached sufficient fidelity to produce perceptually indistinguishable outputs from real recordings. Early forms — computer-synthesised speech and rule-based image compositing — gave way to deep-learning pipelines that can hallucinate entire video sequences, replicate individual vocal signatures, or generate photorealistic faces of non-existent people.
- Why it matters:
  - The information environment now contains media that cannot be authenticated by human perception alone.
  - Creative industries rely on synthetic media for cost-effective localisation, virtual production, and interactive characters.
  - Malicious actors exploit the same capabilities for identity fraud, non-consensual intimate imagery, and political manipulation.
  - Detection and provenance tooling has become a security-critical infrastructure layer.
- How it works:
  - A generative model is trained on a large corpus of real media, learning a compressed latent representation of the distribution.
  - At inference, the model samples from that distribution — conditioned on a text prompt, reference image, or style signal — and decodes to the target modality.
  - Post-processing steps (upscaling, lip-sync alignment, format encoding) produce a final artefact that may be watermarked or signed for provenance.

### Key Components

- **Generation Modalities**
  - [[Image Generation]] — text-to-image and image-to-image synthesis (e.g., Stable Diffusion, Midjourney, DALL-E).
  - [[Video Generation]] — temporal extension of image synthesis to produce coherent motion sequences (e.g., Sora, Runway, Kling).
  - [[Voice Cloning]] and [[Text-to-Speech]] — reconstruct a speaker's vocal identity from seconds of audio.
  - [[AI-Generated Text]] — large language model outputs including articles, scripts, and conversational agents.
  - [[Avatar Synthesis]] — full-body or head-only digital humans driven by motion capture or pose estimation.
- **Core Generation Architectures**
  - [[Diffusion Model]] — iterative denoising from Gaussian noise; dominant for image and video generation as of 2024.
  - [[Generative Adversarial Network]] — adversarial training between generator and discriminator; widely used for face synthesis and style transfer.
  - [[Large Language Model]] — autoregressive or masked transformer for text and multimodal content.
  - [[Foundation Model]] — large pre-trained base models fine-tuned for specific synthetic media tasks.
- **Enablers**
  - High-quality [[Training Data]] curated from licensed or web-scraped sources.
  - Scalable GPU/TPU compute infrastructure.
  - [[Multimodal Learning]] to bridge text, audio, and visual modalities.
  - Latent diffusion techniques that operate in compressed feature space for efficiency.
- **Detection and Verification**
  - [[Deepfake Detection]] classifiers analysing spatial and temporal inconsistencies.
  - [[Digital Watermarking]] embedded in generated outputs (visible or imperceptible).
  - [[Content Provenance]] metadata trails linking media to its generation context.
  - Forensic artefact analysis (GAN fingerprints, compression traces, unnatural blinking patterns).

### Applications and Use Cases

- **Creative and Commercial**
  - Film and television: virtual de-ageing, facial replacement for stunt doubles, set extension.
  - Advertising: hyper-personalised video ad variants generated at scale.
  - Gaming: procedurally generated NPC dialogue and facial animation via [[Avatar Synthesis]].
  - Education: AI-narrated multilingual versions of educational content.
  - Accessibility: real-time sign-language avatar overlays; on-screen [[Text-to-Speech]] narration.
- **Journalism and Media**
  - Automated video reporting from structured data (sports highlights, financial summaries).
  - Localisation of news anchors via [[Voice Cloning]] for regional language variants.
- **Healthcare and Simulation**
  - Synthetic patient data generation for training medical imaging AI without privacy exposure.
  - Procedural training simulations using photorealistic synthetic environments.
- **Malicious and High-Risk Uses**
  - [[Deepfakes]] for political disinformation and election interference.
  - Non-consensual intimate imagery (NCII) targeting individuals.
  - Voice spoofing for social engineering and financial fraud.
  - Automated generation of [[Disinformation]] content at scale.

### Standards and Governance Context

- **C2PA (Coalition for Content Provenance and Authenticity)**
  - Open technical standard providing cryptographically signed provenance manifests for media files.
  - Adopted by major camera manufacturers (Sony, Nikon, Canon) and content platforms (Adobe, Microsoft, Google).
  - Enables a chain-of-custody audit trail from capture or generation to display.
  - Closely related to [[Content Provenance]] and [[Digital Watermarking]] efforts.
- **EU AI Act**
  - Classifies certain synthetic media generation (deepfakes of real persons in political contexts) as high-risk.
  - Mandates labelling obligations: AI-generated video or audio imitating real persons must be disclosed.
  - Reinforces existing obligations under the Digital Services Act for large platforms.
- **UK Online Safety Act**
  - Creates specific duties around non-consensual intimate imagery generated by synthetic means.
  - Ofcom guidance extends to hosting platforms distributing synthetic content.
- **US Legislation**
  - No unified federal framework as of 2025; a patchwork of state laws (California AB 602, AB 730) and FEC guidance on political deepfakes.
  - DEFIANCE Act (2024) introduces federal civil liability for non-consensual AI-generated intimate images.
- **Industry Self-Regulation**
  - Adobe Content Credentials embeds provenance in files at creation.
  - Meta, Google, and TikTok have committed to labelling AI-generated content under [[AI-Generated Content Disclosure]] norms.
  - Partnership on AI Synthetic Media Framework provides voluntary guidelines for responsible deployment.

### Detection and Authenticity Ecosystem

- [[Deepfake Detection]] relies on:
  - Biological signals — unnatural blinking rate, pulse signal (rPPG) absence in skin pixels.
  - Temporal inconsistency — inter-frame incoherence in compressed video.
  - GAN fingerprinting — spectral artefacts from upsampling layers.
  - Classifier ensembles trained on large deepfake benchmark datasets (FaceForensics++, DFDC).
- [[Digital Watermarking]] approaches:
  - Invisible pixel-space watermarks (Stable Signature, Meta's SynthID).
  - Semantic watermarking embedded in latent space during generation.
  - Limitations: watermarks can be removed via re-encoding or adversarial perturbation.
- [[Content Provenance]] as systemic solution:
  - Provenance bound to media at generation, signed with model-operator credentials.
  - Verification possible by any downstream platform without access to the original model.
  - Requires ecosystem adoption across generation tools, distribution platforms, and browsers.

### Ethical and Societal Considerations

- **Consent and Identity Rights** — [[Voice Cloning]] and face synthesis can violate individuals' right to control their own likeness, raising issues at the intersection of [[Digital Identity]] and privacy law.
- **Epistemic Risk** — the proliferation of convincing synthetic media degrades collective epistemic infrastructure, increasing susceptibility to [[Disinformation]] and eroding trust in documentary evidence.
- **Creative Labour** — synthetic media generation competes with human actors, voice artists, illustrators, and journalists, raising economic displacement concerns.
- **Dual-Use Tension** — the same diffusion model that enables accessible creative tools also lowers the barrier to NCII and influence operations; technical mitigations cannot fully substitute for legal and normative frameworks.
- **[[AI Governance]]** frameworks must balance innovation access with harm prevention, requiring proportionate risk classification rather than blanket prohibition.

### Provenance

