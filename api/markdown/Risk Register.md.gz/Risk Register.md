A risk register is a structured record that captures identified risks together with their description, likelihood, impact, ownership, mitigation actions and current status. It serves as the central artefact of a risk management process, enabling organisations to track, prioritise and report on risks over time. The register supports governance by making risk exposure visible and accountable to decision-makers.

### Overview

- A risk register operationalises risk management by turning abstract concerns into a tracked, prioritised inventory. Each entry typically records a risk identifier, description, cause, likelihood and impact scores, a calculated risk rating, an assigned owner, planned and implemented controls, and a review date. Maintained throughout a project or organisational lifecycle, the register feeds governance reporting, audit evidence and board-level oversight.

### Key aspects

- Structured entries capturing likelihood, impact and risk rating
- Clear ownership and accountability for each identified risk
- Mitigation and contingency actions with tracked status
- Periodic review cadence keeping the register current
- Aggregation and reporting to support governance oversight

### Applications

- Project and programme risk tracking
- Enterprise and operational risk management
- Information-security and cyber-risk governance
- Regulatory compliance and audit evidence
- Board and committee risk reporting

### Provenance

