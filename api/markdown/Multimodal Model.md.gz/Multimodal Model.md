A machine learning model that ingests, aligns, or generates information across two or more modalities — text, images, audio, video, or 3D — within a single architecture, typically by encoding each modality into a shared representation space processed by a transformer backbone. Spanning contrastive dual encoders such as CLIP, text-to-image generators, and natively multimodal frontier models like GPT-4o and Gemini, multimodal models underpin image understanding, cross-modal search, and modern creative tooling.

### Semantic Classification

### Content

## Definition

A **multimodal model** is a neural network trained to relate or generate more than one kind of data — most commonly text and images, increasingly audio, video, and 3D structure as well. The unifying design idea is a shared representation space: each modality is tokenised or encoded by a modality-specific front end (a vision encoder patchifying images, an audio codec discretising waveforms, a text tokeniser), and a [[Transformer]] backbone processes the resulting token streams jointly, learning cross-modal correspondences from paired or interleaved data at web scale.

Three architectural families dominate. *Contrastive dual encoders* such as CLIP train separate image and text towers to embed matching pairs nearby, enabling zero-shot classification and cross-modal retrieval. *Generative bridges* condition a decoder in one modality on encodings of another — text-to-image diffusion systems, image-captioning models, and adapter approaches (Flamingo, LLaVA, BLIP-2) that graft a vision encoder onto a [[Large Language Model]]. *Natively multimodal* frontier models — GPT-4o, Gemini, Claude — are trained from the outset on interleaved multimodal data and handle images, audio and text within one autoregressive context, in some cases generating images and speech as well as consuming them.

Multimodality is what moved foundation models beyond text: document and chart understanding, visual question answering, UI and screenshot comprehension for computer-using agents, audio conversation, and the text-to-image and text-to-video engines inside contemporary [[Creative Tools]]. It is equally central to embodied domains, where vision-language-action models drive robots from camera input and language instructions, and to conditioned generation systems such as ControlNet that steer image synthesis with structural inputs like depth or pose.

## Current Landscape

- **Frontier models**: GPT-4o (native text-image-audio), Gemini (long-context multimodal, video input), and Claude (vision input) define the commercial state of the art; open-weight lines include Llama Vision, Qwen-VL, and LLaVA derivatives.
- **Generation**: diffusion and diffusion-transformer systems (Stable Diffusion, FLUX, Midjourney, DALL-E, and video models such as Sora, Veo and Runway) constitute the generative half of the multimodal landscape.
- **Techniques in flux**: unified any-to-any token spaces, early-fusion versus late-fusion trade-offs, native-resolution vision encoders, and multimodal RLHF for grounding and safety are active research fronts.
- **Evaluation**: MMMU, MathVista, DocVQA and video benchmarks probe multimodal reasoning; hallucinated visual detail and brittle spatial reasoning remain the persistent failure modes.
- **Trajectory**: modality coverage keeps widening (3D, sensor streams, biosignals), and multimodal perception is now assumed infrastructure for agentic systems that operate software and robots rather than a research niche.
- **2025 milestones**: Google's Gemini 2.5 Pro (March 2025) processes text, image, audio and video natively in a 1M-token context (2M announced); Meta's Llama 4 (early 2026) adopts an early-fusion native-multimodal backbone; open-weight Qwen3-VL variants report ~97% on DocVQA, leading document-centric tasks.
- **Evidence base**: the MMMU expert-level benchmark had 61 models evaluated as of early 2026, with top scores around 80% — a marker of how fast joint visual-textual reasoning has advanced while vision-only variants (MMMU-Pro) remain far harder.

  **Sources**:

- https://blog.google/innovation-and-ai/models-and-research/google-deepmind/gemini-model-thinking-updates-march-2025/
- https://www.codegpt.co/blog/ai-coding-models-2025-comprehensive-guide

## Merged from Multimodal Models (needs reconciliation)
Multimodal models are machine learning architectures that jointly process, align, and reason over information from two or more distinct data modalities — such as text, images, audio, video, or depth — within a unified model. They learn shared or bridged representations that enable cross-modal tasks including visual question answering, image captioning, speech recognition conditioned on vision, and text-to-image synthesis. These models extend unimodal foundations (typically large language models or vision encoders) by integrating modality-specific encoders or tokenisers with cross-attention or projection layers that align heterogeneous feature spaces. Multimodal models represent the convergence of natural language processing, computer vision, and speech processing into a single, generalist AI paradigm.

### Overview

- Multimodal models address the fundamental limitation of unimodal systems: the real world is inherently multimodal. Humans perceive and reason with vision, hearing, touch, and language simultaneously; capable AI systems must do the same.
- The core challenge is **representation alignment**: how to map heterogeneous inputs (pixels, waveforms, tokens) into a shared or interoperable feature space where cross-modal relationships can be learnt.
- Three dominant fusion strategies define the design space:
  - **Early fusion**: raw or low-level features from all modalities are concatenated before processing by a shared encoder.
  - **Late fusion**: each modality is processed independently to produce high-level representations, which are then combined at inference time.
  - **Intermediate (cross-modal) fusion**: modality-specific encoders produce mid-level representations that are merged via [[Cross-Attention]] or other learned gating mechanisms — the dominant approach in modern systems.
- The dominant architectural pattern: a large [[Transformer]]-based [[Large Language Model]] backbone receives vision tokens (from a [[Vision Encoder]] such as a [[Vision Transformer]]) via a learned [[Projection Layer]] that maps visual embeddings into the LLM's token space.
- Training typically proceeds in stages: first pre-training individual encoders on large unimodal corpora, then aligning modalities using paired data (image-caption pairs, video-transcript pairs), and finally fine-tuning on instruction-following datasets via [[Instruction Tuning]].

### Key Components

- **Modality-Specific Encoders**
  - [[Vision Encoder]]: processes images or video frames into patch-level or frame-level embeddings (e.g. ViT, EVA-CLIP).
  - Audio encoder: extracts acoustic features using convolutional or transformer architectures (e.g. Whisper encoder).
  - Text encoder: a [[Tokeniser]] and [[Embedding Layer]] from a pre-trained [[Large Language Model]].
- **Alignment and Fusion Mechanisms**
  - [[Contrastive Learning]] (e.g. [[CLIP]]): maps image and text encoders into a shared embedding space using contrastive objectives, so similar pairs are close and dissimilar pairs are far apart.
  - [[Cross-Attention]]: allows tokens from one modality to attend to representations from another, enabling fine-grained alignment without collapsing modality-specific detail.
  - [[Projection Layer]] (linear or MLP): translates the output of a vision encoder into the token space of a language decoder.
  - Q-Former (Querying Transformer): a lightweight bridging module (used in BLIP-2) that queries a frozen image encoder with learned query tokens before passing to the LLM.
- **Decoder or Generator**
  - Autoregressive language decoder: generates text (captions, answers, descriptions) token by token, conditioned on multimodal context.
  - [[Diffusion Models]] decoder: generates images from text embeddings (used in [[Stable Diffusion]], DALL·E 3).
  - Interleaved generation heads: some systems can generate both text and images in a single autoregressive sequence (e.g. Chameleon).
- **Training Data**
  - Aligned or paired data is essential: image-text pairs, video-transcript pairs, audio-description pairs.
  - [[Self-Supervised Learning]] techniques (masked image modelling, masked language modelling) reduce reliance on explicit labels.
  - Web-scale data curation (e.g. LAION, DataComp) provides billions of weakly supervised pairs.

### Applications and Use Cases

- **Document understanding**: parsing PDFs, charts, tables, and mixed-media documents that combine text and visual layout.
- **Medical imaging**: correlating clinical notes with radiological scans, pathology slides, or ultrasound video for diagnosis support.
- **Robotics and embodied agents**: grounding natural language instructions in visual observations to drive manipulation or navigation — see [[Embodied AI]] and [[Robotic Manipulation]].
- **Accessibility**: automatic image descriptions for screen readers; real-time sign-language video to text transcription.
- **Content generation**: [[Text-to-Image]] synthesis, video generation from text prompts, music composition from visual mood boards.
- **Search and retrieval**: [[Multimodal Retrieval]] systems (cross-modal search — find images with text queries, or find text passages relevant to an image).
- **Autonomous vehicles**: fusing camera, LiDAR, radar, and map data for scene understanding — see [[Sensor Fusion]].
- **Education and tutoring**: interpreting student-drawn diagrams or hand-written equations alongside textual explanation.
- **Spatial computing and AR/VR**: understanding and annotating 3D scenes in real time via [[Spatial Computing]] integration.
- **Human-computer interaction**: natural conversation interfaces that accept speech, images, and typed queries simultaneously.

### Prominent Architectures

- **CLIP** (OpenAI, 2021): contrastive image-text pretraining; foundational alignment model for the field.
- **DALL·E / DALL·E 3** (OpenAI): text-to-image using diffusion with CLIP-based conditioning.
- **Flamingo** (DeepMind, 2022): few-shot visual language model using cross-attention gating between frozen vision and language encoders.
- **BLIP / BLIP-2** (Salesforce): bootstrapped language-image pretraining; introduced the Q-Former bridge.
- **GPT-4V / GPT-4o** (OpenAI): proprietary large multimodal model accepting image and audio inputs alongside text.
- **LLaVA** (Liu et al., 2023): open-source visual instruction tuning; simple projection layer between CLIP ViT and Vicuna LLM.
- **Gemini** (Google DeepMind): natively multimodal architecture trained jointly on text, image, audio, and video from the outset.
- **Chameleon** (Meta): early-fusion token-based multimodal model generating interleaved image and text sequences.
- **InternVL / InternLM-XComposer**: competitive open-weight vision-language models from the Chinese AI ecosystem.

### Standards and Context

- No single governing standards body controls multimodal model design; the field evolves through open research publication and de facto community standards.
- **Benchmarks** effectively set evaluation standards:
  - VQA v2, GQA: visual question answering.
  - COCO Captions: image captioning.
  - MMBench, MMMU: comprehensive multimodal understanding.
  - SEED-Bench: multi-granularity evaluation of large multimodal models.
- **Ethics and safety**: multimodal models inherit and amplify risks from both language and vision modalities — hallucination of visual content, generative misuse (deepfakes, CSAM), bias from web-scraped training data. Organisations including Anthropic, OpenAI, and Google have published model cards and responsible use guidelines.
- **Evaluation challenge**: assessing cross-modal reasoning requires richer metrics than unimodal benchmarks; human evaluation and adversarial probing remain important complements to automated scores.
- **Data governance**: large-scale web-scraped paired datasets (LAION, WIT) have raised copyright and consent questions, driving interest in [[Synthetic Data]] generation and licensed data pipelines.
- Relevant research venues: NeurIPS, ICML, ICLR, CVPR, ECCV, ACL, EMNLP.

### Provenance

