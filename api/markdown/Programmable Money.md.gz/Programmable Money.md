Programmable Money is a form of digital currency in which the conditions governing the creation, transfer, and use of monetary units are encoded as executable logic—typically within smart contracts on a public or permissioned blockchain—and enforced autonomously without requiring trusted intermediaries. This enables payment instruments that can embed compliance rules, spending constraints, vesting schedules, or multi-party approval workflows directly into the currency itself, transforming money from a passive bearer instrument into an active, self-enforcing contractual construct. Central bank digital currencies (CBDCs), tokenised commercial bank deposits, DeFi stablecoins, and protocol-native assets are all instances of programmable money at different points on the decentralisation and trust spectrum. The paradigm extends the concept of money from a static store of value and medium of exchange into a substrate for encoding and automating financial relationships.

### Overview

- Programmable money sits at the intersection of monetary theory, computer science, and financial regulation. The core insight is that a monetary unit need not be a dumb integer in a ledger — it can carry executable metadata that governs its own lifecycle.
- The concept predates blockchain: prepaid cards with merchant-category restrictions and earmarked welfare vouchers are analogue predecessors. What blockchain and [[Smart Contract]] infrastructure add is trustless enforcement: no central party needs to police the rules because the code does so automatically on every transfer.
- Three major design axes define the design space:
  - **Centralisation vs. decentralisation**: [[Central Bank Digital Currency]] are issued and revocable by a central bank; DeFi tokens are governed by protocol rules and on-chain [[Decentralized Autonomous Organisation]] votes.
  - **Programmability of money vs. programmability of payments**: restricting what the money can buy (money-level programmability) is more controversial than conditional payment triggers such as [[Delivery Versus Payment]] in securities settlement (payment-level programmability).
  - **Privacy**: programmable rules require enforcement visibility, which creates tension with [[Financial Privacy]] expectations and GDPR-style data-protection frameworks.
- Why it matters:
  - Enables complex financial arrangements without legal intermediaries or escrow agents.
  - Allows regulators to encode AML/KYC compliance directly into the currency.
  - Supports novel monetary policy instruments such as time-limited stimulus money or negative interest rates enforced at the token level.
  - Powers [[Machine Economy]] micro-payment rails for autonomous agents and IoT devices.

### Key Mechanisms

- **Token Standards**: [[Token Standard]]s such as ERC-20, ERC-1155, and ERC-3643 (the security-token standard) define the interface contract that wallets, exchanges, and DeFi protocols use to interact with programmable money. Role-based access control and upgradeable proxy patterns allow rule modification by authorised issuers or regulatory bodies post-deployment.
- **Smart Contract Enforcement**: A [[Smart Contract]] overrides the default transfer function to check conditions — allow-lists, transfer caps, time locks, spending categories — before any token movement is finalised on-chain. Failures revert atomically, preventing partial execution.
- **Oracles**: Off-chain data (FX rates, proof-of-delivery, compliance flags) must be injected via [[Blockchain Oracle]]s (e.g. Chainlink, Pyth) to enable condition evaluation that depends on real-world state.
- **Tokenisation**: [[Tokenisation]] of real-world assets (real estate, invoices, securities) creates tokenised deposits and collateral that can be programmatically locked, released, or rebalanced without manual settlement.
- **Consensus Mechanism**: The underlying [[Consensus Mechanism]] (Proof-of-Work, Proof-of-Stake, or BFT variants for permissioned ledgers) determines finality guarantees, throughput, and energy cost — all of which constrain the practical design of programmable money systems.
- **Cryptographic Guarantees**: [[Cryptographic Hash Function]]s and digital signatures provide the authenticity and integrity assurances that allow code-enforced rules to be trusted without a central authority.
- **Atomic Swaps**: [[Atomic Swap]] primitives allow cross-chain, cross-currency exchanges to complete or revert atomically, enabling composable programmable money flows across heterogeneous ledgers.

### Applications and Use Cases

- **Central Bank Digital Currencies (CBDCs)**
  - Retail CBDCs (consumer-facing) may embed spending-category limits (e.g. stimulus funds restricted to domestic merchants), expiry dates to stimulate velocity, or interest-rate policies applied at token level.
  - Wholesale CBDCs target interbank settlement, particularly [[Delivery Versus Payment]] for securities and cross-border payment corridors (Project mBridge, Project Dunbar).
  - Permissioned distributed ledger platforms (Corda, Hyperledger Fabric) are the typical substrate for wholesale CBDC pilots to preserve privacy and throughput.
- **Stablecoins**
  - Fiat-collateralised [[Stablecoin]]s (USDC, EURC) encode redemption and blacklisting logic that allows issuers to freeze sanctioned addresses — an expression of regulator-compliant programmability.
  - Crypto-collateralised stablecoins (DAI, LUSD) encode autonomous liquidation mechanisms that trigger when collateral ratios breach thresholds without human intervention.
  - Algorithmic stablecoins attempt to encode supply expansion and contraction entirely in protocol logic, with mixed track records (Terra/UST collapse illustrating the risks of reflexive algorithmic mechanisms).
- **Decentralised Finance Protocols**
  - [[Automated Market Maker]]s (Uniswap, Curve) encode liquidity provision and price discovery entirely in smart contracts, with trading fees distributed automatically to liquidity providers.
  - Lending protocols (Aave, Compound) encode collateralisation ratios and automated liquidation, enabling permissionless credit markets with no loan officers.
  - Liquidity mining and token vesting schedules distribute protocol ownership over time according to immutable or governance-upgradeable rules.
- **Supply Chain Finance**
  - Programmable escrow releases payment upon receipt of validated [[Internet of Things]] sensor data confirming delivery, temperature compliance, or quality certification — bridging physical logistics with on-chain settlement.
- **Machine Economy and Agent Payments**
  - Autonomous [[Multi-Agent Systems]] and IoT devices can hold and spend programmable money wallets for micro-transactions (streaming payments for API calls, bandwidth, or compute) without human authorisation loops. This is foundational infrastructure for the [[Machine Economy]].
- **Regulated DeFi**
  - Hybrid architectures combine central-bank issued digital liabilities with DeFi composability: the underlying token enforces KYC/AML at transfer level while still being usable in open lending or DEX protocols. BIS Innovation Hub projects and various regulatory sandboxes are actively exploring this design space.

### Standards and Governance Context

- **Token Standards**: Ethereum ERC-20 (fungible), ERC-721 (non-fungible), ERC-1155 (multi-token), ERC-3643 (regulated securities tokens with on-chain identity checks).
- **BIS and Central Banks**: The Bank for International Settlements (BIS) Innovation Hub coordinates CBDC pilots globally. Project mBridge (multi-CBDC corridor for cross-border payments) and Project Mariana (DeFi AMM for FX settlement) are live experiments.
- **FATF Guidance**: The Financial Action Task Force (FATF) Travel Rule requires virtual asset service providers to transmit sender and recipient identity data alongside transfers, complicating pseudonymous programmable money flows.
- **MiCA (Markets in Crypto-Assets Regulation)**: The EU MiCA framework (2024 implementation) creates regulatory categories for e-money tokens and asset-referenced tokens, imposing reserve, disclosure, and operational requirements that constrain how stablecoin programmability can be structured.
- **ISO 20022**: The ISO 20022 financial messaging standard is being adopted by SWIFT and central banks for richer payment data, and is viewed as the structured-data layer that programmable CBDC payment systems will need to align with.
- **W3C DID / Verifiable Credentials**: [[Digital Identity]] infrastructure based on W3C Decentralised Identifiers and [[Verifiable Credential]] is increasingly positioned as the identity layer that satisfies KYC requirements for programmable money without exposing raw personal data on-chain.
- **Privacy Tension**: Zero-knowledge proof systems (zk-SNARKs, zk-STARKs) are being integrated into CBDC and stablecoin designs to allow proof of rule compliance without revealing transaction details — a research-active frontier.

### Risks and Criticisms

- **Surveillance risk**: Money that can be conditionally restricted is money that can be conditionally confiscated or frozen. Retail CBDCs with spending restrictions raise significant civil liberties concerns about financial surveillance and state control of purchasing behaviour.
- **Code risk**: Smart contract bugs can result in permanent loss of funds or unintended rule violations. Unlike legal contracts, on-chain code may be immutable once deployed, making remediation difficult.
- **Regulatory arbitrage**: Permissionless programmable money protocols can be used to circumvent jurisdiction-specific regulations, creating enforcement challenges for AML/CFT regimes.
- **Algorithmic instability**: Fully algorithmic monetary policies (as in algorithmic stablecoins) have repeatedly demonstrated fragility under adversarial market conditions, where the automated rules themselves can create destabilising feedback loops.
- **Interoperability fragmentation**: Proliferation of incompatible token standards and ledger platforms risks fragmenting liquidity and increasing systemic complexity, countering the efficiency gains programmability promises.

### Current Landscape (2026)

- The US GENIUS Act (Public Law 119-27) was signed on 18 July 2025, creating the first federal framework for payment stablecoins; issuers must hold 1:1 reserves in cash and short-dated Treasuries, are barred from paying yield, and fall under the Bank Secrecy Act. Federal regulators (OCC, FDIC, NCUA, Treasury/FinCEN/OFAC) issued implementing proposals through early 2026, with rules due by 18 July 2026 and the Act taking effect on 18 January 2027.
- Regulators are drawing a sharp line between programmable payment stablecoins (no interest, no pass-through deposit insurance) and tokenised bank deposits, which can pay yield and inherit FDIC insurance; the FDIC's April 2026 proposal confirmed deposit insurance is technology-neutral so tokenised deposits qualify if they meet the statutory definition of a deposit.
- The EU's MiCA regulation reached full application, with its stablecoin (ART/EMT) regime live since 30 June 2024 and the CASP licensing regime since 30 December 2024; by November 2025 over 53 CASP licences had been granted, and the European Commission opened a MiCA review consultation in May 2026 (closing 31 August 2026), partly to address tokenised real-world assets under Title V.
- Wholesale programmability advanced via central bank rails: the ECB will launch Project Pontes, its DLT-to-TARGET bridge for settling tokenised transactions in central bank money, in Q3 2026 (targeting roughly 10 transactions per second), with the longer-horizon Appia initiative exploring the broader tokenised ecosystem and an "enhanced" Pontes product possible by 2028.
- The retail digital euro moved to its next phase in October 2025 after the preparation phase closed; contingent on EU legislation being adopted in 2026, a pilot could start in 2027 with potential first issuance in 2029, at an estimated 1.3 billion euro development cost.
- Market infrastructure is consolidating around compliance-embedded token standards such as ERC-3643 (T-REX), which builds identity, access control and transfer rules directly into tokens, while Swift's blockchain shared-ledger initiative (announced September 2025) completed its design phase in March 2026 and began building its first iteration.
- Adoption is globalising fast, with Hong Kong's stablecoin regime effective 1 August 2025, the UAE's Payment Token Services Regulation in full effect from mid-2025, and Japan, Korea and the UK advancing issuer rules; open challenges as of 2026 include reserve run-risk during stress, preserving the "singleness of money" across private and public forms, cross-border and multi-issuance interoperability, and privacy-preserving compliance for programmable transfers.

### References

- 1. Morgan Lewis (2026). GENIUS Act Implementation: Key Proposals and What Comes Next. https://www.morganlewis.com/pubs/2026/04/genius-act-implementation-key-proposals-and-what-comes-next
- 2. Brookings Institution — Liang & Dudley (2026). Next steps for GENIUS payment stablecoins. https://www.brookings.edu/articles/next-steps-for-genius-payment-stablecoins/
- 3. Federal Deposit Insurance Corporation (2026). Notice of Proposed Rulemaking to Establish GENIUS Act Requirements. https://www.fdic.gov/news/financial-institution-letters/2026/notice-proposed-rulemaking-establish-genius-act
- 4. European Central Bank (2026). The Eurosystem's comprehensive payments strategy. https://www.ecb.europa.eu/press/pubbydate/2026/html/ecb.eurosystemcomprehensivepaymentsstrategy202603.en.html
- 5. European Central Bank (2026). Pontes. https://www.ecb.europa.eu/paym/target/pontes/html/index.en.html
- 6. TRM Labs (2025). Global Crypto Policy Review Outlook 2025/26. https://www.trmlabs.com/reports-and-whitepapers/global-crypto-policy-review-outlook-2025-26

### Provenance

