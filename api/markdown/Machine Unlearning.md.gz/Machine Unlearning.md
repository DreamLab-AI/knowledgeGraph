A family of techniques for removing the influence of specific training examples from an already-trained machine learning model without retraining it from scratch, so that the resulting model behaves as if the deleted data had never been seen; motivated by privacy law (the right to erasure), copyright disputes, data poisoning remediation, and the removal of hazardous capabilities from foundation models.

### Semantic Classification

### Content

## Definition

**Machine unlearning** inverts the usual direction of training: instead of adding knowledge to a model, it removes the statistical influence of chosen training examples. The gold standard — exact unlearning — is retraining from scratch on the dataset minus the deleted records, but for large models this is prohibitively expensive. Practical research therefore centres on approximate unlearning: gradient-ascent "forgetting" steps, influence-function corrections, sharded and sliced training (SISA) that confines each example's influence to a retrainable shard, and certified unlearning methods that bound the divergence between the unlearned model and a genuine retrain.

The motivations are legal as much as technical. Data protection regimes such as the UK GDPR grant individuals a right to erasure, and regulators have signalled that a model trained on unlawfully processed data may itself be tainted — the US FTC has ordered "algorithmic disgorgement", the deletion of models built on improperly obtained data. Legislative proposals on frontier AI, including California's AI bills, have raised expectations that developers can excise specific data or capabilities on demand. Unlearning also serves safety engineering: removing memorised personal data, copyrighted passages, or dual-use knowledge (for example biosecurity-relevant content) from foundation models.

Machine unlearning is conceptually paired with [[Continual Learning]]: continual learning fights unwanted catastrophic forgetting, while unlearning induces targeted, verifiable forgetting on demand. The two share machinery — both must reason about how individual experiences shape weights — and mature deployment pipelines increasingly need both.

## Current Landscape

Benchmarks such as TOFU, WMDP, and MUSE now anchor evaluation of unlearning in large language models, measuring whether forget-set knowledge is gone, whether retained capability survives, and whether "relearning" attacks can resurrect the removed content. Results are sobering: many published methods suppress rather than remove knowledge, and fine-tuning on a few related examples often restores it. Verification remains the open problem — proving a model has forgotten is harder than making it appear to forget.

Dated markers of the field's state:

- **Unified evaluation arrived in 2025**: OpenUnlearning (NeurIPS 2025 Datasets & Benchmarks) unifies the TOFU, MUSE and WMDP benchmarks with 13 unlearning algorithms, 16 evaluation metrics (including six membership-inference attacks), and 450+ publicly released model checkpoints; its meta-evaluation found method rankings highly sensitive to experimental design, with SimNPO the strongest performer on TOFU.
- **Relearning attacks confirmed as the weak point**: ICLR 2025 work showed that finetuning an "unlearned" model on a small subset of the forget data — or even auxiliary public data — recovers supposedly removed content across WMDP, TOFU and Who's-Harry-Potter settings, and NeurIPS 2025 work demonstrated data extraction attacks that double success rates even after *exact* unlearning of the target records.
- **Robustness progress**: the UNDO distillation approach (NeurIPS 2025) showed that distilling an unlearned model into a fresh student matches the relearning-robustness of full retraining at 60-80% of the compute — one of the first methods to close the suppression-versus-removal gap.
- **Regulatory pull sharpened**: the EU AI Act's GPAI obligations (applicable from 2 August 2025) require documented training-data governance and copyright compliance, while UK GDPR erasure rights and US FTC algorithmic-disgorgement orders continue to assume deletion capabilities that current approximate methods cannot yet certify.

  Research directions include unlearning in federated settings (where the data holder never shared raw records), certified deletion with differential-privacy-style guarantees, and capability-level unlearning for frontier model safety cases. The field is young but moving quickly, pulled by the widening gap between what privacy and AI regulation assumes is possible and what current techniques reliably deliver.

  **Sources**:

- https://github.com/locuslab/open-unlearning
- https://papers.neurips.cc/paper_files/paper/2025/file/3e4a38f228427ab819ba7899003a44b1-Paper-Datasets_and_Benchmarks_Track.pdf
- https://proceedings.neurips.cc/paper_files/paper/2025/file/800981b7bff06c3feb88c65cc712ba2b-Paper-Conference.pdf
- https://proceedings.iclr.cc/paper_files/paper/2025/file/18fd48d9cbbf9a20e434c9d3db6973c5-Paper-Conference.pdf

### Provenance

