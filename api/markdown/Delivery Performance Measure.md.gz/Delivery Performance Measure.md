A delivery performance measure expresses how reliably a supply chain delivers to customers against the quantity and schedule that were agreed.[^1][^2]

McKinsey describes the consumer industry as moving away from the traditional case-fill rate towards the on-time in-full metric, which measures the extent to which shipments are delivered to their destination according to both the quantity and the schedule specified on the order.[^1] SCOR 12.0 lists three delivery-related metrics under its reliability attribute: Perfect Order Fulfillment at level 1, and % of Orders Delivered In Full and Delivery Performance to Customer Commit Date at level 2.[^2] Gunasekaran, Patel and Tirtiroglu name delivery performance as one of the groups of measures that their metric list emphasises, with suppliers, customer service and inventory and logistics costs.[^3]

## Measures covered here

[[On-Time In-Full]] combines timeliness and completeness in one figure. [[Fill Rate]] in the inventory literature is the long-range average fraction of demand delivered from inventory on the shelf, which is a measure of stock availability.[^4] McKinsey's reference to a traditional case-fill rate shows that fill rates have also been used as delivery measures in the consumer sector.[^1] The two answer different questions, one about the order and one about the demand served from stock.

## Scope and distinctions

This page sits under [[Supply Chain Performance Measure]]. Delivery measures differ in what counts as a delivery, which date applies, and at which level completeness is judged. McKinsey lists three such choices for on-time in-full: the date requested by the retailer or promised by the manufacturer, a specific delivery slot or a broader window, and complete orders, line items or individual cases.[^1]

## What the sources do not establish

SCOR is cite-only and the guide opened gives only the metric names, so this page does not state how those metrics are calculated. No source opened provides a single definition of delivery performance, and McKinsey says there is no standard definition of on-time in-full.[^1][^2]

[^1]: McKinsey & Company (Alan Davies, Shruti Lal, Fernando Perez and Sanjhali Potdar), “Defining ‘on-time, in-full’ in the consumer sector”, 13 June 2019 (Internet Archive copy). https://web.archive.org/web/2024/https://www.mckinsey.com/capabilities/operations/our-insights/defining-on-time-in-full-in-the-consumer-sector
[^2]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf
[^3]: A. Gunasekaran, C. Patel and E. Tirtiroglu, International Journal of Operations and Production Management 21(1-2), 2001 (Penn State record, abstract only), “Performance measures and metrics in a supply chain environment”. https://pure.psu.edu/en/publications/performance-measures-and-metrics-in-a-supply-chain-environment/
[^4]: Georgia Institute of Technology (Marc Goetschalckx), “Chapter 5. Inventory Systems”, Logistics Systems Design. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf

