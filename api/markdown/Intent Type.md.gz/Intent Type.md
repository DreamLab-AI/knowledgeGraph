
An intent type categorises an [[Agent Intent]]. The Agent Ontology declares it as `IntentType` in the intent module, with the comment "Categorizes an intent (e.g., fetch-data, make-decision, generate-artifact)."[^1]

An intent selects its type through the `hasIntentType` property, whose domain is `Intent` and whose range is `IntentType`. The three examples in the comment are illustrations, and the ontology declares no fixed list of types, so the set of categories is left open to whoever uses the vocabulary.[^1]

The class parallels [[Action Type]], which categorises an [[Agent Action]] in the same module. The ontology does not relate the two by subclassing or by property, so an intent's type and the type of the action it produces are linked only by the action and intent themselves.

[^1]: Semantic Agent Communication Community Group, “Intent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/intent.ttl

