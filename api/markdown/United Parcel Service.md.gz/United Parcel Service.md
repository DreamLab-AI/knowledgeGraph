United Parcel Service (UPS) is a package delivery and logistics company. Its own site says that the story of UPS, which it calls the world's largest package delivery company, began more than a century ago with a $100 loan to jumpstart a tiny messenger service, and that it serves 200+ countries and territories.[^1] The European Commission described UPS in a 2013 decision as one of the world's largest logistics providers that operates mainly in the small package delivery, freight transport and contract logistics sectors.[^2]

## Independent description

The Industrial Ontologies Foundry lists UPS with FedEx and DHL as an example of an integrated carrier business organisation, one created to provide different types of transportation and freight forwarding services.[^3] The Commission decision of 2013 concerned UPS's proposed takeover of TNT Express and declared the concentration incompatible with the internal market, as its title and subject show.[^2]

That decision also states that UPS started operating in Europe in 1976 by establishing operations in Germany.[^2]

## Role in the supply chain

UPS is a [[Parcel Carrier]] in this vault, because small package delivery is the first activity in the Commission's description of its operations.[^2] Its freight transport and contract logistics activities also place it among [[Logistics Service Provider]] roles.[^2][^3]

## What the sources do not establish

Its phrase “world’s largest” is the company's own claim, and no independent ranking was opened. The Commission's description gives a turnover figure that is not repeated here, and the sources give no founding place, headquarters or current volumes. The decision text opened is long, and its reasoning is not summarised here.[^1][^2]

[^1]: UPS, “Our Company” page. https://about.ups.com/us/en/our-company.html
[^2]: European Commission, Case COMP/M.6570 UPS / TNT Express, decision of 30 January 2013. https://ec.europa.eu/competition/mergers/cases/decisions/m6570_20130130_20610_4241141_EN.pdf
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

