Human rights due diligence is the ongoing process by which a business enterprise identifies, prevents, mitigates and accounts for how it addresses its adverse impacts on human rights.[^1]

The UN Guiding Principles set it out in principle 17: in order to identify, prevent, mitigate and account for how they address their adverse human rights impacts, business enterprises should carry out human rights due diligence.[^1] The process should include assessing actual and potential human rights impacts, integrating and acting upon the findings, tracking responses, and communicating how impacts are addressed.[^1] It follows from the corporate responsibility to respect human rights, which requires enterprises to avoid causing or contributing to adverse human rights impacts through their own activities and to address such impacts when they occur.[^1]

## Development in law

Directive (EU) 2024/1760 records that the concept of human rights due diligence was specified and further developed in the OECD Guidelines for Multinational Enterprises, which extended the application of due diligence to further areas.[^2] The Directive makes the process a legal duty for covered companies, together with environmental due diligence; see [[Supply Chain Due Diligence Instrument]].

A different design is the transparency statement of the UK Modern Slavery Act 2015. Section 54 requires a commercial organisation within its scope to prepare a slavery and human trafficking statement for each financial year, setting out the steps taken during the year to ensure that slavery and human trafficking is not taking place in its supply chains or its own business, or stating that it has taken no such steps.[^3] The statement may include information on due diligence processes.[^3]

## Scope and limits

Human rights due diligence is the human rights part of [[Supply Chain Due Diligence]]. The sources opened do not measure its effect on rights holders, and the Modern Slavery Act duty is one of disclosure; an organisation may state that it has taken no steps. The Guiding Principles and the Directive are different kinds of instrument: principles issued under the United Nations, and a legal act of the European Union.

[^1]: United Nations Office of the High Commissioner for Human Rights, HR/PUB/11/4, 2011, “Guiding Principles on Business and Human Rights: Implementing the United Nations “Protect, Respect and Remedy” Framework”. https://www.ohchr.org/sites/default/files/documents/publications/guidingprinciplesbusinesshr_en.pdf
[^2]: European Parliament and Council of the European Union, Directive (EU) 2024/1760 of 13 June 2024, “Directive (EU) 2024/1760 of the European Parliament and of the Council on corporate sustainability due diligence”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202401760
[^3]: UK Parliament, Modern Slavery Act 2015, section 54, “Modern Slavery Act 2015, section 54: Transparency in supply chains etc”. https://www.legislation.gov.uk/ukpga/2015/30/section/54

