A trade measure is a policy instrument that affects the flow of goods across a border, whether a tariff or a non-tariff measure.[^1][^2]

The WTO uses market access for goods to mean the conditions, tariff and non-tariff measures, agreed by members for the entry of specific goods into their markets, and says non-tariff measures are dealt with under specific WTO agreements.[^1] Tariffs are customs duties on merchandise imports, and members have listed commitments to cut and bind tariffs on goods schedules that are part of the Uruguay Round Agreements.[^2] Bound tariff rates are one kind of agreed measure.[^2] See [[Customs Duty]].

## Measures in the EU and UK texts

The Union Customs Code defines commercial policy measures as non-tariff measures established, as part of the common commercial policy, in the form of Union provisions governing international trade in goods.[^3] The European Commission separates these from prohibitions and restrictions, the requirements customs enforce at the external border under sectoral EU policies, noting that commercial policy measures are not prohibitions and restrictions even though implementing them is part of customs supervision.[^4] Release for free circulation entails the application of both, insofar as they have not had to be applied at an earlier stage.[^3]

GOV.UK says the Trade Tariff tool helps check whether goods are covered by agricultural policy, anti-dumping duties, UK safeguarding measures or tariff quotas.[^5]

## Evidence limits

No opened source defines the phrase trade measure itself; this page is bounded by the WTO's tariff and non-tariff distinction and by the EU and UK lists above. Export controls and sanctions are not covered by the passages read here.[^1][^3][^5]

[^1]: World Trade Organization, “WTO | Market access for goods - gateway”. https://www.wto.org/english/tratop_e/markacc_e/markacc_e.htm
[^2]: World Trade Organization, “WTO | Tariffs”. https://www.wto.org/english/tratop_e/tariffs_e/tariffs_e.htm
[^3]: European Parliament and Council, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code (recast)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^4]: European Commission, “Prohibitions & Restrictions - European Commission”. https://taxation-customs.ec.europa.eu/customs/prohibitions-restrictions_en
[^5]: HM Revenue and Customs, “Finding commodity codes for imports into or exports out of the UK - GOV.UK”. https://www.gov.uk/guidance/finding-commodity-codes-for-imports-or-exports

