A distribution centre is a warehouse-type facility that serves as the last stop before a product is shipped to a wholesaler, retailer or end-user.[^1]

An eCampusOntario logistics text says distribution centers tend to be located close to the market and that Amazon calls its comparable facilities fulfillment centers, noting that the name a company chooses for its warehouses may vary.[^1] Georgia Tech's open textbook describes a retail distribution center as one that typically supplies product to retail stores, such as Walmart or Target, and names service parts and e-commerce distribution centers as other kinds.[^2] It also treats the distribution centre as an intermediate aggregator: with many vendors and stores, routing through a distribution centre or crossdock replaces many small direct shipments with fewer, larger ones.[^2]

## Loose use of the term

A US Census Bureau committee reviewing the classification of distribution centers says the term is applied to a wide variety of establishments performing very different activities, and that warehouse and cross-docking facility are other terms for these units. It recommended that units collecting, storing and distributing goods to affiliated retail locations be classified under Warehousing and Storage, and avoided the term distribution center in the classification.[^3]

## Scope and distinctions

A fulfilment centre is a distribution centre that fills small individual orders; see [[Fulfilment Centre]]. A distribution centre is a [[Warehouse Facility Type]] and sits in the [[Warehousing and Distribution]] branch. Cross-docking, in which goods move between trucks with no storage, is a related activity covered at [[Cross-Docking]].[^1]

Sources use distribution center, fulfillment center and warehouse close together. This corpus keeps the distribution centre as the general page and treats the others as specialisations or alternative names, a choice the sources do not make for it.[^1][^3]

## What the sources do not establish

No source gives a size, throughput or location rule that separates a distribution centre from a warehouse.

[^1]: eCampusOntario Pressbooks (Introduction to Logistics), “Chapter 5 – Warehousing”. https://ecampusontario.pressbooks.pub/logistics001oerfc/chapter/chapter-5-warehousing/
[^2]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^3]: US Census Bureau, Economic Classification Policy Committee, “Recommendation for Classification of Distribution Centers in North American Industry Classification System (NAICS) Revisions for 2012”. https://www2.census.gov/library/reference/naics/federal-register/supporting/distribution_centers.pdf

