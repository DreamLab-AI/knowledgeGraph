E-Commerce (electronic commerce) is the commercial exchange of goods, services, and information conducted over digital networks, encompassing business-to-consumer (B2C), business-to-business (B2B), consumer-to-consumer (C2C), and direct-to-consumer (D2C) transaction models. It relies on integrated layers of digital payment infrastructure, identity and authentication, logistics coordination, and data-driven personalisation to operate at scale. Modern e-commerce platforms leverage cloud infrastructure, recommendation engines, and APIs to connect buyers, sellers, and fulfilment networks globally. It is a mature commercial domain that continues to evolve through mobile-first experiences, conversational commerce, and blockchain-based payment rails.

### Overview

- E-Commerce emerged in the mid-1990s with early platforms enabling consumers to browse and purchase goods via web browsers. It has since become a fundamental channel of global trade, surpassing physical retail in many product categories.
- The core value proposition is the removal of geographic and temporal friction from commerce: buyers access goods at any time from any location; sellers reach global audiences without physical storefronts.
- Modern e-commerce is characterised by:
  - Platform aggregation — marketplaces such as [[Amazon]], [[Alibaba]], and [[eBay]] centralise millions of sellers
  - Direct-to-consumer brands operating owned storefronts via platforms like [[Shopify]] or [[WooCommerce]]
  - Mobile-first design driven by [[Mobile Commerce]] (m-commerce) accounting for the majority of consumer traffic
  - [[Recommendation System]] engines that drive a substantial share of revenue through personalised discovery
  - Headless and composable architecture decoupling frontend experience from backend commerce logic via [[API]]
- Trust and conversion depend critically on [[Cybersecurity]] controls, regulatory compliance ([[GDPR]], PCI-DSS), and frictionless [[Digital Payments]].

### Key Components

- **Storefront and Product Catalogue**
  - [[Product Catalogue]] management: SKU hierarchies, rich media, localised content
  - Search and filtering powered by [[Information Retrieval]] and vector embedding
  - [[Content Delivery Network]] for low-latency asset delivery globally
- **Transaction Processing**
  - [[Shopping Cart]] and checkout flow optimisation
  - [[Payment System]] integration: card networks (Visa, Mastercard), open banking, digital wallets ([[Digital Payments]])
  - [[Fraud Detection]] and chargeback management
  - Tax calculation and compliance (VAT, GST, sales tax)
- **Identity and Trust**
  - [[Authentication]] — password, MFA, passkeys, social sign-in
  - [[Digital Identity]] — account persistence, loyalty programmes
  - SSL/TLS encryption and [[Cybersecurity]] controls
  - Seller and product reputation systems (reviews, ratings)
- **Order Fulfilment and Logistics**
  - [[Order Management]] systems: picking, packing, dispatch
  - [[Logistics]] and last-mile delivery coordination
  - Returns management and reverse logistics
  - [[Supply Chain Visibility]] tracking via IoT and EDI
- **Data and Personalisation**
  - [[Customer Data Platform]] unifying behavioural, transactional, and demographic signals
  - [[Recommendation System]] — collaborative filtering, content-based, hybrid approaches
  - A/B testing and [[Conversion Rate Optimisation]]
  - [[Analytics]] dashboards for cohort analysis, LTV, and funnel diagnostics
- **Infrastructure**
  - [[Cloud Infrastructure]] (compute, storage, auto-scaling) for peak demand handling
  - Microservices and event-driven architecture for resilience
  - [[API]] gateways enabling composable, headless commerce

### Transaction Models

- **B2C (Business-to-Consumer)** — retailers selling directly to end consumers; highest volume segment
- **B2B (Business-to-Business)** — procurement portals, wholesale ordering, ERP-integrated purchasing
- **C2C (Consumer-to-Consumer)** — peer platforms ([[Marketplace]]) where individuals trade; [[eBay]], Vinted, Depop
- **D2C (Direct-to-Consumer)** — brands bypassing intermediaries; high margin, data-rich customer relationships
- **Social Commerce** — purchasing within social media feeds and live-stream events; integrates with [[Social Network]] platforms
- **Subscription Commerce** — recurring billing for physical or digital goods; relies on [[Digital Payments]] orchestration
- **Headless Commerce** — frontend experience decoupled from commerce engine; enables omnichannel deployments via [[API]]

### Applications and Use Cases

- **Retail** — apparel, electronics, home goods, groceries delivered via e-commerce and [[Quick Commerce]]
- **Digital Goods** — software licences, ebooks, media, SaaS subscriptions
- **Travel and Ticketing** — flight, hotel, and event booking; dynamic pricing systems
- **Healthcare** — online pharmacy, telemedicine payment, medical device ordering
- **Financial Services** — insurance comparison, investment platform onboarding
- **B2B Procurement** — enterprise purchasing via punchout catalogues and EDI integration with [[Supply Chain]] ERP
- **NFT and Digital Asset Trading** — blockchain-enabled ownership and transfer via [[Decentralised Finance]] rails
- **Metaverse Retail** — virtual goods, wearables, and in-world experiences linked to [[Metaverse Commerce]]

### Standards and Governance

- **PCI-DSS** — Payment Card Industry Data Security Standard; mandatory for any entity handling card data; defines controls for network segmentation, encryption, and access control
- **PSD2 / Open Banking** — EU directive enabling third-party access to payment accounts; underpins [[Open Banking]] integrations in European e-commerce
- **GDPR / ePrivacy** — data protection obligations for EU consumers covering cookie consent, data minimisation, and portability
- **ISO 20022** — messaging standard for financial transactions; increasingly adopted by payment networks integrated into e-commerce rails
- **W3C Payment Request API** — browser-native checkout standard reducing form-entry friction
- **OCI / GS1** — product data standards (GTIN, GDSN) used in catalogue syndication for B2B and retail
- **Accessibility (WCAG 2.2)** — web content accessibility guidelines; legally required in many jurisdictions for online storefronts
- **Standards bodies**: W3C, ISO/IEC, GS1, PCI SSC, ETSI

### Emerging Trends

- **AI-powered personalisation** — large language models enabling conversational search, dynamic merchandising, and generative product descriptions; see [[Large Language Model]]
- **Agentic commerce** — AI agents completing purchases autonomously on behalf of users; intersects with [[Autonomous Agent]] research
- **Composable / headless architecture** — MACH (Microservices, API-first, Cloud-native, Headless) enabling rapid channel experimentation
- **Real-time inventory and dynamic pricing** — ML models adjusting prices continuously based on demand signals; see [[Reinforcement Learning]]
- **Sustainable commerce** — carbon-neutral delivery, circular economy returns, scope-3 supply chain reporting
- **Blockchain settlements** — stablecoin-denominated B2B invoices and cross-border payments via [[Decentralised Finance]]

### Security Considerations

- [[Fraud Detection]] is a first-class concern; card-not-present fraud rates require ML-based anomaly detection at transaction time
- [[Cybersecurity]] scope includes web application firewalls (WAF), DDoS mitigation, and bot management to protect storefronts
- Credential stuffing attacks targeting account takeover are mitigated by [[Authentication]] hardening (passkeys, MFA) and risk-based step-up
- PCI-DSS scope reduction via tokenisation and hosted payment pages limits cardholder data exposure
- Regulatory fines under [[GDPR]] for unlawful processing of purchase data can be material; data minimisation and consent management are operational requirements

### Semantic Classification

### Provenance

