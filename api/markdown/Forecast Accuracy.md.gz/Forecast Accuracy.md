Forecast accuracy is how closely forecasts match what actually happened. MIT lecture slides define accuracy as closeness to actual observations and set it beside bias, a persistent tendency to over or under predict.[^1]

Hyndman and Athanasopoulos's open textbook defines a forecast error as the difference between an observed value and its forecast, and explains that here error does not mean a mistake but the unpredictable part of an observation.[^2] It says forecast accuracy can be measured by summarising the forecast errors in different ways.[^2] The alias Forecast Error therefore names the input, while accuracy is the summary.

## Measures and their limits

Errors on the scale of the data give scale-dependent measures, which cannot be used to compare series with different units.[^2] Percentage errors are unit-free and so are frequently used to compare forecast performance between data sets, but the textbook notes that they are infinite or undefined if the actual value is zero for any period, and take extreme values if it is close to zero.[^2]

Hyndman and Koehler discuss and compare measures of accuracy for univariate time series forecasts and propose the mean absolute scaled error as the standard measure for comparing forecast accuracy across multiple series.[^3] The textbook reports that scaled errors were proposed as an alternative to percentage errors when comparing accuracy across series with different units.[^2]

## In supply chains

This page sits under [[Supply Chain Performance Measure]], and forecasting methods are covered at [[Time Series Forecasting]] and [[Demand Forecasting]]. An accuracy figure should name its error measure, because each family described above has its own failure cases.[^2]

## What the sources do not establish

All three sources are forecasting texts, not supply chain texts, so none states a target accuracy for a supply chain or says how forecast accuracy affects stock or service. The MIT slides were read with some formulas garbled by text conversion.[^1][^2][^3]

[^1]: Massachusetts Institute of Technology OpenCourseWare (Chris Caplice), ESD.260J Logistics Systems, “Demand Forecasting II Causal Analysis”. https://ocw.mit.edu/courses/esd-260j-logistics-systems-fall-2006/f2396de71c17e2d45d69aa506eda27ce_lect4.pdf
[^2]: Rob J. Hyndman and George Athanasopoulos, “5 The forecaster’s toolbox”, Forecasting: Principles and Practice, 3rd edition (OTexts). https://otexts.com/fpp3/toolbox.html
[^3]: Rob J. Hyndman and Anne B. Koehler, International Journal of Forecasting 22(4), 2006 (author copy dated 2 November 2005), “Another look at measures of forecast accuracy”. https://robjhyndman.com/papers/mase.pdf

