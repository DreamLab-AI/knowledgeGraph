
A runtime ledger event is a [[Ledger Event]] that records the execution of an agent-level runtime action. The Agent Ontology declares it as `RuntimeLedgerEvent`, a subclass of Ledger Event.[^1]

Most of its properties describe what was executed and under what conditions. `action` links to the action performed (see [[Agent Action]]), `intent` is a string giving its high-level semantic intent, and `usesCapability` links to a capability, with `capabilityVersion` recording which version was used (see [[Agent Capability]]). `executionContext` points to the [[Execution Context]], and three string properties add detail: `environment` for further semantic markers, `hardwareAnchor` for a hardware-backed attestation anchor, and `sandboxProfile`.

Outcomes are recorded through `result`, which points to the execution result of the action, and through the string properties `sideEffect` and `stateChange`.

A runtime ledger event therefore captures an action together with its context and its observable effects, inside the integrity chain it inherits from Ledger Event. It is distinct from an event that records a governance action, such as a [[Governance Proposal]], and the specification version it applies to.

[^1]: Semantic Agent Communication Community Group, “Ledger Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/ledger.ttl

