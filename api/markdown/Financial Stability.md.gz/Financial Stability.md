Financial stability is the condition in which the financial system — encompassing banks, capital markets, payment infrastructure, insurers, and non-bank intermediaries — can absorb shocks, maintain the orderly allocation of capital, and continue to perform its core functions of credit intermediation, risk transfer, and payment settlement without requiring extraordinary public support. It is a macroprudential objective distinct from the microprudential health of individual institutions, focusing instead on the resilience and interconnectedness of the system as a whole. Threats to financial stability include excessive leverage, maturity mismatches, procyclical asset valuations, contagion through counterparty networks, and confidence crises that trigger self-fulfilling runs. International bodies such as the Financial Stability Board (FSB), the Bank for International Settlements (BIS), the International Monetary Fund (IMF), and national central banks monitor systemic risk indicators and coordinate macroprudential policy responses.

### Overview

- Financial stability is treated as a public good because disruptions to the financial system impose costs far beyond the directly affected parties, propagating into the real economy through reduced credit supply, higher borrowing costs, and loss of confidence.
- The concept gained its modern institutional form following the Great Depression (with deposit insurance schemes and central bank lender-of-last-resort doctrines) and was substantially reformed after the 2008 Global Financial Crisis, which revealed gaps in [[Prudential Supervision]], interconnectedness between [[Shadow Banking]] and regulated institutions, and procyclical leverage in structured finance.
- Financial stability analysis operates at two levels: structural (identifying long-run vulnerabilities such as excessive debt accumulation and asset price misalignments) and conjunctural (assessing near-term cyclical amplifiers and crisis transmission channels).
- Macroprudential tools — including countercyclical capital buffers, loan-to-value limits, and systemic surcharges for systemically important institutions — have been developed specifically to address the system-level dimension that microprudential regulation alone cannot address.

### Key Components

#### Systemic Risk Assessment

- [[Systemic Risk]] monitoring tracks vulnerabilities that could trigger cascading failures across financial institutions and markets.
- Key metrics include credit-to-GDP gaps, asset price deviations from fundamentals, interbank market stress indicators, and cross-border capital flow volatility.
- [[Stress Testing]] frameworks (e.g. the EBA stress tests, the Fed's DFAST/CCAR) simulate adverse macroeconomic scenarios to assess institutional resilience.

#### Capital and Liquidity Buffers

- [[Capital Adequacy]] requirements (Basel III/IV) mandate that banks hold sufficient loss-absorbing capital relative to risk-weighted assets.
- [[Liquidity Management]] standards, including the Liquidity Coverage Ratio (LCR) and Net Stable Funding Ratio (NSFR), ensure institutions can meet short-term obligations under stress.
- [[Deposit Insurance]] schemes (e.g. the UK FSCS, the US FDIC) protect retail depositors and reduce the incentive for bank runs.

#### Macroprudential Policy

- [[Macroprudential Policy]] instruments are calibrated to the financial cycle rather than individual firm risk: countercyclical capital buffers are released during downturns to support credit supply.
- Systemically Important Financial Institution (SIFI) surcharges impose additional capital on entities whose failure could destabilise the broader system.
- [[Central Banking]] authorities (e.g. Bank of England Financial Policy Committee, ECB Systemic Risk Board) exercise macroprudential mandates.

#### Resolution and Safety Nets

- Recovery and resolution planning (living wills) ensures that large institutions can fail in an orderly manner without taxpayer bailouts.
- [[Lender of Last Resort]] facilities provide emergency liquidity to solvent but illiquid institutions.
- Cross-border resolution coordination prevents regulatory arbitrage and contagion across jurisdictions.

### Mechanisms of Instability

- **Leverage amplification**: excessive borrowing magnifies both gains and losses; forced deleveraging during downturns depresses asset prices, triggering further margin calls in a procyclical spiral.
- **Maturity and liquidity mismatch**: banks and non-banks that fund long-duration assets with short-term liabilities are vulnerable to runs when short-term creditors lose confidence.
- **Interconnectedness**: bilateral counterparty exposures and common asset holdings propagate losses across institutions; the failure of one node can cascade through the network.
- **Concentration**: markets dominated by few participants amplify the impact of individual failures and reduce competitive buffers.
- **Information asymmetry**: during stress, opacity about counterparty health causes markets to seize; haircuts on collateral rise, further tightening conditions.

### Applications and Use Cases

#### Traditional Finance

- Central banks publish regular Financial Stability Reports assessing macro-financial conditions and emerging risks.
- The [[IMF Financial Sector Assessment Programme]] (FSAP) conducts country-level deep dives, stress-testing national banking systems and assessing regulatory compliance.
- Deposit guarantee schemes and resolution authorities are calibrated to contain bank failures at minimum fiscal cost.

#### Digital Assets and Crypto-Finance

- The rise of [[Stablecoin]] ecosystems introduces structural financial stability risks analogous to money market funds: runs triggered by loss of confidence, as seen in the TerraUSD collapse, can delink stablecoins from their pegs and propagate losses.
- [[Decentralised Finance]] (DeFi) lending protocols with automatic liquidation mechanisms pose novel challenges — rapid procyclical liquidation cascades during market stress can amplify volatility.
- The growth of institutional exposure to [[Crypto-Asset Regulation]]-governed markets creates interconnections between crypto and traditional finance that regulators must monitor.
- [[Central Bank Digital Currency]] (CBDC) design choices — particularly whether CBDCs are interest-bearing and directly accessible to the public — have material implications for bank deposit stability and funding structures.
- The Basel Committee's prudential treatment of banks' crypto-asset exposures (1,250% risk weight for unbacked crypto under the final Basel III rules) reflects financial stability concerns about concentration and volatility risk.

#### Governance and Regulation

- The EU [[Markets in Crypto-Assets Regulation]] (MiCA) addresses financial stability by imposing reserve and redemption requirements on asset-referenced tokens and e-money tokens.
- [[Anti-Money Laundering]] and counter-terrorist financing regimes intersect with financial stability by preventing illicit flows that can distort asset prices and destabilise institutions.
- The FSB's global crypto-asset framework recommendations seek to apply "same activity, same risk, same regulation" principles across jurisdictions.

### Standards and Regulatory Context

- **Financial Stability Board (FSB)**: coordinates international financial regulatory standards; publishes annual global monitoring reports on non-bank financial intermediation; issued the 2023 global regulatory framework for crypto-asset activities.
- **Basel Committee on Banking Supervision (BCBS)**: sets capital and liquidity standards under the Basel Accords (Basel I–IV); the 2022 final standard on prudential treatment of crypto-asset exposures classifies unbacked crypto as Group 2b (highest risk weight).
- **IMF/World Bank FSAP**: the Financial Sector Assessment Programme provides external independent assessment of financial system stability for member countries approximately every five years.
- **EU Systemic Risk Board (ESRB)**: macro-prudential oversight body for the EU financial system; issues risk warnings and recommendations.
- **Markets in Crypto-Assets Regulation (MiCA)**: EU regulation establishing reserve, redemption, and operational requirements for stablecoin issuers; entered into force 2023, fully applicable 2024–2025.
- **Bank of England Financial Policy Committee (FPC)**: exercises macroprudential mandate in the UK; sets countercyclical capital buffers and monitors systemic risk indicators including from crypto-assets.
- **Federal Reserve / FSOC**: the US Financial Stability Oversight Council coordinates domestic systemic risk monitoring and has designated nonbank SIFIs subject to enhanced prudential standards.
- **Deposit guarantee directives**: EU Deposit Guarantee Schemes Directive (DGSD) and equivalents protect depositors up to €100,000; analogous schemes exist in G20 jurisdictions.

### Provenance

