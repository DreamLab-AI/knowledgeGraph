A school of economic thought that analyses how formal institutions (laws, regulations, contracts) and informal institutions (norms, customs, culture) shape economic behaviour, incentive structures, and aggregate outcomes. It departs from neoclassical assumptions of frictionless exchange by foregrounding transaction costs, bounded rationality, and the evolutionary path-dependence of rules. The field spans the original institutionalism of Veblen and Commons and the New Institutional Economics (NIE) of Coase, North, and Williamson, which provided micro-foundations for why institutions exist and how they change. Institutional economics informs applied work in development economics, regulatory design, organisational theory, and governance of digital platforms.

### Overview

- Institutional Economics emerged in the late nineteenth and early twentieth centuries as a critique of the ahistorical, utility-maximising agent of classical and neoclassical theory.
- Core claim: markets are themselves institutions — structured by laws, regulations, cultural conventions, and enforcement mechanisms — and their performance depends on institutional quality.
- The discipline asks why some economies sustain [[Governance]] arrangements that support productive exchange while others are trapped by insecure [[Property Rights]] or predatory states.
- Two main strands:
  - **Original Institutionalism (OI)**: emphasises habit, power, historical context, and evolutionary change; sceptical of formal modelling; associated with Veblen's critique of conspicuous consumption and Commons's legal-economic analysis.
  - **New Institutional Economics (NIE)**: retains rational-choice micro-foundations but adds [[Transaction Costs]], [[Bounded Rationality]], and enforcement; uses formal models and empirical work; associated with Coase (1937, 1960), North (1990), and Williamson (1975, 1985).
- NIE has achieved wide academic and policy influence, with Coase, North, and Williamson each receiving the Nobel Memorial Prize in Economic Sciences.

### Key Components

#### Institutions

- Formal institutions: constitutions, statute law, [[Regulatory Policy]], court systems, [[Contract Theory|contracts]].
- Informal institutions: customs, social norms ([[Social Norms]]), cultural beliefs, professional ethics.
- Enforcement mechanisms: third-party enforcement (state), second-party (reputation, reciprocity), first-party (internalised norms).

#### Transaction Costs

- [[Transaction Costs]] are the costs of specifying, negotiating, monitoring, and enforcing agreements — the economic counterpart to friction in physical systems.
- Coase's theorem: in the absence of transaction costs, resource allocation is invariant to the initial assignment of [[Property Rights]]; because transaction costs are pervasive, institutions matter.
- Types: search and information costs, bargaining and decision costs, policing and enforcement costs.

#### Property Rights

- [[Property Rights]] define who has the right to use, modify, transfer, or exclude others from a resource.
- Well-specified and enforced property rights reduce expropriation risk, encourage investment, and facilitate exchange.
- Ambiguous or insecure rights generate rent-seeking, underinvestment, and resource degradation ([[Commons Governance]]).

#### Path Dependence

- [[Path Dependence]]: institutional configurations are shaped by history; early choices constrain later ones through increasing returns and lock-in.
- North's concept of institutional change as incremental, shaped by organisations and their entrepreneurs seeking rents within the existing rule-set.
- Explains why dysfunctional institutions can persist despite being inefficient.

#### Bounded Rationality

- Agents operate with [[Bounded Rationality]]: limited information-processing capacity, cognitive biases, and incomplete contracting.
- Institutions function as cognitive and behavioural scaffolding — rules reduce the decision space agents must navigate.
- Complementary to [[Behavioural Economics]], though distinct in emphasis on collective rules rather than individual heuristics.

#### Organisational Theory

- [[Organisational Theory]] within NIE: firms exist to economise on transaction costs (Coase, Williamson); the boundaries of the firm are determined by the comparative costs of market contracting versus hierarchical governance.
- Williamson's governance-structure framework maps asset specificity, uncertainty, and frequency onto make-or-buy decisions.

#### Collective Action and Commons

- [[Commons Governance]]: Elinor Ostrom's work demonstrated that communities can self-govern shared resources through polycentric institutional arrangements without either privatisation or state control.
- Complements game-theoretic models of collective action ([[Game Theory]]), adding empirical depth.

### Applications and Use Cases

#### Development Economics

- [[Development Economics]] relies heavily on institutional analysis: cross-country income differences are substantially explained by institutional quality (secure [[Property Rights]], rule of law, control of corruption) rather than geography or culture alone.
- World Bank and IMF reform programmes incorporate institutional diagnostics (Doing Business indicators, governance metrics).

#### Regulatory Policy

- [[Regulatory Policy]] design: understanding how regulatory agencies interact with regulated firms, how capture occurs, and how to design rules that are credible and enforceable.
- Competition policy, utility regulation, and antitrust draw on NIE frameworks.

#### Contract Design and Governance

- [[Contract Theory]] applications in procurement, public-private partnerships, and employment relations draw directly on NIE.
- [[Principal-Agent Theory]] addresses incentive alignment when principals cannot fully monitor agents — a core institutional problem.

#### Political Economy

- [[Political Economy]]: how political institutions (electoral systems, legislative rules, separation of powers) shape economic policy and outcomes.
- [[Public Choice Theory]] (Buchanan, Tullock) is a closely related field analysing government failure through the lens of self-interested political actors.

#### Digital Platforms and Technology Governance

- [[Digital Platform Governance]]: institutional analysis is applied to platform markets, examining how terms of service, algorithmic rules, and data-ownership regimes constitute informal institutions shaping user and producer behaviour.
- [[Smart Contracts]] on blockchain platforms have been analysed through an NIE lens: code-as-institution, examining whether algorithmic enforcement reduces transaction costs or introduces new rigidities.
- [[Decentralised Autonomous Organisation]] (DAO) governance structures can be understood as experiments in institutional design, testing whether on-chain rules can substitute for legal and social enforcement.

### Standards and Context

- No single standards body governs institutional economics as a discipline; the field is multi-paradigmatic.
- Relevant professional bodies: American Economic Association (AEA), European Association for Evolutionary Political Economy (EAEPE), International Society for New Institutional Economics (ISNIE, now SIOE — Society for Institutional and Organizational Economics).
- Nobel Memorial Prize in Economic Sciences: Ronald Coase (1991), Douglass North (1993), Oliver Williamson (2009), Elinor Ostrom (2009).
- Key journals: Journal of Institutional Economics, Journal of Law, Economics, and Organization, Journal of Economic Behavior and Organization.
- Methodological pluralism: OI uses qualitative historical methods; NIE combines formal modelling with comparative empirics; recent work incorporates [[Game Theory]], experiments, and natural experiments.
- Policy interface: World Bank Governance Indicators, OECD Regulatory Policy frameworks, IMF Structural Adjustment programmes all operationalise institutional-economics concepts.

### Provenance

