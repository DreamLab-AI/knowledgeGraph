Layer 2 scaling refers to a category of protocols and systems built atop an existing blockchain (Layer 1) that increase transaction throughput and reduce fees by processing computation and data storage off the main chain while inheriting the security guarantees of the underlying Layer 1 through cryptographic proofs, fraud-proof mechanisms, or periodic state commitments. The Layer 2 anchors itself to the Layer 1 by periodically publishing compressed state roots or validity proofs, enabling the Layer 1 to serve as the ultimate settlement and security layer while the Layer 2 handles high-volume transaction processing. Major architectural families include ZK-rollups, optimistic rollups, state channels, and sidechains, each offering distinct trade-offs between latency, security assumptions, and EVM compatibility.

### Overview

- Layer 2 scaling arose from the practical limits of base-layer [[Blockchain Scalability]]. Ethereum's mainnet could process roughly 15 transactions per second at launch, whilst Bitcoin's throughput was even lower, yet mainstream adoption demands thousands of transactions per second. The blockchain [[Scalability Trilemma]] — the difficulty of simultaneously achieving decentralisation, security, and high throughput — motivated off-chain architectures that relax the throughput constraint whilst preserving the other two properties by anchoring to a secure base layer.
- The core insight is that not every transaction need be validated by every node in the network. If participants can verify the _result_ of a batch of transactions through a compact cryptographic proof or through an economic challenge mechanism, the [[Consensus Mechanism]] work of the base layer can be concentrated on settlement rather than execution.
- Layer 2 solutions are now production-grade infrastructure. By 2024, major rollup networks process more aggregate transaction volume than Ethereum mainnet, and the [[Lightning Network]] carries substantial Bitcoin payment volume with sub-second finality. The deployment of [[EIP-4844]] (proto-danksharding) in March 2024 reduced rollup data costs by 80–90%, making Layer 2 fees negligible for most users.

### Key Architectural Families

#### Rollups

- Rollups batch many off-chain transactions and post compressed calldata or validity proofs to the [[Layer 1 Blockchain]], inheriting its security for final settlement.
- **ZK-Rollups** ([[ZK-Rollup]]): A [[Sequencer]] collects transactions, executes them in an off-chain virtual machine, and generates a [[Zero-Knowledge Proof]] (SNARK or STARK) attesting to the correctness of the state transition. A verifier [[Smart Contract]] on Layer 1 checks this proof, ensuring correctness without re-executing transactions. Implementations include zkSync Era, Starknet, Polygon zkEVM, and Scroll. ZK-rollups offer fast finality (minutes rather than days) and stronger security assumptions, at the cost of significant prover computation.
- **Optimistic Rollups** ([[Optimistic Rollup]]): State roots are posted to Layer 1 optimistically (assumed valid), but a challenge window — typically seven days — allows any observer to submit a [[Fraud Proof]] if they detect an incorrect transition. Challenged batches are re-executed on Layer 1. Implementations include Arbitrum One and Optimism (OP Stack). The trade-off is a withdrawal delay equal to the challenge window, mitigated in practice by liquidity providers who front funds for instant withdrawals.

#### State Channels

- [[State Channel]] networks allow two or more parties to open a channel by locking funds in a [[Smart Contract]] on Layer 1, exchange signed state updates off-chain at high frequency and negligible cost, and close the channel by submitting the final state on-chain.
- The [[Lightning Network]] implements this pattern for Bitcoin using [[Hash Time-Locked Contract]] (HTLC) routing across multi-hop payment paths, enabling [[Micropayment]] streams at millisecond latency.
- State channels are optimal for high-frequency bilateral interactions (payments, gaming moves) but require both parties to be online and pre-fund channels, limiting general-purpose programmability.

#### Sidechains

- A [[Sidechain]] is an independent blockchain with its own [[Consensus Mechanism]] that bridges to the main chain via a two-way peg. Unlike rollups, sidechains do not inherit Layer 1 security — users must trust the sidechain's validators. Polygon PoS (pre-CDK) and Gnosis Chain are examples. Sidechains offer high performance and EVM compatibility but with weaker security guarantees than rollups.

#### Validiums and Volitions

- Validiums use [[Zero-Knowledge Proof]] validity proofs (like ZK-rollups) but store data off-chain with a [[Data Availability]] committee rather than on Layer 1, achieving higher throughput at the cost of data availability trust assumptions. Volitions allow users to choose per-transaction whether to store data on-chain (ZK-rollup mode) or off-chain (validium mode).

### Data Availability

- [[Data Availability]] is the critical bottleneck for rollup scalability: users must be able to reconstruct the full rollup state from data published on-chain in order to exit safely if the sequencer becomes malicious or fails.
- [[EIP-4844]] (proto-danksharding) introduced a new transaction type carrying "blob" data on Ethereum's beacon chain at dramatically reduced cost, with blobs pruned after ~18 days. This reduced rollup posting costs by 80–90%.
- [[Data Availability Sampling]] (DAS) is the mechanism planned for full Danksharding, allowing light clients to verify data availability without downloading the full dataset by sampling random chunks and using erasure coding.
- Alternative data availability layers — including Celestia, EigenDA, and Avail — offer rollups the option to post data off Ethereum entirely, with varying security trade-offs.

### Sequencer Architecture

- Most production rollups use a centralised [[Sequencer]] operated by the rollup team to order and batch transactions. This introduces a potential censorship and liveness risk: if the sequencer fails, the rollup halts, and if it censors, users may be unable to transact.
- Forced inclusion mechanisms allow users to submit transactions directly to the Layer 1 [[Smart Contract]], bypassing the sequencer after a delay, preserving censorship resistance.
- Decentralised sequencer designs — including based rollups (where Ethereum validators sequence the rollup) and shared sequencer networks — are active areas of research aimed at eliminating single points of failure.

### Applications and Use Cases

- **Decentralised Finance**: [[Decentralised Finance]] protocols — DEXs, lending markets, perpetuals — benefit directly from Layer 2 as reduced fees make small trades economically viable. Uniswap, Aave, and Synthetix have deployed on multiple Layer 2 networks.
- **NFT and Gaming**: Low-cost transactions on Layer 2 enable high-frequency in-game economies, NFT minting at negligible cost, and on-chain game state that would be prohibitively expensive on Layer 1.
- **Payments and Micropayments**: The [[Lightning Network]] enables Bitcoin [[Micropayment]] channels for streaming payments, content monetisation, and machine-to-machine payments. Stablecoin payments on rollups achieve sub-cent fees.
- **Cross-Chain Asset Transfer**: [[Cross-Chain Asset Transfer]] relies on [[Bridge Protocol]] contracts that lock assets on Layer 1 and mint wrapped representations on Layer 2, or on optimistic/ZK-proof-based bridges that can verify state across chains.
- **Enterprise and Permissioned Deployments**: Application-specific Layer 3 networks (rollups atop rollups, e.g. via the OP Stack or ZK Stack) enable businesses to deploy permissioned execution environments with customised gas tokens and privacy rules whilst settling to a public Layer 2 and ultimately Ethereum.

### Standards and Context

- Ethereum Improvement Proposals (EIPs) are the primary standards vehicle for Layer 2 infrastructure on Ethereum:
  - **[[EIP-4844]]** (proto-danksharding, EIP-4844, activated Dencun hard fork March 2024): introduces blob-carrying transactions that dramatically reduce rollup data costs.
  - **EIP-7547** (inclusion lists): proposed mechanism to enforce censorship resistance for rollup sequencers by allowing Layer 1 validators to mandate inclusion of specific transactions.
  - **ERC-7683** (cross-chain intents): a standard interface for cross-chain order settlement, coordinating [[Cross-Chain Asset Transfer]] across Layer 2 networks.
- The **L2Beat** platform provides independent risk assessments and security scores for production Layer 2 deployments against a standardised framework covering data availability, upgradeability, sequencer decentralisation, and exit mechanisms.
- The **Rollup Improvement Proposals** (RIPs) process — modelled on EIPs — coordinates standards across OP Stack and ZK Stack deployments.
- [[Blockchain Interoperability]] standards (IBC, CCTP, Axelar) interact with Layer 2 ecosystems for cross-rollup asset movement.

### Security Considerations

- **Bridge risk**: [[Bridge Protocol]] contracts holding locked assets are high-value targets; bridge exploits have accounted for the largest losses in blockchain history (e.g. Ronin, Wormhole, Nomad).
- **Sequencer centralisation**: Centralised sequencers can censor transactions or go offline; forced inclusion mechanisms partially mitigate this.
- **Upgrade key risk**: Many rollup [[Smart Contract]] systems have admin keys or multi-sigs that can upgrade the verifier contracts, introducing trust in the operator; progressive decentralisation of upgrade authorities is a maturity milestone.
- **Proof soundness**: ZK proof systems depend on the soundness of the underlying cryptographic assumptions (discrete log hardness, hash collision resistance); bugs in proving systems have been found in production.
- **Data withholding**: If a sequencer posts a state root but withholds the transaction data, users cannot reconstruct the state and may be unable to prove their balance for exit; [[Data Availability]] guarantees guard against this.

### Provenance

## Merged from Layer2Scaling (needs reconciliation)
Off-chain scaling solutions executing transactions on secondary networks ({{Rollups}}, PaymentChannels, {{Sidechains}}) that batch and settle to base layer (ereum mainnet), reducing transaction costs 100-1000x whilst maintaining security through CryptographicProof|cryptographic proofs.

### Semantic Classification

### Content

#### Current Landscape

- Industry adoption and implementations
- Layer 2 solutions are widely adopted across major blockchain ecosystems, with Optimism, Arbitrum, zkSync, and StarkNet leading the Ethereum ecosystem
- Bitcoin’s Lightning Network continues to expand, supporting micropayments and cross-chain interoperability
- Layer 2 solutions are increasingly integrated into enterprise blockchain platforms, including supply chain and identity management systems
- Notable organisations and platforms
- Ethereum Foundation, Chainlink, and Polygon are prominent contributors to Layer 2 research and development
- Major DeFi protocols such as Uniswap and Aave have migrated or deployed on Layer 2 networks to reduce gas costs and improve user experience
- UK and North England examples where relevant
- UK-based fintech firms and blockchain startups, including Quant Network and Fetch.ai, have explored Layer 2 integrations for enterprise solutions
- In North England, innovation hubs such as the Manchester Blockchain Centre and the Newcastle Blockchain Lab have supported research into Layer 2 scalability for public sector and supply chain applications
- Technical capabilities and limitations
- Layer 2 solutions offer high throughput and low transaction costs, but may introduce complexity in dispute resolution and cross-chain interoperability
- Security remains dependent on the underlying Layer 1 blockchain, with some trade-offs in finality and decentralisation for certain paradigms
- Standards and frameworks
- The Ethereum Layer 2 standardisation efforts, including the ERC-4337 account abstraction proposal, are shaping interoperability and developer tooling
- Industry consortia such as the Blockchain Interoperability Alliance are working on cross-chain Layer 2 frameworks

#### Academic Context

- Brief contextual overview
- Layer 2 scaling refers to protocols and solutions built atop a foundational blockchain (Layer 1) to enhance transaction throughput, reduce costs, and improve user experience without compromising decentralisation or security
- The concept emerged as a response to the scalability trilemma—balancing decentralisation, security, and scalability—first articulated by Vitalik Buterin and widely discussed in blockchain research literature
- Layer 2 solutions are now integral to the architecture of major blockchain ecosystems, including Ethereum, Bitcoin, and increasingly, enterprise and public sector applications
- Key developments and current state
- Rollups (Optimistic and ZK), state channels, and sidechains are the dominant Layer 2 paradigms, each with distinct trade-offs in finality, security, and complexity
- The integration of Layer 2 solutions has enabled the growth of decentralised finance (DeFi), non-fungible tokens (NFTs), and Web3 applications, making blockchain more accessible for mainstream use
- Academic foundations
- The foundational work on payment channels and state channels was introduced by Miller et al. (2017) and extended by Poon and Dryja (2016) in the Bitcoin Lightning Network whitepaper
- Rollup architectures, especially zk-Rollups and Optimistic Rollups, have been formalised in recent academic literature, with ongoing research into zero-knowledge proofs and fraud-proof mechanisms

#### UK Context

- British contributions and implementations
- UK universities and research institutions, including University College London and Imperial College London, have published influential work on Layer 2 scalability and blockchain interoperability
- British fintech firms have piloted Layer 2 solutions for cross-border payments and supply chain transparency
- North England innovation hubs
- The Manchester Blockchain Centre and Newcastle Blockchain Lab have hosted workshops and research projects on Layer 2 scalability for public sector applications
- Local startups in the North East have explored Layer 2 solutions for energy trading and smart city initiatives
- Regional case studies
- A pilot project in Newcastle utilised Layer 2 scaling for a local energy trading platform, demonstrating improved transaction speed and reduced costs
- Manchester-based fintech firms have integrated Layer 2 solutions into their payment systems for SMEs

#### Future Directions

- Emerging trends and developments
- Increased adoption of Layer 2 solutions in enterprise and public sector applications
- Development of hybrid Layer 2 architectures combining rollups, state channels, and sidechains
- Integration of Layer 2 with emerging technologies such as AI and IoT
- Anticipated challenges
- Ensuring security and decentralisation in increasingly complex Layer 2 ecosystems
- Addressing regulatory and compliance issues for cross-border Layer 2 applications
- Managing the environmental impact of Layer 2 solutions
- Research priorities
- Improving the scalability and security of Layer 2 solutions
- Developing standards for cross-chain interoperability
- Exploring the integration of Layer 2 with privacy-preserving technologies

#### Research & Literature

- Key academic papers and sources
- Miller, A., et al. (2017). "The Lightning Network: Scalable Off-Chain Instant Payments." arXiv:1605.06369. https://arxiv.org/abs/1605.06369
- Poon, J., & Dryja, T. (2016). "The Bitcoin Lightning Network: Scalable Off-Chain Instant Payments." https://lightning.network/lightning-network-paper.pdf
- Buterin, V. (2018). "On Layer 2 Scaling Solutions." Ethereum Foundation Blog. https://ethereum.org/en/layer-2/
- ZK-Rollup: Ben-Sasson, E., et al. (2014). "zk-SNARKs: Under the Hood." https://blog.ethereum.org/2016/12/05/zksnarks-in-a-nutshell/
- Optimistic Rollup: Optimism Team. (2020). "Optimistic Rollup: Scalable Blockchain Smart Contracts." https://optimism.io/whitepaper.pdf
- Ongoing research directions
- Improving the efficiency and security of zero-knowledge proofs for rollups
- Developing cross-chain interoperability protocols for Layer 2 solutions
- Exploring the integration of Layer 2 with privacy-preserving technologies

### Provenance

