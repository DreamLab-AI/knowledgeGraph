A contract manufacturer is a business that carries out manufacturing operations for another business. The United Nations ISIC describes the arrangement as one in which units sell goods or services under their own name but the actual production is carried out fully or in part by others through specific contractual arrangements.[^1]

## Definitions in the sources

In drug regulation, the US Food and Drug Administration defines contract facilities as “parties that perform one or more manufacturing operations on behalf of an owner or owners”, and defines owners as manufacturers of APIs, drug substances, in-process materials, finished drug products, including biological products, and combination products.[^2]

The ISIC treats the general case in terms of outsourcing, which it describes as a contractual agreement according to which the principal requires the contractor to carry out a specific production process.[^1] Its classification rule turns on ownership of materials: a principal that completely outsources the transformation process is classified into manufacturing only if it owns the input materials, and therefore the final output.[^1] If it does not own them, it is in fact buying the completed good from the contractor with the intention to re-sell it, and the activity is classified in wholesale and retail trade.[^1]

The Industrial Ontologies Foundry models the contractor side as a manufacturing service provider role, a service provider role held by a person or business organisation when it provides a manufacturing service.[^3] Its examples include a contract machinist who machines parts owned by another company, and Foxconn, which it describes as a contract manufacturing service company that owns and operates factories in China that do the final assembly of iPhones for Apple.[^3]

## Scope and distinctions

A contract manufacturer is a kind of [[Supplier]] and a form of [[Outsourcing]]. The wording varies by field. The FDA definition is specific to drug quality agreements and the IOF example is electronics assembly, and the sources opened do not give a general industrial definition beyond the ISIC description.[^2][^3][^1]

## What the sources do not establish

Sources do not say how contract manufacturers differ from original design manufacturers or electronics manufacturing services providers, because none of the opened material defines those terms. They contain no figures on the size of the sector and no account of intellectual-property arrangements between the parties.

[^1]: United Nations Statistics Division, “International Standard Industrial Classification of All Economic Activities (ISIC), Revision 4”. https://unstats.un.org/unsd/classifications/Econ/Download/In%20Text/ISIC_Rev_4_publication_English.pdf
[^2]: US Food and Drug Administration, “Contract Manufacturing Arrangements for Drugs: Quality Agreements”, guidance for industry, November 2016. https://www.fda.gov/media/86193/download
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

