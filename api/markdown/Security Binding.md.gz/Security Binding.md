
A security binding is the chain that links an agent's identifier to the hardware and ledger that vouch for it. In the SAC-CG Agent Ontology the class `SecurityBinding` "represents the chain binding DID → Key Material → Hardware → Ledger verification."[^1]

The ontology expresses the chain through properties of its neighbouring classes and not on `SecurityBinding` itself: an agent has key material (`hasKeyMaterial`), key material is anchored by a [[Hardware Root of Trust]] (`anchoredBy`), the hardware is verified by a [[Trust Anchor]] (`verifiedBy`), and key material signs ledger records (`signsRecord`). The chain starts at a [[Decentralised Identifier]] and uses a [[Cryptographic Key]].

visionGraph places Security Binding under [[Attestation]], since it is an arrangement that lets a verifier check a claim about an agent. It is distinct from [[Identity Binding]], which links an identity to a key management system by name.

The security binding module is version 0.2.0 of a Community Group draft, not a W3C Recommendation.

[^1]: Semantic Agent Communication Community Group, “Security Binding Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/security-binding.ttl

