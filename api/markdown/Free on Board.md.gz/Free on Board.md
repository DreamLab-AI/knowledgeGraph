Free on Board (FOB) is an Incoterms 2020 rule under which the seller delivers the goods on board the vessel nominated by the buyer at the named port of shipment, and the risk of loss or damage passes to the buyer when the goods are on board.[^1][^2]

The Export Council of Australia says that under the 2020 rules the seller has fulfilled its obligation when the goods are loaded on the vessel, and that the buyer bears costs from that point forward.[^2] The seller handles export clearance, which the council summarises as cleared for export by seller.[^2] The software vendor AEB gives the same split of delivery and risk, and adds that the seller may procure goods already so delivered.[^1]

## Scope and distinctions

FOB is for sea and inland waterway transport only. The US International Trade Administration lists it with the four sea and inland waterway rules, and the Export Council of Australia says FOB should only be used for those modes and is not recommended for container transport.[^3][^2]

Because most goods now reach a container yard rather than the vessel itself, the council says buyer and seller must agree exactly what loaded on board means in the sales contract, as this can vary for different types of vessel and commodity.[^2]

FOB is one rule inside [[Incoterms]], itself a [[Trade Term]] family. It should not be confused with the F.O.B. delivery term in the US Uniform Commercial Code. There, F.O.B. the place of shipment makes the seller bear the expense and risk of putting the goods into the possession of the carrier, and F.O.B. the place of destination makes the seller transport the goods to that place at its own expense and risk.[^4] The Code's rule applies unless the parties otherwise agree.[^4]

## In practice

Under FOB the seller is responsible for loading the goods on the vessel, and the buyer is responsible for everything else necessary to get the goods to the final destination.[^2] The International Trade Administration says parties need to specify clearly which version of Incoterms they are using.[^3]

## What the sources do not establish

No opened source reproduces the ICC text of the rule, which is copyright and was not read. AEB is a trade software vendor, so its glossary is used only to corroborate the two government and association sources. The sources do not cover how courts in particular countries treat FOB.

[^1]: AEB, “FOB – Free on Board (Incoterm)”. https://www.aeb.com/en/glossary/fob-free-on-board-incoterm.php
[^2]: Export Council of Australia, “FOB – Free on Board (Named Place) Incoterms® 2020”. https://export.org.au/?p=17266
[^3]: International Trade Administration (US Department of Commerce), “Know Your Incoterms”. https://www.trade.gov/know-your-incoterms
[^4]: Cornell Law School Legal Information Institute, “§ 2-319. F.O.B. and F.A.S. Terms.” (Uniform Commercial Code). https://www.law.cornell.edu/ucc/2/2-319

