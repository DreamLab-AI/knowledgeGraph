GS1 is the global not-for-profit standards organisation responsible for designing, administering, and maintaining the world's most widely deployed open supply chain identification system, used by over two million companies in more than 150 countries. Its core standards define globally unique identification schemes for trade items (GTIN), locations (GLN), logistic units (SSCC), and assets (GIAI), encoding them in barcodes (EAN-13, ITF-14, GS1-128), two-dimensional symbols (GS1 DataMatrix, GS1 QR), and digital web URIs via GS1 Digital Link. GS1 also governs EPCIS (Electronic Product Code Information Services), the event-data exchange standard that captures What, Where, When, Why, and How across the supply chain, and underpins regulatory traceability mandates in pharmaceuticals, food safety, and sustainable products across the EU, US, and beyond.

### Overview

- GS1 (an abbreviation whose full original name is "Global Standards One") was formed in 2004 through the merger of the Uniform Code Council (UCC) in North America and EAN International in Europe. The UCC had developed the Uniform Product Code (UPC) in 1973, adopted for retail in 1974 with the first scanned product in a US supermarket. The European Article Numbering (EAN) system followed in 1977, extending UPC to 13 digits for international use.
- Today GS1 operates through a federated governance model comprising over 115 national GS1 Member Organisations (such as GS1 US, GS1 UK, GS1 Germany), each serving their local business communities while adhering to global specifications governed by GS1 Global.
- The core proposition of GS1 is that every distinct product, location, and logistic unit in global trade should bear a globally unique, unambiguous identifier that any trading partner worldwide can decode and act upon without prior bilateral agreement. This principle of "common language" for supply chains underpins interoperability across millions of companies and billions of product units daily.
- GS1 standards are unique in that they are adopted bottom-up (through industry voluntary consensus) as well as top-down through regulatory mandates — the US DSCSA for pharmaceuticals, EU Falsified Medicines Directive (FMD), FDA FSMA 204 for food traceability, and EU Digital Product Passport regulations all explicitly reference GS1 schemas.

### Key Components

#### Identification Standards

- **GTIN (Global Trade Item Number)**: A 14-digit globally unique identifier for any trade item, encoded in EAN-13, EAN-8, UPC-A, ITF-14, or GS1-128 [[Barcode]] symbologies depending on packaging context. GTINs are allocated by GS1 Member Organisations and must be used consistently by all trading partners.
- **GLN (Global Location Number)**: A 13-digit identifier for any legal entity, physical location, or functional location involved in supply chain transactions. GLNs identify manufacturers, retailers, warehouses, hospitals, and distribution centres for routing orders, invoices, and [[Electronic Data Interchange]] messages.
- **SSCC (Serial Shipping Container Code)**: An 18-digit identifier for individual logistics units — pallets, cases, containers — enabling each physical unit to be uniquely tracked throughout the supply chain from packing to delivery.
- **GIAI (Global Individual Asset Identifier)**: A unique identifier for fixed or returnable assets (equipment, crates, barrels) owned by a company.
- **GLCN (Global Coupon Number)** and **GSRN (Global Service Relation Number)**: Specialist identifiers for coupons and service relationships respectively.

#### Data Carrier Standards

- **EAN-13 / UPC-A [[Barcode]]**: One-dimensional linear barcodes encoding a 13- or 12-digit GTIN; ubiquitous on consumer retail packaging globally.
- **ITF-14**: 14-digit GTIN barcode for logistics/outer packaging used in warehouses and distribution.
- **GS1-128**: Linear barcode encoding a GTIN plus Application Identifier (AI) data such as batch/lot numbers, expiry dates, and serial numbers.
- **GS1 DataMatrix**: A two-dimensional matrix code used in healthcare (EU FMD, DSCSA) for serialised GTINs with batch, expiry, and serial number on small-format pharmaceutical packaging.
- **GS1 QR Code**: A two-dimensional QR code carrying a [[GS1 Digital Link]] URI, enabling both machine-readable supply chain data and consumer-facing web content from a single scan.
- **[[RFID]] (EPC/GS1 Gen2)**: UHF RFID tags encoding Electronic Product Codes (EPCs) derived from GTINs; used in high-throughput retail, pharmaceutical, and apparel supply chains for item-level visibility without line-of-sight scanning.

#### Data Exchange Standards

- **[[EPCIS]] (Electronic Product Code Information Services)**: An ISO/IEC 19987 and GS1 standard defining a data model and API for sharing supply chain events (ObjectEvent, AggregationEvent, TransactionEvent, TransformationEvent) describing What item, Where it moved, When, Why (business context), and How (sensor data). EPCIS 2.0 (2022) adds REST/JSON-LD alongside SOAP/XML.
- **EDI (Electronic Data Interchange)**: GS1 EANCOM and GS1 XML message standards for purchase orders, advance shipping notices (ASNs), invoices, and inventory reports exchanged between trading partners; now also available in GS1 Web API format.
- **GS1 Core Business Vocabulary (CBV)**: The controlled vocabulary of standardised values (business steps, dispositions, location types) for use in EPCIS event payloads, ensuring semantic interoperability.
- **[[GS1 Digital Link]]**: An ISO/IEC 18975 standard encoding GS1 identifiers within standard HTTPS URIs (e.g., `https://id.gs1.org/01/09501101530003`), resolvable to structured product data, regulatory compliance records, sustainability information, and consumer portals. Enables QR codes to replace traditional 1D barcodes while supporting both B2B and B2C use cases from a single data carrier.

### Applications and Use Cases

#### Retail and Consumer Goods

- EAN-13 / UPC-A barcodes on virtually every consumer packaged goods (CPG) product globally, enabling point-of-sale scanning, inventory management, and demand forecasting. The retail sector was the original driver of GS1 standards adoption and remains the highest-volume use case, covering tens of billions of scans per day worldwide.
- Sunrise 2027: GS1's global initiative driving the retail industry transition from 1D EAN/UPC barcodes to GS1 QR codes (carrying GS1 Digital Link) by 2027, enabling richer product data, serialisation, and [[Digital Product Passport]] compliance alongside POS scanning.

#### Pharmaceuticals and Healthcare

- Serialised GTIN + batch/lot/expiry/serial number in GS1 DataMatrix on all unit-level pharmaceutical packaging, as required under the US DSCSA (full enforcement reached 2024) and EU FMD. Trading partners must exchange EPCIS-format transaction data to comply with these regulations.
- Hospital supply chain management using GLNs to route medical device orders, invoices, and [[RFID]]-based asset tracking of surgical instruments and implants.
- [[Pharmaceutical Traceability]] from manufacturer to patient, enabling rapid identification and recall of counterfeited or diverted medicines.

#### Food Safety and Traceability

- FDA FSMA Rule 204 (Food Traceability Rule, effective January 2026) mandates Key Data Element (KDE) tracking for high-risk foods (leafy greens, cheeses, shell eggs, etc.) aligned to GS1 EPCIS event data for rapid outbreak investigation.
- [[Food Safety Blockchain]] pilots such as IBM Food Trust and Walmart's leafy greens traceability programme use EPCIS events as the structured data layer anchored to blockchain ledgers for immutable provenance records.
- Fresh produce, meat, and seafood supply chains use GTINs combined with batch/lot AIs and EPCIS to enable farm-to-fork traceability aligned with [[Supply Chain Provenance]] requirements.

#### Logistics and Transportation

- SSCC barcodes on pallets and cases enabling warehouse management systems (WMS) to track, sort, and route logistics units through distribution centres. Advance Shipping Notices (ASNs) in GS1 EDI/XML format allow receivers to pre-process incoming shipments before physical arrival.
- [[Logistics Optimisation]] through RFID-tagged pallets and cases scanned at dock doors, enabling real-time inventory positioning and reducing manual scanning labour.
- Cold chain monitoring using EPCIS sensor events to record temperature excursions during transport of food, pharmaceuticals, and biologics.

#### Digital Product Passport and Sustainability

- EU Ecodesign for Sustainable Products Regulation (ESPR) and related Battery Regulation, Textile Regulation, and Construction Products Regulation mandate [[Digital Product Passport]] (DPP) data carriers; GS1 Digital Link QR codes are specified as the preferred carrier, encoding a GS1 identifier that resolves to the passport data repository.
- Product carbon footprint and circularity data accessible via GS1 Digital Link URIs, enabling consumers and recyclers to access material composition, recycling instructions, and end-of-life information.

#### Decentralised Identity and Web3 Integration

- GS1 is collaborating with the W3C Decentralised Identifiers (DIDs) working group to define a GS1 DID method (`did:gs1:`) enabling GS1-identified products to participate in [[Verifiable Credential]] ecosystems. This allows physical product provenance to be attested by manufacturers and verified by trading partners using cryptographic proofs anchored to [[Decentralised Identifier]] infrastructure.
- [[Food Safety Blockchain]] and pharmaceutical serialisation programmes use EPCIS as the structured event format for blockchain-anchored traceability, with GS1 identifiers providing the link between on-chain records and physical items.

### Standards and Context

- GS1 standards are published under the GS1 General Specifications (updated annually), the definitive technical reference for all GS1 barcode, RFID, and data model standards. Key relevant ISO standards include:
  - ISO/IEC 15420 — EAN/UPC barcode symbology specification
  - ISO/IEC 16388 — Code 39 (used with GS1 Application Identifiers)
  - ISO/IEC 15417 — Code 128 (GS1-128 is a subset application)
  - ISO/IEC 16022 — Data Matrix (GS1 DataMatrix is a GS1-constrained application)
  - ISO/IEC 18004 — QR Code (GS1 QR Code is a GS1-constrained application)
  - ISO/IEC 18975 — GS1 Digital Link URI syntax
  - ISO/IEC 19987 — EPCIS 2.0 event data standard
  - ISO/IEC 15693, ISO/IEC 18000-63 — UHF RFID (GS1 EPC Gen2)
- GS1 maintains liaison relationships with ISO TC 68 (financial services), ISO TC 122 (packaging), ISO TC 104 (freight containers), and the World Customs Organisation (WCO) for harmonisation with customs data requirements.
- The GS1 Healthcare User Group (GS1 HUG) coordinates pharmaceutical and medical device industry adoption, working alongside regulatory bodies including the US FDA, European Medicines Agency (EMA), and national health ministries.
- The Global Data Synchronisation Network (GDSN) is the GS1-governed network of interoperable product data pools (e.g., 1WorldSync, Salsify) through which manufacturers publish master product data (attributes, images, regulatory information) synchronised to retailer systems, underpinning [[Data Interoperability]] in the CPG sector.

### Governance and Organisation

- GS1 is governed by a board of directors drawn from major industry sectors (retail, manufacturing, healthcare, logistics) and operates under a not-for-profit charter. Industry engagement occurs through GS1 Global Forums, sector-specific user groups (Healthcare, Fresh Foods, Foodservice, Apparel), and the GS1 Management Board.
- National member organisations (GS1 US, GS1 UK, GS1 Germany, etc.) are federated under the GS1 Global umbrella, licensed to issue GS1 Company Prefixes within their territories and providing local education, support, and market development. Companies obtain their GS1 Company Prefix from their national member organisation, which ensures global uniqueness of all derived GTINs, GLNs, and SSCCs.
- GS1's technical standards development follows a structured process involving Industry Advisory Groups, public comment periods, and pilot testing prior to publication, broadly aligned with the principles of open [[Open Standards]] development.

### Provenance

