A chain of custody model is an approach to tracking certified material through a supply chain so that claims about the final product can be supported, and the models differ in how far certified and non-certified material is kept apart.[^1][^2]

ISO 22095:2020 defines a framework for chain of custody by providing a consistent generic approach to the design, implementation and management of chains of custody, harmonised terminology, general requirements for different chain of custody models, and guidance on the circumstances in which each model might be appropriate.[^1] Its abstract warns that the existence of a chain of custody system alone does not specify the characteristics or conditions under which materials or products are produced.[^1] The standard is cite-only and only the abstract was opened.

## Models in practice

The UN Global Compact guide identifies three models: product segregation, mass balance, and book and claim.[^2] Under product segregation, certified materials and products are physically separated from non-certified materials and products at each stage along the value chain.[^2] Under mass balance, certified and non-certified materials can be mixed, but the volume of certified material entering is controlled and an equivalent volume can be sold as certified; see [[Mass Balance]].[^2] The book and claim model does not seek traceability at each stage.[^2] The guide says mass balance and book and claim are open to criticism for commodities where segregation is available.[^2]

The Roundtable on Sustainable Palm Oil lists four supply chain models: identity preserved, segregated, mass balance, and credits or book and claim.[^3] The Forest Stewardship Council says its chain of custody certification verifies that forest-based materials are used along the product's path from the forest to finished goods, and that only accredited third-party certification bodies can audit.[^4]

## Scope and limits

Chain of custody models belong to the traceability branch headed by [[Traceability and Product Identification]] and are one way to support [[Supply Chain Traceability]]. The sources describe schemes for forest and palm oil products and for commodities generally; they do not report error rates or fraud, and ISO's own terminology could not be read.

[^1]: International Organization for Standardization, catalogue page (abstract only; ISO standards are cite-only), ISO 22095:2020 Chain of custody — General terminology and models. https://www.iso.org/standard/72532.html
[^2]: United Nations Global Compact and BSR, 2014, “A Guide to Traceability: A Practical Approach to Advance Sustainability in Global Supply Chains”. https://www.unglobalcompact.org/docs/issues_doc/supply_chain/Traceability/Guide_to_Traceability.pdf
[^3]: Roundtable on Sustainable Palm Oil, Supply chains. https://rspo.org/?p=135
[^4]: Forest Stewardship Council, “Chain of Custody Certification”. https://fsc.org/en/chain-of-custody-certification

