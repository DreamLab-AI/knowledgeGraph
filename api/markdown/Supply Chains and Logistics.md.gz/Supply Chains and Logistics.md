Supply Chains and Logistics is the organisational label for the corpus domain that covers supply chains, the management of supply chains, and the logistics that moves and stores goods within them.[^1][^2][^3]

None of the sources opened here defines the combined phrase. It is a grouping used by this vault, not an established term of art. Its nearest external parallel is the Industrial Ontologies Foundry, which describes its Supply Chain Ontology as representing generic constructs for the domains of supply chain and logistics, again as a pairing of two named fields.[^3]

## Relationship between the two halves

The Council of Supply Chain Management Professionals (CSCMP) defines supply chain management as the planning and management of all activities in sourcing and procurement, conversion and logistics management, and treats logistics management as a part of it.[^1] The European Commission's transport pages put it in similar terms: logistics is a fundamental part of supply chain management, consisting of the organisation and management of flows of goods linked to purchasing, production, warehousing, distribution and the disposal, reuse and exchange of products, together with added value services.[^2]

Two independent bodies therefore place logistics inside supply chain management. Read the domain name as a grouping, not as two parallel disciplines of equal rank.[^1][^2]

## Scope and distinctions

[[Supply Chain]] is the concept page for the network itself, [[Supply Chain Management]] the discipline that plans and manages it, and [[Logistics]] the flow and storage of goods. They are related pages rather than synonyms.

Sources draw no sharp boundary between logistics and the rest of supply chain management. CSCMP says that, to varying degrees, the logistics function also includes sourcing and procurement, production planning and scheduling, packaging and assembly, and customer service.[^1]

Definitions of the underlying terms are also unsettled. Mentzer and colleagues open their review of the field by observing that so many definitions of supply chain management are used that there is little consensus on what it means, and they review definitions of both supply chain management and supply chain.[^4] Pages in this domain therefore name the source behind each definition and say where sources differ.

## What the sources do not establish

These sources are a professional body, an institution of the European Union, an ontology project and a review of definitions. They do not give a boundary for the domain, a list of its subfields, or a rule for where a topic such as customs or procurement sits relative to logistics. Those placements are editorial decisions of the vault, not findings of the sources.[^1][^2][^3][^4]

[^1]: Council of Supply Chain Management Professionals, “CSCMP Supply Chain Management Definitions and Glossary”. https://cscmp.org/CSCMP/Educate/SCM_Definitions_and_Glossary_of_Terms.aspx
[^2]: European Commission, Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology README, “Supply Chain Reference Ontology (SCRO)”. https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/README.md
[^4]: John T. Mentzer and colleagues, Journal of Business Logistics, 2001, abstract record for the article on defining supply chain management (Crossref). https://api.crossref.org/works/10.1002/j.2158-1592.2001.tb00001.x

