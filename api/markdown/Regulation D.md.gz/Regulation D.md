A United States Securities and Exchange Commission regulation providing exemptions from the registration requirements of the Securities Act of 1933, allowing companies to raise capital through private placements to accredited investors without a full public offering. Its Rules 504 and 506 are the dominant legal pathway for security token offerings and early-stage fundraising, trading reduced disclosure burdens for restrictions on general solicitation and resale.

### Semantic Classification

### Content

## Definition

**Regulation D** is a set of rules adopted by the US Securities and Exchange Commission (SEC) under the Securities Act of 1933 that exempts certain offerings of securities from federal registration. Rather than filing a full prospectus, an issuer relying on Regulation D files a short Form D notice and sells to a restricted pool of purchasers — most importantly *accredited investors*, defined by income, net-worth, or professional-qualification thresholds.

The exemption is not a single rule but a family. Rule 506(b) permits unlimited capital raising from accredited investors (plus up to 35 sophisticated non-accredited investors) provided there is no general solicitation; Rule 506(c) allows public advertising but demands that the issuer take reasonable steps to *verify* accredited status; Rule 504 caps smaller offerings (currently 10 million US dollars in a twelve-month period). Securities sold under Regulation D are "restricted securities" and cannot be freely resold, typically for at least six to twelve months.

Within [[Securities Regulation]] more broadly, Regulation D matters to the digital-asset ecosystem because it is the most common compliance wrapper for a [[Security Token]] offering in the United States: token issuers accept transfer restrictions and investor-verification duties in exchange for a lawful private-placement route, often pairing it with Regulation S for offshore tranches.

## Current Landscape

Regulation D remains the workhorse of US private capital formation, with Form D filings covering well over one trillion US dollars of annual issuance — far exceeding registered public offerings. In tokenised markets, platforms combine Rule 506(c) verification workflows with [[Know Your Customer]] checks and on-chain transfer-restriction logic (for example ERC-1404-style token standards) so that restricted securities cannot move to unverified wallets.

Debate continues over the accredited-investor definition, which gates most Regulation D deals to wealthier participants, and over the boundary between exempt private placements and public [[Crowdfunding]] regimes such as Regulation CF. For UK and EU issuers the closest analogues are prospectus-exemption thresholds, but the regimes differ materially: Regulation D is jurisdiction-specific SEC law, and non-US issuers targeting US investors must still comply with it.

Dated developments:

- **12 March 2025**: the SEC's Division of Corporation Finance issued a no-action letter easing Rule 506(c) accredited-investor verification — issuers may now treat a high **minimum investment amount** (at least $200,000 for natural persons, $1 million for legal entities) as a reasonable verification step, provided they obtain written representations and have no contrary knowledge. This materially lowers the compliance friction that had made 506(c) less popular than 506(b).
- **Thresholds (current)**: the accredited-investor bar for individuals remains $200,000 income ($300,000 with spouse) in each of the two most recent years, or $1 million net worth excluding primary residence — plus professional-certification routes (e.g. Series 7/65/82 licences) added in the 2020 definition expansion.
- **Rule 506(b) vs 506(c)**: both allow unlimited capital; 506(b) forbids general solicitation but permits investor self-certification and up to 35 sophisticated non-accredited purchasers, while 506(c) permits public advertising but requires all purchasers to be verified accredited investors. Form D must be filed within 15 days of first sale.
- **Scale**: Regulation D (chiefly Rule 506) remains the dominant channel of US private capital formation, with annual issuance far exceeding registered public offerings, and Rule 504 caps smaller offerings at $10 million per twelve-month period.

  **Sources**:

- https://www.sec.gov/resources-small-businesses/capital-raising-building-blocks/assessing-accredited-investors-under-regulation-d
- https://www.morganlewis.com/pubs/2025/03/new-sec-guidance-eases-burden-in-rule-506c-accredited-investor-verification-requirements
- https://www.investor.gov/introduction-investing/investing-basics/glossary/rule-506-regulation-d

