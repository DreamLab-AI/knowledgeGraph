In Fisher's framework a responsive supply chain, which he calls a market-responsive chain, is one designed to respond quickly to unpredictable demand in order to minimise stockouts, forced markdowns and obsolete inventory, and it is the chain he matches to “innovative products”.[^1][^2]

Fisher classifies products by demand pattern as primarily functional or primarily “innovative” (his second category, products built on fashion or technology innovation, with unpredictable demand). Fisher's “innovative products” have high profit margins but volatile demand, and so need a fundamentally different supply chain from stable, low-margin functional products.[^1] Because demand is uncertain, market mediation costs predominate for these products: the costs of supply exceeding demand, so that goods are marked down, or falling short of it, so that sales are lost.[^1]

Fisher's comparison table sets out how a market-responsive process differs from a physically efficient one. It deploys excess buffer capacity in manufacturing, holds significant buffer stocks of parts or finished goods, invests aggressively in ways to reduce lead time, selects suppliers primarily for speed, flexibility and quality, and uses modular design to postpone product differentiation for as long as possible.[^1]

Mahdavi, Mahmoudzadeh and Olsen describe Fisher's pairing of responsive chains with “innovative products” as one of the earliest and most widely discussed guidelines in supply chain management.[^2]

## Scope and distinctions

Fisher states that the root cause of many supply chain problems is a mismatch between the type of product and the type of chain, and he argues that for companies with “innovative products” the rewards from investing in responsiveness are usually much greater than from improving efficiency.[^1] The contrasting type is the [[Efficient Supply Chain]].

Other authors use the word too. Christopher says the key to survival in volatile markets is agility, in particular through the creation of responsive supply chains.[^3] The sources opened here do not say whether Fisher's responsive chain and Christopher's agile chain are the same thing, and this vault keeps [[Agile Supply Chain]] as a separate page. See also [[Supply Chain Strategy Type]].

## What the sources do not establish

Fisher's article was read as a Harvard Business Review reprint hosted on a university course site, because the publisher's own page showed no article text. Only Fisher's own text and tables are used. Fisher's framework is built on demand patterns; Lee's article considers the uncertainties of both demand and supply, but only its abstract was opened, so its framework is not described here.[^1][^4]

[^1]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf
[^2]: Mojtaba Mahdavi, Mahdi Mahmoudzadeh and Tava Lennon Olsen, International Journal of Production Economics, vol. 255 (IDEAS/RePEc record, abstract only), “Efficient vs. Responsive supplier selection for functional and innovative products: A quantitative study”. https://ideas.repec.org/a/eee/proeco/v255y2023ics0925527322002389.html
[^3]: Martin Christopher, Industrial Marketing Management, 2000 (Cranfield repository copy), “The Agile Supply Chain : Competing in Volatile Markets”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/3e60f75d-28c1-4659-a260-6608c0e863f2/content
[^4]: Hau L. Lee, California Management Review, Spring 2002 (abstract page), “Aligning Supply Chain Strategies with Product Uncertainties”. https://cmr.berkeley.edu/2002/05/44-3-aligning-supply-chain-strategies-with-product-uncertainties/

