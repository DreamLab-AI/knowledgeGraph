Governance is the set of processes, institutions, norms, rules, and practices by which authority is exercised and decisions are made within an organisation, system, or society. It encompasses the mechanisms through which stakeholders participate in, constrain, and are held accountable by decision-making structures, balancing competing interests through legitimate frameworks. In technical and sociotechnical contexts, governance determines who controls shared resources, how policies are formed and enforced, and how disputes are resolved. Effective governance integrates regulatory compliance, ethical accountability, risk management, and participatory design to achieve legitimate and adaptive coordination.

### Overview

- Governance is one of the most foundational cross-cutting concepts in political science, public administration, international relations, and increasingly in technology policy. It addresses a core problem: how can groups of actors with heterogeneous interests and capabilities make binding collective decisions that are perceived as legitimate?
- Governance is not synonymous with government. It includes informal norms, market mechanisms, civil society networks, and hybrid arrangements such as [[Multi-Stakeholder Governance]] models used in internet policy bodies (e.g. ICANN, IGF).
- Modern governance theory distinguishes:
  - **Hierarchical governance** — top-down authority via states or corporations
  - **Market governance** — price signals and competition allocating resources
  - **Network governance** — negotiated coordination among interdependent actors
  - **Polycentric governance** — overlapping jurisdictions at multiple scales (Ostrom)
- In digital and AI contexts, governance has expanded to address algorithmic systems, data flows, platform power, and the cross-border nature of technology — areas where traditional regulatory instruments are often inadequate.
- Why governance matters:
  - Without governance, collective action problems lead to under-provision of public goods, tragedy of the commons, and regulatory capture.
  - Effective governance enables [[Legitimacy]], predictability, and innovation by reducing uncertainty and building [[Institutional Trust]].
  - Poor governance produces corruption, exclusion, regulatory arbitrage, and erosion of public trust.

### Key Components

- **[[Policy]]** — formal and informal rules that guide decisions and constrain behaviour within a governed system.
- **[[Regulatory Compliance]]** — the set of obligations actors must meet; enforced through audit, certification, and sanctions.
- **[[Accountability]]** — mechanisms by which decision-makers are answerable to those affected by their choices; includes electoral accountability, judicial review, and independent audit.
- **[[Transparency]]** — requirements for disclosure of information so that stakeholders can assess decisions and hold actors accountable.
- **[[Risk Management]]** — systematic identification and mitigation of hazards that governance structures must address, from financial systemic risk to AI safety.
- **[[Enforcement Mechanism]]** — sanctions, incentives, monitoring, and dispute resolution systems that give rules their binding force.
- **[[Stakeholder Participation]]** — processes by which affected parties contribute to rule-setting, including public consultation, deliberative panels, and co-regulation.
- **[[Institutional Trust]]** — the social capital that allows actors to rely on governance structures without requiring verification of every transaction.
- **[[Information Asymmetry]]** — a pervasive challenge: regulated entities often know more than regulators, motivating disclosure requirements and capacity-building.
- **[[Legitimacy]]** — the perceived rightfulness of authority; governance structures lacking legitimacy are fragile and generate non-compliance.

### Mechanisms

- **Rule-making** — drafting and adopting binding or voluntary standards through legislative, regulatory, or standards bodies such as ISO, IEEE, or national parliaments.
- **Monitoring and inspection** — data collection, auditing, and surveillance to check compliance.
- **Adjudication** — dispute resolution through courts, arbitration panels, or ombudsmen.
- **Sanctions** — fines, licence revocation, trade restrictions, or reputational consequences for non-compliance.
- **Incentive design** — subsidies, tax treatment, and procurement preferences that steer behaviour without direct command.
- **Capacity-building** — training regulators and regulated entities to understand complex technical domains (critical for [[AI Governance and Ethics]]).
- **Iterative review** — sunset clauses, regulatory sandboxes, and periodic review cycles to adapt governance to changing conditions.

### Applications and Use Cases

- **Corporate governance** — boards of directors, shareholder rights, audit committees, and executive accountability under frameworks such as the UK Corporate Governance Code or Sarbanes-Oxley. See [[Corporate Governance]].
- **[[Internet Governance]]** — multistakeholder management of DNS, IP address allocation, and content moderation standards through bodies like ICANN, the IGF, and national regulatory authorities.
- **[[Data Governance]]** — policies and frameworks specifying how organisational data is collected, stored, shared, and deleted; underpins GDPR compliance and enterprise data quality programmes.
- **[[AI Governance and Ethics]]** — emerging frameworks for the oversight of AI systems, including the EU AI Act, NIST AI Risk Management Framework, and OECD AI Principles; addresses bias, explainability, [[Algorithmic Accountability]], and [[Risk Management]] across the AI lifecycle.
- **[[Decentralised Autonomous Organisation]] (DAO)** — on-chain governance via smart-contract voting, token-weighted proposals, and protocol upgrades; an experimental form bridging [[Blockchain]] infrastructure with collective decision-making.
- **Environmental governance** — international treaties (Paris Agreement, Montreal Protocol) coordinating state action on shared natural resources; exemplifies polycentric governance across jurisdictions.
- **Platform governance** — content moderation, terms-of-service enforcement, and appeals processes at social media and marketplace platforms; increasingly subject to legislative mandates (DSA, DMA in the EU).
- **Standards governance** — consensus-based rule-setting in bodies like ISO, W3C, IETF, and IEEE; governs interoperability, safety, and accessibility across global technology markets.
- **[[Public Administration]]** — the day-to-day implementation of policy by civil services; includes procurement governance, public financial management, and service delivery oversight.
- **Supply-chain governance** — auditing, certification, and traceability requirements ensuring ethical sourcing and regulatory compliance across multi-tier supplier networks.

### Standards and Context

- **ISO/IEC 38500:2024** — international standard for IT governance; provides principles and a model for boards and senior managers to evaluate, direct, and monitor the use of IT within organisations.
- **ISO 37000:2021** — governance of organisations standard; defines principles including purpose, value generation, strategy, responsibility, accountability, and stakeholder engagement.
- **OECD Principles on AI (2019, updated 2024)** — intergovernmental framework adopted by 46 countries establishing expectations for trustworthy AI; covers transparency, accountability, robustness, and human oversight. See [[OECD Principles on AI]].
- **EU AI Act (2024)** — the world's first comprehensive AI regulation, establishing risk tiers (unacceptable, high, limited, minimal) with corresponding governance obligations for providers and deployers.
- **NIST AI Risk Management Framework (AI RMF 1.0, 2023)** — voluntary US framework for managing AI-related risks across four functions: Govern, Map, Measure, Manage.
- **COBIT** — framework by ISACA for IT governance and management; widely adopted in enterprise and financial sector contexts.
- **GDPR (2018)** — EU regulation establishing data governance obligations including data protection by design, purpose limitation, and data subject rights; foundational to [[Data Governance]] practice.
- **Internet Governance Forum (IGF)** — UN-mandated multistakeholder dialogue forum on Internet policy; non-binding but influential in shaping global norms.
- Key governance research traditions:
  - Elinor Ostrom's polycentric governance theory (Nobel Prize 2009) — governing the commons through self-organised local institutions
  - Principal-agent theory — modelling delegation relationships and accountability gaps
  - Responsive regulation (Braithwaite and Ayres) — a pyramid of escalating enforcement responses
  - Deliberative democracy (Habermas) — legitimacy through reasoned public discourse

### Conceptual Distinctions

- **Governance vs Government** — government is a specific institution; governance is the broader set of processes that may include non-governmental actors.
- **Governance vs Management** — management concerns operational execution within an agreed framework; governance concerns setting that framework and holding management accountable. ISO 38500 draws this distinction explicitly.
- **Hard vs Soft Law** — hard law is binding (treaties, statutes, regulations); soft law (codes of conduct, principles, guidelines) relies on reputational and normative pressure. Both are tools of governance.
- **Regulatory vs Self-Regulatory Governance** — state regulation imposes external rules; self-regulation (industry codes, standards bodies) generates internal norms, often supplemented by co-regulation.
- **Adaptive Governance** — governance frameworks designed to update incrementally in response to new evidence or changed circumstances, particularly relevant for emerging technologies.

### Provenance

