Full container load (FCL) is an ocean container service in which the goods of a single shipper occupy the whole container.[^1]

Maersk, a container carrier, defines FCL as goods from a single shipper occupying the entire container, and names less-than-container load (LCL) as the other main type of containerised service.[^1] A Georgia Tech course glossary words it from the shipper's side: the shipper uses all the space in the container and packs it themselves.[^2] The freight forwarder Flexport describes an ocean shipment in which the cargo occupies a full container of any size, which can be stuffed at the supplier and trucked directly to the container yard.[^3]

## Scope and distinctions

Sources stress different features. Maersk's glossary entry says containers are charged a specific rate for ocean transit regardless of their contents, so a full container offers a better price per unit shipped than LCL.[^4] Flexport likewise says FCL shipments are charged at a flat rate per container.[^3] Read together, these entries describe exclusive use of a container paid for as a unit. They do not say that the container must be physically full, and none of the opened sources gives a minimum fill.[^1][^3][^4]

LCL is the contrast case. Flexport says an LCL shipment is consolidated with other LCL shipments into one container, and that because of the extra handling at the container freight station LCL costs more per unit than FCL once volume grows.[^5] Maersk's glossary adds that ocean rates for LCL are commonly higher per unit than for a full container load.[^4] The consolidation step is covered at [[Freight Consolidation]].

## Evidence limits

Opened sources are a carrier, a forwarder and a university course glossary. None is a legal or standards-body definition, and they do not address who bears liability for packing or what happens to a container shipped part-full.[^1][^2][^3]

[^1]: Maersk, “What is FCL?”. https://www.maersk.com/support/faqs/what-is-fcl
[^2]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Glossary”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/appendices/glossary.pdf
[^3]: Flexport, “FCL (Full Container Load)”. https://www.flexport.com/glossary/full-container-load/
[^4]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms
[^5]: Flexport, “LCL (Less than Container Load)”. https://www.flexport.com/glossary/less-than-container-load/

