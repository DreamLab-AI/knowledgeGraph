Sustainable supply chains are supply chains managed so that their environmental and social effects, as well as their cost and service, are taken into account, and the sources opened here describe the subject through its parts and not through one definition.[^1]

The UN Global Compact and BSR guide says companies attend to supply chain sustainability not only because of the inherent social and environmental risks and the governance challenges the supply chain poses, but also because of the many rewards it can deliver.[^1] It says sustainable supply chain management can be a strong driver of value and success, for business as much as for society.[^1] It also records that developing programmes that cover all four of the Global Compact's issue areas, human rights, labour, environment and anti-corruption, remains a daunting challenge for many.[^1]

## Strands in this branch

Emissions are accounted for by value chain: the GHG Protocol notes that by developing a scope 3 inventory, companies can identify where the largest energy, material and resource use is within the supply chain.[^2] See [[Supply Chain Environmental Accounting]], [[Scope 3 Emissions]] and [[Supply Chain Decarbonisation]].

Material loops are the concern of the circular economy, which the Ellen MacArthur Foundation describes as a system where materials never become waste and nature is regenerated.[^3] See [[Circular Supply Chain]], [[Reverse Logistics]] and [[Product Take-Back Scheme]].

Labour conditions are addressed by codes such as the Ethical Trading Initiative Base Code, which is founded on International Labour Organisation conventions and is described as an internationally recognised code of labour practice.[^4] See [[Ethical Sourcing]].

## Scope and limits

These sources are guidance and standards from different bodies, and they do not form a single framework. The Global Compact guide is a 2010 publication. The pages in this branch cover only the strands above, and pages on due diligence and sustainable procurement sit in the same branch.

[^1]: United Nations Global Compact and Business for Social Responsibility, 2010, “Supply Chain Sustainability: A Practical Guide for Continuous Improvement”. https://www.bsr.org/reports/BSR_UNGC_SupplyChainReport.pdf
[^2]: World Resources Institute and World Business Council for Sustainable Development, GHG Protocol, “Corporate Value Chain (Scope 3) Accounting and Reporting Standard”. https://ghgprotocol.org/sites/default/files/standards/Corporate-Value-Chain-Accounting-Reporing-Standard_041613_2.pdf
[^3]: Ellen MacArthur Foundation, “The Circular Economy: Definition & Model Explained”. https://www.ellenmacarthurfoundation.org/topics/circular-economy-introduction/overview
[^4]: Ethical Trading Initiative, “ETI Base Code”. https://www.ethicaltrade.org/eti-base-code

