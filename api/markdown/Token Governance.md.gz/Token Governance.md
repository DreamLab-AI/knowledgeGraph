A decision-making mechanism for blockchain protocols and DAOs in which voting power is allocated in proportion to holdings of a governance token, so that proposals — parameter changes, treasury spending, protocol upgrades — are ratified by token-weighted ballots executed through smart contracts, trading the legitimacy problems of plutocratic weighting against the sybil resistance and skin-in-the-game that stake-based voting provides.

### Semantic Classification

### Content

## Definition

**Token governance** is the coordination mechanism by which holders of a protocol's [[Governance Token]] collectively steer the protocol: one token, one vote (or a weighted variant), tallied and often executed automatically by [[Smart Contract]]. It emerged from the early DAO experiments on Ethereum and was standardised by DeFi protocols — Compound's Governor contracts, MakerDAO's executive votes, and Aave's proposal lifecycle became reference implementations that hundreds of projects now reuse. A typical flow runs: temperature-check discussion on a forum, formal on-chain proposal (gated by a proposal threshold), voting period with quorum requirements, timelock delay, then automatic execution.

The design rests on a deliberate trade-off. Weighting votes by stake provides sybil resistance — identities are free to create, but tokens are not — and aligns decision power with economic exposure to the outcome. The cost is plutocracy: large holders (funds, founders, exchanges voting custodial balances) can dominate outcomes, and empirical studies of major DAOs repeatedly find Gini coefficients above 0.9 for voting power. Low turnout compounds this; most proposals in large DAOs are decided by a handful of delegates. Mitigations include vote delegation (making a liquid representative layer), vote-escrow models (veCRV-style time-locking that weights commitment as well as stake), [[Quadratic Voting]] experiments that price marginal votes superlinearly, and bicameral designs that pair token votes with councils or citizen-house structures.

Beyond protocol parameters, token governance has become the allocation machinery for substantial treasuries — Uniswap, Arbitrum, and Optimism each govern multi-billion-dollar treasuries through token votes — which makes it a principal channel for [[Public Goods Funding]] in the Ethereum ecosystem (retroactive funding rounds, grants programmes) and a live subject for securities and DAO-liability law.

## Current Landscape

- **Security councils are now standard**: to prevent execution of harmful proposals, most large DAOs run an elected multisig council — e.g. Arbitrum's 12-member Security Council (9-of-12 threshold) — with equivalents at Optimism, ENS, Compound, Uniswap and ZKsync (DAOstar, 2025).
- **Executive-body drift (2025)**: Arbitrum's April 2025 "A Vision for the Future" shifted executive power toward an elected Operational Coordination Body (OpCo); Optimism stood up a Budget Board (May 2025-May 2026) and, from August 2025, made its Developer Advisory Board the primary approver of protocol upgrades.
- **Plutocracy is formally unavoidable**: "The Impossibility of Anti-Plutocratic DAO Governance" (arXiv, 2025) proves no wallet-balance voting rule resists Sybil splitting; replaying five major DAOs it measured Sybil amplification of 1,172x-4,039x under quadratic voting, and showed a ~$300M Uniswap vote capturable for roughly $75K in token and gas costs.
- **Delegation concentration persists**: Uniswap's treasury-delegation programme (rounds since December 2023) and evidence that a16z-affiliated parties attract disproportionate delegations (arXiv 2503.11940) keep centralisation a live concern.
- **Reference stacks**: OpenZeppelin Governor, Compound Governor Bravo, and Aave Governance V3 dominate on-chain execution; Snapshot handles gasless off-chain signalling for thousands of projects.
- **Hybrid trends**: vote-escrow tokenomics, non-transferable participation weight, futarchy pilots, and legal wrappers (Wyoming DAO LLCs, Cayman foundations) that bind on-chain votes to off-chain legal effect.

  **Sources**:

- https://daostar.org/research/delegating_decentralization.pdf
- https://arxiv.org/html/2605.18990v1
- http://arxiv.org/pdf/2503.11940.pdf
- https://docs.arbitrum.foundation/gentle-intro-dao-governance

