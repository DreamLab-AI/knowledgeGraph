The Bank for International Settlements (BIS) is an international financial institution owned by 63 member central banks, founded in 1930 and headquartered in Basel, Switzerland. It acts as banker to central banks, providing settlement, custody, and asset management services while fostering monetary and financial cooperation through research, policy forums, and standard-setting committees. The BIS hosts the Basel Committee on Banking Supervision, the Financial Stability Board secretariat, and the Committee on Payments and Market Infrastructures, which together produce globally binding prudential and operational standards such as the Basel Accords and CPMI principles. Through the BIS Innovation Hub it actively researches central bank digital currencies, tokenisation of financial assets, and cyber resilience for financial market infrastructures.

### Overview

- The BIS occupies a unique position at the apex of the global [[Financial System]]: it is simultaneously a bank, a research institution, a standard-setter, and a policy forum.
- Unlike the [[International Monetary Fund]] or [[World Bank]], the BIS does not lend to governments or intervene in currency markets. Its shareholders and clients are exclusively central banks.
- With 63 member central banks representing roughly 95 per cent of world GDP, the BIS provides an authoritative multilateral channel for harmonising approaches to [[Financial Regulation]], [[Prudential Regulation]], and [[Financial Stability]].
- Its annual and quarterly publications — the BIS Annual Economic Report, the BIS Quarterly Review, and Working Paper series — are among the most cited in international finance and macroeconomics.
- The institution operates from Basel but maintains Innovation Hub centres in Hong Kong, Singapore, London, Stockholm, Toronto, Eurosystem, and other jurisdictions, enabling geographically distributed research into digital finance.

### Key Components

- **Basel Committee on Banking Supervision (BCBS)**
  - Produces the [[Basel Accords]] (Basel I, II, III, and ongoing reforms), which define minimum [[Capital Adequacy Framework]] requirements, liquidity standards (LCR, NSFR), and leverage ratios for internationally active banks.
  - Sets the global floor for [[Prudential Regulation]], shaping domestic banking laws in over 100 jurisdictions.
  - Post-2008 reforms under Basel III substantially reshaped [[Systemic Risk Management]] in the banking sector.
- **Financial Stability Board (FSB)**
  - Secretariat hosted by the BIS; coordinates [[Financial Stability]] policy across G20 economies.
  - Monitors and makes recommendations to mitigate [[Systemic Risk Management]] vulnerabilities, including shadow banking, crypto assets, and climate-related financial risk.
- **Committee on Payments and Market Infrastructures (CPMI)**
  - Develops principles and standards for [[Payment System]] infrastructure and financial market infrastructure (FMI) oversight.
  - Works closely with IOSCO on Principles for Financial Market Infrastructures (PFMIs), foundational to [[Financial Infrastructure]] resilience.
- **BIS Innovation Hub**
  - Established in 2019; delivers proof-of-concept projects in [[Central Bank Digital Currency]], [[Tokenisation]] of financial assets, [[RegTech]], and [[Cyber Resilience]].
  - Key project clusters: Project Nexus ([[Cross-Border Payments]]), Project Mariana (FX settlement with CBDC), Project mBridge (multi-CBDC platform), Project Icebreaker (retail CBDC interoperability).
  - Collaborates openly with central banks, [[International Monetary Fund]], and academic institutions.
- **Monetary and Economic Department (MED)**
  - Produces macroeconomic research on [[Monetary Policy Implementation]], inflation dynamics, financial cycles, and the intersection of [[Financial Technology]] with monetary transmission.
  - Maintains the BIS Statistics portal, the world's largest public repository of international banking and securities data.
- **Banking Department**
  - Manages central bank reserve assets and executes foreign-exchange transactions.
  - Provides emergency short-term liquidity to member central banks, acting as a lender-of-last-resort backstop at the supra-national level.

### Mechanisms

- **Reserve Management** — BIS holds and invests foreign currency reserves on behalf of member central banks, requiring the highest credit quality and liquidity standards, effectively setting a benchmark for sovereign reserve management.
- **BIS Papers & Consultations** — policy guidance is disseminated through consultative documents, final standards, and working papers that drive regulatory change via the standard-setter–member-regulator pipeline.
- **Basel Process** — a formal cycle of consultation, quantitative impact study, finalisation, and national transposition that translates BCBS standards into domestic law, governing [[Capital Adequacy Framework]] globally.
- **Innovation Hub Sprints** — time-boxed prototype experiments test feasibility of novel financial infrastructure concepts using [[Distributed Ledger Technology]], [[Tokenisation]], or AI-assisted [[Prudential Regulation]] tools.
- **Committee Plenary Governance** — BCBS, CPMI, and Markets Committee decisions are made by consensus among member representatives, ensuring legitimacy and broad adoption without formal treaty obligations.

### Applications and Use Cases

- **Global Banking Regulation** — Basel III capital and liquidity standards, transposed into EU (CRR/CRD), US (Basel Endgame rules), and other jurisdictions, directly govern how trillions in bank capital are structured.
- **Cross-Border Payment Reform** — BIS-led G20 roadmap for enhancing [[Cross-Border Payments]] targets to reduce cost, increase speed and transparency; Project Nexus and mBridge are live multi-jurisdictional experiments.
- **CBDC Design** — BIS research and Innovation Hub projects provide central banks with architectural blueprints for retail and wholesale [[Central Bank Digital Currency]], influencing national CBDC design in the EU, UK, India, Brazil, and beyond.
- **Systemic Risk Monitoring** — FSB secretariat functions enable early warning identification of vulnerabilities in shadow banking, crypto markets, and interconnected global financial networks.
- **Reserve Asset Stewardship** — central banks collectively entrust hundreds of billions in reserves to the BIS banking department for safe, liquid investment, avoiding commercial counterparty risk.
- **RegTech & SupTech Research** — Innovation Hub explores machine-readable regulation and automated supervisory reporting, bridging [[RegTech]] innovation with central bank oversight mandates.

### Standards and Context

- **Basel Accords** — Basel I (1988), Basel II (2004), Basel III (2010–2017), and subsequent finalisation packages are the cornerstone outputs of the BIS-hosted BCBS, governing global bank [[Capital Adequacy Framework]] and liquidity risk.
- **Principles for Financial Market Infrastructures (PFMIs)** — joint CPMI–IOSCO standard defining resilience requirements for payment systems, central securities depositories, and central counterparties, foundational to [[Financial Infrastructure]] oversight.
- **FSB Key Attributes of Effective Resolution Regimes** — guides national implementation of bank resolution frameworks to prevent taxpayer bail-outs, a direct output of FSB work hosted at the BIS.
- **BIS Cyber Resilience Guidelines** — used by central banks and financial market infrastructures to benchmark operational resilience programmes, linking to [[Cyber Resilience]] best practice.
- **CPMI Fast Payments Toolkit** — supports jurisdictions in designing instant retail [[Payment System]] infrastructure in alignment with international standards.
- **Regulatory relationship** — the BIS has no formal treaty enforcement powers; its influence operates through consensus norms, reputational pressure, and the expectation that G20 members transpose BCBS/FSB standards into domestic law.

### Provenance

