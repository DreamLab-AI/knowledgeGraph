Aptos is a Layer 1 proof-of-stake blockchain platform founded in 2022 by former Diem (Meta) engineers, designed for safety, scalability, and high throughput. It employs the Move programming language — a resource-oriented, formally verifiable language originally created for the Diem project — to express accounts, digital assets, and smart contracts. Its primary performance innovation is Block-STM (Software Transactional Memory), a parallel transaction execution engine that speculatively executes transactions and resolves conflicts at runtime, enabling high concurrent throughput without requiring developers to pre-declare access sets. The network uses a Byzantine Fault Tolerant consensus mechanism (AptosBFT, derived from HotStuff) to reach finality with low latency.

### Overview

- Aptos emerged from the ashes of Meta's discontinued [[Diem]] stablecoin initiative. Core engineers — including Mo Shaikh (CEO) and Avery Ching (CTO) — incorporated Aptos Labs in 2022 and open-sourced the network the same year, completing mainnet launch in October 2022.
- The blockchain's core value proposition rests on three pillars:
  - **Safety through [[Move Programming Language]]**: Move's linear type system prevents common vulnerabilities such as reentrancy and double-spend bugs. Resources (analogous to assets) cannot be duplicated or accidentally destroyed, only moved.
  - **Performance through [[Parallel Execution]]**: The [[Block-STM]] engine (Software Transactional Memory applied to blockchain) allows validators to execute transactions in parallel without developer-supplied hints, dynamically detecting and re-executing conflicting transactions.
  - **Reliability through [[Byzantine Fault Tolerance]]**: [[AptosBFT]] provides deterministic finality with a rotating leader scheme, tolerating up to one-third malicious validators.
- The native token APT is used for transaction fees, staking, and on-chain governance.

### Key Components

#### Move Programming Language

- [[Move Programming Language]] is a statically typed, resource-oriented language originally designed for the [[Diem]] project at Meta. Resources in Move are first-class types that can only be moved, not copied or dropped, making it structurally impossible to double-spend a digital asset.
- Move Prover, an optional formal verification tool, allows developers to write mathematical specifications alongside code and verify them at compile time, bridging to the domain of [[Formal Verification]].
- Modules (analogous to [[Smart Contract]]s) are deployed to accounts and can be upgraded or frozen by their publishers.

#### Block-STM Parallel Execution Engine

- [[Block-STM]] adapts [[Software Transactional Memory]] — a concurrency control technique from systems programming — to blockchain transaction execution.
- Within a block, transactions are ordered by the proposer but executed speculatively in parallel by all validators. A scheduler tracks read/write sets; if a transaction reads a value later written by an earlier transaction, it is re-executed with the updated value.
- This removes the need for developers to manually specify access lists (unlike Solana's account model), lowering developer complexity while still enabling high parallelism.

#### AptosBFT Consensus

- [[AptosBFT]] is a proof-of-stake [[Consensus Mechanism]] derived from the HotStuff BFT protocol, with enhancements for leader reputation scoring and fast reconfiguration.
- Validators stake APT tokens and take turns proposing blocks. The protocol achieves single-round-trip finality in the optimistic case, targeting latency under one second on a live network.
- Stake delegation allows token holders who are not operating validators to participate in consensus security and earn rewards.

#### Account and Storage Model

- Aptos uses an account-based model where each account is a unique 32-byte address, and all state (modules, resources, events) is stored under that address in a global key-value store.
- The global state is authenticated via a [[Merkle Tree]] (specifically a Jellyfish Merkle Tree), enabling efficient light-client proofs.
- Accounts must be created explicitly (funded to cover storage), distinguishing Aptos from account-free UTXO models.

#### Tokenomics and Governance

- [[Tokenomics]]: APT has a fixed initial supply with a small annual inflation rate directed to validator and staker rewards.
- On-chain governance proposals can modify network parameters, upgrade framework modules, and adjust economic policy — all gated by APT stake-weighted voting.

### Applications and Use Cases

#### Decentralised Finance (DeFi)

- The low-latency finality and high throughput make Aptos suitable for decentralised exchanges ([[Decentralised Finance]]), lending protocols, and automated market makers where stale prices are costly.
- Projects such as Liquidswap and Thala Finance deploy on Aptos to exploit parallel execution for order-book matching and liquidity management.

#### Non-Fungible Tokens and Digital Assets

- The Aptos Token Standard (part of the Aptos Framework) defines [[Non-Fungible Token]] and fungible asset primitives directly in Move, with composable metadata and royalty enforcement.
- The [[Digital Asset]] standard introduced in 2023 unifies NFT and fungible token handling under a single Move module, simplifying wallet and marketplace integration.

#### Enterprise and Institutional Applications

- Aptos's formal verification tooling appeals to financial institutions exploring [[Smart Contract]] deployment for settlement, tokenised securities, and cross-border payments.
- Microsoft partnered with Aptos Labs to explore AI-enhanced blockchain experiences, bridging to the [[Artificial Intelligence]] domain.

#### Gaming and Consumer Applications

- Move's ownership semantics map naturally to in-game item ownership, enabling game studios to issue and transfer assets with provable scarcity without the reentrancy risks common on the Ethereum Virtual Machine.

#### Interoperability

- Bridges such as LayerZero and Wormhole connect Aptos to other [[Blockchain Network]]s, enabling cross-chain asset transfers and liquidity sharing.

### Contrast with Sibling Chains

- **vs [[Ethereum]]**: Ethereum uses the EVM and sequential execution (moving toward parallelism via sharding/rollups); Aptos achieves native parallelism at the base layer with Move rather than Solidity.
- **vs [[Solana]]**: Solana requires developers to declare account access lists upfront (Sealevel model); Aptos's [[Block-STM]] infers access sets dynamically, reducing developer burden. Both target high throughput with different safety trade-offs.
- **vs [[Sui]]**: Both Aptos and [[Sui]] derive from the [[Diem]] codebase and use [[Move Programming Language]], but they diverge on object model (Sui uses object-centric ownership), consensus (Sui uses Bullshark/Narwhal DAG-based), and storage design. The two represent competing visions for post-Diem Move ecosystems.

### Standards and Context

- Move language specification is maintained in the `move-language` open-source repository under the Apache 2.0 licence.
- The Aptos Framework (stdlib) is versioned on-chain; governance proposals can upgrade framework modules, meaning the canonical standard evolves via on-chain vote rather than off-chain hard-fork.
- Aptos Improvement Proposals (AIPs) serve the same role as Ethereum EIPs — tracking standards, protocol changes, and community consensus processes.
- Security audits of the Move VM and Aptos Framework have been conducted by Trail of Bits and other firms, contributing to the network's security posture as a [[Cryptographic Proof]]-anchored system.

### Provenance

