
An execution budget is a constraint on the financial expenditure for a task.[^1] The ontology's class is named `Budget`.

The class is declared in the execution-context module. An [[Execution Environment]] reaches it through `hasBudget`. Two datatype properties describe it: `amount`, a decimal, and `currency`, a string for which the ontology gives examples such as `USD` and `EUR`.

The budget is a monetary ceiling, not a limit on computation. Limits on memory or CPU belong to a [[Resource Constraint]], and limits on request frequency to [[Rate Limiting]]. The ontology does not state whether a budget is cumulative or per call, or what happens when it is exhausted. visionGraph places the concept beneath [[Resource Constraint]].

[^1]: Semantic Agent Communication Community Group, “Execution Context Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/execution-context.ttl

