DSCSA compliance means meeting the requirements of the United States Drug Supply Chain Security Act, which FDA says outlines steps to an interoperable and electronic way to identify and trace certain prescription drugs at the package level as they move through the supply chain.[^1]

FDA's guidance says the Act was signed into law on 27 November 2013 and added section 582 to the Federal Food, Drug, and Cosmetic Act, which established product tracing, product identifier, authorised trading partner and verification requirements for manufacturers, repackagers, wholesale distributors and dispensers.[^2] The HHS Office of Inspector General summarises the core duty as requiring trading partners to create a record of each drug product transaction.[^3]

## What the Act requires

The Act defines a product identifier as a standardised graphic that carries the standardized numerical identifier, lot number and expiration date in both human-readable form and a machine-readable data carrier.[^4] The standardized numerical identifier combines the National Drug Code for the specific product, including its package configuration, with a unique alphanumeric serial number of up to 20 characters.[^4] See [[Product Serialisation]].

Section 582(g)(1) sets the enhanced drug distribution security requirements, which take effect ten years after enactment. Transaction information and transaction statements must be exchanged in a secure, interoperable, electronic manner, the transaction information must include the product identifier at the package level, and systems for verification of product at the package level are required.[^4]

## Timing

FDA announced in August 2023 a one-year stabilisation period, until 27 November 2024, to let trading partners implement, troubleshoot and mature their electronic interoperable systems, and said it did not intend to enforce the section 582(g)(1) requirements during that time.[^5] It added that the period should not be viewed as a justification for delaying efforts to comply.[^5] The pages opened for this entry do not show what FDA did after November 2024.

## Related pages

DSCSA is one of the laws grouped at [[Traceability Regulation]], and the drugs it covers move through the [[Pharmaceutical Supply Chain]].[^1] The Act requires the machine-readable carrier to conform to standards developed by a widely recognized international standards development organization; identifiers in general are covered at [[Supply Chain Identifier]].[^4]

## What the sources do not establish

A 2017 inspector general report predates the electronic requirements. It found that all 31 selected wholesalers exchanged tracing information but that a standardised way to exchange it had not emerged, so it does not describe current practice.[^3] No opened source says which technology trading partners must use, or how many comply today.

[^1]: US Food and Drug Administration, “Drug Supply Chain Security Act (DSCSA)”. https://www.fda.gov/drugs/drug-supply-chain-integrity/drug-supply-chain-security-act-dscsa
[^2]: US Food and Drug Administration, “Enhanced Drug Distribution Security Requirements Under Section 582(g)(1) of the Federal Food, Drug, and Cosmetic Act – Compliance Policies”. https://www.fda.gov/media/171592/download
[^3]: US Department of Health and Human Services Office of Inspector General, “Drug Supply Chain Security: Wholesalers Exchange Most Tracing Information”, report OEI-05-14-00640, September 2017. https://oig.hhs.gov/reports/all/2017/drug-supply-chain-security-wholesalers-exchange-most-tracing-information/
[^4]: US Congress, Drug Quality and Security Act, Public Law 113-54 (GovInfo text). https://www.govinfo.gov/content/pkg/PLAW-113publ54/html/PLAW-113publ54.htm
[^5]: US Food and Drug Administration, “DSCSA compliance policies establish 1-year stabilization period for implementing electronic systems”, 30 August 2023. https://www.fda.gov/drugs/drug-alerts-and-statements/dscsa-compliance-policies-establish-1-year-stabilization-period-implementing-electronic-systems

