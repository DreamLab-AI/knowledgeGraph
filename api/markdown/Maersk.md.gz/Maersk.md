Maersk, formally A.P. Moller - Maersk, is a transport and logistics group headquartered in Copenhagen whose core activity is container liner shipping. The European Commission described it in 2022 as an integrated transport and logistics company headquartered in Copenhagen with worldwide activities, whose core activities comprise container liner shipping through its subsidiaries Maersk A/S, SeaLand and Hamburg Süd, container terminal services, inland transportation, inland services, supply chain management services, harbour towage and reefer container manufacturing.[^1]

## What Maersk says it does

Maersk's own site says that, since 1904, it has helped customers navigate change and uncertainty, and that by connecting ocean, land and air it helps keep supply chains moving.[^2] It states that A.P. Moller - Maersk's vision is to become the Global Integrator, offering integrated logistics solutions that connect, protect and simplify customers' supply chains.[^2] That is a statement of intent, and the Commission's description is the independent account of what the group did at the time.[^2][^1]

## Role in the supply chain

Maersk is an [[Ocean Carrier]]: container liner shipping is its core activity in the Commission's description.[^1] The Alphaliner operator list, which ranks lines by fleet and orderbook capacity in TEU, consolidates Maersk A/S, Hamburg Sud and the SeaLand brands under the Maersk name, which agrees with the subsidiaries the Commission names.[^3][^1] The same decision lists inland and supply chain management services, which places the group among the integrated carriers that offer transportation alongside forwarding and logistics, as the Industrial Ontologies Foundry describes such organisations.[^1][^4]

See [[Container Shipping]] and [[Supply Chain Blockchain]] for related pages. In this vault Maersk is a class under the carrier role, not an individual.

## What the sources do not establish

The Commission's description dates from a 2022 decision, and the group's structure may have changed since. The sources opened give no fleet, capacity or revenue figures: the Alphaliner page shows its ranking only as a graph that the text of the page does not carry, and the UNCTAD market-share tables could not be opened, so no ranking against other lines is stated. The 1904 date appears only on Maersk's own page, which does not say that the group was founded then.[^2][^3]

[^1]: European Commission, Case M.10559 A.P. Moller-Maersk / Senator International, decision of 29 March 2022. https://ec.europa.eu/competition/mergers/cases1/202238/M_10559_8500254_440_3.pdf
[^2]: A.P. Moller - Maersk, About page. https://www.maersk.com/about
[^3]: Alphaliner (AXS Marine), PublicTop100 page, consolidated operator notes. https://alphaliner.axsmarine.com/PublicTop100/
[^4]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

