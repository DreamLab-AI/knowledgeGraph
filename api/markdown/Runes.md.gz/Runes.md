Runes is a protocol for issuing fungible tokens directly on the Bitcoin blockchain, using the transaction model and recorded in the witness data. It launched at the Bitcoin halving in April 2024.

### Semantic Classification

### Content

- Runes is a fungible token protocol for Bitcoin created by the developer behind Ordinals, designed to issue and transfer tokens using Bitcoin's unspent transaction output model. Token operations are encoded in transaction outputs, with issuance and balances tracked by indexers that follow the protocol rules.
- Launched at the April 2024 halving, Runes offered a more efficient alternative to earlier token standards on Bitcoin and drove substantial transaction activity and fees. It sits alongside Ordinals inscriptions as part of a wave of asset issuance on the Bitcoin base layer.

### Provenance

