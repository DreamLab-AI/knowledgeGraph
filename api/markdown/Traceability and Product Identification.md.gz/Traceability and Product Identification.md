Traceability and product identification is the area concerned with following goods through a supply chain and with the identifiers and data carriers that make that possible.[^1][^2]

GS1 states that traceability is the ability to trace the history, application or location of an object, quoting ISO 9001:2015, and that it can relate to the origin of materials and parts, the processing history, and the distribution and location of the product after delivery.[^1] The UN Global Compact guide gives the original ISO definition of traceability as the ability to identify and trace the history, distribution, location and application of products, parts and materials.[^2]

## Identification

GS1 ID Keys enable organisations to assign standard identifiers to entities such as products, documents and locations, and because they are globally unique they can be shared between organisations.[^3] The GS1 Global Traceability Standard notes that instance-level identification, combining a product number with a serial number, makes it possible to identify each product instance individually.[^1]

## Data carriers

GS1 Digital Link is the standardised method for encoding identifiers such as GTINs, GLNs and SSCCs, along with batch numbers, serial numbers and expiry dates.[^4] The Electronic Product Code is syntax for unique identifiers that can be encoded in forms suitable for RFID tags and in text forms for data sharing between enterprise systems.[^5] The Ecodesign for Sustainable Products Regulation defines a data carrier as a linear barcode symbol, a two-dimensional symbol or other automatic identification medium, and a unique product identifier as a string of characters that identifies a product and enables a web link to its digital product passport.[^6]

## Legal duties

Regulation (EC) No 178/2002 requires that the traceability of food, feed and substances intended to be incorporated into them be established at all stages of production, processing and distribution.[^7] See [[Supply Chain Traceability]] and [[Traceability]].

## Scope and limits

Pages in this branch cover [[Critical Tracking Event]], [[Chain of Custody Model]], [[Supply Chain Provenance]], [[Supply Chain Transparency]] and [[Supply Chain Visibility]]. The sources do not agree on one framework: GS1 is a standards body, the Global Compact guide is sustainability guidance and the regulations are law, and none states how they fit together.

[^1]: GS1, Global Traceability Standard Release 2.0 (ratified August 2017), “GS1 Global Traceability Standard”. https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard
[^2]: United Nations Global Compact and BSR, 2014, “A Guide to Traceability: A Practical Approach to Advance Sustainability in Global Supply Chains”. https://www.unglobalcompact.org/docs/issues_doc/supply_chain/Traceability/Guide_to_Traceability.pdf
[^3]: GS1, “GS1 identification keys”. https://www.gs1.org/standards/id-keys
[^4]: GS1, “GS1 Digital Link”. https://www.gs1.org/standards/gs1-digital-link
[^5]: GS1, RFID. https://www.gs1.org/standards/rfid
[^6]: European Parliament and Council of the European Union, Regulation (EU) 2024/1781 of 13 June 2024, “Regulation (EU) 2024/1781 of the European Parliament and of the Council establishing a framework for the setting of ecodesign requirements for sustainable products”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1781
[^7]: European Parliament and Council of the European Union, Regulation (EC) No 178/2002 of 28 January 2002, “Regulation (EC) No 178/2002 of the European Parliament and of the Council laying down the general principles and requirements of food law”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32002R0178

