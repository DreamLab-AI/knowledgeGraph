Supply chain visibility is the ability of an organisation to see what is happening in its supply chain, including who is involved, where goods are and what risks exist, and the sources opened here describe it in three ways without one agreed definition.[^1][^2]

Sedex defines visibility beyond tier 1 as an organisation's ability to understand and monitor the suppliers that sit behind its direct suppliers, including tier 2, tier 3 and further upstream entities.[^1] In simple terms, it says, this means knowing who is involved, where they are located and what risks may exist, even without a direct commercial relationship.[^1] The article is from a practitioner body. See [[Multi-Tier Supply Chain Mapping]].

## Event data

GS1 describes EPCIS as its flagship data sharing standard for enabling visibility, within organisations and across an entire supply chain of trading partners and other stakeholders.[^2] It says the standard helps provide the what, when, where, why and how of products and other assets, enabling the capture and sharing of information about status, location, movement and chain of custody.[^2] GS1's traceability standard says its approach uses open standards to provide visibility of objects relevant to supply chains.[^3] See [[GS1 EPCIS]].

## Visibility and risk

Christopher and Peck state that upstream and downstream visibility is often very poor, which adds to supply chain risk, and they list among the characteristics of a critical path linkages where visibility is poor, meaning little or no shared information between nodes.[^4] They propose creating a high level of supply chain intelligence, a greater visibility of upstream and downstream risk profiles.[^4] See [[Supply Chain Risk and Resilience]].

## Scope and limits

Visibility is the internal view of a chain, while [[Supply Chain Transparency]] concerns disclosure and [[Supply Chain Traceability]] the tracing of goods. None of the sources measures how visible a typical supply chain is.

[^1]: Sedex (Supplier Ethical Data Exchange), article, “Supply Chain Visibility Beyond Tier 1: How to Achieve It”. https://www.sedex.com/blog/supply-chain-visibility-beyond-tier-1/
[^2]: GS1, “EPCIS & CBV”. https://www.gs1.org/standards/epcis
[^3]: GS1, Global Traceability Standard Release 2.0 (ratified August 2017), “GS1 Global Traceability Standard”. https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard
[^4]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content

