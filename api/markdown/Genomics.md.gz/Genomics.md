Genomics is the study of the complete set of genetic material in organisms, encompassing the structure, function, evolution, and editing of genomes. It combines high-throughput DNA sequencing with computational analysis to interpret vast quantities of genetic data. Genomics underpins precision medicine, evolutionary biology, agriculture, and the increasing application of machine learning to biological sequence interpretation.

### Overview

- Genomics expanded from the study of individual genes to the analysis of entire genomes once high-throughput sequencing made large-scale data generation feasible. The field is intrinsically data-intensive: a single genome comprises billions of base pairs, and population-scale studies generate datasets that demand specialised storage, alignment, and statistical methods. Machine learning increasingly drives variant interpretation, functional annotation, and the prediction of biological structure and function from sequence.

### Key aspects

- High-throughput sequencing produces raw reads that are aligned and assembled into genomes.
- Variant calling identifies differences between an individual genome and a reference.
- Functional genomics links sequence to gene expression and biological function.
- Computational pipelines and learned models annotate and interpret genomic features at scale.

### Applications

- Precision medicine tailoring treatment to an individual's genetic profile.
- Accelerating drug discovery by identifying disease-associated targets.
- Crop and livestock improvement through genomic selection.
- Tracing evolutionary relationships and pathogen surveillance.

### Provenance

