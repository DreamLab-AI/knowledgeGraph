The EU Union Customs Code (UCC) is Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013, which lays down the general rules and procedures applicable to goods brought into or taken out of the customs territory of the Union.[^1]

The Regulation says the Code applies uniformly throughout the customs territory of the Union, without prejudice to international law and conventions and Union legislation in other fields.[^1] The European Commission says it entered into force on 1 May 2016 with some transitional arrangements still applying, and that it aims at a paperless and fully automated customs union.[^2]

## Content

The Regulation is organised in titles. One covers the factors on which import or export duty is applied, including the Common Customs Tariff and tariff classification of goods, the origin of goods and the value of goods for customs purposes.[^1] It defines customs legislation as the Code and its implementing provisions, the Common Customs Tariff, the Union system of reliefs from customs duty and applicable international agreements.[^1]

Storage procedures comprise customs warehousing and free zones, and no limit applies to how long goods may remain under such a procedure.[^1] See [[Bonded Warehouse]] and [[Free Trade Zone]]. Articles 38 and 39 govern the status of authorised economic operator, with types for customs simplifications and for security and safety; see [[Authorised Economic Operator]].[^1]

## Scope and distinctions

The UCC is an example of [[Customs Regulation]] at regional level. It applies to the customs territory of the Union and not to every EU rule on goods, since Union legislation in other fields continues to apply.[^1] It belongs alongside international instruments such as the [[WTO Trade Facilitation Agreement]], and relates to [[Customs Trade Facilitation]] and [[Regulatory Compliance]].

## Evidence and corrections

This page rests on two EU sources, the Official Journal text on EUR-Lex and the Commission's overview, which share a registrable domain, so it does not have two fully independent origins. The earlier body listed declarations, tariff classification, valuation and origin rules. The text supports each: it requires goods placed under a customs procedure, with the exception of the free zone procedure, to be covered by a customs declaration, and its titles cover tariff classification, origin and customs value.[^1] The Commission says electronic processing is the aim.[^2]

## What the sources do not establish

No opened source gives the current state of the electronic systems the Commission is building, which the Commission says are still being completed, or how national authorities apply the Code in practice.

[^1]: European Union, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^2]: European Commission, Taxation and Customs Union, Union Customs Code page. https://taxation-customs.ec.europa.eu/customs/union-customs-code_en

