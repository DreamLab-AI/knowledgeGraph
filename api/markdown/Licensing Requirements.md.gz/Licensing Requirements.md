Licensing Requirements are the regulatory authorisation mandates imposed on virtual asset service providers by national or supranational regulators, ranging from state-level money transmitter licences in the United States to jurisdiction-specific crypto licences under EU MiCA, UK FCA, Singapore MAS, and Dubai VARA regimes. Compliance demands operational standards, minimum capital, custody controls, KYC procedures, AML programmes, and ongoing regulatory reporting, with global coverage costing major platforms tens to hundreds of millions of pounds.

### Semantic Classification

### Content

- Licensing requirements for cryptocurrency businesses represent one of the most significant regulatory and financial barriers to entry in the digital asset industry. Jurisdictions worldwide have established diverse licensing frameworks requiring virtual asset service providers to obtain authorisation before offering services like exchange, custody, payment processing, or token issuance. These regimes impose substantial capital requirements, operational standards, personnel qualifications, and ongoing compliance obligations—with costs ranging from hundreds of thousands to tens of millions of dollars depending on scope and geography.

### Major Licensing Regimes

#### United States - State-Level Money Transmitter Licences

- **State Money Transmitter Licensing**: Unlike most jurisdictions with national frameworks, the US requires separate licences in each state where a crypto business operates
  - **Coverage**: 48 states plus DC require money transmitter licences for cryptocurrency exchanges (Montana and Wyoming exempt certain activities)
  - **Cost**: Application fees range from $500 (some states) to $5,000+ (New York BitLicense). Total cost for nationwide coverage: $5-15 million including:
    - Application fees: $100,000-$300,000 across all states
    - Legal counsel and consultants: $2-5 million
    - Surety bonds: $1-3 million annually (varies by transaction volume)
    - Net worth/capital requirements: $1-10 million minimum depending on states
    - Compliance infrastructure: $2-5 million initial setup
  - **Timeline**: 12-24 months for nationwide coverage; individual states vary from 3-18 months
  - **Renewal**: Annual or biennial renewals costing $200,000-$500,000 annually for nationwide operations
- **Examples**:
  - [[Coinbase]] maintains licences in 49+ US jurisdictions; estimated compliance cost $20-30 million annually
  - [[Kraken]] operates in 47 states; chose not to pursue BitLicense, blocking New York customers
  - [[Gemini Multimodal Language Model]] holds BitLicense and 49 state licences; invested $30+ million establishing US regulatory infrastructure

#### New York BitLicense

- **Structure**: New York's Department of Financial Services ([[NYDFS]]) created the first dedicated cryptocurrency licensing regime in 2015
- **Requirements**:
  - Application fee: $5,000
  - Minimum capital: No statutory minimum, but NYDFS expects $500,000-$5 million depending on business model
  - Comprehensive compliance programme including AML, cybersecurity, consumer protection, business continuity
  - Personal background checks for all principals, directors, and key employees
  - Detailed business plan, financial projections, and operational documentation (500-2000 pages typical)
- **Track Record**: Only 50 BitLicences issued between 2015-2024 (compared to 1,500+ applications)
  - Approval rate: ~3-5%
  - Timeline: 18-36 months average processing time; some applications pending 4+ years
  - Many applicants withdrew, citing costs exceeding $1-2 million and unclear approval standards
- **Notable Holders**: [[Coinbase]], [[Gemini Multimodal Language Model]], [[Paxos]], [[Circle]], [[Bitstamp]], [[eToro]], [[Robinhood Crypto]], [[PayPal]]
- **"BitLicense Exodus"**: High costs and slow approvals led many startups to exclude New York from service areas, creating crypto industry concerns about regulatory overreach

#### United Kingdom - FCA Registration

- **Financial Conduct Authority ([[FCA]]) Registration**: Required for crypto asset businesses under Money Laundering Regulations 2017 (amended 2020)
- **Requirements**:
  - Application fee: £2,000-£10,000 depending on firm size and complexity
  - No minimum capital requirement, but must demonstrate financial resources adequate for operations
  - "Fit and proper" tests for senior management and controlling shareholders
  - Comprehensive AML systems, policies, and procedures
  - Ongoing reporting and annual fees: £1,000-£10,000+
- **Track Record**: Exceptionally high rejection rate
  - 2020-2024: Over 300 applications; ~75 approved (~25% approval rate)
  - 75%+ rejection/withdrawal rate due to:
    - Inadequate financial crime controls
    - Insufficient senior management expertise
    - Unclear business models or unacceptable risk profiles
    - Inability to demonstrate adequate capitalization
- **Timeline**: 12-24 months for approval; FCA introduced "pools" system prioritising complete applications
- **Cost**: £500,000-£2 million total including legal, compliance infrastructure, and personnel
- **Notable Approvals**: [[Coinbase]], [[Gemini Multimodal Language Model]], [[eToro]], [[Revolut]], [[Blockchain.com]], [[Copper.co]], [[Crypto.com]] (cryptoasset registration August 2022; EMI authorisation December 2023), [[Kraken]] (cryptoasset registered; EMI authorisation March 2025)
- **Rejections/Withdrawals**: [[Binance]] (rejected 2021), [[Luno]] (initially rejected, later approved)

#### Singapore - MAS Licensing

- **Monetary Authority of Singapore ([[MAS]]) Payment Services Act**: Covers digital payment token services under 2020 Payment Services Act
- **Licence Types**:
  - **Standard Payment Institution (SPI)**: For monthly transaction volumes ≤S$3 million (~$2.2M USD)
  - **Major Payment Institution (MPI)**: For monthly volumes >S$3 million; more stringent requirements
- **Requirements**:
  - Application fee: S$1,000 (standard) to S$10,000 (major)
  - Minimum base capital: S$250,000 (SPI), S$1 million (MPI)
  - Technology risk management, cybersecurity standards
  - AML/CFT programmes meeting international standards
  - Physical presence in Singapore with local management
- **Track Record**: Highly selective
  - ~100 applications received; only ~20 approved by 2024 (~20% approval rate)
  - MAS granted "exemptions" to some firms (2-year grace periods) whilst evaluating applications
  - Many applications remain pending 2-3 years
- **Timeline**: 12-36 months; MAS emphasises thoroughness over speed
- **Cost**: S$2-5 million (~$1.5-3.7M USD) including application, capital, compliance infrastructure, and local presence
- **Notable Approvals**: [[Coinbase]], [[Crypto.com]], [[Gemini Multimodal Language Model]], [[Independent Reserve]], [[Coinhako]]
- **Rejections**: MAS rejected several unnamed applicants for inadequate AML controls and governance

#### European Union - MiCA CASP Authorisation

- **Markets in Crypto-Assets Regulation ([[BC-0484-markets-in-crypto-assets]])**: Creates harmonised EU-wide licensing; CASP provisions fully applicable from 30 December 2024, with transitional periods for existing firms running to 1 July 2026 in most member states (some member states, e.g., Netherlands, applied shorter transitions ending July 2025); after 1 July 2026, operating without CASP authorisation for EU clients constitutes a breach of EU law
- **Crypto-Asset Service Provider (CASP) Authorisation**:
  - **Application**: Submit to home member state regulator; authorisation valid across all 27 EU member states (passporting rights); as of mid-2026, over 40 full CASP authorisations granted, including Kraken (Luxembourg CSSF), Binance (first full CASP secured 2025), and Bitpanda (Austria FMA)
  - **Capital Requirements**: Vary by service type:
    - Exchange/trading platform: €150,000 minimum
    - Custody services: €150,000 minimum
    - Multiple services: €150,000-€730,000 depending on combination
    - Major issuers/platforms: Up to €2 million
  - **Additional Requirements**:
    - Insurance or comparable guarantee: €250,000-€5 million
    - Governance standards including independent risk and compliance functions
    - Conflict of interest policies, client asset segregation, business continuity plans
    - Technical standards for cybersecurity, data protection, operational resilience
- **Timeline**: 6-12 months expected approval timeframe; full enforcement deadline for most member states 1 July 2026
- **Cost**: €1-5 million for comprehensive CASP authorisation including legal, compliance, capital, and ongoing operational costs
- **Transitional Provisions**: Firms with existing national licences (e.g., German BaFin licence) have an 18-month transition period to apply for CASP authorisation; member states adopting the full 18-month period (ending July 2026) include France, Malta, Luxembourg, and Estonia
- **Expected Impact**: Consolidation of 27 national regimes into single framework, reducing compliance costs for EU-wide operations by 30-50% versus current multi-jurisdiction licensing

#### Other Significant Jurisdictions

- **Japan - Payment Services Act (PSA)**: Crypto exchanges must register with [[FSA]] (Financial Services Agency)
  - Capital requirement: ¥10 million (~$67,000) base; ¥100 million (~$670,000) for major platforms
  - Strict cybersecurity and hot/cold wallet requirements following [[Coincheck]] hack (2018, $530M stolen)
  - Timeline: 6-18 months; FSA approved ~30 exchanges by 2024
  - Cost: $1-3 million including application, capital, security infrastructure
- **Switzerland - FINMA Licensing**: Swiss Financial Market Supervisory Authority ([[FINMA]]) oversight
  - Banking licence or securities dealer licence typically required for comprehensive services
  - Capital requirements: CHF 1.5-10 million (~$1.7-11.3M USD) depending on licence type
  - "Crypto Valley" in Zug attracts many firms; favourable tax treatment
  - Notable licensees: [[SEBA Bank]], [[Sygnum Bank]] (first crypto banks), [[Bitcoin Suisse]]
- **Hong Kong - SFC Licensing**: Securities and Futures Commission ([[SFC]]) regulates platforms offering securities tokens
  - Type 1 (dealing) and Type 7 (automated trading) licences required
  - Capital requirement: HK$5-10 million (~$640K-1.28M USD)
  - Only professional investors allowed (minimum HK$8M portfolio); retail access extremely limited
  - Timeline: 12-24 months; only 2 licences granted initially (2020-2022), regime expanded 2023

### Application Process and Requirements

#### Documentation and Disclosure

- **Business Plan**: Comprehensive 50-200 page document detailing:
  - Target market, customer segments, geographical scope
  - Products and services (exchange, custody, staking, lending, etc.)
  - Revenue model and financial projections (3-5 years)
  - Technology infrastructure and cybersecurity measures
  - Compliance programme architecture
  - Growth strategy and scaling plans
- **Financial Information**:
  - Audited financial statements (2-3 years if existing business)
  - Capitalisation plan and proof of funds
  - Insurance coverage details
  - Financial projections with stress testing scenarios
- **Personnel Background Checks**:
  - Detailed personal history for all directors, officers, controlling shareholders
  - Criminal background checks, credit reports, regulatory history
  - Demonstration of "fit and proper" character and competence
  - Relevant experience in financial services, compliance, or technology
- **Compliance Programme Documentation**:
  - [[BC-0481-anti-money-laundering]] (AML) policies and procedures (50-300 pages)
  - [[BC-0480-kyc-requirements]] (KYC) customer verification processes
  - [[BC-0487-compliance-monitoring]] transaction monitoring systems
  - [[BC-0486-regulatory-reporting]] suspicious activity reporting procedures
  - Cybersecurity policies, incident response plans
  - Consumer protection measures, complaints handling
- **Legal Structure and Ownership**:
  - Corporate structure charts showing all related entities
  - Ownership breakdown to ultimate beneficial owners (UBOs)
  - Identification of any shareholders with >10% or >25% stakes (varies by jurisdiction)
  - Demonstration of financial crime risk from ownership structure

#### Technical and Operational Standards

- **Cybersecurity Requirements**: Regulators increasingly mandate specific technical controls
  - Multi-signature wallets for hot wallet funds
  - Cold storage for majority of customer assets (80-95% typical)
  - Penetration testing (annually or semi-annually)
  - Bug bounty programmes for major platforms
  - SOC 2 Type II or ISO 27001 certification
  - Incident response and breach notification procedures
- **Business Continuity and Disaster Recovery**:
  - Redundant infrastructure across multiple geographic locations
  - Regular backup and recovery testing (monthly/quarterly)
  - Documented recovery time objectives (RTOs) and recovery point objectives (RPOs)
  - Crisis management and communication plans
- **Financial Resource Requirements**:
  - Minimum capital based on business model and risk profile
  - Additional capital buffers for operational risk
  - Insurance coverage for cybersecurity, professional indemnity, crime
  - Segregated customer funds in trust accounts or similar arrangements

#### Ongoing Obligations Post-Licensing

- **Reporting Requirements**:
  - Annual audited financial statements
  - Quarterly or monthly operational reporting (transaction volumes, customer counts, incidents)
  - Material change notifications (new products, ownership changes, key personnel departures)
  - Compliance programme effectiveness reports
- **Examination and Audit**:
  - Periodic on-site regulatory examinations (every 1-3 years typical)
  - Third-party compliance audits (annual for major platforms)
  - Remediation of identified deficiencies within specified timelines
- **Fee Structures**:
  - Annual renewal fees based on transaction volume, customer count, or asset size
  - US state licences: $10,000-$100,000 annually per state
  - UK FCA: £1,000-£50,000+ annually based on size
  - Singapore MAS: S$10,000-S$100,000+ annually

### Costs and Timeline Analysis

#### Small Platform (Targeting Single Jurisdiction)

- **Target**: Single-country operation, 10,000-50,000 customers
- **Licensing Costs**:
  - Application and legal fees: $200,000-$500,000
  - Minimum capital: $250,000-$1 million
  - Compliance infrastructure: $300,000-$700,000
  - Insurance: $50,000-$150,000 annually
  - Personnel (compliance officers, legal): $200,000-$500,000 annually
- **Total First-Year Cost**: $1-2.85 million
- **Timeline**: 12-24 months from application to approval

#### Medium Platform (Multi-Jurisdiction)

- **Target**: Regional operation (e.g., EU-wide, or US multi-state), 500,000-2M customers
- **Licensing Costs**:
  - Multiple applications and legal fees: $2-5 million
  - Capital requirements: $3-10 million
  - Compliance infrastructure: $3-8 million
  - Insurance: $500,000-$2 million annually
  - Personnel (15-30 compliance FTE): $1.5-3 million annually
- **Total First-Year Cost**: $10-28 million
- **Timeline**: 18-36 months for multi-jurisdiction coverage

#### Large Platform (Global Operation)

- **Target**: Global or multi-regional (US + EU + Asia), 5M+ customers
- **Licensing Costs**:
  - Global legal and application fees: $10-20 million
  - Capital requirements: $20-50 million (varies significantly by jurisdictions)
  - Compliance infrastructure: $15-40 million
  - Insurance: $5-15 million annually
  - Personnel (100-200 compliance FTE): $10-20 million annually
- **Total First-Year Cost**: $60-145 million
- **Timeline**: 24-48 months for comprehensive global licensing
- **Examples**:
  - [[Coinbase]] estimated spending $150+ million on global licensing and compliance infrastructure (2017-2021)
  - [[Binance]] announced $200+ million compliance investment (2021-2023) including licensing applications across 15+ jurisdictions
  - [[Crypto.com]] reportedly invested $100+ million in global licensing efforts (2020-2024)

### Challenges and Strategic Considerations

#### Regulatory Fragmentation

- **No Global Passport**: Unlike traditional finance where some jurisdictions recognise foreign licences, crypto licensing is almost entirely jurisdiction-specific
  - EU MiCA provides first major "passporting" regime (licence in one EU country valid across all 27 member states)
  - Limited mutual recognition elsewhere; separate applications required for US, UK, Singapore, Japan, etc.
  - Result: Platforms serving global customers face $50-150 million licensing costs
- **Conflicting Requirements**: Jurisdictions impose incompatible standards
  - Privacy laws (e.g., [[GDPR]]) vs US disclosure requirements create data handling conflicts
  - Some jurisdictions ban privacy coins ([[Monero]], [[Zcash]]); others permit with enhanced monitoring
  - Capital requirements vary 100x across jurisdictions (from tens of thousands to tens of millions)

#### Approval Uncertainty

- **Low and Variable Approval Rates**:
  - UK FCA: ~25% approval rate
  - Singapore MAS: ~20% approval rate
  - New York BitLicense: ~3-5% approval rate
- **Prolonged Processing**: Applications often exceed stated timelines by 6-18 months
  - Regulators frequently request additional information, restart "clock" on review periods
  - Some jurisdictions lack sufficient expertise to evaluate complex crypto business models
  - Political and regulatory environment shifts can freeze applications mid-process
- **Sunk Costs**: Applicants invest $500,000-$5 million before learning of rejection
  - Limited feedback on rejection reasons (regulators often cite "fit and proper" concerns without specifics)
  - Difficult to appeal or reapply; substantial reputational damage from public rejections

#### Strategic Licensing Approaches

- **Jurisdictional Prioritisation**: Firms select high-value markets and defer or skip challenging jurisdictions
  - [[Kraken]] skipped New York (BitLicense) but prioritised UK, EU, Australia, Singapore
  - Many platforms exclude US entirely, focusing on EU and Asia-Pacific
  - Cost-benefit analysis: Is $2M BitLicense worth accessing New York market vs serving customers from neighbouring states?
- **Offshore Licensing**: Some firms obtain licences in crypto-friendly jurisdictions and impose geographic restrictions
  - [[Binance]] historically used Malta, Cayman Islands; faced criticism for "regulatory arbitrage"
  - [[FTX]] used Bahamas as headquarters; collapsed in 2022 partly due to weak regulatory oversight
  - Regulatory trend toward blocking offshore-licensed platforms serving local customers without domestic licence
- **Acquisitions**: Buying licensed entities faster and sometimes cheaper than organic licensing
  - [[Kraken]] acquired [[Bit Trade]] (Australia's oldest licensed exchange) for Australian market access in 2023
  - [[Coinbase]] acquired authorised Japanese exchange [[Tsubasa Group]] in 2021
  - Typical premium: 2-5x book value, reflecting licensing value

#### Ongoing Compliance Burden

- **Regulatory Changes**: Licences require continuous adaptation to new rules
  - [[BC-0485-travel-rule]] implementation (2020-2023) required $1-5M infrastructure upgrades for most platforms
  - MiCA (fully applicable December 2024, transitional period ending July 2026) forcing relicensing for 1,000+ EU crypto firms
  - Ongoing regulatory costs often exceed initial licensing costs over 5-year periods
- **Staff Retention**: Compliance expertise scarce and expensive
  - Compliance officers with crypto experience command $150,000-$300,000 salaries (senior roles $250,000-$500,000)
  - High turnover (30-40% annually) due to industry growth and competing offers
  - Training new compliance staff takes 6-12 months to full productivity

### Real-World Licensing Examples

#### Success Cases

- **Coinbase**: Pursued comprehensive global licensing strategy
  - Holds money transmitter licences in 49 US jurisdictions including BitLicense
  - FCA registration in UK (among first approved)
  - MAS licence in Singapore, BaFin registration in Germany, licences in Ireland, Japan, Brazil, Australia
  - Estimated $200+ million invested in global licensing infrastructure (2012-2024)
  - Strategy enabled public company status (NASDAQ: COIN, 2021) and institutional credibility
- **Gemini**: Emphasised regulatory compliance as competitive differentiator
  - Founded by [[Winklevoss]] twins with stated "regulation-first" approach
  - BitLicense (among first granted, 2016), 49 state licences, UK FCA, Singapore MAS
  - Positioned as "most regulated" exchange, attracting institutional clients and earning trust designation
  - However, faced regulatory action in 2023 regarding [[Earn programme]] (unregistered securities), showing compliance complexity
- **Crypto.com**: Rapid global expansion through licensing
  - Obtained licences in 15+ major jurisdictions (2020-2024)
  - Singapore MAS (2022), Dubai VARA licence (2022), UK FCA cryptoasset registration (August 2022), UK FCA Electronic Money Institution (EMI) authorisation (December 2023)
  - Aggressive marketing and sponsorship spending ($100M+ annually) funded partly by international licensing enabling market access

#### Challenge Cases

- **Binance**: Faced regulatory scrutiny due to initial resistance to licensing
  - Operated globally without comprehensive licences (2017-2021), facing regulatory action in UK, Germany, Japan, Thailand
  - FCA rejected UK application (2021); Binance served UK customers without authorisation
  - Major compliance transformation (2021-2024): hired 700+ compliance staff, pursued licences in 15+ jurisdictions
  - Settled with US authorities for $4.3 billion (2023), with licensing deficiencies central to charges
  - Demonstrates consequences of operating without appropriate authorisation
- **FTX**: Obtained Bahamian licence but lacked major market authorisations
  - [[Digital Assets and Registered Exchanges Act]] (DARE) licence in Bahamas (primary headquarters)
  - Limited US state licences; operated partly through affiliated entities
  - Collapse (2022) highlighted risks of weak regulatory oversight and offshore licensing
  - Subsequent investigations revealed Bahamian regulators lacked resources and expertise to supervise complex operations
- **Kraken**: Selective licensing strategy created tensions with regulators
  - Chose not to pursue BitLicense, blocking New York customers (ongoing)
  - Withdrew UK FCA application (2020), re-applied (2022), received FCA Electronic Money Institution (EMI) authorisation (March 2025) after multi-year process; also listed on FCA cryptoasset register
  - Settled with SEC over staking services (2023, $30M), highlighting compliance gaps despite state licences
  - Demonstrates even partially licensed platforms face enforcement risk

### Best Practices for Licensing Success

#### Pre-Application Preparation

- **Regulatory Engagement**: Proactive dialogue with regulators before formal application
  - Pre-application meetings to clarify expectations and address novel business model elements
  - Participation in regulatory sandboxes or innovation hubs (offered by FCA, MAS, ADGM, others)
  - Industry association membership ([[Global Digital Finance]], [[Crypto Council for Innovation]]) for regulatory guidance
- **Comprehensive Gap Analysis**: Identify compliance gaps 6-12 months before application
  - Independent consultant review of systems against regulatory standards
  - Remediation of identified deficiencies before application submission
  - Documented remediation projects demonstrate commitment to compliance
- **Sufficient Capitalisation**: Ensure financial resources exceed minimum requirements
  - Regulators favour applications showing 150-200% of minimum capital requirements
  - Demonstrates sustainability through application process and initial operational period
  - Include capital for unexpected compliance costs and remediation

#### Application Excellence

- **Complete Documentation**: Submit comprehensive applications minimising regulator follow-up questions
  - Anticipate regulator concerns and address proactively in initial submission
  - Clear, concise explanations of complex technical or business model elements
  - Professional formatting and organisation (table of contents, executive summary, appendices)
- **Experienced Personnel**: Recruit compliance and legal leadership before application
  - Regulators assess personnel as heavily as policies; proven expertise critical
  - Consider seconding personnel from traditional financial institutions or regulatory agencies
  - Advisory boards with former regulators demonstrate commitment and provide guidance
- **Technology Demonstration**: Provide detailed technical architecture documentation
  - System architecture diagrams, data flow maps, API documentation
  - Cybersecurity controls mapped to recognised frameworks (NIST, ISO 27001)
  - Live demonstrations or sandbox environments for regulator review

#### Post-Application Management

- **Responsive Communication**: Prioritise timely, complete responses to regulator inquiries
  - Assign dedicated point of contact for regulatory communications
  - Internal SLAs for regulator responses (e.g., 48-72 hours for initial acknowledgment)
  - Escalation procedures ensuring senior leadership involvement in complex questions
- **Continuous Improvement**: Demonstrate ongoing enhancement of compliance programme
  - Regular updates to regulators on programme improvements even during application review
  - Proactive notification of material changes or incidents
  - Adoption of emerging best practices and international standards

#### Post-Licensing Sustainability

- **Independent Compliance Function**: Establish compliance as independent reporting to board/CEO
  - Prevent conflicts between business development and regulatory adherence
  - Adequate budget and authority to implement necessary controls
  - Direct escalation path to board for significant compliance concerns
- **Regulatory Horizon Scanning**: Continuous monitoring of regulatory developments
  - Participation in industry working groups and regulatory consultations
  - Subscription to regulatory intelligence services
  - Internal regulatory change management process ensuring timely adaptation

### Future Licensing Trends

#### Harmonisation Efforts

- **Regional Standardisation**: Movement toward common frameworks within regions
  - EU MiCA represents most advanced harmonisation; reduces 27 national regimes to single framework
  - ASEAN exploring regional crypto framework across Singapore, Thailand, Malaysia, Philippines, Indonesia
  - Latin America standardisation discussions (Mexico, Brazil, Argentina) in early stages
- **International Standards**: Global bodies developing recommended frameworks
  - [[FATF]] standards on virtual assets increasingly adopted as baseline
  - [[IOSCO]] recommendations on crypto asset regulation influencing jurisdictions
  - [[Basel Committee]] capital requirements for bank crypto exposure creating indirect licensing pressure

#### Activity-Based Licensing

- **Granular Authorisations**: Shift from "all or nothing" to modular licensing
  - MiCA allows firms to seek authorisation for specific services (exchange vs custody vs advice)
  - Reduces capital requirements and complexity for specialised providers
  - Enables gradual expansion: start with one service, add others over time
- **Risk-Based Thresholds**: Lighter requirements for lower-risk activities
  - Singapore's SPI vs MPI based on transaction volume
  - Smaller firms face reduced compliance burdens
  - Encourages innovation whilst maintaining oversight of systemically important platforms

#### Technology-Enabled Licensing

- **Regulatory Sandboxes**: Temporary authorisations for testing innovative products
  - UK FCA, Singapore MAS, UAE ADGM, others offer sandbox programmes
  - Typical duration: 6-12 months; limited customer base; close regulator monitoring
  - Successful sandboxes can streamline full licensing applications
- **Automated Compliance Reporting**: Real-time regulatory data feeds replacing periodic reports
  - Regulators developing APIs for continuous compliance monitoring
  - Reduces reporting burden whilst improving oversight
  - Platforms like [[Chainalysis]] offer direct regulator integrations

#### DeFi Licensing Challenges

- **Decentralised Protocol Regulation**: Regulators struggling to apply licensing to DeFi
  - Who must obtain licence: protocol developers, DAO governance, frontend operators, liquidity providers?
  - MiCA attempts to address via "reverse solicitation" provisions and frontend operator responsibilities
  - US SEC taking enforcement approach (e.g., [[Uniswap Labs]] Wells notice) rather than clear licensing framework
- **Permissioned DeFi**: Emergence of licensed DeFi platforms
  - [[Aave Arc]], [[Compound Treasury]] offer KYC-gated DeFi with licensed intermediaries
  - Hybrid models: permissionless protocol base layer, permissioned interface layer
  - May represent future of institutional DeFi adoption

    #### Related Concepts

- [[BC-0479-regulatory-compliance]] - Overall compliance framework
  - [[BC-0480-kyc-requirements]] - KYC requirements for licensing
  - [[BC-0481-anti-money-laundering]] - AML programme requirements
  - [[BC-0486-regulatory-reporting]] - Reporting obligations under licences
  - [[BC-0487-compliance-monitoring]] - Monitoring systems for licence holders
  - [[BC-0484-markets-in-crypto-assets]] - EU MiCA licensing framework
  - [[BC-0490-cross-border-compliance]] - Multi-jurisdiction licensing
  - [[BC-0489-consumer-protection]] - Consumer protection under licensing
  - [[BitLicense]] - New York's cryptocurrency licence
  - [[FCA]] - UK Financial Conduct Authority
  - [[MAS]] - Monetary Authority of Singapore
  - [[Money Transmitter Licence]] - US state licensing requirements

### Provenance

