A GS1 identification key is a numeric or alphanumeric string that incorporates a GS1 Prefix, GS1 Company Prefix or GS1-8 Prefix and is the basis of the unique GS1 identifiers defined for areas such as trade, logistics and asset management.[^1]

GS1 says there are 12 identification keys defined by its General Specifications.[^2] They include the Global Trade Item Number for products and services, the Global Location Number for parties and locations, and the Serial Shipping Container Code for logistics units.[^2] To build a key, an organisation must become a member of GS1 and obtain a GS1 Company Prefix.[^2] Because the keys are globally unique, they can be shared between organisations.[^2]

## Key and identifier

The General Specifications separate two terms. A key may identify a class of entities, such as a trade item, or an instance of an entity, such as a logistic unit.[^1] The term “GS1 identification key” is used for broad communications such as marketing, licensing and policy, while the term GS1 identifier is used for greater precision at the technical level.[^1]

A key can be extended. The Global Trade Item Number with a batch or lot number is the GS1 identifier for a product grouped by production batch, and the same number with a serial number is the identifier for a serialised product.[^1] The extensions are covered at [[Batch Number]] and [[Product Serialisation]].

## In practice

GS1 keys are one family of [[Supply Chain Identifier]] types. GS1 lists each key against what it identifies, and three of them have their own pages here: [[Global Trade Item Number]], [[Global Location Number]] and [[Serial Shipping Container Code]].[^2]

## What the sources do not establish

Both sources are published by GS1, the body that maintains the keys, so this page rests on one standards body. They do not compare the keys with identification schemes from other bodies, and they do not give adoption figures.[^1][^2]

[^1]: GS1, “GS1 General Specifications Standard”, release 26.0. https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf
[^2]: GS1, “GS1 identification keys”. https://www.gs1.org/standards/id-keys

