A curated register of active and accessible funding opportunities for immersive technology, AI, and creative industries R&D, encompassing Innovate UK grants, UKRI programmes, ARIA challenges, Web3 venture capital, and academic grant schemes. The register tracks application status, eligibility constraints, match-funding requirements, and strategic alignment to accelerate project funding decisions.

### Semantic Classification

### Content

- [AI Upskilling fund: application guide - GOV.UK (www.gov.uk)](https://www.gov.uk/government/publications/flexible-ai-upskilling-fund/ai-upskilling-fund-application-guide)
- [Academic Grant Program for Researchers | NVIDIA](https://www.nvidia.com/en-us/industries/higher-education-research/academic-grant-program/?ncid=em-targ-342785-vt16&nvweb_e=XCXFtpRd6n5AWWMXfLopRj_3gB6jRKBo2XIIoE1sfSByqD3i3Swq7aHhfdSErl3JyUgncxjVobAxF51L1AagAQ&mkt_tok=MTU2LU9GTi03NDIAAAGVfrG7xsBKlLS-OJmzdiTGGSrDFZm53xsTZDdLnhn2gJRMONWqXFXfreGwLdYNKOutcVcFpReCANeJu3KlswjJDpeGbtidQUubIJJKOoamKUDcunQsv90) [[MUST]]
- [Creative Catalyst 2024 GOV-UK Find a grant (find-government-grants.service.gov.uk)](https://find-government-grants.service.gov.uk/grants/creative-catalyst-2024-1)
- Visionflow rejection 2 [Application overview
  - flossverse:reflow
  - Innovation Funding Service (apply-for-innovation-funding.service.gov.uk)](https://apply-for-innovation-funding.service.gov.uk/application/10103573/summary)
- Visionflow rejection 1 [Application overview
  - VisionFlow
  - Innovation Funding Service (apply-for-innovation-funding.service.gov.uk)](https://apply-for-innovation-funding.service.gov.uk/application/10079297/summary)
- GPT for the next bid [ChatGPT
  - Structured exploration
  - main daily driver (openai.com)](https://chat.openai.com/g/g-QjexzLwl7-structured-exploration-main-daily-driver/c/1e89a96d-a186-4ba7-99ee-faa81a4db621)
- [Prototyping, Impact and Assessment Research and Development Grants (round two) - XR Network+ (xrstories.co.uk)](https://xrnetworkplus.xrstories.co.uk/grant/prototyping-impact-and-assessment-research-and-development-grants-round-two/)

# The Lab

- [Creative Industries Policy & Evidence Centre | Calling for a UK… (pec.ac.uk)](https://pec.ac.uk/news/calling-for-a-uk-centre-for-ai-and-the-creative-industries)
- [Connected tech: AI and creative technology: Government Response to the Committee’s Eleventh Report of Session 2022–23
  - Culture, Media and Sport Committee (parliament.uk)](https://publications.parliament.uk/pa/cm5804/cmselect/cmcumeds/441/report.html)
- [ ] Talk to FuzzyDuck
- [ ] Get NVIDIA and/or Microsoft buy in
- [ ] Talk to Badger and Coombes
- [ ] Talk to Immersive
- [ ] Start application document
- [x] Finances meeting with Marco

  ![KnowherePrevious.pdf](assets/KnowherePrevious_1706709691210_0.pdf)

  - [ChatGPT
  - Structured exploration
  - main daily driver (openai.com)](https://chat.openai.com/g/g-QjexzLwl7-structured-exploration-main-daily-driver/c/43c2aa80-a317-40b2-b842-283611fceb62)
  - [MITIH Project Grant Application.docx](assets/MITIH_Project_Grant_Application_1706695237566_0.docx)
  - [MITIH_ Risk Register .docx](assets/MITIH_Risk_Register_1706695247428_0.docx)
  - [IUK Official
  - Claim Validation Guidance.docx](assets/IUK_Official_-_Claim_Validation_Guidance_1706695268541_0.docx)
  - [InnnovateUK Company Finance workbook (1).xlsm](assets/InnnovateUK_Company_Finance_workbook_(1)_1706695277680_0.xlsm)
    - This needs to be paid for.
  - **Timing**
    - April May start time, run to December?
    - Calendar Quarterly invoicing with no latency paid by the Landing. Invoicing
    - Evidence all of the subcontractor, time sheeting.
    - Consider taking on the PAYE for simple accounting simplicity. The BAU vs the project can be gnarly.
  - **Collaborator list**
    - FuzzyDuck
      - It's claim in arrears.
      - FuzzyDuck match fund approx £20k?
      - Fuzzyduck NEEDS to have £30k in the bank to cover the match fund at bid time.
      - Subcontract should be Manchester based (percentages).
      - The other funders (future things) can then slice into this across the project.
    - Immersive
      - Location based events product analysis for approx £7k
    - Badger and Coombes
      - Attention tracking in live sports events £3k to develop product pack
    - Co-investment needs to be £100k from a major over 5 years, as a commitment that isn't necessarily serviced.
      - Microsoft?
        - James knows.
      - Nvidia? Talk to Pete.
      - Anyone who has invested in the project up to this point counts against the £200k
      - That can be a live project.
  - Put hardware under materials not capital depreciation
- [Open Opportunities for UK Creative Industries | LinkedIn](https://www.linkedin.com/pulse/open-opportunities-uk-creative-industries-emma-cooper/)
- [Scaling Compute – AI at 1/1000th the cost
  - Aria](https://www.aria.org.uk/scaling-compute/)
- Finish the application [TIC Manchester AI Accelerator
  - Pitch Deck Submission Form (typeform.com)](https://capenterprise.typeform.com/to/a96YE4NG)
- [New funding supports UK artists to work with immersive tech – UKRI](https://www.ukri.org/news/new-funding-supports-uk-artists-to-work-with-immersive-tech/#:~:text=The%20programme%20will%20give%20artists,their%20ideas%20off%20the%20ground)
- https://iuk.ktn-uk.org/programme/european/horizon-europe/?
- [a16z opensource](https://a16z.com/2023/08/30/supporting-the-open-source-ai-community/)
- Stability
- [Web3 funding giants](https://codygarrison.notion.site/Web3-VC-Database-2022-de9c391f8dd14a8a9a3e01a69f4e0b7f)
- [snapdragon](https://www.qualcomm.com/products/application/xr-vr-ar/snapdragon-metaverse-fund)
- [SeeLegal site](https://seedlegals.com/raise/raise-series-a-round/)
- [Academy software foundation membership](https://www.aswf.io/join/)
- Pitch deck
- [Sequoia deck template guide](https://www.slideshare.net/PitchDeckCoach/sequoia-capital-pitchdecktemplate)
- [Reddit startup guide](https://www.reddit.com/r/startups/comments/87j7ap/how_to_make_a_pitch_deck_follow_along_as_i/)
- [£9 million funding will train data visualisat | EurekAlert!](https://www.eurekalert.org/news-releases/1037518)

  ## AI Upskilling

## Creative catalyst

## XRStories

### MITIH

#### Inputs

#### Outputs

### Things to sort

### Needs an external accountant for the due diligence.

### ARIA

## Turing Innovation Catalyst

## UKRI immersive tech

## Horizon Europe

### Provenance

