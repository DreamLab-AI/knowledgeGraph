An interoperability protocol is a formally specified set of rules, message formats, sequencing constraints, and coordination mechanisms that enable independently implemented systems, networks, or platforms to exchange information and invoke services without requiring shared internal architecture or governance. Such protocols define both syntactic structure and semantic contracts so that heterogeneous participants can interact predictably and verifiably. Interoperability protocols range from low-level wire formats to high-level semantic agreements, and form the foundational connective tissue of distributed computing ecosystems including blockchain networks, spatial computing platforms, AI service meshes, and cross-organisational data exchanges. Their design and governance determine whether digital infrastructure remains open and composable or becomes fragmented and extractive.

### Overview

- Interoperability protocols emerge wherever heterogeneous systems must cooperate without sharing a common codebase, vendor, or governance structure. The defining characteristic is the formal, public nature of the protocol contract: rules are specified in documents (RFCs, W3C Recommendations, OpenAPI schemas) that any implementer can reference independently.
- The protocol stack spans multiple layers of abstraction:
  - **Wire format layer** — how bytes are serialised (e.g. Protocol Buffers, MessagePack, JSON, CBOR)
  - **Transport layer** — how connections are established and maintained (TCP/IP, WebSockets, QUIC)
  - **Session/application layer** — how requests, responses, and errors are structured (HTTP, gRPC, GraphQL)
  - **Semantic layer** — what the exchanged data means (JSON-LD contexts, OWL ontologies, OpenAPI schemas)
  - **Trust layer** — how participants authenticate and authorise (OAuth 2.0, DID Auth, W3C Verifiable Credentials)
- What elevates a protocol to an *interoperability* protocol is governance-neutral, open specification and formal conformance testing — properties that allow independent implementations to coexist without central coordination.
- The economic and strategic significance of interoperability protocols is enormous: open protocols enable market competition and ecosystem growth, whereas proprietary integration paths create [[Vendor Lock-In]] and extract rents from dependent systems.

### Key Mechanisms

- **Message framing and encoding** — interoperability protocols define canonical serialisation of structured data so that a sender's encoding can be decoded unambiguously by any conformant receiver. Common formats include JSON, XML, CBOR, and Protobuf, each with tradeoffs in compactness, human-readability, and schema enforcement.
- **Schema and type contracts** — protocols attach semantic meaning to messages through schema languages ([[JSON Schema]], XSD, Avro, Thrift). Without shared schemas, syntactic agreement does not guarantee semantic interoperability.
- **Versioning and negotiation** — long-lived protocols must evolve. Mechanisms such as version handshakes, capability negotiation (as in HTTP/2 ALPN), and semantic versioning allow backward-compatible evolution without breaking deployed implementations.
- **Error handling and idempotency** — protocols specify error codes, retry semantics, and idempotency guarantees so that distributed participants can reason about partial failures without inconsistent state.
- **Security envelope** — transport-layer security (TLS), message signing, and capability tokens are integral to interoperability protocols in adversarial environments. [[Verifiable Credential]] and [[Decentralised Identifier]] layers extend trust into decentralised settings.
- **Proof and attestation mechanisms** — blockchain interoperability protocols (e.g. IBC, CCIP) incorporate cryptographic proofs (Merkle proofs, zero-knowledge proofs) so that receiving chains can verify claims about remote chain state without trusting a centralised relay.

### Taxonomy of Interoperability Protocols

- **Network transport protocols** — IP, TCP, UDP, QUIC: foundational; not application-level but prerequisite infrastructure for all higher-layer interoperability.
- **Application-layer protocols** — HTTP/REST, gRPC, WebSockets, MQTT; define request/response semantics over transport.
- **Data exchange formats** — OpenAPI, JSON-LD, GraphQL SDL, Avro, Parquet; define the semantic contract of data payloads.
- **Identity and trust protocols** — [[Decentralised Identifier]] (W3C DID), [[Verifiable Credential]] (W3C VC), [[OAuth 2.0]], OpenID Connect; specify how principals authenticate and authorise across system boundaries.
- **Blockchain cross-chain protocols** — [[Inter-Blockchain Communication]] (IBC/Cosmos), Chainlink CCIP, LayerZero, Polkadot XCM; address the specific challenge of atomic cross-ledger state transitions.
- **Spatial computing protocols** — [[OpenXR]] (Khronos, runtime API for XR devices), [[Universal Scene Description]] (USD/Pixar-Apple), glTF (Khronos, 3D asset exchange); enable cross-vendor scene and asset portability.
- **AI and agent protocols** — W3C ActivityPub, [[Agent Communication Language]] (ACL/FIPA), emerging [[Model Context Protocol]] (MCP) and [[Agent-to-Agent Protocol]]; specify how software agents advertise capabilities, delegate tasks, and share beliefs.
- **Data governance protocols** — DCAT, ODRL, PROV-O; encode dataset metadata, rights, and provenance in machine-readable form for cross-organisational data exchange.

### Applications and Use Cases

- **Blockchain ecosystems** — Cosmos IBC enables token transfers and cross-chain queries between independent proof-of-stake blockchains by specifying light-client verification and packet relay semantics. Chainlink CCIP extends this to EVM chains with off-chain computation. These protocols make [[Decentralised Finance]] composable across chains.
- **Spatial and extended reality** — [[OpenXR]] allows a single XR application binary to run on headsets from multiple vendors (Meta Quest, HTC Vive, Microsoft HoloLens) without platform-specific code paths. USD and glTF allow 3D scenes authored in Blender, Maya, or Unreal Engine to be exchanged across tools and renderers, enabling a nascent [[Metaverse]] layer.
- **AI service meshes** — MCP (Anthropic's Model Context Protocol) defines how LLM inference engines expose tools to orchestrators, enabling [[Multi-Agent System]] architectures where specialised agents advertise capabilities in a machine-readable registry. This is an emerging class of interoperability protocol for AI ecosystems.
- **Healthcare data exchange** — HL7 FHIR (Fast Healthcare Interoperability Resources) is a REST-based protocol for sharing patient records across hospital systems, insurance providers, and research platforms, demonstrating that domain-specific interoperability protocols can achieve regulatory mandates (ONC, CMS in the US; NHS in the UK).
- **Digital identity and credentials** — W3C Verifiable Credentials and DID protocols enable portable credentials (academic degrees, professional licences, vaccination records) that can be issued by one organisation, held by individuals, and verified by any third party without contacting the issuer — a fundamental shift in identity architecture.
- **Supply chain and trade** — GS1 Electronic Data Interchange (EDI), PEPPOL (Pan-European Public Procurement Online), and emerging blockchain-backed provenance protocols enable cross-enterprise [[Supply Chain]] transparency and automated settlement.
- **Scientific data sharing** — protocols like OAI-PMH (Open Archives Initiative), DataCite metadata schema, and W3C PROV enable research datasets and their provenance to be indexed and cited across institutional repositories.

### Governance and Standardisation

- The governance model of an interoperability protocol profoundly affects its adoption trajectory and neutrality:
  - **IETF** (Internet Engineering Task Force) — produces RFCs through open, rough-consensus processes; governs TCP/IP, HTTP, TLS, OAuth, QUIC. Widely regarded as the gold standard for open, patent-unencumbered protocol specification.
  - **W3C** (World Wide Web Consortium) — produces Recommendations for the web platform: HTML, CSS, JSON-LD, DID, Verifiable Credentials, ActivityPub. Member-driven but with strong royalty-free IP policy.
  - **Khronos Group** — produces open specifications for graphics and XR: OpenGL, Vulkan, OpenXR, glTF. Industry consortium with IP licensing protections for implementers.
  - **IEEE** — produces standards in networking (802.11 Wi-Fi, 802.3 Ethernet) and emerging areas including AI ethics and data provenance.
  - **ISO/IEC** — produces international standards including the OSI reference model, SQL, and MPEG codec specifications.
  - **Domain consortia** — HL7 for healthcare, GS1 for supply chain, ETSI for telecoms; produce vertical protocols with formal conformance programmes.
- Protocols developed through open, royalty-free standards bodies achieve broader adoption because any party can implement without licensing risk or vendor dependency. Proprietary protocols, by contrast, create ecosystem fragmentation and extract value from dependent participants.
- Protocol governance also determines upgrade trajectories: IETF's working-group model allows incremental evolution (HTTP/1.1 → HTTP/2 → HTTP/3); W3C's Recommendation Track provides formal stability guarantees for long-lived web APIs.

### Design Principles

- **Postel's Law (Robustness Principle)** — "be conservative in what you send, liberal in what you accept" — foundational to early internet protocol design, though contested in modern security contexts where permissive parsing creates attack surface.
- **Layering** — separating concerns across protocol layers (OSI model, TCP/IP stack) enables independent evolution of transport, session, and application semantics.
- **Least Privilege** — capability tokens and scoped credentials in interoperability protocols should convey only the rights needed for a specific interaction, limiting blast radius of credential compromise.
- **Semantic precision** — ambiguous semantics are the most common cause of interoperability failures in deployed systems; formal schema languages and well-specified error semantics reduce integration risk.
- **Versioning from day one** — protocols that lack versioning mechanisms become frozen at initial design, accumulating technical debt as requirements evolve.
- **Conformance testing** — protocols without formal test suites produce divergent implementations; test suites (IETF interop events, W3C test suites, Khronos conformance) are integral to protocol maturity.

### Challenges and Failure Modes

- **Semantic mismatch** — two systems can agree on wire format while disagreeing on meaning (e.g. different date/time timezone conventions, unit of measure ambiguity), producing silent data corruption.
- **Protocol proliferation** — competing standards in the same problem space (e.g. multiple blockchain interoperability protocols) fragment ecosystems and impose integration overhead.
- **Security vulnerabilities in protocol design** — flaws in protocol specifications (e.g. TLS 1.0 POODLE, OAuth implicit flow weaknesses) have systemic impact across all implementations; protocol security analysis requires formal verification methods.
- **Governance capture** — protocols controlled by a single dominant player drift toward lock-in even when nominally open; governance structures must include checks against single-party control.
- **Implementation divergence** — partial or incorrect implementations by popular libraries create de facto protocol variants that override the specification; conformance testing mitigates this.

### Standards & Context

- **IETF RFCs** — RFC 9110–9114 (HTTP semantics and HTTP/2/3), RFC 8555 (ACME certificate automation), RFC 8693 (OAuth 2.0 Token Exchange), RFC 9200 (CoAP for constrained devices).
- **W3C Recommendations** — Verifiable Credentials Data Model 2.0, Decentralised Identifiers (DID) Core 1.0, JSON-LD 1.1, ActivityPub, PROV-O, DCAT 3.
- **Khronos Group** — OpenXR 1.1, glTF 2.0; both royalty-free with conformance test suites.
- **Blockchain-specific** — IBC Protocol (Cosmos SDK), Chainlink CCIP (2023), Polkadot XCM v3, LayerZero v2 (2024).
- **Healthcare** — HL7 FHIR R4/R5; mandated by US ONC 21st Century Cures Act Final Rule and NHS England interoperability strategy.
- **AI agent** — Anthropic Model Context Protocol (MCP, 2024), FIPA ACL (legacy but influential in multi-agent literature), Google Agent-to-Agent Protocol (A2A, 2025).
- **Supply chain** — GS1 Digital Link, PEPPOL Access Point specification, EPCIS 2.0.
- **Security overlay** — NIST SP 800-204 (microservice security), NIST SP 800-63 (digital identity), ISO/IEC 27001 as governance backdrop.

### Current Landscape (2026)

- LayerZero V2's modular Decentralised Verifier Network (DVN) design dominates cross-chain messaging, carrying roughly 75-85% of bridge volume (~$293M/day) across 130+ chains; in early 2026 the team announced Zero, a purpose-built layer-1 settlement and coordination chain for the ecosystem.
- Chainlink CCIP consolidated its institutional position with the v1.5 upgrade (January 2025) introducing the Cross-Chain Token (CCT) standard, Fast Transfers and Hooks, followed by the current v1.6.x line; it now underpins real-world-asset and tokenised-fund flows (e.g. BlackRock's BUIDL) and in 2026 the Gravity L1 migrated its standardised interoperability layer from LayerZero to CCIP.
- Wormhole's Native Token Transfer (NTT) standard, which mints natively rather than using pooled liquidity, expanded Ripple's RLUSD stablecoin to 40+ chains and continues to push zero-knowledge proofs into its 19-Guardian security model; Cosmos IBC v2 (early 2025) cut bridging costs by roughly 40% and raised throughput toward ~5,000 TPS.
- Formal standardisation accelerated: ERC-7281 (the xERC20 sovereign-bridge token standard), the ISO/TS 23516 blockchain interoperability framework, and the ITU-T X.1414 recommendation on cross-chain security requirements are converging the field toward common interfaces.
- Security remained the central weakness, with 2026 incidents including a ~$292M LayerZero configuration-flaw loss and a ~$4.67M Axelar third-party-contract exploit, keeping trust-minimisation and light-client verification a live concern.
- The 2025-2026 frontier shifted toward intent-based architectures (users specify an outcome, not execution steps), shared sequencers enabling atomic cross-chain transactions, and ZK light clients expected to become the default high-security verification primitive, alongside academic surveys (e.g. arXiv 2603.21797, March 2026) mapping the design space.

### References

- 1. Gate.com Research (2026). Gravity vs LayerZero vs Wormhole: Cross-Chain Interoperability Protocol Architecture and Ecosystem Analysis. https://www.gate.com/blog/gravity-vs-layerzero-vs-wormhole-2026-cross-chain-interoperability-protocol-architecture-and-ecosystem-analysis
- 2. BlockEden.xyz (2026). Cross-Chain Interoperability Wars 2026: LayerZero, Wormhole, CCIP, Axelar. https://blockeden.xyz/blog/2026/01/26/cross-chain-interoperability-wars-layerzero-wormhole-ccip-axelar/
- 3. Protofire (2026). CCIP vs LayerZero vs Wormhole vs Axelar vs Hyperlane. https://protofire.io/guides/cross-chain-messaging/
- 4. Sei (2025). What Is Blockchain Interoperability? 2025 Guide to Cross-Chain. https://blog.sei.io/blockchain/fundamentals/what-is-blockchain-interoperability-guide-2025/
- 5. Yellow.com Research (2025). Cross-Chain Messaging: Comparing IBC, Wormhole, LayerZero, CCIP and More. https://yellow.com/research/cross-chain-messaging-comparing-ibc-wormhole-layerzero-ccip-and-more

### Provenance

