ETSI (European Telecommunications Standards Institute) is a not-for-profit, independent standardisation organisation headquartered in Sophia Antipolis, France, that produces globally applicable ICT standards covering telecommunications, broadcasting, electronic signatures, cybersecurity, and emerging technologies such as 5G, network functions virtualisation (NFV), and multi-access edge computing (MEC). Founded in 1988 under the auspices of the European Commission, ETSI operates a membership model open to industry, governments, and research bodies worldwide, producing European Norms (ENs), ETSI Standards (ES), and Technical Specifications (TS) that feed into EU regulatory frameworks including eIDAS, the EU AI Act, and the European Cybersecurity Act. Its Industry Specification Groups (ISGs) provide an accelerated track for industry-led work on rapidly evolving topics such as quantum-safe cryptography, AI-assisted network management, and zero-trust architecture.

### Overview

- ETSI was established by the European Commission as the body responsible for producing European telecommunications standards (ETSIs, ENs, ESs, and TSs). Unlike purely governmental bodies, ETSI's open membership model admits industry actors, research institutions, small and medium enterprises, and government bodies from inside and outside Europe, currently counting over 900 member organisations from more than 60 countries.
- The organisation's outputs span the full ICT stack: radio and network access, core network architectures, security and identity, electronic signatures, and increasingly AI-integrated network management. ENs (European Norms) become mandatory references in EU legislation through harmonised standard status, giving ETSI a direct legal role in the EU internal market.
- ETSI's work feeds directly into [[3GPP]], where it is one of the founding organisational partners alongside ARIB, ATIS, CCSA, TSDSI, and TTA. This relationship means ETSI ratifies the global 3GPP specifications (LTE, NR) as European Norms, bridging industry-led global standards and EU-level regulatory requirements.
- Two structural mechanisms accelerate ETSI's output: Technical Committees (TCs), which handle established domains through formal processes, and Industry Specification Groups (ISGs), which allow faster-cycle, industry-led work on emerging topics without the overhead of formal standardisation.

### Key Components

- **Technical Committees (TCs)**
  - TC CYBER: cybersecurity standards including [[Zero Trust Architecture]], threat intelligence sharing, consumer IoT security, and quantum-safe algorithm profiles.
  - TC INT: interoperability testing methodologies feeding into [[Conformance Testing]] frameworks.
  - TC MSG: messaging standards for emergency communications and advanced messaging services.
  - TC SmartM2M: the [[oneM2M]] partnership project managing IoT and machine-to-machine service layer standards.
  - TC TETRA: TETRA and critical communications standards used by emergency services.
- **Industry Specification Groups (ISGs)**
  - ISG NFV: produced the foundational [[Network Functions Virtualisation]] architectural framework (NFV-MANO) enabling software-defined network functions running on commodity hardware.
  - ISG MEC: defines the [[Multi-Access Edge Computing]] framework, APIs, and reference architecture enabling compute at the network edge, foundational for [[Edge Computing]] deployments by operators.
  - ISG ENI: Experiential Networked Intelligence — applies AI/ML-assisted [[Closed-Loop Automation]] to network management, producing specifications for AI-native network intent and policy.
  - ISG QSC (Quantum-Safe Cryptography): catalogues [[Post-Quantum Cryptography]] migration approaches and algorithm recommendations aligned with [[NIST Post-Quantum Standardisation]].
  - ISG ZSM: Zero-touch Network and Service Management — defines an end-to-end [[Network Automation]] framework for autonomous service lifecycle management.
  - ISG SAI: Securing Artificial Intelligence — addresses adversarial ML, data poisoning, and security requirements for AI systems, intersecting with [[AI Trustworthiness]] concerns.
- **Electronic Signature Standards (EN 319 Series)**
  - Defines the formats CAdES (CMS Advanced Electronic Signatures), XAdES (XML), PAdES (PDF), and JAdES (JSON), all mandated under the [[eIDAS Regulation]] regulation for qualified electronic signatures across the EU.
  - Specifies trust service provider requirements, timestamping authorities, and validation procedures that underpin EU digital identity infrastructure.
- **ETSI Plugtests**
  - Organised interoperability events where vendors test implementations of ETSI specifications against each other, producing test reports that inform conformance certification under EU regulatory schemes.

### Applications and Use Cases

- **5G and Beyond**
  - ETSI and [[3GPP]] co-develop 5G NR (New Radio) specifications; ETSI ratifies these as ENs used in EU spectrum licensing and EU telecom regulation compliance. Network slicing, [[Network Slicing]], and [[Network Functions Virtualisation]] are ETSI-standardised components of 5G core architectures.
- **Edge Computing and MEC**
  - Mobile network operators (e.g., Telefónica, Deutsche Telekom) deploy MEC platforms conformant to ETSI ISG MEC specifications, enabling low-latency services including autonomous vehicle data processing, AR/VR offloading, and industrial IoT analytics at the [[Edge Computing]] tier.
- **Electronic Signatures and Digital Identity**
  - EU member states implement eIDAS-compliant qualified signature services using ETSI EN 319 formats. Banking, legal, healthcare, and public administration workflows in the EU depend on these standards for legally binding [[Digital Signature]] transactions.
- **AI in Networks**
  - ETSI ENI specifications are adopted by vendors building AI-driven network orchestrators. ENI's closed-loop automation reference model informs [[Network Automation]] products from Huawei, Ericsson, and Nokia.
- **Critical Communications**
  - ETSI TETRA and MCPTT (Mission Critical Push-to-Talk) standards underpin public safety networks used by police, fire, and ambulance services across Europe and beyond.
- **Quantum-Safe Migration**
  - ETSI ISG QSC migration guides and algorithm catalogues are used by network operators and enterprise security teams planning transitions away from RSA/ECC to [[Post-Quantum Cryptography]] algorithms (CRYSTALS-Kyber, CRYSTALS-Dilithium).
- **IoT and Smart Cities**
  - ETSI EN 303 645 (Cybersecurity for Consumer IoT) has been adopted as the basis for UK PSTI product security legislation and is referenced in EU Cyber Resilience Act conformance frameworks, making ETSI a central actor in [[Internet of Things]] security regulation.
- **AI Act Harmonised Standards**
  - Through CEN-CENELEC JTC 21 and direct ETSI involvement, ETSI contributes technical standards that AI system providers use to demonstrate conformity with the EU AI Act's requirements for high-risk AI systems, linking telecommunications heritage to [[AI Regulation]].

### Standards and Context

- ETSI produces several categories of deliverable:
  - **EN (European Norm)**: harmonised standards mandated or referenced in EU legislation; published jointly in the Official Journal of the EU.
  - **ES (ETSI Standard)**: ETSI-internal standards, not automatically mandated in EU law but widely adopted industry reference points.
  - **TS (Technical Specification)**: faster-cycle outputs suitable for rapidly evolving domains; often precursors to full ENs.
  - **TR (Technical Report)**: informational documents providing landscape analysis, gap assessments, and architectural guidance.
- Key specification series:
  - **ETSI EN 319 series**: electronic signatures and trust services — the legal backbone of [[eIDAS Regulation]].
  - **ETSI GS NFV series**: 40+ specifications defining [[Network Functions Virtualisation]] architecture, interfaces, and information models.
  - **ETSI GS MEC series**: [[Multi-Access Edge Computing]] platform APIs, reference architecture, and use case specifications.
  - **ETSI EN 303 645**: consumer IoT cybersecurity baseline, feeding directly into the EU Cyber Resilience Act and UK PSTI Act.
  - **ETSI TS 102 165 series**: TVRA (Threat, Vulnerability, and Risk Analysis) methodology, widely used in telecom security assessments.
- ETSI membership provides voting rights, access to drafts, and participation in technical work. Membership tiers accommodate large enterprises, SMEs, public bodies, and universities, making ETSI unusually accessible compared with, for example, [[ITU-T]], which operates primarily through national delegations.
- ETSI works under the European Standards Organisations mandate alongside [[CEN-CENELEC]], with formal coordination through the ICT Coordination Group (ICT-CG) ensuring alignment on digital single market initiatives.
- In the AI governance landscape, ETSI's role has expanded since 2023: it participates in the European AI standards ecosystem requested by the European Commission under the AI Act, producing specifications covering AI system transparency, robustness, and conformity assessment that intersect with [[AI Regulation]] and [[AI Trustworthiness]].
- ETSI's ISG SAI (Securing AI) addresses security threats to and from AI systems, producing work items on adversarial attacks on ML models, data integrity in AI pipelines, and framework specifications for secure AI deployment — intersecting with [[Cybersecurity]] and [[Machine Learning]] domains.

### Semantic Classification

### Provenance

