Supply chain management (SCM) is the management of the activities by which products and services are sourced, converted and delivered across the organisations of a supply chain. The Council of Supply Chain Management Professionals (CSCMP) defines it as the planning and management of all activities involved in sourcing and procurement, conversion and all logistics management activities, and states that in essence it integrates supply and demand management within and across companies.[^1]

## Scope and definitions

The CSCMP glossary describes SCM as an integrating function that includes all of the logistics management activities, together with manufacturing operations, and that drives coordination with marketing, sales, product design, finance and information technology.[^1] The European Commission treats logistics as a fundamental part of supply chain management, which agrees with the CSCMP placement of logistics inside it.[^2][^1] A supply chain is, in the NIST glossary wording written for information and communications technology, a linked set of resources and processes between multiple tiers of developers that begins with the sourcing of products and services and extends through design, development, manufacturing, processing, handling and delivery to the acquirer.[^3] That wording is narrower than the general sense used on this page.

Sources agree that the term is contested. Mentzer and colleagues open their review in the Journal of Business Logistics by observing that so many definitions of supply chain management are used that there is little consensus on what it means; only the publisher's abstract was opened.[^4] The CSCMP glossary itself notes that SCM is often confused with logistics management.[^1]

## In practice

NIST's Manufacturing Extension Partnership says that effective supply chain management has always been critical in manufacturing and that, on average, more than half of a manufacturer's total spending occurs in the supply chain, which makes it an ideal target for reducing costs and mitigating risk.[^5]

## Scope and distinctions

In this vault Supply Chain Management is the management discipline at the head of the functional areas, which are linked to it by related-to, not by is-a, with [[Logistics]] and [[Logistics Management]] as its logistics part. See also [[Procurement]], [[Inventory Management]], [[Demand Forecasting]] and [[Supplier Relationship Management]]. It differs from [[Supply Chain]], which names the network of organisations that is managed.

## What the sources do not establish

Sources give no history of the term, no list of its components beyond the CSCMP definition, and no evidence on technology use. The CSCMP glossary is a professional body's definition and is paraphrased here.[^1]

[^1]: Council of Supply Chain Management Professionals, “SCM Definitions and Glossary of Terms” (cite-only, paraphrased). https://cscmp.org/CSCMP/Educate/SCM_Definitions_and_Glossary_of_Terms.aspx
[^2]: European Commission, Directorate-General for Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en
[^3]: NIST Computer Security Resource Center, glossary entry for supply chain. https://csrc.nist.gov/glossary/term/supply_chain
[^4]: Journal of Business Logistics, “Defining Supply Chain Management” (publisher abstract, via Crossref). https://api.crossref.org/works/10.1002/j.2158-1592.2001.tb00001.x
[^5]: NIST Manufacturing Extension Partnership, “Supply Chain Management”. https://www.nist.gov/mep/supply-chain

