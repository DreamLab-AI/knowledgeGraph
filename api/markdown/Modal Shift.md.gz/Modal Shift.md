Modal shift is a reduction of the share of road transport in all transport, towards less polluting and more energy efficient modes of transport.[^1]

That wording comes from a Commission evaluation of the Combined Transport Directive, attached to a 2016 Council cover note, which says such a modal shift can help to reduce the overall environmental impact of freight transport.[^1] The evaluation quotes the EU's 2011 White Paper target of a modal shift of 30% of road freight over 300 km by 2030, and more than 50% by 2050, with respect to business as usual developments.[^1]

## Intermodal transport

The European Court of Auditors defines intermodal freight transport as transporting goods in a single loading unit, such as a container, using a combination of modes of transport: road, rail, waterways or air.[^2] Its 2023 special report says the Commission set targets at EU level for the increased use of rail and inland waterways, and concludes that intermodal freight transport can still not compete on equal grounds with road transport because of regulatory and infrastructure barriers.[^2]

## Measurement

Comparing modes needs consistent emissions accounting. The Global Logistics Emissions Council developed a universal method for calculating logistics emissions across road, rail, air, sea, inland waterways and transhipment centres.[^3]

## Scope and limits

Modal shift is one measure within [[Supply Chain Decarbonisation]]. The sources opened here are EU institutional documents, so they describe European targets and experience; the Council note is a 2016 document and the audit report a 2023 one. Neither source gives the emission saving per tonne-kilometre of any mode, and no other source was opened on this point.

[^1]: Council of the European Union, cover note 8149/16 of 28 April 2016 (Commission staff working document SWD(2016) 140 final), “REFIT ex-post evaluation of Combined Transport Directive 92/106/EEC”. https://data.consilium.europa.eu/doc/document/ST-8149-2016-INIT/en/pdf
[^2]: European Court of Auditors, Special report 08/2023, “Intermodal freight transport: EU still far from getting freight off the road”. https://op.europa.eu/webpub/eca/special-reports/intermodal-freight-transport-08-2023/en/index.html
[^3]: GHG Protocol, blog post of 30 October 2019, “GLEC Framework: a universal method for logistics emissions accounting”. https://ghgprotocol.org/blog/glec-framework-universal-method-logistics-emissions-accounting

