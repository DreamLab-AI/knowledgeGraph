Supplier concentration risk is the exposure of a buyer to loss because its supply of an input depends on one supplier or a few, so that a failure at that point cannot easily be replaced.[^1]

No source opened here defines the term. The description above is assembled from what two sources say about single sources and critical inputs.

Christopher and Peck list, among the characteristics of a critical path in a supply network, a single source of supply with no short-term alternative.[^1] They also list long lead-times and poor visibility between nodes as further characteristics that can combine with it.[^1]

## Evidence from the euro area

The European Central Bank reports harmonised surveys and firm-level data for five European economies showing that 17% to 34% of manufacturing companies rely on China for critical inputs, with 20% to 25% naming China as their main supplier.[^2] A firm-level stress test in the same paper finds that sudden disruptions in the supply of critical inputs from high-risk countries would lead to significant, though very uneven, economic losses across firms, regions and sectors.[^2] The paper also reports that some EU manufacturers are shifting the sourcing of critical inputs from China to within the EU to mitigate the risk of disruptions.[^2]

That paper also warns that addressing foreign dependencies with broadbased protectionism is self-defeating.[^2]

## Related pages

Concentration is a form of [[Supply Risk]]. Where the concentration is tied to a country and its policies, see [[Geopolitical Supply Chain Risk]]. Spreading suppliers is the response described at [[Supplier Diversification]].

## What the sources do not establish

The ECB survey measures the share of firms that rely on China, not the share of input value, and it concerns manufacturers in five European economies.[^2] Neither source opened gives a threshold at which concentration becomes a risk, or a metric for measuring it. This is a thin page resting on two sources.

[^1]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^2]: European Central Bank, Occasional Paper Series, “Navigating a fragmenting global trading system: insights for central banks (No 365)”. https://ecb.europa.eu/pub/pdf/scpops/ecb.op365~362d801aee.es.pdf

