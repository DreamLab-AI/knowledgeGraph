An order management system (OMS) is a digital way to manage the lifecycle of an order, according to IBM.[^1] IBM says it tracks the information and processes involved, including order entry, inventory management, fulfilment and after-sales service.[^1]

SAP gives a similar account. It says order management includes every stage of the order lifecycle, from order placement and inventory checks to shipping, delivery and returns, and that an OMS is the technology and set of procedures that facilitates this.[^2] It adds that a modern OMS integrates with sales, inventory, commerce, store operations, distribution centres, marketplaces, third-party logistics companies, accounting, marketing and customer service systems.[^2]

## Distributed order management

A paper by researchers at Microsoft, the Technion, EPFL and Georgia Tech describes distributed order management as a key component in modern retail applications, where the goal is assigning customers' orders to stores or warehouses while minimising fulfilment costs such as shipping or transport costs.[^3] The paper formalises variants that differ in their objective, for example minimising fulfilment cost or maximising satisfied orders, and in constraints such as whether an order may be split.[^3]

## Scope and distinctions

An OMS sits next to the warehouse and transport systems in the execution class that this domain uses, although the preprint cited at [[Supply Chain Execution System]] lists only warehouse, manufacturing and transportation systems.[^1] See [[Warehouse Management System]] and [[Transportation Management System]].

## What the sources do not establish

Definitions here come from two vendors, and neither is a neutral standard. The academic paper treats one decision inside order management, the assignment of orders to fulfilment locations, and does not define the system as a whole. No source opened gives adoption figures or a standard list of functions.[^1][^2][^3]

[^1]: IBM, “What is Order Management?”. https://www.ibm.com/think/topics/order-management
[^2]: SAP, “A guide to order management”. https://www.sap.com/resources/a-guide-to-order-management
[^3]: Michael Berezansky, Yaron Fairstein, Luke Marshall, Ishai Menache, Joseph (Seffi) Naor, Ola Svensson and Timur Tankayev, “Models and Algorithms for Distributed Order Management”. https://www.microsoft.com/en-us/research/wp-content/uploads/2019/11/Theory__DOM.pdf

