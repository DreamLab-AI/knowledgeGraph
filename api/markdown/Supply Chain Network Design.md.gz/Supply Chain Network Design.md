Supply chain network design is the strategic planning of the facilities in a supply chain and the flows between them, deciding their number, location, capacity and technology.[^1][^2]

Melo, Nickel and Saldanha da Gama place network design at the strategic planning level and say it involves decisions concerning the number, location, capacity and technology of facilities.[^1] They also report that in some books and papers the terms network design and supply chain network design are used as synonyms of strategic supply chain planning.[^1] The decisions concern facilities that perform operations from the acquisition of raw materials to the distribution of finished goods.[^1]

These decisions are long-lived. Melo and colleagues note that large amounts of capital must typically be committed to a new facility, which makes the investment a long-term project, and that changes during a facility's lifetime may turn a good location today into a bad one in the future.[^1] The operations research handbook chapter on location problems lists transportation costs and the availability of transportation infrastructure as the most prominent factors, alongside the availability and cost of land, labour, materials, energy and government incentives.[^2]

## Methods and related pages

Melo and colleagues treat location models as central to the topic: their review opens by saying that facility location decisions play a critical role in the strategic design of supply chain networks.[^1] The [[Facility Location Problem]] is the operations research formulation. A lecture on logistics systems presents methods in two groups: continuous methods such as [[Centre of Gravity Analysis]], and discrete methods that evaluate known candidate locations, such as factor rating and cost-volume analysis.[^3] See also [[Operations Research]] and [[Mathematical Optimisation]].

CSCMP lists logistics network design among the activities of logistics management, so CSCMP files the topic under logistics management as well as under the strategic planning described above.[^4]

## Scope and distinctions

Network design is not facility design. A handbook on operations research says that facility location decisions differ from facility design decisions, which consist of facility layout and material handling systems design.[^2] It is also distinct from the tactical and operational planning of inventory policy, transport modes and routing, which Melo and colleagues describe as strongly related to location even though typically no location decisions are made at the tactical or operational level.[^1]

## What the sources do not establish

Melo and colleagues' paper was read in its 2007 report version, and it quotes other authors for some of its wording; those words are attributed to them only as quoted. None of the opened sources sets out a step-by-step design process or shows how often firms redesign their networks. The Groningen lecture is teaching material and the CSCMP glossary is a professional body's definition list, so neither is evidence of practice.[^3][^4]

[^1]: Melo, Nickel and Saldanha da Gama, Fraunhofer ITWM report 130, “Facility Location and Supply Chain Management - A comprehensive review”. https://kluedo.ub.rptu.de/files/1985/bericht130.pdf
[^2]: Petropoulos, Laporte and colleagues (section 3.13 by Sibel A. Alumur), arXiv, “Operational Research: Methods and Applications”. https://arxiv.org/pdf/2303.14217
[^3]: Tri M. Tran, University of Groningen, lecture slides hosted by Aalto University, “Session 9: Facility location problems”. https://mycourses.aalto.fi/pluginfile.php/2142267/mod_folder/content/0/Lecture%209%20-%2015.11./LSA%202023%20Session%209%20-%20Facility%20location%20problems.pdf
[^4]: Council of Supply Chain Management Professionals, “CSCMP Supply Chain Management Definitions and Glossary”. https://cscmp.org/CSCMP/Educate/SCM_Definitions_and_Glossary_of_Terms.aspx

