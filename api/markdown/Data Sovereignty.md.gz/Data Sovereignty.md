Data sovereignty is the legal and political principle that digital data is subject to the laws, governance structures, and enforcement jurisdiction of the nation, region, or community in which it originates or is processed. It encompasses requirements such as data localisation (mandating that data remain physically within specified geographic boundaries), restrictions on cross-border data flows, and the right of governments or communities to compel access for regulatory, security, or cultural-preservation purposes. Data sovereignty directly shapes cloud architecture decisions, AI training dataset curation, federated system design, and multinational data-sharing agreements. It intersects with — yet is conceptually distinct from — privacy rights, data protection law, and cybersecurity, being principally concerned with jurisdictional control rather than individual rights.

### Overview

- Data sovereignty emerged as a geopolitical concern once hyperscale cloud providers began routing and storing citizen and enterprise data across international boundaries without explicit consent from the governments of origin.
- The concept operates at three distinct levels:
  - **National sovereignty** — governments assert the right to regulate, access, and protect data generated within their borders, motivated by [[National Security]], law enforcement, and economic competitiveness interests.
  - **Organisational sovereignty** — enterprises seek control over their own data assets to prevent lock-in, maintain competitive advantage, and satisfy board-level risk appetite — closely linked to [[Data Governance]] policies and [[Regulatory Compliance]] obligations.
  - **Community or [[Indigenous Data Sovereignty]]** — indigenous peoples and marginalised communities assert that data describing their members, territories, and cultural heritage remains under collective community governance rather than state or corporate control. The CARE Principles (Collective Benefit, Authority to Control, Responsibility, Ethics) formalise this dimension.
- Why it matters:
  - AI and machine-learning pipelines increasingly depend on vast datasets whose lawful use turns on the jurisdiction-of-origin consent rules under which they were collected.
  - Geopolitical fragmentation (the "splinternet") means a data architecture acceptable in one jurisdiction may be unlawful in another, forcing multinational organisations to design for heterogeneous compliance.
  - Cloud lock-in and [[Vendor Lock-In]] risks compound sovereignty risks — when data is held exclusively by a foreign-headquartered provider, legal instruments like the US CLOUD Act can compel disclosure irrespective of where the data physically resides.
  - The proliferation of large language models and generative AI has intensified scrutiny of training data provenance, creating new sovereignty obligations around AI-generated derivatives of protected data.

### Key Components

- **[[Data Localisation]]** — statutory or contractual requirement that specified data categories (health, financial, biometric, government) be stored and processed on infrastructure physically located within national or regional borders.
- **[[Data Residency]]** — the weaker cousin of localisation: the data may be stored in a defined location but does not prevent access by foreign entities via the controller's home-country law.
- **[[Jurisdiction]]** — the legal authority of a state or court to make and enforce laws with respect to particular persons, property, or matters. Determines which sovereignty regime applies when data flows across multiple territories.
- **Cross-border transfer restrictions** — mechanisms such as adequacy decisions (GDPR Article 45), Standard Contractual Clauses (SCCs), and Binding Corporate Rules (BCRs) that govern when data may legally leave a jurisdiction.
- **Government access rights** — statutory powers enabling law enforcement, intelligence agencies, and regulators to compel data disclosure, including mutual legal assistance treaties (MLATs) and extraterritorial instruments like the US CLOUD Act or China's National Intelligence Law.
- **Sovereignty-by-Design** — an emerging architectural pattern embedding jurisdictional controls ([[Encryption]] key custody, access logging, geo-fencing) at the infrastructure layer rather than relying solely on legal instruments.
- **[[Confidential Computing]]** — hardware-enforced trusted execution environments (TEEs) such as Intel TDX and AMD SEV that enable cloud processing of sensitive data without exposing plaintext to the cloud provider's staff or systems.
- **[[Federated Learning]]** — a machine-learning paradigm that keeps raw training data on local devices or within national boundaries, sharing only gradient updates, partially addressing sovereignty concerns for AI model training.
- **[[Sovereign Cloud]]** offerings — physically isolated cloud regions operated by local entities (or under local key custody) that contractually prevent foreign government access; examples include EU sovereign cloud initiatives by major hyperscalers and the GAIA-X framework.
- **[[Access Control]]** frameworks — role-based, attribute-based, and policy-based access control systems that enforce data-flow rules, preventing unauthorised cross-border replication or processing.

### Applications and Use Cases

- **Healthcare data** — patient records in the EU must comply with GDPR; in Germany, additional state-level Landesdatenschutz laws impose further constraints. [[Sovereign Cloud]] deployments enable AI-assisted diagnostics without exporting sensitive health data across borders.
- **Financial services** — central banks and financial regulators in India, Russia, and China mandate that payment data and customer financial records be stored domestically, shaping which cloud providers can operate in those markets and driving adoption of [[Data Localisation]] measures.
- **Government and defence** — classified or sensitive government workloads demand complete data sovereignty guarantees, typically via on-premises infrastructure or commercially operated national security clouds. These workloads cannot tolerate foreign-accessible hyperscale environments.
- **AI training provenance** — organisations curating training datasets for large language models must trace the geographic origin and consent status of each data record to comply with the jurisdiction's data protection law and avoid downstream liability under emerging AI regulation.
- **Indigenous data governance** — programmes such as the Global Indigenous Data Alliance (GIDA) and Te Mana Raraunga (Māori Data Sovereignty Network) assert community control over datasets describing indigenous peoples, influencing how research institutions may access and share such data.
- **Autonomous vehicles and IoT** — real-time sensor and telemetry data generated in China must, under China's Data Security Law and Personal Information Protection Law (PIPL), remain within Chinese borders, complicating global fleet-management platforms and cross-border [[Cloud Computing]] architectures.
- **Content moderation** — sovereign mandates may require that user-generated content be reviewed by locally based moderators with access to locally stored copies, directly affecting global platform architectures and [[Cross-Border Data Flows]] policies.
- **Research and academia** — international scientific data-sharing programmes must navigate sovereignty constraints when combining datasets from multiple jurisdictions, driving adoption of [[Secure Multi-Party Computation]] and [[Federated Learning]] approaches.

### Mechanisms and Technical Enablers

- **[[Encryption]] with local key custody** — data encrypted at rest and in transit, with encryption keys held by a locally regulated key management service, ensures foreign cloud operators cannot decrypt data without local government authorisation.
- **[[Homomorphic Encryption]]** — allows computation on encrypted data without decryption, enabling cross-border analytics whilst the raw data never leaves the jurisdiction of origin.
- **[[Secure Multi-Party Computation]]** — distributes computation across parties such that no single party sees the full dataset, supporting cross-border collaboration without exposing individual jurisdictions' data to counterparties.
- **Policy-enforcement layers** — tools such as Open Policy Agent (OPA) and Attribute-Based [[Access Control]] (ABAC) enforce data-flow rules at API gateways, preventing unauthorised cross-border replication.
- **[[Zero Trust Architecture]]** — continuous verification of identity and context at every data access event replaces network perimeter assumptions, enabling fine-grained sovereignty enforcement irrespective of physical data location.
- **Audit logs and provenance tracking** — immutable audit trails (sometimes on distributed ledgers) enable regulatory demonstration that data has remained within mandated boundaries and has only been accessed by authorised parties with appropriate [[Jurisdiction]].
- **[[Decentralised Identity]]** — self-sovereign identity (SSI) systems based on W3C DID and Verifiable Credentials allow individuals and organisations to assert provenance and consent status without relying on centralised foreign identity providers.
- **Data mesh and federated architectures** — distributing data ownership to domain teams with explicit governance contracts allows large organisations to implement sovereignty policies at a granular level aligned with [[Data Governance]] frameworks.

### Standards and Regulatory Context

- **GDPR (EU, 2018)** — Chapter V governs international transfers; adequacy decisions, SCCs, and BCRs are the primary instruments. The Schrems II ruling (CJEU, 2020) invalidated the EU–US Privacy Shield, intensifying sovereignty pressures and driving adoption of supplementary technical measures.
- **China Data Security Law (DSL, 2021) and PIPL (2021)** — impose strict localisation on "important data" and personal information, with mandatory security assessments required for cross-border transfers; sector guidance elaborates the thresholds and approval processes.
- **India Digital Personal Data Protection Act (DPDPA, 2023)** — grants the government power to restrict transfers to specified countries; sector-specific localisation requirements (e.g., Reserve Bank of India payment data rules) pre-date the Act and remain in force.
- **US CLOUD Act (2018)** — allows US law enforcement to compel US-headquartered cloud providers to produce data regardless of storage location, creating direct tension with EU and other national sovereignty frameworks and influencing [[Sovereign Cloud]] procurement decisions.
- **GAIA-X (EU)** — a federated data infrastructure initiative promoting interoperability and sovereignty-preserving data sharing across European cloud and edge providers, with a focus on trust frameworks and data spaces.
- **EU Data Act (2024)** — establishes rights over data generated by connected devices and services, including business-to-government data sharing obligations, further shaping sovereignty responsibilities for product manufacturers and service providers.
- **NIS2 Directive (EU, 2022)** — extends cybersecurity obligations to essential and important entities, intersecting with sovereignty requirements for critical infrastructure data and supply chain security.
- **ISO/IEC 27701** — extends ISO/IEC 27001 to privacy information management; widely used as a compliance framework supporting sovereignty claims and third-party audit programmes.
- **OECD Guidelines on Privacy and Trans-border Data Flows** — long-standing soft-law framework influencing bilateral and multilateral digital trade agreements; the 2013 revision introduced accountability principles that underpin modern sovereignty regimes.
- **CARE Principles for Indigenous Data Governance** — non-binding but widely adopted framework developed by GIDA that asserts Collective Benefit, Authority to Control, Responsibility, and Ethics as governing principles for [[Indigenous Data Sovereignty]].
- **UN Convention on the Law of the Sea (UNCLOS) analogy** — scholars have drawn analogies between maritime exclusive economic zones and proposed "data economic zones," suggesting sovereignty over data generated by activities within a state's territory.

### Tensions and Debates

- **Sovereignty vs. interoperability** — strict localisation requirements fragment the global data economy, raising costs for multinational organisations and reducing the efficiency gains of cloud-scale analytics and AI model training.
- **Security vs. access** — end-to-end [[Encryption]] and sovereign key custody protect against foreign government access but may impede lawful domestic law enforcement and judicial processes, creating a tension within the sovereignty concept itself.
- **Fragmentation of the internet** — ITU and WTO analyses note that sovereignty-driven fragmentation of the internet ("splinternet") may undermine the economic benefits of [[Digital Trade]], particularly for developing economies with limited domestic cloud infrastructure.
- **AI and sovereignty** — frontier AI models trained on globally aggregated data may inadvertently encode data from jurisdictions with strict sovereignty requirements, exposing model operators to legal liability; conversely, pure localisation of training data may degrade model quality by reducing dataset diversity and linguistic coverage.
- **Technical sovereignty vs. legal sovereignty** — technical measures (TEEs, [[Homomorphic Encryption]]) can enforce sovereignty-by-design but cannot substitute for the legal framework establishing what constitutes lawful access and processing, nor do they address accountability gaps.
- **Corporate sovereignty claims** — large technology firms assert contractual and architectural sovereignty over user data, creating friction with both state sovereignty frameworks and individual [[Privacy]] rights, particularly in the context of platform terms of service.
- **Developing-economy dilemma** — nations with less domestic cloud infrastructure must choose between accepting foreign-hosted services (surrendering sovereignty) or investing in domestic infrastructure at potentially prohibitive cost, influencing geopolitical alignment and [[Digital Autonomy]] aspirations.

### Provenance

