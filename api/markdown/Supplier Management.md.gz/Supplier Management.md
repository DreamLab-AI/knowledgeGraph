Supplier management is the set of activities by which a buyer works with its suppliers over the course of the relationship, and it is usually treated in the literature under the heading of supplier relationship management.[^1][^2]

No opened source defines supplier management as a term. Moeller, Fassnacht and Klose describe purchasing as the gateway between the external suppliers and the internal functions that create and deliver value for customers. They say growing expectations of the purchasing function and the suppliers have enhanced the importance of the supplier base, that the old arm's-length collaboration is suitable for some suppliers while others should be treated as close partners, and that an overall framework integrating the different types of supplier along the course of the relationship remains desirable.[^1]

The UK Cabinet Office Sourcing Playbook distinguishes a contracting authority's own management of its suppliers from the work of the Cabinet Office's Markets, Sourcing and Suppliers team, which maintains the government's strategic suppliers across a number of departments to improve supplier relationships and create value.[^2] Klobucar and Erjavec write that procurement has become a key strategic business function, which has made supplier integration a key activity in supply-chain management.[^3] The Playbook also says effective contract management is essential to value for money and successful contractual outcomes, and that the government's most important contracts should be managed by an accredited contract manager.[^2]

## Scope and distinctions

See [[Supplier Relationship Management]], [[Supplier Selection]], [[Supplier Qualification]] and [[Strategic Sourcing]].

## What the sources do not establish

These three sources treat the subject through relationship management and give no definition of supplier management or list of its activities, so the page is thinly evidenced.[^1][^2][^3]

[^1]: Sabine Moeller, Martin Fassnacht and Sonja Klose, Journal of Business-to-Business Marketing 13(4), 2006 (Australian National University research portal record, abstract), “A framework for Supplier Relationship Management (SRM)”. https://researchportalplus.anu.edu.au/en/publications/a-framework-for-supplier-relationship-management-srm/
[^2]: UK Cabinet Office, Crown copyright (Open Government Licence v3.0), June 2023, “The Sourcing Playbook: Government guidance on service delivery, including outsourcing, insourcing, mixed economy sourcing and contracting”. https://assets.publishing.service.gov.uk/media/64901fcc5f7bb700127fac5e/Sourcing_Playbook_Final.pdf
[^3]: Tilen Klobucar and Jure Erjavec, Poslovna izvrsnost - Business Excellence 13(2), 2019 (Hrcak record, abstract), “CONTINUOUS SUPPLIER RELATIONSHIP MANAGEMENT FRAMEWORK”. https://hrcak.srce.hr/clanak/333916

