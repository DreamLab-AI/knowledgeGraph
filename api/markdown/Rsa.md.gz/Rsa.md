RSA is a public-key cryptosystem, named after Rivest, Shamir and Adleman, whose security rests on the computational difficulty of factoring the product of two large prime numbers. It supports both encryption — where a message encrypted with a public key can only be decrypted with the corresponding private key — and digital signatures, where a private key signs data that anyone can verify with the public key. As one of the earliest and most widely deployed asymmetric algorithms, RSA underpins much of the legacy public-key infrastructure, though it is gradually being supplemented by faster elliptic-curve schemes and, prospectively, post-quantum alternatives.

### Overview

- Introduced in 1977, RSA was the first practical public-key algorithm capable of both encryption and signing, and it became the cornerstone of digital certificates, secure email, and the early web's transport security. Key generation produces a modulus from two secret primes together with public and private exponents; encryption and signing are modular exponentiations. Secure deployment depends critically on adequate key sizes, secure padding schemes such as OAEP and PSS, and protection of the private key, with key sizes having grown from 512 to 2048 bits and beyond as factoring capability advanced.

### Mechanisms

- Key generation from two large secret prime numbers
- Modular exponentiation for encryption and signature operations
- Trapdoor based on the hardness of integer factorisation
- Padding schemes (OAEP, PSS) to achieve provable security
- Growing key sizes (2048+ bits) to stay ahead of factoring advances

### Applications

- X.509 certificates and the legacy web public-key infrastructure
- Secure email signing and encryption (S/MIME, PGP)
- Code and document signing
- Legacy TLS key transport and authentication

### Provenance

- This class was materialised to resolve inbound references from existing classes in the knowledge graph.

