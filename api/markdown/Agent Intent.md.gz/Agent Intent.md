
An agent intent is a semantic expression of purpose, objective or expected action outcome.[^1] The intent module reads it as a statement of what an agent aims to achieve,[^2] and the threat-model module as a purpose or goal communicated by an agent, which is the basis of the intent-ambiguity threat.[^3] visionGraph places it under [[Goal]].

An intent has an [[Intent Type]] (`hasIntentType`), typed [[Intent Parameter]] values (`hasParameter`), and an authorising [[Agent Delegation]] (`authorizedBy`). It leads to an [[Agent Action]] through `producesAction`.[^2] An agent is linked to its intent by `hasIntent`, or `expressesIntent` in the threat model.

An intent can be aligned with the [[Agent Task]] it authorises or motivates, through `IntentAlignsWithTask` in the security-binding module.[^4] Working out an intent from natural language is the work of [[Intent Recognition]]. The schema.org mapping aligns the class with `schema:Intent`.[^5]

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Intent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/intent.ttl
[^3]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl
[^4]: Semantic Agent Communication Community Group, “Security Binding Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/security-binding.ttl
[^5]: Semantic Agent Communication Community Group, “Agent Ontology to Schema.org Mapping” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/schema-org-mapping.ttl

