Supply planning is the planning that ensures the timely availability of material and products to meet customer demands.[^1]

Jatta says supply planning involves various functions within a manufacturing entity, and that the uncertainty of demand signals, propagated and magnified in what is commonly known as the bullwhip effect, adds to the complexity of supply chain planning.[^1] He names three traditional functions in the supply chain, procurement, production and distribution, and says all of them need diligent, integrated and well-coordinated planning to fulfil demand.[^1] His review separates procurement planning, strategic procurement, capacity planning and production planning, and describes production planning as ensuring that products are made in a timely manner for distribution to customers and warehouses.[^1]

Jatta notes that procurement plays a critical role as organisations and supply chains grow, and that most planners now accept safety stock, capacity buffers and safety time as mitigating strategies, although some researchers contend that these also add to operational inefficiencies.[^1]

## Scope and distinctions

Supply planning acts on the demand plan. Jatta says the demand plan serves as the strategy from which other plans in the supply chain are generated and weighs heavily on manufacturing, logistics, capacity and safety stock decisions.[^1] An open operations management textbook describes aggregate planning as developing production strategies that optimise resource use to meet forecasted demand, at the level of product families.[^2] In a university module on MRP, the master schedule states quantities that need to be produced, not what can be produced.[^3] See [[Demand Planning]], [[Aggregate Planning]], [[Master Production Scheduling]] and [[Sales and Operations Planning]].

## What the sources do not establish

Evidence is thin: one dissertation names the term, and the other sources describe the neighbouring plans without using the phrase.[^1][^2][^3]

[^1]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content
[^2]: Operations Management open textbook, eCampusOntario Pressbooks, section 14.2, “Concept and Horizon of Aggregate Planning”. https://ecampusontario.pressbooks.pub/opsmgmt/chapter/14-2-concept-and-horizon-of-aggregate-planning/
[^3]: Terry Janicki, University of North Carolina Wilmington, OPS 370 course module, “Materials Requirements Planning Module 11”. https://csbapp.uncw.edu/janickit/ops370/modules/Module11.pdf

