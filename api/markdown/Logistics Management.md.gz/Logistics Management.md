Logistics management is the managerial practice of planning, implementing and controlling the logistics of an organisation. The CSCMP glossary defines it as that part of supply chain management that plans, implements and controls the efficient, effective forward and reverse flow and storage of goods, services and related information between the point of origin and the point of consumption in order to meet customers' requirements.[^1]

## Activities

CSCMP lists the activities that logistics management typically includes: inbound and outbound transportation management, fleet management, warehousing, materials handling, order fulfilment, logistics network design, inventory management, supply and demand planning, and management of third party logistics service providers.[^1] The European Commission's account of logistics covers a similar set, with flows of goods related to purchasing, production, warehousing, distribution and the disposal, reuse and exchange of products, and added value services.[^2]

CSCMP adds that, to varying degrees, the logistics function also reaches sourcing and procurement, production planning and scheduling, packaging and assembly, and customer service, and that logistics management is an integrating function that coordinates logistics activities and links them with marketing, sales, manufacturing, finance and information technology.[^1]

## Scope and distinctions

Logistics Management is a kind of [[Logistics]] in this vault and a part of [[Supply Chain Management]], as the CSCMP definition places it.[^1] The CSCMP glossary also warns that supply chain management is often confused with logistics management, so the two are not synonyms.[^1] The relation between logistics and logistics management is a matter of use. The sources opened define logistics management but give no separate CSCMP definition of logistics, and the Commission page describes logistics in terms close to the CSCMP logistics management activities, so the pages are kept distinct by decision and not because the sources separate them.[^1][^2] Related pages are [[Reverse Logistics]], [[Logistics Service Provider]] and [[Fleet Management]].

## What the sources do not establish

Sources give no evidence on performance outcomes, and the CSCMP glossary is a professional body's text that is paraphrased here.[^1]

[^1]: Council of Supply Chain Management Professionals, “SCM Definitions and Glossary of Terms” (cite-only, paraphrased). https://cscmp.org/CSCMP/Educate/SCM_Definitions_and_Glossary_of_Terms.aspx
[^2]: European Commission, Directorate-General for Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en

