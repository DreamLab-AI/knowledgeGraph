AI Accountability is the set of mechanisms, obligations, and institutional structures that ensure developers, deployers, and operators of AI systems can be held responsible for the outcomes those systems produce. It encompasses technical auditability, legal liability, organisational governance, and redress pathways for harms caused by algorithmic decisions. Accountability frameworks bind technical transparency measures to enforceable consequences, distinguishing it from voluntary explainability efforts. Effective AI accountability requires clear assignment of responsibility across the AI value chain—from data collection through deployment and monitoring.

### Semantic Classification

### Content

## Compositional Relationships (Components)
```manchester-syntax
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:hasPart ai:AuditTrail))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:hasPart ai:AlgorithmicAuditing))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:hasPart ai:AiImpactAssessment))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:hasPart ai:ModelCard))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:hasPart ai:ConformityAssessment))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:hasPart ai:PostMarketMonitoring))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:hasPart ai:RedressMechanism))
```
## Dependency Relationships
```manchester-syntax
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:requires ai:Explainability))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:requires ai:HumanOversight))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:requires ai:Transparency))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:requires ai:DataGovernance))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:dependsOn ai:RiskManagement))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:dependsOn ai:ExplainableAi))
```
## Capability Relationships
```manchester-syntax
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:enables ai:AiTrustworthiness))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:enables ai:DigitalRights))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:enables ai:Fairness))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:supports ai:RegulatoryCompliance))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:supports ai:AiSafety))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:supports ai:ResponsibleAi))
```
## Implementation Relationships
```manchester-syntax
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:implements ai:EuAiActRegulatoryInstrument))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:implements ai:NistAiRmf))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:implements ai:IsoIec42001))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:implements ai:Gdpr))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:implements ai:OecdAiPrinciples))
```
## Reduction Relationships
```manchester-syntax
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:reducesTo ai:Accountability))
SubClassOf(ai:AiAccountability
  ObjectSomeValuesFrom(ai:reducesTo ai:AlgorithmicAccountability))
```

## About

AI Accountability emerged from policy debates in the mid-2010s as [[Machine Learning]] systems began making consequential decisions in credit scoring, criminal justice, and healthcare. Early frameworks borrowed from corporate governance and product liability law, asking who is responsible when an algorithm causes harm. The 2016 [[GDPR]] introduced a right to explanation under Article 22, marking the first major legislative attempt to encode accountability into automated decision-making—a principle subsequently operationalised at greater specificity and enforceability by the [[EU AI Act]]. The concept is analytically distinct from [[Explainability]] and [[Transparency]]: those properties describe what information is available about a system and its behaviour, whereas accountability describes the institutional and legal structures that bind actors to consequences when things go wrong. A system can be fully explainable yet its developer still escape accountability if the legal and organisational structures are absent; conversely, accountability regimes can exist in principle without the technical tools to enforce them in practice. The two dimensions are therefore complementary rather than substitutable, which explains why modern governance frameworks such as the [[NIST AI Risk Management Framework]] treat them as jointly necessary components of trustworthy AI.

Accountability mechanisms operate across three interlocking levels. Technical accountability creates verifiable records and testable claims about system behaviour: [[Audit Trail]] systems log inputs, decisions, and outputs with cryptographic integrity guarantees; [[Model Card]] documentation discloses capabilities, limitations, and intended use contexts; [[Algorithmic Auditing]] processes systematically probe deployed systems for discriminatory patterns, calibration failures, and adversarial vulnerabilities. Organisational accountability assigns internal roles and processes: [[AI Ethics Board]] structures provide governance oversight; responsible AI officers carry designated accountability for deployment decisions; incident response protocols define escalation paths when harms occur. Legal accountability establishes binding consequences: [[Liability]] regimes—still evolving in most jurisdictions—determine who bears civil and criminal responsibility for AI-caused harm; complaint procedures give affected individuals enforceable rights of challenge; regulatory enforcement through bodies such as the [[Information Commissioner's Office]] in the UK or the EU AI Office imposes sanctions on non-compliant deployers. Effective accountability requires all three levels to function in coordination: technical tooling provides the evidentiary substrate, organisational structures deploy it operationally, and legal frameworks translate it into enforceable duties and consequences.

The significance of AI accountability is amplified by the scale and opacity of modern [[Deep Learning]] systems. A single [[Foundation Model]] deployed in customer-facing applications can affect millions of people, yet its decision logic may be opaque even to its creators. This creates accountability gaps that are structurally difficult to close: the upstream model developer may disclaim liability for downstream misuse, while the downstream deployer claims ignorance of the model's emergent capabilities. The [[EU AI Act]], which entered into force in August 2024, addresses this through a value-chain model: general-purpose AI model providers face transparency and technical documentation obligations, while deployers bear responsibility for use-context risk assessment and [[Conformity Assessment]] for high-risk applications. The layered obligation structure is analogous to pharmaceutical regulation, where ingredient manufacturers and drug formulators carry distinct but complementary duties.

## Components / Architecture

The accountability architecture of a compliant AI system spans five functional layers:

- **Governance layer**: [[AI Ethics Board]] oversight, designated responsible AI officers, board-level accountability statements, and internal escalation procedures for high-stakes deployment decisions
- **Documentation layer**: [[Model Card]] specifications of intended use, performance benchmarks by demographic subgroup, known failure modes, and recommended deployment constraints; [[AI Impact Assessment]] documentation prior to high-risk deployment
- **Audit layer**: Immutable [[Audit Trail]] records of all inputs, outputs, and intermediate decisions; third-party [[Algorithmic Auditing]] engagements using adversarial testing and bias probing toolkits; conformity self-assessments for medium-risk applications
- **Monitoring layer**: [[Post-Market Monitoring]] for performance drift, distributional shift, and emergent harms after deployment; incident logging with mandatory regulatory notification for serious failures
- **Redress layer**: Individual-facing [[Redress Mechanism]] procedures including human review of automated decisions, right of contestation, and compensation pathways; alignment with data subject rights under [[GDPR]] Article 22

  Each layer maps to specific obligations under different regulatory instruments. The EU AI Act's high-risk tier mandates layers 1–5 in full. The NIST AI RMF's GOVERN, MAP, MEASURE, and MANAGE functions distribute these responsibilities across an organisation's lifecycle processes.

  ## Use Cases / Major Families

  **High-risk domain accountability**: Credit scoring, employment screening, criminal risk assessment, and healthcare diagnostic support systems carry the most intensive accountability obligations under the EU AI Act. Deployers must complete [[Conformity Assessment]] before deployment, maintain comprehensive [[Audit Trail]] records, and implement [[Human Oversight]] for consequential decisions. The [[GDPR]] Article 22 right to human review of purely automated decisions applies independently.

  **Foundation model accountability**: Large generalist models such as GPT-4, Claude, and Gemini pose new accountability challenges because the same model is used for diverse purposes by heterogeneous deployers. The EU AI Act introduces tiered obligations for general-purpose AI models with systemic risk (above 10^25 FLOPs training compute): mandatory adversarial red-teaming, technical documentation, and cooperation with regulatory incident investigations.

  **Public sector accountability**: Government use of AI for benefits determination, border control, predictive policing, and judicial decision support attracts heightened accountability scrutiny because state power is involved. The [[Centre for Data Ethics and Innovation]] in the UK has mandated impact assessments for high-risk public-sector AI since 2024, and the [[OECD AI Principles]] include specific provisions on public-sector transparency.

  **Healthcare AI accountability**: Clinical decision support systems require alignment of [[AI Accountability]] with medical device regulation, creating a dual accountability regime. NHS trusts in England designate clinical AI responsible officers and require Data Protection Impact Assessments for all AI implementations, with additional accountability structures for diagnostic AI.

  ## Academic Context

  The intellectual foundations of AI accountability draw on several distinct scholarly traditions. Administrative law scholarship, particularly the work of Danielle Citron and Frank Pasquale on "technological due process," established that automated decision systems implicate constitutional and administrative law norms of notice, hearing, and reasoned decision-making. Computer science accountability research, exemplified by the ACM FAccT community (founding conference 2018), developed technical methods for fairness auditing, counterfactual explanation, and [[Algorithmic Accountability]] measurement. Policy scholarship, including the Oxford Internet Institute's research programme on algorithmic governance, analysed how accountability principles could be translated into regulatory instruments, culminating in analyses of the GDPR's Article 22 and later the EU AI Act's risk-tier model.

  Landmark papers include Selbst and Barocas (2018) "Fairness and Abstraction in Sociotechnical Systems" (FAccT) which argued that accountability cannot be achieved through technical fixes alone; Doshi-Velez and Kim (2017) on the taxonomy of interpretability required for accountability; and Raji et al. (2020) "Closing the AI Accountability Gap" which proposed an end-to-end framework for internal AI auditing. The Foundation Model Transparency Index (Bommasani et al., 2023, Stanford CRFM) systematically evaluated upstream accountability of major model providers, revealing significant gaps in documentation and testing disclosure. By 2024–2025, the scholarly focus had shifted to enforcement: how do regulatory institutions actually operationalise accountability obligations in a technical domain where they have limited internal expertise, and what role should third-party auditors and civil society play in filling enforcement gaps?

  ## Current Landscape (2026)

  The regulatory landscape has accelerated substantially since 2024. The [[EU AI Act]] entered into force on 1 August 2024, with enforcement proceeding in phases: the prohibition on unacceptable-risk AI practices (Article 5, covering social scoring and real-time biometric surveillance in public spaces) became applicable in February 2025; obligations on general-purpose AI model providers (Articles 51–56) apply from August 2025; and the full high-risk accountability regime (Articles 6–49, covering credit, employment, healthcare, and critical infrastructure AI) takes effect in August 2026. The newly established EU AI Office is the principal enforcement authority, with penalties reaching €35 million or 7% of global turnover for the most serious violations. National competent authorities in each member state handle sectoral enforcement.

  In the United Kingdom, the [[Information Commissioner's Office]] has emerged as the de facto lead AI regulator because data protection law—implemented in the UK GDPR and Data Protection Act 2018—touches virtually every AI system processing personal data. The Data (Use and Access) Act 2025, which came into law on 19 June 2025, updated the UK's automated decision-making rules, creating a more permissive framework for some uses while introducing new individual rights safeguards aligned with the GDPR baseline. The ICO is developing a statutory Code of Practice on AI and Automated Decision-Making under regulations expected to finalise in 2026. The [[Centre for Data Ethics and Innovation]] introduced mandatory impact assessments for high-risk public-sector AI in 2024, and the [[NIST AI Risk Management Framework]] remains the dominant voluntary structure for US-aligned organisations.

  The enterprise accountability market has industrialised: specialist vendors offer [[Algorithmic Auditing]] toolkits, continuous compliance monitoring dashboards, and [[Audit Trail]] management platforms. IBM, Microsoft, and Salesforce all publish annual responsible AI transparency reports. The Stanford HAI Foundation Model Transparency Index has become an informal industry benchmark, inducing competitive pressure on major model providers to improve upstream documentation. Accountability gaps in [[Foundation Model]] supply chains remain the most contested policy terrain in 2026, with ongoing negotiations in the EU AI Office about the precise scope of systemic-risk obligations.

  ## UK Context

  The UK has developed a distinctive approach to AI accountability that prioritises regulatory agility over comprehensive legislation. Rather than passing an AI-specific statute to match the EU AI Act, the government published a Pro-Innovation Approach to AI Regulation (DSIT, 2023) that tasks existing sector regulators—the ICO, Financial Conduct Authority (FCA), Medicines and Healthcare products Regulatory Agency (MHRA), and Ofcom—with applying their existing powers to AI applications within their remits, coordinated through a central AI Safety Institute (AISI). This creates a patchwork of accountability standards that are sector-specific rather than cross-cutting.

  Key institutional actors in the UK accountability ecosystem include:

- **[[Information Commissioner's Office]]**: Applies UK GDPR Article 22 automated decision-making obligations; issued detailed guidance on AI and data protection (2023, updated 2025); lead enforcement authority for AI-driven personal data processing across sectors
- **[[Centre for Data Ethics and Innovation]]**: Research and policy body producing impact assessment guidance, algorithmic transparency standards, and public-sector deployment frameworks
- **Alan Turing Institute**: Conducts foundational research on algorithmic accountability, fairness measurement, and audit methodology, with academic partnerships across Imperial College, Edinburgh, Oxford, and UCL
- **Financial Conduct Authority**: Enforcing accountability obligations for AI in financial services, including model validation, explainability of credit decisions, and consumer duty compliance

  Northern English institutional contributions are substantial. The University of Manchester hosts the Alan Turing Institute node and has a dedicated AI Ethics and Society research group investigating accountability in clinical AI and public administration. The universities of Leeds and Sheffield collaborate on accountability frameworks for industrial AI applications in manufacturing and logistics. Newcastle University's Digital Institute has produced influential work on algorithmic accountability in public-sector benefits administration, with partnerships with local government authorities in the North East. The Manchester-Leeds-Sheffield triangle is also home to significant financial services and healthcare AI deployment, making it a natural laboratory for accountability frameworks in regulated industries.

  NHS accountability for AI is governed by a layered framework: NHS England's AI Strategy (2023) requires all deployed AI systems to have a designated clinical responsible officer; the Care Quality Commission incorporates AI governance into its inspection regime; and NHS trusts must complete Data Protection Impact Assessments before deploying any AI that processes patient data. The Rotherham Doncaster and South Humber NHS Trust published one of the most detailed AI governance policies in the sector (2024), designating senior responsible officers for each AI system and requiring regular re-assessment of systems already in deployment.

  ## Future Directions (2026–2030)

  **Automated accountability infrastructure**: The manual processes currently used for [[Audit Trail]] management and [[Algorithmic Auditing]] will increasingly be replaced by automated compliance monitoring systems that continuously check deployed AI against performance benchmarks, detect distributional shift, and generate regulatory reporting artefacts. This shifts accountability from periodic audits to continuous assurance.

  **Foundation model accountability standardisation**: The EU AI Office and NIST are developing technical standards for assessing general-purpose AI model risk, which will feed into binding accountability obligations for model developers. Expect a convergence around common documentation templates (analogous to [[Model Card]] specifications), mandatory red-team testing protocols, and incident reporting registries for systemic-risk model failures.

  **AI liability law development**: Courts in the EU, UK, and US are beginning to adjudicate AI liability cases, which will crystallise the legal theory of [[Liability]] for algorithmic harms. The EU AI Liability Directive (proposed 2022, still in legislative process as of 2026) would create a rebuttable presumption of causal link between AI failures and harm, materially lowering the evidentiary burden for claimants and increasing the incentive for deployers to invest in [[Accountability]] infrastructure preventatively.

  **Agentic AI accountability**: The proliferation of autonomous AI agents that take multi-step actions in the world—purchasing, communications, code execution—creates new accountability challenges because individual decisions are harder to isolate and human oversight is structurally limited by the speed and volume of agent actions. Frameworks for agentic accountability, including agent audit logs, capability-level conformity assessments, and principal-agent accountability chains, are an active area of governance research in 2026.

  **International harmonisation**: Regulatory fragmentation between the EU AI Act, US executive AI governance, and the UK's sector-led model creates compliance complexity for global AI deployers. The OECD AI Principles and ISO/IEC 42001 are likely to become de facto harmonisation vehicles, with bilateral regulatory cooperation agreements filling gaps. The UK's post-Brexit position—maintaining EU data adequacy while diverging on AI regulation—creates particular tension that the ICO's Code of Practice on AI will need to navigate.

  ## Research & Literature

  1. Selbst, A.D. and Barocas, S. (2018). "Fairness and Abstraction in Sociotechnical Systems." *ACM FAccT*. Argued that accountability cannot be achieved through technical fixes alone without addressing system-level context.

  2. Doshi-Velez, F. and Kim, B. (2017). "Towards a Rigorous Science of Interpretable Machine Learning." *arXiv:1702.08608*. Established the taxonomy of interpretability necessary to support accountability audits.

  3. Raji, I.D., Smart, A., White, R.N., Mitchell, M., Gebru, T., Hutchinson, B., Smith-Loud, J., Theron, D. and Barnes, P. (2020). "Closing the AI Accountability Gap: Defining an End-to-End Framework for Internal Algorithmic Auditing." *ACM FAccT*. Proposed a structured internal audit framework covering scoping, mapping, artefact collection, and documentation.

  4. Citron, D.K. and Pasquale, F.A. (2014). "The Scored Society: Due Process for Automated Predictions." *Washington Law Review*, 89(1). Established administrative law foundations for algorithmic accountability.

  5. Pasquale, F. (2015). *The Black Box Society: The Secret Algorithms That Control Money and Information*. Harvard University Press. Seminal popular-academic account of the accountability crisis in algorithmic systems.

  6. Bommasani, R. et al. (2023). "The Foundation Model Transparency Index." *Stanford Center for Research on Foundation Models (CRFM)*. arXiv:2310.12941. Systematic evaluation of 10 major foundation model providers on 100 transparency criteria.

  7. European Parliament and Council (2024). "Regulation (EU) 2024/1689 on Artificial Intelligence (the AI Act)." *Official Journal of the European Union*. Establishing the most comprehensive binding AI accountability framework globally.

  8. NIST (2023). *Artificial Intelligence Risk Management Framework (AI RMF 1.0)*. National Institute of Standards and Technology. The primary US voluntary framework, organising AI governance around GOVERN, MAP, MEASURE, and MANAGE functions.

  9. ISO/IEC (2023). *ISO/IEC 42001: Artificial Intelligence — Management System*. International Organisation for Standardisation. First international management system standard for AI, requiring documented accountability structures.

  10. OECD (2019, revised 2024). *OECD Recommendation of the Council on Artificial Intelligence*. Organisation for Economic Co-operation and Development. The international policy baseline adopted by 46 countries, incorporating accountability as a core principle.

  11. Mitchell, M., Wu, S., Zaldivar, A., Barnes, P., Vasserman, L., Hutchinson, B., Spitzer, E., Raji, I.D. and Gebru, T. (2019). "Model Cards for Model Reporting." *ACM FAccT*. Introduced the model card documentation format as an accountability artefact.

  12. Buolamwini, J. and Gebru, T. (2018). "Gender Shades: Intersectional Accuracy Disparities in Commercial Gender Classification." *Proceedings of Machine Learning Research*, 81. Demonstrated empirically that commercial AI systems exhibit accountability-relevant demographic performance gaps.

  13. Wachter, S., Mittelstadt, B. and Russell, C. (2017). "Counterfactual Explanations without Opening the Black Box: Automated Decisions and the GDPR." *Harvard Journal of Law and Technology*, 31(2). Analysed how GDPR Article 22 creates accountability obligations through the right to explanation.

  14. Kearns, M. and Roth, A. (2019). *The Ethical Algorithm: The Science of Socially Aware Algorithm Design*. Oxford University Press. Accessible treatment of how algorithmic systems can be designed to embed accountability constraints.

  15. Floridi, L. et al. (2018). "AI4People—An Ethical Framework for a Good AI Society: Opportunities, Risks, Principles, and Recommendations." *Minds and Machines*, 28(4). Developed five principles of AI ethics including accountability as a core pillar.

  16. Gebru, T., Morgenstern, J., Vecchione, B., Vaughan, J.W., Wallach, H., Hal, D. and Crawford, K. (2018). "Datasheets for Datasets." *arXiv:1803.09010*. Extended the accountability documentation paradigm upstream to training data provenance.

  17. Hadfield-Menell, D. and Hadfield, G.K. (2019). "Incomplete Contracting and AI Alignment." *ICML Workshop on AI Safety*. Analysed how principal-agent misalignment in AI creates accountability gaps absent complete contractual specification.

  18. CDEI (2020). *Review into Bias in Algorithmic Decision-Making*. Centre for Data Ethics and Innovation, UK Government. Government-commissioned survey of accountability failures in UK public-sector algorithmic decision-making.

  19. Royal Academy of Engineering (2019). *Algorithms in Decision-Making: Accountability and Transparency*. Royal Academy of Engineering. UK-specific technical analysis of accountability requirements for algorithmic systems.

  20. Veale, M. and Binns, R. (2017). "Fairer Machine Learning in the Real World: Mitigating Discrimination without Collecting Sensitive Data." *Big Data and Society*, 4(2). UK-based research on practical accountability constraints in regulated sectors.

  21. Raji, I.D. and Buolamwini, J. (2019). "Actionable Auditing: Investigating the Impact of Publicly Naming and Shaming Commercial AI." *AIES 2019*. Empirical study showing that public accountability mechanisms drive measurable behavioural change by AI providers.

  22. Information Commissioner's Office (2023, updated 2025). *Guidance on AI and Data Protection*. ICO. UK regulatory guidance specifying accountability obligations for AI systems under the UK GDPR.

  23. Obermeyer, Z., Powers, B., Vogeli, C. and Mullainathan, S. (2019). "Dissecting Racial Bias in an Algorithm Used to Manage the Health of Populations." *Science*, 366(6464). High-impact demonstration of accountability failure in deployed healthcare AI.

  24. Whittlestone, J., Nyrup, R., Alexandrova, A. and Cave, S. (2019). "The Role and Limits of Principles in AI Ethics: Towards a Focus on Tensions." *AIES 2019*. Alan Turing Institute analysis of why principled accountability frameworks require institutional enforcement to be effective.

  25. Frontiers in Human Dynamics (2024). "Transparency and Accountability in AI Systems: Safeguarding Wellbeing in the Age of Algorithmic Decision-Making." *Frontiers in Human Dynamics*. Recent synthesis covering technical and governance dimensions of AI accountability.

  26. Rauf, A. et al. (2025). "Algorithmic Accountability and Ethical AI Frameworks for Regulatory Governance in Financial Technologies." *ResearchGate preprint*. Detailed accountability framework analysis for high-stakes financial AI applications.

  27. DSIT (2023). *A Pro-Innovation Approach to AI Regulation*. Department for Science, Innovation and Technology, UK Government. Sets out the UK's sector-led regulatory model and accountability assignment principles.

### Provenance

