An Agent Communication Language (ACL) is a formal, standardised message format and semantics that lets autonomous software agents exchange information, requests and commitments independently of their internal implementation. ACLs define performatives (speech acts such as inform, request and propose), a content language and an ontology reference so that interacting agents share a common interpretation of messages. Established examples include FIPA-ACL and KQML.

### Overview

- ACLs grew out of distributed artificial intelligence research, where heterogeneous agents built by different parties needed a shared communication standard. By separating the performative (the communicative intent) from the content (the proposition being communicated) and the ontology (the shared vocabulary), an ACL allows loose coupling: an agent can reason about what another agent intends without depending on how it is built. This underpins open multi-agent systems, negotiation protocols and service marketplaces.

### Key aspects

- Performatives express speech acts such as inform, request, query, propose and refuse.
- A content language (for example FIPA-SL or KIF) carries the propositional payload.
- An ontology reference fixes the meaning of terms used in the content.
- Conversation protocols sequence messages into coherent interaction patterns.
- Transport is decoupled, so the same ACL can run over different message-passing layers.

### Applications

- Automated negotiation and auction systems between buyer and seller agents.
- Service discovery and brokering in open agent marketplaces.
- Coordination of distributed sensors and robotic agents.
- Workflow orchestration across organisational boundaries.

### Provenance

