A deposit return scheme is a system in which a refundable deposit is charged on a product container and refunded when the empty container is returned.[^1]

The Department of Agriculture, Environment and Rural Affairs in Northern Ireland describes the arrangement simply: consumers pay a small deposit when buying a drink, which is refunded upon returning the empty container.[^1] The UK Government's policy statement says the scheme will introduce a refundable deposit on single-use drinks containers.[^2]

## UK scheme

The UK Government is working with the Scottish Government and DAERA to introduce the scheme, which aims to reduce litter, increase recycling rates and create high-quality recycled materials that drinks producers can use again.[^2] The scheme is managed by a deposit management organisation, and UK Deposit Management Organisation Limited was appointed to that role in May 2025.[^2] DAERA says the scheme is set to launch in October 2027, with deposits on single-use plastic and metal drinks containers from 150 ml to 3 litres.[^1]

DAERA also says that many countries have successfully used deposit return schemes to boost recycling rates of drinks containers, often reaching 90% or higher.[^1] The page cites no study for this, and the figure is not checked here against national data.

## Scope and distinctions

A deposit return scheme creates a reverse flow of containers, as described at [[Reverse Logistics]], and feeds recycled material back into production, as in a [[Circular Supply Chain]]. It differs from the producer take-back duties at [[Product Take-Back Scheme]] in that a payment attached to the item drives the return.

Both sources concern one national scheme that has not yet started operating. Neither source reports return rates achieved in the UK, costs to producers or retailers, or the treatment of other container types.

[^1]: Department of Agriculture, Environment and Rural Affairs (Northern Ireland), “Deposit Return Scheme”. https://www.daera-ni.gov.uk/topics/deposit-return-scheme
[^2]: UK Government, with the Scottish Government and DAERA, policy statement, “Deposit Return Scheme for drinks containers: policy statement”. https://www.gov.uk/government/publications/deposit-return-scheme-for-drinks-containers-policy-statement/deposit-return-scheme-for-drinks-containers-policy-statement

