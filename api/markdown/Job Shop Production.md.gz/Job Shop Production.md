Job shop production is a production system type for low-volume, high-variety work, where each product is typically unique to a customer and made intermittently on general-purpose equipment.[^1]

An open operations management text describes the job shop as a make-to-order type of business where production is intermittent: work continues on multiple products as time permits rather than one entire product at a time. It says the volume of output is low, the equipment is quite general purpose, and the workers are highly skilled in their craft or trade. Its examples are a small bakery making custom wedding cakes and a business making custom guitars or bicycles to a customer's measurements.[^1]

## Layout

Georgia Tech class notes describe the same system from the layout side: the overall layout is determined by the different processes, and machines are grouped by function to produce a multitude of products, located without regard for the material movements of the products. The environment consists of small order quantities with varying production routings, and the number of units of each product is typically less than a dozen. The notes call this a process layout associated with a job shop.[^2]

## Scope and distinctions

Job shop production is one of the classes under [[Production System Type]]. It is the low-volume end of the variety and volume spectrum, opposite [[Mass Production]], with [[Batch Production]] between them.[^1][^2] It is also related to make-to-order, which describes when production is triggered; see [[Make-to-Order]]. Another open text uses the make-to-order strategy for print or sign shops producing low-volume, high-variety goods according to customer specifications.[^3]

Engineer-to-order suppliers in one university study make components using a range of jobbing, batch, flow and assembly processes, so a job shop process can sit inside an engineer-to-order business; see [[Engineer-to-Order]].[^4]

## What the sources do not establish

No source gives figures on how common the job shop is. The class notes give an efficiency figure for the process layout based on the share of the year a plant is actually producing, and it depends on shifts worked, so it is not used here.[^2]

[^1]: Business LibreTexts (Introduction to Operations Management, NWTC), “6.3: Process Types”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/06:_Process_Design/6.03:_Process_Types
[^2]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design Class Notes, Chapter 12. Manufacturing Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/Logistics%20Systems%20Design/Full%20Text%20PDF/Manufacturing%20Systems.pdf
[^3]: eCampusOntario Pressbooks (Introduction to Canadian Business), “Operations Management”. https://ecampusontario.pressbooks.pub/bus108g/chapter/opsmanagement/
[^4]: Newcastle University, Department of Mechanical, Materials and Manufacturing Engineering (Dr Christian Hicks), “Make to Order / Engineer to Order Companies”. https://www.staff.ncl.ac.uk/chris.hicks/make_to_order.htm

