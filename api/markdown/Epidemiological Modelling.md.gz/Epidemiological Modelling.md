Epidemiological modelling is the use of mathematical and computational models to describe how infectious diseases spread through populations over time. Compartmental models partition a population into states such as susceptible, infected, and recovered, and use differential equations to govern transitions between them, while network and agent-based models capture heterogeneous contact structures. These models inform forecasting, intervention design, and public-health policy.

### Semantic Classification

### Content

## Compositional Relationships (Components)

```
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:hasPart epi:CompartmentalModel))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:hasPart epi:BasicReproductionNumber))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:hasPart epi:ContactNetwork))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:hasPart sci:StochasticProcess))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:hasPart sci:BayesianInference))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:hasPart sci:SensitivityAnalysis))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:hasPart sci:DataAssimilation))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:hasPart sci:UncertaintyQuantification))
```

## Dependency Relationships

```
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:requires sci:DifferentialEquation))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:requires sci:BayesianInference))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:requires sci:Statistics))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:requires sci:MonteCarloSimulation))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:requires sci:NetworkAnalysis))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:dependsOn sci:ComputationalModelling))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:dependsOn sci:HighPerformanceComputing))
```

## Capability Relationships

```
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:enables epi:PandemicPreparedness))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:enables epi:VaccineAllocation))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:enables epi:ContactTracing))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:enables epi:HealthcareDemandForecasting))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:enables sci:TimeSeriesForecasting))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:enables epi:WastewaterSurveillance))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:supports epi:PublicHealth))
```

## Implementation Relationships

```
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:implements epi:SIRModel))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:implements epi:SEIRModel))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:implements ai:AgentBasedModelling))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:implements sci:ProbabilisticModelling))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:implements sci:BayesianInference))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:uses ai:MachineLearning))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:uses sci:DataAssimilation))
```

## Reduction Relationships

```
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:reducesTo epi:CompartmentalModel))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:reducesTo sci:DifferentialEquation))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:reducesTo epi:SIRModel))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:reducesTo sci:StochasticProcess))
```

## Support Relationships

```
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:supports epi:PublicHealth))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:supports epi:PolicySimulation))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:supports sci:DigitalTwin))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:supports epi:VaccinationStrategy))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:supports epi:PandemicPreparedness))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:relatedTo sci:ComputationalBiology))
SubClassOf(epi:EpidemiologicalModelling
  ObjectSomeValuesFrom(ai:relatedTo sci:ComplexSystems))
```

## About

- Epidemiological Modelling sits at the intersection of [[Mathematical Biology]], [[Computational Modelling]], and [[Public Health]] policy, constituting one of the most consequential applications of applied mathematics to human welfare. Its intellectual lineage runs from Daniel Bernoulli's 1760 analysis of smallpox inoculation — the first mathematical treatment of an infectious disease — through William Farr's statistical law of epidemic rise and decline (1840), to the landmark Kermack-McKendrick series of papers (1927–1939) that established the threshold theorem and the SIR framework that still underpins the field. The threshold theorem proved that an epidemic in a homogeneous population only occurs if the initial fraction susceptible exceeds a critical threshold 1/R₀, providing the theoretical basis for herd immunity calculations that guide vaccination coverage targets. The mid-twentieth century saw the development of more refined mathematical epidemiology under Norman Bailey, George Macdonald (who derived the Ross-Macdonald model for malaria transmission), and Klaus Dietz, establishing the analytical apparatus of next-generation matrices, threshold conditions in heterogeneous populations, and the theory of endemic equilibria.
- The modern era of Epidemiological Modelling is defined by three converging forces: increased computational power enabling stochastic simulation at population scale; the proliferation of digital surveillance data streams beyond traditional case counts; and the integration of statistical and machine learning methods into the modelling workflow. The SIR-family of deterministic ODE models, while analytically tractable and valuable for intuition, rests on the assumption of homogeneous mixing — every individual contacts every other at the same rate — which is epidemiologically unrealistic for most real populations with household structure, age-assortative contact patterns, geographic heterogeneity, and behavioural heterogeneity. Age-structured compartmental models address demographic heterogeneity through contact matrices (derived from social contact surveys such as the POLYMOD study, Mossong et al. 2008) that specify age-assortative contact rates between age groups, enabling R₀ to be computed as the spectral radius of the next-generation matrix. [[Network Analysis]] models encode the contact structure as an explicit graph, enabling the study of how degree distribution, clustering, and community structure affect epidemic dynamics and intervention efficacy. The configuration model and random geometric graphs provide tractable network ensembles for analytical study, while empirical contact networks from proximity sensors, mobile phone data, and social network records provide realistic substrates for simulation. [[Agent-Based Modelling]] frameworks — exemplified by CovidSim (Imperial College London) and EpiModel — provide the highest resolution representation of population heterogeneity and spatial structure, at the cost of computational expense and the challenge of parameter calibration in high-dimensional systems.
- [[Data Assimilation]] from the meteorological tradition has been adapted for epidemic models to continuously update model state and parameters as new surveillance data arrive, addressing a fundamental challenge of real-time outbreak response: models parameterised from early outbreak data become misspecified as the epidemic evolves, behaviour changes, and new variants emerge. Ensemble Kalman filter methods and particle filters enable online state estimation, tracking latent compartment sizes and effective reproduction number Rₜ in near-real-time from reported case counts. [[Bayesian Inference]] via Markov chain Monte Carlo (MCMC) or sequential Monte Carlo (SMC) provides the principled framework for jointly estimating transmission parameters, observation processes (reporting rates, testing sensitivity), and intervention effects from multiple heterogeneous data streams simultaneously. The challenge of identifiability — multiple parameter combinations producing similar observational signatures — motivates [[Sensitivity Analysis]] using Sobol indices or Morris screening to identify which parameters are estimable from available data and which must be fixed at prior values from biological studies or meta-analyses.
- The COVID-19 pandemic (2020–2023) was a watershed moment for Epidemiological Modelling, demonstrating both its power and its limitations at the level of global public policy. The landmark Imperial College London Report 9 (Ferguson et al., 16 March 2020) used a large-scale [[Agent-Based Modelling]] framework with 66 million synthetic UK agents and 330 million synthetic US agents, parameterised from social contact survey data, to project approximately 510,000 deaths in Great Britain and 2.2 million in the United States under unmitigated spread. Crucially, it quantified that combinations of household isolation, school closure, and social distancing could reduce peak intensive care unit (ICU) demand by over 60 per cent. This analysis directly informed the UK government's announcement of a national lockdown on 23 March 2020 — one of the most consequential applications of Epidemiological Modelling in modern policy history. The SPI-M-O (Scientific Pandemic Influenza Group on Modelling, Operational sub-group) coordinated the UK's multiple modelling groups (Imperial, LSHTM, Warwick, Cambridge) during the pandemic, synthesising ensemble projections across models with different structures and assumptions, producing the consensus medium-term scenario planning that informed Cabinet Office and NHS England capacity planning throughout 2020–2022. Simultaneously, the pandemic drove rapid methodological innovations: the EpiNow2 R package enabling near-real-time Rₜ estimation from case reports; digital wastewater-based epidemiology (WBE) providing population-level infection prevalence independent of testing behaviour; genomic surveillance via COG-UK integrating phylogenetic analysis with epidemiological modelling to track variant emergence and spread; and neural network surrogate models that dramatically accelerated MCMC sampling by replacing expensive forward model evaluations with fast emulators.
- The period 2024–2026 has witnessed accelerating integration of artificial intelligence into Epidemiological Modelling workflows. A landmark February 2025 Nature paper from the MRC Centre for Global Infectious Disease Analysis at Imperial College London outlined how recent advances in AI can accelerate breakthroughs in answering key epidemiological questions and can be applied to routinely collected infectious disease surveillance data. Physics-informed neural networks (PINNs) have been applied to learn SIR and SEIR ODE dynamics from sparse case count data, providing a meshless, differentiable alternative to traditional ODE solvers that enables gradient-based inference of transmission parameters. Neural parameter calibration methods — combining deep learning with [[Uncertainty Quantification]] — have been demonstrated for epidemic forecasting with improved accuracy over MCMC baselines, particularly in data-sparse outbreak scenarios. Universal Differential Equations (Rackauckas et al.) provide a hybrid framework combining mechanistic ODE compartmental structure with learned neural network terms that capture unmeasured biological or behavioural processes, enabling adaptive transmission rate estimation that responds to behavioural changes and variant dynamics without explicit re-parameterisation.

## Components / Architecture

- **Compartmental Model Layer**
  - SIR model — Susceptible, Infectious, Recovered; governed by dS/dt = -βSI/N, dI/dt = βSI/N - γI, dR/dt = γI; R₀ = β/γ; threshold condition for epidemic: R₀ > 1
  - SEIR model — adds Exposed (latent period E); dE/dt = βSI/N - σE, dI/dt = σE - γI; mean latent period 1/σ
  - SEIRD — adds Deceased compartment D with mortality rate δ
  - SEIQR — adds Quarantine compartment for contact-traced exposed individuals
  - SEIHRD — adds Hospitalised compartment H for healthcare demand modelling
  - Metapopulation models — spatial patches (districts, regions, countries) coupled by mobility flux; used for multi-country pandemic spread modelling
  - Age-stratified SEIR — next-generation matrix formalism; contact matrices from POLYMOD survey (Mossong et al.); R₀ = spectral radius of K = G · F, where G is the generation time distribution and F the force of infection matrix
- **Stochastic Simulation Layer**
  - Continuous-time Markov chain (CTMC) SIR — exact stochastic simulation via Gillespie algorithm; essential for small populations where demographic stochasticity determines outbreak fate
  - Tau-leaping — approximate stochastic simulation; Poisson or negative-binomial transition counts; 100–1,000 times faster than Gillespie for large populations
  - Branching process approximation — near extinction or near threshold; enables closed-form probability of outbreak establishment given importation of k infectious cases
  - Individual-based stochastic simulation — each agent drawn as a realisation of the stochastic process; enables heterogeneous transmission rates, contact duration distributions, and importation events
- **Network and Spatial Layer**
  - Static contact network — configuration model, Barabási-Albert scale-free, Watts-Strogatz small-world; analytical SIR results via cavity methods and heterogeneous mean-field theory
  - Dynamic contact network — adaptive network where susceptibles rewire away from infectious neighbours; models behaviour change during epidemics
  - Geographic information system (GIS) layer — spatial population density rasters, road network distance matrices, transport flow data; enables spatial heterogeneity in force of infection and intervention reach
  - Mobility data integration — mobile phone GPS traces, commuter flow surveys, air travel itinerary data (IATA); parameterises spatial transmission kernels in metapopulation and network models
- **Agent-Based Epidemiological Layer**
  - Synthetic population generation — census microdata, household survey imputation, land use data; creates agents with age, sex, household composition, workplace/school assignment, and contact group membership
  - Transmission events — contacts drawn from age-stratified contact matrices; per-contact transmission probability depends on viral load, setting (household vs. workplace vs. community), and host immune status
  - Intervention modules — mass vaccination (coverage, schedule, dose interval, waning), targeted NPIs (school closure, workplace closure, household quarantine, shielding), test-trace-isolate (testing capacity, turnaround time, compliance fraction)
  - Platforms: CovidSim (C++, Imperial College), EpiModel (R, University of Washington), OpenABM-Covid19 (C++, Oxford/Edinburgh), Epiabm (Python/C++, Cambridge), FLAME GPU 2 (GPU-accelerated, Sheffield)
- **Statistical Inference and Calibration Layer**
  - [[Bayesian Inference]] via MCMC — Metropolis-Hastings, Hamiltonian Monte Carlo (Stan/CmdStan), Sequential Monte Carlo (SMC2, PMMH); joint posterior over transmission parameters, reporting rates, seeding dates
  - Approximate Bayesian Computation (ABC) — simulation-based inference without explicit likelihood; fits summary statistics of simulated epidemics to observed data; computationally feasible for individual-based models
  - Neural posterior estimation — normalising flows trained on simulation-observation pairs; amortised inference enabling rapid posterior evaluation for new outbreak data without re-running MCMC
  - EpiNow2 / EpiEstim — Bayesian Rₜ estimation frameworks in R; widely deployed by UKHSA and WHO during COVID-19; nowcasting corrects for reporting delays and right-censoring of recent case counts
  - [[Data Assimilation]] — ensemble Kalman filter (EnKF) and particle filter for real-time state estimation; fuses daily surveillance counts into running model state; analogous to numerical weather prediction assimilation
- **Surveillance Data Integration Layer**
  - Case count time series — PCR/LFT positive tests stratified by age, region, setting; right-censored and subject to testing behaviour confounding
  - Genomic surveillance — COG-UK sequencing programme; variant frequencies by region and time; integrated with phylogenetic trees to estimate variant-specific transmission advantages
  - Seroprevalence surveys — REACT-2, ONS Infection Survey; population-level antibody prevalence; corrects for under-reporting and enables attack rate estimation
  - [[Wastewater Surveillance]] — SARS-CoV-2 RNA concentration in sewage; early warning signal 3–7 days ahead of clinical case counts; UKHSA expanding to 11 high-priority pathogens under £1.3 million Integrated Security Fund (2025)
  - Hospital admissions, ICU occupancy, deaths — direct demand metrics for NHS capacity modelling; lag behind infection events by 1–3 weeks

## Use Cases / Major Families

- **Pandemic response planning** — SIR/SEIR compartmental models and ABMs jointly provide the epidemic curve projections, healthcare demand forecasts, and intervention efficacy estimates required for governments to plan hospital surge capacity, procure personal protective equipment, and calibrate non-pharmaceutical intervention stringency. During COVID-19, the UK's SPI-M-O ensemble combined outputs from Imperial College London (CovidSim ABM), London School of Hygiene and Tropical Medicine (LSHTM Epi model), Warwick University (WM model), and Cambridge University (PHE-MRC model) into consensus scenarios used for Cabinet Office Briefing Room (COBR) planning. Ensemble spread across models provided probabilistic uncertainty ranges that prevented over-reliance on any single model's projection.
- **Vaccine allocation and deployment strategy** — Age-structured epidemiological models with explicit vaccine efficacy parameters enable optimisation of vaccination priority ordering. Priority allocation to older age groups was validated by models showing that vaccinating the highest-contact versus highest-mortality groups produces qualitatively different epidemic trajectories, and that age-prioritised vaccination minimised deaths per dose administered under supply constraints. Network models capture the indirect (herd immunity) protection conferred by vaccinating highly connected nodes before peripheral nodes.
- **Endemic disease burden and control** — Long-term endemic equilibrium analysis using SIS and SEIRS models (allowing waning immunity) estimates the ongoing disease burden at steady state and the vaccination coverage threshold required for elimination (herd immunity threshold = 1 - 1/R₀). Applied to seasonal influenza (R₀ ≈ 1.2–1.4; herd immunity threshold 17–29%), measles (R₀ ≈ 12–18; herd immunity threshold 92–94%), and polio. WHO's Global Polio Eradication Initiative uses metapopulation models with real mobility data to identify high-risk transmission corridors and plan supplementary immunisation activity campaigns.
- **Emerging pathogen surveillance and early warning** — During the first weeks of a novel outbreak, near-real-time Rₜ estimation from case report time series (corrected for reporting delays using EpiNow2) provides early situational awareness. Phylogenetic molecular clock models using pathogen genomic sequences estimate the date of origin and geographic source of emergence. Branching process models estimate the probability that initial imported cases will lead to sustained transmission chains, informing quarantine and border control policies. UKHSA's wastewater epidemiology programme (2025) targets 11 high-priority pathogens for early detection in sewage before clinical cases present.
- **Non-pharmaceutical intervention (NPI) evaluation** — Counterfactual modelling quantifies the effect of specific NPIs by comparing observed epidemic trajectories against model projections under the NPI-free scenario. Difference-in-differences analyses using geographic variation in NPI timing exploit natural experiments. Comprehensive NPI effect meta-analyses (Flaxman et al., 2020; Brauner et al., 2021) used Bayesian hierarchical epidemiological models across multiple European countries to simultaneously estimate the effectiveness of school closure, workplace closure, social gathering bans, and lockdown, finding that lockdowns and business closure had the largest effects on Rₜ reduction.
- **Tropical and vector-borne disease modelling** — Ross-Macdonald malaria transmission models parameterise the mosquito-human transmission cycle, enabling optimal vector control targeting and insecticide resistance management. Dengue and Zika metapopulation models with Aedes aegypti density data and temperature-dependent transmission rates project outbreak risk under climate change scenarios. Leishmaniasis and Chagas disease models incorporate zoonotic reservoir hosts (dogs, domestic animals) as transmission sources requiring veterinary intervention alongside human treatment.

## Academic Context

- Epidemiological Modelling as a formalised discipline traces its origins to two traditions: the theoretical mathematical epidemiology pioneered by Ross, Kermack, and McKendrick in the early twentieth century, and the statistical epidemiology of Farr, Snow, and Greenwood focused on empirical analysis of disease surveillance data. These traditions converged in the second half of the twentieth century as computing enabled both large-scale numerical solution of ODE systems and statistical fitting of models to data.
- Key theoretical milestones include: Ross (1911) demonstrating mathematically that malaria eradication does not require eliminating every mosquito but reducing the mosquito density below a threshold — the first proof that an epidemic threshold concept governs disease persistence; Kermack and McKendrick (1927) deriving the SIR threshold theorem and the final size relation between R₀ and the fraction ultimately infected; MacDonald (1952) extending Ross's malaria model to include the extrinsic incubation period in mosquitoes and vector survival; Bailey (1957) formalising stochastic epidemic models; Anderson and May (1979, 1982, 1991) establishing the theoretical framework for age-structured transmission dynamics, parasite-host coevolution, and vaccination theory in a series of papers culminating in the monograph "Infectious Diseases of Humans: Dynamics and Control" (1991) — the definitive reference for mathematical epidemiology.
- The computational revolution of the 1990s–2000s enabled agent-based epidemic simulation at realistic population scales. Ferguson et al. (2005) published the first large-scale pandemic influenza ABM calibrated to UK and US demographic data, directly influencing the 2009 H1N1 pandemic response. Halloran et al. (2008) validated ABM for community influenza interventions. Eubank et al. (2004) modelled smallpox spread across the real social contact network of Portland, Oregon using mobility data.
- The journal Epidemics (founded 2009, Elsevier) and the Journal of Mathematical Biology, Bulletin of Mathematical Biology, and PLOS Computational Biology are the primary venues for Epidemiological Modelling research. The Society for Mathematical Biology (SMB) and the European Society for Mathematical and Theoretical Biology (ESMTB) are the primary professional communities. The MRC Centre for Global Infectious Disease Analysis at Imperial College London (directed by Azra Ghani and previously Neil Ferguson) is the world's most cited academic Epidemiological Modelling group. The Centre for Mathematical Modelling of Infectious Diseases (CMMID) at London School of Hygiene and Tropical Medicine is a close second, and the interdisciplinary Warwick Institute for the Science of Cities contributes substantially to network and spatial epidemic models.

## Current Landscape (2026)

- The post-COVID-19 period 2024–2026 is characterised by consolidation of pandemic-era methodological advances into standard operational practice, alongside rapid expansion of AI-augmented modelling. The UK government's 2023 COVID-19 Preparedness Review explicitly listed improved Epidemiological Modelling capacity as a national security priority, leading to sustained investment in modelling infrastructure at UKHSA, the MRC Centre at Imperial, and CMMID at LSHTM.
- A February 2025 Nature paper from the MRC Centre for Global Infectious Disease Analysis systematically reviewed how advances in AI — including deep learning surrogate models, physics-informed neural networks, and neural posterior estimation — can accelerate answering key epidemiological questions using routinely collected surveillance data. By mid-2025, AI-based forecasting models were operationally incorporated into national response dashboards for multiple respiratory pathogens, demonstrating lead times of up to two weeks for hospitalisation peak prediction. The EditoriAl in PMC (2025) reviewing AI's journey through COVID-19 identified neural network calibration, wastewater signal integration, and generative model-based synthetic data augmentation as the three highest-impact AI contributions to Epidemiological Modelling.
- [[Physics-Informed Neural Network]]s applied to epidemic ODEs have been demonstrated to simultaneously infer transmission parameters and solve forward epidemic trajectories from sparse case count data, with computational advantages over MCMC for problems with smooth transmission dynamics. A 2025 ScienceDirect paper applied PINNs to COVID-19 data assimilation across multiple UK regions with promising accuracy. Neural parameter calibration with [[Uncertainty Quantification]] (PMC12007818, 2025) demonstrated improved accuracy over traditional MCMC for epidemic forecasting under data scarcity, particularly relevant for novel pathogen emergence scenarios.
- UKHSA's wastewater epidemiology programme expanded in 2025 from a COVID-19 polio surveillance network of 28 sites to a broader R&D programme targeting 11 high-priority pathogens — including Crimean-Congo haemorrhagic fever, Lassa fever, Mpox, West Nile virus, and hypervirulent Klebsiella pneumoniae — funded by £1.3 million from the UK Integrated Security Fund. This programme integrates wastewater environmental signals directly into Bayesian epidemiological models as an additional data stream alongside clinical case counts, enabling earlier outbreak detection independent of healthcare-seeking behaviour.
- Gaussian Markov random field (GMRF) spatial models have been applied to the UK population (stratified by NHS region and age group) to provide computationally efficient Bayesian inference for epidemic parameters at geographic resolution previously requiring full MCMC chains on HPC clusters (arXiv:2505.03938, 2025). Differentiable epidemic simulation via Universal Differential Equations in the Julia SciML ecosystem enables gradient-based calibration of SIR models with learned neural network terms for time-varying transmission rates (arXiv:2310.16804).
- The global landscape shows parallel advances: the US CDC's FluSight ensemble now routinely incorporates both mechanistic epidemiological models and [[Machine Learning]] regression models; ECDC operates a multi-country epidemic intelligence platform integrating modelling with genomic surveillance; WHO's Epidemic Intelligence from Open Sources (EIOS) platform aggregates outbreak signals from web and social media for early warning model initialisation.

## UK Context

- The United Kingdom holds a globally pre-eminent position in Epidemiological Modelling, with world-leading academic groups, national public health institutions, and a policy infrastructure for integrating modelling into government decision-making that was significantly strengthened following COVID-19.
- **Imperial College London** — The MRC Centre for Global Infectious Disease Analysis (Azra Ghani, previously Neil Ferguson) is the world's most cited Epidemiological Modelling group. CovidSim (C++, 66 million synthetic UK agents) directly informed the March 2020 lockdown. Imperial also hosts the VIMC (Vaccine Impact Modelling Consortium) coordinating global vaccine burden estimation for Gavi and UNICEF across 10 pathogens in 112 countries, providing the modelled evidence base for the global vaccine investment portfolio.
- **London School of Hygiene and Tropical Medicine (LSHTM)** — The Centre for Mathematical Modelling of Infectious Diseases (CMMID) — one of the largest infectious disease modelling groups globally, with over 100 researchers — was instrumental in UK COVID-19 SPI-M-O modelling. CMMID maintains widely used open-source tools including EpiNow2 (real-time Rₜ estimation), epidemia (Bayesian renewal process models), and socialmixr (contact matrix estimation). Strong tradition in global health [[Epidemiological Modelling]]: malaria (Malaria Atlas Project), tuberculosis, neglected tropical diseases.
- **University of Warwick** — Warwick Mathematics Institute hosts a major infectious disease modelling group (Matt Keeling, Mike Tildesley) contributing the WM (Warwick Model) to SPI-M-O. Keeling's textbook "Modeling Infectious Diseases in Humans and Animals" (with Rohani, 2007) is a standard graduate reference. Strong tradition in foot-and-mouth disease modelling informing DEFRA veterinary policy.
- **University of Cambridge** — Department of Applied Mathematics and Theoretical Physics (DAMTP) and MRC Biostatistics Unit contribute Bayesian epidemic methodology. Cambridge developed the Epiabm open-source Python/C++ framework for spatially explicit ABM at local-authority resolution, used in UKHSA pandemic preparedness infrastructure. Julia Gog (St John's College) is a leader in network epidemiology.
- **University of Edinburgh** — Roslin Institute and the Usher Institute contribute veterinary and human epidemiological modelling, including spatial spread of livestock disease and zoonotic transmission risk assessment. Edinburgh's access to ARCHER2 HPC (750,000 AMD EPYC cores, 48 PetaFLOPs) enables large-scale ensemble runs for stochastic individual-based epidemic models.
- **UKHSA (UK Health Security Agency)** — The national public health agency operates the Epidemiology Modelling Review Group (EMRG) and maintains operational modelling capacity for seasonal influenza, respiratory syncytial virus, COVID-19, and emerging pathogens. UKHSA's Joint Biosecurity Centre (JBC) uses real-time epidemiological models to monitor threat levels. The wastewater epidemiology expansion (2025, £1.3 million ISF funding) targets 11 high-priority pathogens.
- **Northern England** — Manchester's Centre for Epidemiology at the University of Manchester contributes to chronic disease epidemiology and health economic modelling. Sheffield's FLAME GPU platform (Paul Richmond, Computer Science) provides world-leading GPU-accelerated simulation infrastructure applicable to large-scale epidemic ABMs. Leeds' School of Medicine contributes methodological work on infectious disease surveillance design and reporting fraction estimation. Newcastle University's Institute for Ageing contributes age-stratified epidemic modelling for care home outbreak dynamics.

## Future Directions (2026–2030)

- **Real-time digital epidemiological twins** — Integration of continuously calibrated epidemiological models with live multi-stream surveillance data (clinical cases, wastewater, genomic surveillance, mobility data) to produce real-time [[Digital Twin]] representations of outbreak dynamics across spatial scales from individual households to national populations. These twins will enable automated Rₜ monitoring with alert triggers, dynamic hospital capacity demand forecasting, and near-real-time counterfactual evaluation of emerging interventions.
- **AI-augmented parameter inference** — Neural posterior estimation (NPE) and simulation-based inference frameworks (sbi, BayesFlow) will replace computationally expensive MCMC for ABM calibration, enabling full Bayesian parameter estimation for models with millions of agents within hours rather than weeks. Differentiable epidemic ABMs (JAX-based, analogous to ABMax) will enable gradient-based optimisation of intervention parameters directly through the simulation graph.
- **Multi-pathogen surveillance modelling** — Simultaneous multi-pathogen epidemiological models that track co-circulation of seasonal influenza, RSV, COVID-19, and emerging pathogens within a unified framework, accounting for immunological interactions (cross-protection, immune landscape) and shared healthcare demand. Integration with wastewater multi-pathogen surveillance (UKHSA 2025 programme) will provide environmental leading indicators feeding directly into ensemble model nowcasts.
- **Climate-epidemic coupling** — Epidemiological models coupled to climate projections will forecast how temperature, rainfall, and urbanisation trends affect the geographic range and seasonality of vector-borne diseases (malaria, dengue, Lyme disease, West Nile virus) under 2°C and 4°C warming scenarios, informing UK border health screening priorities and global health investment decisions.
- **Pathogen genomics integration** — Full phylogenetic-epidemiological models (PhyDyn, BEAST2 phylodynamic frameworks) will routinely integrate genomic surveillance into transmission parameter estimation, enabling variant-specific Rₜ estimation and geographic origin inference within hours of sequence availability. Neural network phylogenetic models will dramatically accelerate the Bayesian phylodynamic inference currently bottlenecked by MCMC on large sequence datasets.
- **Behavioural and social media data integration** — Incorporating mobility indices (Google Mobility Reports, mobile phone aggregates), social media risk perception signals, and digital contact tracing data as model covariates will improve behavioural realism in epidemiological models and enable anticipatory modelling of compliance changes. [[Agent-Based Modelling]] with [[Large Language Model]] as agent behavioural engines (Park et al. 2023 paradigm) offers a pathway to realistic heterogeneous behavioural responses to epidemic communication.

## Research & Literature

- 1. Kermack, W. O., & McKendrick, A. G. (1927). "A Contribution to the Mathematical Theory of Epidemics." Proceedings of the Royal Society of London A, 115(772), 700–721. [Foundation SIR threshold theorem]
- 2. Ross, R. (1911). The Prevention of Malaria (2nd ed.). John Murray. [First mathematical epidemic threshold proof]
- 3. Anderson, R. M., & May, R. M. (1991). Infectious Diseases of Humans: Dynamics and Control. Oxford University Press. [Canonical mathematical epidemiology reference]
- 4. Bailey, N. T. J. (1957). The Mathematical Theory of Infectious Diseases. Griffin. [Stochastic epidemic theory]
- 5. Keeling, M. J., & Rohani, P. (2007). Modeling Infectious Diseases in Humans and Animals. Princeton University Press. [Graduate-level textbook; [[Network Analysis]] and [[Agent-Based Modelling]] coverage]
- 6. Mossong, J., et al. (2008). "Social Contacts and Mixing Patterns Relevant to the Spread of Infectious Diseases." PLOS Medicine, 5(3), e74. [POLYMOD contact matrix survey; underpins age-structured models]
- 7. Ferguson, N. M., et al. (2006). "Strategies for Mitigating an Influenza Pandemic." Nature, 442(7101), 448–452. [First large-scale pandemic ABM with UK/US synthetic populations]
- 8. Ferguson, N. M., et al. (2020). "Impact of Non-Pharmaceutical Interventions (NPIs) to Reduce COVID-19 Mortality and Healthcare Demand." Imperial College COVID-19 Response Team Report 9. [Policy-defining COVID-19 ABM]
- 9. Flaxman, S., et al. (2020). "Estimating the Effects of Non-Pharmaceutical Interventions on COVID-19 in Europe." Nature, 584(7820), 257–261. [Bayesian hierarchical epidemic model; NPI effect estimation]
- 10. Brauner, J. M., et al. (2021). "Inferring the Effectiveness of Government Interventions Against COVID-19." Science, 371(6531), eabd9338. [Multi-country [[Bayesian Inference]] for NPI effects]
- 11. Cori, A., et al. (2013). "A New Framework and Software to Estimate Time-Varying Reproduction Numbers During Epidemics." American Journal of Epidemiology, 178(9), 1505–1512. [EpiEstim Rₜ estimation; basis of EpiNow2]
- 12. Eubank, S., et al. (2004). "Modelling Disease Outbreaks in Realistic Urban Social Networks." Nature, 429(6988), 180–184. [First contact-network epidemic ABM using real mobility data]
- 13. Diekmann, O., Heesterbeek, J. A. P., & Metz, J. A. J. (1990). "On the Definition and the Computation of the Basic Reproduction Ratio R₀ in Models for Infectious Diseases." Journal of Mathematical Biology, 28(4), 365–382. [Next-generation matrix framework for R₀]
- 14. Evensen, G. (1994). "Sequential Data Assimilation with a Nonlinear Quasi-Geostrophic Model." Journal of Geophysical Research: Oceans, 99(C5), 10143–10162. [Ensemble Kalman Filter; adapted for epidemic [[Data Assimilation]]]
- 15. Raissi, M., Perdikaris, P., & Karniadakis, G. E. (2019). "Physics-Informed Neural Networks." Journal of Computational Physics, 378, 686–707. [[[Physics-Informed Neural Network]] framework; applied to epidemic ODEs]
- 16. Rackauckas, C., et al. (2020). "Universal Differential Equations for Scientific Machine Learning." arXiv:2001.04385. [Hybrid neural-ODE epidemic modelling in Julia SciML]
- 17. Thompson, R. N., et al. (2019). "Improved Inference of Time-Varying Reproduction Numbers During Infectious Disease Outbreaks." Epidemics, 29, 100356. [EpiNow2 methodology]
- 18. Cranmer, K., Brehmer, J., & Louppe, G. (2020). "The Frontier of Simulation-Based Inference." PNAS, 117(48), 30055–30062. [Neural posterior estimation for complex simulators; applicable to epidemic ABMs]
- 19. Pullano, G., et al. (2021). "Underdetection of COVID-19 Cases in France Threatens Epidemic Control." Nature, 590(7844), 134–139. [Bayesian epidemic model integrating multiple surveillance streams]
- 20. arXiv:2505.03938 (2025). "A computationally efficient framework for realistic epidemic modelling through Gaussian Markov random fields." [GMRF spatial epidemic modelling; UK case study]
- 21. arXiv:2310.16804. "Learning COVID-19 Regional Transmission Using Universal Differential Equations in a SIR Model." [Differentiable SIR with learned transmission rates]
- 22. PMC12007818 (2025). "Neural parameter calibration and uncertainty quantification for epidemic forecasting." [AI-augmented Bayesian inference for epidemic forecasting]
- 23. PMC11695538 (2025). "The role of AI in pandemic responses: from epidemiological modelling to vaccine development." NCBl review. [Comprehensive AI/ML integration review]
- 24. PMC12203812 (2025). "Outbreak oracles: how AI's journey through COVID-19 shapes future epidemic strategy." Editorial review. [AI integration in epidemic forecasting post-COVID]
- 25. UKHSA (2025). "UKHSA launches development programme for wastewater monitoring techniques." GOV.UK. [Wastewater epidemiology expansion to 11 pathogens; £1.3M ISF funding]
- 26. ScienceDirect (2024). "Approaching epidemiological dynamics of COVID-19 with physics-informed neural networks." Journal of the Franklin Institute. [PINNs for epidemic parameter inference]
- 27. Chopra, A., et al. (2023). "Differentiable Agent-Based Epidemiology." AAMAS 2023. [Gradient-based calibration of epidemic ABMs]
- 28. Nature Research Intelligence (2025). "Epidemiological Modelling" topic summary. https://www.nature.com/research-intelligence/nri-topic-summaries/epidemiological-modelling-for-l3-420205 [Current research landscape overview]

### Provenance

