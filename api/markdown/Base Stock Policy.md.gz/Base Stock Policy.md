A base stock policy replenishes the inventory position up to a target level, the base stock or order-up-to level.[^1][^2]

A Penn State teaching note describes the periodic review system as ordering enough to increase the inventory position to a predetermined base-stock or order-up-to level, so that the order quantity varies while the average order quantity over many periods equals average demand per period.[^1] MIT slides write the periodic form as (R, S): order S minus the inventory position every R periods.[^2]

## Relation to reorder point policies

Columbia University lecture notes say that the case where the order quantity Q is one reduces the (Q, r) policy to a base stock policy with base stock level S equal to r plus Q, which is r plus one.[^3] See [[Reorder Point Policy]].

## Optimality

A review of operations and supply chain management says the optimality of periodic review order-up-to policies was proved for stochastic demand with backordering (citing Arrow and colleagues, 1958), while later studies turned to lost-sales models.[^4] The original proof was not opened. The wording of the review limits the claim to the backordering case.[^4]

## Scope and distinctions

Base stock policy is filed under [[Periodic Review Policy]], following the Penn State and MIT descriptions. The Columbia notes reach the same policy through a continuous review model with Q equal to one, so the sources place it under both review types depending on the setting.[^1][^3]

Order-up-to policy and base stock policy are used interchangeably in these sources.[^1][^2]

## What the sources do not establish

No source opened gives a formula for choosing the base stock level, so the page does not.

[^1]: J. E. Tyworth, Penn State Smeal College of Business SCM 810 technical note, February 2014, “Basic Multi-period Inventory Systems”. https://courses.smeal.psu.edu/SCM810/scm_810_module_3/Multi%20Period%20Inventory%20Systems%20Teaching%20Note.pdf
[^2]: Chris Caplice, MIT OpenCourseWare ESD.260 Logistics Systems, October 2006, “Inventory Management: Probabilistic Demand”. https://ocw.mit.edu/courses/esd-260j-logistics-systems-fall-2006/8b53c45fd26ffff706d815131e8d177e_lect11.pdf
[^3]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “Positive Ordering Costs”. https://www.columbia.edu/~gmg2/4000/pdf/lect_09.pdf
[^4]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

