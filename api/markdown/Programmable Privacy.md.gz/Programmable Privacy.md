Programmable Privacy is the capability to define custom, application-specific privacy rules for blockchain transactions and smart-contract state using zero-knowledge proofs, allowing developers to selectively disclose or conceal data rather than relying on an all-or-nothing privacy model. It lets a single protocol support both private and public execution paths within the same contract. Protocols such as Aztec expose this as a first-class primitive for confidential smart contracts.

### Provenance

