The structured transparency artefacts that record what an AI system is, how it was built, and how it behaves — model cards, datasheets for datasets, system cards, technical files, and decision logs. AI documentation is the evidentiary substrate of AI accountability: it lets developers, deployers, auditors, and regulators trace capabilities, limitations, training data provenance, and evaluation results, and is increasingly mandated by regimes such as the EU AI Act.

### Semantic Classification

### Content

## Definition

**AI Documentation** is the family of structured artefacts that make an AI system legible to people who did not build it. Unlike general software [[Documentation]], which primarily explains how to use or maintain code, AI documentation must capture properties that emerge from data and training rather than from explicit programming: what data the model learned from and under what rights, how it was evaluated and on which populations, where it performs poorly, what uses are intended and which are out of scope, and what risks were identified and mitigated.

The canonical genres emerged from research practice between 2018 and 2021. *Model cards* (Mitchell et al., 2019) summarise a model's intended use, evaluation results disaggregated across demographic groups, and known limitations. *Datasheets for datasets* (Gebru et al., 2021) interrogate a dataset's motivation, composition, collection process, consent basis, and recommended uses. *System cards* extend the idea from single models to deployed systems with retrieval, filtering, and human-in-the-loop components. Around these sit factsheets, risk registers, evaluation reports, and decision logs recording how design trade-offs were resolved.

Documentation is the practical mechanism through which [[AI Accountability]] becomes checkable: an accountability claim without documentation is unfalsifiable, whereas a model card, a [[Training Data]] summary, and an audit trail give internal reviewers, external auditors, and regulators something to verify against. This is why accountability frameworks consistently list documentation as a hard requirement rather than good practice.

## Current Landscape

Regulation has converted AI documentation from voluntary hygiene into legal obligation. The EU AI Act requires providers of high-risk systems to maintain extensive technical documentation (Annex IV) and obliges general-purpose model providers under Article 53 to keep technical files and publish training-content summaries. Key dates and instruments:

- **10 July 2025**: the European Commission published the GPAI Code of Practice, whose Transparency chapter centres on a standardised **Model Documentation Form** covering licensing, technical specifications, intended uses, dataset details, and compute and energy usage, with tiered disclosure to the AI Office, national authorities, and downstream providers.
- **24 July 2025**: the AI Office adopted the mandatory template for the public **training-data summary** under Article 53(1)(d), requiring general model information, a list of data sources (including the most-used web-scraped domains), and data-processing descriptions; summaries must be updated at least every six months where training continues.
- **2 August 2025**: GPAI documentation obligations began applying to new models; Commission enforcement powers start 2 August 2026, and models placed on the market before August 2025 have until 2 August 2027 to comply.
- NIST's AI Risk Management Framework, ISO/IEC 42001, and the UK's Algorithmic Transparency Recording Standard all embed documentation duties, while procurement processes increasingly demand model cards as a condition of purchase.

  Industry tooling has followed: Hugging Face made model cards a repository norm with structured templates and automated population; major laboratories publish system cards alongside frontier releases; and MLOps platforms generate evaluation documentation from pipeline metadata rather than by hand. The unresolved tensions are freshness (documentation drifting out of date as models are retrained), depth versus trade secrecy (training-data disclosure meeting IP and privacy resistance), and verification — a document is only as trustworthy as the process that audits it against the system it describes.

  **Sources**:

- https://digital-strategy.ec.europa.eu/en/news/commission-presents-template-general-purpose-ai-model-providers-summarise-data-used-train-their
- https://www.wilmerhale.com/en/insights/blogs/wilmerhale-privacy-and-cybersecurity-law/european-commission-releases-mandatory-template-for-public-disclosure-of-ai-training-data
- https://digital-strategy.ec.europa.eu/en/policies/contents-code-gpai
- https://www.twobirds.com/en/insights/2025/taking-the-eu-ai-act-to-practice-decoding-the-gpai-code-of-practice-and-the-training-data-summary-te

