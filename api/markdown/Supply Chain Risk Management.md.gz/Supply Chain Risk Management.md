Supply chain risk management is the organised management of risks to a supply network, and the sources opened here define it only for particular settings rather than as a general term.[^1][^2]

The National Institute of Standards and Technology defines cybersecurity supply chain risk management, C-SCRM, as the organized and purposeful management of cybersecurity risks throughout the supply chain.[^1] It says that in general practice C-SCRM sits at the nexus of traditional supply chain risk management and traditional information security, and that it is an enterprise-wide activity to be directed from a governance perspective.[^1] NIST also advises enterprises to attempt to identify single points of failure and risk among primes and lower-level entities in the supply chain.[^1]

## Managerial accounts

Christopher and Peck focus on a managerial agenda for the identification and management of supply chain risk, with recommendations to improve the resilience of supply chains.[^2] They say that because supply chain vulnerability is a network-wide concept, the management of risk has to be network-wide too.[^2]

Simchi-Levi and colleagues, working with Ford, developed a risk-exposure model that assesses the impact of a disruption originating anywhere in a firm's supply chain.[^3] Their approach defers the need to estimate the probability of any specific disruption until the firm has learned the effect that disruption would have on its operations.[^3] This is a different design from methods that begin by estimating probabilities. Only the abstract was opened, and the method is expanded at [[Time to Recover]].

## Practice

The Center for Climate and Energy Solutions says that supply chain risk management today tends to operate separately from other communities of resilience practice, like climate risk.[^4]

## Scope and limits

[[Supply Chain Risk Type]] lists the risk categories managed, and the capacity the process seeks to build is [[Supply Chain Resilience]]. Two related techniques have their own pages: [[Multi-Tier Supply Chain Mapping]] and [[Supply Chain Stress Testing]].

No opened source states a general definition of supply chain risk management or a standard process for it outside cybersecurity. The NIST publication is about information and communications technology supply chains, so its terms are not assumed to apply to physical goods.

[^1]: National Institute of Standards and Technology, NIST Special Publication 800-161r1-upd1 (May 2022, updated), “Cybersecurity Supply Chain Risk Management Practices for Systems and Organizations”. https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-161r1-upd1.pdf
[^2]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^3]: David Simchi-Levi and colleagues, Interfaces, October 2015 (MIT DSpace record, abstract only), “Identifying Risks and Mitigating Disruptions in the Automotive Supply Chain”. https://dspace.mit.edu/entities/publication/d44ef29a-78b6-4ec5-a537-d6e4c4f3f55a
[^4]: Center for Climate and Energy Solutions (C2ES), September 2025, “Assessing the Landscape of Climate Risk and Supply Chain Resilience: A Primer for Corporate Leaders and Climate Risk Professionals”. https://www.c2es.org/wp-content/uploads/2025/09/Climate-Risk-and-Supply-Chain-Report_FINAL_v3.pdf

