NeurIPS (Neural Information Processing Systems) is the premier annual international conference on machine learning, computational neuroscience, and artificial intelligence, held each December and governed by the NeurIPS Foundation. Founded in 1987 at the intersection of neuroscience and statistical learning theory, it has evolved into the most selective and impactful peer-reviewed publication venue in AI, shaping research agendas across deep learning, reinforcement learning, probabilistic modelling, generative AI, and AI ethics. Accepted papers undergo rigorous double-blind peer review and are freely available via the NeurIPS Proceedings archive, with acceptance rates typically below 26 percent in recent years. The conference serves as a primary mechanism for the global dissemination, validation, and agenda-setting of foundational machine learning research.

### Overview

- NeurIPS was established in 1987 to bridge [[Computational Neuroscience]] and machine learning, initially convened in Denver by researchers seeking interdisciplinary dialogue between neural systems biology and learning algorithms. Over three decades it transitioned from a specialised symposium to the dominant forum for applied and theoretical AI research.
- The conference is governed by the NeurIPS Foundation, a non-profit that manages the annual programme committee, proceedings, workshop programme, and ethical-review processes. The Foundation issues calls for papers approximately six months before each December conference, conducts double-blind [[Peer Review]] across programme committee members drawn from the global academic and industrial research community, and publishes accepted work openly via the NeurIPS Proceedings website.
- Acceptance rates fell progressively through the 2010s and stabilised in the 20–26 percent range as submission volumes grew exponentially, making selective acceptance a meaningful signal of research quality. The conference's influence is such that major technology companies, universities, and national AI strategies explicitly track NeurIPS publication counts as proxies for research excellence.
- The 2012 AlexNet paper, presented in a NeurIPS workshop, is widely credited as catalysing the [[Deep Learning]] revolution. Subsequent NeurIPS main-track papers introduced the [[Variational Autoencoder]] (VAE), [[Generative Adversarial Network]] (GAN), [[word2vec]] embeddings, key components of [[AlphaGo]] training, and foundational [[Reinforcement Learning from Human Feedback]] (RLHF) techniques — illustrating the conference's role as the primary birthplace of modern AI paradigms.

### Key Components

- **Main Track**
  - The principal peer-reviewed programme of full research papers. Authors submit via the OpenReview platform. Area chairs assign reviewers from the programme committee; papers receive written reviews followed by author rebuttals before final decisions. Accepted papers are presented as [[Poster Session]] posters; a small selection is also featured as oral or spotlight talks.
- **Workshop Programme**
  - Dozens of focused [[Workshop]] events run alongside the main conference on the first and last days. Workshops are independently organised by community members and cover specialised sub-fields such as ML for health, [[AI Ethics]], [[Fairness in Machine Learning]], causal inference, and emerging methodologies. Workshops often serve as incubators for ideas that later become main-track papers.
- **Tutorials**
  - Half-day or full-day [[Tutorial]] sessions delivered by leading researchers provide deep dives into established or rapidly evolving sub-fields. Topics span foundational methods (e.g., [[Gaussian Processes]]) to cutting-edge applications (e.g., [[Diffusion Models]], [[Large Language Model]]).
- **Competitions and Datasets**
  - The NeurIPS competition track hosts ML challenges with novel datasets and evaluation frameworks, driving community progress on specific benchmarks. Past competitions introduced influential datasets in areas such as [[Computer Vision]], [[Reinforcement Learning]], and healthcare prediction. These directly feed [[Evaluation Benchmarks and Leaderboards]] infrastructure.
- **Broader Impact and Ethics Review**
  - Since 2020, all submissions include a broader-impact statement assessed by reviewers. A separate ethics review board evaluates papers flagged for potential harm, making NeurIPS a significant institutional site for advancing [[Responsible AI]] practice.
- **Social Events and Affinity Groups**
  - NeurIPS hosts affinity workshops and social events for under-represented communities in AI (e.g., Black in AI, LatinX in AI, Queer in AI), supporting diversity, equity, and inclusion in the global research community.

### Landmark Research Contributions

- Several of the most-cited and most-consequential papers in modern AI were first published at NeurIPS:
  - **GANs (2014)** — Goodfellow et al. introduced [[Generative Adversarial Networks]], spawning an entire sub-field of [[Generative AI]].
  - **Variational Autoencoders (2013/2014)** — Kingma and Welling presented the [[Variational Autoencoder]], a foundational [[Latent Space Representation]] model.
  - **word2vec (2013)** — Mikolov et al. presented distributed [[Word Embeddings]] that became standard in [[Natural Language Processing]].
  - **AlexNet workshop (2012)** — Krizhevsky et al. demonstrated GPU-accelerated deep [[Convolutional Neural Networks]] dominating [[ImageNet]], starting the deep learning era.
  - **RLHF (2017)** — Christiano et al. introduced [[Reinforcement Learning from Human Feedback]], later foundational to [[Large Language Model]] alignment.
  - **Attention mechanisms** — Early formulations influencing [[Transformer Architecture]] appeared in NeurIPS proceedings.
  - **Neural Turing Machines, [[Neural Architecture Search]], [[Dropout Regularisation]], [[Batch Normalisation]]** variants — numerous foundational components trace back to NeurIPS papers.

### Applications and Use Cases

- **Academic Research Agenda-Setting**: Researchers worldwide target NeurIPS as the primary venue for publishing foundational advances. Acceptance shapes tenure decisions, grant allocations, and university rankings in AI.
- **Industry Research Benchmarking**: Technology companies such as Google DeepMind, Meta AI, Microsoft Research, and OpenAI use NeurIPS publication counts in research reports and use the conference to recruit talent and announce high-impact results.
- **Dataset and [[Benchmark Standard]] Introduction**: NeurIPS competitions and papers introduce community-wide evaluation standards, including datasets that persist for years as canonical benchmarks in [[Computer Vision]], [[Reinforcement Learning]], and [[Natural Language Processing]].
- **Policy and National AI Strategy**: Government agencies (e.g., UKRI, NSF, EU) cite NeurIPS acceptance rates and national publication counts in competitiveness assessments, influencing funding allocation for [[AI Research]].
- **Open-Access Dissemination**: All accepted papers are freely downloadable, making NeurIPS proceedings a primary resource for practitioners, students, and policymakers in low-resource settings. This supports [[Open Science]] and [[Research Dissemination]] globally.
- **Interdisciplinary Bridge**: The workshop programme enables ML researchers to engage with [[Neuroscience]], [[Cognitive Science]], [[Statistics]], physics, and social science, making NeurIPS a cross-domain connector across intellectual communities.

### Standards and Context

- **Governance**: The NeurIPS Foundation is the governing non-profit. It appoints programme chairs annually and has developed formal processes for code-of-conduct enforcement, conflict-of-interest management, and ethics review.
- **Review System**: NeurIPS pioneered the adoption of OpenReview for large-scale double-blind peer review in AI. The platform allows public visibility of reviews post-decision, increasing accountability.
- **Broader Impact Criterion**: Introduced in 2020, this requirement for all submissions to address societal implications has influenced similar policies at ICML and ICLR, establishing a community norm for [[Responsible AI]] practice.
- **Reproducibility**: NeurIPS introduced a checklist requiring authors to document code availability, experimental setup, and statistical methodology — advancing reproducibility standards across the [[Machine Learning]] community.
- **Affiliation with Learned Societies**: NeurIPS is independent of ACM and IEEE (unlike CVPR and some other venues), managed exclusively by the Foundation, which gives it flexibility but also community-specific accountability structures.
- **Proceedings**: Published as annual Advances in Neural Information Processing Systems volumes, openly accessible and indexed in major academic databases.

### Historical Milestones

- **1987** — First Neural Information Processing Systems conference, Denver; bridging [[Neuroscience]] and learning algorithms.
- **2012** — AlexNet workshop at NeurIPS; catalysed [[Deep Learning]] era.
- **2014** — GANs paper published; [[Generative AI]] sub-field launched.
- **2017** — RLHF paper; laid groundwork for [[Reinforcement Learning from Human Feedback]] used in modern LLMs.
- **2018** — Conference renamed from NIPS to NeurIPS following community consultation.
- **2019** — Lottery system introduced for non-author attendee registration as demand vastly exceeded venue capacity.
- **2020** — Fully virtual format due to COVID-19; broader-impact review criterion introduced.
- **2021-present** — Hybrid and in-person formats resume; ethics review board formalised; competition track expanded.

### Current Landscape (2026)

- NeurIPS 2025 (the 39th edition, 2-7 December) ran for the first time as a dual-location event, headquartered at the San Diego Convention Center with a co-located secondary site in Mexico City (Hilton Reforma, 30 November - 5 December), the first time the conference operated outside its traditional single US/Canada venue.
- Scale reached record levels: the main track drew 21,575 valid submissions (up roughly 38% on 2024's 15,671) and accepted 5,290 papers for a 24.5% acceptance rate, supported by a reviewing pool of over 20,500 reviewers, 1,663 area chairs and 199 senior area chairs; total registrants numbered around 26,000, with about 24,500 in person in San Diego.
- Award-winning work signalled a shift from raw scaling towards reasoning and systems: the 2025 Best Paper Awards honoured seven papers, including "Gated Attention for Large Language Models" (Qiu et al., Alibaba), "Why Diffusion Models Don't Memorise" (Bonnaire et al.), "1000 Layer Networks for Self-Supervised RL" (Wang et al.) and the datasets-track winner "Artificial Hivemind" (Jiang et al.); the Test of Time Award went to Faster R-CNN (Ren, He, Girshick, Sun, NeurIPS 2015, 56,700+ citations).
- Geopolitically, US and Chinese institutions produced roughly 2,450 and 2,370 accepted papers respectively, together comprising nearly 90% of accepted work, with the two nations effectively tied on paper counts and top awards.
- Peer review integrity became the defining governance issue: NeurIPS issued a formal 2025 LLM policy permitting AI writing assistance but requiring disclosure of methodologically important LLM use and holding authors fully responsible for verifying citations, while reviewers are barred from sharing submissions with any LLM.
- In January 2026 GPTZero reported that over 100 AI-hallucinated citations spanning at least 53 accepted 2025 papers had slipped past reviewers, prompting a measured NeurIPS board statement that it is actively monitoring LLM use and had already instructed reviewers to flag hallucinations.
- Governance also tightened around reviewer conduct: under the "responsible reviewing" initiative, chairs may now withhold reviews from authors who miss their own reviewing duties and desk-reject the co-authored papers of grossly negligent reviewers; a November 2025 OpenReview security breach exposing reviewer identities triggered a firm confidentiality reaffirmation.
- Looking to 2026, the main track is planning a controlled experiment in which reviewers receive sanctioned OpenReview-provided LLM support on some papers and none on others, alongside stricter dataset requirements such as mandatory Croissant metadata and code release for artifact submissions.

### References

- 1. NeurIPS (2025). NeurIPS 2025 Fact Sheet. https://media.neurips.cc/Conferences/NeurIPS2025/press/NeurIPS2025-Fact_Sheet.pdf
- 2. NeurIPS Program Committee Chairs (2025). Announcing the NeurIPS 2025 Best Paper Awards. https://blog.neurips.cc/2025/11/26/announcing-the-neurips-2025-best-paper-awards/
- 3. Fortune / GPTZero (2026). NeurIPS research papers contained 100+ AI-hallucinated citations. https://fortune.com/2026/01/21/neurips-ai-conferences-research-papers-hallucinations/
- 4. NeurIPS (2025). NeurIPS 2025 Policy on the Use of Large Language Models. https://neurips.cc/Conferences/2025/LLM
- 5. IntuitionLabs (2025). NeurIPS 2025: A Guide to Key Papers, Trends & Stats. https://intuitionlabs.ai/articles/neurips-2025-conference-summary-trends

### Provenance

