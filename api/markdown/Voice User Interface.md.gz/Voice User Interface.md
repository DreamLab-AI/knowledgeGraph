A Voice User Interface (VUI) is a human-computer interaction modality in which users issue commands and receive responses through spoken language rather than visual controls. It chains automatic speech recognition, natural-language understanding, dialogue management and speech synthesis to turn utterances into actions and synthesised replies. VUIs power virtual assistants, in-car systems and accessibility tools where hands-free or eyes-free operation is valuable.

### Overview

- [[User Interface]] provides the broader context within which Voice User Interface sits.
- Voice User Interface is treated here as a member of the **artificial-intelligence** domain at **established** maturity.
- It is referenced across the knowledge graph by classes that depend on or compose it, making it a central node that warranted an explicit definition.

### Key aspects

- It comprises [[Speech Recognition]].
- It comprises [[Speech Synthesis]].
- It comprises [[Intent Classification]].
- It comprises [[Dialogue System]].
- It requires [[Automatic Speech Recognition]].
- It requires [[Natural Language Understanding]].
- It requires [[Text-to-Speech]].
- It makes use of [[Natural Language Processing]].

### Mechanisms

- Voice User Interface operates by combining its constituent parts into a coherent capability that other classes can rely upon.
- Its guarantees and behaviours are realised through the dependencies and standards captured in the relations below.

### Applications

- Enables and supports [[Conversational AI]].
- Enables and supports [[Voice Assistant]].
- Enables and supports [[Human-Computer Interaction]].
- Enables and supports [[Accessibility]].

### Provenance

