Strategic sourcing is, in United States federal usage, the collaborative and structured process of critically analysing an organisation's spending and using this information to make business decisions about acquiring commodities and services more effectively and efficiently.[^1]

That wording appears in the Office of Federal Procurement Policy notice that proposed a circular on category management, which says the Office of Management and Budget had worked with agencies for more than a decade on government-wide strategic sourcing initiatives.[^1] The General Services Administration describes its Strategic Sourcing Initiative as strategically sourced products and services that “leverage the government’s purchasing power to reduce cost”, and lists building maintenance and operations, maintenance repair facility supplies and office supplies among them.[^2]

That notice reports that strategic sourcing efforts since 2010 have helped agencies to save more than $500 million by reducing unit prices, applying demand management strategies and avoiding duplicative administrative costs, and says a broader organisational vision was needed beyond them.[^1] Medina-Serrano and colleagues use strategic sourcing in a different sense. Their paper treats make-or-buy decisions, between designing and manufacturing in-house, buying from external providers or combining both, as strategic sourcing decisions, and their keywords include outsourcing, plural sourcing and hybrid sourcing.[^3]

## Scope and distinctions

Strategic sourcing starts from [[Spend Analysis]], and the federal notice proposes [[Category Management]] as the broader vision that followed. See [[Sourcing Strategy]], [[Kraljic Portfolio Matrix]] and [[Supply Chain Configuration Decision]].

## What the sources do not establish

These two senses are not reconciled in any opened source. The government definition comes from a single notice, and GAO reports that restate it could not be opened.[^1][^3]

[^1]: Office of Federal Procurement Policy, Federal Register, 7 October 2016, “Category Management”. https://www.federalregister.gov/documents/2016/10/07/2016-24054/category-management
[^2]: US General Services Administration, “Purchasing programs”. https://www.gsa.gov/buy-through-us/purchasing-programs
[^3]: Ruben Medina-Serrano and colleagues, Journal of Industrial Engineering and Management, 2020, “Strategic Sourcing: Developing a Progressive Framework for Make-Or-Buy Decisions”. https://jiem.org/index.php/jiem/article/download/2858/922

