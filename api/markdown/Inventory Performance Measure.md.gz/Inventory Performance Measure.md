An inventory performance measure assesses how productively a business uses its inventory, for example how fast stock cycles through sales or how many days of demand it covers.[^1][^2]

OpenStax, in an open accounting textbook, says two ratios can be used to assess how efficiently management is handling inventory.[^1] The first, inventory turnover, measures the number of times an average quantity of inventory was bought and sold during the period. The second, number of days' sales in inventory, measures how many days it takes to complete the cycle between buying and selling inventory.[^1] See [[Inventory Turnover]].

## Measures in SCOR

SCOR 12.0 files its inventory measures under the asset management efficiency attribute. They include Inventory Days of Supply at level 2, with further days-of-supply metrics for raw material, work in progress and finished goods, and Percentage Defective Inventory and Percentage Excess Inventory.[^2] The guide opened gives only the names, so this page does not state how SCOR calculates them.

## Scope and distinctions

Turnover counts cycles per period and days of supply counts time, so the two express the same stock behaviour in different units.[^1] That relationship is shown by the OpenStax definitions, which put turnover on cost of goods sold over average inventory and days' sales in inventory on average inventory over daily cost of goods sold.[^1] Percentage defective or excess inventory describes stock quality, not speed.[^2]

This page sits under [[Supply Chain Performance Measure]]. Gunasekaran, Patel and Tirtiroglu name inventory and logistics costs among the measures their metric list emphasises.[^3]

## What the sources do not establish

No source opened defines inventory performance measure as a group, and none ranks the measures or gives target values. OpenStax is an accounting source, so its ratios are financial statement ratios, and the SCOR entries are names without formulae.[^1][^2]

[^1]: OpenStax, “10.5 Examine the Efficiency of Inventory Management Using Financial Ratios”, Principles of Accounting, Volume 1: Financial Accounting. https://openstax.org/books/principles-financial-accounting/pages/10-5-examine-the-efficiency-of-inventory-management-using-financial-ratios
[^2]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf
[^3]: A. Gunasekaran, C. Patel and E. Tirtiroglu, International Journal of Operations and Production Management 21(1-2), 2001 (Penn State record, abstract only), “Performance measures and metrics in a supply chain environment”. https://pure.psu.edu/en/publications/performance-measures-and-metrics-in-a-supply-chain-environment/

