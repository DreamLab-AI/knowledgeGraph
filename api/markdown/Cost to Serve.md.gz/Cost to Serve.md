Cost to serve is the cost of serving a particular customer or channel, which differs from the cost of the product itself and is used to judge how profitable that customer or channel is.[^1][^2][^3]

Niraj, Gupta and Narasimhan argue that estimating current profitability at the individual customer level is important to distinguish more profitable customers from less profitable ones.[^1] They note that this is harder for an intermediary such as a distributor, because the costs of servicing a retail customer include costs incurred directly for that customer and costs incurred by the distributor in dealing with its own vendors for goods supplied to that customer.[^1]

## Why it is hard to calculate

Ozener, Ergun and Savelsbergh study the problem for vendor managed inventory, where a supplier controls its customers' stock levels. They say that, because of the intricate interactions between customers, calculating a fair cost-to-serve for each customer is a daunting task.[^2] They describe cost-to-serve information as valuable for sales and marketing and for distribution planning, and note that if the distribution component of a price is smaller than the actual cost-to-serve, profit margins will be smaller or even negative.[^2]

## Relation to activity-based costing

A trade magazine article on activity-based costing for logistics gives the cost to serve different distribution channels as an example of an analysis that will differ between an activity-based costing system and a traditional accounting system, while the totals must still agree at the aggregate operating cost level.[^3] The article is about the costing method and does not define cost to serve separately.[^3] This page sits under [[Supply Chain Cost Measure]]; see also [[Total Landed Cost]].

## What the sources do not establish

Evidence is thin. The Niraj record is an abstract, the Georgia Tech paper is a submitted manuscript on one distribution setting, and the third source is a magazine article. None defines cost to serve in general terms, none lists its components, and none compares allocation methods, so the page does not offer a formula.[^1][^2][^3]

[^1]: Rakesh Niraj, Mahendra Gupta and Chakravarthi Narasimhan, Journal of Marketing, 2001 (WashU record, abstract only), “Customer profitability in a supply chain”. https://profiles.wustl.edu/en/publications/customer-profitability-in-a-supply-chain/
[^2]: Okan Orsan Ozener, Ozlem Ergun and Martin Savelsbergh, “Allocating Cost of Service to Customers in Inventory Routing”, manuscript submitted to Operations Research (Georgia Tech copy). https://www2.isye.gatech.edu/people/faculty/Martin_Savelsbergh/publications/irp-costallocation.pdf
[^3]: Tan Miller, Material Handling & Logistics, July/August 2017 (Rider University copy), “The ABCs of Activity-Based Costing for Logistics”. https://www.rider.edu/sites/default/files/2024-03/MH&L_JulyAug2017_ABC.pdf

