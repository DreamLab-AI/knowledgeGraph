Planning master data is the set of stored records that a planning system reads to plan material and capacity, such as product structures, item attributes, inventory status, routings and work centres.[^1][^2]

No opened source defines the phrase. Gallego names the three major inputs of an MRP system as the master production schedule, the product structure records and the inventory status records, and says the system cannot function without them.[^1] He lists, for each item, part number, description, quantity per assembly, next higher assembly, lead times and quantity per end item.[^1] Gershwin's MIT lecture lists an item master file holding, for each part number, the description, bill of materials, lot-sizing and planning lead times.[^2]

## Inventory and routing records

A University of North Carolina Wilmington module says the inventory record specifies the order or lot size policy, the lead times and a record of all transactions, which are changes in inventory levels.[^3] Oracle's JD Edwards documentation says routing instructions define the operations required to produce an item and the lead time at each step, and that a work centre is a production facility where the operations occur, defined by queue and move times, operator, machine and hours-per-day capacity, and rates for set-up, labour, machine and overhead.[^4]

## Scope and distinctions

Records differ by system and author, and the groupings above are editorial. See [[Bill of Materials]], [[Material Requirements Planning]], [[Routing]] and [[Supply Chain Planning]].

## What the sources do not establish

No standard defines master data for planning, and the sources describe the records of manufacturing systems rather than distribution or transport planning. Gallego warns that inventory status records must be kept up to date, with each receipt, disbursement or withdrawal documented, to maintain record integrity.[^1]

[^1]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “Material Requirements Planning (MRP)”. http://www.columbia.edu/~gmg2/4000/pdf/lect_06.pdf
[^2]: Stanley B. Gershwin, MIT 2.853/2.854 Introduction to Manufacturing Systems lecture slides (MIT OpenCourseWare), “Material Requirements Planning”. https://ocw.mit.edu/courses/2-854-introduction-to-manufacturing-systems-fall-2016/4eec617bb52d64f4ea1bed6d9905bc00_MIT2_854F16_MatrialRequire.pdf
[^3]: Terry Janicki, University of North Carolina Wilmington, OPS 370 course module, “Materials Requirements Planning Module 11”. https://csbapp.uncw.edu/janickit/ops370/modules/Module11.pdf
[^4]: Oracle, JD Edwards EnterpriseOne Applications Product Data Management documentation, “5 Entering Work Centers and Routing Instructions”. https://docs.oracle.com/cd/E16582_01/doc.91/e15128/enter_wc_and_rtg_instructs.htm

