Aggregate planning is the medium-term development of production strategies that optimise resource use to meet forecasted demand, at the level of product families rather than individual items.[^1]

An open operations management textbook places it in the medium-term (tactical) horizon of 3 to 18 months and describes it as interrelated with sales and operations planning.[^1] It lists three primary strategies: chase, which adjusts production rates and workforce levels to match demand; level, which keeps a constant production rate and workforce and uses inventory to buffer demand variability; and mixed, which combines the two, often through overtime, subcontracting or inventory adjustments.[^2] It also names quantitative methods: linear programming, transportation models, management coefficient models and decision rules.[^2]

Beasley's OR-Notes at Brunel University describe the same kind of plan: an input of forecast demand and production and inventory costs gives a production plan with amounts to be produced and staffing levels for each period, operating at an aggregate level and attempting to meet requirements at minimum cost, hence the name aggregate planning.[^3]

Beasley's worked example has a single product made each week in a normal shift or in overtime, with completed items that can be bought in from a subcontractor, workers who can be hired or fired at a cost, backorders allowed and lost sales not allowed.[^3]

## Scope and distinctions

OR-Notes call this plan the master production schedule, whereas the course module on MRP uses that phrase for the schedule of end items that drives material requirements planning; the two usages differ in scope.[^3][^4] See [[Master Production Scheduling]], [[Sales and Operations Planning]] and [[Supply Chain Planning]].

## What the sources do not establish

Neither source gives evidence on which strategy performs better, and the horizon figures come from one textbook.[^1][^2][^3]

[^1]: Operations Management open textbook, eCampusOntario Pressbooks, section 14.2, “Concept and Horizon of Aggregate Planning”. https://ecampusontario.pressbooks.pub/opsmgmt/chapter/14-2-concept-and-horizon-of-aggregate-planning/
[^2]: Operations Management open textbook, eCampusOntario Pressbooks, section 14.3, “Aggregate Planning Strategies”. https://ecampusontario.pressbooks.pub/opsmgmt/chapter/14-3-aggregate-planning-strategies/
[^3]: J. E. Beasley, OR-Notes, Brunel University London (originally Imperial College), “Master production schedule”. https://people.brunel.ac.uk/~mastjjb/jeb/or/masprod.html
[^4]: Terry Janicki, University of North Carolina Wilmington, OPS 370 course module, “Materials Requirements Planning Module 11”. https://csbapp.uncw.edu/janickit/ops370/modules/Module11.pdf

