An EVM-compatible blockchain is a network whose execution environment implements the Ethereum Virtual Machine semantics, allowing it to run unmodified Ethereum smart contract bytecode and reuse Ethereum tooling. Compatibility lets developers deploy Solidity contracts, wallets and infrastructure across many chains with minimal changes, fostering an interoperable multi-chain ecosystem. Such chains include layer-2 rollups, sidechains and alternative layer-1 networks.

### Overview

- EVM compatibility has become a de facto standard for smart-contract platforms because it lets an entire ecosystem of tooling, wallets, libraries and audited contracts port across chains. A compatible chain executes the same bytecode and exposes the same JSON-RPC interfaces as Ethereum, so developers can redeploy applications with minimal friction. This compatibility spans layer-2 rollups, sidechains and independent layer-1s, accelerating multi-chain deployment and liquidity.

### Key aspects

- Execution environment implementing EVM opcode semantics
- Support for Solidity and Ethereum bytecode without modification
- Gas-metered computation and account-based state model
- Reuse of Ethereum tooling, wallets and JSON-RPC interfaces
- Spanning rollups, sidechains and alternative layer-1 networks

### Applications

- Deploying DeFi protocols across multiple chains
- Layer-2 scaling through EVM rollups
- Cross-chain liquidity and bridging
- Porting NFT and token standards between networks
- Enterprise and app-specific EVM chains

### Provenance

