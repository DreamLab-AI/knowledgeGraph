Multi-echelon inventory optimisation is the optimisation of inventory levels, in particular safety stock, across the stages of a supply network.[^1][^2]

An arXiv preprint says it plays a key role in a supply chain seeking to achieve specified customer service levels with a minimum capital in inventory. The same paper proposes a generalised model based on the guaranteed service approach to allocate safety stock levels across the network at the lowest holding cost.[^1] Lehigh University slides describe the system as composed of stages, such as nodes or sites, grouped into echelons, with downstream stages facing customer demand. They show serial, assembly, distribution and mixed topologies.[^2] A paper on stock-out prediction describes a multi-echelon network as a chain of nodes that aims to provide a product or service to its customers, and says the performance of a node is affected by events at many other nodes and in other time periods.[^5]

## Two approaches

A review of operations and supply chain management says most work uses a stochastic service approach, in which each stock location keeps a safety stock to reach a service level target, and that stock-outs then occur and delay downstream replenishments. The guaranteed service approach, attributed to Simpson (1958), assumes bounded demand and has each location keep a safety stock so that a given service time to the downstream location is always guaranteed.[^3] The Lehigh slides describe an approximate method in which each stage is assumed to deliver within a committed service time most of the time.[^2]

## Serial systems

The Lehigh slides say exact algorithms exist for serial systems, citing Clark and Scarf (1960), but that they are cumbersome.[^2] A Columbia and Stanford paper calls the study of multi-stage serial inventory systems central to supply chain management, as a benchmark and as a building block for more complex networks, and proposes a heuristic that requires solving a single newsvendor problem per stage.[^4]

## Scope and distinctions

This page covers optimisation of stock across stages, an [[Inventory Model]] class; for stock held at one location see [[Safety Stock]] and [[Base Stock Policy]]. Network design is covered at [[Supply Chain Network Design]].

## What the sources do not establish

Sources do not say how widely multi-echelon optimisation is applied. The original Clark and Scarf and Simpson papers were not opened.

[^1]: arXiv (Achkar, Brunaud, Pérez, Musa, Méndez and Grossmann), “Extensions to the Guaranteed Service Model for Industrial Applications of Multi-Echelon Inventory Optimization”. https://arxiv.org/pdf/2306.10961
[^2]: Larry Snyder, Lehigh University OR Roundtable slides, 15 June 2006, “Multi-Echelon Inventory Management”. https://coral.ise.lehigh.edu/wp-content/uploads/presentations/MultiEchelonInventory.pdf
[^3]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^4]: Guillermo Gallego and Özalp Özer, working paper, 1 September 2004, “A New Algorithm and a New Heuristic for Serial Supply Systems”. https://www.columbia.edu/~gmg2/4000/pdf/lect_10.pdf
[^5]: arXiv (Oroojlooyjadid, Snyder and Takáč, Lehigh University), “Stock-out Prediction in Multi-echelon Networks”. https://arxiv.org/pdf/1709.06922

