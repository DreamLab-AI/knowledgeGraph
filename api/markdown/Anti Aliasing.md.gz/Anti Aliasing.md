Anti-aliasing is a family of rendering techniques that reduce the jagged, stair-stepped edges and shimmering artefacts that arise when continuous geometry and signals are sampled onto a discrete pixel grid. By increasing effective sampling, blending edge pixels, or reconstructing from accumulated samples, anti-aliasing produces smoother, more visually faithful images. It is a standard stage of real-time and offline rendering pipelines, with methods such as supersampling, multisampling, post-process filtering, and temporal accumulation.

- Anti-aliasing is a [[Real-Time Rendering]] technique that suppresses jagged edges caused by discrete [[Sampling]].
- It is applied within the [[Rendering Pipeline]], often as a [[Post-Processing]] stage.
- It complements [[Rasterization]] and [[Ray Tracing]] outputs.
- It relates closely to [[Texture Mapping]] and image quality in [[Computer Graphics]].

### Overview

- Aliasing arises because rendering samples continuous scene functions at a finite pixel resolution, producing stair-stepping and temporal shimmer.
- Anti-aliasing counteracts this by raising effective sample density or by reconstructing smoother signals from available samples.
- Spatial methods include supersampling and multisampling; analytic and post-process methods estimate coverage; temporal methods accumulate samples across frames.
- The choice of method trades image quality against memory bandwidth and compute budget.

### Mechanisms

- Supersampling renders at higher resolution then downsamples.
- Multisampling shades once per pixel but tests coverage at multiple subsample positions.
- Post-process filters detect and blend edges from the final image.
- Temporal accumulation reuses jittered samples across frames with motion-vector reprojection.

### Applications

- Real-time game and interactive engines balancing quality and frame rate.
- Offline film rendering pursuing maximal fidelity.
- Text and vector rendering for legible edges.
- Virtual and augmented reality where shimmer is especially distracting.

### Provenance

