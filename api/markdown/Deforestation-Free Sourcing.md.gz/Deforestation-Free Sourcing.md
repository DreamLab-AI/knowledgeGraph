Deforestation-free sourcing is the purchase of commodities and products that have not been produced on land converted from forest, and it is defined most precisely in the European Union's Regulation on deforestation-free products.[^1]

The Regulation defines deforestation as the conversion of forest to agricultural use, whether human-induced or not.[^1] It says relevant products are deforestation-free if the commodities in them were produced on land that has not been subject to deforestation after 31 December 2020.[^1] Under Article 3, relevant commodities and products must not be placed on the market or exported unless they are deforestation-free, were produced in accordance with the legislation of the country of production, and are covered by a due diligence statement.[^1] Its recitals say due diligence systems should include three elements, information requirements, risk assessment and risk mitigation measures, complemented by reporting obligations.[^1]

The European Commission describes the aim as ensuring that the products consumed in the EU do not contribute to deforestation or forest degradation in the EU or globally.[^2]

## UK regime

Schedule 17 of the Environment Act 2021 takes a different route. It defines a forest risk commodity as a commodity specified in regulations, and prohibits a regulated person from using such a commodity in UK commercial activities unless relevant local laws were complied with.[^3] It also requires a regulated person to establish and implement a due diligence system for identifying information about the commodity, assessing the risk that local laws were not complied with, and mitigating that risk.[^3] The test is legality of the land use, not an absence of deforestation, so the two regimes are not equivalent.

## Scope and limits

Deforestation-free sourcing is an application of [[Supply Chain Due Diligence]] and part of [[Sustainable Supply Chains]]. These sources describe legal requirements, not results: none reports how much deforestation the regimes have prevented. The EU regulation and the Commission page share an origin, and the UK Act's secondary regulations, which list the commodities, were not opened.

[^1]: European Parliament and Council of the European Union, Regulation (EU) 2023/1115 of 31 May 2023, “Regulation (EU) 2023/1115 of the European Parliament and of the Council on the making available on the Union market and the export from the Union of certain commodities and products associated with deforestation and forest degradation”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32023R1115
[^2]: European Commission, Directorate-General for Environment, “Regulation on Deforestation-free products”. https://environment.ec.europa.eu/topics/forests/deforestation/regulation-deforestation-free-products_en
[^3]: UK Parliament, Environment Act 2021, Schedule 17, “Environment Act 2021, Schedule 17: Forest risk commodities”. https://www.legislation.gov.uk/ukpga/2021/30/schedule/17

