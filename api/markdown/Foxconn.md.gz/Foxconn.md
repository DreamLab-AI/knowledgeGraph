Foxconn is the name used by Hon Hai Technology Group, an electronics contract manufacturer established in Taiwan in 1974.[^2] The European Commission described Hon Hai in a 2016 decision as a provider of third-party electronic manufacturing services (EMS) to original equipment manufacturers (OEMs) of electronic products such as computers, mobile phones, video game consoles and televisions, with operations across the Americas, Asia and Europe.[^1]

## What the sources say

Foxconn's own group profile says that Hon Hai Technology Group (Foxconn) was established in Taiwan in 1974 and calls it the world's largest electronics manufacturer, a claim by the company that no independent ranking in the sources opened confirms.[^2] The same Commission decision records that, after acquiring Sharp, Hon Hai is also an OEM selling consumer electronics products such as mobile phones, tablets, refrigerators, cooking appliances and TV sets.[^1] It adds that, according to the parties, more than 100 companies provide third-party EMS, so Foxconn is one among many such providers.[^1]

The Industrial Ontologies Foundry uses Foxconn as its example of a contract manufacturing service company: it owns and operates factories in China that do the final assembly of iPhones for Apple.[^3]

## Role in the supply chain

Foxconn is a [[Contract Manufacturer]]: it makes products that other brands sell. The Commission's account shows the line blurring, because the same group also sells products under its own name after the Sharp acquisition.[^1] For the brand it assembles for, see [[Apple Inc Technology Corporation]]. In this vault Foxconn is a class under the contract manufacturer role, not an individual.

## What the sources do not establish

Sources give no figures for revenue, staff or output, and no list of customers beyond the IOF example, which is an ontology illustration and not a statement of current contracts. The Commission's description dates from 2016 and the group's structure may have changed. The Commission decision uses the short name Hon Hai.[^1]

[^1]: European Commission, Case M.8109 FIH Mobile / Feature Phone Business of Microsoft Mobile, decision of 22 September 2016. https://ec.europa.eu/competition/mergers/cases/decisions/m8109_216_3.pdf
[^2]: Hon Hai Technology Group (Foxconn), group profile page. https://www.foxconn.com/en-us/about/group-profile
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

