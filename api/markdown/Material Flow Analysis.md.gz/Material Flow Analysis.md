Material flow analysis, abbreviated MFA, is a systematic assessment of the flows and stocks of materials within a system defined in space and time.[^1]

That wording is quoted on a lecture slide from an MIT industrial ecology course, which attributes it to Brunner and Rechberger, 2004; the book itself was not opened.[^1] The slides list among applications of MFA the creation of loop-closing industrial practices.[^1]

## Economy-wide accounts

Eurostat applies the method at national scale as economy-wide material flow accounts, abbreviated EW-MFA. Its reference metadata says they provide an aggregate overview, in thousand tonnes per year, of the material flows into and out of an economy, and that they cover solid, gaseous and liquid materials, except for bulk flows of water and air.[^2] Eurostat's methodological guide says the accounts and balances show the amounts of physical inputs into an economy, material accumulation in the economy and outputs to other economies or back to nature.[^3]

Eurostat's guide adds that the EU Environmental Headline Indicators and the United Nations Indicators for Sustainable Development include a resource use or material consumption indicator based on a material balance approach.[^3]

## Scope and distinctions

MFA supports [[Supply Chain Environmental Accounting]] and the closing of loops described at [[Circular Supply Chain]]. It tracks mass, which is a separate matter from the emissions inventory at [[Scope 3 Emissions]].

Both Eurostat sources come from one organisation, and the MIT slide is a secondary quotation, so the page rests on two origins. Neither source describes how MFA is carried out for one product or one company supply chain, and the Eurostat material is about national economies.

[^1]: Jeremy Gregory, MIT course 3.560/ESD.123 Industrial Ecology, lecture slides (OCW copy hosted by ocw.iti.hr), “Material Flow Analysis”. https://ocw.iti.hr/courses/engineering-systems-division/esd-123j-systems-perspectives-on-industrial-ecology-spring-2006/lecture-notes/lec14.pdf
[^2]: Eurostat reference metadata, Material flow accounts (env_ac_mfa), national page (Poland), “Material flow accounts (env_ac_mfa)”. https://ec.europa.eu/eurostat/cache/metadata/en/env_ac_mfa_simsmf_pl.htm
[^3]: Eurostat, European Commission, 2001, “Economy-wide material flow accounts and derived indicators: a methodological guide”. https://ec.europa.eu/eurostat/documents/1798247/6191533/3-Economy-wide-material-flow-accounts...-A-methodological-guide-2001-edition.pdf

