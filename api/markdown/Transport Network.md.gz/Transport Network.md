A transport network is the underlying backhaul or fronthaul infrastructure that interconnects the access and core segments of a communications system, carrying aggregated traffic between sites over fibre, microwave or leased links. In mobile networks it links radio sites to the core network and determines achievable latency and capacity. The term also covers physical transportation infrastructure, such as roads, rail and transit systems, that a region depends on for the movement of people and goods.

### Provenance

