A freight service is a commercial offering to carry freight or to arrange its carriage for customers; the sources separate carriers, which carry goods for remuneration, from intermediaries such as freight forwarders and brokers, which organise transport on behalf of customers.[^1][^2][^3][^4]

## Carriage for hire

The Glossary for transport statistics defines transport for hire and reward as carriage, for remuneration, of persons or goods on behalf of third parties. It names road goods transport enterprises, which offer and perform services in the transport of goods, and railway transport operators, which are licensed to provide services for the transport of goods or passengers by rail.[^1]

## Freight forwarding

The European Commission, in a 2017 merger decision, recalls that it has defined freight forwarding as the organisation of transportation of items, possibly including customs clearance, warehousing and ground services, on behalf of customers according to their needs. It has divided the market into domestic and cross-border freight forwarding and into forwarding by air, land and sea, and it says sea freight forwarders are among the most important customers of container liner shipping companies.[^2]

## Legal categories in United States law

Title 46 of the US Code defines a non-vessel-operating common carrier as a common carrier that does not operate the vessels by which the ocean transportation is provided and is a shipper in its relationship with an ocean common carrier. It defines an ocean freight forwarder as a person that dispatches shipments from the United States via a common carrier, books or otherwise arranges space on behalf of shippers, and processes the documentation.[^3] Title 49 defines a broker as a person, other than a motor carrier, that sells, negotiates for or arranges transportation by motor carrier for compensation, and defines a carrier as a motor carrier, a water carrier and a freight forwarder.[^4]

## Scope and distinctions

Freight Service is part of [[Freight Transportation]]. Related pages are [[Freight Forwarder]], [[Container Shipping]] and [[Logistics]].

## What the sources do not establish

Statutory categories are one jurisdiction's, and the Commission's definition serves competition analysis. No international definition of freight forwarder was opened, because the FIATA text could not be found, and the sources do not set out service levels such as full or part loads, so the page does not.

[^1]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^2]: European Commission, Case M.8594 - COSCO SHIPPING / OOIL, Commission decision of 5 December 2017 (public version). https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX%3A32017M8594
[^3]: Cornell Law School Legal Information Institute (text of 46 U.S.C. § 40102), “46 U.S. Code § 40102 - Definitions”. https://www.law.cornell.edu/uscode/text/46/40102
[^4]: Cornell Law School Legal Information Institute (text of 49 U.S.C. § 13102), “49 U.S. Code § 13102 - Definitions”. https://www.law.cornell.edu/uscode/text/49/13102

