
A tone model is a pragmatic modulation model that guides an agent's emotional stance and manner of interaction. In the SAC-CG Agent Ontology the class `ToneModel` is defined as guiding "emotional stance, pacing, softness/firmness, or collaborative rhythm".[^1]

It is a component of an [[Agent Profile]], attached by the `hasToneModel` property, which the ontology glosses as describing "pragmatics: cadence, pacing, assertiveness, contextual modulation." It sits beside [[Agent Personality]], which captures stable decision biases, and [[Language Preference]], which captures the language itself. The tone model concerns how something is said and not what is said or in which language.

visionGraph places Tone Model under [[Natural Language Generation]], since tone shapes generated text, and as part of the Agent Profile. The class is independent of any particular generation technique.

The profile module is version 0.2.0 of a Community Group draft, not a W3C Recommendation.

[^1]: Semantic Agent Communication Community Group, “Agent Profile Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent-profile.ttl

