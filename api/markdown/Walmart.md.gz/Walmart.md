Walmart is a retail company that operates stores in the United States and internationally and is a retailer in the sense used throughout this domain. Its own site says that, since Sam Walton opened the first Walmart, it has opened thousands of stores across the U.S. and internationally.[^1] In a 1999 merger decision the European Commission described Wal-Mart as a US-based international retailer offering a broad range of general merchandise and food, on a self-service basis.[^2]

## Supply chain traceability

On 24 September 2018 Walmart and Sam's Club announced that they would ask suppliers of leafy greens to implement real-time, end-to-end traceability, and the press release headline gives September 2019 as the date for suppliers to use blockchain technology.[^3] The release says that Walmart, working with IBM and 11 other food companies, had developed a blockchain-enabled food traceability network built on open-source technology.[^3] A trade press report at the time described Walmart and Sam's Club as urging lettuce and spinach suppliers to contribute to a blockchain database that can quickly and efficiently identify contamination.[^4]

Walmart's press release quotes IBM's statement that it developed IBM Food Trust as an open platform with a broad group of food stakeholders, and this is the basis on which the vault links Walmart to [[IBM Food Trust]] and [[Distributed Ledger]].[^3] The sources opened establish a requirement for leafy greens suppliers; they do not show how the system is used for other products, and they do not support calling Walmart an early adopter in comparison with other retailers.

## Role in the supply chain

Walmart is a [[Retailer]]. The Industrial Ontologies Foundry quotes the CSCMP wording that names global companies like Walmart among retailers.[^5] See [[Vendor-Managed Inventory]] for the inventory practice the vault relates to Walmart; no source opened here describes Walmart's use of it.

## What the sources do not establish

Sources give no store counts, revenue or supplier numbers that are current. The Commission description is from 1999, and the company's about page is a general statement.[^2][^1]

[^1]: Walmart, “About Walmart”. https://corporate.walmart.com/about
[^2]: European Commission, Case M.1612 Wal-Mart / ASDA, merger decision of 1999. https://ec.europa.eu/competition/mergers/cases/decisions/m1612_en.pdf
[^3]: Walmart and Sam’s Club press release, “Walmart and Sam’s Club to Require Real-Time, End-to-End Food Traceability with Blockchain”, 24 September 2018. https://corporate.walmart.com/content/dam/corporate/documents/press-center/in-wake-of-romaine-e-coli-scare-walmart-deploys-blockchain-to-track-leafy-greens/press-release-leafy-greens-on-blockchain.pdf
[^4]: FoodIngredientsFirst, “Tracking leafy greens: Walmart urges suppliers to contribute to blockchain database”, 27 September 2018. https://www.foodingredientsfirst.com/news/tracking-leafy-greens-walmart-urges-suppliers-to-contribute-to-blockchain-database.html
[^5]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

