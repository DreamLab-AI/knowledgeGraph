Supplier selection is the choice of which suppliers a buyer will deal with, based on an assessment of the suppliers themselves against stated criteria.[^1][^2][^3]

The UK Cabinet Office Sourcing Playbook says the selection process determines whether bidders can comply with exclusion grounds and demonstrate suitability to carry out the contract, and that the selection stage is an assessment of the suppliers themselves, as opposed to the evaluation and award stage, which is an assessment of their bids.[^1] On technical and professional ability, it says the skills, efficiency, experience and reliability of suppliers should be taken into account.[^1]

Article 58 of Directive 2014/24/EU says selection criteria may relate to suitability to pursue the professional activity, economic and financial standing, and technical and professional ability. Contracting authorities may impose only requirements appropriate to ensure that a candidate or tenderer has the legal and financial capacities and the technical and professional abilities to perform the contract, related and proportionate to its subject-matter.[^2] UNCITRAL's Model Law lists criteria that suppliers must meet as the procuring entity considers appropriate, including the necessary professional, technical and environmental qualifications, financial resources, equipment, managerial capability, reliability, experience and personnel to perform the contract.[^3]

## Scope and distinctions

In pharmaceutical manufacturing, EU good manufacturing practice says the selection, qualification, approval and maintenance of suppliers of starting materials should be documented as part of the quality system, with supervision proportionate to risk.[^4] See [[Supplier Qualification]], [[Supplier Management]], [[Request for Proposal]] and [[Procurement]].

## What the sources do not establish

All sources are public procurement or regulatory rules, so the multi-criteria methods used by private buyers to rank suppliers are not covered here; the standard review of those methods could not be opened.[^1][^2][^3]

[^1]: UK Cabinet Office, Crown copyright (Open Government Licence v3.0), June 2023, “The Sourcing Playbook: Government guidance on service delivery, including outsourcing, insourcing, mixed economy sourcing and contracting”. https://assets.publishing.service.gov.uk/media/64901fcc5f7bb700127fac5e/Sourcing_Playbook_Final.pdf
[^2]: European Parliament and Council, Directive 2014/24/EU on public procurement (legislation.gov.uk copy), “Article 58 Selection criteria”. https://www.legislation.gov.uk/eudr/2014/24/article/58
[^3]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf
[^4]: European Commission, EudraLex Volume 4, EU Guidelines for Good Manufacturing Practice, Part I Chapter 5, “Chapter 5: Production”. https://health.ec.europa.eu/document/download/4a1fdb4f-6f6f-49c4-b264-8056e5bbe078_en?filename=chapter_5.pdf

