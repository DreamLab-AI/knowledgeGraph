Secondary protocols built atop Layer 1 blockchains that process transactions off-chain or in parallel batches, then periodically commit aggregated state changes to the main chain. Layer 2 solutions achieve dramatically higher throughput, lower fees, and improved user experience while inheriting the security guarantees of the underlying base layer. Principal approaches include rollups (optimistic and ZK), state channels, and sidechains.

### Semantic Classification

### Content

## Layer 2 Definition & Core Architecture

- **Layer 2 (L2)** represents a category of [[blockchain]] [[scaling-solutions]] that operate as secondary frameworks built atop [[Layer1]] base chains like [[Ethereum]], [[Bitcoin Proof-of-Work Protocol]], or [[Polygon]], executing transactions off the main chain while leveraging the security and finality of the underlying Layer 1.

### Fundamental Architecture Principles

- **Off-Chain Execution**: Transactions are processed outside the main chain by [[sequencer|sequencers]] or [[validator|validators]], dramatically reducing computational load on Layer 1
- **On-Chain Settlement**: Final state commitments and [[fraud-proofs]] or [[validity-proofs]] are periodically posted to Layer 1 for security anchoring
- **Security Inheritance**: L2 solutions derive their ultimate security from Layer 1 [[consensus-mechanisms]] and [[cryptographic-primitives]]
- **Data Availability**: Transaction data is either posted on-chain ([[rollup|rollups]]) or kept off-chain with commitments ([[Plasma]], [[Validium]])
- **Bridge Mechanisms**: [[canonical-bridge|Canonical bridges]] or [[third-party-bridges]] enable asset transfers between Layer 1 and Layer 2

### Why Layer 2 Solutions Are Essential

- **Scalability Bottleneck**: [[Ethereum]] processes ~15-30 TPS, [[Bitcoin Proof-of-Work Protocol]] ~7 TPS - insufficient for global-scale adoption
- **High Transaction Costs**: During network congestion, [[gas-fees]] on Ethereum can exceed $50-200 per transaction
- **User Experience**: Slow confirmation times (10-15 minutes for Bitcoin, 12-15 seconds for Ethereum) hinder real-time applications
- **Environmental Impact**: Layer 1 [[Proof-of-Work]] and [[Proof-of-Stake]] consume significant energy; L2 amortizes this across thousands of transactions
- **Economic Efficiency**: L2 enables [[micropayments]], [[NFT]] minting, [[Decentralised Finance]] operations, and [[gaming]] at fraction of Layer 1 costs

### Layer 2 vs Layer 1 Fundamental Differences

- **Execution Environment**: L1 = every node validates every transaction; L2 = centralized or semi-decentralized sequencers batch transactions
- **Security Model**: L1 = direct consensus; L2 = derived security through [[fraud-proofs]], [[validity-proofs]], or [[Multisignature]] schemes
- **Finality**: L1 = probabilistic (Bitcoin) or deterministic (Ethereum); L2 = soft finality (instant) + hard finality (after L1 settlement)
- **Decentralization Trade-off**: Most L2s sacrifice some decentralization for performance, though [[decentralized-sequencers]] are emerging

## Layer 2 Categories & Technical Approaches

### 1. Rollups (Most Secure & Popular)

- **Definition**: Bundle hundreds of transactions into a single batch, execute off-chain, post compressed data + state root to Layer 1
- **Security**: Inherits full Layer 1 security through [[fraud-proofs]] (Optimistic) or [[validity-proofs]] (ZK)
- **Data Availability**: All transaction data posted on-chain, enabling anyone to reconstruct state

#### Optimistic Rollups

- **Mechanism**: Assume transactions are valid by default; use [[fraud-proof]] challenges during 7-day dispute window
- **Proof System**: [[interactive-fraud-proofs]] where challengers and asserters engage in binary search to identify disputed instruction
- **Withdrawal Delay**: 7 days for [[Arbitrum]], [[Optimism]]; required for security of fraud proof game
- **EVM Compatibility**: Near-perfect [[EVM-equivalence]] enabling seamless [[Solidity]] contract migration
- **Leading Implementations**:
  - **[[Arbitrum]]**: Largest L2 by [[TVL]] ($3.2B as of 2025), uses [[Nitro]] architecture with [[WASM]]-based fraud proofs
  - **[[Optimism]]**: Pioneer of [[OP-Stack]] modular framework, powers [[Base]], [[Zora]], [[Mode]]
  - **[[Base]]**: Coinbase's L2 built on OP-Stack, $1.8B TVL, focus on [[consumer-applications]]
  - **[[Mantle]]**: Uses [[modular-data-availability]] and [[EigenDA]] for enhanced throughput
- **Advantages**: Low proof generation costs, high EVM compatibility, mature tooling
- **Disadvantages**: 7-day withdrawal delay, vulnerable to [[sequencer-censorship]], higher on-chain data costs

#### ZK-Rollups (Zero-Knowledge Rollups)

- **Mechanism**: Generate [[validity-proofs]] ([[zkSNARK]], [[zkSTARK]], [[PLONK]]) proving correct state transition
- **Proof Verification**: Layer 1 verifies cryptographic proof in single transaction, providing instant finality
- **Withdrawal Speed**: Minutes to hours (no challenge period needed)
- **Privacy Potential**: ZK proofs can hide transaction details while proving validity ([[Aztec]], [[zkSync]])
- **Leading Implementations**:
  - **[[zkSync-Era]]**: [[zkEVM]] using [[PLONK]] proofs, $230M TVL, native [[account-abstraction]]
  - **[[Starknet]]**: Uses [[Cairo]] programming language and [[zkSTARK]] proofs (no trusted setup, quantum-resistant)
  - **[[Polygon-zkEVM]]**: Type 2 zkEVM, high EVM equivalence, $85M TVL
  - **[[Scroll]]**: Type 2 zkEVM optimizing for EVM compatibility, $65M TVL
  - **[[Linea]]**: ConsenSys zkEVM, [[zkSTARK]]-based, integrated with [[MetaMask]]
  - **[[Taiko]]**: Type 1 zkEVM (full Ethereum equivalence), decentralized prover network
- **Advantages**: Fast withdrawals, higher privacy potential, lower on-chain data in some designs
- **Disadvantages**: Complex proof generation (high computational cost), EVM compatibility challenges, immature tooling

#### Hybrid & Next-Gen Rollups

- **[[Metis]]**: Optimistic rollup with decentralized sequencer rotation
- **[[Boba-Network]]**: Optimistic rollup with fast exit via liquidity pools
- **[[Aztec]]**: Privacy-focused zkRollup with encrypted transaction execution
- **[[Fuel]]**: Modular execution layer using [[UTXO]] model for parallel transaction processing

### 2. State Channels

- **Definition**: Multi-party off-chain agreements secured by on-chain [[smart-contracts]], enabling unlimited transactions with only 2 on-chain txs (open/close)
- **Security Model**: [[cryptoeconomic-security]] through [[Multisignature]] and punishment mechanisms
- **Use Cases**: High-frequency bidirectional payments, [[gaming]] state updates, [[streaming-payments]]
- **Limitations**: Require online participation from all parties, capital lockup, complex channel management

#### Leading State Channel Implementations

- **[[Lightning-Network]]**: Bitcoin's premier L2 with 15,000+ nodes, $300M+ capacity, enables instant BTC payments
  - **Architecture**: [[HTLC]] (Hash Time-Locked Contracts) for trustless routing across multi-hop channels
  - **Routing**: [[pathfinding-algorithms]] find optimal payment routes through network graph
  - **Watchtowers**: Third-party services monitor channels for fraud attempts while users are offline
  - **Recent Innovations**: [[Taproot]] integration, [[PTLCs]] (Point Time-Locked Contracts), [[channel-factories]]
  - **Adoption**: Major exchanges (Kraken, Bitfinex) and apps (Strike, Cash App) integrate Lightning
- **[[Raiden-Network]]**: Ethereum state channel network for ERC-20 token transfers
- **[[Connext]]**: [[NXTP]] protocol for cross-chain liquidity using state channels
- **[[Celer-Network]]**: Generalized state channel platform with [[layer2.finance]] DeFi aggregation

### 3. Sidechains

- **Definition**: Independent blockchains with their own [[consensus-mechanisms]], connected to Layer 1 via [[two-way-peg]] bridges
- **Security Model**: **Independent security** - does NOT inherit Layer 1 security; relies on own validator set
- **Trade-off**: Higher performance and flexibility, but weaker security guarantees than rollups
- **Use Cases**: [[Gaming]], high-throughput applications, experimentation with new consensus

#### Leading Sidechain Implementations

- **[[Polygon-PoS]]**: Largest sidechain with $1.1B TVL, [[Proof-of-Stake]] consensus, 100+ validators
- **[[Gnosis-Chain]]**: Ethereum sidechain for [[prediction-markets]] and [[DAOs]], uses [[xDai]] stablecoin
- **[[Ronin]]**: Gaming-focused sidechain for [[Axie-Infinity]], recovered from $625M bridge hack
- **[[Liquid-Network]]**: Bitcoin sidechain for institutional settlement, 2-minute blocks, [[Confidential-Transactions]]
  - **Use Case**: Exchange-to-exchange transfers, [[tether]] issuance, [[asset-tokenization]]
  - **Federation**: 15-member [[functionary]] group controls peg
- **[[Rootstock]] (RSK)**: Bitcoin sidechain with [[EVM]] compatibility, [[merge-mining]] with Bitcoin
  - **Smart Contracts**: Enables Solidity contracts secured by Bitcoin hashrate
  - **[[Powpeg]]**: Hybrid security model with [[HSMs]] and Bitcoin full nodes

### 4. Plasma

- **Definition**: Framework for creating child chains that periodically commit [[Merkle-roots]] to Layer 1
- **Data Availability**: Off-chain (only commitments on Layer 1), reducing costs but requiring users to watch chain
- **Exit Mechanism**: Users submit [[Merkle-proofs]] to withdraw; 7-14 day challenge period
- **Limitation**: [[data-availability-problem]] and [[mass-exit]] scenarios led to decline in favor of rollups
- **Historical Implementations**: [[OMG-Network]], [[Polygon-Plasma]] (deprecated), [[Matic-Network]] (migrated to PoS)

### 5. Validium

- **Definition**: Hybrid of zkRollup (validity proofs) + Plasma (off-chain data availability)
- **Security**: Validity proofs ensure state correctness, but off-chain data creates availability risk
- **Use Cases**: High-throughput applications where some data availability risk is acceptable
- **Implementations**: [[StarkEx]] (powers [[dYdX]], [[Sorare]], [[ImmutableX]]), [[zkPorter]]

## Ethereum Layer 2 Ecosystem (2025 Landscape)

### Market Overview & Adoption Metrics

- **Total L2 TVL**: $12.4 billion (as of Q1 2025)
- **Daily Transactions**: 8.5 million across all Ethereum L2s (vs 1.2M on Ethereum mainnet)
- **Average Transaction Cost**: $0.02-0.15 on L2 vs $3-25 on Ethereum L1
- **User Adoption**: 4.2 million daily active addresses across L2 ecosystem

### Top Ethereum L2s by TVL (Q1 2025)

- **1. [[Arbitrum-One]]**: $3.2B TVL
  - [[Arbitrum-Nitro]] upgrade delivers 10x performance improvement
  - [[Stylus]] enables [[Rust Systems Programming Language]], [[C++]] smart contracts alongside Solidity
  - [[Arbitrum-Orbit]]: Framework for custom L3 chains (gaming, enterprise)
  - Ecosystem: 400+ dApps including [[GMX]], [[Camelot]], [[Radiant-Capital]]
- **2. [[Optimism-Mainnet]]**: $2.1B TVL
  - [[OP-Stack]]: Modular framework powering 15+ L2s and L3s
  - [[Superchain]] vision: Network of interoperable OP-Stack chains
  - [[RetroPGF]]: Novel public goods funding mechanism ($30M distributed)
  - Ecosystem: [[Velodrome]], [[Synthetix]], [[Perpetual-Protocol]]
- **3. [[Base]]**: $1.8B TVL
  - Coinbase-backed L2, onboarded 2M+ users in 6 months
  - Focus on [[consumer-crypto]]: [[Farcaster]], [[friend.tech]], [[Zora]]
  - Seamless fiat on-ramp integration via Coinbase
- **4. [[Blast]]**: $1.4B TVL
  - Native yield for ETH and stablecoins (4% ETH, 5% stablecoin)
  - Controversial early launch with TVL locked for 3 months
- **5. [[zkSync-Era]]**: $230M TVL
  - Leading zkEVM with native [[account-abstraction]] (AA)
  - [[Paymasters]] enable gasless transactions and [[ERC-20]] fee payment
  - [[Hyperchains]]: Customizable zkSync-powered L3s launching 2025
- **6. [[Polygon-zkEVM]]**: $85M TVL
  - Type 2 zkEVM prioritizing EVM compatibility
  - [[Polygon-2.0]] upgrade: Unified liquidity layer connecting all Polygon chains
- **7. [[Starknet]]**: $1.1B TVL
  - [[Cairo-1.0]]: Safer, more expressive smart contract language
  - [[Starknet-Stack]]: Build custom appchains (StarkEx → Starknet migration path)
  - [[Volition]]: Hybrid data availability (on-chain + off-chain per-user choice)
- **8. [[Linea]]**: $450M TVL
  - ConsenSys zkEVM with deep MetaMask integration
  - [[Verifier]]: Decentralized proof verification network (launching Q2 2025)
- **9. [[Scroll]]**: $65M TVL
  - Type 2 zkEVM with focus on decentralization
  - [[decentralized-prover-network]] distributes proof generation
- **10. [[Mantle]]**: $1.2B TVL
  - [[modular-architecture]]: Separate execution, settlement, data availability
  - [[EigenDA]] integration for ultra-low-cost data availability

### Emerging Ethereum L2 Technologies

- **[[OP-Stack]] Chains**: [[Mode]], [[Zora]], [[Public-Goods-Network]], [[Fraxtal]] - all sharing Optimism's security
- **[[Arbitrum-Orbit]] Chains**: [[Xai]] (gaming), [[Proof-of-Play]] (gaming), [[Rari-Chain]] (NFTs)
- **[[Taiko]]**: Type 1 zkEVM achieving full Ethereum equivalence (can verify Ethereum blocks)
- **[[Kakarot]]**: zkEVM built with Cairo, combining Starknet and Ethereum ecosystems
- **[[Aztec]]**: Encrypted L2 enabling private DeFi with [[private-state]] and [[public-state]]

## Bitcoin Layer 2 Ecosystem (2025 Landscape)

### Bitcoin L2 Landscape Overview

- **Unique Challenges**: Bitcoin's [[UTXO]] model, limited [[Script]] functionality, and [[Proof-of-Work]] consensus create different constraints than Ethereum
- **Security Philosophy**: Bitcoin L2s prioritize inheriting Bitcoin's unmatched security over rapid innovation
- **Market Opportunity**: Bitcoin holds $1.2 trillion market cap but lacks native [[smart-contract]] and [[Decentralised Finance]] capabilities

### 1. Lightning Network (Premier Bitcoin L2)

- **Architecture**: [[payment-channel]] network using [[HTLC]] for trustless multi-hop routing
- **Statistics (Q1 2025)**:
  - **15,432 active nodes** across global network
  - **48,200 payment channels** with total capacity of **$310 million**
  - **Average channel capacity**: 6.4M satoshis (~$4,000)
  - **Payment success rate**: 94.7% for payments under $100
- **Technical Components**:
  - **[[BOLT]] Specifications**: Lightning's technical standards (BOLT 1-11)
  - **[[onion-routing]]**: Privacy-preserving payment routing (similar to Tor)
  - **[[AMP]]** (Atomic Multi-Path Payments): Split large payments across multiple routes
  - **[[Keysend]]**: Spontaneous payments without invoices
  - **[[LNURL]]**: Simplified UX protocol for Lightning apps
- **Recent Innovations**:
  - **[[Taproot-Channels]]**: Enhanced privacy and reduced on-chain footprint
  - **[[PTLCs]]** (Point Time-Locked Contracts): Replacing HTLCs for better privacy
  - **[[channel-factories]]**: Hierarchical channels reducing on-chain transactions
  - **[[eltoo]]**: Simplified channel update mechanism (requires [[SIGHASH_ANYPREVOUT]])
  - **[[Trampoline-routing]]**: Outsourced pathfinding for mobile wallets
- **Ecosystem Applications**:
  - **[[Strike]]**: Fiat-to-Lightning bridge, powering [[Twitter-Tips]] and [[Shopify]] payments
  - **[[Cash-App]]**: Square's integration brings Lightning to 40M+ users
  - **[[Kraken]]**, **[[Bitfinex]]**: Major exchange integrations
  - **[[Wallet-of-Satoshi]]**: Custodial Lightning wallet with 500K+ users (shut down in USA)
  - **[[Breez]]**: Non-custodial mobile wallet with integrated Lightning Service Provider
  - **[[Phoenix]]**: Self-custodial mobile wallet with automated channel management
- **Challenges**:
  - **Liquidity Management**: Channels require balanced inbound/outbound capacity
  - **Routing Failures**: Large payments (>$500) have lower success rates
  - **Online Requirement**: Requires periodic connectivity for security
  - **UX Complexity**: Channel management intimidates non-technical users

### 2. RGB Protocol (Bitcoin Smart Contracts)

- **Architecture**: [[client-side-validation]] framework for smart contracts with Bitcoin as commitment layer
- **How It Works**: Contract state stored off-chain; Bitcoin blockchain used only for [[single-use-seals]] (UTXO-based commitments)
- **Privacy**: Contract details only visible to participants, not global broadcast
- **Use Cases**:
  - **[[Fungible-Assets]]**: Issue tokens (RGB20 standard, similar to ERC-20)
  - **[[NFTs]]**: Collectibles and digital art (RGB21 standard)
  - **[[Decentralised Finance]]**: Decentralized exchanges, lending protocols
  - **[[Stablecoins]]**: USDT considering RGB for Bitcoin-native issuance
- **Technical Features**:
  - **[[Turing-complete]] contracts**: More expressive than Bitcoin Script
  - **[[deterministic-execution]]**: No consensus required for state transitions
  - **Lightning integration**: RGB contracts compatible with Lightning channels
- **Development Status**: Mainnet beta launched Q4 2024, growing developer adoption
- **Implementations**: [[RGB-Node]], [[RGB-Core]], [[Bitlight-Wallet]]

### 3. Liquid Network (Institutional Bitcoin L2)

- **Purpose**: Fast, confidential Bitcoin transactions for exchanges and institutions
- **Consensus**: [[Strong-Federation]] of 15 [[functionaries]] (Blockstream, exchanges, financial institutions)
- **Features**:
  - **[[Confidential-Transactions]]**: Blinded amounts using [[Pedersen-commitments]]
  - **[[Issued-Assets]]**: Create tokens on Liquid (USDT has $100M+ on Liquid)
  - **2-minute blocks**: 30x faster than Bitcoin
  - **[[Atomic-Swaps]]**: Trustless trades between L-BTC and Liquid assets
- **Statistics (Q1 2025)**:
  - **$280 million** in L-BTC (pegged Bitcoin)
  - **$150 million** in Tether (USDt) on Liquid
  - **45,000** transactions per month
- **Use Cases**: Exchange settlements, OTC trading, tokenized securities
- **Trade-off**: Centralized federation vs Lightning's decentralization

### 4. Stacks (Bitcoin Smart Contract Layer)

- **Architecture**: Separate blockchain that settles to Bitcoin via [[Proof-of-Transfer]] (PoX)
- **[[Clarity]] Language**: Decidable smart contract language (knows outcomes before execution)
- **Bitcoin Integration**:
  - All Stacks blocks hash to Bitcoin blockchain
  - [[sBTC]]: Decentralized Bitcoin peg (launching Q2 2025)
  - Bitcoin can trigger Stacks contracts ([[Bitcoin-Triggers]])
- **Statistics (Q1 2025)**:
  - **$140 million TVL** (post-sBTC launch estimate)
  - **300+ dApps** including [[ALEX]], [[Arkadiko]], [[Gamma]]
  - **$180 million** market cap of STX token
- **Use Cases**: [[Decentralised Finance]], [[NFTs]] ([[Bitcoin-Ordinals]] integration), [[DAOs]]
- **[[Nakamoto-Release]]** (2024): 5-second block times, 100% Bitcoin finality

### 5. Rootstock (RSK) - Bitcoin EVM Sidechain

- **Architecture**: Merged-mined sidechain with [[EVM]] compatibility
- **Security**: Secured by ~45% of Bitcoin hashrate through merge-mining
- **[[Powpeg]]**: Hybrid custody using Bitcoin full nodes + [[HSMs]]
- **Statistics**: $110M TVL, 2,500 daily active users
- **Use Cases**: Port Ethereum dApps to Bitcoin ecosystem
- **Challenges**: Lower adoption compared to Ethereum L2s

### 6. Emerging Bitcoin L2 Solutions

- **[[BitVM]]**: Enable arbitrary computation on Bitcoin using fraud proofs (theoretical framework, in research)
- **[[Ark]]**: [[Virtual-UTXO]] protocol for scalable, privacy-preserving payments
- **[[Fedimint]]**: [[Chaumian-e-cash]] federations for community banks on Bitcoin
- **[[Nomic]]**: Decentralized Bitcoin bridge to [[Cosmos]] ecosystem
- **[[Threshold-Network]]**: Decentralized bridge bringing Bitcoin to Ethereum (tBTC)
- **[[Rollkit]]**: Sovereign rollups using Bitcoin for data availability

### Bitcoin L2 Comparison Matrix

- **Lightning**: Best for payments, high decentralization, requires liquidity management
- **RGB**: Best for smart contracts and privacy, experimental stage
- **Liquid**: Best for institutions, fast settlement, centralized federation
- **Stacks**: Best for DeFi/NFTs, established ecosystem, indirect Bitcoin security
- **Rootstock**: Best for EVM compatibility, moderate adoption

## Layer 2 Performance Metrics & Benchmarks

### Throughput Comparison (Transactions Per Second)

- **Ethereum L1**: 15-30 TPS
- **Bitcoin L1**: 7 TPS
- **[[Arbitrum]]**: 4,000 TPS (theoretical), 40-50 TPS (current)
- **[[Optimism]]**: 2,000 TPS (theoretical), 30-40 TPS (current)
- **[[zkSync-Era]]**: 2,000+ TPS
- **[[Starknet]]**: 10,000+ TPS (with recursive proofs)
- **[[Polygon-zkEVM]]**: 2,000 TPS
- **[[Lightning-Network]]**: Unlimited TPS (within channels), 10,000+ TPS (network-wide)
- **[[Liquid-Network]]**: 140 TPS (2-minute blocks)

### Transaction Cost Comparison (USD, Q1 2025)

- **Ethereum L1**: $3-25 (simple transfer), $50-200 (complex DeFi)
- **Bitcoin L1**: $1-5 (standard priority)
- **Arbitrum**: $0.10-0.30
- **Optimism/Base**: $0.05-0.20
- **zkSync Era**: $0.15-0.40
- **Starknet**: $0.02-0.10 (lowest among zkEVMs)
- **Polygon zkEVM**: $0.08-0.25
- **Lightning Network**: $0.001-0.01 (sub-cent routing fees)
- **Liquid Network**: $0.10-0.20

### Finality Time Comparison

- **Ethereum L1**: 12-15 minutes (2 epochs)
- **Bitcoin L1**: 60 minutes (6 confirmations)
- **Optimistic Rollups (soft)**: 1-2 seconds (sequencer confirmation)
- **Optimistic Rollups (hard)**: 7 days (fraud proof window)
- **ZK-Rollups (soft)**: 1-2 seconds (sequencer)
- **ZK-Rollups (hard)**: 15 minutes - 2 hours (proof generation + L1 verification)
- **Lightning Network**: <1 second (instant settlement within channel)
- **Liquid Network**: 2 minutes (block time)
- **Stacks**: 5 seconds (Nakamoto upgrade), anchored to Bitcoin every ~10 minutes

### Withdrawal Time (L2 → L1)

- **Optimistic Rollups**: 7 days (challenge period)
- **ZK-Rollups**: 15 minutes - 4 hours (proof generation time)
- **Lightning**: 1-2 hours (cooperative close) or 1-2 weeks (force close with timelock)
- **Liquid**: 2 hours - 24 hours (federation signature collection)
- **Polygon PoS**: 3 hours (checkpoint finality)

### Security Score (Derived from L2Beat.com)

- **Stage 2 Rollups** (Full L1 security): None yet (as of Q1 2025)
- **Stage 1 Rollups** (Fraud/validity proofs live, some training wheels): [[zkSync-Era]], [[Starknet]]
- **Stage 0 Rollups** (Proofs in development): [[Arbitrum]], [[Optimism]], [[Base]]
- **Sidechains** (Independent security): [[Polygon-PoS]], [[Gnosis]], [[Liquid]], [[Rootstock]]
- **State Channels** (Cryptoeconomic security): [[Lightning-Network]]

## Layer 1 vs Layer 2 Trade-Offs

### Security

- **L1 Advantages**: Direct consensus validation, battle-tested security, no additional trust assumptions
- **L2 Trade-offs**: Rollups inherit L1 security but add sequencer and bridge risks; sidechains have independent security
- **Risk Vectors**: [[sequencer-censorship]], [[bridge-hacks]], [[smart-contract-bugs]], [[centralized-operators]]

### Decentralization

- **L1**: Thousands of independent nodes (Ethereum: 7,000+, Bitcoin: 15,000+)
- **L2 Current State**: Most L2s have centralized sequencers (single point of failure/censorship)
- **L2 Roadmap**: [[decentralized-sequencers]] (Metis launched Q4 2024), [[shared-sequencers]] ([[Astria]], [[Espresso]])

### Speed & User Experience

- **L1 Limitations**: 10-15 second block times (Ethereum), 10-minute blocks (Bitcoin), frequent congestion
- **L2 Benefits**: Sub-second confirmations, instant feedback, consistent performance

### Cost Efficiency

- **L1**: High costs during demand spikes (NFT mints, DeFi volatility)
- **L2**: 90-99.9% cost reduction by amortizing L1 verification across hundreds of transactions

### Composability

- **L1 Advantages**: Atomic composability - all dApps can interact within single transaction
- **L2 Challenges**: Cross-L2 composability requires bridges, breaking atomic execution
- **Emerging Solutions**: [[shared-sequencers]], [[cross-L2-messaging]] ([[LayerZero]], [[Chainlink-CCIP]])

### Censorship Resistance

- **L1**: Maximum censorship resistance (anyone can submit transaction via P2P network)
- **L2**: Sequencer can censor/reorder transactions; forced inclusion mechanisms mitigate this
- **Fallback**: All L2s must provide "escape hatch" to withdraw directly from L1 contract

## Bridges & Cross-Chain Interoperability

### Bridge Architectures

#### Canonical Bridges (Native L2 Bridges)

- **Design**: Deployed by L2 team, tightly integrated with L2 protocol
- **Security**: Inherits L2's security model (fraud proofs or validity proofs)
- **Examples**: [[Arbitrum-Bridge]], [[Optimism-Bridge]], [[zkSync-Bridge]]
- **Advantages**: Most secure, official support, aligned incentives
- **Disadvantages**: Slow withdrawals (7 days for Optimistic Rollups), limited to single L2

#### Third-Party Bridges

- **Design**: Independent protocols connecting multiple chains
- **Security Models**:
  - **[[Lock-and-Mint]]**: Lock asset on source chain, mint wrapped version on destination
  - **[[Liquidity-Networks]]**: Use liquidity pools on both chains for instant swaps
  - **[[Optimistic-Bridges]]**: Use fraud proofs to verify cross-chain messages
  - **[[Light-Client-Bridges]]**: Verify source chain headers on destination
- **Examples**: [[Hop-Protocol]], [[Across-Protocol]], [[Stargate]], [[Synapse]]
- **Advantages**: Fast withdrawals (minutes), multi-chain support, better UX
- **Disadvantages**: Additional trust assumptions, smart contract risk, [[bridge-hacks]] ($2.5B stolen in 2022)

#### Token Bridges vs Message Bridges

- **Token Bridges**: Transfer only assets (ERC-20, NFTs)
- **Message Bridges**: Pass arbitrary data enabling [[cross-chain-smart-contracts]]
- **Leading Message Bridges**: [[LayerZero]], [[Chainlink-CCIP]], [[Axelar]], [[Wormhole]]

### Bridge Security Incidents & Lessons

- **Ronin Bridge** (2022): $625M stolen via compromised validator keys
- **Wormhole** (2022): $320M exploit in signature verification
- **Nomad Bridge** (2022): $190M drained due to implementation bug
- **Key Lessons**: Bridges are critical attack vectors; prefer canonical bridges or battle-tested third-party options

### Cross-L2 Communication Protocols

- **[[Superchain]]** (Optimism): Shared [[OP-Stack]] enables native interoperability
- **[[AggLayer]]** (Polygon): Unified liquidity and state across Polygon chains
- **[[shared-sequencers]]**: [[Astria]], [[Espresso]] enable atomic cross-L2 transactions
- **[[intent-based-protocols]]**: [[Anoma]], [[SUAVE]] abstract cross-chain complexity

## 2025 Layer 2 Statistics & Market Data

### Ethereum L2 Ecosystem Metrics

- **Total Value Locked**: $12.4 billion across all L2s
- **Daily Active Addresses**: 4.2 million (vs 400K on Ethereum L1)
- **Daily Transaction Volume**: 8.5 million transactions
- **Transaction Cost Savings**: $4.2 billion saved vs L1 fees (2024 estimate)
- **L2 as % of Ethereum Activity**: 87% of transactions, 23% of economic value

### Bitcoin L2 Ecosystem Metrics

- **Lightning Network Capacity**: $310 million
- **Lightning Active Nodes**: 15,432
- **Lightning Payment Channels**: 48,200
- **Liquid Network L-BTC**: $280 million
- **Stacks TVL**: $140 million (post-sBTC estimate)
- **Rootstock TVL**: $110 million

### Top L2s by Transaction Count (Daily, Q1 2025)

- **Base**: 3.2M transactions/day (consumer apps)
- **Arbitrum**: 1.8M transactions/day
- **Optimism**: 850K transactions/day
- **Polygon zkEVM**: 420K transactions/day
- **zkSync Era**: 380K transactions/day

### Institutional Adoption Indicators

- **[[Coinbase]]**: Launched Base L2, onboarding mainstream users
- **[[Visa]]**: Piloting stablecoin settlements on Ethereum L2s
- **[[PayPal]]**: PYUSD stablecoin deployed on Base and Ethereum
- **[[Sony]]**: Building [[Soneium]] L2 for gaming and entertainment
- **[[Kraken]]**: Lightning Network integration for Bitcoin withdrawals

### Developer Activity (GitHub Commits, 2024)

- **Arbitrum**: 12,400 commits
- **Optimism/OP-Stack**: 18,200 commits (modular framework activity)
- **zkSync**: 8,600 commits
- **Starknet**: 7,300 commits
- **Lightning Network**: 5,800 commits (across implementations)

  #### Future Directions

### 1. Layer 3 and Application-Specific Chains

- **Definition**: L3 protocols built on top of L2s, inheriting security while adding customization
- **Use Cases**:
  - **Gaming**: Custom gas tokens, instant finality, high throughput
  - **Enterprise**: Permissioned execution with public settlement
  - **Privacy**: App-specific privacy guarantees
- **Frameworks**:
  - **[[Arbitrum-Orbit]]**: Customizable L3s on Arbitrum (Xai for gaming, Proof-of-Play)
  - **[[OP-Stack]]**: Modular L3s with alternative DA layers
  - **[[zkSync-Hyperchains]]**: ZK-powered L3s with unified liquidity
- **Architecture**: L3 posts to L2, L2 posts to L1 (recursive security)

### 2. Decentralized Sequencers

- **Current Problem**: Most L2s have single centralized sequencer (censorship risk, downtime)
- **Solutions in Development**:
  - **[[Metis]]**: Sequencer rotation among decentralized pool
  - **[[Taiko]]**: Based sequencing (Ethereum validators sequence L2 blocks)
  - **[[Astria]]**: Shared decentralized sequencer for multiple rollups
  - **[[Espresso]]**: Decentralized sequencer with [[HotShot]] consensus
- **Benefits**: Censorship resistance, liveness guarantees, credible neutrality

### 3. Shared Sequencers & Atomic Cross-L2

- **Vision**: Single sequencer network ordering transactions for multiple L2s
- **Benefits**: Atomic cross-L2 transactions, unified liquidity, simplified UX
- **Projects**: [[Astria]], [[Espresso]], [[Radius]]

### 4. Data Availability Innovations

- **Problem**: Posting rollup data to Ethereum L1 is expensive ($0.01-0.05 per transaction)
- **Solutions**:
  - **[[EIP-4844]]** (Proto-Danksharding): Introduced "blob" transactions, 10x cheaper DA (launched March 2024)
  - **[[Danksharding]]**: Full sharding with 16MB/block DA (2025-2026)
  - **[[EigenDA]]**: Off-chain DA secured by [[EigenLayer]] restaking (used by Mantle)
  - **[[Celestia]]**: Modular DA layer for rollups (150+ integrations)
  - **[[Avail]]**: Standalone DA network with [[validity-proofs]]
- **Impact**: 100x cost reduction enabling sub-cent transactions

### 5. ZK-EVM Maturity & Equivalence Ladder

- **Type 1** (Fully Ethereum-equivalent): [[Taiko]], [[Scroll]] - can verify Ethereum blocks
- **Type 2** (EVM-equivalent): [[Polygon-zkEVM]], [[Linea]] - equivalent at bytecode level
- **Type 3** (Almost EVM-equivalent): Minor modifications to enable efficient proving
- **Type 4** (High-level language equivalent): [[zkSync-Era]], [[Starknet]] - compile Solidity to custom VM
- **Trend**: Convergence toward Type 1-2 for maximum compatibility

### 6. Account Abstraction at L2 Scale

- **[[ERC-4337]]**: Standard for [[smart-contract-wallets]] deployed on Ethereum L1
- **Native AA**: zkSync Era, Starknet have account abstraction built into protocol
- **Use Cases**: [[social-recovery]], [[gasless-transactions]], [[multi-sig]] as default, [[session-keys]]
- **Adoption**: Base, Arbitrum, Optimism all support ERC-4337 infrastructure

### 7. Bitcoin L2 Renaissance

- **Drivers**: [[Ordinals]] and [[BRC-20]] showed demand for Bitcoin blockspace beyond payments
- **Innovations**:
  - **[[BitVM]]**: Enable complex contracts with fraud proofs (theoretical, in research)
  - **[[OP_CAT]] restoration**: Enable covenants and enhanced smart contracts
  - **[[Covenant-opcodes]]**: BIP-119 ([[CHECKTEMPLATEVERIFY]]), BIP-118 ([[SIGHASH_ANYPREVOUT]])
  - **RGB + Lightning**: Combine smart contracts with payment channels
- **Vision**: Bitcoin as settlement layer for diverse L2 ecosystem (payments, DeFi, NFTs, governance)

### 8. Regulatory & Compliance L2s

- **Trend**: Institutions require KYC, compliance without sacrificing performance
- **Approaches**:
  - **Permissioned L2s**: Whitelisted participants on private chains
  - **[[zk-KYC]]**: Prove compliance without revealing identity
  - **[[Compliance-Oracles]]**: On-chain verification of off-chain credentials
- **Projects**: [[Liquid]] (for institutions), custom Orbit/OP-Stack chains

### 9. Rollup-as-a-Service (RaaS)

- **Vision**: No-code deployment of custom L2s for specific applications
- **Providers**:
  - **[[Caldera]]**: Arbitrum/OP-Stack rollups with custom DA
  - **[[Conduit]]**: Managed OP-Stack rollups (powers Base infrastructure)
  - **[[Gelato]]**: Web3 Functions + RaaS for automated L2s
  - **[[AltLayer]]**: Restaked rollups with [[EigenLayer]] security
- **Use Cases**: Gaming studios, enterprises, DAOs launching custom chains

### 10. AI + L2 Convergence

- **[[on-chain-AI]]**: L2s provide cheap computation for [[AI-inference]] and [[zkML]] (zero-knowledge machine learning)
- **[[zkML]]**: Prove AI model executed correctly without revealing model or data
- **Projects**: [[Giza]] (zkML), [[EZKL]] (ZK for neural networks), [[Modulus-Labs]]
- **Vision**: Decentralized AI models verified on rollups

## Technical Challenges & Research Frontiers

### 1. MEV (Maximal Extractable Value) on L2

- **Problem**: Sequencers can extract MEV by reordering transactions
- **Solutions**: [[encrypted-mempools]], [[Fair-Sequencing-Service]], [[threshold-encryption]]
- **Projects**: [[Flashbots-SUAVE]], [[Chainlink-FSS]]

### 2. Prover Decentralization

- **Problem**: ZK-Rollups currently rely on centralized provers (high compute requirements)
- **Solutions**: [[distributed-proving]], [[proof-markets]], [[FPGA-acceleration]], [[GPU-proving]]
- **Projects**: [[RISC-Zero]], [[=nil; Foundation]], [[Polygon-Hermez]] prover network

### 3. Cross-L2 Liquidity Fragmentation

- **Problem**: Each L2 fragments liquidity, harming DeFi efficiency
- **Solutions**: [[shared-liquidity-layers]], [[intent-solvers]], [[cross-chain-AMMs]]
- **Projects**: [[Polygon-AggLayer]], [[Optimism-Superchain]], [[Chainlink-CCIP]]

### 4. Proof Recursion & Aggregation

- **Concept**: Generate proof that verifies multiple other proofs
- **Benefits**: Verify 1000s of L2s in single L1 transaction
- **Implementations**: [[Starknet-recursive-proofs]], [[Polygon-proof-aggregation]], [[zkSync-proof-compression]]

### 5. Data Availability Sampling

- **Concept**: Light clients verify data availability without downloading full data
- **Technology**: [[DAS]] (Data Availability Sampling) with [[KZG-commitments]]
- **Implementations**: Ethereum Danksharding, [[Celestia]]

## Ecosystem Tools & Infrastructure

### L2 Aggregators & Bridges

- **[[Jumper.exchange]]**: Meta-aggregator for cross-chain swaps
- **[[Bungee]]**: Bridge aggregator comparing routes
- **[[Orbiter-Finance]]**: Fast L2-to-L2 transfers
- **[[Hop-Protocol]]**: AMM-based cross-rollup bridge
- **[[Across-Protocol]]**: Optimistic bridge with instant transfers

### L2 Data & Analytics

- **[[L2Beat]]**: Comprehensive L2 risk analysis and TVL tracking
- **[[DeFiLlama]]**: Multi-chain TVL and protocol analytics
- **[[Dune-Analytics]]**: Community dashboards for L2 metrics
- **[[Growthepie]]**: L2 fundamental analysis and comparisons
- **[[Token-Terminal]]**: L2 revenue and financial metrics

### Developer Tools

- **[[Hardhat]]**: Ethereum development environment with L2 plugins
- **[[Foundry]]**: Fast Solidity framework with L2 fork testing
- **[[thirdweb]]**: Full-stack web3 development with L2 SDKs
- **[[scaffold-eth]]**: Rapid prototyping for L2 dApps
- **[[Alchemy]]**: Node infrastructure for 15+ L2s
- **[[QuickNode]]**: Multi-chain RPC with L2 support

### L2 Wallets

- **[[MetaMask]]**: Leading browser wallet with auto-network detection
- **[[Rainbow-Wallet]]**: Mobile-first with seamless L2 bridging
- **[[Rabby]]**: Multi-chain wallet with L2 transaction simulation
- **[[Argent]]**: Smart contract wallet with zkSync integration
- **[[Braavos]]**: Starknet-native wallet with account abstraction

  #### Related Concepts

- **Core Infrastructure**: [[Layer1]], [[Ethereum]], [[Bitcoin Proof-of-Work Protocol]], [[Consensus-Mechanisms]], [[Blockchain-Trilemma]]
- **Scaling Technologies**: [[Rollup]], [[StateChannel]], [[Sidechain]], [[Plasma]], [[Validium]], [[Volition]]
- **Proof Systems**: [[fraud-proofs]], [[validity-proofs]], [[zkSNARK]], [[zkSTARK]], [[PLONK]], [[Groth16]]
- **Cross-Chain**: [[Bridge]], [[cross-chain-messaging]], [[LayerZero]], [[Chainlink-CCIP]], [[Wormhole]]
- **Bitcoin L2**: [[Lightning-Network]], [[RGB-Protocol]], [[Liquid-Network]], [[Stacks]], [[Rootstock]]
- **Ethereum L2**: [[Arbitrum]], [[Optimism]], [[Base]], [[zkSync-Era]], [[Starknet]], [[Polygon-zkEVM]]
- **Advanced Concepts**: [[Data-Availability]], [[Sequencer]], [[shared-sequencers]], [[account-abstraction]], [[MEV]]
- **Future Tech**: [[Layer3]], [[Danksharding]], [[EIP-4844]], [[zkEVM]], [[BitVM]], [[OP-Stack]]
- **Security**: [[bridge-security]], [[sequencer-censorship]], [[fraud-proof-games]], [[escape-hatches]]
- **Standards**: [[ERC-4337]], [[BOLT]], [[OP-Stack]], [[Arbitrum-Orbit]], [[Cairo]], [[Clarity]]

## Key Resources & Documentation

- **Ethereum L2 Research**: [L2Beat.com](https://l2beat.com), [Ethereum.org/L2](https://ethereum.org/en/layer-2/)
- **Arbitrum**: [docs.arbitrum.io](https://docs.arbitrum.io)
- **Optimism**: [docs.optimism.io](https://docs.optimism.io), [OP-Stack specs](https://specs.optimism.io)
- **zkSync**: [docs.zksync.io](https://docs.zksync.io)
- **Starknet**: [docs.starknet.io](https://docs.starknet.io), [Cairo book](https://book.cairo-lang.org)
- **Lightning Network**: [lightning.network](https://lightning.network), [BOLT specs](https://github.com/lightning/bolts)
- **RGB Protocol**: [rgb.tech](https://rgb.tech)
- **Stacks**: [docs.stacks.co](https://docs.stacks.co)
- **Academic**: [L2Beat Risk Framework](https://l2beat.com/scaling/summary), [Vitalik's Rollup Guide](https://vitalik.ca/general/2021/01/05/rollup.html)

### Provenance

