Runes Protocol is a fungible token standard for the Bitcoin blockchain, introduced by Casey Rodarmor in 2024, that encodes token creation and transfer instructions directly into transaction outputs using the UTXO model. Unlike account-based token systems, Runes attaches a OP_RETURN-stored protocol message (a Runestone) to each transaction, assigning token balances to specific outputs so that ownership is tracked through spendable transaction outputs rather than a separate ledger. The protocol is designed to be more on-chain efficient than earlier Bitcoin-native token conventions such as BRC-20 and Ordinals-based token schemes, minimising UTXO proliferation while remaining fully compatible with the base-layer Bitcoin settlement mechanism. It reached significant ecosystem traction following its mainnet launch at the Bitcoin halving block in April 2024.

### Overview

- Runes Protocol addresses a long-standing gap in the Bitcoin ecosystem: a well-designed, native [[Fungible Token]] standard that does not require a separate chain, wrapped assets, or a state model foreign to Bitcoin's architecture.
- **Motivation**: Earlier approaches such as [[Colored Coins]], [[Counterparty]], and [[BRC-20]] suffered from UTXO bloat, reliance on third-party indexers, or opaque off-chain state machines. Runes aimed to fix these issues with a clean, minimal on-chain encoding.
- **Launch**: Mainnet activation occurred at block 840,000 (the fourth Bitcoin halving, April 2024), giving the protocol a clear, unambiguous genesis point that is verifiable by any [[Bitcoin Script]] evaluator.
- **Adoption**: Within weeks of launch, Runes accounted for a substantial share of Bitcoin transaction volume as speculators etched (created) thousands of tokens. This validated the protocol's on-chain mechanics while also highlighting fee-market pressures on the base layer.
- **Relationship to Ordinals**: The same team and community that developed [[Ordinals Protocol]] (for non-fungible inscriptions) built Runes. Both share the [[Bitcoin Proof-of-Work Protocol]] security model and UTXO-centric design philosophy, but serve different asset classes ([[Non-Fungible Token]] vs [[Fungible Token]]).

### Key Mechanisms

#### Runestone

- The core data structure is the **Runestone**, a protocol message encoded in an [[OP_RETURN]] output of a [[Bitcoin Transaction]].
- A Runestone can carry one or more of the following operations: Etch (create a new rune), Mint (claim open-edition tokens), Transfer (move balances between outputs), and Burn (destroy tokens).
- Nodes that do not understand the Runes protocol simply ignore the [[OP_RETURN]] data — it is consensus-safe and does not alter [[Bitcoin Script]] validation.

#### UTXO Balance Model

- Token balances are assigned to [[UTXO]] outputs. When a transaction spends a UTXO carrying a Rune balance, the Runestone in that transaction specifies how the balance is redistributed to the new outputs.
- This aligns with [[Blockchain Transaction]] atomicity: balances can only move if the spending transaction is valid and confirmed on the [[Bitcoin Proof-of-Work Protocol]] chain.
- Unallocated balances (not explicitly assigned by the Runestone) default to the first non-[[OP_RETURN]] output, preventing accidental loss.

#### Etching (Token Creation)

- Creating a new Rune (called **etching**) requires embedding a Runestone that specifies: the rune's unique name (a sequence of capital letters), divisibility (decimal places), supply cap, minting terms (open or closed), and optional metadata such as a symbol character.
- Names are globally unique and encoded as integers in the protocol to save space. Shorter names were initially reserved for a 4-year unlock schedule to reward early adopters who wait.

#### Minting

- Runes can be **open-mint** (anyone can mint up to a cap) or **pre-minted** (fixed supply at etch). Open-mint allows permissionless [[Token Minting]] within the parameters set by the etcher.
- Each mint operation is a [[Bitcoin Transaction]] carrying a Runestone that references the rune by ID (block:tx index).

#### Indexer Architecture

- Because Bitcoin nodes do not natively interpret Runes, wallets and explorers rely on **Runes indexers** — software that replays the blockchain, interpreting every Runestone to maintain a current balance state.
- The reference implementation is `ord` (the same binary used for [[Ordinals Protocol]]), which implements the canonical indexing rules.
- Indexers are off-chain but their output is deterministic: any conforming indexer reading the same blockchain data produces identical balances, making [[Tokenisation]] trust-minimised.

### Applications and Use Cases

- **Speculative token issuance**: Community and project tokens etched on Bitcoin, leveraging Bitcoin's security and global liquidity for fungible asset issuance.
- **Protocol governance tokens**: Projects can issue governance tokens that are secured by [[Proof of Work]] settlement rather than delegated [[Smart Contract]] platforms, reducing counterparty risk.
- **Bridging to DeFi**: Rune-backed assets can be wrapped and bridged into [[Decentralised Finance]] ecosystems (e.g., wrapped via custodians or trust-minimised bridges), giving Bitcoin-native tokens access to [[Decentralised Exchange]] liquidity.
- **Reward and loyalty tokens**: Applications issuing utility or reward tokens benefit from using a [[Bitcoin Proof-of-Work Protocol]]-anchored standard rather than a permissioned chain.
- **Digital collectible ecosystems**: Projects that already issue non-fungible inscriptions via [[Ordinals Protocol]] can pair them with Runes-based fungible companion tokens to create richer [[Digital Asset]] ecosystems.
- **Fee market signal**: High Runes minting activity creates significant transaction fee revenue for Bitcoin miners, contributing to the long-term fee-market sustainability after block reward reductions.

### Standards and Context

- Runes Protocol is not governed by a formal standards body. The canonical specification is maintained by Casey Rodarmor and the `ord` project on GitHub, with protocol changes released via the `ord` binary versioning.
- The protocol is self-enforcing through indexer consensus: any indexer that deviates from the canonical rules will compute different balances and become incompatible with the rest of the ecosystem. This creates informal but strong protocol stability incentives.
- Comparison with [[ERC-20]] on [[Ethereum]]: ERC-20 relies on [[Smart Contract]] execution within the EVM; Runes rely on [[Bitcoin Script]]'s UTXO model and off-chain indexers. Runes are simpler (no Turing-complete execution) but less programmable.
- Comparison with [[BRC-20]]: BRC-20 (also a Bitcoin fungible token convention) uses Ordinals inscriptions to store JSON state transitions, requiring more on-chain data per operation and more complex indexing. Runes are designed to be lighter and more UTXO-compatible.
- The broader regulatory context of [[Digital Asset]] classification (e.g., as securities or commodities) applies to Runes-issued tokens in the same way as other [[Blockchain Transaction]]-native tokens, with jurisdiction-specific outcomes.

### Provenance

