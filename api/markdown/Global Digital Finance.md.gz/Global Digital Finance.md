Global Digital Finance (GDF) is an industry membership association and self-regulatory organisation founded to develop voluntary codes of conduct, taxonomies, and governance frameworks for the digital asset and cryptocurrency sector. It convenes cross-sector working groups that produce best-practice guidance on topics such as crypto asset taxonomy, market conduct, custody, and consumer protection, while engaging with regulators, standards bodies, and central banks to inform policy. GDF acts as a liaison body between industry participants and public authorities including the Financial Stability Board, IOSCO, and national financial regulators, promoting responsible adoption of blockchain-based financial instruments. Its outputs serve as voluntary soft-law standards intended to accelerate convergence toward enforceable regulatory frameworks.

### Overview

- Global Digital Finance was established to address the governance gap that emerged as [[Digital Asset]] markets grew rapidly without consistent industry standards or regulatory clarity.
- As a [[Standards Body]], GDF occupies a soft-law position: its outputs are voluntary but are designed to precede and inform hard law, reducing regulatory fragmentation across jurisdictions.
- The organisation draws membership from exchanges, custodians, asset managers, technology providers, law firms, and financial institutions with exposure to [[Cryptocurrency]] and [[Token Economy]] markets.
- GDF engages directly with bodies including the [[Financial Stability Board]], the [[Bank for International Settlements]], the [[Financial Action Task Force]], and national regulators in the UK, EU, and Asia-Pacific.
- Its principal value proposition is convening neutral ground where competitors can agree minimum conduct standards, reducing race-to-the-bottom dynamics in [[Digital Asset Regulation]].

### Key Components

#### Codes of Conduct

- GDF's foundational output is a set of voluntary codes covering: market conduct on [[Cryptocurrency]] exchanges, [[Custody]] and safeguarding of [[Digital Asset]], token issuance best practices, and [[Anti-Money Laundering]] / [[Know Your Customer]] compliance.
- Codes are structured to be compatible with existing financial regulation, facilitating adoption by regulated entities seeking alignment with [[Regulatory Compliance]] requirements.

#### Crypto Asset Taxonomy

- GDF developed one of the first widely adopted industry taxonomies classifying crypto assets into categories (exchange tokens, utility tokens, security tokens, stablecoins), providing definitional clarity for both industry and regulators.
- This [[Crypto Asset Taxonomy]] has been referenced by the UK Financial Conduct Authority and HM Treasury in consultation papers on [[Digital Asset Regulation]].

#### Working Groups

- Specialist working groups cover: DeFi and [[Decentralised Finance]] governance, [[Stablecoin]] frameworks, [[Central Bank Digital Currency]] interoperability, [[Non-Fungible Token]] standards, and [[Environmental, Social, Governance]] in digital assets.
- Working group outputs feed into GDF's published guidance and are shared with public authorities as industry positions.

#### Policy Engagement

- GDF submits formal responses to consultations by the [[Financial Stability Board]], [[IOSCO]], UK FCA, EU Commission (MiCA implementation), and G20 Digital Economy Working Groups.
- The organisation convenes annual summits and roundtables that bring together regulators and industry practitioners, functioning as a [[Regulatory Sandbox]] for soft-law experimentation.

#### Membership & Governance

- Membership tiers include founding members, associate members, and academic affiliates; governance is handled through a board and a technical committee structure.
- Conflicts of interest are managed through a [[Self-Regulation]] governance charter that requires disclosure and recusal procedures analogous to those in traditional [[Financial Market Infrastructure]] bodies.

### Applications and Use Cases

- **Regulatory Pre-emption**: Firms use GDF codes to demonstrate responsible conduct to regulators, reducing the likelihood of prescriptive rulemaking that might constrain innovation in [[Blockchain]] applications.
- **Compliance Benchmarking**: [[Cryptocurrency]] exchanges and custodians adopt GDF codes as internal compliance benchmarks, mapping them against [[Anti-Money Laundering]] directives and [[Know Your Customer]] obligations.
- **Cross-Jurisdictional Harmonisation**: Multi-national digital asset businesses reference GDF taxonomy and codes to achieve consistent compliance posture across the UK, EU (under MiCA), Singapore MAS, and other regimes.
- **DeFi Governance**: GDF working groups on [[Decentralised Finance]] provide governance models for protocol DAOs seeking legitimacy with institutional counterparties without sacrificing decentralisation.
- **Stablecoin Frameworks**: GDF guidance on [[Stablecoin]] reserve transparency and redemption rights has been adopted by issuers seeking to meet G7 stablecoin principles ahead of formal regulation.
- **CBDC Interoperability**: GDF's work on [[Central Bank Digital Currency]] interoperability standards informs how private sector participants integrate with public money rails, bridging [[Open Finance]] and sovereign monetary systems.
- **ESG Reporting**: The ESG working group provides frameworks for reporting on the energy consumption and governance of [[Proof of Work]] and [[Proof of Stake]] networks, addressing sustainability disclosure demands.

### Standards & Regulatory Context

- **MiCA (Markets in Crypto-Assets Regulation)**: The EU's comprehensive [[Digital Asset Regulation]] framework, which GDF actively shaped through consultation submissions; GDF codes are positioned as pre-compliance tools for firms entering MiCA scope.
- **FATF Guidance on Virtual Assets**: GDF aligns its [[Anti-Money Laundering]] codes with the [[Financial Action Task Force]] Travel Rule and virtual asset service provider (VASP) definitions.
- **FSB Crypto-Asset Reporting Framework**: GDF participates in the [[Financial Stability Board]] process for cross-border crypto-asset reporting, contributing industry data and definitional frameworks.
- **UK FCA Cryptoasset Registration Regime**: GDF taxonomy and [[Know Your Customer]] guidance are referenced by firms seeking FCA registration under the UK Money Laundering Regulations.
- **ISO TC 307**: GDF liaisons with [[ISO]] Technical Committee 307 on [[Blockchain]] and [[Distributed Ledger Technology]] standards to ensure alignment between soft-law codes and formal international standards.
- **IOSCO Crypto-Asset Roadmap**: GDF submitted detailed responses to [[IOSCO]]'s crypto-asset policy recommendations, particularly on conflicts of interest in multi-function platforms and [[Custody]] segregation.
- **Basel III and Digital Assets**: GDF has engaged with the Basel Committee on Banking Supervision regarding the prudential treatment of crypto asset exposures, informing the phased capital requirements for banks holding [[Digital Asset]].

### Relationship to Decentralised Finance

- GDF occupies a distinctive position in the governance landscape by seeking to apply traditional financial conduct principles to both centralised crypto markets and emerging [[Decentralised Finance]] protocols.
- Its DeFi working group explores how concepts such as [[Market Integrity]], [[Consumer Protection]], and [[Anti-Money Laundering]] can be operationalised in systems lacking central intermediaries.
- GDF's bridging role reflects the broader tension between [[Self-Regulation]] traditions in financial services and the architectural affordances of permissionless [[Blockchain]] systems.
- The organisation's work on [[Stablecoin]] frameworks and [[Central Bank Digital Currency]] interoperability positions it as a key interface between traditional monetary systems and the emerging [[Token Economy]].

### Provenance

