A distribution strategy is the choice of how goods flow from source to customer, in particular whether they are shipped directly or pass through intermediate storage points.[^1][^2]

A Northwestern University paper defines distribution as the steps taken to move and store a product from the supplier stage to a customer stage in the supply chain, and says the performance of a distribution network should be evaluated on the customer needs that are met and the cost of meeting them.[^1] It identifies two key decisions in designing a network: whether product will be delivered to the customer location or picked up from a preordained site, and whether it will flow through an intermediary.[^1] From these it derives six designs: manufacturer storage with direct shipping, the same with in-transit merge, distributor storage with package carrier delivery, distributor storage with last mile delivery, manufacturer or distributor storage with customer pickup, and retail storage with customer pickup.[^1]

## Direct shipment and intermediate storage

McGraw-Hill/Irwin slides describe two fundamental strategies: items can be shipped directly from the supplier or manufacturer to the retail stores or end customer, or intermediate inventory storage points, typically warehouses and distribution centers, can be used.[^2] Chopra says the biggest advantage of drop shipping is the ability to centralise inventories at the manufacturer.[^1] Georgia Tech's textbook shows why intermediate storage can help: with many vendors and stores, direct shipment means many small shipments at less-than-truckload rates, while an aggregator such as a distribution center or crossdock means fewer, larger shipments.[^3]

## Scope and distinctions

Distribution strategy sits under [[Warehousing and Distribution]]. Final delivery to the customer is covered at [[Last-Mile Delivery]], and the facilities involved at [[Distribution Centre]] and [[Warehouse Facility Type]]. Network design more broadly is covered at [[Supply Chain Network Design]].

## What the sources do not establish

Sources do not say which design is best in general; Chopra frames the choice by customer and product characteristics. The slide deck is a textbook companion and gives no data.[^2]

[^1]: Northwestern University, Kellogg School of Management (Sunil Chopra), “Designing the Distribution Network in a Supply Chain”. https://transportation.northwestern.edu/docs/research/core-topics/logistics-and-supply-chain-management/Chopra_DistributionSupplyChain.pdf
[^2]: McGraw-Hill/Irwin, Chapter 7 slides (copy hosted by SUNY New Paltz), “Distribution Strategies”. https://www2.newpaltz.edu/~liush/MOIT/distribution%20strategies.pdf
[^3]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf

