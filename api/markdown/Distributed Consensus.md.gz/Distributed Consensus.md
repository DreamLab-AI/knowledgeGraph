Distributed consensus is the fundamental computer science problem of achieving reliable agreement on a shared value or sequence of values across a set of independent processes in a distributed system, despite the possibility of node crashes, network partitions, message delays, and Byzantine (arbitrarily malicious) behaviour. The problem is formalised through three core properties: agreement (all non-faulty nodes decide the same value), validity (the decided value was proposed by some participant), and termination (every non-faulty node eventually decides). The Fischer-Lynch-Paterson (FLP) impossibility theorem establishes that deterministic consensus in a fully asynchronous system is impossible even with one crash-faulty process, forcing all practical protocols to make synchrony assumptions or adopt probabilistic termination.

### Overview

- Distributed consensus sits at the heart of every system that must coordinate state across independent machines. Without it, independent replicas diverge, transaction histories conflict, and coordination collapses under failures.
- The problem was formally studied from the late 1970s onwards. Key milestones:
  - **1978** — Lamport's "Time, Clocks, and the Ordering of Events" established logical time for distributed systems.
  - **1982** — The Byzantine Generals Problem paper formalised adversarial failure models.
  - **1985** — Fischer, Lynch, Paterson proved the FLP impossibility result: deterministic consensus is impossible in a fully asynchronous system with even a single crash-fault process.
  - **1989–1998** — Paxos was designed and eventually published, providing crash-fault-tolerant consensus under partial synchrony.
  - **2009** — Nakamoto consensus (Bitcoin) demonstrated open-participation probabilistic consensus via [[Proof Of Work]].
  - **2013–2014** — [[Raft]] simplified Paxos for practical engineering; [[PBFT]]-derived protocols multiplied.
  - **2018–present** — Linear-complexity BFT protocols ([[HotStuff]], Jolteon, DiemBFT) enabled large validator sets.
- Why it matters: every distributed database, coordination service, and blockchain depends on some form of consensus to achieve correctness.

### Key Mechanisms

- **Crash Fault Tolerant (CFT) Protocols**
  - Designed for benign (crash-stop) failures only.
  - [[Paxos]]: two-phase single-decree protocol; Multi-Paxos extends to a log; requires f < n/2 failures.
  - [[Raft]]: leader-based replicated log optimised for understandability; strong leader simplifies membership changes.
  - Used in [[Distributed Database]] systems (Google Spanner, CockroachDB, etcd, ZooKeeper).
- **Byzantine Fault Tolerant (BFT) Protocols**
  - Tolerate f < n/3 arbitrarily malicious nodes.
  - [[PBFT]] (Castro & Liskov, 1999): three-phase (pre-prepare, prepare, commit); O(n²) message complexity; deterministic finality.
  - [[HotStuff]]: linear O(n) message complexity via threshold signatures; forms the basis of DiemBFT/LibraBFT.
  - [[Tendermint]]: lock-and-vote BFT used in the Cosmos ecosystem; provides instant finality.
  - Casper FFG: Ethereum's finality gadget layered over [[Proof of Stake]] block production.
- **Nakamoto-Style Probabilistic Consensus**
  - Used in [[Proof Of Work]] blockchains (Bitcoin, early Ethereum).
  - No explicit voting; nodes extend the chain with the highest cumulative work.
  - Finality is probabilistic and improves exponentially with block depth.
  - Open participation without prior identity — [[Sybil Resistance]] provided by computational expenditure.
- **Proof of Stake BFT Hybrids**
  - Validators are economically staked; equivocation is punished by slashing (economic [[Byzantine Fault Tolerance]]).
  - Examples: Ethereum's Casper + LMD-GHOST fork choice, Cosmos/Tendermint, Algorand (cryptographic sortition).
- **[[Quorum System]] Design**
  - Quorums define the minimum overlap required for safety guarantees.
  - Flexible quorum systems (FPaxos) trade availability for smaller quorums.
  - Threshold signatures and aggregate BLS signatures reduce communication overhead.
- **[[Leader Election]]**
  - Most CFT and BFT protocols elect a distinguished leader per view/epoch to drive progress.
  - Leader rotation and view-change protocols handle leader failures.
  - Rotating leaders improve liveness and censorship resistance.

### Applications and Use Cases

- **Distributed Databases and Coordination Services**
  - [[Replicated State Machine]] model underlies etcd, ZooKeeper, and Apache Kafka's KRaft mode.
  - Google Spanner uses Paxos per shard for globally consistent transactions.
  - CockroachDB uses Raft for per-range replication.
- **Blockchain Networks**
  - [[Blockchain]] is perhaps the most widely deployed application of distributed consensus at internet scale.
  - Bitcoin uses Nakamoto consensus; Ethereum transitioned to PoS BFT with The Merge (2022).
  - Enterprise blockchains (Hyperledger Fabric, Quorum) use permissioned BFT variants (PBFT, Istanbul BFT).
- **[[Distributed Ledger]] Systems**
  - Permissioned ledgers such as R3 Corda and Hyperledger Besu operate with known validator sets, allowing classical BFT.
- **Cross-Chain and Interoperability**
  - Bridge protocols must achieve consensus about the state of a foreign chain whose native consensus is not directly verifiable.
  - Light-client proofs, optimistic attestations, and zero-knowledge state proofs are active research areas here.
- **[[Federated Learning]] and AI Coordination**
  - Decentralised model aggregation protocols in federated learning systems increasingly borrow consensus primitives to detect and exclude Byzantine gradient updates.
  - [[Multi-Agent Coordination]] systems in AI research apply consensus to coordinate actions among autonomous agents without a central planner.
- **Cloud Infrastructure**
  - Lock services, service mesh control planes, and secrets managers (HashiCorp Vault) use Raft or Paxos internally.
  - Kubernetes leader election uses etcd's Raft-backed leases.

### Theoretical Foundations

- **FLP Impossibility**
  - No deterministic protocol can guarantee consensus termination in a fully asynchronous system with even one crash-fault process.
  - Practical workaround: assume partial synchrony (DLS model) or use randomised protocols.
- **[[CAP Theorem]]**
  - A consensus system that is partition-tolerant must choose between consistency and availability during a partition.
  - CFT and BFT consensus systems generally prioritise consistency (CP systems).
- **[[Atomic Broadcast]] Equivalence**
  - Distributed consensus is computationally equivalent to atomic broadcast (total-order broadcast).
  - A solution to one immediately yields a solution to the other.
- **Synchrony Models**
  - Asynchronous: no timing assumptions — FLP applies, only randomised or probabilistic protocols work.
  - Partial synchrony (DLS): messages eventually arrive within unknown-but-finite bounds — Paxos, PBFT, HotStuff work here.
  - Synchronous: known message delay bounds — simpler but impractical at internet scale.
- **Safety vs. Liveness**
  - Safety ("nothing bad happens"): no two nodes decide different values.
  - Liveness ("something good happens"): every non-faulty node eventually decides.
  - BFT protocols guarantee safety unconditionally and liveness under partial synchrony.

### Standards and Context

- No single formal standard governs distributed consensus protocols, reflecting their origins in academic research rather than standards bodies.
- [[IETF]] has produced RFCs relevant to specific protocol mechanisms (e.g., RFC 5905 for NTP synchrony, BFT-related drafts in distributed ledger working groups).
- [[IEEE]] publishes relevant research through IEEE Transactions on Parallel and Distributed Systems.
- The Hyperledger Foundation (Linux Foundation project) maintains open-source BFT consensus implementations used in enterprise settings.
- NIST has studied consensus protocols in the context of blockchain standards (NIST IR 8202, 8301).
- Academic venues: SOSP, OSDI, PODC, and DISC are the primary publication venues for new consensus protocols.
- The Ethereum Foundation maintains EIPs (Ethereum Improvement Proposals) formalising consensus-related protocol changes.

### Current Landscape (2026)

- Solana's Alpenglow (SIMD-0326) is the biggest shift in production consensus: validator governance approved it in September 2025 with 98.27% support, and its Votor voting engine replaces TowerBFT and removes Proof of History from consensus, targeting deterministic finality of roughly 100-150ms versus the previous 12.8s. It went live on Anza's community test cluster on 11 May 2026, with mainnet targeted for late Q3/early Q4 2026.
- Votor moves validator votes off-chain as lightweight messages aggregated into a ~1,000-byte BLS12-381 certificate, running concurrent fast (80% stake, one round) and slow (60% stake, two rounds) paths; this removes vote transactions that had consumed ~75% of Solana block space.
- DAG-based BFT has matured from research into the dominant high-throughput design, separating data dissemination from ordering: Sui's Mysticeti and the Narwhal/Bullshark lineage now underpin Aptos and Sui, and 2024-2025 work such as Shoal++ cut end-to-end DAG-BFT commit latency to ~4.5 message delays (a ~60% reduction over Shoal), while Mysticeti-C reached the 3-message-round latency lower bound.
- Leaderless consensus became a notable frontier through 2025-2026, with designs like Democratic BFT (DBFT), Mir-BFT and epidemic/gossip protocols (e.g. BECP, July 2025) aiming to remove the single-leader bottleneck and scale BFT across wide-area networks, complementing asynchronous DAG approaches (Mahi-Mahi, Sailfish, BBCA-CHAIN).
- Crash-fault-tolerant consensus in the datacentre remains anchored on Raft and multi-Raft (CockroachDB, TiKV, YugabyteDB), with KRaft replacing ZooKeeper as Kafka's metadata quorum; 2024-2025 refinements include CFT-Forensics (Byzantine accountability layered onto Raft/multi-Paxos) and streamlined Mencius/MultiPaxos reimplementations.
- Standardisation and supervisory attention grew: the IMF published a 2025 update to its "Blockchain Consensus Mechanisms: A Primer for Supervisors" (September 2025), reflecting regulatory interest in how proof-of-stake and BFT finality underpin financial-market infrastructure.
- Open challenges as of 2026 include closing the latency-throughput gap in asynchronous DAG-BFT, MEV-resistance in DAG total-ordering (e.g. Aptos and Chainlink's Fino), formally verifying newer leaderless protocols at production scale, and validating claimed finality figures (Alpenglow's 100-150ms remains simulation-based pending mainnet p50/p99 measurement).

### References

- 1. Anza (2025). Alpenglow: A New Consensus for Solana. https://www.anza.xyz/blog/alpenglow-a-new-consensus-for-solana
- 2. Chainstack (2026). Solana: Alpenglow consensus explained. https://docs.chainstack.com/docs/solana-alpenglow-consensus
- 3. Solana Foundation (2025). SIMD-0326: Alpenglow. https://github.com/solana-foundation/solana-improvement-documents/blob/main/proposals/0326-alpenglow.md
- 4. Gelashvili, R. et al. (2025). Shoal++: High Throughput DAG BFT Can Be Fast! https://arxiv.org/pdf/2405.20488.pdf
- 5. Wu, H. et al. (2025). Half a Century of Distributed Byzantine Fault-Tolerant Consensus: Design Principles and Evolutionary Pathways. https://arxiv.org/html/2407.19863v3
- 6. Bains, P. / IMF (2025). Blockchain Consensus Mechanisms: A Primer for Supervisors (2025 Update). https://www.imf.org/-/media/files/publications/wp/2025/english/wpiea2025186-source-pdf.pdf

### Provenance

