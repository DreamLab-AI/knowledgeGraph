A circular supply chain is a supply chain organised so that products and materials are kept in use and returned to the economy, in contrast to a linear chain that ends in waste, and no source opened here defines the term itself.[^1]

The Ellen MacArthur Foundation describes the circular economy as a system where materials never become waste and nature is regenerated, and says that in it products and materials are kept in circulation through maintenance, reuse, refurbishment, remanufacture, recycling and composting.[^1] It contrasts this with the current linear economy, in which we take materials from the Earth, make products from them and eventually throw them away as waste.[^1]

## Supply chain terms

De Brito and Dekker note that the term closed-loop supply chain was introduced because forward and reverse logistics melt into each other, and that it puts recovery practices in the frame of supply chain management.[^2] Their paper's main subject is [[Reverse Logistics]], the flow back from users, which is one part of a circular chain.

## Instruments

The EU's waste electrical and electronic equipment directive requires systems allowing final holders and distributors to return waste at least free of charge, and requires producers to finance the collection, treatment, recovery and environmentally sound disposal of household waste deposited at collection facilities.[^3] See [[Product Take-Back Scheme]]. Deposit schemes for drinks containers work by refunding a deposit on return and are described at [[Deposit Return Scheme]].

Cradle to Cradle certification is based on a design framework in which everything can be designed to be disassembled and safely returned to the soil as biological nutrients, or re-utilised as high quality materials for new products as technical nutrients.[^4] The design side is at [[Cradle-to-Cradle Design]], and material accounting at [[Material Flow Analysis]].

## What the sources do not establish

None of the sources measures how circular a supply chain is, or says how far a chain can close its loops. The Foundation is an advocacy body, the certifier's document is a marketing overview of its own standard, and the directive describes obligations in law and not outcomes.

[^1]: Ellen MacArthur Foundation, “The Circular Economy: Definition & Model Explained”. https://www.ellenmacarthurfoundation.org/topics/circular-economy-introduction/overview
[^2]: Marisa P. de Brito and Rommert Dekker, Econometric Institute Report EI 2002-38, Erasmus University Rotterdam, 2002, “Reverse Logistics – a framework”. https://repub.eur.nl/pub/543/feweco20021018095304.pdf
[^3]: European Parliament and Council of the European Union, Directive 2012/19/EU of 4 July 2012, “Directive 2012/19/EU of the European Parliament and of the Council on waste electrical and electronic equipment (WEEE)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32012L0019
[^4]: MBDC (McDonough Braungart Design Chemistry), overview document, “Cradle to Cradle Certified: The Product Quality Standard for the Circular Economy”. https://mbdc.com/wp-content/uploads/C2C-Certified-Product-Standard_v3.1_compiled.pdf

