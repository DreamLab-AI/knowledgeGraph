Point cloud processing is the body of computational algorithms and end-to-end pipelines that transform raw collections of georeferenced 3D coordinate samples — produced by LiDAR scanners, depth cameras, structured-light systems, or photogrammetric reconstruction — into structured, semantically meaningful representations suitable for downstream applications such as autonomous navigation, digital twin construction, heritage documentation, and environmental monitoring. Core operations include noise filtering, voxel downsampling, multi-scan registration via Iterative Closest Point (ICP) and feature-based variants, normal estimation, segmentation, surface reconstruction, and compression. These operations are increasingly augmented by deep learning models operating directly on unordered point sets (PointNet family, sparse 3D CNNs), often executed on GPU-accelerated or specialised embedded hardware to meet real-time constraints. The field bridges classical computational geometry with modern neural scene representations such as NeRF and 3D Gaussian Splatting.

### Overview

- Point cloud processing became a distinct engineering discipline with the commercial availability of terrestrial LiDAR scanners in the early 2000s, and accelerated sharply with the integration of LiDAR into autonomous vehicle development after 2010.
- A point cloud is an unordered, irregular set of (x, y, z) samples — often augmented with intensity, colour (RGB), or return-time attributes — that collectively describe the surface geometry of a scanned environment or object.
- Unlike voxel grids or meshes, point clouds preserve raw sensor fidelity and scale to billions of points, making efficient processing a non-trivial computational challenge.
- The open-source [[Point Cloud Library]] (PCL, launched 2011) provided the canonical algorithmic toolkit: filtering, normal estimation, keypoint detection, feature description, registration, segmentation, and surface reconstruction. PCL remains the reference implementation for many classical algorithms.
- From 2017 onwards, deep learning methods operating directly on unordered point sets (PointNet, PointNet++, VoxelNet, PointPillars) transformed the field, achieving state-of-the-art results on semantic segmentation and 3D object detection benchmarks without requiring conversion to volumetric grids.
- As of 2024–2025, GPU-accelerated real-time processing, neural scene representations, and edge-deployable LiDAR chips with integrated [[Simultaneous Localisation and Mapping]] have further expanded the field's reach.

### Key Components

#### Acquisition

- [[Lidar Scanning]] — time-of-flight or phase-shift laser measurement producing dense, precise point sets; spinning mechanical units (Velodyne HDL-64E being historically canonical) and solid-state units (Livox, Ouster, Hesai) vary in density and scan pattern.
- [[Depth Sensing]] — structured-light (Intel RealSense, Azure Kinect) and stereo cameras produce dense, colour-registered point clouds at shorter ranges.
- [[Photogrammetry]] — multi-image structure-from-motion (SfM) and multi-view stereo (MVS) pipelines (COLMAP, RealityCapture) generate dense point clouds from photographs.
- Mobile mapping systems combine GPS/IMU with LiDAR for large-scale outdoor capture at vehicle speed.

#### Pre-processing and Filtering

- Statistical Outlier Removal (SOR) — identifies and removes points whose mean distance to k nearest neighbours deviates from the global mean by more than a configurable standard deviation threshold.
- Radius Outlier Removal — removes isolated points with fewer than a minimum number of neighbours within a given radius.
- Voxel Grid Downsampling — approximates a point cloud with a single centroid per voxel cell, dramatically reducing point count while preserving shape.
- Pass-through filtering — clips points outside axis-aligned bounding regions of interest.

#### [[Spatial Data Structure]]s

- [[Octree]] — recursive axis-aligned subdivision enabling efficient spatial queries, compression, and streaming of large clouds.
- k-d Tree — binary space partitioning tree optimised for nearest-neighbour and radius searches; the backbone of most PCL algorithms.
- [[Voxel Grid]] — regular 3D lattice enabling fast occupancy queries and deep learning feature extraction (sparse convolution).
- Range image — cylindrical or spherical 2D projection of a point cloud enabling image-based CNN processing (RangeNet++, SalsaNext).

#### Registration

- [[Iterative Closest Point]] (ICP) — iteratively minimises point-to-point or point-to-plane distance between overlapping scans to find the optimal rigid transformation; computationally simple but sensitive to initial alignment and outliers.
- Feature-based registration (FPFH, SHOT, FPCS, TEASER++) — detects geometric keypoints, extracts local descriptors, and solves the correspondence problem robustly before refining with ICP.
- Continuous-time SLAM — tightly integrates IMU pre-integration with scan matching for distortion-corrected, high-frequency pose estimation (LIO-SAM, FAST-LIO2).

#### [[Normal Estimation]]

- Covariance Analysis — PCA over local k-NN neighbourhood; eigenvector corresponding to smallest eigenvalue is the normal. Orientation consistency is enforced via viewpoint or propagation.
- Normals are prerequisite for Poisson surface reconstruction, curvature-based features, and many deep learning architectures.

#### [[Point Cloud Segmentation]]

- Plane segmentation via RANSAC — robustly fits planes (ground, walls, ceilings) to point subsets; iterative with outlier rejection.
- Euclidean Clustering — groups points within a Euclidean distance threshold into object hypotheses.
- Region Growing — expands seed regions based on normal angle and curvature similarity.
- Deep Semantic Segmentation — PointNet++, MinkowskiEngine, and Cylinder3D assign per-point semantic labels end-to-end.

#### [[Surface Reconstruction]]

- Poisson Surface Reconstruction — fits a smooth, watertight implicit surface to oriented point normals; excellent for organic shapes.
- Greedy Projection Triangulation — locally connects points into a mesh without global optimisation; faster but noisier.
- Ball-Pivoting Algorithm (BPA) — rolls a sphere of specified radius over the point cloud to generate triangle mesh edges.

#### Deep Learning on Point Clouds

- PointNet — the seminal architecture (Qi et al., 2017) using shared MLP layers and max-pooling to achieve permutation-invariant global feature extraction.
- PointNet++ — hierarchical abstraction via set abstraction layers with local neighbourhood grouping.
- Sparse 3D CNNs (MinkowskiEngine, spconv) — apply convolutions only at occupied voxels, enabling efficient processing of large outdoor scans.
- PointPillars, VoxelNet — pillar/voxel encoders followed by 2D CNNs optimised for real-time autonomous driving inference.
- Point Transformer, 3DETR — transformer-based architectures with attention over point neighbourhoods.

### Applications

#### Autonomous Vehicles

- Real-time 3D object detection, tracking, and velocity estimation from spinning LiDAR operating at 10–20 Hz.
- Free-space estimation and drivable surface segmentation.
- High-definition (HD) map construction by accumulating registered point clouds of road geometry.
- [[Autonomous Vehicle Perception]] fuses LiDAR point clouds with camera images for robust multi-modal detection.

#### Robotics

- [[Simultaneous Localisation and Mapping]] (SLAM) — mobile robots build and localise within 3D maps using scan-matching.
- Robotic grasping — pose estimation and collision-free motion planning from object point clouds.
- Inspection drones use real-time SLAM on edge devices to navigate GPS-denied environments.
- [[Robotics Perception]] systems pipeline point clouds through segmentation and classification for manipulation tasks.

#### [[Digital Twin]] and BIM

- [[Building Information Modelling]] (BIM) workflows use terrestrial LiDAR to capture as-built conditions; processing pipelines extract planar elements, openings, and MEP routes.
- Infrastructure inspection (bridges, tunnels, pipelines) uses point cloud differencing to detect deformation and damage over time.
- Urban digital twins fuse airborne LiDAR with photogrammetric meshes for city-scale representations.

#### Heritage and Cultural Documentation

- Millimetre-resolution scanning of archaeological sites, statues, and historical buildings creates permanent digital archives.
- Processing pipelines produce textured meshes for museum VR experiences and restoration planning.

#### Geospatial and Environmental

- Airborne LiDAR (ALS) surveys measure canopy height, biomass estimation, and terrain under dense vegetation (ground filtering by progressive morphological filter).
- Bathymetric LiDAR measures underwater topography for coastal management.
- [[Geospatial Data]] products derived from processed point clouds underpin national mapping programmes and climate monitoring.

#### Extended Reality

- Spatial anchoring for [[Spatial Computing]] headsets (Apple Vision Pro, HoloLens) uses room-scale point clouds to anchor virtual content to physical geometry.
- [[3D Gaussian Splatting]] and [[NeRF]] workflows initialise neural scene representations from LiDAR-seeded point clouds, bridging scan capture to photorealistic real-time rendering.

### Standards & Context

- **LAS/LAZ format** — the de facto standard for LiDAR point cloud interchange (ASPRS LAS Specification), supporting point record formats with intensity, RGB, classification, and return number. LAZ is the lossless compressed variant widely used for archival.
- **E57 format** — ASTM E57 standard for 3D imaging data interchange, supporting multiple scan positions and imagery, used heavily in terrestrial scanning for BIM workflows.
- **Open3D** — modern open-source library (Intel Labs) providing Python and C++ APIs for geometry processing and deep learning on point clouds; complements PCL.
- **PCL (Point Cloud Library)** — BSD-licensed C++ library; the foundational reference for classical algorithms; maintained community project since 2011.
- **ROS/ROS2** — the Robot Operating System de facto middleware for point cloud message passing (sensor\_msgs/PointCloud2), visualisation (RViz), and algorithm integration in robotics.
- **ISO 19157** (Data Quality for Geographic Information) applies to geospatial point cloud products regarding positional accuracy reporting.
- **OGC standards** — the Open Geospatial Consortium's CityGML and 3D Tiles specifications support tiled streaming of large point cloud datasets for web visualisation (Cesium, Potree).
- The autonomous driving sector is converging on the **nuScenes**, **KITTI**, and **Waymo Open Dataset** benchmarks for LiDAR perception evaluation, driving algorithm development.

### Provenance

