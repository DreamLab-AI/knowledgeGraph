A query engine is the software component that parses, plans, optimises, and executes declarative queries against one or more data stores, returning result sets to callers. It transforms a high-level query into an efficient physical execution plan using statistics, indexes, and cost models, and may operate over a single database, a data warehouse, or federated sources, forming the computational core of database and analytics systems.

- A [[Query Engine]] parses, plans, optimises, and executes declarative queries against data stores. It uses [[SQL]] and [[Columnar Storage]], relies on [[Indexing]], and is the computational core of a [[Database System]].

### Overview

- The query engine turns what users want into how the system gets it. A declarative query specifies the desired result, and the engine chooses an efficient physical plan, weighing scan strategies, join orders, and access methods.
- Cost-based optimisation uses statistics and available indexes to estimate plan cost and select the cheapest viable plan, which is decisive for performance at scale.

### Mechanisms

- Parsing and binding turn query text into a validated logical representation.
- The optimiser rewrites the logical plan and selects a physical plan using cost models and statistics.
- The execution layer runs operators such as scans, joins, aggregations, and sorts, often in parallel.
- [[Indexing]] and [[Columnar Storage]] accelerate access for selective and analytical workloads respectively.

### Applications

- Transactional [[Database System]] query processing for applications.
- Analytical querying over a [[Data Warehouse]] for [[OLAP]] reporting.
- Federated and search workloads exposing [[Full-Text Search]].

### Provenance

