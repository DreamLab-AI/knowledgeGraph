A Layer 1 Blockchain is a base-layer distributed ledger that provides its own consensus, settlement and security without relying on another chain. It defines the native protocol, block production rules and economic security that applications and higher layers build upon, and is where transactions achieve final settlement. Examples include Bitcoin, Ethereum, Avalanche and Cardano. Layer 1 design choices around consensus and data structures determine the throughput, decentralisation and security trade-offs that Layer 2 solutions later seek to extend.

### Overview

- The term contrasts the base protocol (Layer 1) with off-chain or secondary protocols (Layer 2) that inherit security from it.
- Layer 1 owns the canonical state and ordering of transactions, secured by economic incentives and a consensus protocol.
- Because every full node validates Layer 1 transactions, raw on-chain throughput is bounded, motivating the blockchain trilemma framing of security, decentralisation and scalability.
- Some Layer 1 chains pursue on-chain scaling (e.g. [[Sharding]] or high-throughput consensus), while others delegate scaling to Layer 2.
- The native token typically pays transaction fees and secures the network through staking or mining.

### Key aspects

- Native consensus: the chain runs its own [[Proof of Stake]] or [[Proof of Work]] (or other) consensus rather than borrowing security.
- Final settlement: transactions confirmed at Layer 1 are the source of truth for all dependent systems.
- Economic security: validators or miners are rewarded for honest participation and penalised for misbehaviour.
- Execution environment: programmable Layer 1 chains expose a virtual machine for [[Smart Contract]] deployment.
- Scalability strategy: choices between monolithic and modular designs shape how the chain grows.

### Applications

- Hosting decentralised applications, tokens and DeFi protocols at the settlement layer.
- Anchoring [[Layer 2 Scaling]] rollups and channels that post proofs or data back to Layer 1.
- Providing the security base for cross-chain and interoperability protocols.
- Serving as the trust root for digital assets and on-chain identity.

### Provenance

