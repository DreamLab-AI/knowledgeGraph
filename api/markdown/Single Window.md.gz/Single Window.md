A single window is a facility that allows parties involved in trade and transport to lodge standardised information and documents at a single entry point to fulfil all import, export and transit-related regulatory requirements, with each data element submitted only once electronically; this is the definition of UN/CEFACT Recommendation No. 33.[^1]

The Cross-Border Paperless Trade Database describes the Recommendation as setting out key principles for single window systems and explaining how information flows between trade and transport parties and regulatory agencies, while promoting a single submission point to avoid repeated data entry.[^2] The 2020 edition says a National Single Window lets a trader submit all trade declarations and relevant information to the various authorities for processing and approval only once, in a single data format.[^1] The entry point may be run by one of the participating agencies or by an independent body, public, private or both.[^1]

## In trade law

The WTO Agreement on Trade Facilitation includes a single window provision. Members shall endeavour to establish or maintain a single window enabling traders to submit documentation and data requirements for importation, exportation or transit through a single entry point to the participating authorities or agencies.[^3] Once information has been received through the single window, the same requirements may not be requested again by participating authorities except in urgent circumstances and other limited exceptions that are made public.[^3] The wording is an endeavour, not an unconditional obligation.[^3] The WCO links its Data Model to the potential of a single window.[^4] The WCO SAFE Framework names cooperation between customs and other government agencies through a single window as one of its objectives; see [[WCO SAFE Framework]].[^5]

## Scope and distinctions

A single window is a form of [[Trade Facilitation]]. The term is used loosely. A UNECE and UN/CEFACT technical note says it has at times been used to describe various mechanisms and computer systems, which has caused confusion among stakeholders and users.[^6] The page therefore uses the Recommendation 33 definition and does not treat every national port or customs system as a single window.[^1][^6]

## What the sources do not establish

No opened source says how many countries operate a single window, how well any of them performs, or which agencies take part in a given country. The Recommendation 33 PDF on unece.org returned an error, so the 2020 text was read in a copy hosted by a third party and checked against the database summary.

[^1]: United Nations Economic Commission for Europe, “Recommendation and Guidelines on Establishing a Single Window To Enhance the Efficient Exchange of International Trade Information Between Trade and Government” (Recommendation No. 33, 2020 edition, copy hosted by mpoverello.com). https://mpoverello.com/wp-content/uploads/2020/10/un_special_recommendation_33_guidelines_for_single_window_1601652333.pdf
[^2]: Cross-Border Paperless Trade Database, “Recommendation and Guidelines on establishing a Single Window (Recommendation No. 33) (UNECE and UN/CEFACT)”. https://www.digitalizetrade.org/legal-instrument/recommendation-and-guidelines-establishing-single-window-recommendation-no-33
[^3]: World Trade Organization, “Agreement on Trade Facilitation”. https://www.wto.org/english/docs_e/legal_e/tfa-nov14_e.htm
[^4]: World Customs Organization, Procedures and Facilitation overview page. https://www.wcoomd.org/en/topics/facilitation/overview.aspx
[^5]: World Customs Organization, “SAFE Framework of Standards 2021”. https://www.wcoomd.org/-/media/wco/public/global/pdf/topics/facilitation/instruments-and-tools/tools/safe-package/safe-framework-of-standards.pdf
[^6]: UNECE and UN/CEFACT, technical note on terminology for Single Window and other ePlatforms. https://digitalizetrade.org/files/legal/documents/WP-TechNoteSWTerminology_Eng.pdf

