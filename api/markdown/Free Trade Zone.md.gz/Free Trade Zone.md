A free trade zone is an area where goods that are brought in are generally regarded, as far as import duties and taxes go, as outside the customs territory; the Revised Kyoto Convention calls it a free zone, and the United States calls the equivalent a foreign-trade zone.[^1][^2]

The World Customs Organization (WCO) defines a free zone as a part of the territory of a Contracting Party where any goods introduced are generally regarded, insofar as import duties and taxes are concerned, as being outside the customs territory.[^1] The wording ties the special status to the goods and to duties and taxes. The zone itself remains part of the state's territory.[^1] The Convention leaves the requirements for establishing zones, the kinds of goods admitted and the operations allowed to national legislation.[^1]

## European Union

Under the Union Customs Code, Member States may designate parts of the customs territory of the Union as free zones. For each one the Member State determines the area covered and defines the entry and exit points.[^3] Free zones must be enclosed, their perimeter and entry and exit points are under customs supervision, and persons, goods and means of transport entering or leaving may be subject to customs controls.[^3] Any industrial, commercial or service activity is permitted in a free zone subject to the customs legislation and to advance notification to the customs authorities.[^3] The Code groups customs warehousing and free zones together as storage procedures, and no limit applies to how long goods may remain under a storage procedure.[^3] A recital says that, in view of increased security-related measures, placing goods into free zones should become a customs procedure and the goods should be subject to customs controls at entry and with regard to records.[^3]

## United States

The US International Trade Administration describes foreign-trade zones as designated sites licensed by the Foreign-Trade Zones Board at which special customs procedures may be used.[^2] Duty-free treatment is accorded to items that are re-exported, and duty payment is deferred on items sold in the US market.[^2] A formal customs entry with duty payment is made only when merchandise is shipped from the zone to the US market.[^2] A site with zone status cannot be used for zone activity until US Customs and Border Protection has separately approved it, and the activity stays under its supervision.[^2]

## Scope and distinctions

A free zone is related to a [[Bonded Warehouse]], known in the EU as a customs warehouse. The Union Customs Code treats customs warehousing and free zones as parallel storage procedures.[^3] Duty treatment is covered at [[Customs Duty]].

## What the sources do not establish

No opened source gives the number of zones worldwide, their economic effects or the rules of jurisdictions other than the EU and the US. Terminology differs between sources, and the page reports each in its own words.

[^1]: World Customs Organization, Revised Kyoto Convention Specific Annex D, Chapter 2 on free zones. https://www.wcoomd.org/en/topics/facilitation/instrument-and-tools/conventions/pf_revised_kyoto_conv/kyoto_new/spand.aspx
[^2]: International Trade Administration (US Department of Commerce), “About FTZs”. https://www.trade.gov/index.php/about-ftzs
[^3]: European Union, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952

