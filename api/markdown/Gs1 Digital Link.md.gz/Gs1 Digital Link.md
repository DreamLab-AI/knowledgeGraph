GS1 Digital Link is a standard that expresses GS1 identifiers, such as the Global Trade Item Number, as web URIs so that a single QR code or data carrier can connect a physical product to multiple online resources. A resolver service interprets the URI and routes requests to information such as product details, instructions, provenance, or recycling guidance. It bridges traditional barcodes with the web and semantic data.

### Overview

- Conventional GS1 barcodes encode an identifier intended primarily for point-of-sale scanning. GS1 Digital Link reframes that identifier as a structured, web-addressable URI, so that scanning a product can open a webpage rather than just registering a number. A conformant resolver examines the link type requested and returns the appropriate resource, allowing one code to serve consumers, regulators, and supply-chain systems simultaneously. This makes products first-class participants in the web and in linked-data ecosystems.

### Mechanisms

- Encodes GS1 identifiers as structured HTTP URIs.
- A resolver maps link types to target resources.
- A single carrier can serve many use cases and audiences.
- Compatible with QR codes and other two-dimensional carriers.
- Aligns product data with web and semantic-web conventions.

### Applications

- Consumer engagement and product information pages.
- Provenance and authenticity verification.
- Recycling and circular-economy guidance.
- Regulatory and safety information delivery.
- Connecting physical products to linked-data services.

### Provenance

