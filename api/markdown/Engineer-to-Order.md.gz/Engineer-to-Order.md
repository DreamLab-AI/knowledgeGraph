Engineer-to-order is a production strategy in which the product is designed to the customer's requirements after the order is placed, so engineering as well as manufacturing is triggered by the order.[^1][^2]

A Newcastle University engineering page describes the capital goods sector this way: individual products are usually highly customised to meet individual customer requirements and are produced in very low volumes. It names turbine generators, boilers and switch gear for the power industry, and oil rigs for the offshore industry, as examples.[^1] It says engineer-to-order supply involves a non-physical stage, including engineering design and process planning, and a physical stage covering component manufacturing, assembly and installation.[^1]

In the customer order decoupling point frame, engineer to order is the position furthest from stock: a review says engineering and purchasing start only once an order arrives, so delivery lead time, product specificity and the work after ordering differ widely from make-to-stock.[^3] See [[Production Strategy]].

## Sources differ on scope

The Newcastle page includes the physical manufacture of the product.[^1] The abstract of a University of Hertfordshire chapter treats engineer-to-order as basically a product development process that starts with a product specification and finishes with an engineering design, and says it rarely includes manufacturing processes. Its main drawback is a long lead time.[^2] The two descriptions are compatible if the second is read as the engineering stage of the first, but neither source says so. This page uses the broader reading, which is the one the Newcastle capital goods examples need.[^1]

## In practice

At Newcastle, suppliers typically interact with customers in two stages: a tendering stage, with preliminary conceptual design and definition of major components, and contract execution, with the overall project plan, detailed design, procurement, manufacturing, assembly, construction and commissioning.[^1] Components are produced using a range of jobbing, batch, flow and assembly processes, and price and delivery performance are generally the main order winning criteria.[^1] See also [[Make-to-Order]] and [[Job Shop Production]].

## What the sources do not establish

Evidence is small: one university page about a regional capital goods cluster and one abstract. Neither gives data on how widespread the strategy is.

[^1]: Newcastle University, Department of Mechanical, Materials and Manufacturing Engineering (Dr Christian Hicks), “Make to Order / Engineer to Order Companies”. https://www.staff.ncl.ac.uk/chris.hicks/make_to_order.htm
[^2]: Richard Addo-Tenkorang and Ephrem Eyob, University of Hertfordshire research record (abstract only), “Engineer-to-order: A maturity concurrent engineering best practice in improving supply chains”. https://researchprofiles.herts.ac.uk/en/publications/engineer-to-order-a-maturity-concurrent-engineering-best-practice/
[^3]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

