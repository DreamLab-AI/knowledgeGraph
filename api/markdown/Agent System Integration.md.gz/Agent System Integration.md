
An agent system integration is a declaration of the dependencies and interfaces an agent needs in order to run at operating-system level, declared as `SystemIntegration` in the agent module of the Agent Ontology.[^1] visionGraph places it under [[System Integration]].

An [[Agent]] reaches it through `systemIntegrationAndDependencies`. Two properties then describe it. `dependsOn` relates it to the [[Agent Entity]] things it relies on, and `interface` relates it to one or more [[Agent Interface Specification]] instances.

The class is a specific use of the more general idea of [[System Integration]]: here the integration is a structured record attached to a particular agent, not a software engineering practice in general. It lets a deployment check, before an agent starts, that everything it needs is present and that its interfaces are described.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

