
A ledger event is the canonical semantic event in an append-only ledger stream, declared in the Agent Ontology as `LedgerEvent`.[^1] It has two declared subclasses, the [[Runtime Ledger Event]] and the [[Governance Ledger Event]]. visionGraph places it under [[Event]] and as a part of a [[Ledger]].

The class carries the integrity machinery of the ledger. `previousEventHash` holds the hash of the preceding event in the chain, and `appendOnly` is a boolean that "enforces append-only semantics; always true". Each event also has an `eventId`, a `timestamp`, a `hash`, a `signature`, a `publicKey`, a `proofType` and a `verifiedBy` string naming an external verifier or attestation provider.

Two object properties tie an event to the agent world: `actor`, the agent or principal responsible, and `delegation`, the delegation authorising the event (see [[Agent Delegation]]). The property `accountabilityRecord` connects an event to an [[Accountability Event]], and the string properties `aiActSection` and `riskClassification` annotate it for regulatory purposes. For the container concept see [[Ledger]].

[^1]: Semantic Agent Communication Community Group, “Ledger Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/ledger.ttl

