KQML, the Knowledge Query and Manipulation Language, is an early agent communication language and protocol for exchanging information and knowledge among software agents. It defines a set of performatives, message types grounded in speech-act theory, that express the intent of a communication such as ask, tell, subscribe or achieve. KQML influenced later standards including the FIPA Agent Communication Language.

### Overview

- KQML emerged from the United States DARPA Knowledge Sharing Effort as a language and protocol for knowledge-level communication between agents. A KQML message wraps content in a performative that names the communicative act, together with parameters specifying sender, receiver, content language and ontology. By separating the intent layer from the content language, KQML let heterogeneous agents interoperate, and its design directly shaped the later FIPA Agent Communication Language.

### Key aspects

- Performatives grounded in speech-act theory
- Separation of communicative intent from content language
- Parameters for sender, receiver, ontology and language
- Facilitator agents for matchmaking and brokering
- Direct ancestor of the FIPA ACL standard

### Mechanisms

- Performatives grounded in speech-act theory
- Separation of communicative intent from content language
- Parameters for sender, receiver, ontology and language

### Applications

- Knowledge sharing between heterogeneous agents
- Distributed artificial intelligence research systems
- Brokering and matchmaking via facilitator agents
- Foundations for later agent communication standards
- Interoperable multi-agent system prototypes

### Provenance

