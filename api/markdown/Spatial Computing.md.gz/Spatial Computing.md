Spatial computing is a computing paradigm in which digital information, computation, and interaction are anchored to and organised within three-dimensional physical or virtual space, enabling humans and machines to engage with data as if it inhabits the real world. It integrates continuous spatial sensing — through depth cameras, LiDAR, inertial measurement units, and computer vision — with real-time 3D rendering and multi-modal input (gaze, gesture, voice, touch) to create systems that perceive, reason about, and respond to the user's physical environment. The paradigm subsumes augmented reality, mixed reality, virtual reality, and autonomous spatial agents, unifying them under a common architectural requirement: the continuous, low-latency alignment of digital representations with physical geometry.

### Overview

- Spatial computing marks a transition from the two-dimensional, screen-and-pointer paradigm of classical desktop computing to an interaction model where the user's body, gaze, and physical surroundings serve as the primary interface.
- Where [[Ambient Computing]] embeds computation invisibly into the environment and [[Pervasive Computing]] distributes computation across networked devices, spatial computing adds the layer of explicit three-dimensional geometry: the system must build and maintain a model of space and position digital content within it.
- The paradigm places heavy demands on the entire hardware stack: [[GPU Computing]] for per-frame rendering at high frame rates, silicon with dedicated neural processing for on-device [[Computer Vision]], display optics that achieve accurate vergence and focus cues, and IMU-based tracking pipelines that must keep motion-to-photon latency below approximately 20 milliseconds to prevent perceptual discomfort.
- The term gained mainstream currency following Apple's introduction of Apple Vision Pro (January 2024), which Apple explicitly described as "the first spatial computer," cementing the paradigm label across the industry.

### Key Components

#### Sensing and Tracking

- [[Simultaneous Localisation and Mapping]] (SLAM) constructs a metric map of the environment from camera and IMU data while simultaneously localising the device within that map — the foundational perception primitive for all spatial computing platforms.
- [[Depth Sensing]] — via structured light, time-of-flight, or stereo cameras — provides dense per-pixel distance measurements that enable surface reconstruction, occlusion handling, and safe physics simulation.
- [[Sensor Fusion]] combines data from inertial measurement units, optical cameras, depth sensors, and (where available) GPS or ultrawideband beacons to produce stable, drift-corrected pose estimates at the rates required for comfortable interaction.
- [[6DoF Tracking]] (six degrees of freedom) captures full translational and rotational motion of the head and hands, enabling users to move freely through space without motion sickness artefacts introduced by positional drift.

#### Rendering and Display

- [[Real-Time Rendering]] at 60–120 frames per second is required for comfortable use; [[Head-Mounted Display]] devices with high pixel density, wide field of view, and low persistence reduce motion blur and improve visual fidelity.
- Techniques such as foveated rendering — exploiting [[Eye Tracking]] data to render the gaze centre at full resolution while reducing resolution in the periphery — reduce [[GPU Computing]] load without perceptible quality loss.
- Correct occlusion of virtual objects by real surfaces requires accurate depth meshes and per-pixel compositing, tasks handled by dedicated render passes in engines such as Unity and Unreal.
- [[Display Technology]] advances — micro-OLED, microLED, and pancake lens optics — drive down device size and weight while expanding the field of view, directly shaping user adoption curves.

#### Interaction

- [[Hand Tracking]] via neural network inference on fisheye camera streams eliminates the need for handheld controllers on fully featured spatial devices, enabling natural dexterous manipulation of virtual objects.
- [[Eye Tracking]] enables gaze-directed selection, foveated rendering, and social cue communication in collaborative experiences.
- [[Gesture Recognition]] interprets hand shapes and motion trajectories as discrete commands, bridging the gap between dexterous manipulation and high-level UI actions.
- [[Haptic Feedback]] devices — including controller rumble, gloves with pneumatic actuators, and ultrasound-based mid-air haptics — close the sensorimotor loop by providing tactile confirmation of virtual interactions.

### Applications and Use Cases

#### Industrial and Enterprise

- [[Digital Twin]] overlays on physical assets allow maintenance technicians to visualise internal structure, historical sensor data, and step-by-step repair procedures in situ, reducing mean time to repair and error rates.
- Manufacturing assembly guidance layers instruction cards onto physical work surfaces, eliminating the need to consult paper manuals and reducing training time for complex multi-step procedures.
- Field service applications deliver remote expert guidance: an on-site technician's view is streamed to a remote expert who annotates the feed with AR arrows and labels visible in the technician's [[Head-Mounted Display]].

#### Healthcare and Life Sciences

- Surgical navigation overlays pre-operative imaging (CT, MRI) onto the patient during procedures, improving spatial accuracy for tumour resection, orthopaedic implant placement, and vascular surgery.
- Medical training platforms allow students to practise anatomy, clinical examination, and procedural skills in photorealistic [[Virtual Reality]] simulations with objective performance metrics.
- Rehabilitation applications use spatial computing to guide movement therapy, gamifying exercise protocols and providing biofeedback aligned to physical gestures.

#### Architecture, Engineering, and Construction

- [[Augmented Reality]] site overlays project building information model (BIM) data at 1:1 scale onto construction sites, enabling clash detection and progress verification against design intent.
- Design review in [[Virtual Reality]] allows stakeholders to walk through a building at full scale before construction begins, catching spatial conflicts that are invisible in two-dimensional drawings.

#### Consumer and Creative

- Gaming and interactive entertainment represent the highest-volume consumer use case, with platform ecosystems anchored to [[Virtual Reality]] and [[Mixed Reality]] headsets from Meta, Sony, and Apple.
- Spatial audio systems combined with head-tracked visual rendering create convincing environmental presence; [[Geospatial Technology]] enables outdoor AR experiences anchored to real-world coordinates.
- Education and museum installations use spatial computing to present historical reconstructions, scientific simulations, and cultural artefacts at scales and with interactivity impossible in physical displays.

### Standards and Ecosystem

- [[OpenXR]] (Khronos Group, 1.0 released 2019; 1.1 in 2024) provides a cross-vendor, royalty-free API that abstracts over device-specific runtimes, enabling a single codebase to target headsets from Meta, Microsoft, Varjo, Sony, and others. It is the primary standardisation vector reducing fragmentation in the spatial computing software stack.
- [[WebXR]] (W3C, candidate recommendation) extends the open web platform to immersive experiences, enabling spatial applications that run in-browser without native installation, expanding the addressable audience and lowering distribution friction.
- [[Khronos Group]] also maintains glTF (GL Transmission Format), the de facto standard for real-time 3D asset interchange across spatial computing pipelines — addressing the content interoperability gap between authoring tools and runtime environments.
- Platform interoperability for multi-user spatial experiences remains an open problem; the Metaverse Standards Forum and IETF/W3C working groups are developing shared anchoring, identity, and avatar interchange specifications.
- Privacy regulation — particularly the collection of biometric data (gaze, hand geometry, face geometry) inherent to spatial sensing — is an active regulatory concern in the EU (AI Act, GDPR), UK, and US state-level frameworks.

### Architectural Stack

- The canonical spatial computing stack layers hardware (optics, display, compute SoC, sensors) beneath a spatial OS (spatial scene graph, anchor management, session lifecycle) that exposes runtimes to developer APIs ([[OpenXR]], [[WebXR]], ARKit, ARCore), above which application frameworks (Unity, Unreal, web-based) host end-user experiences.
- Edge and cloud offload architectures supplement on-device compute for workloads — particularly neural radiance field reconstruction, photogrammetry, and large-model inference — that exceed wearable power budgets. [[Edge Computing]] nodes co-located with 5G base stations target sub-20 ms round-trip latencies required for comfortable tethered rendering.
- [[Simultaneous Localisation and Mapping]] pipelines on modern devices integrate visual-inertial odometry, plane detection, mesh reconstruction, and semantic labelling within a unified scene graph maintained across sessions, enabling persistent AR anchors tied to physical locations.

### Current Landscape (2026)

- Samsung's Galaxy XR, the first headset running Google's Android XR (Android-14-based, Snapdragon XR2+ Gen 2, 27MP micro-OLED, Gemini built in), launched in October 2025 at $1,799, breaking Apple's premium price monopoly and marking the Android ecosystem's entry into high-end spatial computing.
- Apple Vision Pro momentum reversed sharply: after roughly 390,000 units in its 2024 launch year, it shipped only about 85,000 in 2025 (a ~78% year-on-year fall), prompting an M5-chip refresh in October 2025 and reports that Apple has pivoted toward smart glasses rather than a near-term Vision Pro successor.
- Smart glasses became the growth story, shipping around 7.25 million units in 2025 (roughly half of all XR devices and up ~247% on 2024), led by Ray-Ban Meta Gen 2; total XR shipments reached about 14.5 million units in 2025, up 41.6% year-on-year, with the market valued near $20.43 billion and forecast toward $85 billion by 2030 (Mordor Intelligence, ~33% CAGR).
- Khronos ratified the OpenXR Spatial Entities Extensions in June 2025 (part of OpenXR 1.1), the first open standard for spatial anchors, plane/marker tracking and cross-session persistence; by 2026 there were 11 conformant runtimes and engine support across Unity, Unreal and Godot, reframing OpenXR from a portability layer into a spatial-computing platform (SIGGRAPH 2026 session theme).
- AI became a standard headset feature: Gemini Live on Android XR, Apple Intelligence in visionOS, and multimodal assistants aware of spatial context, alongside OpenUSD/USDZ consolidating as the cross-vendor 3D interchange format (Apple, NVIDIA Omniverse, Adobe, Autodesk).
- WebXR matured as the browser-native layer, enabled by default in Safari on visionOS 2 (immersive-vr sessions; AR module still unsupported), with Apple working with the W3C on a new "transient-pointer" input mode and WebGPU pushing web spatial rendering forward.
- Open challenges as of 2026 remain weak consumer demand for premium headsets, comfort and weight, thin native app catalogues, fragmented spatial-video codecs beyond MV-HEVC, and true optical see-through AR glasses (Snap Spectacles, Meta Orion, XREAL) still short of a mainstream all-day form factor.

### References

- 1. Treeview Studio (2026). XR & Smart Glasses Market Statistics Report (2026). https://treeview.studio/blog/xr-spatial-computing-smart-glasses-market-statistics-report
- 2. Treeview Studio (2026). AR/VR/MR/XR Spatial Computing Industry Statistics Report (2026). https://treeview.studio/blog/ar-vr-mr-xr-metaverse-spatial-computing-industry-stats
- 3. Youngju.dev (2026). AR/VR & Spatial Computing 2026 Complete Guide — visionOS, Meta Quest 3, Android XR, OpenXR & OpenUSD Deep Dive. https://www.youngju.dev/blog/culture/2026-05-16-ar-vr-spatial-computing-2026-visionos-2-meta-quest-3-android-xr-unity-unreal-5-5-reality-composer-pro-deep-dive.en
- 4. Develop3D (2025). Spatial Entities Extensions released by Khronos and OpenXR. https://develop3d.com/vr-ar-mr/spatial-entities-extensions-released-by-khronos-and-openxr/
- 5. VR.org (2026). OpenXR Is Quietly Becoming a Spatial Computing Platform (SIGGRAPH 2026). https://vr.org/articles/openxr-spatial-computing-platform-siggraph-2026

### Provenance

