Data science is an interdisciplinary field that combines statistics, programming, and domain knowledge to extract insight and build predictive models from data. It spans the full lifecycle from data acquisition and cleaning through exploratory analysis, modelling, and communication of results. Data science underpins evidence-based decision-making and supplies the analytical foundation for applied machine learning.

- Data science combines [[Statistics]], programming and domain knowledge to extract insight and build predictive models, spanning acquisition, cleaning, analysis and communication.
- It is a specialisation of [[Data Analytics]] and supplies the analytical foundation that [[Machine Learning]] applies in practice.

### Overview

- Data science treats data as the raw material of discovery: practitioners frame questions, gather and clean data, explore it, model relationships, and translate findings into decisions.
- Statistical reasoning anchors the discipline, ensuring conclusions account for uncertainty, bias and sampling.
- Programming — commonly in [[Python]] — operationalises analysis at scale, while [[Feature Engineering]] turns raw inputs into informative model variables.
- The field overlaps heavily with [[Machine Learning]] but emphasises the whole workflow and the communication of results to support [[Decision Support]].

### Key aspects

- Statistical foundation: inference, estimation and hypothesis testing rooted in [[Statistics]].
- Data preparation: cleaning and shaping inputs, relying on upstream [[Data Engineering]].
- Modelling: applying [[Supervised Learning]] and [[Unsupervised Learning]] to find structure and make predictions.
- Communication: presenting results through [[Data Visualisation]] for non-technical stakeholders.

### Mechanisms

- Exploratory analysis surfaces structure and anomalies before modelling.
- [[Feature Engineering]] transforms raw data into predictors that improve model performance.
- Cross-validation and statistical testing guard against overfitting and spurious findings.
- Pipelines built in [[Python]] reproduce analyses and feed [[Predictive Analytics]].

### Applications

- Forecasting and [[Predictive Analytics]] across commerce, health and science.
- [[Business Intelligence]] and [[Decision Support]] grounded in quantitative evidence.
- Experimentation and causal analysis to evaluate interventions.
- Powering applied [[Deep Learning]] and broader [[Machine Learning]] systems.

### Provenance

