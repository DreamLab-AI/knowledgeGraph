A product take-back scheme is an arrangement under which producers, distributors or retailers accept end-of-life or used products from their holders and manage their recovery or disposal, and the sources opened here are both EU legislation, which describes such arrangements without defining the term.[^1][^2]

The EU waste framework directive allows Member States to take legislative or non-legislative measures to ensure that anyone who professionally develops, manufactures, processes, treats, sells or imports products has extended producer responsibility.[^1] It says such measures may include an acceptance of returned products and of the waste that remains after those products have been used, as well as the subsequent management of the waste and financial responsibility for such activities.[^1] Its recitals give examples of collection arrangements, among them waste medicines collected by pharmacies and take-back schemes in shops for consumer goods.[^1]

## Electrical and electronic equipment

The WEEE directive lays down measures to protect the environment and human health by preventing or reducing the adverse impacts of the generation and management of waste from electrical and electronic equipment.[^2] For household waste, Member States must ensure that systems allow final holders and distributors to return waste at least free of charge, and that distributors supplying a new product can take back old equipment of an equivalent type on a one-to-one basis.[^2] Producers must provide at least for the financing of collection, treatment, recovery and environmentally sound disposal of household WEEE deposited at the collection facilities.[^2]

## Scope and distinctions

Take-back is one route by which goods flow back along a chain, described at [[Reverse Logistics]], and it supports the loops in a [[Circular Supply Chain]]. A deposit scheme pays for the return of an item, as at [[Deposit Return Scheme]]; the sources opened do not classify deposit schemes as a kind of take-back.

## What the sources do not establish

Both sources are EU legislation, so the page rests on one legal tradition. The OECD's guidance on extended producer responsibility could not be opened. No source reports collection rates or the cost of the schemes it describes.

[^1]: European Parliament and Council of the European Union, Directive 2008/98/EC of 19 November 2008, “Directive 2008/98/EC of the European Parliament and of the Council on waste”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32008L0098
[^2]: European Parliament and Council of the European Union, Directive 2012/19/EU of 4 July 2012, “Directive 2012/19/EU of the European Parliament and of the Council on waste electrical and electronic equipment (WEEE)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32012L0019

