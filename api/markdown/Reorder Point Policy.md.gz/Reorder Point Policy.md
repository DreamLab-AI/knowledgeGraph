A reorder point policy places an order of a fixed quantity whenever the inventory position falls to or below a set trigger level, the reorder point.[^1][^2]

A Penn State teaching note describes the continuous review (ROP, Q) system: when the inventory position drops to or below the reorder point, the system orders a fixed replenishment quantity Q, and the exposure period begins.[^1] MIT slides call the same rule the order-point, order-quantity policy (s, Q) and state it as ordering Q if the inventory position is at or below s.[^2] Columbia University lecture notes use the notation (Q, r): the manager monitors the inventory position and orders a quantity Q whenever the position falls to or below the reorder point r.[^3]

## Setting the reorder point

The MIT slides set s by adding safety stock to the expected demand over the lead time.[^2] An open operations text defines lead time as the time from when an order is placed with a supplier until it is received, and describes the reorder point as the level at which the system signals an order.[^4] See [[Safety Stock]].

## Scope and distinctions

The Columbia notes contrast (Q, r) with the (s, S) policy, in which the manager restores the inventory position to S whenever it falls to or below s. They say the two are equivalent when demand grows continuously or is always for a single unit, and behave differently when demands can be larger than one and Q is greater than one.[^3] A reorder point policy is a [[Continuous Review Policy]]. The 

Columbia's notes say the case in which Q equals one reduces to a base stock policy; see [[Base Stock Policy]].[^3]

## What the sources do not establish

Notation differs: ROP, s and r all denote the reorder point. Caplice says the order quantity Q in an (s, Q) system is usually determined from the economic order quantity.[^2] See [[Economic Order Quantity]].

[^1]: J. E. Tyworth, Penn State Smeal College of Business SCM 810 technical note, February 2014, “Basic Multi-period Inventory Systems”. https://courses.smeal.psu.edu/SCM810/scm_810_module_3/Multi%20Period%20Inventory%20Systems%20Teaching%20Note.pdf
[^2]: Chris Caplice, MIT OpenCourseWare ESD.260 Logistics Systems, October 2006, “Inventory Management: Probabilistic Demand”. https://ocw.mit.edu/courses/esd-260j-logistics-systems-fall-2006/8b53c45fd26ffff706d815131e8d177e_lect11.pdf
[^3]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “Positive Ordering Costs”. https://www.columbia.edu/~gmg2/4000/pdf/lect_09.pdf
[^4]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.2: Inventory Management Models”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.02%3A_Inventory_Management_Models

