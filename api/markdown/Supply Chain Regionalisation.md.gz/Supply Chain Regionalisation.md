Supply chain regionalisation is the shortening or concentration of supply chains into regional networks, for example by sourcing nearer to the market or within a group of allied countries, and no source opened here defines the term itself.[^1]

The World Trade Organization records that in public debate terms such as offshoring and outsourcing have been replaced by re-shoring, near-shoring, friendshoring and decoupling.[^1] It describes near-shoring as bringing production closer to large markets and friendshoring as strengthening production networks with like-minded countries, and says that both would lead to fragmentation of the global economy along regional and geopolitical lines.[^1]

## Arguments for

The White House 100-day review says that tools including ally and friend-shoring, and stockpiling, along with investments in sustainable domestic production and processing, will all be necessary to strengthen resilience.[^2] The European Central Bank reports corporate survey evidence that some EU manufacturers are shifting the sourcing of critical inputs from China to within the EU, which it calls EU-shoring, to mitigate the risk of disruptions.[^3]

## Arguments against

The WTO takes the opposite view. It says the COVID-19 pandemic raised questions about the fragility of global supply chains and generated demands to reshore production domestically, and concludes that the answer lies in expanding and diversifying trade, not restricting or reshoring it.[^1] It argues that reshoring or friend-shoring could have the opposite effect to the one intended, making supply chains more fragile by cutting off global options, and that friend-shoring can face implementation risks if the geopolitical landscape is unstable.[^1] The ECB adds that addressing foreign dependencies with broadbased protectionism is self-defeating.[^3]

## Scope and limits

Regionalisation is a contested option within [[Supply Chain Resilience Strategy]], and the alternative emphasis on spreading suppliers across regions is [[Supplier Diversification]]. Its geopolitical background is described at [[Geopolitical Supply Chain Risk]].

These three sources are policy and survey documents, and their terms overlap without agreed definitions. None presents a measurement of the effect of regionalising on resilience, so the page records an argument and not a result. This is a thin page.

[^1]: World Trade Organization, “World Trade Report 2023: Re-globalization for a secure, inclusive and sustainable future”. https://www.wto.org/english/res_e/booksp_e/wtr23_e/wtr23_e.pdf
[^2]: The White House, report under Executive Order 14017, June 2021, “Building Resilient Supply Chains, Revitalizing American Manufacturing, and Fostering Broad-Based Growth: 100-Day Reviews under Executive Order 14017”. https://bidenwhitehouse.archives.gov/wp-content/uploads/2021/06/100-day-supply-chain-review-report.pdf
[^3]: European Central Bank, Occasional Paper Series, “Navigating a fragmenting global trading system: insights for central banks (No 365)”. https://ecb.europa.eu/pub/pdf/scpops/ecb.op365~362d801aee.es.pdf

