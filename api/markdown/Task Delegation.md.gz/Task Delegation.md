Task Delegation is the mechanism by which an agent assigns a sub-task to another agent or tool deemed more capable, available or specialised for that work. In multi-agent and agentic systems it underpins division of labour, allowing a coordinating agent to decompose a goal and route components to subordinate executors. Effective delegation requires shared task representation, capability awareness and result aggregation.

### Overview

- Task delegation lets agentic systems scale beyond a single model's competence by routing work to the most appropriate executor. A planner or orchestrator decomposes a goal, identifies which agent or tool can satisfy each part based on advertised capabilities, dispatches the work and reintegrates the returned results. It depends on a shared communication language and on mechanisms for monitoring progress and handling failure or reassignment.

### Key aspects

- Goal decomposition into delegatable sub-tasks
- Capability matching to select an appropriate executor
- Communication of task, context and acceptance criteria
- Result aggregation and quality verification
- Failure handling, retries and reassignment

### Mechanisms

- Goal decomposition into delegatable sub-tasks
- Capability matching to select an appropriate executor
- Communication of task, context and acceptance criteria

### Applications

- Orchestrating specialised tool-using agents
- Hierarchical planner-executor agent architectures
- Routing queries to domain-expert models
- Distributed problem solving across agent teams
- Human-in-the-loop escalation and handoff

### Provenance

## SAC-CG Agent Ontology

The Semantic Agent Communication Community Group's draft Agent Ontology (version 0.4.0, not a W3C Recommendation) defines `Delegation` as a "structured semantic relation where one Agent authorizes another to act within a defined scope".[^sac-1] That is a transfer of authority, the sense of [[Agent Delegation]], and visionGraph places Task Delegation under it as the case where the delegated matter is a task.

The task case is carried by the property `delegatesTask`, which relates an `Agent` to a `Task` and is described as "an Agent delegates a specific Task to another Agent".[^sac-2] Routing a sub-task to a more capable executor is this property together with the delegation it creates, bounded by a [[Delegation Scope]]. The delegating agent selects the executor by comparing the capabilities the task requires with those the candidate agents have; the ontology leaves matching and result aggregation to the implementation.

[^sac-1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^sac-2]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl

