Mobile computing is the discipline of delivering computation, data, and connectivity to portable devices such as smartphones, tablets, and wearables that operate while in motion. It contends with constraints on battery, memory, bandwidth, and intermittent connectivity, and increasingly hosts machine-learning inference directly on-device. Mobile computing bridges cloud back-ends and edge devices, enabling responsive, context-aware applications wherever the user goes.

### Overview

- Mobile computing extends information systems beyond fixed workstations into the pocket, the wrist, and the vehicle, where compute and power budgets are tight and the network is unreliable. To remain responsive, applications cache aggressively, degrade gracefully offline, and increasingly run compressed machine-learning models on the device itself. This on-device intelligence reduces latency, preserves privacy, and lowers dependence on continuous connectivity.

### Key aspects

- Energy-aware computation under strict battery and thermal budgets
- Intermittent connectivity handling, caching, and offline-first design
- On-device inference via quantised and compressed models
- Context awareness from sensors such as GPS, accelerometers, and cameras
- Privacy-preserving learning through federated approaches

### Applications

- On-device assistants and real-time translation
- Mobile augmented-reality experiences
- Health and activity tracking on wearables
- Federated model training across fleets of phones

### Provenance

