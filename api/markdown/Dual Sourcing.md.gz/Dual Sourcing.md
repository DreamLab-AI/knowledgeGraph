Dual sourcing is the practice of buying the same item from two suppliers rather than one, most often to reduce the risk of disruption.[^1][^2]

A literature review from City, University of London says many firms aim to source critical components and raw materials from at least two suppliers. It adds that sourcing from two suppliers may be more expensive than sole sourcing, because of lack of economies of scale or increased management costs, but that firms find value in the increased resilience of their supply chain.[^1] The same review defines supplier diversification as sourcing from various suppliers and notes research on a dual sourcing problem in which the buyer can also influence the disruption likelihood of the supplier.[^1]

Bimpikis, Fearing and Tahbaz-Salehi use the term in a model of a multitier supply chain: they let suppliers choose between sourcing from a single tier 2 firm or dividing their orders equally between two fabricators, an outcome they simply call dual-sourcing.[^2] A Pennsylvania State University course module treats multiple sourcing as the antithesis of single and sole sourcing.[^3]

## Why firms diversify

Most extant theories attribute supplier diversification to supplier risk. Chod, Trichakis and Tsoukalas argue instead that it can follow from buyer risk: buyers that signal creditworthiness to suppliers and then source from a single supplier become vulnerable to future holdup, and ex ante diversification can alleviate this at the cost of higher up-front signalling costs.[^4] Federgruen and Yang model a firm with access to a set of potential suppliers with specific yield and price characteristics, where a procurement strategy specifies the set of suppliers retained and their shares of each replenishment.[^5]

See [[Single Sourcing]], [[Sole Sourcing]], [[Sourcing Strategy]] and [[Supply Chain Resilience]].

## What the sources do not establish

None of the sources opened gives a standard definition of dual sourcing, and three of them are mathematical models whose assumptions are their own, so the page makes no claim about how much resilience it buys.[^2][^4][^5]

[^1]: Lucker and colleagues, City St George's, University of London repository, 2024, “Balancing Resilience and Efficiency: A Literature Review on Overcoming Supply Chain Disruptions”. https://openaccess.city.ac.uk/id/eprint/33699/8/lucker-et-al-2024-balancing-resilience-and-efficiency-a-literature-review-on-overcoming-supply-chain-disruptions.pdf
[^2]: Kostas Bimpikis, Douglas Fearing and Alireza Tahbaz-Salehi, Operations Research 66(4), 2018 (copy on the Kellogg School of Management site), “Multisourcing and Miscoordination in Supply Chain Networks”. https://www.kellogg.northwestern.edu/faculty/alirezat/Multisourcing.pdf
[^3]: Pennsylvania State University Smeal College of Business, SCM 820 course module 4, “Lesson 1: Single or Sole Sourcing”. https://courses.smeal.psu.edu/scm824fa20/scm824fa20_module_4/2011/06/SCM820-M4L1Single-or-Sole-Sourcing.html
[^4]: Jiri Chod, Nikolaos Trichakis and Gerry Tsoukalas, Management Science, 2019 (MIT copy), “Supplier Diversification Under Buyer Risk”. https://web.mit.edu/nitric/www/SupplierDiv.pdf
[^5]: Awi Federgruen and Nan Yang, Operations Research 59(4), 2011 (Columbia Business School copy), “Procurement Strategies with Unreliable Suppliers”. https://business.columbia.edu/sites/default/files-efs/pubfiles/5371/procurement%20strategies.pdf

