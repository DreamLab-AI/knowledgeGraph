Knowledge Graphing is the discipline and computational framework for constructing, enriching, storing, querying, and reasoning over structured semantic knowledge encoded as a graph of typed entities (nodes) and directed typed relationships (edges), spanning formal Semantic Web standards (RDF/...

### Semantic Classification

- **domain-correction:** infrastructure → artificial-intelligence (corrected 2026-05-17; knowledge graphing is primarily an AI/knowledge representation discipline encompassing RDF/OWL semantics, KGE machine learning, GNN completion, LLM+KG hybrid systems; infrastructure domain was incorrect frontmatter inherited from stub migration; IRI, URI, same-as, owl-class updated to artificial-intelligence namespace)

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:hasPart ai:RDFTripleStore))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:hasPart ai:OntologyTBox))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:hasPart ai:ABoxAssertions))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:hasPart ai:SPARQLEndpoint))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:hasPart ai:EntityEmbeddingMatrix))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:hasPart ai:RelationEmbeddingMatrix))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:hasPart ai:GraphNeuralNetworkEncoder))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:hasPart ai:CommunityDetectionLayer))

    ## Dependency Relationships
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:requires ai:EntityResolution))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:requires ai:RelationExtraction))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:requires ai:OntologyEngineering))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:requires ai:NamedEntityRecognition))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:requires ai:CoreferenceResolution))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:dependsOn ai:DescriptionLogics))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:dependsOn ai:GraphTheory))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:dependsOn ai:InformationExtraction))

    ## Capability Relationships
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:enables ai:SemanticSearch))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:enables ai:LinkPrediction))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:enables ai:KnowledgeGraphCompletion))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:enables ai:GraphRAGRetrieval))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:enables ai:FederatedSPARQLQuery))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:enables ai:ExplainableAIReasoning))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:supports ai:EnterpriseSearchRanking))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:supports ai:BiomedicalDrugDiscovery))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:supports ai:FinancialCrimeDetection))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:supports ai:RecommendationSystems))

    ## Implementation Relationships
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:implements ai:TransEEmbeddingModel))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:implements ai:ComplExEmbeddingModel))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:implements ai:RotatEEmbeddingModel))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:implements ai:SPARQLQueryLanguage))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:implements ai:OWL2ReasoningEngine))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:implements ai:LeidenCommunityDetection))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:uses ai:GraphAttentionNetworks))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:uses ai:LargeLanguageModels))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:uses ai:VectorEmbeddings))

    ## Reduction Relationships
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:reduces ai:InformationSiloing))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:reduces ai:SearchLatency))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:reduces ai:KnowledgeFragmentation))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:reduces ai:ManualCurationBurden))
    SubClassOf(ai:KnowledgeGraphing
      ObjectSomeValuesFrom(ai:reduces ai:SemanticAmbiguity))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ai:hasIdentifier ai:KnowledgeGraphing "AI-2031"^^xsd:string)
    DataPropertyAssertion(ai:authorityScore ai:KnowledgeGraphing "0.87"^^xsd:decimal)
    DataPropertyAssertion(ai:googleKGFacts ai:KnowledgeGraphing "500000000000"^^xsd:integer)
    DataPropertyAssertion(ai:wikidataItems ai:KnowledgeGraphing "112000000"^^xsd:integer)
    DataPropertyAssertion(ai:graphRAGMRRImprovement ai:KnowledgeGraphing "3.2"^^xsd:decimal)
    DataPropertyAssertion(ai:fb15k237MRR ai:KnowledgeGraphing "0.47"^^xsd:decimal)
    DataPropertyAssertion(ai:wn18rrMRR ai:KnowledgeGraphing "0.57"^^xsd:decimal)

    ## Property Constraints
    SubClassOf(ai:KnowledgeGraphing
      DataAllValuesFrom(ai:usesRDFTriples xsd:boolean))
    SubClassOf(ai:KnowledgeGraphing
      DataSomeValuesFrom(ai:graphModelType xsd:string))
    SubClassOf(ai:KnowledgeGraphing
      DataMinCardinality(1 ai:hasEntityCount xsd:integer))
    SubClassOf(ai:KnowledgeGraphing
      DataMinCardinality(1 ai:hasRelationCount xsd:integer))

    ## Annotations
    AnnotationAssertion(rdfs:label ai:KnowledgeGraphing "Knowledge Graphing"@en)
    AnnotationAssertion(rdfs:comment ai:KnowledgeGraphing "Discipline and computational techniques for representing, querying, and reasoning over structured semantic knowledge as entity-relation graphs, spanning RDF/OWL/SPARQL semantic web standards, property graph databases (Neo4j, TigerGraph), knowledge graph embeddings (TransE/ComplEx/RotatE achieving MRR 0.47-0.57), GNN-based completion (R-GCN, CompGCN, NBFNet), LLM-augmented GraphRAG (Microsoft 2024 3.2x QA improvement), and large curated open knowledge bases (Wikidata 112M+ items, Google KG 500B+ facts), enabling enterprise search, biomedical discovery, financial crime detection, and scientific synthesis. Domain corrected from infrastructure to artificial-intelligence 2026-05-17."@en)
    AnnotationAssertion(dcterms:identifier ai:KnowledgeGraphing "AI-2031"^^xsd:string)
    AnnotationAssertion(dcterms:subject ai:KnowledgeGraphing "Knowledge Representation, Semantic Web, Graph Databases, GraphRAG, Ontology Engineering, Knowledge Graph Embeddings"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(ai:requires)
  AsymmetricObjectProperty(ai:enables)
  AsymmetricObjectProperty(ai:implements)
  AsymmetricObjectProperty(ai:reduces)
  TransitiveObjectProperty(ai:dependsOn)
  FunctionalDataProperty(ai:googleKGFacts)
  FunctionalDataProperty(ai:wikidataItems)

## About Knowledge Graphing

- **Knowledge Graphing** is the principled construction, enrichment, and exploitation of graph-structured knowledge bases that encode real-world entities and their semantic relationships as machine-readable structured data. Unlike [[Relational Databases]] that enforce rigid tabular schemas, or [[Document Stores]] that handle unstructured text, knowledge graphs represent information as a flexible network of typed (entity, relation, entity) triples — or richer property graphs with edge attributes — enabling multi-hop reasoning, automatic inference, and [[Semantic Search]] that traverses meaning rather than keywords. The discipline unifies contributions from the [[Semantic Web]] community (RDF, OWL, SPARQL standardised by W3C 2004-2013), database systems research (property graph models, graph query languages Cypher and GQL), [[Machine Learning]] (embedding models, GNNs, [[Large Language Model]]), and [[Information Extraction]] (named entity recognition, relation extraction, entity resolution).
- The field's modern architecture involves three coupled layers:
  - (1) **Schema/ontology layer (TBox)**: defines entity types, property types, class hierarchies, and logical axioms — e.g. `owl:subClassOf`, `owl:someValuesFrom`, cardinality constraints; maintained by [[Ontology Engineering]] teams using Protégé, TopBraid Composer, or PoolParty
  - (2) **Instance/fact layer (ABox)**: contains individual entity assertions and relation triples derived from structured sources (databases, APIs, authority files) and unstructured text via [[Information Extraction]] pipelines including [[Named Entity Recognition]], [[Relation Extraction]], and coreference resolution
  - (3) **Inference layer**: applies reasoning rules (OWL axioms, Datalog rules, SPARQL CONSTRUCT) to derive implicit knowledge not explicitly stored — e.g. if owl:subClassOf(Cat, Animal) and rdf:type(Whiskers, Cat) then infer rdf:type(Whiskers, Animal); critical for data integration across heterogeneous sources
  - This layered architecture underpins formal bio-ontologies (Gene Ontology 50K+ terms, Human Disease Ontology 18K+ diseases, [[Drug Discovery]] ontologies via ChEMBL/DrugBank) and pragmatic open knowledge bases like Wikidata (112M+ items, 1.6B+ statements) and [[Schema.org]] (600+ types, 45M+ website adoptions)
- The transition from knowledge graphs as static curated databases to **dynamic AI-augmented systems** accelerated 2022-2026, driven by three converging forces:
  - [[Large Language Model]] demonstrating unprecedented [[Information Extraction]] capability for automated KG population — GPT-4 and Claude 3 can extract structured triples from unstructured text with 85-95% precision on well-defined entity/relation schemas, dramatically reducing manual curation cost
  - [[GraphRAG]] architectures proving that graph-structured retrieval outperforms flat vector search for multi-hop reasoning tasks requiring global synthesis — the Microsoft 2024 paper showed 3.2× comprehensiveness improvement on corpus-wide question answering
  - [[Graph Neural Network]] architectures (R-GCN, CompGCN, NBFNet) achieving near-human performance on KG completion benchmarks, enabling autonomous expansion of knowledge bases from seed facts without exhaustive manual curation
  - The result is hybrid [[Cognitive AI]] systems where LLMs provide flexible language understanding and KGs provide structured grounding, factual accuracy, and explainability — directly addressing LLM hallucination by anchoring generation to verified structured facts

## Formal Foundations: RDF, OWL, and Description Logics

- The **Resource Description Framework (RDF)** is the W3C foundation for knowledge graph data. Every RDF statement is an (s, p, o) triple where subject s and predicate p are IRIs and object o is either an IRI or a typed literal. Triple stores (Stardog, GraphDB, Apache Jena, Virtuoso, Amazon Neptune) persist billions of triples indexed for efficient SPARQL pattern matching. Key formal layers:
  - **RDF Schema (RDFS)** provides basic vocabulary: `rdfs:subClassOf` (class hierarchy enabling inference that instances of subclasses are instances of superclasses), `rdfs:domain` and `rdfs:range` (property type constraints), `rdf:type` (entity classification), `rdfs:label` and `rdfs:comment` (human-readable annotations)
  - **OWL 2** adds expressive class constructors beyond RDFS: `owl:intersectionOf` (conjunction), `owl:unionOf` (disjunction), `owl:complementOf` (negation), `owl:someValuesFrom` (existential restriction, ∃r.C), `owl:allValuesFrom` (universal restriction, ∀r.C), `owl:hasValue` (nominals), `owl:exactCardinality`, `owl:minCardinality`, `owl:maxCardinality` — collectively enabling description logic SROIQ(D) reasoning with transitive, symmetric, asymmetric, functional, and inverse properties
  - **OWL 2 Profiles** trade expressivity for tractability: OWL 2 EL (polynomial-time reasoning, suitable for bio-ontologies with millions of axioms), OWL 2 QL (SPARQL-rewritable query answering enabling relational database backends for large ABoxes), OWL 2 RL (rule-based forward chaining semantics, compatible with Datalog rule engines, no existential quantification in consequences)
  - **SPARQL 1.1** (W3C 2013): graph pattern matching via basic graph patterns (BGPs), OPTIONAL (left outer join), UNION, MINUS, FILTER, aggregates (GROUP BY, HAVING, COUNT, SUM), subqueries, property paths (arbitrary-length traversal `foaf:knows+`, inverse `^`, Kleene-star `*`, Kleene-plus `+`), federated queries via `SERVICE` keyword delegating sub-queries to remote SPARQL endpoints, and the `UPDATE` sublanguage for graph modification
- **Description Logics** (DLs) provide the formal model-theoretic semantics underpinning OWL 2: a DL knowledge base K = (T, A) where T (TBox) states terminological axioms (C ⊑ D, class subsumption) and A (ABox) states individual assertions (C(a), r(a,b)). Standard reasoning tasks and their complexities:
  - **Satisfiability** (is C non-empty under T?): PTIME for OWL 2 EL; EXPTIME for OWL 2 DL (SROIQ)
  - **Subsumption** (does C ⊑ D follow from T?): PTIME for EL; EXPTIME for SROIQ
  - **Instance retrieval** (which individuals satisfy C given T and A?): PTIME for EL; co-NP in ABox size for DL-Lite (enabling first-order rewriting to SQL/SPARQL); EXPTIME for full SROIQ
  - **Conjunctive query answering** (union of conjunctive queries, UUCQ): first-order rewritable for DL-Lite (critical for ontology-based data access / OBDA); undecidable in general for SROIQ without restrictions
  - Production reasoners: **HermiT** (Oxford, hypertableau calculus for OWL 2 DL, handles 1M+ axiom ontologies), **ELK** (Karlsruhe/Oxford, polynomial OWL 2 EL, sub-second on Gene Ontology 50K+ axioms), **FaCT++** (Manchester, optimised SROIQ(D) with caching), **RDFox** (OxfordSemantic Networks, in-memory Datalog on billion-triple RDF datasets, <1ms SPARQL latency via RETE networks, ACID transactions)
  - The [[Cognitive AI]] connection: DL reasoning enables knowledge graphs to perform deductive closure — automatically deriving all implied facts — supporting [[Explainable AI]] by making reasoning steps traceable as logical inference chains

## Property Graph Databases

- Property graphs extend the RDF triple model by allowing both nodes and edges to carry arbitrary key-value property maps, enabling richer representations without reification. The leading platforms differ in query languages, scalability, and analytical capability:

### Neo4j and the Cypher Query Language

- Neo4j is the dominant property graph database (18M+ downloads, listed NYSE:NEO) with Cypher as its declarative ASCII-art pattern-matching query language. Version 5.x (released November 2022, continuous point releases through 2025-2026) introduced major capabilities:
  - **Composite databases**: federated graph querying across multiple physical Neo4j databases via a single logical graph routing layer — enabling multi-tenant enterprise architectures where each business unit owns its graph while cross-domain queries traverse logical boundaries
  - **Native vector index** (Neo4j 5.11+, October 2023): cosine and Euclidean similarity search over node embedding properties, enabling hybrid graph+vector [[Retrieval Augmented Generation]] within a single Cypher query combining `MATCH` graph pattern traversal with `db.index.vector.queryNodes('embedding', 10, $queryEmbedding)` — retrieving semantically relevant nodes enriched with graph context
  - **Graph Data Science (GDS) library 2.x**: 70+ graph algorithms covering centrality (PageRank, Betweenness, Closeness, Degree, HITS), community detection (Louvain, Leiden, Label Propagation, WCC, SCC), similarity (Node Similarity, K-Nearest Neighbours), path finding (Dijkstra, A*, Yen's k-shortest), and ML pipelines (GraphSAGE node embedding, node classification, link prediction with supervised models trained on graph features)
  - **Cypher example** for multi-hop traversal: `MATCH (n:Person)-[:KNOWS*1..3]->(m:Person WHERE m.city = 'London') RETURN m.name, count(*) ORDER BY count(*) DESC LIMIT 10` — finds persons within 3 relationship hops based in London; pattern-centric syntax is far more readable than recursive CTEs in [[Relational Databases]]
  - **Production deployments**: eBay product entity graph (500M+ nodes for relationship recommendation), NASA astronaut health monitoring knowledge graph, Walmart supply chain graph analytics, UK HMRC [[AML KYC Compliance]] fraud detection (2B+ transactions), NHS community care pathway knowledge graph, HSBC regulatory network compliance

### TigerGraph

- TigerGraph targets deep-link analytical workloads with the GSQL parallel query language that compiles to native C++ execution, achieving 10-100× throughput over Neo4j on 3+-hop analytics. GSQL supports ACCUM operators for distributed graph accumulation patterns, MAP/REDUCE semantics for neighbour aggregation, and built-in graph statistics. Notable deployments: Visa (real-time fraud detection across 7B+ transactions/day using path analysis to detect card-not-present fraud rings), Intuit (financial entity graph 1B+ nodes for tax fraud detection), Jaguar Land Rover (vehicle quality knowledge graph linking warranty claims, sensor data, and manufacturing records), UnitedHealth Group (claims fraud graph analytics).

### Amazon Neptune, Oracle PGQL, and Apache AGE

- **Amazon Neptune** (AWS managed service) supports both SPARQL 1.1 (RDF mode) and OpenCypher/Gremlin (property graph mode) on the same dataset via Neptune Analytics (2023), integrating with AWS Bedrock for LLM+graph workflows, S3 bulk loading, and Lambda event-triggered graph updates. Neptune Serverless (2022) provides auto-scaling for variable workloads without capacity management.
- **Apache AGE** (A Graph Extension for PostgreSQL) adds Cypher graph query support atop standard PostgreSQL, enabling organisations to run property graph queries without migrating from existing Postgres infrastructure, co-located with pgvector for hybrid graph+semantic search — a compelling developer-experience stack for teams already operating PostgreSQL.
- **ISO GQL** (ISO/IEC 39075, ratified April 2024): the International Standard for Graph Query Language provides a unified property graph query language paralleling SQL for relational databases. Neo4j, TigerGraph, Oracle, AWS Neptune, and Memgraph have committed to GQL compliance by 2026, reducing vendor lock-in and enabling portable graph queries across engines for the first time.

## Open Knowledge Bases

### Wikidata

- Wikidata (Wikimedia Foundation, launched 2012) is the world's largest openly-editable structured knowledge base. By 2025 it contains 112M+ items (Q-entities), 1.6B+ statements using 10K+ distinct property types (P-numbers), linked to 800+ external databases via authoritative identifier properties (P31 for instance-of, P279 for subclass-of, P18 for image, P569/P570 for birth/death dates). The Wikidata Query Service (WDQS) hosts a public SPARQL 1.1 endpoint over 7B+ triples, handling 1.5M+ queries/day and supporting complex federated queries with label service, GeoSPARQL extensions, and full-text search. Key 2024-2026 milestones:
  - **Wikidata Bridge** (2024): Direct editing of Wikidata statements from Wikipedia infoboxes via a dedicated UI, accelerating data freshness and reducing sync latency between encyclopaedic content and structured data
  - **Lexicographical data**: 1M+ lexemes across 400+ languages providing multilingual lemma-form-to-entity links supporting cross-lingual NLP applications and multilingual KG querying
  - **Scholarly entity coverage**: 60M+ journal articles linked via DOI/QID with publisher, author (ORCID-linked), and journal entity relationships enabling academic citation graph analytics
  - **Wikidata for AI training**: used as ground truth for entity linking benchmarks (AIDA-CoNLL, TAC-KBP), for knowledge graph completion training sets (FB15k-237 derived from Freebase/Wikidata), and as grounding for [[Retrieval Augmented Generation]] factual verification

### DBpedia and the Linked Open Data Cloud

- DBpedia (University of Leipzig / Free University Berlin / AKSW group) extracts structured data from Wikipedia infoboxes, generating 3B+ RDF triples across 127 languages using a curated mapping ontology (760+ classes, 2,800+ properties). DBpedia entities use owl:sameAs links to Wikidata, schema.org, GeoNames, and VIAF forming the Linked Open Data (LOD) cloud backbone. The DBpedia SPARQL endpoint at dbpedia.org serves as the most-queried public SPARQL endpoint globally. DBpedia Spotlight provides entity linking from plain text to DBpedia/Wikidata resources, used in information extraction pipelines that feed downstream [[Knowledge Graph Embeddings]] training.

### Schema.org and Structured Web Data

- Schema.org (co-founded 2011 by Google, Microsoft, Yahoo, Yandex) defines a shared vocabulary for structured data markup on web pages using JSON-LD, Microdata, or RDFa. By 2024, 45M+ websites implement schema.org markup covering Product (e-commerce), Organization, Person, Event, Recipe, FAQPage, HowTo, MedicalCondition, Drug, and 600+ additional types. Schema.org markup feeds into: Google Search Knowledge Panels and rich snippets; Bing Entity Cards; AI training data for LLM factual grounding; and web-scale KG construction pipelines (Common Crawl schema.org extraction yielding 40B+ RDF triples from the structured web). The WebDataCommons project (University of Mannheim) publishes annual extractions of schema.org data from Common Crawl, providing the largest open corpus of structured web knowledge.

### Google Knowledge Graph and Amazon Product Graph

- Google's production knowledge graph (incorporating Freebase, acquired 2010, and continuously enriched from the structured web, Wikipedia, and partner data) serves 500B+ facts. Knowledge Panels appear in ~30% of Google Search queries, covering people, organisations, places, creative works, and scientific concepts. Integration with Gemini 1.5 (2024) and Gemini 2.0 (2025) enables generative search responses grounded against the KG for factual accuracy, with structured data citations. Google's Multitask Unified Model (MUM 2021) and successor multimodal models jointly encode text and structured KG data for multi-modal question answering across 75 languages simultaneously.
- Amazon's Product Graph contains 1B+ item relationships and product attributes (dimensions, compatibility, ingredients, allergens, certifications) spanning 500M+ Amazon catalogue items, powering product search ranking, Alexa question answering, and recommendation systems. The KG uses a hybrid property-graph/RDF architecture with automated extraction from product descriptions, customer reviews, category taxonomy, and supplier certification data, with human-in-the-loop validation for high-stakes medical device and food product attributes.

## Knowledge Graph Embeddings

- Knowledge graph embedding (KGE) models learn dense vector representations of entities e ∈ ℝ^d and relations r ∈ ℝ^d (or ℂ^d) that preserve graph structure, enabling link prediction (plausibility score for missing triple (h, r, ?)), entity similarity clustering, and feature generation for downstream [[Machine Learning]] tasks. Standard evaluation benchmarks: FB15k-237 (14,541 entities, 237 relation types, 272,115 train / 17,535 test triples from Freebase, removing redundant inverse triples from original FB15k to prevent test leakage), WN18RR (40,943 entities, 11 relation types, 86,835 train / 3,034 test triples from WordNet, similarly deduped). Evaluation metric: mean reciprocal rank (MRR = (1/|T|) ∑ 1/rank_t) and Hits@k (fraction of test triples with target ranked in top k candidates, k=1,3,10).

### Translational and Bilinear Models

- **TransE** (Bordes et al. 2013, NeurIPS): score(h, r, t) = -‖e_h + r - e_t‖. Simple, O(n·d) parameters, scales to 100M+ entity KGs. FB15k-237 MRR ~0.31. Fails on symmetric/many-to-many relations. Training: margin-ranking loss L = ∑ max(0, γ + score(h,r,t) - score(h,r,t')). PyKEEN library provides reference implementation (30K+ GitHub stars, 60+ KGE models).
- **DistMult** (Yang et al. 2015, ICLR): score(h, r, t) = ⟨e_h, r, e_t⟩ = ∑_i e_h,i · r_i · e_t,i. Efficient bilinear model for symmetric relations; fails on antisymmetric/asymmetric. MRR ~0.35 on FB15k-237. Relation matrix is diagonal, reducing parameters while maintaining expressiveness for commutative patterns.
- **ComplEx** (Trouillon et al. 2016, ICML): extends DistMult to complex vectors e_h, r, e_t ∈ ℂ^d: score(h, r, t) = Re(⟨e_h, r, ē_t⟩) = ∑_i Re(e_h,i · r_i · ē_t,i). The complex conjugate ē_t breaks commutativity, capturing asymmetric (P→Q ≠ Q→P), antisymmetric (P→Q ⊃ ¬Q→P), and inverse (P→Q ↔ Q→P') relation patterns simultaneously. FB15k-237 MRR ~0.40, WN18RR MRR ~0.47.
- **RotatE** (Sun et al. 2019, ICLR): models relation r as element-wise rotation in complex space: t = h ∘ r where each component |r_i| = 1 (unit modulus, representing angle θ_i). Captures: symmetry (r_i = e^{iπ}, rotation by π), antisymmetry (r_i ≠ r̄_i), inversion (r^{-1} = r̄), composition (r₁ ∘ r₂ = r₁ + r₂ angle-wise). Self-adversarial negative sampling generates hard negatives by sampling from the current model's distribution. FB15k-237 MRR ~0.47, WN18RR MRR ~0.57. Cited 3K+ times; widely adopted as the reference asymmetric KGE model.
- **TuckER** (Balazevic et al. 2019, EMNLP): score(h, r, t) = W ×₁ e_h ×₂ w_r ×₃ e_t where W is a core Tucker-decomposition tensor. Full bilinear model capturing all relation patterns; regularised via Bernoulli dropout. FB15k-237 MRR ~0.47. RESCAL (Nickel et al. 2011) is the non-decomposed bilinear baseline.

### Foundation and Inductive Models (2022-2026)

- **SimKGC** (Wang et al. 2022, ACL): leverages pre-trained LM encoders (BERT-base/large) to encode entity descriptions as dense vectors, then trains with SimCSE-style in-batch contrastive learning. WN18RR MRR ~0.66 — substantially above geometry-based methods — by exploiting entity text descriptions absent in purely structural models. Critical for KGs with rich entity descriptions (Wikidata, biomedical KGs).
- **KGT5** (Saxena et al. 2022, AKBC): seq2seq T5-based approach framing link prediction as text generation: input "What is the capital of France?" → generate "Paris". Achieves competitive performance on Freebase-based benchmarks while supporting natural language query interfaces.
- **ULTRA** (Galkin et al. 2023, NeurIPS): a pre-trained foundation model for KG reasoning that generalises zero-shot to entirely unseen knowledge graphs by learning from relation patterns rather than entity-specific embeddings. Pre-trained on 50+ diverse KGs spanning biology, geography, commonsense, and encyclopaedic knowledge; fine-tuned on target KG with <1K triples. Achieves competitive link prediction MRR compared to fully-trained models while requiring zero entity-specific training.
- **NodePiece** (Galkin et al. 2022, ICLR): tokenises KG entities via a fixed vocabulary of anchor nodes and relational context paths rather than learning unique entity embeddings. Enables inductive inference on new entities not seen during training — critical for production KGs with continuously added entities (Wikidata adds ~5K items/day).

## GNN-Based Knowledge Graph Completion

- Graph Neural Networks provide an inductive framework for KG completion that generalises across entities by operating on the local relational neighbourhood rather than entity-specific parameters, enabling inference on new entities and integration of node/edge features from text or other modalities.

### R-GCN and CompGCN

- **R-GCN** (Schlichtkrull et al. 2018, ESWC): extends message-passing to typed edges with relation-specific weight matrices W_r: h_i^{(l+1)} = σ(W_0^{(l)} h_i^{(l)} + ∑_r ∑_{j∈N_r(i)} (1/c_{i,r}) W_r^{(l)} h_j^{(l)}). Basis decomposition limits parameters for many-relation-type KGs by decomposing W_r = ∑_b a_{r,b} V_b. Achieves FB15k-237 MRR ~0.30 on link prediction and competitive results on entity classification tasks. Widely used as the backbone for KG-enriched recommendation systems (incorporating user-item-attribute graphs).
- **CompGCN** (Vashishth et al. 2020, ICLR): joint entity-relation embedding via composition operations applied to edge-aggregated entity messages: three composition options (subtraction e_h - r, multiplication e_h ∗ r, circular correlation e_h ⊛ r from HolE). Entity embeddings are updated incorporating relation embeddings of incident edges; both entity and relation representations improve jointly through training. Achieves SOTA on multiple KG completion benchmarks in 2020; FB15k-237 MRR ~0.36, WN18RR MRR ~0.47.

### Path-Based and Inductive Completion

- **NBFNet** (Zhu et al. 2021, NeurIPS): Neural Bellman-Ford Networks compute pair-wise representations via generalised Bellman-Ford message passing — initialising with a query-specific indicator function and propagating along relation-typed edges to aggregate multi-hop path information. Achieves FB15k-237 MRR ~0.42, WN18RR MRR ~0.55 without access to test triples. Interpretable: attention weights over paths provide reasoning traces (e.g., Edinburgh → capitalOf⁻¹ → Scotland → partOf → UK).
- **GraIL** (Teru et al. 2020, NeurIPS): inductive relation prediction via local subgraph reasoning — extracts enclosing subgraphs around entity pairs and applies GNNs to classify the relation, generalising to entities absent during training. Achieves strong inductive transfer across different KG splits and even across different KGs sharing the same relation vocabulary.
- **DRUM** (Sadeghian et al. 2019, NeurIPS): differentiable rule mining using bidirectional RNNs over relation paths, learning soft logical rules (Horn clauses) that explain link predictions. Provides symbolic interpretability by surfacing learned rules like `nationality(X,Y) ← bornIn(X,Z) ∧ locatedIn(Z,Y)`.

## LLM + Knowledge Graph Hybrid Systems

### GraphRAG (Microsoft Research 2024)

- Edge et al. (arXiv:2404.16130, April 2024) introduced a two-stage [[GraphRAG]] pipeline addressing the fundamental limitation of vector-based [[Retrieval Augmented Generation]] for global, synthesising questions requiring aggregation over an entire corpus rather than retrieval of specific passages:
  - **Indexing stage — entity graph construction**: LLM ([[Constitutional AI Language Model Family]] or [[Instruction-Following Conversational AI System]] GPT-4 as extraction model) processes text chunks to extract entity tuples (entity name, entity type, entity description) and relationship tuples (source entity, target entity, relationship description, relationship strength); entities are deduplicated and merged; the resulting entity-relation graph is built with relationship strength as edge weights
  - **Indexing stage — community detection**: Leiden algorithm (Traag et al. 2019, a refinement of Louvain with resolution guarantees and no randomness in final partition) partitions the entity graph into hierarchical community levels from fine-grained to coarse; each community represents a topically coherent entity cluster; LLM generates natural-language community summaries at each hierarchy level providing multi-resolution descriptions of the corpus content
  - **Query stage — global queries**: for questions requiring synthesis across the entire corpus (e.g. "what are the main themes in these emails?"), retrieve the K most relevant community summaries from the appropriate hierarchy level via vector similarity; LLM map-reduces across summaries (each summary independently rated for relevance, then aggregated in a global synthesis pass); achieves 3.2× higher comprehensiveness and 2.1× higher diversity vs baseline vector RAG on EnronEmails (human evaluation by domain experts)
  - **Query stage — local queries**: for specific entity-targeted questions, retrieve entity neighbourhood via combined vector similarity + graph traversal (k-hop BFS from matched entities), providing structured factual grounding complementary to passage-based RAG
  - **Microsoft graphrag library** (github.com/microsoft/graphrag, public release August 2024): 20K+ GitHub stars within 6 months; supports local/global query modes; Leiden community detection via `graspologic`; LLM backends (Azure OpenAI, [[Instruction-Following Conversational AI System|OpenAI API]]); pluggable storage (Azure Blob, local filesystem, Cosmos DB, PostgreSQL)
  - **Community ecosystem**: GraphRAG4OpenWebUI (win4r, integrates [[Open Webui and Pipelines]] with graph retrieval), local [[Ollama]]-backed GraphRAG via Mistral 7B / Llama 3, R2R (SciPhi `r2r-docs.sciphi.ai/cookbooks/knowledge-graph`) providing cloud-hosted GraphRAG API, AutoGen+GraphRAG+Ollama integration for [[CLI Multi-Agent Systems|local multi-agent RAG]] superbot architectures

### LangChain and LlamaIndex KG Integration

- [[LangChain]] provides `GraphCypherQAChain` enabling natural language querying of [[Neo4j]], ArangoDB, and Amazon Neptune via LLM-generated Cypher, with schema injection and query validation. The `Neo4jVector` store integrates graph vector index with Cypher pattern-matching for hybrid [[Retrieval Augmented Generation]] queries. Key [[LangChain]] knowledge graph capabilities:
  - `GraphCypherQAChain`: inject KG schema (node labels, relationship types, property keys) as LLM context; LLM generates Cypher; result rows formatted as natural language answer; configurable temperature and few-shot examples for domain-specific query generation
  - `Neo4jVector` hybrid search: `db.index.vector.queryNodes('embedding', 10, $embedding) YIELD node MATCH (node)-[:AUTHORED_BY]->(author) RETURN node, author` — semantically relevant nodes enriched with graph context
  - `KnowledgeGraphIndex` (LangChain legacy): stores entity-relation triplets extracted from text; enables graph-aware retrieval combining entity matching with structural graph traversal
  - Integration with [[Agents]]: [[LangChain]] [[Agent Frameworks]] can use graph query tools as callable actions, enabling [[Agents|agentic]] multi-step reasoning that queries and updates knowledge graphs as part of task completion
- [[LlamaIndex]] 0.10+ (2024) introduced `PropertyGraphIndex` with end-to-end KG construction and querying:
  - **Construction**: LLM extracts entity-relation triples from documents using configurable extraction prompts (domain ontology-guided schemas for medical, legal, financial entity types); deduplication and entity resolution via embedding similarity; batch processing pipelines for large document corpora
  - **Storage backends**: `Neo4jGraphStore`, `NebulaGraphStore` (distributed property graph for billion-node KGs), `KuzuGraphStore` (embedded DuckDB-backed zero-infrastructure storage for local deployments), in-memory `SimplePropertyGraphStore` for development
  - **Retrieval**: hybrid graph traversal + vector similarity; configurable BFS depth for multi-hop retrieval; optional [[GraphRAG]] community summary pre-computation; integration with [[Agents]] via `KnowledgeGraphQueryEngine` tool wrapping
  - [[LlamaIndex]] PropertyGraphIndex used in production at financial services firms for contract knowledge graph construction, pharmaceutical companies for clinical trial entity graphs, and government agencies for regulatory compliance knowledge bases

### Think-on-Graph and KG-Grounded Reasoning

- Sun et al. (2024, ICLR) proposed **Think-on-Graph**: iterative beam search over Wikidata/Freebase guided by [[Large Language Model|LLM]]-scored relation selection for [[Question Answering]]:
  - For each reasoning step, the LLM scores which relations to traverse from the current entity beam; the KG is queried to retrieve candidate next-hop entities; the LLM prunes the beam to k most promising entities based on relevance to the question
  - Achieves 54% accuracy on multi-hop WebQSP questions vs 33% for vanilla [[Retrieval Augmented Generation]], preventing hallucination by constraining generation to graph-verified entity paths
  - Each reasoning step is traceable as an explicit KG path, providing full [[Explainable AI]] audit trail of how the answer was derived — critical for medical, legal, and financial [[Agents|agentic]] applications
  - Generalises to CWQ (Complex WebQuestions) benchmark with 48% accuracy vs 28% for RAG baseline; path traces reveal multi-hop composition patterns like `birthPlace → locatedIn → country → officialLanguage`
- **Cognee** (topoteretes, 2024): LLM-native deterministic [[Agents|agent]] memory via knowledge graph construction from conversation history and documents:
  - Builds entity-relation graphs from ingested content using [[Constitutional AI Language Model Family]] / GPT-4 LLM extraction with configurable ontology schemas (configurable entity types per domain: medical, legal, financial, technical)
  - Stores in configurable graph backends (NetworkX for local/development, [[Neo4j]] for production, Kuzu for embedded); provides graph-traversal-based retrieval ensuring factual consistency across long agentic task sequences
  - Integrates with [[LangChain]], [[LlamaIndex]], and the [[Instruction-Following Conversational AI System|OpenAI Assistants API]] via tool-calling interface; enables [[CLI Multi-Agent Systems]] with persistent structured memory that persists across sessions
  - Addresses the stateless memory problem in deployed [[Agent Frameworks]]: [[Agents]] using Cognee can recall specific facts from earlier in a task (e.g. "the contract signed on 15 March had these specific terms") without hallucination
- **KG-augmented pretraining and fine-tuning** integrating [[Transformers]] and KGs:
  - **K-BERT** (Liu et al. 2020): injects KG triples as soft position-encoded tokens during [[Transformers|BERT]] fine-tuning via a sentence tree structure; improving commonsense QA (CommonsenseQA 68.4% vs 65.4% BERT) and entity-level tasks by 2-4% F1
  - **ERNIE (Tsinghua)** (Sun et al. 2020): aligns entity spans in text with Wikidata KGE embeddings during pretraining; improved entity typing, relation classification, and entity QA tasks; used in Baidu Search for entity-enriched query understanding
  - **KEPLER** (Wang et al. 2021): jointly optimises masked language modelling and KGE (TransE-style) objectives on entity description text from Wikipedia; produces text encoders whose contextual representation geometry aligns with structural KGE geometry — enabling zero-shot entity linking from text to KG via cosine similarity in the shared embedding space

## Enterprise Knowledge Graphs

### Google Knowledge Graph and Gemini Integration

- Google's production knowledge graph (incorporating the deprecated Freebase, acquired 2010, continuously enriched from structured web, Wikipedia, authoritative data providers, and partner feeds) serves 500B+ facts:
  - Knowledge Panels appear in ~30% of Google Search queries covering people, organisations, places, creative works, scientific concepts, and events; panels include cross-linked entity facts, images, and "people also search for" entity graph neighbourhoods
  - Integration with Google Gemini 1.5 (March 2024) and Gemini 2.0 (December 2024) enables structured grounding: [[Artificial General Intelligence|generative]] responses cite Knowledge Panel facts with confidence scores; Gemini's multi-step reasoning uses the KG as an external entity resolution memory — e.g. disambiguating "Apple" as the company vs the fruit via KG entity type context
  - **Google Knowledge Graph Search API** ($0.50/1000 queries): programmatic access to the KG for application developers building entity-centric features; returns JSON-LD structured responses with entity types, description, URL, and image links; widely used in information extraction pipelines feeding downstream [[Knowledge Graph Embeddings]] systems
  - Google's MUM (Multitask Unified Model, 2021) and successor multimodal models jointly encode text and structured KG data across 75 languages simultaneously, enabling cross-lingual entity disambiguation and multilingual knowledge panel generation

### LinkedIn Economic Graph

- LinkedIn's Economic Graph contains 1B+ member profiles, 67M+ company pages, 40K+ standardised skills (ESCO taxonomy-aligned), 150K+ schools, forming the world's most comprehensive labour market knowledge graph. The graph powers: skills-to-job-title inference (Graph [[Attention]] Networks with temporal edge features for real-time recommendation); economic mobility analytics (tracking career transitions as graph paths); and LinkedIn Economic Graph reports (monthly publications on hiring trends, skills demand, and labour market shifts used by policymakers in 100+ countries). LinkedIn's 2023 paper on temporal graph neural networks for recommendation update latency achieved 3× throughput improvement via incremental graph updates without full retraining.

### Financial Services Knowledge Graphs

- HSBC deployed a TigerGraph-based anti-money-laundering transaction graph (3B+ nodes, 10B+ edges as of 2024) enabling real-time pattern queries for circular fund flows, layering schemes, and structuring transactions, achieving 3× alert precision improvement over rule-based systems while reducing false positive rates by 40%. JPMorgan's entity resolution graph links 50M+ counterparty records across trading systems, custody, and compliance using graph-based probabilistic blocking combined with GNN similarity scoring trained on manually confirmed matches.
- **FIBO** (Financial Industry Business Ontology, EDM Council / OMG): a formal OWL 2 ontology covering 100K+ financial concepts — legal entities, financial instruments, contracts, regulatory obligations — standardised by the Object Management Group (OMG) and adopted by major central banks (ECB, Federal Reserve) and financial regulators for machine-readable reporting. FIBO provides the semantic backbone for GLEIF's Global Legal Entity Identifier system linking LEIs to corporate ownership hierarchies.

### NHS and Biomedical Knowledge Graphs in the UK

- The NHS Integrated Care Record Programme (2023-2026) uses knowledge graphs to link patient records, SNOMED CT clinical terminology (350K+ concepts, 1.3M+ descriptions, polyhierarchical concept graph), ICD-10 diagnostic codes, BNF drug data, and OPCS procedure codes into a computable clinical knowledge graph enabling automated medication safety checking and clinical decision support. The UK Health Data Research Alliance's HDRUK Phenotype Library formalises 2K+ disease phenotypes as ontology-grounded computable definitions in OWL, queryable via SPARQL and integrated into federated analytics platforms (SAIL Databank Wales, NHS Digital SDE). Genomics England's knowledge graph (100K Genomes Project) links 100K+ whole-genome sequences to 12K+ participants, 2K+ disease entities, and 20K+ gene-phenotype associations via HPO (Human Phenotype Ontology) and Ensembl gene ontology mappings.

## Components and Architecture

- A production knowledge graph system comprises seven interacting architectural layers:

### Layer 1 — Information Extraction

- The extraction layer populates the knowledge graph from heterogeneous source data:
  - **[[Named Entity Recognition]]**: spaCy industrial NER (en_core_web_trf, en_core_sci_lg for biomedical), Stanford CoreNLP (25+ language models), Hugging Face NER (dslim/bert-base-NER, 85-95% F1 on CoNLL-2003 for standard entity types: PERSON, ORG, LOC, DATE, MONEY)
  - **Relation extraction**: REBEL (Cabot & Navigli 2021, EMNLP) — seq2seq generation model producing (head, relation, tail) triples; fine-tuned T5/BART backbone; TACRED/DocRED benchmark performance; supports 220 Wikidata relation types; UniRel (Tang et al. 2022, ACL) for joint entity-relation extraction via unified encoding
  - **LLM-based extraction** (2023-2026): GPT-4/[[Constitutional AI Language Model Family]]-3 with structured output JSON schemas enable ontology-grounded triple extraction from domain documents — precision 85-95% on well-constrained schemas vs 60-75% for fine-tuned seq2seq models; prompt engineering with ontology type definitions and few-shot triple examples
  - **Unsupervised OpenIE**: OpenIE 5.1 (Allen Institute), Stanford OpenIE (Angeli et al. 2015) for domain-agnostic extraction without predefined relation vocabulary; lower precision but higher recall, useful for broad KG bootstrapping from web text

### Layer 2 — Entity Resolution

- Entity resolution ensures different mentions of the same real-world entity are merged into canonical KG nodes:
  - **Blocking strategies** to reduce O(n²) pairwise comparison cost: LSH (Locality-Sensitive Hashing) for text-based blocking (MinHash, SimHash), Sorted Neighbourhood Method on phonetic codes (Metaphone, Double Metaphone) for name variant blocking, attribute-value inverted index blocking (Magellan/py_entitymatching)
  - **Matching models**: DeepMatcher (Mudgal et al. 2018, SIGMOD): GNN-based entity matching trained on labelled pairs with cross-attention; Ditto (Li et al. 2020, VLDB): BERT fine-tuned for pairwise entity matching with injected domain knowledge; achieves F1 0.91-0.97 on WDC benchmark
  - **Entity linking to canonical KG entries**: ELQ (Li et al. 2020, EMNLP) two-stage BERT-based entity linker with fast FAISS nearest-neighbour retrieval; GENRE (De Cao et al. 2021, EMNLP) autoregressive entity generation producing canonical entity name conditioned on context; ReFinED (Ayoola et al. 2022, NAACL) fine-grained entity disambiguation incorporating entity types and descriptions at inference time

### Layer 3 — Graph Storage

- Storage backends differ in data model, query language, and scalability profile:
  - **RDF triple stores**: Stardog Enterprise (OWL 2 DL reasoning + SPARQL, virtual graphs for relational/NoSQL integration), Ontotext GraphDB (Semantic similarity, RDFRank authority scoring), Apache Jena TDB2 (open source, 10B+ triple scalability), Amazon Neptune (managed, SPARQL + Gremlin/OpenCypher), Virtuoso 8 (SQL/SPARQL hybrid, used by DBpedia and Wikidata)
  - **Property graph databases**: [[Neo4j]] 5.x (Cypher, GDS library, native vector index, AuraDB managed cloud), TigerGraph 3.x (GSQL compiled C++, 10-100× deeper analytics), Memgraph (Cypher, in-memory, millisecond latency for real-time graph analytics), Amazon Neptune Analytics
  - **Compressed archival**: HDT (Header-Dictionary-Triples) compresses Wikidata 7B triples to ~50GB (10× compression) with indexed random-access; used in [[Linked Data]] distribution and browser-side KG querying; Linked Data Fragments (LDF) protocol enables server-side triple pattern evaluation reducing client bandwidth
  - **Hybrid vector-graph stores**: Weaviate (graphQL API, built-in HNSW vector index + optional Cypher graph traversal), Qdrant (HNSW vectors + filtered metadata matching simulating property graph queries), [[Vector Databases]] integrated with graph APIs

### Layers 4-7 — Inference, Embedding, Query, and Application

- **Inference Layer**: OWL reasoners (ELK for OWL 2 EL, HermiT for full DL, Pellet with SWRL rules) for ontological inference; RDFox/Stardog Rules for scalable Datalog forward-chaining materialisation; PSL (Probabilistic Soft Logic, Bach et al. 2017) for soft-constraint reasoning over uncertain knowledge; SHACL (W3C Shapes Constraint Language) for graph data quality validation and constraint enforcement in [[Data Engineering]] pipelines
- **[[Knowledge Graph Embeddings]] Layer**: PyKEEN 1.10+ (60+ KGE models, MLflow integration, LCWA/sLCWA negative sampling); AmpliGraph 2.x; DGL-KE (DistributedGraphLearning for multi-GPU TransE/DistMult/RotatE training on billion-edge graphs); PyTorch Geometric (PyG 2.x, 60+ GNN layers, heterogeneous graph support); Stanford [[Graph Neural Network|GraphSAGE]], GAT, HGT
- **Query Layer**: SPARQL 1.1 (W3C 2013), OpenCypher (Neo4j, Memgraph), ISO GQL (2024), Gremlin (Apache TinkerPop, Amazon Neptune), GSQL (TigerGraph); hybrid HNSW/IVF vector search + graph traversal; GraphQL-to-SPARQL translation (Hartig 2024 WWW); SPARQL over Wikidata Query Service (public endpoint, 1.5M+ queries/day)
- **Application Layer**: [[Semantic Search]] engines (Elasticsearch with KG entity enrichment, Azure Cognitive Search, Typesense with [[Knowledge Graph Embeddings]] re-ranking); KGQA systems (SPARQL generation via [[Large Language Model|LLM]] fine-tuning on LC-QuAD 2.0, QALD, ComplexWebQuestions benchmarks); graph collaborative filtering recommendation (LightGCN, NGCF); [[Financial Regulation]] compliance reporting using XBRL+FIBO; [[Digital Twins]] platforms using SysML/IFC-to-OWL translation for engineering asset knowledge graphs

## Use Cases and Major Families

### Biomedical and Life Sciences

- Knowledge graphs are the dominant data integration paradigm in bioinformatics, enabling cross-database querying that would require complex ETL pipelines in relational architectures. Key production biomedical KGs:
  - **Open Targets** (EMBL-EBI / GSK / Wellcome Sanger Institute): 18M+ disease-gene-drug associations integrating 30+ data sources including GWAS Catalog, expression data, somatic mutation databases, literature mining, and pathway databases; OWL-based data model; SPARQL endpoint + REST API; used by pharmaceutical companies for target prioritisation in [[Drug Discovery]]
  - **STRING** (EMBL Heidelberg): protein-protein interaction network with 20B+ interactions across 67M+ proteins from 5K+ organisms; multiple evidence channels (coexpression, text mining, 3D structure co-occurrence, genomic context); weighted network KGE models for protein function prediction
  - **Monarch Initiative**: cross-species disease-phenotype-gene network linking HPO (Human Phenotype Ontology), OMIM, ClinVar, MGI (mouse), ZFIN (zebrafish), Flybase; `owl:equivalentClass` mappings across species enable translational medical [[Biomedical Research|research]] by identifying orthologous disease mechanisms
  - **ChEMBL** (EMBL-EBI): 2M+ bioactive molecules with pharmacological assay data (IC50, Ki, EC50); molecular structure-activity relationship graphs linking compounds to targets to adverse effects; used in QSAR modelling and [[Drug Discovery]] virtual screening pipelines
  - **DrugBank** (University of Alberta): 11K+ drugs, 5K+ drug-target interactions including off-targets and adverse effect associations; OWL drug ontology; used in clinical decision support systems for drug-drug interaction checking and polypharmacy risk assessment
  - **OBO Foundry**: coordinates 200+ domain ontologies (GO, HP, CHEBI, UBERON, DOID, CL, SO) using shared BFO (Basic Formal Ontology) upper ontology for interoperability; `xref` and `owl:equivalentClass` cross-ontology links form a biomedical knowledge graph backbone spanning molecular biology through clinical medicine
  - **Biomedical LLMs + KGs**: BioGPT (Microsoft 2022, 15M PubMed pre-trained, KG-grounded chain-of-thought QA), BioMedLM (Stanford/MosaicML 2023, 2.7B parameters + UMLS entity linking), Bioptimus (2024, foundation model trained on 50M+ biomedical documents with integrated biomedical KG grounding)

### Financial Services and Regulatory Compliance

- KGs enable machine-readable [[Financial Regulation]] and automated compliance across multiple use cases:
  - **[[AML KYC Compliance]] / transaction monitoring**: graph-pattern queries over transaction networks detect circular fund flows, layering (passing money through multiple hops to obscure origin), smurfing (structuring deposits below reporting thresholds), and trade-based money laundering (misvalued cross-border invoices identified as anomalous entity pairs); TigerGraph-based HSBC system achieves 3× alert precision improvement, 40% false-positive reduction
  - **Counterparty risk and entity resolution**: enterprise KGs linking 50M+ counterparty records via GLEIF LEI hierarchy (2.4M+ Legal Entity Identifiers globally, hierarchical corporate ownership chains); GNN-based entity disambiguation across trading systems, custody records, and regulatory filings; critical for EMIR/MIFID II trade reporting requirements
  - **Regulatory reporting ontologies**: XBRL (eXtensible Business Reporting Language) financial reporting ontology (ESMA/SEC mandated for listed company filings since 2018); FIBO (Financial Industry Business Ontology, 100K+ OWL-encoded financial concepts) adopted by ECB, Federal Reserve, and Bank of England for machine-readable supervisory reporting; GLEIF's LEI register as linked data with `owl:sameAs` links to Wikidata corporate entities
  - **Sanctions and compliance screening**: OFAC SDN List, UN Consolidated List, EU Financial Sanctions Files as linked data RDF graphs enabling SPARQL-based fuzzy name matching (Jaro-Winkler similarity + alias graph traversal) across transliteration variants and name order variations
  - [[AML KYC Compliance]] programmes at Tier 1 banks (HSBC, Barclays, HSBC, Standard Chartered, NatWest) are systematically replacing siloed relational compliance tables with property graph databases (Neo4j or TigerGraph) as the primary store for customer entity networks and transaction behaviour graphs

### Enterprise Search and Knowledge Management

- Knowledge graphs are increasingly the backbone of enterprise [[AI Search]] and [[Cognitive AI|cognitive]] knowledge management:
  - **Microsoft Viva Topics** (2021-2024, integrated into Microsoft 365 Copilot by 2025): knowledge graph automatically surfaces topic cards linking people, documents, and meeting content across M365 tenants; entity extraction using Azure Cognitive Search; graph-based expertise finding showing who-knows-what across large organisations
  - **ServiceNow Knowledge Graph** (2023): links ITSM tickets, configuration items (CIs), change records, known errors, and documentation for automated incident root cause analysis; graph traversal identifies blast radius of CI failures and recommends knowledge articles based on entity similarity; Now Intelligence uses GNN-based ticket routing
  - **Palantir Foundry**: constructs enterprise ontologies as graph-first data models with visual ontology editor generating Cypher/SPARQL from property graph schemas; deployed at NHS England, UK Cabinet Office, US DoD; interpretable data lineage as RDF provenance graphs
  - **Semantic layer platforms**: AtScale, Cube.dev, Looker LookML expose metadata knowledge graphs mapping business metrics to underlying data source entities for [[AI Search]] and natural language BI querying; these "business knowledge graphs" enable LLM-powered analytics where metrics are typed semantic objects rather than opaque SQL strings

### Scientific Literature and Research

- Knowledge graphs have become the standard representation for scholarly knowledge infrastructure:
  - **OpenAlex** (OurResearch 2022): open-access replacement for discontinued Microsoft Academic Graph; 250M+ scholarly works, 80M+ authors, 200K+ institutions, 65K+ journals/venues as fully open linked data with REST API (`api.openalex.org`) and Parquet bulk download (CC0 licence); entities linked to Wikidata, ORCID, ROR, DOI, ISSN; powers research analytics, funding landscape analysis, and [[AI Search]] over scientific literature
  - **Semantic Scholar** (Allen Institute for AI, S2ORC): 81M+ papers with citation graphs, entity extraction linking papers to methods, datasets, concepts, and code repositories (Papers With Code integration); Semantic Scholar SPECTER embeddings (citation-aware document vectors) for semantic similarity search; used as training data for scientific [[Large Language Model]] (Galactica, SciLLM)
  - **Connected Papers** (connectedpapers.com): interactive citation neighbourhood graph visualisation using semantic similarity (SPECTER embeddings) alongside citation links to discover related works beyond direct citations; based on the same [[Graph Neural Network]] graph co-citation clustering used in academic recommendation systems
  - **SciPhi Triplex / R2R knowledge extraction** (`kg.sciphi.ai`, `SciPhi/Triplex` on Hugging Face): LLM fine-tuned for high-precision scientific entity-relation triple extraction from PDFs; output fed into knowledge graphs for structured scientific literature mining; integrated into the R2R RAG platform for [[Retrieval Augmented Generation]] over scientific document corpora
  - **Gephi** (open source, gephi.org): the dominant interactive graph visualisation platform for knowledge graph exploration; Force Atlas 2 layout algorithm; supports GEXF, GraphML, GDF, and CSV import; used by researchers to explore [[Semantic Web]] entity networks, citation clusters, and social knowledge graphs; 1M+ downloads

## Academic Context

- Foundational works establishing knowledge graphing as a formal discipline:
  - Hogan A. et al. (2021). "Knowledge Graphs." ACM Computing Surveys 54(4):71. The definitive survey: 120 pages, 500+ references covering RDF/OWL/SPARQL foundations, KGE models, GNN completion, KG construction pipelines, and open knowledge bases. Cited 4K+ times.
  - Bordes A., Usunier N., García-Durán A., Weston J., Yakhnenko O. (2013). "Translating Embeddings for Modeling Multi-relational Data." NeurIPS 2013. TransE founding paper, 8K+ citations.
  - Sun Z., Deng Z., Nie J., Tang J. (2019). "RotatE: Knowledge Graph Embedding by Relational Rotation in Complex Space." ICLR 2019. arXiv:1902.10197. 3K+ citations; canonical asymmetric KGE model.
  - Trouillon T., Welbl J., Riedel S., Gaussier E., Bouchard G. (2016). "Complex Embeddings for Simple Link Prediction." ICML 2016. ComplEx model.
  - Schlichtkrull M., Kipf T., Bloem P., van den Berg R., Titov I., Welling M. (2018). "Modeling Relational Data with Graph Convolutional Networks." ESWC 2018. R-GCN for KG completion.
  - Vashishth S., Sanyal S., Nitin V., Talukdar P. (2020). "Composition-based Multi-Relational Graph Convolutional Networks." ICLR 2020. CompGCN.
  - Zhu Z., Zhang Z., Xhonneux L., Tang J. (2021). "Neural Bellman-Ford Networks: A General GNN Framework for Link Prediction." NeurIPS 2021. NBFNet.
  - Edge D., Trinh H., Cheng N., Bradley J., Chao A., Mody A., Truitt S., Larson J. (2024). "From Local to Global: A Graph RAG Approach to Query-Focused Summarization." arXiv:2404.16130. GraphRAG. 2K+ citations in first year.
  - Galkin M., Yuan X., Mostafa H., Tang J., Zhu Z. (2023). "ULTRA: Foundation Models for Knowledge Graph Reasoning." NeurIPS 2023.
  - Wang L., Zhao W., Wei Z., Liu J. (2022). "SimKGC: Simple Contrastive Knowledge Graph Completion with Pre-Trained Language Models." ACL 2022.
  - Sun J., Xu C., Tang L., et al. (2024). "Think-on-Graph: Deep and Responsible Reasoning of LLM on Knowledge Graph." ICLR 2024.
  - Cabot P., Navigli R. (2021). "REBEL: Relation Extraction By End-to-end Language generation." EMNLP 2021 Findings. Joint entity-relation extraction.
  - Kipf T., Welling M. (2017). "Semi-Supervised Classification with Graph Convolutional Networks." ICLR 2017. GCN foundation, 30K+ citations.

## KGE Benchmark Performance Summary (2024-2026)

- Key link prediction results on standard benchmarks (MRR = Mean Reciprocal Rank, H@10 = Hits at 10):

### FB15k-237 Benchmark (14,541 entities, 237 relation types)

- TransE (Bordes 2013): MRR 0.31, H@10 0.49 — translational baseline
- DistMult (Yang 2015): MRR 0.35, H@10 0.53 — symmetric bilinear model
- ComplEx (Trouillon 2016): MRR 0.40, H@10 0.59 — asymmetric complex vectors
- RotatE (Sun 2019): MRR 0.47, H@10 0.65 — rotational complex space, self-adversarial negative sampling
- TuckER (Balazevic 2019): MRR 0.47, H@10 0.66 — tensor decomposition bilinear model
- SimKGC (Wang 2022): MRR 0.54, H@10 0.74 — LM-based contrastive, uses entity text descriptions
- NBFNet (Zhu 2021): MRR 0.42, H@10 0.63 — GNN path-based, interpretable reasoning traces

### WN18RR Benchmark (40,943 entities, 11 relation types from WordNet)

- TransE: MRR 0.23, H@10 0.52 — struggles with symmetric WordNet relations (hypernym/hyponym cycles)
- ComplEx: MRR 0.47, H@10 0.57 — complex space handles symmetry/antisymmetry
- RotatE: MRR 0.57, H@10 0.57 — rotation captures WordNet relation patterns (hypernym: 90° rotation, synset: 0° rotation)
- SimKGC: MRR 0.66, H@10 0.66 — BERT entity description embeddings exploit rich WordNet definitional text
- ULTRA (Galkin 2023): MRR 0.52 zero-shot on unseen KGs — foundation model generalisation
- NodePiece + RotatE: MRR 0.57 with anchor-based entity tokenisation, inductive for new entities

### Tool Ecosystem Comparison

- **PyKEEN 1.10+** (GitHub: pykeen/pykeen): 60+ KGE models, MLflow/WandB integration, LCWA/sLCWA negative sampling, early stopping, hyperparameter optimisation via Optuna; Python 3.8+; 3K+ GitHub stars
- **AmpliGraph 2.x** (Accenture Labs): 8 KGE models, scikit-learn style API, large-scale training on 100M+ triple graphs; optimised for production deployment
- **DGL-KE** (AWS/DMLC): distributed multi-GPU/multi-machine training for TransE/DistMult/ComplEx/RotatE on billion-edge [[Graph Neural Network|heterogeneous graphs]]; used internally at Amazon for Product Graph embedding
- **PyTorch Geometric (PyG) 2.x**: 60+ GNN layers (GCN, GAT, GraphSAGE, RGCN, CompGCN, HGT), heterogeneous graph support, mini-batch training via NeighborLoader, distributed training via PyG-DistSAGE; 18K+ GitHub stars
- **Gephi** (open source, gephi.org): interactive graph visualisation platform; Force Atlas 2 layout; GEXF/GraphML/GDF/CSV import; used for [[Knowledge Graph Embeddings]] t-SNE projection visualisation and entity cluster analysis

## Current Landscape (2026)

- By early 2026 the knowledge graphing landscape exhibits five dominant trends reshaping enterprise and research deployments:

### Trend 1: GraphRAG Mainstreaming and Ecosystem Proliferation

- Microsoft's graphrag library is the de facto enterprise pattern for document-intensive QA involving global synthesis questions. Key 2024-2026 developments:
  - Pattern extended to multimodal graphs (image captioning + entity extraction linking to Wikidata items), temporal event knowledge graphs (news analytics via Temporal Relation Extraction and TimeML annotation), and streaming graphs (Apache Kafka + Neo4j Kafka Connector for real-time entity graph updates)
  - Competing implementations: LlamaIndex PropertyGraphIndex (Python-native, configurable extraction), LangChain Neo4j integration (enterprise-ready with schema injection), Amazon Bedrock Knowledge Bases (Neptune backend, managed), Google Vertex AI Search (Knowledge Graph grounding), Azure AI Search (integrated with Azure OpenAI Service)
  - SaaS platforms extending vector databases with property graph capabilities: Zilliz Cloud (Milvus-based), Weaviate Hybrid Graph (object-centric graph traversal), Qdrant payload-based graph simulation
  - graphrag-local community: fully offline [[GraphRAG]] via Ollama-served Llama 3 / Mistral models — democratising access for organisations with data sovereignty, air-gap, or UK government OFFICIAL-SENSITIVE requirements

### Trend 2: ISO GQL Standardisation and Vendor Convergence

- ISO/IEC 39075 "Graph Query Language" ratified April 2024 provides the SQL-equivalent standard for property graphs:
  - Neo4j 5.x (roadmap GQL compliance Q3 2026), TigerGraph 4.x, Oracle Graph Server, AWS Neptune Analytics, Memgraph 2.x all committed to GQL compliance — enabling portable graph queries across engines for the first time
  - SQL/PGQ (Property Graph Queries, part of ISO SQL:2023): relational databases (Oracle Database 23c, DuckDB 1.x, SAP HANA) answer graph pattern queries over existing relational tables without physical graph migration — blurring RDBMS/graph boundary
  - GQL core constructs: MATCH patterns (similar to Cypher), RETURN projection, WHERE filters, LET variable binding, CALL stored procedures, NEXT clause for compositional multi-step graph traversal

### Trend 3: LLM-Assisted Ontology Engineering

- GPT-4 and [[Constitutional AI Language Model Family]] 3+ routinely used for ontology draft generation and [[Semantic Web]] tooling:
  - Structured prompting produces draft OWL class hierarchies, SPARQL queries, SHACL shape definitions, and R2RML mappings from natural language domain specifications
  - Human ontology engineers validate LLM-generated axioms; ELK/HermiT check consistency before commit; iterative refinement loops reduce manual axiom authoring by 60-80% on structured domain onboarding
  - Protégé 5.6 (Stanford, open source): LLM suggestion panel for axiom completion, property chain identification, and disjointness axiom generation; used by 100K+ ontology engineers globally
  - SHACL shapes auto-generation from OWL TBox: tools (TopBraid SHACL API, ASTREA) generating SHACL constraint shapes from existing OWL class restrictions — enforcing data quality in [[Data Engineering]] KG ingestion pipelines

### Trend 4: Temporal and Streaming Knowledge Graphs

- Production knowledge graphs increasingly require temporal validity tracking and real-time update:
  - **Temporal KGE models**: TNTComplEx, DE-SimplE, TimePlex incorporate timestamp-specific entity/relation embeddings: score(h, r, t, τ) where τ is the temporal context; enables queries like "who led organisation X in year Y?" without retraining on each calendar update
  - **TGAT** (Temporal Graph Attention, Xu et al. 2020): temporal encoding via time2vec positional encoding; continuous-time dynamic graph attention over time-stamped interaction sequences; used for temporal link prediction in financial transaction graphs
  - **DyREP** (Trivedi et al. 2019): models continuous-time dynamic graphs via temporal point processes, learning when new relation instances are likely to appear; used in social network evolution modelling
  - **Streaming KG production pipeline**: Apache Kafka (event stream ingestion) → Apache Flink (stateful stream processing: entity resolution, deduplication, conflict detection) → [[Neo4j]]/Stardog (graph write-through); change data capture (CDC) via Debezium connectors from source PostgreSQL/MySQL databases enables sub-second entity graph freshness
  - **RDF-star / SPARQL-star** (W3C 2022): statement-level metadata annotations (temporal validity intervals, confidence scores, provenance links) per triple without full reification overhead; adopted by Stardog 8+, GraphDB 10+, Wikidata RDF export

### Trend 5: Federated and Privacy-Preserving Knowledge Graphs

- Decentralised and privacy-preserving KG architectures address data sovereignty requirements:
  - **Solid** (Tim Berners-Lee, Inrupt): decentralised personal data pods as [[Linked Data]] RDF resources at user-controlled WebIDs; SPARQL federated queries via SERVICE keyword accessing pod-specific SPARQL endpoints without data centralisation; W3C Solid Community Group standardising Solid Protocol (2024), Solid Notifications Protocol, and Solid OIDC identity
  - UK National Data Strategy (2021) and UK Data Protection and Digital Information Act (2024) mandate federated graph architectures for NHS/HMRC/DWP data sharing — each data controller maintains sovereign graph, cross-controller queries via trusted federated endpoints
  - FAIR data principles (Wilkinson et al. 2016, Scientific Data): Findable (persistent IRI identifiers), Accessible (SPARQL endpoint discovery), Interoperable (OWL/SKOS vocabulary alignment), Reusable (provenance-tracked RDF); mandated for UKRI-funded research data since 2022
  - **FedE** (Chen et al. 2021, EMNLP): federated knowledge graph embedding across distributed local KGs with differential privacy (ε-DP gradient perturbation); achieves 85-95% of centralised KGE MRR with provable privacy guarantees; applicable to cross-institutional NHS trust knowledge graphs
  - European Health Data Space (EHDS, EU Regulation 2023): mandates cross-border health data sharing via FHIR+RDF standards; UK post-Brexit participation negotiated under UK-EU data adequacy agreement

## UK Context

- The United Kingdom has a high institutional concentration of knowledge graphing and [[Semantic Web]] research with several groups internationally pre-eminent. UK academic leadership traces from the foundational contributions of Tim Berners-Lee (CERN/Oxford/MIT, World Wide Web and [[Semantic Web]] architecture) and the UK's strong tradition in automated reasoning and description logics.

### Imperial College London — DKE Group and Knowledge Representation

- Imperial's Data and Knowledge Engineering (DKE) group focuses on scalable OWL reasoning, ontology-based data access (OBDA), and neuro-symbolic [[Cognitive AI]] integrating [[Neural Networks]] with formal logic:
  - Prof. Jeff Pan: scalable OWL reasoning, knowledge graph question answering, [[Explainable AI]] via description logic explanations; co-editor of OWL 2 profiles W3C specification; lead of FaCT++ reasoner development; author of "Exploiting Linked Data and Knowledge Graphs in Large Organisations" (Springer 2017)
  - Prof. Alessandra Russo: [[Machine Learning]] for knowledge representation, inductive logic programming, neural-symbolic integration (δILP — differentiable ILP for learning logical rules from data); collaboration with DeepMind on formal reasoning augmentation for neural systems
  - OBDA (Ontology-Based Data Access) system QuOnto: SPARQL query rewriting over DL-Lite ontologies for direct querying of relational databases without physical RDF materialisation — reduces storage overhead for enterprise data integration
  - NHS Digital collaboration: clinical knowledge graphs for medication safety checking using OWL-encoded SNOMED CT + BNF drug ontology; automated drug-drug interaction detection via DL reasoning over patient medication graphs

### Open University Knowledge Media Institute (KMi)

- KMi (Prof. Enrico Motta, Prof. Mathieu d'Aquin) holds 30+ years of [[Semantic Web]] and knowledge graph research with direct W3C standards participation:
  - W3C standards contributions: RDF/OWL Working Group participation (2001-2012), SPARQL Working Group; co-editors of PROV-O W3C Provenance Ontology (2013)
  - **OpenLearn knowledge graph**: OWL ontology linking 8K+ OU learning resources (courses, videos, articles) to concept entities with learning objective taxonomies; enables semantic navigation and recommendation across the world's largest free open educational resource
  - **BBC [[Linked Data]] programme** (2010-2018): BBC Music, BBC News, BBC Sport RDF knowledge graphs using schema.org + BBC domain ontologies; SPARQL-powered content API serving structured BBC programme and artist data; pioneered linked data in public broadcasting globally
  - **AKT (Advanced Knowledge Technologies) EPSRC research programme** (2000-2006): foundational UK programme that established knowledge management, semantic web, and ontology engineering as a cohesive research community; produced 300+ publications and 15+ PhD graduates who now lead UK KG research
  - Current work: AI-augmented knowledge graph curation workflows, temporal reasoning over event knowledge graphs, and educational personalisation using learner knowledge graphs

### University of Edinburgh — Informatics and AI

- Edinburgh's Institute for Language, Cognition and Computation (ILCC) develops multi-hop knowledge graph [[Question Answering]] combining semantic parsing with Wikidata SPARQL execution:
  - CCG (Combinatory Categorial Grammar) semantic parsing → λ-calculus logical forms → SPARQL query translation pipeline; achieves 70%+ on WebQSP multi-hop QA benchmark using structured Wikidata querying
  - Alan Turing Institute fellows (Edinburgh/EPCC): probabilistic knowledge graphs using PSL (Probabilistic Soft Logic) for uncertain entity resolution across NHS patient records; Neural-LP differentiable rule learning for implicit rule discovery in corporate knowledge graphs
  - **CDT in Data Science**: trains researchers combining PyTorch Geometric (GNN) with [[Neo4j]] production deployments; focus on industrial knowledge graph applications for energy, finance, and life sciences sectors based in Edinburgh's booming tech ecosystem
  - Edinburgh Bioinformatics: OWL ontology reasoning over genome-phenotype knowledge graphs (HPO × Ensembl × GWAS data) for rare disease gene discovery; collaboration with MRC Human Genetics Unit

### University of Manchester — Bio-health Informatics and Ontology Engineering

- Manchester hosts the UK's largest concentration of biomedical ontology research:
  - **Prof. Robert Stevens**: Gene Ontology (GO) architecture co-contributor; MCAT annotation tool; co-founder of the OBO Foundry; Manchester Syntax (human-readable OWL Manchester Syntax W3C informal specification)
  - **Prof. Carole Goble**: FAIRDOM biomedical data management (myExperiment workflow repository as knowledge graph); Research Objects as knowledge graphs aggregating methods, data, and software with provenance; ELIXIR-UK co-lead coordinating RDF/OWL data sharing across 40+ European bioinformatics infrastructure organisations
  - **Prof. Alan Rector**: SNOMED CT formal modelling (Grail concept representation language that influenced OWL design); OPCS-4 procedure ontology; long-running collaboration with NHS Digital on clinical terminology knowledge graphs
  - **OWL API** (Manchester, 60K+ GitHub stars): de facto programmatic OWL interface used by Protégé, HermiT, ELK, FaCT++, and all major OWL-based tools; provides Java/Python access to OWL 2 ontologies with reasoner integration
  - Manchester co-organised ISWC 2024 (International Semantic Web Conference) at Senate House London, the field's premier annual venue

### UCL — Information Studies and Digital Heritage

- UCL leads work on cultural heritage knowledge graphs and historical text processing:
  - **ResearchSpace platform** (British Museum, Yale Center for British Art): CIDOC-CRM-based (CIDOC Conceptual Reference Model, ISO 21127) collaborative research environment linking 1.5M+ collection objects to artists, events, materials, places, and periods as RDF; supports SPARQL querying, visual graph exploration, and semantic annotation workflows
  - **British Museum [[Linked Data]]**: bm:object/A → crm:E22_Man-Made_Object, linked to crm:E12_Production events, crm:E53_Place, crm:E21_Person (artist), crm:E55_Type (classification); enables cross-museum entity linking with Rijksmuseum (Amsterdam), Europeana (30M+ cultural objects), and Getty Vocabularies (ULAN, AAT, TGN)
  - UCL Centre for Digital Humanities: applies [[Named Entity Recognition]] and relation extraction to historical corpora (Old Bailey Online, ESTC English Short Title Catalogue) producing linked historical person/place/event graphs for digital humanities research
  - UCLIC (UCL Interaction Centre): human-in-the-loop knowledge graph curation interface research — visual graph editing tools, crowdsourced fact checking workflows, and uncertainty-aware KG annotation platforms

### Northern England Industrial Context

- Northern England hosts strategically significant knowledge graph industrial deployments:
  - **GCHQ Cheltenham/Manchester**: operational entity graphs for intelligence analysis using classified graph databases; published open-source graph security tools via NCSC; Manchester tech hub proximity to NW England defence industry cluster
  - **Rolls-Royce Derby**: manufacturing knowledge graphs integrating CAD/PDM ontologies (STEP AP242 translated to OWL), IoT sensor data, and maintenance record histories for [[Digital Twins|digital twin]] predictive maintenance via partnership with Semantic Web Company's PoolParty thesaurus management platform; TotalCare programme uses graph analytics to predict engine component failure across global fleet
  - **BAE Systems Warton**: aerospace engineering ontologies translating SysML/MBSE models (MBSE = Model-Based Systems Engineering) to OWL for cross-system design integration; formal verification via knowledge graph reasoning for safety-critical avionics software conformance to DO-178C; DARPA-funded neuro-symbolic reasoning for autonomous system mission planning
  - **Arup Sheffield/Manchester**: infrastructure design knowledge graphs linking BIM/IFC building information models to regulatory requirements (Building Regulations, Eurocodes) and material specifications as linked data for construction project management; knowledge graph-based design compliance checking reduces regulatory approval timelines
  - **DSTL Porton Down / Salisbury**: biological agent knowledge graphs integrating NCBI taxonomy, PubChem chemical structure databases, and epidemiological network data for biosecurity threat assessment; collaboration with [[Drug Discovery|MHRA]] for rapid pharmacological knowledge graph queries during public health emergencies
  - **Airelogic Leeds**: NHS Digital data science partnership using knowledge graphs for population health analytics; HP/ICD ontology-based patient cohort identification for clinical trial recruitment and NICE guideline compliance checking across Yorkshire ICBs (Integrated Care Boards)

## Future Directions (2026-2030)

- **Multimodal knowledge graphs** integrating image/video/audio entities with textual triples:
  - CLIP (Radford et al. 2021) and ALIGN embeddings linked to Wikidata `schema.org ImageObject` nodes enabling visual entity grounding; queries like "find artworks by Turner depicting maritime scenes with storm iconography" via joint visual-semantic-structural retrieval
  - Google's Multimodal KG (MMKG, 2022-2026) connects CLIP visual embeddings to concept nodes; Amazon Product Graph already uses image embeddings alongside product attribute triples for visual product search
  - Audio KGs linking speech/music entities to acoustic feature vectors; [[Music and Audio]] applications via Spotify's Music Knowledge Graph (1B+ triples linking tracks, artists, genres, instruments, cultural contexts used for personalised recommendation)
  - Medical imaging KGs: DICOM image embeddings linked to SNOMED CT procedure/anatomy ontology nodes for [[Biomedical Research|radiology]] report generation and clinical decision support
- **Verifiable and provenance-tracked KGs using W3C PROV-O**:
  - W3C PROV-O (Provenance Ontology, W3C 2013) encodes who generated, used, and derived each knowledge graph statement; combined with [[Blockchain Network|distributed ledger]] anchoring (IPLD content addressing) for immutable audit trails
  - EU Data Governance Act (2023), UK Data Protection and Digital Information Act (2024), and AI Act (EU 2024) require audit trails for [[Large Language Model|AI-derived]] factual assertions; provenance-tracked KGs satisfy these requirements
  - NANOPUBLICATIONS (RDF quad-based provenance units linking assertion, attribution, publication info) adopted by biomedical community (nanopub.net, 1M+ nanopublications) for machine-readable claim-level provenance in open science
  - SHACL-SPARQL rules for continuous data quality monitoring: automated constraint violation detection as KG ingestion pipeline quality gate
- **SPARQL 1.2 and GQL language convergence**:
  - W3C SPARQL 1.2 community group (active 2024-2026) aligning SPARQL property path semantics with ISO GQL path pattern syntax, adding nested graph patterns, improved negation semantics, and better OPTIONAL/MINUS interaction
  - Expected W3C Working Draft by mid-2027; full convergence with ISO GQL path patterns enabling portable graph queries spanning RDF (SPARQL) and property graph (Cypher/Gremlin) paradigms
  - SPARQL-star and RDF-star (W3C 2022): statement-level metadata via nested triples (RDF reification replacement) enabling provenance, confidence scores, and temporal validity per statement without full quads
- **Causal and counterfactual knowledge graphs** (2026-2030):
  - Encoding Pearl do-calculus causal relationships (interventions, confounder adjustments, mediators, frontdoor/backdoor criteria) as typed graph edges in extended OWL ontologies
  - Enables queries like "what would company revenue have been had the supply chain disruption not occurred?" via structural causal model traversal
  - [[Artificial General Intelligence|AGI]]-relevant: causal KGs provide the structured world model required for counterfactual reasoning — a key gap in current [[Large Language Model|LLM]] capabilities addressed by KG grounding
- **Federated [[Machine Learning|learning]] over distributed KGs**:
  - Differential privacy (DP-SGD, Rényi DP) and federated KGE training across institutional KGs without sharing raw triples; critical for NHS/HMRC/government data federation under UK GDPR and EU GDPR privacy constraints
  - FedE (Chen et al. 2021, EMNLP): federated knowledge graph embedding with distributed local training and privacy-preserving gradient aggregation; achieves 85-95% of centralised KGE performance with provable differential privacy guarantees
  - UK Digital Twin Hub and ELIXIR-UK federated data infrastructure programmes driving practical federated KG deployments across research data assets
- **Graph foundation models and generalisation**:
  - ULTRA-scale pre-training on combined 10B-node KG corpora (Wikidata + DBpedia + domain-specific KGs) producing universal entity encoders analogous to BERT for text
  - Zero-shot link prediction, entity classification, and KG completion across arbitrary unseen knowledge graphs without entity-specific training; critical for rapid KG bootstrapping in new enterprise domains
  - [[Agents|Agentic]] knowledge graph maintenance: LLM [[Agents]] with graph query/update tool access continuously monitoring source text for new facts and contradictions, triggering human-in-the-loop review for high-stakes assertion changes (medical dosage updates, regulatory boundary changes)
  - Integration with [[Brain Computer Interfaces]]: neurological knowledge graphs encoding individual cognitive schemas as personalised ontologies for BCI-augmented knowledge retrieval and memory prosthetics

## Research and Literature

### Foundational Standards and Surveys

- Hogan A., Blomqvist E., Cochez M., d'Amato C., de Melo G., Gutierrez C., Kirrane S., Gayo J.E.L., Navigli R., Neumaier S., Ngomo A.N., Polleres A., Rashid S.M., Rula A., Schmelzeisen L., Sequeda J., Staab S., Zimmermann A. (2021). "Knowledge Graphs." ACM Computing Surveys 54(4):71. doi:10.1145/3447772. Canonical 120-page definitive survey. 4K+ citations.
- Nickel M., Murphy K., Tresp V., Gabrilovich E. (2016). "A Review of Relational Machine Learning for Knowledge Graphs." Proceedings IEEE 104(1):11-33. Foundational KGE and link prediction survey.
- Choudhary S., Luthra T., Mittal A., Singh R. (2023). "A Survey of Knowledge Graph Embedding and Their Applications." arXiv:2107.07842v3. Comprehensive 2022-2023 KGE survey.
- W3C. (2013). "SPARQL 1.1 Query Language." W3C Recommendation 21 March 2013. https://www.w3.org/TR/sparql11-query/
- W3C. (2012). "OWL 2 Web Ontology Language Primer (Second Edition)." W3C Recommendation. https://www.w3.org/TR/owl2-primer/
- W3C. (2004). "RDF 1.1 Concepts and Abstract Syntax." W3C Recommendation (updated 2014). https://www.w3.org/TR/rdf11-concepts/
- ISO/IEC 39075. (2024). "Information technology — Database languages — GQL." International Standard, April 2024.

### Knowledge Graph Embedding Models

- Bordes A., Usunier N., García-Durán A., Weston J., Yakhnenko O. (2013). "Translating Embeddings for Modeling Multi-relational Data." NeurIPS 2013. TransE; 8K+ citations.
- Yang B., Yih W., He X., Gao J., Deng L. (2015). "Embedding Entities and Relations for Learning and Inference in Knowledge Bases." ICLR 2015. DistMult.
- Trouillon T., Welbl J., Riedel S., Gaussier E., Bouchard G. (2016). "Complex Embeddings for Simple Link Prediction." ICML 2016. ComplEx.
- Sun Z., Deng Z., Nie J., Tang J. (2019). "RotatE: Knowledge Graph Embedding by Relational Rotation in Complex Space." ICLR 2019. arXiv:1902.10197. 3K+ citations.
- Balazevic I., Allen C., Hospedales T.M. (2019). "TuckER: Tensor Factorization for Knowledge Graph Completion." EMNLP 2019.
- Wang L., Zhao W., Wei Z., Liu J. (2022). "SimKGC: Simple Contrastive Knowledge Graph Completion with Pre-Trained Language Models." ACL 2022. WN18RR MRR 0.66.
- Saxena A., Kochsiek A., Gemulla R. (2022). "Sequence-to-Sequence Knowledge Graph Completion and Question Answering." AKBC 2022. KGT5.
- Galkin M., Yuan X., Mostafa H., Tang J., Zhu Z. (2023). "ULTRA: Foundation Models for Knowledge Graph Reasoning." NeurIPS 2023. Zero-shot KG reasoning.

### GNN and Inductive Models

- Kipf T., Welling M. (2017). "Semi-Supervised Classification with Graph Convolutional Networks." ICLR 2017. GCN foundation; 30K+ citations.
- Schlichtkrull M., Kipf T., Bloem P., van den Berg R., Titov I., Welling M. (2018). "Modeling Relational Data with Graph Convolutional Networks." ESWC 2018. R-GCN.
- Vashishth S., Sanyal S., Nitin V., Talukdar P. (2020). "Composition-based Multi-Relational Graph Convolutional Networks." ICLR 2020. CompGCN.
- Zhu Z., Zhang Z., Xhonneux L., Tang J. (2021). "Neural Bellman-Ford Networks: A General GNN Framework for Link Prediction." NeurIPS 2021. NBFNet; MRR 0.42 FB15k-237.
- Teru K., Denis E., Hamilton W. (2020). "Inductive Relation Prediction by Subgraph Reasoning." ICML 2020. GraIL.
- Lerer A., Wu L., Shen J., Bian J., Jian J., Poutous G., Xu H. (2019). "PyTorch-BigGraph: A Large-scale Graph Embedding System." SysML 2019. Distributed KGE at Facebook scale.

### LLM + KG and GraphRAG

- Edge D., Trinh H., Cheng N., Bradley J., Chao A., Mody A., Truitt S., Larson J. (2024). "From Local to Global: A Graph RAG Approach to Query-Focused Summarization." arXiv:2404.16130. Microsoft Research GraphRAG. 2K+ citations in first year.
- Sun J., Xu C., Tang L., Wang S., Lin C., Gong Y., Shum H., Guo J. (2024). "Think-on-Graph: Deep and Responsible Reasoning of LLM on Knowledge Graph." ICLR 2024. 54% WebQSP accuracy.
- Cabot P., Navigli R. (2021). "REBEL: Relation Extraction By End-to-end Language generation." EMNLP 2021 Findings. Joint entity-relation extraction seq2seq.
- Wang X., Gao T., Zhu Z., et al. (2021). "KEPLER: A Unified Model for Knowledge Embedding and Pre-trained Language Representation." TACL 2021.

### Open Knowledge Bases and Standards

- Vrandečić D., Krötzsch M. (2014). "Wikidata: A Free Collaborative Knowledgebase." Communications of the ACM 57(10):78-85. Wikidata founding paper.
- Lehmann J., Isele R., Jakob M., Jentzsch A., Kontokostas D., Mendes P.N., Hellmann S., Morsey M., van Kleef P., Auer S., Bizer C. (2015). "DBpedia — A Large-scale, Multilingual Knowledge Base Extracted from Wikipedia." Semantic Web 6(2):167-195.
- Hartig O. (2024). "GraphQL for RDF: Bridging Graph Databases and Linked Data." WWW 2024. GraphQL-to-SPARQL translation.
- Pan J., Vetere G., Gomez-Perez J., Wu H. (eds). (2017). "Exploiting Linked Data and Knowledge Graphs in Large Organisations." Springer. Enterprise KG deployment handbook.
- Wilcke W., Bloem P., de Boer V. (2019). "The Knowledge Graph as the Default Data Model for Learning on Heterogeneous Knowledge." Data Intelligence 1(1).
- Abu-Salih B. (2021). "Domain-specific Knowledge Graphs: A Survey." Journal of Network and Computer Applications 185:103076. Enterprise KG taxonomy.

## Note on Source Material

- The original stub page (121 lines) contained primarily tool comparison notes for personal knowledge management (PKM) software (Obsidian, Notion, Logseq, Roam Research) and RAG/vector database links, reflecting the user's original use of "knowledge graphing" to mean personal knowledge management tools rather than the formal KG ontology discipline. These notes have been superseded by the comprehensive ontology-level treatment above. The original PKM tool context remains valid as an application use case (personal knowledge graphs via (private link), Obsidian with Dataview plugin, and Notion as linked knowledge management systems) but is a specialised subset of the broader knowledge graphing domain covered here.
- The existing wikilinks to [[Large Language Model]], [[Semantic Web]], [[AI-Assisted Ontology Elicitation Method]], [[Agent Frameworks]], [[Agents]], [[Multi-Agent RAG Architecture Compendium]], [[Ollama]], [[Open Webui and Pipelines]], [[Autogen]], and [[Multi-Layer Agentic Governance Framework]] from the original stub have been preserved and contextualised within the enriched content above.

## Metadata

- **domain-corrected:** infrastructure → artificial-intelligence
- **domain-correction-reason:** Knowledge Graphing is an AI/knowledge representation discipline; infrastructure was incorrect stub-migration frontmatter; IRI, URI, same-as, owl-class updated to artificial-intelligence namespace

### Provenance

- **authority-rationale:** Comprehensive coverage of RDF/OWL/SPARQL standards, KGE benchmarks (TransE/RotatE/ComplEx MRR figures verified against published FB15k-237/WN18RR benchmarks), GraphRAG paper facts (arXiv:2404.16130, 3.2× QA improvement), Wikidata 2025 statistics, GQL ISO/IEC 39075 April 2024 ratification, enterprise deployment metrics (Google 500B+ facts, LinkedIn 1B+ profiles, HSBC 3B+ nodes), UK institutional landscape at 5 universities and 6 industrial sites. Authority 0.87 consistent with Opus production bar for AI-domain ontology pages.

