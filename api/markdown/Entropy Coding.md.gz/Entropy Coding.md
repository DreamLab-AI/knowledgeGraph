Entropy coding is a class of lossless data-compression techniques that assign shorter codewords to more frequent symbols and longer codewords to rarer ones, approaching the information-theoretic entropy limit of a source. Methods such as Huffman coding and arithmetic coding form the final, lossless stage of most image, audio, and video codecs, packing quantised data into a compact bitstream. Because it discards no information, entropy coding can be perfectly reversed during decoding.

- Entropy Coding is a [[Lossless Compression]] family that exploits symbol probabilities to approach the [[Entropy]] limit of a source, serving as the final stage of a [[Codec]] and a core part of [[Data Compression]].
- It assigns shorter representations to frequent symbols and longer ones to rare symbols, packing [[Data Encoding]] into a minimal bitstream.

### Overview

- Entropy coding rests on Shannon's source-coding theorem, which establishes the entropy of a source as a lower bound on the average number of bits needed to represent its symbols losslessly.
- In practice it appears as the back end of compression pipelines: a transform and quantisation stage produces symbols whose statistics are then squeezed by an entropy coder. The two dominant families are Huffman coding, which builds an optimal prefix code from a symbol-frequency tree, and arithmetic coding, which represents an entire message as a single fractional number within an interval.
- Modern variants such as range coding and context-adaptive binary arithmetic coding (CABAC) adapt their probability models on the fly, improving efficiency for non-stationary sources.

### Mechanisms

- Symbol-frequency analysis estimates the probability distribution that drives codeword length.
- Prefix codes guarantee unambiguous decoding without separator markers.
- Arithmetic coding subdivides a numeric interval in proportion to symbol probabilities, achieving fractional-bit efficiency.
- Adaptive models update probabilities as data is processed, removing the need to transmit a static table.
- Context modelling conditions probabilities on neighbouring symbols, capturing local structure.

### Applications

- The lossless final stage of [[Image Compression]] formats such as JPEG and PNG.
- The bitstream packing layer of [[Video Compression]] standards and [[Video Codec]] implementations.
- Audio codecs and general-purpose archivers that combine entropy coding with dictionary methods.
- File and stream formats where minimising [[Bitrate]] without information loss is essential.

### Provenance

