The International Chamber of Commerce (ICC) is a business organisation that publishes the Incoterms rules. It describes itself as the world's business organisation and as the institutional representative of 45 million companies in more than 170 countries, making it easier for businesses to trade internationally.[^1]

## Incoterms

The ICC describes Incoterms rules as a set of eleven three-letter trade terms, reflecting business-to-business practice in contracts for the sale and purchase of goods.[^2] The European Commission's Access2Markets glossary describes Incoterms as eleven terms of sale accepted worldwide in assignment of costs and responsibilities between the buyer and the seller, proposed, updated and copyrighted by the ICC, serving as global standards for uniform interpretation of common contract clauses in international trade.[^3] UK Government guidance says that the terms are produced by the ICC, that the current version is Incoterms 2020, and that Incoterms 2020 has 11 terms.[^4] See [[Incoterms]] and [[Trade Term]].

## Role in the supply chain

The ICC is a [[Trade Body]] in this vault: a business organisation that represents companies, not governments. The ICC's own page also states over 100 years of legacy rooted in its conviction that trade is a force for good.[^1]

## What the sources do not establish

Its membership figures are its own and were not verified against an independent count. The sources opened do not describe the ICC's governance, its dispute resolution services or its founding in detail, and no source opened here gives a founding date. The Incoterms text itself is proprietary and is cited by rule name only; it is not reproduced.[^1][^2]

[^1]: International Chamber of Commerce, About ICC page. https://iccwbo.org/about-us/
[^2]: International Chamber of Commerce, “Incoterms® rules”. https://iccwbo.org/business-solutions/incoterms-rules/
[^3]: European Commission, Access2Markets, glossary entry for Incoterms. https://trade.ec.europa.eu/access-to-markets/en/glossary/incoterms
[^4]: Business.gov.uk, “Choosing the right incoterms”. https://www.business.gov.uk/export-from-uk/learn/categories/selling-across-borders-product-and-services-regulations-licensing-and-logistics/logistics-and-freight-forwarders/incoterms/

