A class of malware that denies victims access to their data or systems — typically by encrypting files with attacker-held keys, and increasingly by exfiltrating data for extortion — and demands payment, usually in cryptocurrency, for restoration or non-disclosure. Operated today as a service economy with affiliates, initial-access brokers, and leak sites, ransomware is among the most financially damaging cyber threats and the principal stress test of an organisation's backup, incident response, and disaster recovery posture.

### Semantic Classification

### Content

## Definition

**Ransomware** is [[Malware]] that weaponises the victim's own dependence on data availability. Classic crypto-ransomware enumerates files and encrypts them with a hybrid scheme — a symmetric key per file or volume, wrapped by an attacker-controlled public key — so that only payment yields the decryption capability. The attack turns strong [[Encryption]], normally a defensive technology, into the instrument of denial. Locker variants block system access without touching files; wiper-adjacent strains (NotPetya, 2017) mimic ransomware while making recovery impossible.

The modern threat is an economy rather than a program. Ransomware-as-a-service (RaaS) operators lease tooling and infrastructure to affiliates who conduct intrusions, splitting proceeds; initial-access brokers sell footholds obtained through phishing, stolen credentials, and unpatched edge devices — social engineering remains the leading entry vector. Since around 2019 the dominant playbook is **double extortion**: exfiltrate data first, then encrypt, so that even a victim with perfect backups faces a [[Data Breach]] disclosure threat via the gang's leak site. Payments are demanded in cryptocurrency, principally [[Bitcoin]] or Monero, with blockchain-analytics firms and sanctions regimes increasingly targeting the laundering pipeline.

Defence is correspondingly layered. Prevention centres on phishing-resistant authentication, patching of internet-facing services, and least-privilege segmentation to stop lateral movement. Resilience centres on immutable, offline, tested backups — the core of [[Disaster Recovery]] — because paying the ransom neither guarantees working decryptors nor removes the stolen data. Mature [[Incident Response]] plans rehearse the specific ransomware scenario: isolation, forensics, legal and regulatory notification (UK GDPR, NIS regulations), and the payment decision, on which official guidance from the NCSC and law enforcement is firmly against paying.

## Current Landscape

- **Scale**: annual global damages are estimated in the tens of billions of dollars; healthcare, education, manufacturing, and local government are disproportionately hit because downtime is intolerable.
- **Notable incidents**: WannaCry and NotPetya (2017), Colonial Pipeline and Kaseya (2021), MOVEit mass extortion (2023), the British Library attack (2023), and the Change Healthcare and Synnovis/NHS incidents (2024) illustrate supply-chain and critical-infrastructure exposure.
- **Ecosystem churn**: law-enforcement takedowns (LockBit's Operation Cronos, ALPHV's collapse in 2024) fragment groups without ending the model; affiliates migrate to successor brands.
- **Policy direction**: mandatory incident reporting, sanctions on payment facilitation, and proposals (including in the UK) to ban or require notification of ransom payments by public bodies and critical infrastructure operators.
- **Countermeasures**: EDR with behavioural detection of mass encryption, immutable object-lock backups, network segmentation, and rehearsed offline recovery are the consensus baseline.

  Dated developments (2024–2026):

- **UK policy (Jan/Feb 2025)**: the Home Office consulted on three legislative proposals — a targeted **ban on ransom payments** by all public-sector bodies and regulated Critical National Infrastructure operators; a **payment-prevention regime** (other victims must notify authorities before paying); and a mandatory **incident-reporting regime** (initial report within 72 hours, full report within 28 days).
- **Encryption → pure extortion**: Check Point's 2025 tracking shows a decisive shift away from file encryption toward data-theft-only extortion; the global ransom *payment* rate fell to a historic low of roughly 25–27%, driven by resilient backups and payment restrictions.
- **Ecosystem fragmentation**: after LockBit's disruption (Operation Cronos, Feb 2024; further internal-data leak May 2025) and the collapse of other brands, Q3 2025 saw a record ~85 active extortion/leak-site groups with the top 10 accounting for only ~56% of victims; **Qilin** became the most active operator, and LockBit re-emerged with LockBit 5.0 in September 2025.
- **UK threat picture**: the NCSC Annual Review 2025 recorded a 50% year-on-year rise in "highly significant" incidents (the third consecutive annual increase); the 3 June 2024 Synnovis/NHS pathology attack postponed over 10,000 outpatient appointments and 1,700 elective procedures across two London trusts.
- **Business prevalence (UK)**: the Cyber Security Breaches Survey 2025/2026 found ransomware affecting ~1% of businesses (down from 3% in the prior two years), with phishing still the dominant attack vector.

  **Sources**:

- https://www.gov.uk/government/consultations/ransomware-proposals-to-increase-incident-reporting-and-reduce-payments-to-criminals/ransomware-legislative-proposals-reducing-payments-to-cyber-criminals-and-increasing-incident-reporting-accessible
- https://research.checkpoint.com/2025/the-state-of-ransomware-q3-2025/
- https://www.ncsc.gov.uk/files/ncsc-annual-review-2025.pdf

