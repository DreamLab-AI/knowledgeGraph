Data quality management is the discipline of measuring, monitoring, and improving the accuracy, completeness, consistency, and timeliness of data across its lifecycle. It combines profiling, validation, cleansing, and continuous monitoring with governance policies that define quality expectations. Reliable data quality is a precondition for trustworthy analytics, machine learning, and regulatory reporting.

- Data quality management measures, monitors and improves the accuracy, completeness, consistency and timeliness of data across its lifecycle, combining profiling, [[Data Cleaning]] and continuous monitoring.
- It is a facet of [[Data Quality]], operates within [[Data Governance]], and is a precondition for trustworthy [[Data Analytics]] and [[Machine Learning]].

### Overview

- Data quality management begins by defining what "good" data means for a given use — the dimensions of accuracy, completeness, consistency, validity, uniqueness and timeliness.
- Profiling establishes a baseline; validation rules then enforce expectations as data flows through a [[Data Pipeline]].
- When defects are found, [[Data Cleaning]] corrects or quarantines records, while [[Data Observability]] tooling continuously watches for drift and freshness failures.
- Sustained quality requires governance: clear ownership, documented rules in a [[Data Catalogue]], and traceability via [[Data Lineage]].

### Key aspects

- Quality dimensions: accuracy, completeness, consistency, validity and timeliness as measurable targets.
- Validation: rule-based checks applied as data enters and moves through pipelines.
- Cleansing: correcting, standardising and deduplicating records through [[Data Cleaning]].
- Monitoring: ongoing [[Data Observability]] to detect regressions in quality over time.
- Governance integration: aligning quality rules with [[Data Governance]] policies and ownership.

### Mechanisms

- Profiling computes statistics and detects outliers to establish a quality baseline.
- Validation gates enforce constraints, supporting [[Data Integrity]] within the [[Data Pipeline]].
- [[Metadata Management]] and [[Data Lineage]] make quality issues traceable to their source.
- Remediation workflows route defects for correction and feed back into [[Master Data Management]].

### Applications

- Preparing reliable inputs for [[Data Analytics]] and [[Machine Learning]] models.
- Regulatory and financial reporting that demands auditable, accurate data.
- Consolidating golden records through [[Master Data Management]].
- Cataloguing trusted datasets in a [[Data Catalogue]] for self-service use.

### Provenance

