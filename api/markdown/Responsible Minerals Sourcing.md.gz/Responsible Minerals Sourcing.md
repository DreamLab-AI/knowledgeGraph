Responsible minerals sourcing is the practice of buying minerals under supply chain due diligence designed to avoid financing armed conflict and serious abuses, and the clearest legal statement in the sources opened here is the European Union's Conflict Minerals Regulation.[^1]

Regulation (EU) 2017/821 establishes a Union system for supply chain due diligence in order to curtail opportunities for armed groups and security forces to trade in tin, tantalum and tungsten, their ores, and gold.[^1] It defines supply chain due diligence as the obligations of Union importers in relation to their management systems, risk management, independent third-party audits and disclosure of information, with a view to identifying and addressing risks linked to conflict-affected and high-risk areas.[^1] The European Commission says the regulation aims to help stem the trade in the four minerals, which sometimes finance armed conflict or are mined using forced labour.[^2]

## OECD framework

Regulation (EU) 2017/821 refers to the OECD Due Diligence Guidance for Responsible Supply Chains of Minerals from Conflict-Affected and High-Risk Areas, and notes that in May 2011 the OECD Ministerial Council recommended active promotion of the observance of that Guidance.[^1] The Commission says the regulation requires importers to follow a five-step framework laid out by the OECD: establish company management systems, identify and assess risk in the supply chain, design and implement a strategy to respond to identified risks, carry out an independent third-party audit, and report annually.[^2] The OECD text was not opened; see [[OECD Due Diligence Guidance]].

## Industry assurance

The Responsible Minerals Initiative, an initiative of the Responsible Business Alliance founded in 2008, says it supports a due diligence ecosystem through standards for smelters, refiners and recyclers, data and collaborative actions across minerals supply chains.[^3] It says it does not validate minerals, material or mines.[^3]

## Scope and limits

This topic belongs to [[Sustainable Supply Chains]] and is an application of [[Supply Chain Due Diligence]]. The sources cover tin, tantalum, tungsten and gold and the EU regime; they do not cover cobalt or other minerals, and they do not report outcomes for conflict-affected communities. The Commission page and the Regulation are both EU sources.

[^1]: European Parliament and Council of the European Union, Regulation (EU) 2017/821 of 17 May 2017, “Regulation (EU) 2017/821 of the European Parliament and of the Council laying down supply chain due diligence obligations for Union importers of tin, tantalum and tungsten, their ores, and gold originating from conflict-affected and high-risk areas”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32017R0821
[^2]: European Commission, Directorate-General for Trade, “Conflict Minerals Regulation: The regulation explained”. https://policy.trade.ec.europa.eu/development-and-sustainability/conflict-minerals-regulation/regulation-explained_en
[^3]: Responsible Minerals Initiative (an initiative of the Responsible Business Alliance), “About the Responsible Minerals Initiative”. https://www.responsiblemineralsinitiative.org/about/

