Goods-to-person picking is an order picking method in which stock is brought to a stationary picker, so that the picker does not travel to the storage location.[^1]

Sources opened here use the term parts-to-picker rather than goods-to-person. A review of operations and supply chain management says parts-to-picker systems eliminate unproductive picker travel by delivering stock keeping units to workstations with stationary pickers, who may be humans or automated devices such as a robot arm. Its main hardware elements are an automated storage and retrieval system where goods are stored and retrieved, the picking workstations, and a conveying system connecting them.[^1]

## Variants

That review says the traditional automated storage and retrieval system is a crane-operated rack filled with pallets or bins, and names carousels, vertical lift modules, puzzle-based storage, deep-lane and shuttle-based systems as others.[^1] It describes shelf-moving robots as the most famous autonomous mobile robots of parts-to-picker systems: they drive under a rack, lift it and deliver it to a stationary picker.[^1] The 2007 literature review describes aisle-bound cranes that retrieve unit loads, pallets or bins, and bring them to a pick position where the picker takes the required pieces and the remaining load is stored again.[^2]

## Trade-offs

That review says picker-to-parts systems offer high flexibility but incur significant wage costs, while parts-to-picker systems use fixed machinery, which is less flexible but involves a higher investment, reduces operational expenses and can increase order throughput.[^1]

## Scope and distinctions

Goods-to-person picking is a form of [[Order Picking]] and relies on [[Automated Storage and Retrieval System]] or mobile robots; see also [[Autonomous Mobile Robots]]. The manual alternative is picker-to-parts, which the 2007 review calls most common.[^2]

## What the sources do not establish

No source defines goods-to-person as a separate term, and none gives figures for the throughput gain.

[^1]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: René de Koster, Tho Le-Duc and Kees Jan Roodbergen, European Journal of Operational Research 182(2), 2007, “Design and control of warehouse order picking: A literature review”. https://pure.eur.nl/ws/portalfiles/portal/46713708/DesignandControl_2007.pdf

