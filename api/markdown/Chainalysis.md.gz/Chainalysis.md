Chainalysis is a commercial blockchain data analytics and intelligence platform founded in 2014 that provides investigative, compliance, and risk-management tools to government agencies, financial institutions, and cryptocurrency businesses for tracing, monitoring, and understanding blockchain transaction flows. It maintains a large proprietary database of attributed blockchain addresses — linking pseudonymous on-chain addresses to real-world entities through heuristic clustering, open-source intelligence, data partnerships, and legal processes — and offers products including Reactor (graph-based investigation tool), KYT (Know Your Transaction real-time compliance API), and Kryptos (market intelligence). Chainalysis is a primary contractor to agencies including the US Department of Justice, IRS Criminal Investigation, and OFAC for cryptocurrency-related law enforcement investigations, and publishes the annual Crypto Crime Report, the most widely cited source for cryptocurrency illicit finance statistics.

### Overview

- Chainalysis was founded in 2014 by Michael Gronager and Jonathan Levin in the aftermath of the Mt. Gox hack, which demonstrated the traceability of Bitcoin flows on a public ledger. The company's early work traced the movement of stolen Mt. Gox funds, establishing proof-of-concept for blockchain forensics and securing early contracts with the US Drug Enforcement Administration (DEA) and other law enforcement agencies.
- The company grew rapidly through subsequent years, building both commercial and government business lines. It raises venture funding and has reached multi-billion valuations, reflecting the growing market for crypto compliance tooling driven by global regulatory expansion.
- Chainalysis publishes the annual Crypto Crime Report — the most cited source of data on [[Ransomware Attribution]], darknet market volumes, and scam activity — establishing the company as a de facto data authority in the cryptocurrency crime landscape.
- The platform serves three primary customer segments:
  - Government agencies: law enforcement (FBI, DEA, IRS-CI), intelligence, OFAC sanctions enforcement
  - Financial institutions: banks and payment processors managing crypto exposure
  - Cryptocurrency businesses: exchanges, custodians, and VASPs requiring compliance tools

### Key Components

- **Reactor** — Graph-based investigation tool used by law enforcement to visualise [[Transaction Graph Analysis]] flows, identify entity clusters, and build cases around on-chain activity. Displays attributed addresses and their connections in an interactive network diagram.
- **KYT (Know Your Transaction)** — Real-time compliance API enabling VASPs to screen incoming and outgoing transfers for exposure to high-risk counterparties (sanctioned entities, [[Darknet Market]] services, [[Cryptocurrency Mixer]] protocols). The [[Know Your Transaction]] product is the primary compliance revenue source.
- **Kryptos** — Market intelligence product serving institutional investors with on-chain data signals, flow analysis, and macro-level transaction data.
- **Address Attribution Database** — The core proprietary asset: a continuously updated mapping of blockchain addresses to real-world entities (exchanges, mixers, illicit services, government wallets). Built through exchange data partnerships, court-ordered disclosures, OSINT, and undercover investigative techniques.
- **Crypto Crime Report** — Annual publication aggregating transaction data to estimate illicit activity volumes across blockchain networks, widely used by regulators and policymakers.

### Mechanisms and Technical Methods

- **[[Heuristic Clustering]]** — The foundational technique grouping addresses likely controlled by the same entity. Key heuristics include:
  - Common Input Ownership (CIO): addresses that co-sign a single Bitcoin transaction share a common controller
  - Change address detection: identifying the "change" output returned to sender in [[UTXO Model]] transactions
  - Dust attack clustering: sending small amounts to probe address reuse
- **[[Transaction Graph Analysis]]** — Directed graph traversal following transaction outputs across the [[Blockchain Data]] to trace fund flows between clusters, even across multiple intermediate hops
- **Peel chain analysis** — Following rapid sequential transfers characteristic of money laundering through multiple intermediate addresses
- **Cross-chain tracing** — Tracking funds across bridge protocols and wrapped asset transfers between different blockchains
- **Exchange subpoena data** — Legal process compels exchanges to disclose KYC data for specific deposit addresses, anchoring cluster attribution
- **[[Open-Source Intelligence]]** — Forum posts, darknet market listings, social media, and leaked data supplement on-chain analysis

### Applications and Use Cases

- **Law enforcement investigations** — US DOJ, Europol, and similar agencies use Reactor for tracing ransomware payments, darknet drug market proceeds, and terrorism financing. High-profile cases include seizures from Colonial Pipeline ransomware attackers and Bitfinex hackers.
- **[[Sanctions Compliance]]** — OFAC-licensed screening of transactions against sanctioned addresses (e.g., Lazarus Group wallets, Tornado Cash smart contracts following 2022 OFAC designation). VASPs must demonstrate screening capability to maintain banking relationships.
- **[[AML KYC Compliance]]** for exchanges — VASPs integrate KYT API into deposit/withdrawal flows to flag high-risk transactions and meet anti-money laundering obligations under FinCEN, MiCA, and FATF guidance
- **[[Ransomware Attribution]]** — Tracking ransomware payment flows to identify operators, laundering routes, and ultimately cashing-out infrastructure. Feeds into DOJ ransomware task force operations.
- **[[Digital Forensics]]** in civil asset forfeiture — Tracing stolen funds or proceeds of crime to support civil forfeiture applications
- **[[FATF Travel Rule]] compliance** — Assisting VASPs in identifying counterparty VASPs for travel rule data exchange requirements
- **Market intelligence** — Institutional investors use on-chain flow data as signals for exchange inflows/outflows, whale activity, and macro crypto market conditions
- **Regulatory reporting** — Governments and international bodies cite Chainalysis data in policy papers and legislative proceedings

### Competitive Landscape

- Chainalysis operates in a growing market with several significant competitors:
  - **Elliptic** — UK-based, strong in European compliance markets and exchange-facing tools
  - **TRM Labs** — Government-focused, strong in OFAC sanctions and national security use cases
  - **CipherTrace** (acquired by Mastercard) — Integrated into Mastercard's compliance stack
  - **Nansen** — Analytics-focused, stronger on DeFi and on-chain signal intelligence for investors
  - **Crystal Blockchain** — European-focused compliance tooling
- Chainalysis holds the largest government contract base and the most comprehensive Bitcoin and Ethereum attribution database among commercial providers, though competitors contest specific chain coverage and DeFi analytics.

### Standards and Regulatory Context

- **[[FATF Travel Rule]]** (FATF Recommendation 16) — Requires VASPs to transmit originator/beneficiary information; Chainalysis KYT supports VASP identification component
- **OFAC SDN List compliance** — US VASPs must screen against the Specially Designated Nationals list; Chainalysis provides real-time SDN address coverage
- **FinCEN guidance (USA)** — Bank Secrecy Act obligations for virtual currency businesses create the US compliance market
- **MiCA (EU)** — Markets in Crypto-Assets Regulation mandates AML compliance for EU VASPs, expanding the European compliance market
- **5AMLD / 6AMLD (EU)** — Anti-Money Laundering Directives bringing VASPs under EU AML framework
- **[[VASP Regulation]]** globally — FATF's revised standards (2019) require member countries to regulate VASPs, creating a global compliance market that Chainalysis serves

### Privacy and Civil Liberties Concerns

- Critics argue that [[Heuristic Clustering]] involves probabilistic attribution that may incorrectly link addresses to individuals, raising due process concerns in law enforcement contexts where Chainalysis output is treated as reliable evidence.
- The company's role as an unaccountable private actor with significant influence over law enforcement cryptocurrency investigations lacks the transparency of court-supervised forensic methods.
- Academic researchers have published work challenging the reliability of common input ownership heuristics, particularly as wallet software behaviour evolves (CoinJoin, PayJoin).
- The fundamental tension: public blockchains were pseudonymous by design, but Chainalysis-style attribution effectively re-identifies transactions, arguably transforming them into a financial surveillance infrastructure.
- [[Zero-Knowledge Proof]] systems, [[Privacy Coin]] protocols (Zcash, Monero), and privacy-preserving rollups (Aztec) represent technical countermeasures that cryptographically resist graph-analysis attribution.
- The 2022 OFAC sanctions against Tornado Cash smart contract addresses — where immutable code, not a legal entity, was sanctioned — illustrated how Chainalysis's attribution methods feed directly into novel and contested regulatory actions affecting [[Cryptocurrency Mixer]] protocols.

### Provenance

