Signature Aggregation is a cryptographic technique that combines multiple digital signatures over distinct or identical messages into a single compact signature that can be verified with one operation. It reduces on-chain storage and verification cost in blockchain systems where many parties sign, such as validator committees. Schemes such as BLS and Schnorr support aggregation, improving scalability and bandwidth efficiency for distributed consensus.

### Overview

- Signature Aggregation is a cryptographic technique that combines multiple digital signatures over distinct or identical messages into a single compact signature that can be verified with one operation.
- It reduces on-chain storage and verification cost in blockchain systems where many parties sign, such as validator committees.
- Schemes such as BLS and Schnorr support aggregation, improving scalability and bandwidth efficiency for distributed consensus.
- It is modelled as a subclass of [[Digital Signature]] within the blockchain domain.

### Key aspects

- [[Cryptography]] is a constituent or mechanism relevant to Signature Aggregation.
- [[Verification]] is a constituent or mechanism relevant to Signature Aggregation.
- [[BLS Signature]] is a constituent or mechanism relevant to Signature Aggregation.
- [[Schnorr Signature]] is a constituent or mechanism relevant to Signature Aggregation.

### Mechanisms

- Signature Aggregation enables [[Scalability]].
- Signature Aggregation enables [[Multisignature]].
- Signature Aggregation supports [[Consensus Mechanism]].
- Signature Aggregation supports [[Validator]].
- Signature Aggregation supports [[Rollup]].

### Applications

- Applied in contexts involving [[Scalability]].
- Applied in contexts involving [[Multisignature]].
- Applied in contexts involving [[Consensus Mechanism]].
- Applied in contexts involving [[Validator]].
- Applied in contexts involving [[Rollup]].
- Applied in contexts involving [[Bandwidth]].

### Provenance

