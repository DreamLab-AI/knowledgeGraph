Reflective or active tracking points placed on subjects for optical motion capture systems, typically 12-15mm diameter for full-body capture, enabling precise position tracking at frame rates from 120fps to fps for animation, biomechanics, and performance analysis.

### Semantic Classification

### Content

## Marker-Based Systems

### Gold Standard Status

- Clinical acceptance
- High accuracy
- Proven reliability
- Research validation
- Industry standard

  ### Technical Specifications

- 12-15mm diameter typical
- Full-body tracking
- 120-160fps standard
- Up to 10,000fps possible
- Resolution-dependent speed

  ## System Comparison (2024)

  ### Marker-Based Advantages

- Higher precision
- Established protocols
- Research validation
- Professional workflows
- Consistent results

  ### Markerless Development

- Non-invasive tracking
- Computer vision methods
- Deep learning algorithms
- Video-based analysis
- Accessibility improvement

  ## Accuracy Research

  ### Systematic Review Findings

- Good to excellent spatiotemporal accuracy
- Hip and knee: moderate to excellent
- Ankle: variable reliability
- Gait analysis focus
- Meta-analysis validation

  ### Reliability Studies

- 39 kinematic variables tested
- 10 fundamental movements
- Moderate to excellent ICC
- Most movements excellent (>0.90)
- Inter/intra-rater consistency

  ## Applications

  ### Clinical Biomechanics

- Gait analysis
- Rehabilitation assessment
- Injury evaluation
- Surgical planning
- Treatment monitoring

  ### Entertainment Industry

- Film animation
- Video game development
- Virtual production
- Performance capture
- Character animation

  ### Sports Science

- Athlete performance
- Technique analysis
- Injury prevention
- Training optimisation
- Movement patterns

  ## December 2024 Development

  ### CAMERA Software (University of Bath)

- Open access release
- Markerless analysis
- Comparable accuracy
- Deep learning methods
- Body landmark detection

  ### Clinical Implications

- Unobtrusive analysis
- Video footage processing
- Physiotherapy support
- Sports coaching
- Accessibility expansion

  ## Marker Types

  ### Passive Markers

- Reflective material
- Infrared illumination
- Camera detection
- No power required
- Cost-effective

  ### Active Markers

- LED-based
- Self-illuminating
- Unique identification
- Higher visibility
- Power requirements

  ## Placement Protocols

  ### Anatomical Landmarks

- Joint centres
- Bony prominences
- Segment tracking
- Standardised protocols
- Cluster configurations

  ### Considerations

- Subject size
- Movement range
- Occlusion prevention
- Marker visibility
- Attachment security

  ## Future Trends

  ### Hybrid Approaches

- Marker and markerless fusion
- AI-enhanced tracking
- Real-world deployment
- Reduced setup time
- Broader accessibility

  ### Research Directions

- Clinical usefulness validation
- Real-world performance
- Neurodegeneration applications
- Functional assessment
- Home-based monitoring

### Provenance

