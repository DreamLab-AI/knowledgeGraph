A RAIN RFID tag is a passive ultra-high-frequency radio tag that uses the ISO/IEC 18000-63 air interface protocol, also known as GS1 UHF Gen2, and can carry an Electronic Product Code that identifies the item it is attached to.[^1][^2]

The RAIN Alliance says RAIN is the term chosen by the industry to describe a standards-based wireless communication technology that uses that air interface.[^1] It adds that GS1's EPC Gen 2 air interface forms the foundation of the ISO/IEC 18000-63 standard, and that the RAIN Alliance and GS1 agreed the technology should be called RAIN and the GS1 data system the EPC Code.[^1] GS1 says its standards focus on passive UHF and HF tags and that the most broadly implemented are UHF passive tags, also known as RAIN RFID tags.[^2]

## What the tag holds

The Electronic Product Code is a syntax for unique identifiers assigned to physical objects, unit loads, locations or other identifiable entities, and it has binary forms suitable for RFID tags and text forms suitable for sharing among enterprise information systems.[^2] The RAIN Alliance says most RAIN tags contain only a simple number, usually 96 or 128 binary bits, which is used as a lookup in a database to identify the item.[^1]

## In practice

GS1 says that when unique EPCs are encoded onto individual RAIN RFID tags, radio waves can capture the identifiers at extremely high rates and at distances well in excess of 10 metres, without line-of-sight contact.[^2] The RAIN Alliance lists retail, logistics, healthcare and aviation as applications where rapid, accurate collection of information is essential.[^1] See [[RFID]] and [[Automatic Identification and Data Capture]].

## What the sources do not establish

The RAIN Alliance does not test for compliance: to be compliant a tag or reader must follow ISO/IEC 18000-63 and the appropriate data encoding rules.[^1] Both sources promote the technology and neither gives measured read rates, costs or failure modes, so the performance statements above are the bodies' own. The ISO standard itself was not opened.[^1][^2]

[^1]: RAIN Alliance, “FAQs”. https://rainrfid.org/faqs/
[^2]: GS1, “RFID”. https://www.gs1.org/standards/epc-rfid

