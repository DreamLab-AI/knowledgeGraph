Taxonomy category root for Cryptographic Primitive within Blockchain. The concept itself is described at [[Cryptographic Primitive]], which sits under this category; the category exists so the published graph can group its members.

