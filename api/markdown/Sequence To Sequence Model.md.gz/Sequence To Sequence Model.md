A sequence-to-sequence model is a neural architecture that maps an input sequence of arbitrary length to an output sequence of arbitrary length, classically using an encoder to compress the input into a context representation and a decoder to generate the output one element at a time. Originally built from recurrent networks such as LSTMs and GRUs and later augmented with attention to overcome the fixed-context bottleneck, the paradigm became the foundation for the transformer. Sequence-to-sequence models power machine translation, text summarisation, speech recognition, and other tasks where input and output structures differ.

### Overview

- Sequence To Sequence Model sits within the broader category of [[Neural Network]], which it specialises.
- It connects to a network of 14 related classes across the knowledge graph, anchoring edges that previously pointed to an undefined node.

### Key aspects

- uses: [[LSTM]]
- uses: [[GRU]]
- uses: [[Attention Mechanism]]
- uses: [[Beam Search]]
- implements: [[Encoder-Decoder]]
- implements: [[Recurrent Neural Network]]

### Mechanisms

- Sequence To Sequence Model operates through its constituent parts and dependencies, integrating with adjacent systems to deliver its function within artificial intelligence.

### Applications

- Applied to advance [[Machine Translation]].
- Applied to advance [[Text Summarisation]].
- Applied to advance [[Speech Recognition]].
- Applied to advance [[Natural Language Processing]].

### Provenance

