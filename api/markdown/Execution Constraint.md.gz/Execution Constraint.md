
An execution constraint is an operational or environmental constraint limiting the delegate's permissible actions.[^1]

The class is declared in the delegation module. It is reached from a [[Delegation Scope]] through the property `executionConstraint`, whose domain is the scope and whose range is this class. The module declares no properties on the class itself, so the nature of a given constraint, such as a time limit or a permitted environment, is not further specified.

The execution-context module has related classes that attach to the execution environment rather than to a delegation, such as [[Resource Constraint]], [[Execution Budget]] and [[Rate Limiting]].[^2] visionGraph places the concept under [[Constraint]].

[^1]: Semantic Agent Communication Community Group, “Delegation Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/delegation.ttl
[^2]: Semantic Agent Communication Community Group, “Execution Context Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/execution-context.ttl

