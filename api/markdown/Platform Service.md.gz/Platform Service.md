A managed, API-exposed capability unit delivered by a cloud or middleware platform that provides reusable building blocks—such as authentication, storage, messaging, compute, or rendering—to applications built atop that platform. Platform services abstract the operational complexity of underlying infrastructure by encapsulating it behind stable, versioned contracts, enabling developers to compose higher-order application features without provisioning or administering raw resources. They are the foundational unit of Platform-as-a-Service (PaaS) and are central to cloud-native, microservices, and distributed systems architectures. At scale, platform services enforce tenancy boundaries, SLA guarantees, and metered billing, transforming infrastructure capabilities into economically composable software products.

### Overview

- Platform services emerged as a structured response to the operational burden of managing raw [[Infrastructure-as-a-Service]] resources. Where IaaS provisions virtual machines and networks, a platform service abstracts an entire functional capability—a database cluster becomes a managed database service; a pub/sub bus becomes a [[Message Queue]] service; a certificate store becomes an [[Identity and Access Management]] service. The developer interacts only with the service contract, not the operational machinery beneath it.
- **Why it matters**
  - Accelerates time-to-market by removing undifferentiated heavy lifting from application teams
  - Enforces consistent [[Service Level Agreement]] boundaries across heterogeneous consumers
  - Enables [[Multi-Tenant Architecture]] by centralising shared concerns (auth, billing, routing) into single, governed services
  - Provides the economic unit of metered consumption that cloud providers monetise at scale
- **How it works**
  - A platform service is typically deployed as a set of [[Microservices Architecture]] pods managed by [[Container Orchestration]] (e.g., Kubernetes), fronted by an [[API Gateway]] that enforces auth, rate-limiting, and routing.
  - Service discovery, load balancing, and inter-service communication are handled by a [[Service Mesh]] (e.g., Istio or Linkerd).
  - Lifecycle management (rolling upgrades, canary releases, auto-scaling) is governed by declarative [[Infrastructure-as-Code]] pipelines.
  - [[Observability]] instrumentation (metrics, traces, logs) is mandatory—a service without observability cannot uphold its SLA.

### Key Components

- **[[Authentication Service]]** — identity verification and token issuance (OAuth2, OIDC, SAML); every platform service enforces AuthN/AuthZ at the boundary
- **[[API Gateway]]** — the single entry point for external consumers; performs protocol translation, rate limiting, versioning, and audit logging
- **[[Notification System]]** — push, email, SMS, and in-app alert delivery; decoupled from business logic via event streams
- **[[Object Storage]]** — durable, geo-replicated blob storage exposed via S3-compatible APIs; foundational for media, backups, and data lakes
- **[[Message Queue]]** — ordered, durable message transport (e.g., Apache Kafka, Amazon SQS, Google Pub/Sub); decouples producers from consumers at scale
- **[[Service Mesh]]** — sidecar-based transparent proxy layer (e.g., Envoy) providing mutual TLS, circuit breaking, and telemetry between services
- **Managed Database Service** — database capability (relational, document, time-series) delivered as an API with automatic failover and backups
- **CDN / Edge Cache** — content delivery acceleration, tightly coupled to platform service endpoints for latency-sensitive assets
- **Secret Manager** — centralised credential and certificate storage; often integrated with [[Identity and Access Management]] for dynamic secret rotation

### Service Categorisation

- Platform services are commonly organised by functional domain:
  - **Compute services** — managed functions (FaaS), container jobs, batch processing; see [[Serverless Computing]]
  - **Data services** — managed SQL/NoSQL, data warehouses, streaming pipelines
  - **Integration services** — [[API Gateway]], event buses, workflow orchestrators
  - **Security services** — [[OAuth2]], secrets management, Web Application Firewalls
  - **Observability services** — distributed tracing, log aggregation, synthetic monitoring
  - **AI/ML services** — model inference endpoints; the fastest-growing category; see [[AI Inference Service]]
  - **Spatial services** — map tiles, 3D asset pipelines, physics simulation APIs; integral to [[Spatial Computing]] and [[Metaverse Platform]] stacks

### Applications and Use Cases

- **SaaS product engineering** — ISVs build product features by composing platform services rather than operating their own infrastructure, dramatically reducing operational headcount
- **[[Metaverse Platform]] backend** — avatar persistence, real-time synchronisation, spatial audio, and rendering orchestration are each implemented as discrete platform services shared across virtual world instances
- **[[Digital Twin]]** — IoT sensor streams ingest to a managed timeseries service; simulation state is stored in managed graph databases; dashboards consume via managed analytics services
- **[[Event-Driven Architecture]]** — enterprise integration buses built on managed message queues and event hubs, replacing brittle point-to-point integrations
- **[[Edge Computing]] deployments** — platform services replicated to edge nodes via lightweight container runtimes (e.g., K3s), enabling low-latency capability delivery at the network edge
- **[[Multi-Tenant Architecture]]** — SaaS tenants share platform services with isolation enforced at the service boundary (namespace, VLAN, encryption key) rather than at the hardware level
- **Regulated industries** — managed compliance-as-a-service: data residency controls, audit trails, and consent management surface as platform service APIs, simplifying GDPR and HIPAA obligations

### Standards and Governance

- **[[OpenAPI]]** (OAS 3.x) — the de facto standard for describing RESTful platform service interfaces; consumers use generated SDKs derived from OAS documents
- **[[Cloud Native Computing Foundation]]** (CNCF) — stewards key platform service infrastructure: Kubernetes (orchestration), Envoy (service mesh), Prometheus (observability), Argo (workflow)
- **OAuth2 / OIDC** (RFC 6749 / OpenID Foundation) — token-based authorisation flows universally adopted by platform service auth boundaries
- **gRPC / Protocol Buffers** — binary RPC framework from Google, increasingly the internal transport for high-throughput platform service communication
- **OpenTelemetry** (CNCF) — vendor-neutral observability instrumentation API/SDK ensuring consistent telemetry across heterogeneous platform services
- **ISO/IEC 17788** — Cloud computing vocabulary and concepts; provides the normative definition framework within which platform services sit
- **NIST SP 800-204 series** — security guidance specifically for microservice and platform service architectures in regulated deployments

### Contrast with Adjacent Service Models

- **vs [[Infrastructure-as-a-Service]]** — IaaS exposes raw compute, storage, and network primitives; the consumer manages the OS, runtime, and application. A platform service removes that entire layer, exposing only a business-capability API.
- **vs [[Software-as-a-Service]]** — SaaS is a complete, end-user application (e.g., Gmail). A platform service is an intermediate, composable capability consumed by developers, not end-users.
- **vs [[Serverless Computing]]** — Serverless (FaaS) is a specific execution model for event-triggered functions; it is one implementation pattern for a compute platform service, but platform services encompass a far broader capability surface.

### Current Landscape (2026)

- Platform services are now consumed chiefly through Internal Developer Platforms (IDPs) and portals: Gartner's 2026 Market Guide for Internal Developer Portals frames an IDP as "a single front door to engineering" that exposes APIs, catalogues and self-service automation while treating underlying technical platforms as reusable assets.
- Backstage remains the de facto standard portal layer — a CNCF Incubating project sitting in the "adopt" position (alongside Helm and kro) on the CNCF Q1 2026 Technology Radar; the mid-2025 snapshot reported over 270 organisations running it in production, at release line 1.42.x.
- "Platform as a product" has become mainstream: Gartner projected 80% of large software-engineering organisations would run dedicated platform teams by 2026 (up from ~45% in 2022), and Futurum found more than 80% of enterprise platforms are now managed as products rather than projects.
- The commercial layer has consolidated around a two-tier split — provisioning/orchestration engines (Humanitec, Qovery, Appvia Wayfinder, Mia-Platform, Crossplane, Kratix) beneath developer portals (Backstage, Port, Cortex, OpsLevel) — with Spotify's hosted Backstage Enterprise and Roadie adding managed, AI-assisted cataloguing.
- Standardisation is maturing: the Score workload specification moved under CNCF custodianship, kro and the emerging platformspec.io effort are formalising platform interfaces, and OPA/Kyverno policy-as-code plus OpenTelemetry observability are now expected baseline capabilities.
- The defining 2026 shift is that platform services must be "AI-operable", not just developer-operable — IDPs are being extended to broker self-service access to AI models, orchestration frameworks and ModelOps for agents; the 2026 Gartner Software Engineering Survey found 67% of leaders cite building AI capabilities into applications as a top pain point.
- Open challenges remain adoption and bypass: CNCF/SlashData's Q1 2026 radar found only 28% of organisations have a dedicated platform team (41% still collaborate across multiple teams), and surveys report roughly 64% of engineers still route around platform tooling in some cases.

### References

- 1. Gartner / Mia-Platform (2026). Mia-Platform mentioned in the 2026 Gartner Market Guide for Internal Developer Portals. https://mia-platform.eu/news-en/mia-platform-mentioned-in-the-gartner-market-guide-internal-developer-portals-2026/
- 2. Cloud Native Computing Foundation (2026). Q1 2026 CNCF Technology Radar Report (platform engineering). https://www.cncf.io/wp-content/uploads/2026/03/Q1-2026-CNCF-Technology-Radar-Report.pdf
- 3. Platform Engineering (2025). Backstage, a Mid-Year Snapshot. https://platformengineering.com/social-facebook/backstage-a-mid-year-snapshot/
- 4. Facets.cloud (2026). The Best Internal Developer Platforms (IDPs) to Consider in 2026. https://www.facets.cloud/blog/7-best-internal-developer-platforms-idps-to-consider
- 5. Frontiers in Computer Science (2026). Platform engineering and internal developer portals: a multivocal literature review. https://www.frontiersin.org/journals/computer-science/articles/10.3389/fcomp.2026.1814498/full
- 6. Signiscys (2026). GitOps, IaC and Platform as Product: Three Pillars of Modern DevOps in 2026. https://www.signisys.com/blog/gitops-iac-and-platform-as-product-three-pillars-of-modern-devops-in-2026/

### Provenance

