
An agent profile is a stable behavioural descriptor for an autonomous agent, covering its pragmatic and behavioural parameters.[^1] Where identity, capability, delegation and ledger describe what an agent can do, the profile describes how it behaves. visionGraph places it under [[Persona]].

The profile covers linguistic preferences, tone patterns and personality-like biases, and this layer influences task decomposition, intent interpretation and multi-agent coordination stability. It is not executable semantics, so it guides how an agent behaves without changing what it is permitted to do.

Three properties attach its components: `hasPersonality` to [[Agent Personality]], `usesLanguage` to [[Language Preference]] and `hasToneModel` to [[Tone Model]]. An [[Agent]] is linked to its profile through `hasProfile`. A neutral, balanced default profile can be built from standard values for each component, which gives agents with no declared character a predictable baseline.

[^1]: Semantic Agent Communication Community Group, “Agent Profile Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent-profile.ttl

