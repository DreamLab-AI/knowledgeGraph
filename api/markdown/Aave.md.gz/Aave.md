Aave is a decentralised, non-custodial liquidity protocol deployed on Ethereum and multiple EVM-compatible networks that allows users to supply crypto assets into pooled reserves to earn algorithmically set interest, and to borrow against over-collateralised positions at variable or stable rates. Pioneered by Stani Kulechov and launched as ETHLend in 2017 before rebranding in 2020, it introduced the flash loan — an uncollateralised loan that must be atomically repaid within a single transaction block — as a foundational DeFi primitive. Governance is exercised by AAVE token holders who vote on Aave Improvement Proposals controlling risk parameters, supported asset listings, protocol upgrades, and treasury allocations.

### Overview

- Aave launched in 2017 as ETHLend — a peer-to-peer lending platform matching borrowers and lenders directly on [[Ethereum]]. The protocol rebranded to Aave (Finnish for "ghost") in 2020, pivoting to a pooled liquidity model that dramatically improved capital efficiency and user experience.
- Aave V2 (2020) introduced debt tokenisation, [[Collateralised Borrowing]] with stable and variable rate switching, and gas optimisations. Aave V3 (2022) added supply and borrow caps, [[Cross-Chain Bridge]] portals, isolation mode for newly listed risky assets, and efficiency mode (eMode) that allows higher LTV for correlated asset pairs such as stablecoin–stablecoin or ETH-derivative–ETH pairs.
- The protocol is widely regarded as one of the foundational "money lego" primitives of DeFi, with deep integration into the broader [[DeFi Ecosystem]] through composable interactions with [[Yield Farming]], [[On-Chain Arbitrage]], and [[Automated Market Maker]] protocols.

### Key Mechanisms

#### Pooled Reserves and aTokens

- Assets are deposited into shared reserve pools rather than matched peer-to-peer.
- Depositors receive aTokens (e.g. aUSDC, aWETH) minted 1:1, whose balance increases in real time as interest accrues via the [[Liquidity Index]].
- [[aToken]] design eliminates the need to manually claim interest — balances grow continuously in the depositor's wallet.

#### Algorithmic Interest Rates

- [[Algorithmic Interest Rate]] models adjust continuously based on the utilisation ratio — the fraction of pooled assets currently borrowed.
- Below an optimal utilisation threshold, rates are low and rise slowly; above the threshold, rates escalate steeply to incentivise repayment and attract new supply.
- Borrowers may switch between variable rates (tracking real-time utilisation) and stable rates (fixed for the duration of the loan, subject to rebalancing in extreme conditions).

#### Over-Collateralisation and Health Factor

- Every borrow position requires [[Over-Collateralisation]]: the collateral value must exceed the borrowed value by a margin set by the asset's Loan-to-Value (LTV) ratio.
- A Health Factor (HF) metric aggregates collateral value against total debt; HF < 1 triggers [[Liquidation Mechanism]] by third-party liquidators who repay debt and claim collateral at a liquidation bonus discount.
- Price data is sourced from [[Chainlink]] [[Oracle]] price feeds, ensuring manipulation resistance.

#### Flash Loans

- [[Flash Loan]] transactions allow any contract to borrow unlimited liquidity from an Aave pool within a single [[Ethereum]] transaction without posting [[Collateral]].
- The borrowed amount plus a fee (0.09% in V3) must be returned before the transaction finalises; if repayment fails the entire transaction reverts atomically.
- Use cases include: [[On-Chain Arbitrage]] across [[Decentralised Exchange]] venues, [[Self-Liquidation]] of underwater positions, collateral swaps, and protocol-level [[Governance]] attacks (a notable security concern).

#### On-Chain Governance

- [[On-Chain Governance]] is conducted via the [[AAVE Token]] with voting power proportional to holdings (plus staked AAVE in the Safety Module).
- Aave Improvement Proposals (AIPs) cover asset listings, risk parameter adjustments, fee configurations, and core contract upgrades.
- A timelock delay between proposal passage and execution provides a security buffer against malicious governance actions.

#### GHO Stablecoin

- Aave V3 introduced [[GHO Stablecoin]], a decentralised, over-collateralised stablecoin mintable by depositing supported assets, with interest flowing directly to the Aave DAO treasury.
- GHO operates as a native stablecoin for the Aave ecosystem, enabling tighter vertical integration compared to borrowing third-party stablecoins.

#### Safety Module

- The Safety Module is a staking contract where AAVE holders lock tokens as a backstop against shortfall events (protocol insolvency).
- Stakers earn rewards in exchange for accepting slashing risk (up to 30% of staked tokens may be liquidated to cover a deficit).

### Applications and Use Cases

- **Yield Optimisation**: Depositors earn passive yield on idle assets including ETH, WBTC, USDC, USDT, DAI, and other supported tokens, often as part of larger [[Yield Farming]] strategies.
- **Leveraged Positions**: Borrowers can use deposited collateral to borrow stablecoins, deploy those stablecoins elsewhere, and loop positions — a form of synthetic leverage common in [[DeFi Ecosystem]] strategies.
- **Flash Loan Arbitrage**: [[On-Chain Arbitrage]] bots routinely use flash loans to exploit price discrepancies across [[Automated Market Maker]] pools and centralised/decentralised exchange pairs atomically.
- **Collateral Swaps**: Users can swap the asset backing a loan position without closing the position, using a flash loan to transiently cover the rebalancing — relevant when managing [[Liquidation Mechanism]] risk.
- **Protocol Treasury Management**: DAOs and protocol treasuries use Aave to earn yield on idle [[Stablecoin]] holdings or to access short-term liquidity without selling assets.
- **Real-World Asset Integration**: Aave V3 and Aave Arc (a permissioned deployment) explored [[Real-World Asset]] tokenisation and institutional liquidity provisioning in compliance-gated pools.
- **AI-Augmented Risk Management**: Emerging use of [[AI-Driven Trading]] and [[Risk Modelling]] systems that monitor Aave positions, automate liquidation avoidance, and optimise rate switching — a cross-domain bridge between blockchain protocol layers and machine intelligence.

### Standards and Context

- Aave's smart contracts are written in Solidity and audited by multiple independent firms including Certora, OpenZeppelin, and Trail of Bits.
- The protocol uses ERC-20 for aTokens and debt tokens, and the EIP-3156 flash loan standard (Aave's own flash loan interface predates EIP-3156 and differs slightly).
- [[Chainlink]] [[Oracle]] price feeds are the primary data source for collateral valuation; Aave governance may approve alternative oracles on a per-asset basis.
- Regulatory scrutiny of [[Decentralised Finance]] protocols — particularly those offering borrowing and interest — is increasing in the EU (MiCA framework) and US (SEC/CFTC jurisdiction debates), creating compliance pressure on permissionless deployments.
- Aave Arc was developed as a permissioned pool variant to meet KYC/AML requirements for institutional participants, partnering with Fireblocks for whitelisted address management.
- The [[DeFi Ecosystem]] broadly relies on composable protocol interactions; Aave's pooled liquidity model has been forked widely (e.g. Radiant Capital, Venus Protocol on BNB Chain).

### Provenance

