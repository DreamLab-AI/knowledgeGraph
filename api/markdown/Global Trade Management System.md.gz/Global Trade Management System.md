A global trade management system is software that supports cross-border trade work, mainly trade compliance, customs and landed cost.[^1][^2]

No neutral definition was found, so the page records what vendors say their products do. Oracle says its Global Trade Management product enables tariff management, product classification, landed cost simulation, trade agreement and incentive program qualification, country of origin designation, supplier solicitation, customs management and analytics.[^1] SAP describes its Global Trade Services as “a solution that automates and streamlines trade compliance processes”, saying a company can control costs, reduce the risk of penalties and fines, and clear customs faster.[^2]

## Screening and landed cost

Part of the work is checking parties against government lists. The US Consolidated Screening List is a list of parties for which the United States Government maintains restrictions on certain exports, reexports or transfers of items, and the International Trade Administration says a match requires additional due diligence before proceeding.[^3] Landed cost, which Oracle's product simulates, is defined by the Administration as the total price of a product once it has arrived at the buyer, including the original price, insurance, freight, tariffs and taxes, and other fees.[^1][^4] See [[Total Landed Cost]], [[Customs Declaration]] and [[Customs Duty]].

## Scope and distinctions

Georgia Tech slides list global trade management among the functions of systems that call themselves transportation management systems, so the boundary with [[Transportation Management System]] is not fixed.[^5] See [[Supply Chain Information Systems]].

## What the sources do not establish

Vendor pages are marketing descriptions and their feature lists are claims. The Administration pages describe a list and a cost concept and not the software itself. No opened source states how widely such systems are used, which functions are required by law, or how products differ, so the page is thin.[^1][^2][^3][^4]

[^1]: Oracle, “Global Trade Management”. https://www.oracle.com/scm/logistics/global-trade-management/
[^2]: SAP, “Global Trade Services Management and Compliance”. https://www.sap.com/products/financial-management/global-trade-management.html
[^3]: US International Trade Administration, “Consolidated Screening List”. https://www.trade.gov/consolidated-screening-list
[^4]: US International Trade Administration, “Determine Total Export Price”. https://www.trade.gov/determine-total-export-price
[^5]: Georgia Tech Supply Chain and Logistics Institute, “Principles of Transportation Management” (overview presentation). https://www.scl.gatech.edu/sites/default/files/presentations/GTSCL-PrinciplesTransportationManagementOverview.pdf

