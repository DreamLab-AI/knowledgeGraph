
An agent lifecycle record is the record of the lifecycle of an AI agent, declared as `LifecycleRecord` in the lifecycle module of the Agent Ontology.[^1] The Agent Ontology declares the class without a definition; this one follows from its properties. visionGraph places it under [[Lifecycle Management]].

An [[Agent]] reaches its record through `lifecycleManagement` in the agent module.[^2] Four properties have the record as domain: `genesisRecord`, ranging over the [[Agent Genesis Record]]; `decommissionRecord`, ranging over the [[Agent Decommission Record]]; `healthCheck`, ranging over a [[Health Check]] specification (declared as `HealthCheckSpec`); and `state`, a string.

A lifecycle record therefore brackets an agent's existence between a creation record and a retirement record, with a health specification and a current state in between. The permitted values of `state` are chosen by the deployment, which can follow whatever lifecycle model it uses.

[^1]: Semantic Agent Communication Community Group, “Lifecycle Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/lifecycle.ttl
[^2]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

