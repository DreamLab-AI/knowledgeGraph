
An execution context is a contextual frame describing conditions, trust anchors or constraints associated with an agent action.[^1]

The class is declared in the core module. The property `contextOf` has an `ExecutionContext` as domain and an `Action` as range, indicating that the context applies to a specific action. The intent module adds `executedIn`, linking an action to its context. The execution-context module then breaks the context into parts: `hasEnvironment` leads to an [[Execution Environment]], `hasSecurityContext` to a [[Security Context]], and `inputState` and `outputState` to an [[Input State]] and an [[Output State]].[^2]

The execution context is the domain of all four properties. visionGraph places the concept under [[Runtime Environment]].

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Execution Context Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/execution-context.ttl

