Query processing is the set of activities a database system performs to translate a declarative query into an efficient execution that returns the requested data. It spans parsing and semantic analysis, logical and physical query optimisation, plan selection, and execution against stored data and indexes. Effective query processing is central to database performance, determining how quickly results are produced and how system resources are used.

### Overview

- Query processing turns a user's [[SQL]] statement into a chosen physical plan and runs it over the [[Database System]].
- It relies on cost estimation, statistics, and [[Indexing]] to pick efficient access paths and join orders.
- The quality of query processing directly governs latency and throughput for both analytical and transactional workloads.

### Mechanisms

- Parsing and binding: validating syntax and resolving schema references.
- Query rewriting: applying logical transformations and predicate pushdown.
- Optimisation: cost-based selection of join orders and access methods.
- Plan generation: producing a physical execution plan with operators.
- Execution: iterating operators, using indexes, and managing memory and parallelism.

### Applications

- Relational OLTP engines serving [[Transaction Processing]].
- Analytical engines and [[Data Warehouse]] query execution.
- Query optimisation and tuning for performance-critical applications.
- Distributed and federated query execution across data sources.

### Provenance

