An inventory model is an analytical description of an inventory system used to decide how much to order and when, usually by minimising a total cost or maximising a profit.[^1][^2]

A BCcampus open textbook says many models have been developed for controlling inventories in firms and organisations and classifies them by the decision conditions governing the system: complete certainty, or uncertainty, which it divides into complete uncertainty and risk. It adds that models are sometimes classified in two categories, deterministic and probabilistic.[^1] It places the Wilson-Harris model, the safety stock model and the total discount model under certainty, and single-period and periodic review models under uncertainty.[^1]

## Dimensions

MIT lecture slides list the features that distinguish types of inventory model: demand that is constant, deterministic or stochastic; lead times of zero, positive or stochastic; a single-period, finite or infinite horizon; one product or several; capacity limits or none; and service that meets all demand or allows shortages.[^2] Georgia Tech class notes say the total system cost traditionally consists of the costs of holding inventory, of ordering replenishment goods and of unsatisfied demand, and that a minimum service level may be used in place of the cost of unsatisfied demand.[^4]

## History and scope

A review of operations and supply chain management says inventory management research originated with the economic order quantity model for single-item, single-echelon systems under constant demand, and that by the 1950s advances had extended to systems with stochastic demand, multiple items and multiple echelons.[^3] See [[Economic Order Quantity]], [[Newsvendor Model]] and [[Multi-Echelon Inventory Optimisation]].

Models differ from policies. A model describes and optimises a system, whereas an [[Inventory Policy]] is the rule a manager applies. The sources use the words close together, and this corpus keeps them as separate pages under [[Inventory Management]].

## What the sources do not establish

Sources do not agree on one classification of models. The BCcampus textbook is a single-author text and its split into certainty, risk and complete uncertainty is recorded as its own.[^1]

[^1]: Hamid Bazargan, BCcampus Open Education, November 2021, “Classical Topics in Inventory Control”. https://opentextbc.ca/oerdiscipline/wp-content/uploads/sites/213/2018/09/Classical-Topics-in-Inventory-Control.pdf
[^2]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf
[^3]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^4]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf

