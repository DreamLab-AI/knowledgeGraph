The Corporate Sustainability Reporting Directive (CSRD) is a European Union law that expands and standardises the sustainability information companies must disclose, replacing the earlier Non-Financial Reporting Directive. It mandates reporting against the European Sustainability Reporting Standards, applies a double-materiality lens and requires assurance of the disclosed data. It substantially widens the scope of in-scope undertakings and the depth of environmental, social and governance disclosure.

### Overview

- CSRD is a centrepiece of the European Union's sustainable-finance agenda, designed to give investors and stakeholders comparable, reliable and auditable sustainability data. It introduces mandatory European Sustainability Reporting Standards and the double-materiality principle, under which firms report both their impact on the world and the world's impact on them.

### Key aspects

- Double-materiality assessment covering impact and financial materiality
- Reporting against the European Sustainability Reporting Standards
- Mandatory limited, later reasonable, assurance of disclosures
- Phased application across large, listed and eventually smaller undertakings

### Applications

- Corporate annual sustainability statements in the EU
- Value-chain emissions and Scope 3 reporting
- ESG data collection and assurance programmes
- Investor screening on standardised sustainability data

### Provenance

