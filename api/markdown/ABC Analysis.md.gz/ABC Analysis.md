ABC analysis is a categorisation method in which inventory is classified into classes A, B and C, with A the lowest quantity and highest value and C the highest quantity and lowest value.[^1]

The Bazargan open textbook says its purpose is to help managers identify the items that represent the large segment of the inventory costs in order to manage them better, allowing different inventory management techniques to be applied to different segments. It presents the method as an application of the Pareto principle: within any system, a small portion of input has the highest value and output.[^1]

## Class boundaries

That textbook notes that the A, B and C categories are identified according to the viewpoint of higher-level management, so the cut-off percentages are not fixed. The criterion for categorisation might be delivery time as well as dollar value.[^1] MIT lecture slides describe the classes in terms of control: A items are very few high-impact items that require the most managerial attention and review, B items get automated control with management by exception, and C items should have control systems as simple as possible. The slides add that these are arbitrary classifications.[^2]

## In practice

The Bazargan text says control of category C items can mean keeping a relatively large number of units on hand with a simple inventory record or periodic review.[^1] The Ohio State University inventory policy applies the classes to counting: A items, a percentage of the highest dollar or usage items, are counted every 30 days, B items every 60 days and C items, all the remainder, every 90 days.[^3] A Texas Department of Transportation audit reports on count frequencies by A, B and C class and found items counted 31 days or more past due.[^4] See [[Cycle Counting]].

## Scope and distinctions

ABC analysis is a form of [[Inventory Classification]]. It is not the same as classifying by type, covered at [[Inventory Type]].

## What the sources do not establish

Sources do not agree on class percentages, and none reports evidence that ABC classes reduce cost. The textbook cites research that does not limit the analysis to three classes.[^1]

[^1]: Hamid Bazargan, BCcampus Open Education, November 2021, “Classical Topics in Inventory Control”. https://opentextbc.ca/oerdiscipline/wp-content/uploads/sites/213/2018/09/Classical-Topics-in-Inventory-Control.pdf
[^2]: Chris Caplice, MIT OpenCourseWare ESD.260 Logistics Systems, October 2006, “Inventory Management: Probabilistic Demand”. https://ocw.mit.edu/courses/esd-260j-logistics-systems-fall-2006/8b53c45fd26ffff706d815131e8d177e_lect11.pdf
[^3]: The Ohio State University, “Inventory” (university policy). https://policies.osu.edu/sites/default/files/documents/2024/09/inventory-policy.pdf
[^4]: Texas Department of Transportation, Internal Audit Division, October 2018, “Physical and Cycle Count Inventory Procedures”. https://ftp.txdot.gov/pub/txdot-info/aud/reports/phys_cycle_count_inv_procedures_final_audit_report.pdf

