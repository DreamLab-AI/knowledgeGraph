Independent blockchain connected to a parent blockchain via a two-way peg mechanism that operates with its own consensus and validation rules while enabling asset transfers between chains, providing scalability and experimental capabilities without impacting the main chain.

### Semantic Classification

### Content

## Definition

- Independent blockchain connected to parent blockchain via two-way peg
- Operates with own consensus mechanism and validation rules
- Enables asset transfer between main chain and sidechain while maintaining separate security model

  ## Core Components

- **Two-Way Peg**: Mechanism for locking assets on main chain and issuing on sidechain
- **Federated Validators**: Custodians managing cross-chain asset transfers
- **Consensus Layer**: Independent block production and finalization
- **Bridge Contract**: Smart contract coordinating asset transfers

  ## Technical Characteristics

- **Independent Security**: Own validator set and consensus rules
- **Flexible Design**: Custom block time, transaction format, and VM
- **Asset Portability**: Native token representation across chains
- **Scalability**: Parallel transaction processing off main chain

  ## Peg Mechanisms

- **Symmetric Peg**: Equal value representation on both chains
- **Asymmetric Peg**: Different tokenomics on sidechain
- **SPV Proof**: Simplified payment verification for cross-chain validation
- **Federated Signatures**: Multi-sig control of locked assets

  ## Use Cases

- High-throughput transaction processing
- Experimental feature deployment
- Privacy-enhanced transactions
- Gaming and microtransaction platforms

  ## Examples

- [[Polygon PoS]]: Ethereum sidechain with plasma bridge
- [[Liquid Network]]: Bitcoin sidechain for fast settlement
- [[Ronin]]: Gaming-focused Ethereum sidechain
- [[Gnosis Chain]]: Prediction market sidechain

  ## Relationships

  ## Security Model

- Trust assumptions in bridge validators
- Economic security independent from main chain
- Potential centralization in federated pegs
- Reorganization risks with different finality guarantees

  ## Advantages

- No parent chain throughput constraints
- Flexible consensus and execution rules
- Lower transaction costs
- Isolated security incidents

  ## Limitations

- Weaker security guarantees than main chain
- Bridge vulnerability attack surface
- Asset liquidity fragmentation
- Validator set trust requirements

  ## Performance Metrics

- Cross-chain transfer latency
- Bridge validator decentralization
- Transaction throughput vs main chain
- Asset lock duration requirements

  #### Related Concepts

- [[Cross-Chain Bridge]]
- [[Scalability Solutions]]
- [[Two-Way Peg]]
- [[Federated Byzantine Agreement]]

  #blockchain #sidechain #scalability #bridge

  ### Relationships

### Provenance

