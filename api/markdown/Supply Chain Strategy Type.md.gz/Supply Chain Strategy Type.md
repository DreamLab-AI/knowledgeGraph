A supply chain strategy type is a named, generic posture that a supply chain can adopt, such as lean, agile, efficient or responsive, chosen according to the demand the chain serves.[^1][^2][^3]

No source opened here defines the umbrella term. Literature names postures in two overlapping vocabularies, and this page records both without merging them.

Fisher classifies products by demand pattern as primarily functional or primarily “innovative” (his second category: products built on fashion or technology innovation, with unpredictable demand), and pairs each with its own kind of chain: physically efficient for functional products and market-responsive for “innovative” ones.[^1] Mahdavi, Mahmoudzadeh and Olsen describe this pairing as one of the earliest and most widely discussed guidelines in supply chain management.[^4]

Christopher and Towill, and Mason-Jones, Naylor and Towill, use a different pair, lean and agile. Lean concepts are said to work well where demand is stable and predictable and variety is low, and a much higher level of agility is required where demand is volatile and variety is high.[^2] Mason-Jones and colleagues add a hybrid, the “Leagile Paradigm”, which uses “a different paradigm on either side of the material flow de-coupling point”.[^3]

## Scope and distinctions

No opened source shows that the two vocabularies name the same things. Fisher's categories are defined by the primary purpose of the chain in relation to product demand. Christopher and Towill describe lean and agile through market qualifiers and market winners: quality, service level and lead time qualify a lean chain while cost wins orders, and cost is only an important qualifier in an agile one.[^2] Christopher also says the key to survival in volatile markets is agility, in particular through responsive supply chains, which treats responsive chains as a means to agility.[^5]

Types are not mutually exclusive. Christopher and Towill state that lean and agile can be combined in several ways, for instance by managing a predictable minority of products differently from the remainder.[^2] Lee's article argues that strategies must be matched to the uncertainties of demand and supply, but only its abstract was opened, so its own list of types is not given here.[^6]

Individual postures are described at [[Lean Supply Chain]], [[Agile Supply Chain]], [[Efficient Supply Chain]] and [[Responsive Supply Chain]].

## What the sources do not establish

Evidence for the umbrella concept itself is thin. Each source defines its own postures; none sets out a taxonomy, and the apparent correspondence of lean with efficient and of agile with responsive is not stated by any source opened here.

[^1]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf
[^2]: Martin Christopher and Denis Towill, International Journal of Physical Distribution and Logistics Management, 2001 (Cranfield repository copy), “An Integrated Model for the Design of Agile Supply Chains”. https://dspace.lib.cranfield.ac.uk/bitstreams/db14daf6-8518-476e-9211-b6af2f1515a5/download
[^3]: Rachel Mason-Jones, Ben Naylor and Denis R. Towill, International Journal of Production Research, 2000 (Cardiff Metropolitan University record, abstract only), “Lean, agile or leagile? Matching your supply chain to the marketplace”. https://pure.cardiffmet.ac.uk/en/publications/lean-agile-or-leagile-matching-your-supply-chain-to-the-marketpla/
[^4]: Mojtaba Mahdavi, Mahdi Mahmoudzadeh and Tava Lennon Olsen, International Journal of Production Economics, vol. 255 (IDEAS/RePEc record, abstract only), “Efficient vs. Responsive supplier selection for functional and innovative products: A quantitative study”. https://ideas.repec.org/a/eee/proeco/v255y2023ics0925527322002389.html
[^5]: Martin Christopher, Industrial Marketing Management, 2000 (Cranfield repository copy), “The Agile Supply Chain : Competing in Volatile Markets”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/3e60f75d-28c1-4659-a260-6608c0e863f2/content
[^6]: Hau L. Lee, California Management Review, Spring 2002 (abstract page), “Aligning Supply Chain Strategies with Product Uncertainties”. https://cmr.berkeley.edu/2002/05/44-3-aligning-supply-chain-strategies-with-product-uncertainties/

