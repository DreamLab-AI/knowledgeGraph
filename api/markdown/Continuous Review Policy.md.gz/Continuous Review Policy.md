A continuous review policy monitors the inventory position of an item continuously and places an order whenever the position falls to a trigger level.[^1][^2]

A Penn State teaching note describes a continuous review system as one that monitors the inventory position, on hand plus on order minus backorders, of a stock keeping unit and triggers a fixed replenishment quantity Q whenever a transaction causes the position to drop to or below the reorder point. It says the near real-time monitoring makes the system very responsive to demand and a good candidate for fast-moving consumer products.[^1] An open operations text describes it as checking the inventory level at all times, with the system notifying a buyer, or in more automated systems placing the order itself, when the level hits the reorder point.[^2]

## Forms

MIT slides write continuous review as the case where the review period R is zero and give two forms: the order-point, order-quantity policy (s, Q), which orders Q if the inventory position is at or below s, and the order-point, order-up-to-level policy (s, S).[^3] See [[Reorder Point Policy]]. The slides also ask whether continuous review is really continuous.[^3]

## Scope and distinctions

Its contrast is [[Periodic Review Policy]], which reviews at fixed intervals. The Penn State note says more safety inventory is needed under periodic review for the same availability target.[^1] Safety stock is covered at [[Safety Stock]].

Georgia Tech class notes give a sequential method for choosing the order quantity Q and reorder point R for a continuous review system, using a service level target.[^4] This page does not reproduce the method.

## What the sources do not establish

Sources do not agree on a name for the trigger: reorder point, order point, r and s all appear. None gives a rule for choosing continuous over periodic review.

[^1]: J. E. Tyworth, Penn State Smeal College of Business SCM 810 technical note, February 2014, “Basic Multi-period Inventory Systems”. https://courses.smeal.psu.edu/SCM810/scm_810_module_3/Multi%20Period%20Inventory%20Systems%20Teaching%20Note.pdf
[^2]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.2: Inventory Management Models”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.02%3A_Inventory_Management_Models
[^3]: Chris Caplice, MIT OpenCourseWare ESD.260 Logistics Systems, October 2006, “Inventory Management: Probabilistic Demand”. https://ocw.mit.edu/courses/esd-260j-logistics-systems-fall-2006/8b53c45fd26ffff706d815131e8d177e_lect11.pdf
[^4]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf

