An inventory type is a class into which stock is divided, either by its stage in the flow of materials or by the role it plays in the system.[^1][^2]

## By stage

An open operations text lists raw materials or purchased parts, work in process, finished goods or merchandise, and spare parts or tools and supplies among the types of inventory in an organisation.[^1] MIT lecture slides give the first three as the types of inventory.[^2] Georgia Tech class notes pair them with position: raw materials are incoming to the organisation, work in process is internal and finished goods are outgoing.[^3] See [[Raw Materials Inventory]], [[Work-in-Progress Inventory]] and [[Finished Goods Inventory]].

## By role

The MIT slides list the roles of inventory as anticipation stock, cycle stock, safety stock, pipeline stock and decoupling stock.[^2] The Georgia Tech notes give a different list: pipeline, cycle, safety, seasonal, aging and speculative inventory.[^3] The sources do not reconcile the two lists, and this corpus records them side by side. See [[Pipeline Inventory]] and [[Safety Stock]].

That open text also gives reasons for holding inventory, among them that inventory is still in transit and that stock protects against stockouts, which it calls probably the most common reason.[^1]

## Scope and distinctions

Classification by stage is a view of where an item is in the production flow, and classification by role is a view of why it is held. This corpus does not claim that one scheme maps onto the other.

Inventory types sit under [[Inventory Management]].

## What the sources do not establish

No source offers a single agreed list. The three sources used here are teaching materials, and the lists of roles differ in count and in names. Cycle stock, anticipation stock and decoupling stock are named but not defined further in this corpus.

[^1]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.1: Types of Inventory”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.01%3A_Types_of_Inventory
[^2]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf
[^3]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf

