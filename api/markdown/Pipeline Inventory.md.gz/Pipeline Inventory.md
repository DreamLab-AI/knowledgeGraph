Pipeline inventory is stock that has been ordered but has not yet arrived, also called in-transit stock.[^1]

MIT lecture slides describe pipeline stock as stock that has been ordered but has not arrived, caused by unavoidable time lags and delays, and list it as one of five roles of inventory alongside anticipation, cycle, safety and decoupling stock.[^1] An open operations text gives holding inventory because it is still in transit as one of the reasons for keeping inventory: the goods have not reached the facility, but because the buyer has paid for them they are counted as the buyer's inventory.[^2] Georgia Tech class notes list pipeline inventory first among their inventory types and describe it as in-transit or aging and curing inventory.[^3]

## Scope and distinctions

Pipeline inventory is a role-based type; see [[Inventory Type]]. It is defined by being in transit rather than by the stage of the item, unlike [[Raw Materials Inventory]] or [[Finished Goods Inventory]].[^1][^3]

A Penn State teaching note says inventory holding cost is based on average levels of cycle, safety and pipeline stocks, which treats pipeline stock as a cost-bearing part of inventory like the others.[^4] See [[Safety Stock]] for the stock held against uncertainty.

Georgia Tech's notes include aging and curing inventory under the same heading as in-transit inventory, which means the label covers stock that waits for a process as well as stock that moves.[^3] The MIT slides use the narrower in-transit sense.[^1]

## What the sources do not establish

Georgia Tech's notes give pipeline inventory as demand during the planning period multiplied by transit time in planning periods.[^3] No source opened here discusses how to reduce it.

[^1]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf
[^2]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.1: Types of Inventory”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.01%3A_Types_of_Inventory
[^3]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf
[^4]: J. E. Tyworth, Penn State Smeal College of Business SCM 810 technical note, February 2014, “Basic Multi-period Inventory Systems”. https://courses.smeal.psu.edu/SCM810/scm_810_module_3/Multi%20Period%20Inventory%20Systems%20Teaching%20Note.pdf

