Taxonomy category root for AI Infrastructure within Artificial Intelligence. The concept itself is described at [[AI Infrastructure]], which sits under this category; the category exists so the published graph can group its members.

