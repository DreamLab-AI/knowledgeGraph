Supply chain information systems are the software systems that plan, run and connect the activities of a supply chain.[^1][^2]

No source opened defines the grouping. A preprint by Zaidi, Amanton and Sanlaville describes three classes of ICT systems related to logistics: enterprise resource planning, which represents the main database for firm activity; supply chain planning, which consists of product lifecycle management, scheduling and production planning; and supply chain execution, which comprises warehouse management systems, manufacturing execution systems and transportation management systems.[^1] The authors add that supply chain information systems around the world are heterogeneous, each producing and receiving large amounts of structured and unstructured data in real time.[^1]

## Where the systems sit

The ISA-95 model, from the International Society of Automation, places manufacturing execution systems at Level 3, where they manage manufacturing operations, and enterprise resource planning at Level 4, business planning and logistics, with the standard primarily concerned with the interface between those two levels.[^2] See [[Manufacturing Execution System]].

In warehouses, the Georgia Tech course text says a warehouse management system is a large software system that coordinates the activities of the warehouse.[^3] For transport, Georgia Tech presentation slides say there is no one true definition of a transportation management system today.[^4] See [[Warehouse Management System]], [[Transportation Management System]], [[Order Management System]] and [[Global Trade Management System]].

## Between firms

GS1 describes its electronic data interchange standards as providing global standards for electronic business messaging that allow automation of business transactions across the supply chain.[^5] See [[B2B Integration]], [[Supply Chain Execution System]] and [[Supply Chain Planning System]].

## What the sources do not establish

This three-class split comes from one preprint, and other authors could draw the lines differently, for instance by placing order management or trade compliance software in execution. No opened source gives a market size or adoption data. Later pages in this domain cover visibility, control towers and digital twins, which were not part of this research.[^1][^2][^3][^4][^5]

[^1]: Fares Zaidi, Laurent Amanton and Eric Sanlaville, “Towards a Novel Cooperative Logistics Information System Framework”, arXiv:1905.00687. https://arxiv.org/pdf/1905.00687
[^2]: International Society of Automation, “ISA-95 Standard: Enterprise-Control System Integration”. https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard
[^3]: John J. Bartholdi III and Steven T. Hackman, “Warehouse & Distribution Science”, Release 0.1.2 (Georgia Tech course text, revised 24 May 2002). https://www2.isye.gatech.edu/~spyros/courses/IE6202/Fall-2002/Bartholdi-Hackman.pdf
[^4]: Georgia Tech Supply Chain and Logistics Institute, “Principles of Transportation Management” (overview presentation). https://www.scl.gatech.edu/sites/default/files/presentations/GTSCL-PrinciplesTransportationManagementOverview.pdf
[^5]: GS1, “GS1 Electronic Data Interchange (EDI) - Standards”. https://www.gs1.org/standards/edi

