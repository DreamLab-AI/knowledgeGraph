A framebuffer is a region of memory that holds the pixel data representing a complete frame to be displayed or further processed, typically organised as colour, depth, and stencil buffers. In a graphics pipeline, rendering operations write their results into a framebuffer, which the display hardware then scans out to a screen or which subsequent passes read as input. Framebuffers are central to double buffering, post-processing, off-screen rendering, and the multi-pass techniques that underpin modern real-time graphics.

### Overview

- The framebuffer is the destination of the rendering process and the bridge between computation and display. Beyond the final colour image, modern framebuffers aggregate auxiliary buffers — depth for occlusion, stencil for masking, and multiple colour attachments for deferred shading and G-buffers. Off-screen framebuffers (render targets) feed post-processing effects such as bloom, tone mapping, and anti-aliasing, while double or triple buffering prevents visible tearing by separating the buffer being drawn from the one being displayed.

### Mechanisms

- Colour, depth, and stencil attachments forming a complete frame
- Double and triple buffering to avoid tearing
- Off-screen render targets for multi-pass rendering
- Multiple render targets enabling deferred shading and G-buffers
- Scan-out of the front buffer to the display device

### Applications

- Real-time game and engine rendering
- Post-processing pipelines (bloom, tone mapping, anti-aliasing)
- Deferred and forward+ shading
- XR compositing and lens distortion correction
- GPU image processing and compute readback

### Provenance

- This class was materialised to resolve inbound references from existing classes in the knowledge graph.

