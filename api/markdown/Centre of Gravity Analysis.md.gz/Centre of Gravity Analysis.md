Centre of gravity analysis is a method for siting a single distribution facility at the volume-weighted average of the coordinates of the locations it serves.[^1][^2]

The University of Houston text introduces the method through a physical model that was used before computers: a map is laid on a table, a hole is drilled at each customer, and a string with a bag of fishing weights passes through each hole, with the number of weights matching the volume shipped to that customer.[^1] The numerical version takes the coordinates of existing locations and the volumes moved to or from each, and computes the new location as the volume-weighted average of the x coordinates and of the y coordinates.[^2][^1] In the Houston spreadsheet the x coordinate is the sum of volume-rate-x products divided by the sum of volume-rate products, and the shipping rates can be set equal if they are unknown.[^1]

## Scope and assumptions

The INFLIBNET operations management e-text says the method is predominantly used for distribution centres such as warehouses, and that it assumes the facility serves similar or only one kind of product and that inbound and outbound transport costs are equal.[^2] The Groningen lecture classes it as a continuous method, finding a location anywhere in a plane for a single facility, as against discrete methods that compare known candidate sites.[^3]

Houston and the e-text both treat the result as a starting point. Houston says the point may fall at an infeasible location and that many other factors must be considered, and the e-text says costs and demand should be considered before finalising the location.[^1][^2]

## Sources disagree on what it optimises

The Houston text says the point minimises the sum of the weighted straight-line distances to the customers, then says its model gives only an approximation to that result which can be refined by an iterative search.[^1] The Groningen lecture says the ideal location minimises distance weighted by volume of goods and presents the weighted-average calculation as giving the optimal location.[^3]

A Princeton course note treats the unweighted case and says otherwise: the centroid does not minimise the sum of the distances, it minimises the sum of the squares of the distances, and there is no simple formula for the distance-minimising location, which is found by Weiszfeld's iteration.[^4] That note concerns equal weights and does not address the weighted formula directly, so it does not settle the question for volumes. It does show that a closed-form weighted average and a minimum of weighted straight-line distance are different things in general. Readers should treat the closed-form result as a starting point, as Houston does, not as proof of minimum distance. A handbook on operations research lists minimising total weighted distance as a standard continuous objective with solution algorithms for the single-facility case.[^5]

## Related pages

[[Supply Chain Network Design]], [[Facility Location Problem]] and [[Distribution Centre]].

## What the sources do not establish

These sources are textbook and course material. None reports how often the method is used in practice, and straight-line distance ignores the road network, which Houston acknowledges only by saying other factors must be considered.[^1]

[^1]: University of Houston Bauer College of Business, operations management text, chapter 6, “Chapter 6 Facility Location”. https://www.bauer.uh.edu/egardner/3301H%20Operations%20Management/OM%20Text/6LOCATION-1.pdf
[^2]: INFLIBNET Centre, e-PG Pathshala, Operations Management, “Quantitative Methods of Deciding Facility Location”. https://ebooks.inflibnet.ac.in/mgmtp04/chapter/quantitative-methods-of-deciding-facility-location/
[^3]: Tri M. Tran, University of Groningen, lecture slides hosted by Aalto University, “Session 9: Facility location problems”. https://mycourses.aalto.fi/pluginfile.php/2142267/mod_folder/content/0/Lecture%209%20-%2015.11./LSA%202023%20Session%209%20-%20Facility%20location%20problems.pdf
[^4]: Princeton University ORF 201 course lab (Robert Vanderbei), unweighted case, “Lab 6: Facility Location”. https://vanderbei.princeton.edu/JAVA/ORF201/median/lab6.pdf
[^5]: Petropoulos, Laporte and colleagues (section 3.13 by Sibel A. Alumur), arXiv, “Operational Research: Methods and Applications”. https://arxiv.org/pdf/2303.14217

