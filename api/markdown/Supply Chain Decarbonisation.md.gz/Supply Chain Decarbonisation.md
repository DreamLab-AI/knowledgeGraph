Supply chain decarbonisation is the reduction of greenhouse gas emissions across a company's supply chain, in its suppliers' operations and in transport, and no source opened here defines the term, so the page describes measures the sources discuss.[^1][^2]

## Engaging suppliers

The Science Based Targets initiative's guidance, written for it by WWF, says that for most companies supply chain-related emissions represent a substantial portion of their scope 3 emissions.[^1] It describes supplier engagement targets as a way to influence decarbonisation within a company's supply chain when granular emissions data is challenging to track or unavailable.[^1] See [[Scope 3 Emissions]].

## Logistics

The GHG Protocol Scope 3 Standard gives an example in which a company whose largest source of value chain emissions is contracted logistics may change product packaging to increase the volume per shipment, or increase the number of low-carbon logistics providers.[^2] The GHG Protocol also reports that the Global Logistics Emissions Council, led by Smart Freight Centre, has developed a universal method for calculating logistics emissions across road, rail, air, sea, inland waterways and transhipment centres.[^3]

Shifting freight between modes is a further lever, covered at [[Modal Shift]]. The Council of the European Union's evaluation papers describe a reduction of the share of road transport towards less polluting and more energy efficient modes as a way to reduce the environmental impact of freight.[^4]

## Limits

The European Court of Auditors found that intermodal freight transport can still not compete on equal grounds with road transport because of regulatory and infrastructure barriers, which limits that lever in the EU.[^5]

None of the sources measures how much emission reduction these measures have achieved, and the SBTi, GHG Protocol and EU documents are guidance and audit material, not outcome studies. The wider branch is [[Sustainable Supply Chains]].

[^1]: Science Based Targets initiative (developed by WWF), version 1.1, July 2025, “Engaging Supply Chains on the Decarbonization Journey: A Guide to Developing and Achieving Scope 3 Supplier Engagement Targets”. https://sciencebasedtargets.org/resources/files/Supplier-Engagement-Guidance.pdf
[^2]: World Resources Institute and World Business Council for Sustainable Development, GHG Protocol, “Corporate Value Chain (Scope 3) Accounting and Reporting Standard”. https://ghgprotocol.org/sites/default/files/standards/Corporate-Value-Chain-Accounting-Reporing-Standard_041613_2.pdf
[^3]: GHG Protocol, blog post of 30 October 2019, “GLEC Framework: a universal method for logistics emissions accounting”. https://ghgprotocol.org/blog/glec-framework-universal-method-logistics-emissions-accounting
[^4]: Council of the European Union, cover note 8149/16 of 28 April 2016 (Commission staff working document SWD(2016) 140 final), “REFIT ex-post evaluation of Combined Transport Directive 92/106/EEC”. https://data.consilium.europa.eu/doc/document/ST-8149-2016-INIT/en/pdf
[^5]: European Court of Auditors, Special report 08/2023, “Intermodal freight transport: EU still far from getting freight off the road”. https://op.europa.eu/webpub/eca/special-reports/intermodal-freight-transport-08-2023/en/index.html

