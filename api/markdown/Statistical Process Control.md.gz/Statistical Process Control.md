Statistical Process Control (SPC) is a quality-control methodology that applies statistical methods to monitor and control a manufacturing or service process. By tracking process variation over time against statistically derived control limits, SPC distinguishes ordinary common-cause variation from assignable special-cause variation, enabling operators to intervene only when a process is genuinely out of control. It underpins continuous improvement and defect prevention in industrial production.

- Statistical Process Control is a [[Quality Control]] discipline that uses [[Statistics]] to monitor process variation in real time, supporting [[Process Control]] and [[Industrial Inspection]] through systematic [[Monitoring]].
- It separates random common-cause variation from assignable special-cause variation so that intervention happens only when warranted.

### Overview

- SPC emerged from early twentieth-century manufacturing as a way to make process behaviour visible and actionable. Rather than inspecting finished output for defects after the fact, SPC observes the process while it runs, plotting measurements against statistically derived limits.
- A process operating within its control limits is described as being in a state of statistical control: its output is predictable within known bounds. When points fall outside those limits, or form non-random patterns, the process signals an assignable cause that warrants investigation.
- The methodology is foundational to lean manufacturing, Six Sigma, and continuous improvement programmes, and increasingly intersects with data-driven [[Anomaly Detection]] and [[Machine Learning]].

### Key aspects

- Control limits are computed from process data itself, typically at three standard deviations from the centre line, distinguishing them from specification limits set by design requirements.
- Common-cause variation is the inherent noise of a stable process; special-cause variation is an external, identifiable disturbance.
- Process capability indices quantify how well a controlled process meets its specification tolerances.
- Run rules and pattern tests detect drifts, trends, and shifts that individual out-of-limit points might miss.
- Sampling strategy and measurement-system analysis determine the trustworthiness of the data feeding the charts.

### Applications

- Manufacturing lines use SPC to hold dimensional, weight, and assembly tolerances within bounds.
- Service and transactional processes apply SPC to cycle times, error rates, and throughput.
- Semiconductor fabrication and pharmaceutical production rely on tight SPC for yield and regulatory compliance.
- Modern industrial monitoring pipelines feed sensor streams into automated SPC, blending classical charts with [[Anomaly Detection]].

### Provenance

