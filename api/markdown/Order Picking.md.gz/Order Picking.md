Order picking is the process of retrieving products from storage, or from buffer areas, in response to a specific customer request.[^1]

A literature review by de Koster, Le-Duc and Roodbergen calls order picking the most labour-intensive operation in warehouses with manual systems and a very capital-intensive operation in warehouses with automated systems. It cites estimates that the cost of order picking is as much as 55 percent of total warehouse operating expense.[^1] Georgia Tech's open textbook gives the same share, about 55 percent of warehouse operating costs.[^2]

## System types

A review of operations and supply chain management says warehousing systems can be categorised as picker-to-parts and parts-to-picker, depending on how stock keeping units and pickers come together. In picker-to-parts systems pickers move to storage locations, and in parts-to-picker systems the units are brought to pick stations with stationary pickers.[^3] The 2007 review says the picker-to-parts systems, where the order picker walks or drives along the aisles, are most common, and describes low-level picking from racks or bins while travelling along the aisles.[^1] See [[Goods-to-Person Picking]].

## Batching and zoning

Order batching, the method of grouping a set of orders into sub-sets that can each be retrieved by a single picking tour, is described in the 2007 review.[^1] The more recent review explains that batching groups multiple customer orders into extended pick lists and zoning partitions the warehouse into smaller zones, each with a dedicated workforce.[^3]

## Scope and distinctions

Order picking is a [[Warehouse Operation]]. The mechanised alternative is covered at [[Goods-to-Person Picking]] and [[Automated Storage and Retrieval System]]. Robots that pick are covered at [[Pick and Place]].

## What the sources do not establish

A 55 percent share is an estimate for typical warehouses. Neither source says how it varies with automation or order profile.

[^1]: René de Koster, Tho Le-Duc and Kees Jan Roodbergen, European Journal of Operational Research 182(2), 2007, “Design and control of warehouse order picking: A literature review”. https://pure.eur.nl/ws/portalfiles/portal/46713708/DesignandControl_2007.pdf
[^2]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^3]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

