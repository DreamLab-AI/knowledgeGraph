A Service Endpoint is a network-addressable location, typically expressed as a URL or URI, at which a service exposes its functionality to clients. It defines where requests are sent and, together with a protocol and interface contract, how interactions are framed and authenticated. Service endpoints are central to APIs, microservices and decentralised-identity documents, where they advertise the reachable interfaces associated with an identity or capability.

### Overview

- [[API]] provides the broader context within which Service Endpoint sits.
- Service Endpoint is treated here as a member of the **security** domain at **established** maturity.
- It is referenced across the knowledge graph by classes that depend on or compose it, making it a central node that warranted an explicit definition.

### Key aspects

- It comprises [[Authentication]].
- It requires [[Transport Layer Security]].
- It makes use of [[REST API]].
- It makes use of [[HTTP]].

### Mechanisms

- Service Endpoint operates by combining its constituent parts into a coherent capability that other classes can rely upon.
- Its guarantees and behaviours are realised through the dependencies and standards captured in the relations below.

### Applications

- Enables and supports [[Service Discovery]].
- Enables and supports [[Microservices]].
- Enables and supports [[Service-Oriented Architecture]].

### Provenance

