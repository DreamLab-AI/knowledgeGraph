Network Function Virtualization (NFV) is an architectural paradigm that decouples network functions — such as firewalls, load balancers, intrusion detection systems, and routers — from dedicated proprietary hardware appliances and implements them as software running on commercial off-the-shelf (COTS) servers, switches, and storage. Standardised by ETSI's NFV Industry Specification Group, NFV introduces a three-layer model comprising the NFV Infrastructure (NFVI), Virtual Network Functions (VNFs), and the NFV Management and Orchestration (MANO) framework. By enabling elastic provisioning, rapid deployment, and lifecycle automation of network services, NFV reduces capital and operational expenditure while providing the flexibility required for 5G, edge computing, and cloud-native telecom architectures. It is closely related to and operationally complementary with Software-Defined Networking (SDN), which separates the network control plane from the data plane.

### Overview

- NFV emerged from a 2012 white paper co-authored by thirteen major telecom operators who proposed moving network functions from bespoke hardware to standard, high-volume servers and storage.
- The central insight is that network functions — routing, deep packet inspection, session border control, WAN acceleration — are fundamentally software algorithms that do not inherently require dedicated silicon.
- By hosting these functions as [[Virtual Machine|virtual machines]] or [[Container Orchestration|containers]], operators gain the same elastic scalability and rapid iteration cycles that have transformed enterprise IT via [[Cloud Computing]].
- NFV is operationally complementary to [[Software-Defined Networking]] (SDN): SDN separates the control plane from the data plane; NFV virtualises the network functions themselves. Together they form the basis of cloud-native telecom infrastructure.
- The technology underpins carrier-grade deployments including [[5G Networks]], [[Telecom Cloud]] platforms, and [[Multi-Access Edge Computing]] nodes, where rapid, programmable service instantiation is essential.

### Key Components

#### NFV Infrastructure (NFVI)

- The physical and virtual resources on which VNFs execute: compute (CPU, GPU), storage, and networking hardware.
- A virtualisation layer (hypervisor or container runtime) abstracts physical resources into virtual resources.
- Typical hardware: COTS x86 servers, high-bandwidth NICs with [[SR-IOV]], and software switches such as [[Open vSwitch]].

#### Virtual Network Functions (VNFs)

- Software implementations of traditional network appliances: virtual firewalls, vEPC (evolved packet core), virtual CDN nodes, virtual IMS (IP multimedia subsystem).
- VNFs are packaged as images (QCOW2, OCI container images) with descriptors specifying compute, memory, and connectivity requirements.
- [[Cloud-Native Network Function|Cloud-Native Network Functions (CNFs)]] are the container-based, microservices-aligned evolution of VNFs, running on [[Kubernetes]] with [[Service Mesh]] support.

#### NFV Management and Orchestration (MANO)

- The [[NFV Management and Orchestration]] layer comprises three functional blocks:
  - **NFV Orchestrator (NFVO)**: manages lifecycle of network services and resource orchestration across NFVI.
  - **VNF Manager (VNFM)**: handles instantiation, scaling, healing, and termination of individual VNFs.
  - **Virtualised Infrastructure Manager (VIM)**: controls compute, storage, and network resources (e.g., [[OpenStack]], [[Kubernetes]]).
- Open-source MANO implementations include ETSI OSM (Open Source MANO) and [[ONAP]] (Open Network Automation Platform).

#### Service Function Chaining (SFC)

- [[Service Function Chaining]] defines ordered sequences of VNFs that traffic must traverse — e.g., firewall → load balancer → DPI — without hardcoding physical paths.
- Standardised in IETF RFC 7665; implemented via [[Network Service Header]] (NSH) encapsulation.

### Applications and Use Cases

- **5G Core Virtualisation**: NFV is fundamental to the 3GPP 5G core specification, where all core network functions (AMF, SMF, UPF, PCF) are defined as software services deployable on NFVI or cloud platforms.
- **[[Network Slicing]]**: NFV provides the resource abstraction layer enabling operators to carve logically isolated, SLA-bound network slices for different service classes (eMBB, URLLC, mMTC) over shared physical infrastructure.
- **[[Multi-Access Edge Computing]] (MEC)**: VNFs are instantiated at edge nodes to deliver low-latency services including video transcoding, AR/VR stream processing, and real-time analytics.
- **SD-WAN**: Enterprise [[Software-Defined Wide Area Network]] deployments use VNFs to replace branch-office hardware appliances with software running on standard routers or cloud instances.
- **Virtual CPE (vCPE)**: Carrier-managed customer premises equipment moves firewall, VPN gateway, and WAN optimisation functions to cloud-hosted VNFs, simplifying on-site hardware.
- **Security Functions Virtualisation**: Virtual intrusion prevention, DDoS mitigation, and [[Firewall]] services can be spun up elastically in response to traffic anomalies, enabling adaptive [[Network Security]] postures.
- **IoT Gateway Functions**: NFV enables scalable protocol translation and data aggregation functions for [[Internet of Things]] deployments without deploying dedicated gateways per site.
- **[[Edge AI]] Inference**: Emerging use case — AI inference VNFs co-located at the edge support real-time inference for autonomous vehicles, smart cameras, and industrial automation.

### Standards and Governance

- **ETSI NFV ISG**: The primary standardisation body. The ETSI NFV Release 4 and Release 5 specifications define architecture, interfaces, and descriptors (TOSCA-based [[Network Service Descriptor|NSDs]] and [[VNF Descriptor|VNFDs]]).
- **3GPP**: Incorporates NFV as a foundational assumption in 5G core network specifications (TS 23.501, TS 28.500-series for management).
- **IETF SFC Working Group**: Defines the [[Service Function Chaining]] architecture and [[Network Service Header]] (RFC 8300).
- **ONAP**: The [[Linux Foundation]] [[ONAP|Open Network Automation Platform]] provides open-source MANO and orchestration aligned with ETSI NFV and 3GPP management models.
- **ETSI OSM**: Open Source MANO project under ETSI providing a reference MANO implementation supporting multiple VIM backends.
- **O-RAN Alliance**: Extends NFV principles to radio access network functions, specifying open, virtualised [[O-RAN]] CU/DU architectures deployable on COTS hardware.
- **TM Forum**: Provides business process and API standards (Open APIs) that integrate with NFV orchestration for end-to-end service management.
- **MEF (Metro Ethernet Forum)**: Defines SD-WAN and carrier ethernet services that leverage NFV for virtualised service delivery.
- TOSCA (Topology and Orchestration Specification for Cloud Applications) is the descriptor language standardised by OASIS and adopted by ETSI for VNF and NS packaging.

### Architectural Considerations

- **Performance**: Virtualisation overhead is a key concern. Technologies such as [[SR-IOV]], [[DPDK]] (Data Plane Development Kit), and hardware offload cards (SmartNICs) bridge the gap between software VNFs and hardware appliance throughput.
- **High Availability**: VNF lifecycle management must support auto-healing, redundancy, and geo-redundant placement to meet carrier-grade SLAs (99.999% availability).
- **Security**: The expanded attack surface (hypervisor, management plane, orchestrator) introduces risks not present in closed hardware. [[Zero Trust Network Access]] principles apply to inter-VNF communication.
- **Multi-Vendor Interoperability**: ETSI NFV defines open interfaces (Os-Ma-nfvo, Ve-Vnfm-em) to allow multi-vendor VNF ecosystems; in practice, integration complexity remains high.
- **Cloud-Native Evolution**: The industry trajectory moves from VM-based VNFs toward CNFs on [[Kubernetes]], leveraging [[Helm]] charts, [[Istio]] service meshes, and GitOps workflows for lifecycle management.

### Provenance

