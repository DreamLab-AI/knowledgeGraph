A neural network latent space is a continuous, lower-dimensional manifold that a neural network learns to construct from high-dimensional input data, representing the data's underlying generative factors as geometric relationships between points. Encoder networks compress inputs into latent vectors that capture semantically meaningful structure, while decoder networks reconstruct outputs from those vectors; the resulting geometry encodes similarity such that interpolation along geodesics yields semantically coherent transitions. Architectures including variational autoencoders, generative adversarial networks, and diffusion models exploit structured latent spaces to enable sampling, conditional generation, and disentangled attribute control through vector arithmetic operations.

### Overview

- Neural networks trained on large corpora develop internal representations that compress the statistical regularities of their training distribution into a compact geometric form known as the latent space.
- The core insight, formalised through [[Representation Learning]] and the [[Manifold Hypothesis]], is that real-world high-dimensional data (images, text, audio) lies on a much lower-dimensional manifold embedded within the input space.
- A well-trained model learns a mapping that unfolds this manifold, placing semantically similar data near each other in the latent space.
- **Why it matters:**
  - Enables compression: a latent vector of hundreds or thousands of dimensions replaces millions of raw pixels or tokens.
  - Enables generation: sampling new latent points and decoding them produces novel, realistic outputs.
  - Enables control: vector arithmetic (e.g. "king − man + woman ≈ queen" in [[Word2Vec]]-style spaces) allows attribute manipulation.
  - Enables retrieval: [[Semantic Embedding]] search finds conceptually related items without lexical overlap.
- The latent space concept is foundational to virtually every modern generative architecture and large-scale retrieval system.

### Key Components

#### Encoder

- Maps raw input (image, text, audio) to a latent representation.
- In [[Variational Autoencoders]] the encoder outputs a mean and variance vector, parameterising a Gaussian distribution rather than a deterministic point.
- In [[Generative Adversarial Network]]s, the generator implicitly defines a mapping from a prior noise distribution to the data space, without an explicit encoder unless combined in an encoder-GAN variant.
- Relies on [[Backpropagation]] through successive layers of the [[Encoder-Decoder]].

#### Decoder / Generator

- Inverts the encoder mapping: takes a [[Latent Vector]] and reconstructs a plausible data sample.
- In [[Diffusion Model]]s the "decoder" is an iterative denoising network rather than a single-pass feedforward network.
- Quality of reconstruction is governed by the reconstruction loss plus any regularisation imposed on the latent distribution.

#### Latent Vector

- The point in latent space assigned to a specific input.
- Dimensionality is a design choice: lower dimensionality forces stronger compression, higher dimensionality preserves finer detail but risks sparsity.
- Structured latent vectors from [[Disentangled Representation]] learning correspond individual dimensions to interpretable generative factors (pose, lighting, colour).

#### Latent Code

- Discrete variant of the latent vector used in models such as VQ-VAE (Vector Quantised VAE), where the continuous space is replaced by a discrete codebook of [[Latent Code]] entries.
- Enables efficient compression and compatibility with autoregressive generation over a vocabulary of learned codes.

#### Prior Distribution

- The distribution over latent space assumed during training (typically an isotropic Gaussian for VAEs).
- Determines what points are "valid" samples; mismatch between the prior and the aggregate posterior leads to holes or discontinuities in the generated outputs.
- [[Variational Inference]] provides the theoretical basis for optimising the encoder to match this prior via the KL divergence term in the ELBO objective.

### Mechanisms

#### Dimensionality Reduction and Compression

- [[Dimensionality Reduction]] through the encoder bottleneck is the fundamental mechanism: only information predictive of the output is preserved.
- Classical linear methods such as [[Principal Component Analysis]] can be viewed as shallow, linear precursors to deep latent spaces.
- Non-linear alternatives like t-SNE and UMAP operate on pre-computed embeddings and serve primarily as visualisation tools rather than generative mechanisms.

#### Interpolation

- Smooth interpolation between two latent vectors z1 and z2 (linear or spherical) produces intermediate decoded outputs that blend properties of both inputs.
- Valid interpolation requires the latent space to be both continuous and dense — a property explicitly enforced by the KL regularisation in [[Variational Autoencoders]].

#### Vector Arithmetic

- Additive operations in latent space correspond to semantic transformations in data space.
- First demonstrated clearly in [[Word2Vec]] embeddings; subsequently shown in image latent spaces (face attribute editing in GANs, style mixing in StyleGAN).
- Enables zero-shot attribute transfer without retraining.

#### Conditioning and Guidance

- In text-conditioned [[Image Synthesis]] (e.g. Stable Diffusion), a [[Semantic Embedding]] of the text prompt is injected into the denoising network's cross-attention layers, effectively steering the trajectory through latent space.
- Classifier-free guidance amplifies the conditional direction relative to the unconditional direction in latent space, trading diversity for fidelity.

#### Disentanglement

- A [[Disentangled Representation]] separates independent generative factors into distinct latent dimensions.
- Methods such as beta-VAE and FactorVAE impose additional constraints on the posterior to encourage axis-aligned factor recovery.
- Disentangled latent spaces support systematic generalisation and more predictable attribute editing.

### Applications

#### Image and Video Generation

- [[Generative Adversarial Network]]s (GANs) and [[Diffusion Model]]s both exploit structured latent spaces to produce photorealistic imagery.
- [[Text-to-Image Generation]] models (Stable Diffusion, DALL-E, Imagen) encode text prompts into [[Semantic Embedding]]s that guide sampling through a latent diffusion space.
- Video generation extends the latent space to temporal sequences, requiring temporal coherence across decoded frames.

#### Drug Discovery and Molecular Design

- [[Deep Neural Network]]s trained on molecular graphs map chemical compounds into a latent space where molecular properties vary smoothly.
- Optimisation algorithms (Bayesian optimisation, gradient ascent) navigate the latent space to find novel molecules with desired pharmacological properties.

#### Natural Language Processing

- Large language models develop rich token-level and sequence-level latent representations that encode grammatical structure, world knowledge, and reasoning chains.
- [[Semantic Embedding]] vectors derived from transformer encoders underpin semantic search, clustering, and cross-lingual transfer.

#### Style Transfer

- [[Style Transfer]] separates content and style in the latent space and recombines them: the content vector of one image with the style vector of another.
- Used in artistic image generation, video stylisation, and adaptive UI theming.

#### Anomaly Detection

- Points that cannot be accurately reconstructed from their latent representation (high reconstruction error) indicate anomalies or out-of-distribution samples.
- Applied in industrial quality control, network intrusion detection, and medical imaging.

#### 3D Spatial Representation

- In spatial-computing applications, latent spaces encode 3D scenes, shape priors, and scene appearance (NeRF-based methods compress scene radiance fields into compact latent codes).
- Bridges to [[3D Scene Understanding]] and [[Spatial Data Representation]] for AR/VR environments.

#### Personalisation and Recommendation

- User and item embeddings in collaborative filtering systems occupy a shared latent space; dot products or cosine similarities in that space predict preference.

### Standards & Context

- There is no single standardising body governing latent space design; the field evolves through peer-reviewed research at venues including NeurIPS, ICML, ICLR, CVPR, and ECCV.
- The [[Variational Autoencoders]] framework (Kingma & Welling) and the GAN framework (Goodfellow et al.) established the foundational formalisms for structured latent spaces.
- The [[Diffusion Model]] framework (Ho et al.; Song et al.) introduced latent diffusion as a computationally tractable alternative that preserves semantic structure.
- Latent diffusion models (Rombach et al., "High-Resolution Image Synthesis with Latent Diffusion Models") shifted generation to a compressed latent domain, reducing compute requirements dramatically.
- Industrial implementations include: Stability AI (Stable Diffusion), OpenAI (DALL-E, CLIP embeddings), Google DeepMind (Imagen), Meta AI (LLaMA latent representations).
- Interpretability and alignment research increasingly focuses on understanding the geometry of latent spaces in large language models, particularly through the lens of [[Representation Learning]] and mechanistic interpretability.

### Provenance

