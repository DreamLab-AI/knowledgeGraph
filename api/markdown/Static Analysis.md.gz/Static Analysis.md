Static analysis is the examination of software source code, byte code or binaries without executing the program, in order to detect defects, security vulnerabilities, style violations and correctness properties. Techniques range from simple pattern-based linting to formal abstract interpretation and data-flow analysis over the program's control structure. It is commonly integrated into editors and continuous-integration pipelines to provide early feedback before code runs.

### Overview

- Static analysis inspects a program's structure rather than its runtime behaviour, allowing defects to be found without test inputs.
- It complements dynamic testing by reasoning about all possible execution paths through control-flow and data-flow abstractions.
- Modern tooling embeds static analysis directly into editors and continuous-integration systems for immediate developer feedback.

### Mechanisms

- Pattern-based linters flag stylistic and common-error constructs using syntactic rules.
- Abstract interpretation soundly over-approximates program states to prove the absence of whole classes of bugs.
- Data-flow and taint analysis track how values propagate to detect injection and information-leak vulnerabilities.
- Type checking and [[Formal Verification]] extend analysis toward provable correctness guarantees.

### Applications

- Automated [[Code Review]] gates that block defective changes before merge.
- [[Security Audit]] pipelines that surface vulnerable patterns in source code.
- Compiler-integrated diagnostics that improve [[Code Generation]] quality.
- Quality enforcement within [[Software Testing]] workflows.

### Provenance

