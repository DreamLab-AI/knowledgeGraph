The October 2008 technical paper by pseudonymous author Satoshi Nakamoto, titled 'Bitcoin: A Peer-to-Peer Electronic Cash System', which introduced the design of a decentralised digital currency that eliminates reliance on trusted third parties. It proposed a chain of cryptographically linked blocks secured by proof-of-work consensus to prevent double-spending without a central authority. The paper synthesised prior work on digital cash, cryptographic hash functions, and distributed timestamps into a coherent, deployable protocol that was subsequently realised in the January 2009 Bitcoin genesis block launch.

### Overview

- Published on 31 October 2008 to the Cryptography Mailing List, the whitepaper arrived during a period of acute crisis in traditional finance and proposed a radical alternative: a currency whose integrity depended solely on mathematical proof and distributed consensus rather than institutional trust.
- The paper is notable for its concision — nine pages — while covering cryptographic primitives, network topology, incentive design, and privacy considerations with sufficient rigour to serve as a direct implementation blueprint.
- [[Satoshi Nakamoto]]'s identity has never been confirmed; the name is widely assumed to be a pseudonym for an individual or small group. The paper was followed by the release of open-source reference software and the mining of the [[Genesis Block]] in January 2009.
- The whitepaper's influence extends far beyond [[Bitcoin]] itself: it catalysed the fields of [[Decentralised Finance]], [[Smart Contract]] platforms, [[Distributed Ledger]] technology, and continues to shape debates around digital sovereignty and [[Monetary Policy]].

### Key Components

#### Transactions

- Defines a coin as a chain of [[Digital Signature]]s: each owner signs a hash of the previous transaction together with the public key of the next owner.
- Uses [[Elliptic Curve Cryptography]] (implicitly via the reference implementation) to generate [[Public Key Infrastructure]] keypairs.
- Introduces the [[Unspent Transaction Output]] (UTXO) model, tracking spendable outputs rather than account balances.

#### Timestamp Server and Blockchain

- Proposes a [[Distributed Ledger]] in which every block contains a [[Cryptographic Hash Function]] of the previous block, creating an immutable sequence.
- Employs a [[Merkle Tree]] structure inside each block to allow efficient verification of individual transactions without downloading the full chain.
- The chain of hashes constitutes the "blockchain", a term that became the common descriptor for this family of data structures.

#### Proof-of-Work Consensus

- Borrows [[Hashcash]]'s mechanism of requiring miners to find a nonce such that the [[SHA-256]] double-hash of the block header falls below a target value.
- Difficulty adjusts every 2,016 blocks (approximately two weeks) to maintain an average ten-minute inter-block interval.
- The longest chain — the one embodying the greatest cumulative computational work — is the canonical chain, providing [[Byzantine Fault Tolerance]] against attackers controlling less than half the network's hash rate (the "51% attack" threshold).

#### Incentive Mechanism

- New coins are minted in the [[Coinbase Transaction]] of each block, creating an economic incentive for miners to extend the honest chain.
- Block reward halves roughly every four years (the "halving"), enforcing a hard supply cap of 21 million [[Bitcoin]].
- Long-term security is designed to transition from block subsidies to transaction fees as the primary miner incentive.

#### Privacy Model

- Separates identities from public keys: while all transactions are publicly auditable, addresses are pseudonymous.
- Recommends generating a new keypair per transaction to limit linkability, anticipating later formalisation in [[Bitcoin Improvement Proposal]] standards.

#### Simplified Payment Verification (SPV)

- Describes how lightweight clients can verify transactions without running a full node by checking only [[Merkle Tree]] proofs against block headers obtained from [[Peer-to-Peer Network]] peers.
- This design underpins [[Bitcoin]] mobile wallets and is foundational to [[Payment Channel]] designs including the [[Lightning Network]].

### Technical Mechanisms

#### SHA-256 Hash Chaining

- Each block header commits to the previous block's hash, the [[Merkle Tree]] root of its transactions, a timestamp, the difficulty target, and a nonce.
- Altering any historical block would require redoing its [[Proof of Work]] and every subsequent block — computationally infeasible against a majority-honest network.

#### Nakamoto Consensus

- Nodes always extend the chain with the greatest cumulative difficulty; no explicit voting or leader election is required.
- [[Byzantine Fault Tolerance]] is probabilistic: the probability of a successful double-spend falls off exponentially with the number of confirming blocks.

#### Network Propagation

- The [[Peer-to-Peer Network]] uses a gossip protocol; new transactions and blocks are broadcast to all connected peers.
- Race conditions at the tip of the chain (natural forks) are resolved by the longest-chain rule within minutes.

### Applications

#### Peer-to-Peer Payments

- The whitepaper's stated goal: enabling direct, irreversible payments between parties without a bank or payment processor.
- Realised commercially through wallets, exchanges, and payment processors built atop the [[Bitcoin Protocol]].

#### Store of Value

- Bitcoin's fixed supply schedule, derived directly from the whitepaper's incentive model, underpins its positioning as a "digital gold" hedge against [[Monetary Policy]] inflation.

#### Layer-2 Protocols

- [[Lightning Network]] uses bidirectional [[Payment Channel]]s to enable high-frequency, low-fee micropayments off-chain, settling on-chain via Bitcoin's [[Unspent Transaction Output]] model.

#### Alternative Blockchain Designs

- Ethereum, Litecoin, and hundreds of subsequent projects either extended or intentionally diverged from the whitepaper's design, making it the de facto canonical reference for [[Blockchain Technology]].

#### Academic and Regulatory Reference

- Cited extensively in computer science, economics, and law literature. Regulators worldwide reference the whitepaper to characterise [[Cryptocurrency]] for classification under securities, commodities, or payments frameworks.

#### [[Decentralised Finance]] (DeFi)

- The whitepaper's trustless transaction logic inspired [[Smart Contract]] platforms and [[Decentralised Autonomous Organisation]] governance models, bridging into broader [[Distributed Systems]] design.

#### [[Zero-Knowledge Proof]] Integration

- Later cryptographic research (Zcash, STARKs, ZK-rollups) builds on the whitepaper's privacy principles while extending them with formal zero-knowledge techniques, representing a cross-domain bridge from [[Blockchain Technology]] to advanced [[Security]] cryptography.

### Standards & Context

- The whitepaper itself carries no formal standards-body number; it is an informal publication circulated via mailing list, yet it functions as the de facto specification.
- [[Bitcoin Improvement Proposal]] (BIP) process formalises extensions to the original protocol; BIPs must be compatible with the whitepaper's core invariants (UTXO model, [[Proof of Work]], 21-million supply cap).
- Regulatory context: the U.S. CFTC treats [[Bitcoin]] as a commodity; the EU's MiCA regulation explicitly categorises it separately from asset-referenced tokens; the whitepaper's pseudonymous authorship raises persistent questions in [[Intellectual Property]] law.
- The [[Cypherpunk Movement]] mailing list, on which the whitepaper was first posted, had previously hosted discussion of [[Hashcash]], b-money, bit gold, and [[Digital Signature]] schemes — situating the paper within a decade-long tradition of privacy-preserving digital cash research.
- Academic treatment: the whitepaper is studied in distributed systems curricula alongside the [[Byzantine Fault Tolerance]] literature (Lamport, Shostak, Pease) and the broader [[Cryptographic Hash Function]] canon.

### Provenance

