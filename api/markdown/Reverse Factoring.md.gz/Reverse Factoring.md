Reverse factoring is a buyer-led financing arrangement in which suppliers can obtain early payment on invoices that the buyer has approved. The Global Supply Chain Finance Forum's standard terminology calls it payables finance and lists reverse factoring and approved payables finance among the synonyms.[^1][^2]

The 2016 Standard Definitions for Techniques of Supply Chain Finance define payables finance as provided through a buyer-led programme within which sellers in the buyer's supply chain are able to access finance by means of receivables purchase.[^1] It gives the seller the option of receiving the discounted value of receivables, represented by outstanding invoices, before their due date, typically at a financing cost aligned with the credit risk of the buyer, and the payable continues to be due by the buyer until its due date.[^1] The Forum decided that Payables Finance is a generic and neutral expression that captures the essence of the technique.[^1]

## How it works

Finance providers rely on the creditworthiness of the buyer and typically grant the financing without recourse to the seller, although the standard says it is common for certain elements of recourse to be retained against the seller, such as for breaches of representations and warranties.[^1] The Forum's technique description adds that in all cases the invoices have been approved for payment by the buyer.[^2]

FASB describes the same arrangement for accounting. It says supplier finance programs allow a buyer to offer its suppliers access to payment in advance of an invoice due date, paid by a third-party finance provider or intermediary on the basis of invoices that the buyer has confirmed as valid.[^3] A program has three characteristics: the entity agrees with a finance provider or intermediary, the entity confirms supplier invoices as valid under that agreement, and the supplier has the option to request early payment from a party other than the entity.[^3]

## Scope and distinctions

Reverse factoring is a technique within [[Supply Chain Finance]]. In factoring proper, the seller sells receivables to a factor that typically manages the debtor portfolio; see [[Receivables Factoring]].[^1]

## What the sources do not establish

Both the standard and the forum document come from the same forum, so they are not independent of each other. FASB is the independent witness for the structure. The sources do not give pricing, volumes or default experience, and they do not compare buyer-led programmes with seller-led finance beyond the definitions.[^1][^2][^3]

[^1]: Global Supply Chain Finance Forum (ICC Banking Commission, BAFT, Euro Banking Association, Factors Chain International and ITFA), “Standard Definitions for Techniques of Supply Chain Finance”, 2016 (Internet Archive copy of the ICC PDF). https://web.archive.org/web/2023/https://cdn.iccwbo.org/content/uploads/sites/3/2017/01/ICC-Standard-Definitions-for-Techniques-of-Supply-Chain-Finance-Global-SCF-Forum-2016.pdf
[^2]: Global Supply Chain Finance Forum, “GSCFF APF Techniques”, Payables Finance technique description (Trade Finance Global copy). https://tradefinanceglobal.com/wp-content/uploads/2020/11/GSCFF-APF-Techniques.pdf
[^3]: Financial Accounting Standards Board, “Liabilities—Supplier Finance Programs (Subtopic 405-50): Disclosure of Supplier Finance Program Obligations”, Accounting Standards Update No. 2022-04. https://storage.fasb.org/ASU%202022-04.pdf

