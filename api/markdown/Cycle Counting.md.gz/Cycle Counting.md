Cycle counting is the periodic physical counting of inventory at times other than fiscal year-end, to verify that controls work and that recorded quantities are reasonably close to those expected.[^1]

The Ohio State University inventory policy defines a cycle count as a periodic physical inventory count performed at a time other than fiscal year-end as a verification of the effectiveness of the controls in place, and to verify that the inventory quantities are reasonably close to those expected as a result of activity since the last cycle count. It separates this from the annual physical inventory count recorded in the unit balance sheet.[^1]

## Frequency by class

That policy allows a unit to perform and document periodic cycle counts based on an ABC classification where a perpetual system is used. A items are counted every 30 days, B items every 60 days and C items every 90 days.[^1] See [[ABC Analysis]].

## Audit findings

A Texas Department of Transportation internal audit sought to determine the adequacy of controls over the management and reporting of inventory. It found that 100,962 of 152,869 inventory items, 66 percent, were counted outside the required count frequency, with 31 percent of A items counted 31 days or more past due 43 percent of the time. It also found that count sheets included pre-populated quantities from the enterprise system, so that the counts were not blind.[^2] The audit shows the practice in one agency, and it does not give an industry rate.[^2]

## Scope and distinctions

Cycle counting is an [[Inventory Control Practice]] that checks record accuracy; it is different from the planning decisions in [[Inventory Policy]]. A year-end physical count remains a separate event in the Ohio State policy.[^1] See [[Inventory Management]].

## What the sources do not establish

Opened sources do not say how accurate cycle counts need to be, or what error rate justifies replacing an annual count.

[^1]: The Ohio State University, “Inventory” (university policy). https://policies.osu.edu/sites/default/files/documents/2024/09/inventory-policy.pdf
[^2]: Texas Department of Transportation, Internal Audit Division, October 2018, “Physical and Cycle Count Inventory Procedures”. https://ftp.txdot.gov/pub/txdot-info/aud/reports/phys_cycle_count_inv_procedures_final_audit_report.pdf

