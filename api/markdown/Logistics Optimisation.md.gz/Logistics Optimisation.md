Logistics optimisation is the use of mathematical optimisation and operational research methods to choose routes and facility locations, and to arrange loads, within cost and feasibility constraints.[^1]

No opened source defines the phrase itself. This page is bounded by the problems that the operational research literature treats as optimisation problems in logistics.[^1][^2]

## Problems covered

Vehicle routing asks for a set of routes for a fleet of vehicles, based at one or more depots, that delivers goods to a given set of customers under a set of conditions at minimum overall transportation cost.[^1] Dantzig and Ramser introduced it in 1959 for a fleet of gasoline delivery trucks between a bulk terminal and many service stations, and their abstract gives a procedure based on a linear programming formulation for a near-optimal solution.[^3][^1] See [[Vehicle Routing Problem]]. Khayya, Medarhri and Zine call the administration and strategising of distribution networks for vehicle fleets a “crucial component” within any logistics framework.[^2]

The Petropoulos and Laporte review describes facility location as finding the best placement of facilities from geographical demands, installation costs and transportation costs so as to minimise total cost.[^1] It also notes that applications in 3D container loading bring constraints on the arrangement of boxes, covering weight distribution, the stability of the load and the strength of stacked boxes.[^1]

## Methods

For the capacitated routing problem the review reports that branch-cut-and-price is the most successful exact framework at the time of writing. It also reports that metaheuristics can solve very large instances in limited computing time, without a proof of optimality for the solutions found.[^1] The review names the hybrid genetic algorithm among the popular frameworks, and a 2022 competition aimed at developing and comparing machine learning techniques for the problem.[^1]

## Scope and distinctions

Rodrigue lists the choice of modes, terminals, routes and scheduling among the sources of efficiency in freight mobility. See [[Transport Planning]].[^4] Network flow, inventory placement and specific solver technologies are sometimes attached to the term; the opened sources do not establish them for logistics as a whole, so they are not asserted here.[^1][^2]

## Evidence limits

The Dantzig and Ramser and Khayya records were read as abstracts only; their full texts were not opened.[^3][^2]

[^1]: Fotios Petropoulos, Gilbert Laporte and colleagues, “Operational Research: Methods and Applications”, arXiv:2303.14217. https://arxiv.org/pdf/2303.14217
[^2]: E. Khayya, I. Medarhri and R. Zine, “A survey of the vehicle routing problem and its variants: formulations and solutions”, Mathematical Modeling and Computing 11(1), abstract record. https://science.lpnu.ua/node/34084
[^3]: G. B. Dantzig and J. H. Ramser, “The Truck Dispatching Problem”, Management Science 6(1), abstract record on IDEAS/RePEc. https://ideas.repec.org/a/inm/ormnsc/v6y1959i1p80-91.html
[^4]: Jean-Paul Rodrigue, The Geography of Transport Systems, “7.4 – Logistics and Freight Distribution”. https://transportgeography.org/contents/chapter7/logistics-freight-distribution/

