Taxonomy category root for Software Engineering within Infrastructure. The concept itself is described at [[Software Engineering]], which sits under this category; the category exists so the published graph can group its members.

