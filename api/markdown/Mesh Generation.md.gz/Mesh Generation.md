Mesh generation is the process of constructing a discrete representation of a geometric domain as a network of vertices, edges and faces - typically triangles or tetrahedra - suitable for rendering, simulation or analysis. It transforms continuous shapes, point clouds or implicit surfaces into well-formed polygonal or volumetric meshes that meet quality, density and topology constraints. Mesh generation underpins computer graphics, 3D reconstruction and numerical simulation.

- [[Mesh Generation]] constructs a discrete representation of a geometric domain as a network of vertices, edges and faces, usually triangles or tetrahedra, ready for rendering or analysis. It is a core task of [[Computer Graphics]].
- It turns continuous shapes, [[Point Cloud]]s or a [[Signed Distance Function]] into well-formed meshes, and is closely related to [[Point Cloud Generation]] and [[Neural Radiance Field]] reconstruction.

### Overview

- A mesh is the workhorse data structure of 3D computing: it approximates surfaces (for rendering) or volumes (for simulation) with simple polygonal or polyhedral elements.
- Surface mesh generation reconstructs a watertight shell from sampled points or an implicit field, while volume mesh generation fills the interior with tetrahedra or hexahedra for physical simulation.
- Quality matters: element shape, size grading and topology determine rendering fidelity and the accuracy and stability of numerical solvers run on the mesh.

### Mechanisms

- Triangulation: Delaunay and advancing-front methods produce well-shaped triangles.
- Implicit surface extraction: marching cubes and dual contouring meshes a signed distance field.
- Point-cloud reconstruction: Poisson and ball-pivoting build surfaces from scans.
- Remeshing and simplification: refine or decimate to target resolution and quality.
- Quality control: aspect-ratio and angle constraints keep elements well-conditioned.

### Applications

- Rendering reconstructed objects and scenes in graphics pipelines.
- Producing simulation-ready meshes for finite-element and fluid analysis.
- Converting LiDAR and photogrammetry point clouds into usable models.
- Asset creation for games, AR/VR and digital twins in spatial computing.

### Provenance

