Mechanisms, architectures, and toolchains that translate declarative security and governance rules into runtime decisions—permitting, denying, mutating, or auditing operations across compute, data, network, and AI systems.

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:hasPart infra:PolicyAdministrationPoint))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:hasPart infra:PolicyDecisionPoint))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:hasPart infra:PolicyEnforcementPoint))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:hasPart infra:PolicyInformationPoint))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:hasPart infra:AuditLogger))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:hasPart infra:PolicyRetrievalPoint))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:hasPart infra:RemediationHandler))

    ## Dependency Relationships
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:requires infra:AuthenticationService))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:requires infra:IdentityManagement))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:requires infra:PolicyLanguage))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:requires infra:AttributeStore))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:requires infra:AuditInfrastructure))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:dependsOn infra:CloudNativeInfrastructure))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:dependsOn infra:CryptographicSecurity))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:dependsOn infra:ServiceMesh))

    ## Capability Relationships
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:enables infra:ComplianceAssurance))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:enables infra:AuditTrail))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:enables infra:RegulatoryAdherence))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:enables infra:ZeroTrustEnforcement))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:enables infra:RuleAsCode))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:supports infra:AIGovernance))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:supports infra:IncidentResponse))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:supports infra:SupplyChainSecurity))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:supports infra:DataMinimisation))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:supports infra:LeastPrivilege))

    ## Implementation Relationships
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:implements infra:RBAC))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:implements infra:ABAC))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:implements infra:ReBAC))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:implements infra:PBAC))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:implements infra:xACML))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:uses infra:Rego))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:uses infra:CedarPolicyLanguage))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:uses infra:OpenPolicyAgent))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:uses infra:KubernetesAdmissionWebhook))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:uses infra:eBPF))

    ## Reduction Relationships
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:reduces infra:PolicyDrift))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:reduces infra:PrivilegeEscalation))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:reduces infra:LateralMovement))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:reduces infra:ComplianceGap))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:reduces infra:ManualAuditBurden))
    SubClassOf(infra:PolicyEnforcement
      ObjectSomeValuesFrom(infra:reduces infra:UnauthorisedDataAccess))

## About Policy Enforcement

- **Policy Enforcement** is the cross-cutting discipline of ensuring that declarative security, governance, and compliance rules are consistently applied at every decision point within a computing environment—API gateway, database query, container admission, service-mesh call, data pipeline, AI model invocation, and physical access request alike. The discipline addresses a fundamental tension: human-readable policies and machine-enforced controls must remain semantically equivalent as systems scale to millions of operations per second and hundreds of microservices, while simultaneously satisfying regulators, auditors, and end users.
- The foundational decomposition originates in the OASIS XACML (eXtensible Access Control Markup Language) standard: a **Policy Administration Point (PAP)** manages the authoritative policy repository; a **Policy Retrieval Point (PRP)** vends applicable policies to the decision engine; a **Policy Decision Point (PDP)** evaluates a structured access request against retrieved policies and returns an authorization decision (Permit, Deny, Indeterminate, NotApplicable); a **Policy Information Point (PIP)** resolves missing attributes at evaluation time (group membership, real-time risk scores, geographic lookups); and a **Policy Enforcement Point (PEP)** intercepts the subject's request, constructs the authorization request, sends it to the PDP, and enforces the returned decision by either passing the request through, blocking it, or redirecting to an error handler. This loosely coupled, five-tier architecture enables **separation of concerns**: enforcement logic can be updated independently of application code, policy decisions can be cached and replicated for sub-millisecond latency, and every decision can be logged with full request context for audit.

### Access Control Paradigms

- **Role-Based Access Control (RBAC)** is the baseline model in which subjects are assigned one or more roles (Admin, Editor, Viewer, Billing), roles carry sets of permissions (read:invoice, write:invoice, delete:user), and access decisions reduce to role membership lookup. RBAC's strength is its administrative tractability—adding a new employee means assigning roles, not rewriting policies. Its limitation is combinatorial explosion when fine-grained distinctions are needed: an organisation with 500 resources and 50 contextual distinctions per resource cannot practically define 25,000 roles. Kubernetes namespace-level RBAC, AWS IAM roles, and Active Directory groups are the most widely deployed RBAC implementations globally.
- **Attribute-Based Access Control (ABAC)** evaluates a tuple of subject attributes (department=finance, clearance=secret), resource attributes (classification=confidential, owner=team-X), action attributes (method=DELETE), and environment attributes (time=09:00-17:00 GMT, ip_range=10.0.0.0/8) against a policy rule such as: permit if subject.department = resource.owner_dept AND action ≠ DELETE AND env.time IN business_hours. ABAC enables arbitrarily fine-grained policies without role explosion, at the cost of policy authoring complexity and PIP latency (attribute resolution at decision time). OPA with Rego, XACML, and Cedar all implement ABAC natively.
- **Relationship-Based Access Control (ReBAC)** traverses a directed graph of typed relationships between entities to derive permissions. Google published the Zanzibar paper in 2019, describing the global authorisation system protecting Gmail, Drive, YouTube, and Maps at planet scale (trillions of relationships, millions of check operations per second, sub-10 ms p99 latency via consistency tokens called zookies). A ReBAC check asks: "does user U have relation R to resource X?" The engine traverses the graph—U is a member of group G, G is an editor of folder F, folder F contains document D, therefore U has editor access to D. OpenFGA (Auth0/Okta origin, donated to CNCF September 2022, accepted as CNCF Incubating project November 2025), SpiceDB (Authzed), and Permify implement the Zanzibar model for application-level fine-grained authorization. ReBAC excels at collaborative document systems, multi-tenant SaaS, and any domain with deep ownership hierarchies.

### Policy Engines in Depth

- **Open Policy Agent (OPA)** is the dominant general-purpose policy engine in cloud-native infrastructure. Accepted to CNCF March 2018, graduated January 2021, OPA runs as a sidecar or daemon exposing a JSON HTTP API and evaluating policies written in **Rego**, a purpose-built declarative language derived from Datalog. A Rego policy is a set of rules mapping input documents (the authorization request as a JSON object) to decision documents (allow := true/false, plus structured responses). OPA's design deliberately separates policy from policy enforcement: the application calls OPA's `/v1/data` endpoint with request context; OPA evaluates relevant rules against that context plus any loaded data bundles (e.g., group-membership data, attribute stores); the application enforces the returned decision. This architecture means the same OPA binary serves Kubernetes admission webhooks, API gateways, microservice middleware, Terraform plan checks, and CI pipeline gates. The OPAL (Open Policy Administration Layer) project (Permit.io) provides a real-time data-sync layer feeding OPA instances with live attribute data, enabling sub-100 ms policy updates across distributed clusters. OPA is deployed in production by Netflix (API authorization), Goldman Sachs (infrastructure policy), T-Mobile (Kubernetes cluster governance), and thousands of other organisations. In October 2024, the Istio project published reference architecture for integrating OPA as an external authorization engine behind Istio's Envoy-based CUSTOM AuthorizationPolicy action, enabling L7 application-level authorization from within service mesh control.
- **Gatekeeper** is OPA's Kubernetes-native wrapper, implementing the Kubernetes ValidatingAdmissionWebhook and MutatingAdmissionWebhook interfaces. Rather than raw Rego files, Gatekeeper exposes Constraint Templates (CRD definitions encoding parameterised Rego logic) and Constraint instances (policy instantiations with specific parameter values). A Constraint Template might express "containers must not run as root"; a Constraint instantiates it for the production namespace with exceptions for system containers. Gatekeeper also supports audit mode, continuously scanning existing cluster resources for policy violations and surfacing them via Kubernetes events and metrics, enabling retrospective compliance reporting.
- **Kyverno** is an alternative Kubernetes-native policy engine that eliminates the need to learn a separate policy language: policies are authored as YAML Kubernetes resources using JSONPath, JMESPath, and a growing CEL (Common Expression Language) expression dialect. Kyverno supports four policy types—validate, mutate, generate, and clean up—applied via admission webhooks and background scan reconcilers. Kyverno 1.16 (November 2025) reached beta for CEL-native ValidatingPolicy and MutatingPolicy types aligned with the Kubernetes upstream ValidatingAdmissionPolicy API, with full metrics and event generation for observability. The Kyverno Authz Server (1.16) extends enforcement beyond admission to Envoy external authorisation, enabling Kyverno policies to authorize HTTP service requests via the same YAML authoring model. CNCF graduated Kyverno in April 2023. Comparative analysis (Nirmata, April 2025) positions Kyverno as preferable for Kubernetes-native teams favouring YAML fluency, whilst OPA/Gatekeeper suits polyglot environments requiring a single engine across non-Kubernetes workloads.
- **Cedar** is an open-source policy language and authorisation engine created by the AWS Automated Reasoning Group and open-sourced in May 2023 under Apache License 2.0. Cedar's design goals are expressiveness, performance, safety, and analysability: policies are machine-readable but close to natural language (permit (principal in Group::"editors", action == Action::"edit", resource in Album::"vacation")); the engine is written in Rust and formally modelled using automated reasoning tools that prove safety and correctness properties; and the SDK provides a policy validator that checks policies against a schema to prevent type errors before deployment. AWS uses Cedar as the policy language for Amazon Verified Permissions (AVP), a managed authorisation service storing Cedar policies centrally with millisecond-latency evaluation. Cedar natively supports RBAC, ABAC, and hybrid models, and its formal verification approach allows checking whether two policies are equivalent or whether a policy can ever permit a given action—capabilities impossible in Rego.
- **Falco** is a CNCF-graduated (February 2024) runtime security engine that enforces behavioural policies over kernel system-call streams and Kubernetes audit logs. Where OPA/Kyverno/Gatekeeper enforce at admission time (before resources are created), Falco enforces at runtime (after processes start executing). Falco uses eBPF probes or a kernel module to intercept every system call, matches the stream against a Falco rules file (YAML, with a Sysdig-inspired filter expression language), and fires alerts on policy violations—e.g., a container spawning a shell, writing to /etc, or opening a sensitive file. Falco Talon (submitted to the falcosecurity GitHub organisation September 2024) provides a no-code response engine: Talon rules define sequential response actions (terminate pod, isolate network, capture forensic dump) triggered by Falco alert events, closing the detect-respond loop without custom scripting. Falco 2025 integrates with Stratoshark (CNCF announcement November 2025) to pair real-time syscall alerts with forensic captures, enabling post-incident root cause analysis at packet-capture fidelity.

### Kubernetes Admission Controllers

- Kubernetes admission control is the primary policy enforcement plane for container workloads. The API server passes every mutating and validating request through a configurable chain of admission controllers before persisting it to etcd. Static built-in controllers handle NamespaceLifecycle, LimitRanger, ResourceQuota, PodSecurity, and PodSecurityAdmission (PSA, GA in 1.25, which replaced the deprecated PodSecurityPolicy). Dynamic admission control is implemented via the MutatingAdmissionWebhook and ValidatingAdmissionWebhook interfaces, which proxy requests to external servers (OPA/Gatekeeper, Kyverno, custom webhooks). Kubernetes 1.28+ introduces ValidatingAdmissionPolicy (VAP), a native in-tree policy mechanism using CEL that eliminates the webhook round-trip for simple validation rules, reducing latency from ~5-15 ms (webhook) to ~0.5 ms (in-process CEL) and removing the operational burden of managing external admission webhook availability. Policy as Code practice for Kubernetes typically involves writing policies in OPA/Rego or Kyverno YAML, testing against synthetic request fixtures in CI with `conftest` (OPA) or `kyverno test`, and deploying policies via GitOps (ArgoCD, Flux) with rollout controlled by admission webhook `failurePolicy: Ignore|Fail` settings.

### Service Mesh Policy: Istio AuthorizationPolicy

- Istio's security model enforces mutual TLS (mTLS) authentication between workloads via PeerAuthentication resources and HTTP/gRPC-level authorization via AuthorizationPolicy resources, implemented natively inside the Envoy sidecar proxies without application code changes. An AuthorizationPolicy selects workloads by label, specifies a source principal or namespace, and defines rules mapping HTTP methods/paths/headers/JWT claims to ALLOW, DENY, or CUSTOM decisions. The CUSTOM action delegates evaluation to an external authorization engine (e.g., OPA server) via the Envoy ext_authz filter, enabling application-level ABAC/ReBAC decisions inside the mesh control plane. Beginning with Istio 1.25, AuthorizationPolicy resources may be bound to a GatewayClass, allowing cluster-wide default policies applied to all gateway instances of that class—a significant operational simplification for multi-tenant gateway fleets. In Istio ambient mode (sidecar-free L4/L7 processing via ztunnel and waypoint proxies), AuthorizationPolicy enforcement migrates from per-pod sidecars to per-namespace waypoints, reducing per-pod memory overhead by ~50% whilst preserving enforcement semantics.

### Relationship-Based Access Control: OpenFGA and the Zanzibar Model

- Google's Zanzibar paper (2019) described a globally consistent access-control system managing trillions of relationship tuples across all Google products. The core data model is a set of triples `(user, relation, object)` (e.g., `(alice, owner, folder:reports)`) augmented by **userset rewrite rules** that compose relations transitively: if `(alice, owner, folder:reports)` and `(bob, member, group:finance)` and `(group:finance, viewer, folder:reports)` then `(bob, viewer, folder:reports)` holds via group membership. Zanzibar guarantees linearizability via **zookies** (consistency tokens encoding a tuple-store snapshot), enabling freshness-bounded checks without global coordination. OpenFGA implements this model with a typed relation tuple store, a Fine-Grained Authorization (FGA) modelling language for schema definition, a `/check` endpoint returning allow/deny with sub-5 ms p95 latency on commodity hardware, a `/list-objects` endpoint returning all resources a user has a given relation with (used for UI filtering), and a `/list-users` endpoint returning all users with a given relation on a resource (used for notifications, sharing dialogs). OpenFGA 1.x introduces Conditions—ABAC attribute checks that augment relationship traversal with dynamic attribute predicates—converging ReBAC and ABAC into a unified evaluation model. The CNCF TAG Security self-assessment (2025) cites OpenFGA's adoption in Okta, Grafana, and enterprise SaaS multi-tenancy as evidence of production readiness. SpiceDB (Authzed) and Permify offer commercial-supported alternatives implementing the same Zanzibar semantics.

### EU AI Act Enforcement Obligations

- The EU AI Act (Regulation 2024/1689) introduces layered policy enforcement obligations that must be implemented as technical and organisational controls, not merely legal declarations. **Article 6 and Annex III** define high-risk AI systems (employment screening, credit scoring, education, law enforcement, border control, critical infrastructure) subject to requirements including: mandatory conformity assessments before market placement; registration in the EU AI database; technical documentation and EU declaration of conformity; post-market monitoring; serious incident reporting; human oversight measures. These obligations become enforceable on **2 August 2026** for most high-risk systems. **Article 9** mandates risk management systems—documented lifecycle processes for identifying, evaluating, and mitigating foreseeable risks. **Article 10** requires training data governance with bias testing, data quality measures, and documentation of design choices. **Article 12** mandates automatic event logging sufficient to reconstruct reasoning sequences of AI decisions that may affect persons. From a policy enforcement architecture perspective, these obligations translate directly to: OPA/Cedar rules encoding prohibited use conditions; Falco/eBPF runtime monitors detecting unexpected model behaviour; Kyverno admission policies preventing deployment of unregistered AI models in regulated namespaces; Audit Trail systems capturing every AI decision with input, output, model version, and timestamp; and access control policies restricting AI model access to authorised personnel. The AI omnibus agreement (7 May 2026) streamlines some compliance processes but does not reduce the technical enforcement baseline.
- **Prohibited practices** (Article 5, enforceable February 2025) include: social scoring by public authorities; real-time biometric identification in public spaces (with narrow exceptions); cognitive behavioural manipulation; exploitation of vulnerable groups. Technical policy enforcement for these prohibitions requires use-case classification at model registration time, enforced by admission controllers that reject models without approved use-case labels.

### Rule-as-Code Practice

- Rule-as-Code (RaC) is the practice of expressing regulatory rules, compliance controls, and business policies as executable, version-controlled code rather than prose documents. New Zealand's Inland Revenue was an early pioneer (2019), translating tax legislation into Python/Clojure. The approach scales to enterprise compliance: GDPR Article 25 by-design requirements encoded as OPA policies run in CI against infrastructure-as-code pull requests; PCI-DSS controls encoded as Kyverno policies preventing non-compliant container images from reaching production; HIPAA minimum-necessary rules encoded as Cedar policies enforcing field-level access controls on EHR APIs. Rule-as-Code tooling includes: Open Policy Agent with the `conftest` testing harness (Styra); Kyverno CLI with `kyverno test`; Regula (Fugue/Lacework) for Terraform/CloudFormation; Checkov (Prisma Cloud) for IaC scanning; Cloud Custodian (Capital One origin, CNCF project) for real-time cloud resource policy enforcement.

### UK Context

- The **NCSC Cyber Assessment Framework (CAF) v4.0** (August 2025) is the primary technical policy enforcement standard for UK critical national infrastructure operators under the Network and Information Systems (NIS) Regulations. CAF Principle B1 (Service Protection Policies) requires documented policies, an evidence-based assurance process, and technical controls that directly enforce policy objectives—precisely the PEP/PDP/PAP decomposition described above. CAF v4.0 adds new sections covering AI-related cyber risks and secure software development, requiring CNI operators to assess AI systems as potential attack surfaces and enforce integrity policies over model deployments. The **Cyber Security and Resilience Bill** (expected 2026) extends NIS Regulation scope to managed service providers and digital supply chains, increasing the population of organisations required to implement formal policy enforcement architectures.
- The **ICO's guidance on Article 25 UK GDPR** (Data Protection by Design and by Default) requires that policy enforcement mechanisms implement data minimisation and purpose limitation as technical controls, not merely procedural commitments. The Data (Use and Access) Act 2025 (Royal Assent 19 June 2025) amends Article 25 to require children's higher protection matters in information society services—technically implementable as ABAC policies checking user age attributes before granting access to higher-risk data-processing paths. The ICO published draft enforcement procedural guidance (October 2025) providing the first detailed account of how the Commissioner will apply investigative powers under the DUAA, signalling increased enforcement intensity.
- **CyberUK 2025** was held in Manchester, with the UK Government's Cyber Growth Action Plan 2025 and the National Cyber Security Centre's expanded CAF guidance representing the primary policy framework outputs of the year. Manchester and Edinburgh are emerging as significant UK cybersecurity cluster cities: Manchester hosts the CyberUK conference hub and Greater Manchester Combined Authority digital-security initiatives; Edinburgh's proximity to the National Cyber Security Academy Scotland and Heriot-Watt/Edinburgh Napier cybersecurity research programmes supports a growing RegTech/GovTech policy-enforcement startup ecosystem. UK companies active in the policy enforcement tooling space include Nettitude (PwC), Bridewell (managed security), Resilience (cyber risk quantification), and the UK R&D arms of international vendors including Elastic (threat detection), HashiCorp/IBM (identity and policy management), and Snyk (supply chain policy).

### Components / Architecture

- The reference policy enforcement stack comprises five horizontal layers: (1) **Authoring & Administration** — PAP tools (OPA Playground, Styra DAS, Kyverno Policy Reporter, Permit.io Studio, Cedar Playground) where policy authors draft, test, and version-control rules in a Git-backed repository; (2) **Distribution** — bundle servers (OPA bundle API, OPAL data sync, Kyverno ConfigMap injection) that push policy and data updates to enforcement nodes within seconds of commit; (3) **Evaluation** — PDP clusters (OPA sidecar, Kyverno admission webhook, Cedar AVP, OpenFGA server) that handle evaluation requests with sub-5 ms latency at 10K-100K RPS; (4) **Enforcement** — PEP integrations at every control plane boundary: Envoy ext_authz filter for service mesh, Kubernetes AdmissionWebhook for cluster admission, API gateway plugins (Kong, AWS API Gateway Lambda authoriser, NGINX njs module), AWS IAM policy evaluation for cloud-resource access, database proxy filters for data-layer enforcement; (5) **Observability** — structured decision logs (OPA decision log, Kyverno PolicyReport CRD, Falco JSON event stream) aggregated into SIEM platforms (Splunk, Elastic, Microsoft Sentinel) for compliance dashboards and anomaly detection.

### Use Cases / Major Families

- **Kubernetes Cluster Governance**: Kyverno and OPA/Gatekeeper enforce Pod Security Standards (privileged, baseline, restricted), image registry allow-lists, resource quota limits, label/annotation mandates, and network policy co-requirements. Typical enterprise clusters run 50-200 active constraints with full audit trails fed to compliance dashboards.
- **API Gateway Authorization**: OPA or Cedar policies enforce JWT claim-based RBAC, rate-limiting policy decisions, geographic access restrictions, and tenant isolation at API gateway ingress. A single OPA decision call takes 0.5-2 ms, acceptable for synchronous gateway enforcement at 50K RPS.
- **Cloud Infrastructure Compliance**: Cloud Custodian (CNCF) and Regula enforce policies over AWS/Azure/GCP resources—e.g., S3 buckets must not be public, all EC2 instances must have encryption-at-rest, IAM roles must not have `*:*` permissions. Policies run in real-time event-driven mode (CloudTrail → Lambda → custodian) and in scheduled scan mode for drift detection.
- **Service Mesh L7 Authorization**: Istio AuthorizationPolicy with OPA ext_authz delegates application-level decisions (user X may access document Y only if user is in workspace of document) to a PDP, without any application code modification, separating auth logic from business logic.
- **AI Governance Enforcement**: Policy engines encode EU AI Act compliance controls—prohibited-use checks, model registration validation, logging obligations, human-oversight thresholds—as executable Rego/Cedar/Kyverno policies enforced at model serving infrastructure, CI/CD pipeline, and data platform layers.
- **Supply Chain Security**: Kyverno verifies container image signatures (Sigstore/Cosign) and SBOM attestations as an admission policy prerequisite, preventing unsigned or unattested images from reaching production. This implements SLSA (Supply-chain Levels for Software Artifacts) Level 2-3 requirements as code.

### Academic Context

- The theoretical foundations of policy enforcement span access control theory, formal methods, and distributed systems. Lampson's 1974 Protection paper established the access matrix model from which RBAC derives. Ferraiolo and Kuhn's 1992 NIST paper formalised RBAC with four reference models (flat, hierarchical, constrained, symmetric). Sandhu et al.'s 1996 RBAC96 model remains the dominant academic reference. ABAC was formalised by Hu et al. in NIST SP 800-162 (2014), defining subject/resource/action/environment attribute categories. The Google Zanzibar paper (Warema et al. 2019) introduced the ReBAC model at planetary scale. The Cedar formal methods paper (Amazon Science, 2023) applies SMT solver-based automated reasoning to policy analysis, representing the first industrially deployed policy language with machine-verified correctness properties. Datalog, the logic-programming ancestor of Rego, was formalised by Ullman (1988) and remains relevant to policy language semantics and termination guarantees.

### Current Landscape (2026)

- As of mid-2026, the policy enforcement market has consolidated around three primary open-source evaluation engines—OPA (Rego), Cedar, and OpenFGA—with Kyverno as the dominant Kubernetes-native admission layer and Falco as the standard runtime behavioural enforcement engine. Styra (OPA's commercial sponsor) offers Styra DAS as a centralized policy-as-code platform. Permit.io and OPAL provide developer-friendly PDP-as-a-service wrappers over OPA. Authzed's SpiceDB and Permify commercialise the Zanzibar/ReBAC model for enterprise SaaS. AWS Verified Permissions has matured as a managed Cedar-powered PDP accessible via API, removing operational burden for application-level fine-grained authorization.
- The EU AI Act's August 2026 enforcement date is driving rapid integration of policy engines into AI model serving infrastructure: MLflow, Kubeflow, and Seldon Core have all added OPA/Kyverno integration points for AI governance policy enforcement in 2025-2026 roadmaps. The AI omnibus agreement (May 2026) simplifies some procedural compliance requirements but does not reduce the technical enforcement obligations for high-risk systems.
- NIST SP 800-207 (Zero Trust Architecture, 2020) and its follow-on SP 800-207A (2023) have further accelerated adoption of explicit PDP/PEP decomposition as a Zero Trust implementation pattern, with the PDP mapping to a Policy Engine and the PEP mapping to Policy Enforcement infrastructure at every network segment boundary.

### Future Directions (2026-2030)

- **Confidential Policy Evaluation**: Zero-knowledge proofs and trusted execution environments (Intel TDX, AMD SEV-SNP) will enable PDP evaluation inside hardware enclaves, allowing cloud tenants to enforce policies over data they cannot decrypt—critical for cross-organisational data sharing with sensitive attribute stores.
- **AI-Assisted Policy Authoring**: Large language models will increasingly assist in translating regulatory prose (GDPR recitals, EU AI Act Annex III requirements) directly into executable Rego/Cedar/Kyverno policies, with formal verification gates preventing semantic drift between the legal and technical representations.
- **Continuous Compliance Attestation**: Policy enforcement logs will be cryptographically signed and anchored to transparency logs (similar to Certificate Transparency), enabling regulator-facing continuous compliance attestation rather than periodic audit snapshots.
- **Unified Policy Plane**: Emerging efforts (CNCF Policy Working Group, 2025) aim to define a standard policy API surface abstracting across OPA, Cedar, Kyverno, and OpenFGA, allowing organisations to switch evaluation engines without rewriting PEP integrations—analogous to how the CSI/CNI/CRI interfaces abstracted Kubernetes storage/networking/container runtime.
- **eBPF-Native Enforcement**: Cilium's Tetragon and other eBPF-based security tools are moving policy enforcement into the kernel data plane, achieving microsecond enforcement latency and eliminating the userspace round-trip overhead of ext_authz patterns.
- **Post-Quantum Cryptography for Policy Tokens**: As NIST PQC standards (ML-KEM, ML-DSA, SLH-DSA) enter production (2026-2028), policy token signing and identity assertion schemes will migrate to post-quantum algorithms, ensuring enforcement infrastructure remains secure against future adversarial capabilities.

### Research & Literature

- Butler Lampson. "Protection." ACM SIGOPS Operating Systems Review, 8(1):18-24, 1974.
- D. Ferraiolo and R. Kuhn. "Role-Based Access Controls." 15th NIST-NCSC National Computer Security Conference, 1992.
- Ravi Sandhu, Edward Coyne, Hal Feinstein, Charles Youman. "Role-Based Access Control Models." IEEE Computer, 29(2):38-47, 1996.
- Vincent Hu, D. Ferraiolo, R. Kuhn, et al. NIST SP 800-162: Guide to Attribute Based Access Control (ABAC) Definition and Considerations. NIST, 2014.
- Evan Gilman and Doug Barth. Zero Trust Networks. O'Reilly Media, 2017.
- Lior Yarom et al. "XACML 3.0 Core and Hierarchical Role-Based Access Control." OASIS Standard, 2013.
- Ruoming Pang, Vinod Yegneswaran, Paul Barford, Vern Paxson, Larry Peterson. "Characteristics of Internet Background Radiation." ACM IMC 2004. (foundational to Falco threat model).
- Samuel Warema, et al. "Zanzibar: Google's Consistent, Global Authorization System." USENIX ATC 2019.
- Ananya Bhatt, Ryan Wisnesky, et al. "Cedar: A New Language for Expressive, Fast, Safe, and Analyzable Authorization." Amazon Science, 2023.
- Open Policy Agent Project. "OPA Documentation and Rego Language Reference." CNCF, 2021-2026. https://www.openpolicyagent.org/docs/
- OASIS XACML Technical Committee. "eXtensible Access Control Markup Language (XACML) Version 3.0." OASIS Standard, January 2013.
- NIST SP 800-207. "Zero Trust Architecture." NIST, August 2020.
- NIST SP 800-207A. "A Zero Trust Architecture Model for Access Control in Cloud-Native Systems in Multi-Cloud Environments." NIST, 2023.
- AWS. "Introducing Cedar, an open-source language for access control." AWS What's New, May 2023.
- Kyverno Project. "Announcing Kyverno Release 1.16." CNCF Blog, November 2025.
- CNCF. "Falco Links Real-Time Detection with Forensic-Level Analysis in the Cloud Native Stack." CNCF Announcement, November 2025.
- OpenFGA Project. "OpenFGA Becomes a CNCF Incubating Project." CNCF Blog, November 2025.
- Istio Project. "Can Your Platform Do Policy? Accelerate Teams With Platform L7 Policy Functionality." Istio Blog, October 2024.
- NCSC. "Cyber Assessment Framework v4.0." National Cyber Security Centre, August 2025.
- ICO. "Data Protection by Design and by Default." Information Commissioner's Office, 2025. https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/accountability-and-governance/
- European Parliament and Council. "Regulation (EU) 2024/1689 on Artificial Intelligence (AI Act)." Official Journal of the EU, July 2024.
- European Council. "Artificial Intelligence: Council and Parliament agree to simplify and streamline rules (AI Omnibus)." Press Release, May 2026.
- HM Government. "Cyber Security and Resilience Bill — Proposed Scope." UK Cabinet Office, 2025.
- Styra. "Open Policy Agent Graduating in the CNCF Proves Need for Cloud Native AuthZ." Styra Blog, 2021.
- Permit.io. "OPAL + OPA vs XACML." Permit.io Blog, 2024.

### Metadata

- **Domain correction**: None. `infrastructure` is the correct ontological domain for Policy Enforcement — it is a foundational infrastructure concern orthogonal to any single application domain.
- **Legacy term ID assigned**: IF-0842 (Infrastructure domain, policy-enforcement cluster).
- **Enrichment date**: 2026-05-17
- **Worker model**: claude-sonnet-4-6
- **Authority basis**: CNCF project records (OPA graduation 2021, Falco graduation Feb 2024, OpenFGA incubation Nov 2025), AWS Cedar launch documentation May 2023, EU AI Act Regulation 2024/1689, NCSC CAF v4.0 August 2025, ICO DUAA guidance 2025, Kyverno 1.16 release notes Nov 2025, Istio 1.25 AuthorizationPolicy documentation, Google Zanzibar USENIX ATC 2019, Amazon Science Cedar paper 2023.

### Provenance

- CNCF. "Cloud Native Computing Foundation Announces Open Policy Agent Graduation." CNCF Announcement, 4 February 2021. https://www.cncf.io/announcements/2021/02/04/cloud-native-computing-foundation-announces-open-policy-agent-graduation/
- AWS. "Introducing Cedar, an open-source language for access control." AWS What's New, May 2023. https://aws.amazon.com/about-aws/whats-new/2023/05/cedar-open-source-language-access-control/
- CNCF. "OpenFGA Becomes a CNCF Incubating Project." November 2025. https://www.cncf.io/blog/2025/11/11/openfga-becomes-a-cncf-incubating-project/
- Kyverno. "Announcing Kyverno Release 1.16." November 2025. https://kyverno.io/blog/2025/11/10/announcing-kyverno-release-1.16/
- CNCF. "Falco Links Real-Time Detection with Forensic-Level Analysis in the Cloud Native Stack." November 2025. https://www.cncf.io/announcements/2025/11/10/falco-links-real-time-detection-with-forensic-level-analysis-in-the-cloud-native-stack/
- Istio. "Can Your Platform Do Policy?" October 2024. https://istio.io/latest/blog/2024/l7-policy-with-opa/
- European Parliament. "Regulation (EU) 2024/1689 — AI Act." July 2024. https://artificialintelligenceact.eu/
- NCSC. "Cyber Assessment Framework v4.0." August 2025. https://www.ncsc.gov.uk/collection/caf/
- ICO. "Data Protection by Design and by Default." 2025. https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/accountability-and-governance/data-protection-by-design-and-by-default/
- NIST. "SP 800-207: Zero Trust Architecture." August 2020.
- Samuel Warema et al. "Zanzibar: Google's Consistent, Global Authorization System." USENIX ATC 2019.
- Ananya Bhatt et al. "Cedar: A New Language for Expressive, Fast, Safe, and Analyzable Authorization." Amazon Science 2023. https://assets.amazon.science/96/a8/1b427993481cbdf0ef2c8ca6db85/cedar-a-new-language-for-expressive-fast-safe-and-analyzable-authorization.pdf
- Open Policy Agent. GitHub Repository. https://github.com/open-policy-agent/opa
- OpenFGA. Fine-Grained Authorization documentation. https://openfga.dev/
- OASIS. "XACML 3.0 Standard." January 2013.
- DLA Piper. "Latest wave of obligations under the EU AI Act take effect." August 2025. https://www.dlapiper.com/en-us/insights/publications/2025/08/latest-wave-of-obligations-under-the-eu-ai-act-take-effect
- Ravi Sandhu et al. "Role-Based Access Control Models." IEEE Computer 29(2), 1996.
- Vincent Hu et al. "NIST SP 800-162: ABAC Definition and Considerations." NIST, 2014.
- European Council. "AI Omnibus Agreement." May 2026. https://www.consilium.europa.eu/en/press/press-releases/2026/05/07/artificial-intelligence-council-and-parliament-agree-to-simplify-and-streamline-rules/
- Styra. "OPA CNCF Graduation Blog." 2021. https://www.styra.com/blog/open-policy-agent-graduating-in-the-cncf-proves-need-for-cloud-native-authz/
- Solo.io. "Istio Authorization Policy in Ambient Mesh." 2025. https://www.solo.io/blog/a-guide-to-authorization-policy-in-ambient-mesh
- Nirmata. "10 Reasons Why Kubernetes Users Choose Kyverno Over OPA Gatekeeper." April 2025. https://nirmata.com/2025/04/14/10-reasons-why-kubernetes-users-choose-kyverno-over-opa-gatekeeper/
- Help Net Security. "OpenFGA: The open-source engine redefining access control." October 2025. https://www.helpnetsecurity.com/2025/10/22/openfga-open-source-access-control/
- Osohq. "OPA vs Cedar vs Zanzibar: 2025 Policy Engine Guide." 2025. https://www.osohq.com/learn/opa-vs-cedar-vs-zanzibar
- Legalnodes. "EU AI Act 2026 Updates: Compliance Requirements and Business Risks." 2026. https://www.legalnodes.com/article/eu-ai-act-2026-updates-compliance-requirements-and-business-risks
- CNCF. "Kyverno vs Kubernetes policies." October 2025. https://www.cncf.io/blog/2025/10/16/kyverno-vs-kubernetes-policies-how-kyverno-complements-and-completes-kubernetes-policy-types/

