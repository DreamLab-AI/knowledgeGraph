Reshoring is the return of production or other value-added activities that were moved abroad to the home location.[^1][^2]

Pylypenko and Herasymenko define it as the process through which a transnational company relocates all or part of the value-added activities conducted abroad back to its home country.[^1] A European Parliament study says reshoring refers to bringing productive activities home to a specific location, and uses backshoring for manufacturing activities that return to their initial country of origin.[^2] The OECD describes re-shoring as repatriating supply chain nodes.[^3]

## Scope and distinctions

Eurofound's European Restructuring Monitor uses a narrower, regional definition: reshoring is the relocation of previously offshored activities to an EU destination, covering both companies returning activities to their home country within the EU and companies moving activities offshored to a non-EU country to any EU country.[^4] The sources therefore disagree on whether the destination must be the home country or only the home region. See [[Offshoring]], [[Nearshoring]] and [[Supply Chain Configuration Decision]].

The OECD notes that reshoring the supply chain is often understood as relocating the factory only, which leaves out the need to develop a local supplier base.[^3] The European Parliament study concludes that reshoring is unlikely for most previously offshored products, citing required economies of scale, complex established regional supplier networks, and higher wages and sustainability standards in the EU.[^2]

## What the sources do not establish

That study treats reshoring as a measure rather than a goal in its own right, to be assessed against the EU objectives of security of supply of critical products and open strategic autonomy.[^2] The OECD adds that empirical evidence suggests efforts to redesign supply chains to reduce geographic risk generally fall short of expectations.[^3] The European Parliament conclusions concern the EU and rest on one study, so this page makes no claim about other regions.[^2]

[^1]: N. M. Pylypenko and T. V. Herasymenko, Economics Bulletin (Dnipro University of Technology), 2022, “Reasons and dynamics of reshoring in the European Union and USA”. https://ev.nmu.org.ua/docs/2022/4/EV20224_034-041.pdf
[^2]: European Parliament, Policy Department for External Policies (study requested by the INTA committee), “Post Covid-19 value chains: options for reshoring production back to Europe in a globalised economy”. https://www.europarl.europa.eu/RegData/etudes/STUD/2021/653626/EXPO_STU(2021)653626_EN.pdf
[^3]: OECD, report on supply chain resilience, “Promoting resilience and preparedness in supply chains”. https://www.oecd.org/content/dam/oecd/en/publications/reports/2024/11/promoting-resilience-and-preparedness-in-supply-chains_c0320739/be692d01-en.pdf
[^4]: Eurofound, European Restructuring Monitor, “Reshoring”. https://apps.eurofound.europa.eu/restructuring-events/types/Reshoring

