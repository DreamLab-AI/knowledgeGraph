A traceability regulation is a law that requires businesses to identify products and keep records so that products and their inputs can be traced through the supply chain.[^1][^2][^3]

Regulation (EC) No 178/2002 defines traceability as the ability to trace and follow a food, feed, food-producing animal or substance intended to be incorporated into a food or feed through all stages of production, processing and distribution.[^1] Article 18 requires traceability to be established at all stages and says operators must be able to identify who supplied them and must have systems to identify the businesses they supplied.[^2] The copies opened here are the retained UK versions held on legislation.gov.uk, not the current EU text.[^1][^2]

## Rules by sector

Food lot marking is covered by Directive 2011/91/EU, which says that indicating the lot is a useful source of information when foodstuffs are the subject of dispute or constitute a health hazard for consumers.[^4] See [[Batch Number]].

For medicines, Delegated Regulation (EU) 2016/161 requires a unique identifier unique to a given pack, and FDA describes the United States Drug Supply Chain Security Act as outlining steps to an interoperable, electronic way to identify and trace certain prescription drugs at the package level.[^5][^6] See [[Product Serialisation]] and [[DSCSA Compliance]].

For food in the United States, the FDA Food Traceability Rule requires that once a food has been assigned a traceability lot code, the records at each critical tracking event include it.[^3] FDA's page says the original compliance date was 20 January 2026, that FDA proposed to extend it by 30 months to 20 July 2028, and that Congress directed FDA not to enforce the rule before that date.[^3]

## Standards that support the rules

ISO 22005:2007 gives principles and basic requirements for designing a feed and food traceability system.[^7] Data standards such as [[GS1 EPCIS]] are grouped under [[Traceability Data Standard]].

## What the sources do not establish

No source opened here defines traceability regulation as a general term, and the page does not rank the rules or claim that one satisfies another. The compliance date is moving: the FDA page also still carries an older line naming 20 January 2026, so the date should be checked at the source.[^3]

[^1]: European Parliament and Council, Regulation (EC) No 178/2002, Article 3 “Other definitions”, legislation.gov.uk retained version. https://www.legislation.gov.uk/eur/2002/178/article/3
[^2]: European Parliament and Council, “Regulation (EC) No 178/2002 of the European Parliament and of the Council of 28 January 2002 laying down the general principles and requirements of food law, establishing the European Food Safety Authority and laying down procedures in matters of food safety”, Article 18, legislation.gov.uk retained version. https://www.legislation.gov.uk/eur/2002/178/article/18/data.htm?view=plain
[^3]: US Food and Drug Administration, “FSMA Final Rule on Requirements for Additional Traceability Records for Certain Foods”. https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-requirements-additional-traceability-records-certain-foods
[^4]: European Parliament and Council, “Directive 2011/91/EU of the European Parliament and of the Council of 13 December 2011 on indications or marks identifying the lot to which a foodstuff belongs (codification)”, legislation.gov.uk copy. https://www.legislation.gov.uk/eudr/2011/91/data.htm?view=plain
[^5]: European Commission, “Commission Delegated Regulation (EU) 2016/161 of 2 October 2015 supplementing Directive 2001/83/EC of the European Parliament and of the Council by laying down detailed rules for the safety features appearing on the packaging of medicinal products for human use”, legislation.gov.uk copy. https://www.legislation.gov.uk/eur/2016/161/adopted/data.htm
[^6]: US Food and Drug Administration, “Drug Supply Chain Security Act (DSCSA)”. https://www.fda.gov/drugs/drug-supply-chain-integrity/drug-supply-chain-security-act-dscsa
[^7]: ISO, “ISO 22005:2007 - Traceability in the feed and food chain — General principles and basic requirements for system design and implementation” (catalogue record). https://www.iso.org/standard/36297.html

