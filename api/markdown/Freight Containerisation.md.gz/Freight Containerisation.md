Freight containerisation is the carriage of cargo in standardised containers that move between modes as a single unit, so that the goods themselves are not handled at each change of mode.[^1][^2]

The Glossary for transport statistics describes unitised transport as the carriage of cargo in intermodal transport units such as containers.[^1] The term means physical freight containers; the software technique of the same name is covered at [[Containerisation]].

## Origins

USC Sea Grant dates the idea to 1956, when Malcolm McLean, owner of a regional trucking company in Winston-Salem, North Carolina, had an idea for moving cargo more efficiently.[^3] Harvard Business School says McLean redesigned truck trailers into two parts, a truck bed on wheels and an independent box trailer or container, and that his converted oil tanker, the Ideal X, carried fifty-eight new box trailers or containers from Port Newark, New Jersey, to Houston in April 1956.[^2] USC Sea Grant instead describes the Ideal X as a tankship converted to permit deck loads of trailer vans.[^3] The two accounts describe the first ship's load differently.

## Standardisation and regulation

Harvard Business School says McLean made his patents available by a royalty-free lease to what it calls the Industrial Organization for Standardization (ISO).[^2] The International Maritime Organization records a rapid increase in the use of freight containers by sea in the 1960s, a 1967 study of the safety of containerisation, and the Convention for Safe Containers, adopted on 2 December 1972 and in force from 6 September 1977.[^4]

## Scope and distinctions

Freight Containerisation is part of [[Freight Transportation]]. Related pages are [[Shipping Container]], [[Intermodal Transport]] and [[Container Shipping]].

## What the sources do not establish

Sources here are a business-school excerpt and a university extension article, and they do not agree on the loading of the first voyage. They do not give cost-saving figures that this page relies on.

[^1]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^2]: Harvard Business School, Working Knowledge (Mayo and Nohria), “The Truck Driver Who Reinvented Shipping”, 2005. https://www.library.hbs.edu/working-knowledge/the-truck-driver-who-reinvented-shipping
[^3]: University of Southern California Sea Grant (Fawcett), “2. The Box: An Inside Look at the Shipping Container”, 2020. https://dornsife.usc.edu/uscseagrant/2020/05/29/2-the-box-an-inside-look-at-the-shipping-container/
[^4]: International Maritime Organization, “International Convention for Safe Containers (CSC)”. https://www.imo.org/en/about/Conventions/Pages/International-Convention-for-Safe-Containers-(CSC).aspx

