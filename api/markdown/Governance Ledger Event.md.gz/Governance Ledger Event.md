
A governance ledger event is a ledger event that represents governance or specification update events, declared in the Agent Ontology as `GovernanceLedgerEvent` and a subclass of [[Ledger Event]].[^1] It is the counterpart of the [[Runtime Ledger Event]]: where the runtime kind records what an agent did, the governance kind records changes to the rules and specifications around it.

Two properties have this class as their domain. `governanceAction` links the event to the governance action it records, such as a [[Governance Proposal]], and `specVersion` to the specification version the action applies to.

Everything else about the event, including its hash chain, signature, actor and timestamp, is inherited from [[Ledger Event]]. The class is the ledger-level analogue of the idea of [[On-chain Governance]], although the ontology does not state that relationship itself.

[^1]: Semantic Agent Communication Community Group, “Ledger Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/ledger.ttl

