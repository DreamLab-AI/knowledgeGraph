Pharmaceutical logistics is the distribution of pharmaceutical products, which the World Health Organization calls an important activity in the integrated supply-chain management of pharmaceutical products and governs through good distribution practice guidance.[^1]

The European Union's guidelines make the same point for wholesale distribution of medicinal products. They cite Directive 2001/83/EC, under which wholesale distribution is all activities consisting of procuring, holding, supplying or exporting medicinal products, apart from supplying medicinal products to the public.[^2] The WHO document says every activity in the distribution of pharmaceutical products should be carried out according to the principles of good manufacturing practice, good storage practice and good distribution practice as applicable.[^1]

## Purposes of the rules

Both documents aim to protect the integrity of the supply chain. The WHO text says that weak points in the distribution of pharmaceutical products provide an avenue for counterfeit as well as illegally imported, stolen and substandard medicines to enter the supply chain, and says regulations should “foster a safe, transparent and secure distribution system” which includes product traceability throughout the supply chain.[^1] The EU guidelines say they lay down appropriate tools to assist wholesale distributors in conducting their activities and to prevent falsified medicines from entering the legal supply chain.[^2]

## Temperature control

The WHO text says storage conditions should be maintained within acceptable limits during transportation, and mentions the cold chain for thermolabile products.[^1] The EU guidelines place responsibility on the supplying wholesale distributor to protect medicinal products and ensure that temperature conditions are maintained within acceptable limits during transport.[^2] The wider topic is covered at [[Cold Chain Logistics]].

## Scope and distinctions

Pharmaceutical Logistics is a form of [[Sector Logistics]]. A related page is [[Pharmaceutical Supply Chain]], and [[Logistics Optimisation]] covers general route and inventory methods.

## What the sources do not establish

The WHO and EU documents opened here do not establish unit-level serialisation, tamper-evident packaging or sensor networks as requirements, so this page does not claim them.

[^1]: World Health Organization, WHO Technical Report Series No. 957, 2010, Annex 5, “WHO good distribution practices for pharmaceutical products”. https://www.who.int/docs/default-source/medicines/norms-and-standards/guidelines/distribution/trs957-annex5-who-good-distribution-practices-for-pharmaceutical-products.pdf
[^2]: European Union, Official Journal C 343/1, 2013, “Guidelines of 5 November 2013 on Good Distribution Practice of medicinal products for human use”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:52013XC1123(01)

