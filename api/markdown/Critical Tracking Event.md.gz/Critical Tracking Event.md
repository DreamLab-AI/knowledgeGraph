A critical tracking event, abbreviated CTE, is an event that occurs to a traceable object during its lifecycle and at which traceability data has to be captured.[^1]

GS1's Global Traceability Standard describes critical tracking events as the actual events that occur to traceable objects during their lifecycle, such as receiving, transforming, packing, shipping and transporting.[^1] It pairs them with key data elements, the pieces of data that describe the actual instances of the events.[^1] GS1 separately describes its EPCIS standard as helping provide the what, when, where, why and how of products and other assets.[^2]

## FDA rule

The US Food and Drug Administration's Food Traceability Rule makes the pairing a legal requirement for foods on the Food Traceability List: persons who manufacture, process, pack or hold such foods must maintain records containing key data elements associated with specific critical tracking events, and provide information to the FDA within 24 hours or within some reasonable time to which the FDA has agreed.[^3] The rule lists the events as harvesting; cooling before initial packing; initial packing of a raw agricultural commodity other than a food from a fishing vessel; first land-based receiving of a food from a fishing vessel; shipping; receiving; and transformation of the food.[^3] The key data elements required vary depending on the event being performed.[^3]

The FDA page records that it proposed to extend the compliance date for the rule by 30 months to July 2028.[^3] The status of that date may have changed since the page was opened.

## Scope and limits

Critical tracking events are the unit of record in [[Supply Chain Traceability]], and the event data standard is described at [[GS1 EPCIS]]. The list of events is specific to the FDA rule and to foods; GS1's examples are illustrative and not a closed list. The two sources agree on the idea but come from different kinds of body, and neither says how many events a chain should record.

[^1]: GS1, Global Traceability Standard Release 2.0 (ratified August 2017), “GS1 Global Traceability Standard”. https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard
[^2]: GS1, “EPCIS & CBV”. https://www.gs1.org/standards/epcis
[^3]: U.S. Food and Drug Administration, “FSMA Final Rule on Requirements for Additional Traceability Records for Certain Foods”. https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-requirements-additional-traceability-records-certain-foods

