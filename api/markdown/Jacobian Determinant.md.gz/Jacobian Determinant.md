The Jacobian determinant is the scalar determinant of the Jacobian matrix of a differentiable vector-valued function, measuring the local factor by which the function expands or contracts volume around a point. In probability and machine learning it provides the change-of-variables correction needed to transform a probability density through an invertible mapping, ensuring the transformed density integrates to one. Its sign indicates whether the transformation preserves or reverses orientation, and its magnitude governs local volume scaling.

### Overview

- The Jacobian determinant generalises the one-dimensional derivative to multivariable transformations: where a scalar derivative tells how a single coordinate stretches, the determinant of the matrix of all first-order partial derivatives tells how an infinitesimal volume element is rescaled. This makes it central to the multivariate change-of-variables formula and to any learning model that needs to track how a transformation reshapes a density.
- It is modelled as a subclass of [[Jacobian Matrix]] within the machine-learning domain.
- Computing the determinant of a general dense Jacobian costs cubic time in the dimension, which would be prohibitive inside a deep generative model evaluated millions of times. This computational reality has shaped the design of invertible architectures: coupling layers, autoregressive transforms and other constructions force the Jacobian into triangular or otherwise structured form whose determinant is the cheap product of diagonal entries.
- Beyond machine learning, the Jacobian determinant is the bridge between coordinate systems in physics and engineering, converting integrals expressed in one set of variables into another and quantifying how meshes deform under a mapping in finite-element analysis.

### Mechanisms

- Volume scaling: the absolute value of the determinant equals the local volume-change factor of the mapping.
- Invertibility test: a non-zero Jacobian determinant certifies that the function is locally invertible (inverse function theorem).
- Density correction: the change-of-variables formula multiplies the base density by the absolute inverse determinant of the transformation Jacobian.
- Tractability: flow architectures are designed so the Jacobian is triangular or has structure that makes its determinant cheap to compute.

### Applications

- Computing exact likelihoods in normalising flow generative models.
- Transforming integrals and densities under coordinate changes in statistics and physics.
- Detecting singularities and orientation reversal in geometric and simulation pipelines.

### Considerations

- A vanishing Jacobian determinant signals a non-invertible point, where the transformation collapses volume and the change-of-variables formula breaks down.
- Numerical stability matters: log-determinants are accumulated in log space to avoid underflow when many small factors multiply.
- For continuous-time flows the determinant is replaced by the trace of the Jacobian, integrated over time via the instantaneous change-of-variables formula.

### Provenance

