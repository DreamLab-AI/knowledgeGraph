Compound is an algorithmic, autonomous interest-rate protocol built on Ethereum that enables users to supply crypto assets to liquidity pools and earn continuously accruing interest, or borrow assets against over-collateralised positions at algorithmically determined rates. Interest rates adjust dynamically based on the utilisation ratio of each asset pool, eliminating the need for bilateral loan negotiation or centralised intermediaries. Supplied assets are represented as cTokens — ERC-20 tokens whose exchange rate appreciates with every block as interest accrues — which can themselves be used as collateral or freely traded. Governance of protocol parameters is conducted on-chain through the COMP token and the Compound Governor Bravo smart-contract system, making it one of the earliest fully decentralised autonomous lending protocols in the DeFi ecosystem.

### Overview

- Compound was created by Robert Leshner and Geoffrey Hayes and its v2 protocol launched on Ethereum mainnet in May 2019. It introduced a peer-to-pool lending model: rather than matching individual lenders with borrowers, all depositors contribute to a shared reserve from which any qualifying borrower may draw, with rates determined algorithmically rather than bilaterally. This design removed the friction of order-book matching and enabled 24/7 global access to crypto credit markets without a central intermediary.
- The protocol matters because it demonstrated that [[Smart Contracts]] could replace the core functions of a bank's lending desk — accepting deposits, setting rates, enforcing collateral requirements, and processing liquidations — entirely on-chain. Its COMP token distribution in June 2020 triggered the "DeFi Summer" phenomenon, in which [[Yield Farming]] strategies drove billions of dollars into DeFi protocols and established the [[Liquidity Mining]] pattern copied by virtually every subsequent protocol.
- Compound III (Comet), launched in 2022, redesigned the architecture around isolated markets with a single base asset per deployment, improving capital efficiency and reducing contagion risk compared to the pooled multi-asset v2 model.

### Key Mechanisms

- **cToken Model**
  - When a user deposits an asset (e.g. ETH, USDC, WBTC), Compound mints [[cToken]] receipts (cETH, cUSDC, cWBTC) representing the depositor's share of the pool.
  - The cToken [[Exchange Rate]] rises every [[Ethereum]] block (approximately every 12 seconds) as accrued interest is added to the pool, so interest compounds automatically without any user action.
  - cTokens are standard [[ERC-20]] tokens and can be transferred, used as collateral within Compound, or integrated into other [[DeFi Protocol]] composability stacks.
- **Kinked Interest Rate Model**
  - Each market operates an [[Interest Rate Model]] with a kink point — typically at 80 % utilisation.
  - Below the kink, borrow rates rise slowly as utilisation increases, maintaining cheap credit while supply is ample.
  - Above the kink, rates rise steeply to discourage further borrowing and attract new supply, protecting liquidity available for withdrawals.
  - The parameters of the [[Interest Rate Model]] (base rate, slope, kink, jump multiplier) are set by [[Compound Governor Bravo]] governance votes.
- **Over-Collateralisation and Collateral Factors**
  - Borrowers must lock collateral exceeding the value of their loan; the allowed loan-to-value ratio is the [[Collateral Factor]] (e.g. 0.75 for USDC means a user can borrow up to 75 % of their USDC deposit's value).
  - If a borrower's account liquidity falls below zero (collateral value × collateral factor < outstanding borrows), any account can call the [[Liquidation]] function to repay part of the debt and seize a portion of the collateral at a discount.
  - Liquidation incentives are set by the [[Liquidation Incentive]] governance parameter, typically 8 %.
- **Price Oracles**
  - Compound relies on [[Price Oracle]] feeds to value collateral and detect undercollateralised positions. In v2, Compound used a combination of Chainlink feeds and an on-chain open-price-feed aggregated from centralised exchanges. Incorrect oracle values represent the primary systemic risk vector for the protocol.
- **Compound Governor Bravo**
  - [[Compound Governor Bravo]] is the on-chain governance contract through which COMP token holders propose and vote on protocol changes. A proposal requires a minimum proposer threshold, a voting period of roughly two days, a minimum quorum, and a time-lock delay before execution, providing a multi-layer security buffer against governance attacks.
- **Compound III (Comet) Architecture**
  - Unlike v2's unified multi-asset pool, Comet creates isolated lending markets each with a single designated base asset (e.g. USDC). Collateral assets can only be deposited, not borrowed, reducing the attack surface and preventing cross-market contagion from a single asset's volatility.

### Applications and Use Cases

- **Passive Yield Generation** — users supply stablecoins or blue-chip crypto assets and earn continuously compounding interest with no lockup period.
- **Leveraged Long Positions** — a user deposits ETH as collateral, borrows USDC, purchases more ETH, and repeats; this creates leveraged exposure without using a derivatives exchange.
- **Short Selling** — a user supplies USDC, borrows a token they expect to depreciate, sells it on a [[Decentralised Exchange]], and later repurchases to repay the loan at a lower price.
- **Treasury Management** — DAOs and protocols hold idle stablecoin treasuries in Compound to earn yield while maintaining immediate liquidity.
- **Liquidity Mining Integration** — other [[DeFi Protocol]] composability stacks (e.g. [[Yearn Finance]], [[Convex Finance]]) route user funds through Compound markets to capture COMP rewards in addition to base interest, amplifying yield.
- **Collateralised Debt Positions for DeFi Composability** — cTokens are accepted as collateral in secondary protocols, enabling stacked composability where the same underlying asset earns interest in Compound while simultaneously securing a position elsewhere.
- **Institutional On-Chain Lending** — Compound Treasury (a centralised wrapper product) targeted institutional access to Compound's USDC supply rate, bridging DeFi yield to traditional finance treasury products.

### Contrast with Sibling Protocols

- **Compound vs [[MakerDAO]]** — MakerDAO issues DAI, a protocol-native stablecoin, against locked collateral; Compound lends existing tokens from a shared pool. MakerDAO requires minting a new asset; Compound recycles existing market liquidity.
- **Compound vs [[Aave]]** — Aave introduced flash loans (uncollateralised single-transaction borrows), variable/stable rate switching, and a broader set of listed assets. Compound's simpler model was historically more conservative; Comet narrows the gap on isolated markets.
- **Compound vs [[Uniswap]]** — Uniswap is a spot-trading [[Automated Market Maker]] focused on token swaps; Compound is a lending protocol focused on interest-bearing deposits and collateralised borrows. Both use pooled liquidity but serve fundamentally different financial primitives.

### Standards and Governance Context

- Smart contracts are deployed on [[Ethereum]], currently a proof-of-stake chain governed by [[Ethereum Improvement Proposal]] upgrade proposals. Compound's contracts are audited open-source Solidity code; the protocol does not rely on any off-chain services for core settlement.
- The [[COMP]] token implements the [[ERC-20]] standard and confers voting rights; delegation is supported so passive holders can assign votes to active delegates.
- [[Compound Governor Bravo]] implements a standard on-chain governance pattern subsequently forked by dozens of protocols ([[Uniswap]] governance, [[Gitcoin]] governance, and others). The pattern is sometimes called the "Compound governance standard."
- Interest rate mathematics follows the standard continuous compounding approximation used across DeFi lending protocols; rates are expressed as per-block values and converted to APY for display.
- The OpenZeppelin [[Smart Contracts]] library underpins many of Compound's token and access-control primitives, and Compound contributed to the broader security tooling ecosystem through its own code audits (by Trail of Bits, OpenZeppelin Security, and ABDK) published transparently.

### Provenance

