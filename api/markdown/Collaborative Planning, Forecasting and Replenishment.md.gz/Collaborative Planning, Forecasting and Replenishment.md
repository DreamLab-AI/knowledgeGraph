Collaborative Planning, Forecasting and Replenishment (CPFR) is a business model in which trading partners jointly plan, forecast and replenish stock, developed in the United States by VICS in 1997 and published in guidelines in 1998.[^1]

GS1 Germany, in its guide to CPFR in German-speaking markets, says VICS defines CPFR as a nine-step business model that shows the levels of cooperation between companies in one workflow. It gives the general aim as optimal cooperation of all parties along the value chain to raise consumer benefit, achieved by jointly steering the planning, forecasting and replenishment processes so that availability on the shelf is high while stock is optimised.[^1]

An open operations management textbook describes CPFR as enabling trading partners to collaborate on forecasting and order planning by sharing point-of-sale data, promotion plans, inventory status and forecasts, comparing the shared data with the manufacturer's forecasts and capacity, and resolving discrepancies to agree final forecasts and replenishment plans.[^2]

## Scope and distinctions

Jatta, reviewing the literature, says CPFR has superseded earlier collaborative tools such as vendor-managed inventory, efficient consumer response and electronic data interchange, and reports that it has helped collaborators reduce on-hand inventory, safety stock and lead time while improving service levels and response time.[^3] He contrasts it with sales and operations planning, which he calls predominantly an intrafirm tool.[^3] See [[Supply Chain Collaboration]], [[Vendor-Managed Inventory]] and [[Sales and Operations Planning]].

## What the sources do not establish

Sources opened here do not set out the nine steps by name or report later revisions of the model. The benefits come from a literature review by one author rather than from a measured study.[^3][^1]

[^1]: GS1 Germany, Leitfaden zur Umsetzung von CPFR im deutschsprachigen Wirtschaftsraum, Kapitel 2 (in German), “Kapitel 2 Leitfaden zur Umsetzung von CPFR”. https://events.gs1.de/fileadmin/gs1/fachpublikationen/Kap2_leitfaden_zur_umsetzung_von_cpfr_im_wirtschaftsraum.pdf
[^2]: Operations Management open textbook, eCampusOntario Pressbooks, section 7.8, “Supply Chain Collaboration”. https://ecampusontario.pressbooks.pub/opsmgmt/chapter/7-8-supply-chain-collaboration/
[^3]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content

