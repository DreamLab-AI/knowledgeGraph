A warehouse operation is one of the activities carried out inside a warehouse as goods pass through it.[^1][^2]

A review of operations and supply chain management gives the basic process steps of warehousing as receiving, storage, order picking, shipping and return handling.[^1] A literature review of order picking lists the main warehouse activities as receiving, transfer and put away, order picking or selection, accumulation and sortation, cross-docking, and shipping.[^2] An eCampusOntario logistics text gives a general process in which product is received from incoming vehicles, unloaded, documented, stored, retrieved, packed and loaded on outgoing vehicles.[^3]

## Operations in this corpus

[[Goods Receiving]] and [[Order Picking]] have their own pages. Put-away, which the Georgia Tech textbook describes as requiring an appropriate storage location to be determined before the product is stored, follows receiving.[^4] Storage equipment is covered at [[Warehouse Storage System]].

## Variation between warehouses

That review says virtually every warehouse performs the basic steps but that execution varies significantly between warehousing systems, each of which consists of hardware, such as racks and material handling systems, and processes defining the workflow along the hardware.[^1] It categorises systems as picker-to-parts and parts-to-picker, depending on how stock keeping units and pickers come together.[^1]

## Scope and distinctions

Warehouse operations sit under [[Warehousing and Distribution]]. They are distinct from the choice of facility type at [[Warehouse Facility Type]] and from planning decisions such as [[Inventory Policy]]. A warehouse management system coordinates the activities; see [[Warehouse Management System]].

## What the sources do not establish

Sources give different lists of activities, and none treats the list as fixed. Cost shares quoted for individual activities come from older studies cited by the textbook and are not repeated here.

[^1]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: René de Koster, Tho Le-Duc and Kees Jan Roodbergen, European Journal of Operational Research 182(2), 2007, “Design and control of warehouse order picking: A literature review”. https://pure.eur.nl/ws/portalfiles/portal/46713708/DesignandControl_2007.pdf
[^3]: eCampusOntario Pressbooks (Introduction to Logistics), “Chapter 5 – Warehousing”. https://ecampusontario.pressbooks.pub/logistics001oerfc/chapter/chapter-5-warehousing/
[^4]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf

