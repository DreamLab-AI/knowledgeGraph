Portfolio Management is the discipline of selecting, weighting and overseeing a collection of financial assets so that their combined risk and return characteristics align with an investor's objectives and constraints. It applies diversification, asset allocation and ongoing rebalancing to balance expected return against tolerable risk over a defined horizon. The practice spans both passive strategies that track benchmarks and active strategies that seek to outperform them.

### Overview

- [[Investment Management]] provides the broader context within which Portfolio Management sits.
- Portfolio Management is treated here as a member of the **finance** domain at **mature** maturity.
- It is referenced across the knowledge graph by classes that depend on or compose it, making it a central node that warranted an explicit definition.

### Key aspects

- It comprises [[Asset Management]].
- It comprises [[Risk Management]].
- It requires [[Financial Instruments]].
- It requires [[Data Analytics]].

### Mechanisms

- Portfolio Management operates by combining its constituent parts into a coherent capability that other classes can rely upon.
- Its guarantees and behaviours are realised through the dependencies and standards captured in the relations below.

### Applications

- Enables and supports [[Asset Management]].
- Enables and supports [[Financial Services]].
- Enables and supports [[Financial System]].

### Provenance

