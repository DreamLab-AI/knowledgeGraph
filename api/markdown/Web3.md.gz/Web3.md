Web3 is a blockchain-anchored paradigm for the decentralised web, first coined by ereum co-founder Gavin Wood in his April 2014 essay "DApps: What Web 3.0 Looks Like", that reconceives the internet as a zero-trust interaction system eliminating the need to trust any individual institution or plat...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:SmartContract))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:DecentralisedApplication))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:CryptoWallet))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:EthereumNameService))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:IPFS))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:DAO))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:NFT))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:DEX))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:AccountAbstraction))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:hasPart bc:RestakingProtocol))

    ## Dependency Relationships
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:requires bc:Ethereum))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:requires bc:PublicKeyCryptography))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:requires bc:ConsensusMechanism))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:requires bc:ContentAddressedStorage))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:requires bc:DigitalIdentity))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:dependsOn bc:Layer2Networks))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:dependsOn bc:Tokenomics))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:dependsOn bc:P2PNetworking))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:dependsOn bc:Cryptography))

    ## Capability Relationships
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:enables bc:DigitalSovereignty))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:enables bc:DecentralisedFinance))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:enables bc:Tokenisation))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:enables bc:OnChainGovernance))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:enables bc:AgenticInternet))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:enables bc:DecentralisedIdentity))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:supports bc:DeFi))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:supports bc:NFTEcosystem))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:supports bc:DAOGovernance))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:supports bc:DecentralisedStorage))

    ## Implementation Relationships
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:implements bc:ERC4337AccountAbstraction))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:implements bc:EIP7702PectraAbstraction))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:implements bc:EIP4361SignInWithEthereum))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:implements bc:ENSDecentralisedNaming))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:implements bc:IPFSContentAddressing))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:implements bc:W3CDID))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:uses bc:MetaMaskWallet))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:uses bc:UniswapDEX))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:uses bc:EigenLayerRestaking))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:uses bc:FilecoinStorage))

    ## Reduction Relationships
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:reduces bc:IntermediaryDependence))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:reduces bc:PlatformCensorshipRisk))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:reduces bc:CustodialCounterpartyRisk))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:reduces bc:DataPortabilityBarrier))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:contrasts bc:Web2CentralisedPlatform))
    SubClassOf(bc:Web3
      ObjectSomeValuesFrom(bc:contrasts bc:SolidDecentralisedWeb))

    ## Annotations
    AnnotationAssertion(rdfs:label bc:Web3 "Web3"@en)
    AnnotationAssertion(rdfs:comment bc:Web3 "Blockchain-anchored decentralised web paradigm (Gavin Wood 2014) reconceiving the internet as a zero-trust interaction system built on smart contracts, content-addressed storage, cryptographic identity, and decentralised governance, encompassing DeFi, NFTs, DAOs, account abstraction (ERC-4337/EIP-7702), ENS, IPFS, restaking (EigenLayer), decentralised social (Farcaster, Lens), and an emerging agentic layer where AI agents hold on-chain wallets and execute autonomous transactions."@en)
    AnnotationAssertion(dcterms:identifier bc:Web3 "BC-0032"^^xsd:string)
    AnnotationAssertion(dcterms:subject bc:Web3 "Blockchain, Decentralised Web, Smart Contracts, Digital Sovereignty, DeFi, NFT, DAO, Account Abstraction, ENS, IPFS"@en)
  )

## Property Characteristics
AsymmetricObjectProperty(bc:requires)
AsymmetricObjectProperty(bc:enables)
AsymmetricObjectProperty(bc:implements)
AsymmetricObjectProperty(bc:reduces)
TransitiveObjectProperty(bc:dependsOn)

## About Web3

- **Web3** is a blockchain-anchored paradigm for the decentralised internet, conceptually originating in Gavin Wood's April 2014 essay "ĐApps: What Web 3.0 Looks Like". Wood, then a co-founder of Ethereum, characterised the problem with the existing web as one of misplaced trust: users are compelled to entrust their personal data, financial transactions, and communications to centralised intermediaries whose interests diverge structurally from their own. His proposed alternative was a "zero-trust interaction system"—a stack in which no single party holds privileged, unilateral authority over data or transactions. The term "Web3" itself subsequently gained enormous cultural traction, particularly during the 2020-2022 speculative cycle, though the underlying architectural vision predates the hype considerably.
- The lineage from Web 1.0 (read-only static pages), through Web 2.0 (read-write, platform-mediated participation), to Web3 (read-write-own, cryptographically enforced self-custody) is the canonical framing. Wood's four primitives—static content publication, pseudonymous messaging, consensus-engine-backed transactions, and browser-integrated user interface—map directly to the technology stacks that have since matured: IPFS and Filecoin for content-addressed storage, Ethereum and its rollup ecosystem for execution, MetaMask and its successors for wallet-embedded browsers, and emerging decentralised social protocols for messaging.
- A healthy body of critique accompanies Web3 enthusiasm. The most technically incisive came from Moxie Marlinspike (Signal founder), whose January 2022 essay "My first impressions of web3" demonstrated empirically that the ecosystem had re-centralised around a small number of API providers (Infura, Alchemy for blockchain access; OpenSea for NFT metadata) such that removing content from OpenSea caused it to disappear from all crypto wallets—precisely the censorship-resistance failure Web3 promised to prevent. MetaMask itself banned users from sanctioned jurisdictions in 2022, demonstrating that client-layer centralisation can neutralise protocol-layer decentralisation. These failures are not refutations of the Web3 thesis but rather maps of where the engineering remains incomplete.

### Origins: Gavin Wood's 2014 Vision

- The founding document is Gavin Wood's blog post of 17 April 2014, "ĐApps: What Web 3.0 Looks Like", published at gavwood.com. Wood argued that the post-Snowden internet required a paradigm shift: rather than trusting organisations to behave ethically, the architecture itself should be incapable of permitting betrayal. He identified four components required for this zero-trust web. First, trustless static content publication—any user should be able to publish content that cannot be altered or censored by any third party, pointing toward content-addressed (hash-verified) storage. Second, a pseudonymous low-level messaging layer allowing communication without exposing identity, pointing toward what later became the Whisper and Waku protocols. Third, a consensus engine—a decentralised, programmable state machine in which arbitrary agreements (smart contracts) are enforced by the network without requiring trust in any counterparty, which Ethereum was designed to fulfil. Fourth, an integrated user-interface layer that makes all of the above accessible inside a browser, which has since evolved into browser extension wallets (MetaMask) and mobile-native wallets (Rainbow, Coinbase Wallet, Phantom for Solana).
- Wood went on to co-found the Web3 Foundation in 2017 (registered in Zug, Switzerland), which funded the Polkadot ecosystem, a heterogeneous multi-chain architecture using substrate-based parachains connected via a relay chain. Polkadot's cross-chain message passing (XCMP) and the Kusama canary network represent Wood's ongoing effort to deliver the interoperability components of his original vision.

### Core Infrastructure: Wallets, ENS, and IPFS

#### Crypto Wallets

- Wallets are the primary Web3 user-interface layer, managing cryptographic keys, signing transactions, and presenting on-chain state. The "wallet wars" of 2022-2024 produced a diverse competitive field. **MetaMask** (ConsenSys) is the dominant Ethereum browser extension with over 30 million monthly active users as of 2023, though its jurisdiction-based sanctions compliance in 2022 drew widespread criticism. **Rainbow** is a consumer-grade Ethereum mobile wallet known for UX quality, NFT display, and WalletConnect v2 support. **Phantom** originated as the dominant Solana wallet and expanded to Ethereum and Bitcoin, crossing 10 million users in 2024. **Coinbase Wallet** and **Robinhood's crypto wallet** brought over 100 million combined registered users to the self-custodial wallet space, significantly expanding the addressable market. The next generation of wallets is being redesigned around **account abstraction** (see below), enabling features such as social recovery (replacing seed phrases with trusted contacts), session keys for gaming, gas-sponsored transactions where applications pay users' fees, and passkey-based authentication via device biometrics rather than mnemonic phrases.

#### Ethereum Name Service (ENS)

- ENS is a distributed, open, and extensible naming system based on the Ethereum blockchain, translating human-readable names (e.g., vitalik.eth) to machine-readable identifiers including Ethereum addresses, content hashes (IPFS CIDs), and metadata. ENS launched in May 2017 and decentralised its governance via the ENS DAO in November 2021. As of 2024-2025, ENS holds over 85% market share in decentralised on-chain naming across Ethereum. ENS names are ERC-721 NFTs registered via the .eth registrar, with subnames (e.g., wallet.vitalik.eth) enabling delegation hierarchies. ENSv2, announced for deployment in early 2026, moves the registrar logic directly onto Ethereum mainnet (cancelling a planned dedicated L2) to maximise security guarantees. ENS has become critical infrastructure for decentralised identity: wallets resolve .eth names natively, Sign-In with Ethereum (EIP-4361) uses ENS as a human-readable identifier layer, and emerging AI agent identity frameworks propose ENS subnames as machine-agent identifiers.

#### IPFS and Filecoin

- The **InterPlanetary File System (IPFS)**, created by Protocol Labs and first published by Juan Benet in 2014, is a peer-to-peer hypermedia protocol using content addressing (CIDs, SHA-256 Merkle DAGs) rather than location addressing. Content is identified by what it is rather than where it is hosted, making it inherently censorship-resistant and deduplicated. IPFS underpins a significant fraction of NFT metadata and asset storage: a 2024 analysis found approximately 39% of NFTs stored their metadata and assets on IPFS. The IPFS network maintained approximately 23,000 active peers in 2024-2025. **Filecoin**, Protocol Labs' incentivised storage layer built on IPFS, adds economic guarantees: storage providers are cryptographically required to prove ongoing data possession via Proof-of-Spacetime (PoSt). By Q3 2025, Filecoin hosted 2,491 onboarded datasets, with 925 exceeding 1,000 TiB. The decentralised cloud storage market reached approximately $577 million in 2025 (14.9% CAGR from $506M in 2024). **Arweave** offers a complementary one-time-payment permanent storage model targeting immutable archival use cases including NFT assets and on-chain governance history.

### Account Abstraction: ERC-4337 and EIP-7702

#### ERC-4337 Account Abstraction

- Account abstraction decouples Ethereum accounts from the EOA (Externally Owned Account) model—where a single private key controls all operations—and enables arbitrary validation logic in smart contract wallets. ERC-4337, authored by Vitalik Buterin and collaborators, achieved general availability on Ethereum mainnet in March 2023 via deployment of the EntryPoint singleton contract at a canonical address. The standard introduces **UserOperations** (pseudo-transactions bundled by Bundlers), **Paymasters** (gas sponsorship abstractions), **Account Factories** (counterfactual smart wallet deployment), and an **Alt Mempool** for UserOperation propagation. Adoption accelerated dramatically in 2024: over 40 million smart accounts were deployed across Ethereum and Layer 2s (nearly 20 million in 2024 alone, 7× year-over-year growth), with cumulative UserOperations exceeding 100 million by year-end 2024—a 10× increase from 2023. The vast majority of UserOperations leverage Paymasters for sponsored gas, with tens of millions of dollars in fees absorbed by applications. Base, Polygon, and Optimism lead adoption; Polygon alone exceeded 7 million smart accounts. Industry projections anticipated over 200 million smart accounts by late 2025.

#### EIP-7702 and the Pectra Hard Fork

- EIP-7702 was activated on Ethereum mainnet as part of the **Pectra hard fork** on 7 May 2025 at epoch 364032 (10:05:11 UTC). Authored by Vitalik Buterin, Sam Wilson, and Ansgar Dietrichs, EIP-7702 introduces a new transaction type (type 0x04, "setCode") allowing an EOA to temporarily delegate control to a smart contract implementation—granting it smart-account capabilities (batching, gas sponsorship, passkey authentication, social recovery) without requiring migration to a new address. This is complementary to rather than a replacement of ERC-4337: wallets implementing EIP-7702 can leverage existing ERC-4337 Bundler and Paymaster infrastructure. Within the first week post-Pectra, over 11,000 EIP-7702 authorizations were created on-chain. Pectra also included EIP-7251 (validator consolidation, raising the maximum effective balance from 32 to 2,048 ETH) and EIP-7691 (blobspace doubling for L2 data availability). The combined effect of ERC-4337 and EIP-7702 is the practical completion of account abstraction as a general Ethereum primitive, enabling Web2-level onboarding UX (biometric sign-in, no seed phrases, application-pays-gas) at the wallet layer.

### Decentralised Finance (DeFi)

- DeFi encompasses financial primitives implemented as permissionless, composable smart contracts on public blockchains, eliminating the need for licensed intermediaries. The core DeFi stack includes: **Automated Market Makers (AMMs)** such as Uniswap (v1-v4, concentrated liquidity, hooks architecture), Curve (stablecoin-optimised), and Balancer (customisable pool weights), executing token swaps via the constant-product or similar invariant formulas without order books; **lending protocols** such as Aave and Compound implementing overcollateralised variable/fixed rate borrowing with on-chain liquidation engines; **stablecoins** including DAI (MakerDAO, collateral-backed), USDC (Circle, regulated fiat-backed), and algorithmic variants with volatile track records (Terra/LUNA collapse May 2022); and **derivatives** including Synthetix, dYdX, and GMX for perpetual swaps and synthetic asset exposure. DeFi total value locked (TVL) peaked at approximately $180B in November 2021, collapsed to approximately $40B by late 2022, and recovered to $90-120B range through 2024-2025. **MEV (Maximal Extractable Value)** represents a structural feature/pathology of DeFi: validators and block builders can reorder, insert, or exclude transactions to extract value, producing sandwich attacks (51.56% of $561.92M in MEV transaction volume in 2025), arbitrage, and liquidation front-running. By mid-2024, approximately 526,000 ETH (~$686M) had been extracted via MEV-Boost since the Merge; three builders produced over 80% of Ethereum blocks within a six-month period in 2024, indicating significant block production centralisation.

### Non-Fungible Tokens (NFTs)

- Non-fungible tokens are ERC-721 (or ERC-1155 semi-fungible) smart contract tokens encoding unique, verifiable digital ownership on public blockchains. NFTs enable artists, musicians, game developers, and brands to sell digital items with on-chain provenance and royalty logic. The 2021-2022 speculative cycle saw extraordinary volume—Bored Ape Yacht Club (BAYC), CryptoPunks, and Art Blocks commanded prices of $100K-$1M+ per item. The critique that NFTs are a "complex and inefficient digital rights management system" gained traction as it became clear that: (1) NFT metadata and media assets are typically stored off-chain (on IPFS or centralised servers) rather than on-chain, meaning OpenSea (or a CDN) can effectively delete the displayed content; (2) royalty enforcement depends on marketplace compliance rather than protocol-layer enforcement, and marketplace competition drove royalties toward zero in 2022-2023; (3) the majority of NFT trading volume was driven by speculation rather than utilitarian use. Nevertheless, NFTs retain structural utility for gaming asset ownership, event ticketing (fungibility-resistant), creator subscriptions, and on-chain governance voting tokens (ERC-721 used as DAO membership). ERC-6551 (Token Bound Accounts, 2023) enables NFTs to own other assets and act as wallets, opening composable "NFT-as-agent" patterns.

### Decentralised Autonomous Organisations (DAOs)

- DAOs implement on-chain governance using token voting (ERC-20 governance tokens, ERC-721 membership NFTs, or more sophisticated vote-escrow mechanisms like Curve's veCRV). The canonical DAO tooling stack includes Snapshot (off-chain signalling, gas-free voting), Governor Bravo / OpenZeppelin Governor (on-chain proposal execution), Gnosis Safe (multi-signature treasury management), and Tally (governance dashboard). Notable DAOs include MakerDAO (governs DAI stablecoin and Spark lending protocol, treasury >$3B), Uniswap DAO ($4B+ treasury), ENS DAO, Gitcoin DAO (public goods funding), and the Ethereum Cat Herders (EIP process). DAO governance challenges include low voter participation (typically 5-20% of eligible tokens), plutocratic voting power concentration (large token holders dominate), governance attacks (hostile acquisition of voting majority to drain treasury—the original "The DAO" hack of 2016 extracted $60M), and meta-governance complexity as protocols hold governance tokens in other protocols. Emerging solutions include conviction voting, quadratic voting, delegate systems (Compound's delegation model), and rage-quit mechanisms (Moloch DAO, DAOHaus).

### Decentralised Social: Farcaster, Lens, and Bluesky

- Decentralised social protocols attempt to give users ownership of their social graph and content, preventing platform lock-in and censorship. **Farcaster** (Merkle Manufactory / Warpcast) is a sufficiently decentralised social network anchored on Ethereum: user identities (Farcaster IDs, FIDs) are registered as NFTs on an Ethereum-deployed Farcaster ID Registry, but content (casts, reactions, links) is stored off-chain in a federated network of Hubs, reducing cost and latency. Farcaster reached 1,049,519+ registered IDs by April 2025, with a peak of 80,000 monthly active users before declining to under 20,000 by late 2025, reflecting the difficulty of sustaining engagement on crypto-native social layers. Frames (interactive in-feed mini-apps) and Channels (topic-based communities) are platform-level innovations extending protocol capabilities. **Lens Protocol** (Stani Kulechov, Aave team) stores social graph data as on-chain NFTs (Profile NFTs, Follow NFTs, Publication NFTs) on Polygon, enabling fully composable social primitives. Lens completed a major migration of 650,000 user profiles and 125GB of social graph data to its own L2 chain in 2025; DAU stabilised at approximately 20,000. **Bluesky** and the **AT Protocol** (Authenticated Transfer Protocol) are not blockchain-based but share the Web3 ethos of user-controlled identity (DIDs anchored in the `did:plc` or `did:web` registries) and portable social graphs across federated PDS (Personal Data Server) providers. Bluesky reached approximately 38 million users by September 2025 with 4-5 million DAU, outpacing both Farcaster and Lens in mainstream adoption, suggesting that cryptographic guarantees without token mechanics may be more accessible to non-crypto users.

### Restaking: EigenLayer and the AVS Ecosystem

- Restaking allows ETH stakers to extend their cryptoeconomic security to additional protocols beyond Ethereum consensus. **EigenLayer** (Eigen Labs, Seattle/Seattle) introduced restaking on Ethereum mainnet in 2023, enabling LST holders and native stakers to opt-in to securing **Actively Validated Services (AVS)**—external protocols that require customisable trust assumptions including bridges, oracles, data availability layers, shared sequencers, ZK coprocessors, and AI model verification. EigenLayer grew from $1.1B TVL to over $18B TVL by February 2026 (1,900+ active operators), representing 85%+ of the restaking market. The emerging **Vertical AVS (VAVS)** trend specialises AVS instances by validation type; AI verification AVS became the fastest-growing category in 2025 as 280+ crypto-AI projects sought trust-minimised model evaluation. Competing restaking protocols include Symbiotic (Lido-backed, multi-asset) and Karak Network, creating a competitive restaking primitive market. The systemic risk of restaking—slashing cascade and correlated failure across protocols sharing the same restaked ETH—remains an active research concern flagged by Ethereum researchers including Dankrad Feist and Justin Drake.

### MEV: The Dark Forest

- Maximal Extractable Value (MEV)—previously termed "miner extractable value"—refers to the value that can be captured by block producers (validators post-Merge) by manipulating transaction ordering: including, excluding, or reordering transactions within a block beyond standard gas-price priority. The "dark forest" metaphor (named after a 2020 essay by Dan Robinson and Georgios Konstantopoulos) captures the predatory dynamic: sophisticated MEV bots monitor the public mempool and front-run, back-run, or sandwich user transactions. MEV-Boost (Flashbots) separated the proposer-builder separation (PBS) into a market where specialised builders compete to construct the most profitable block, with validators selecting the highest-bid block via relay infrastructure. MEV revenue averaged $500K/day in 2023, stabilising at approximately $300K/day by 2024. Sandwich attacks accounted for 51.56% of $561.92M in MEV transaction volume in 2025. Three builders producing >80% of Ethereum blocks in 2024 represents severe centralisation risk. Mitigation approaches include: encrypted mempools (SUAVE, Shutter Network), MEV-aware DEX design (Uniswap v4 hooks for MEV recapture), and intent-based transaction systems (CoW Protocol, 1inch Fusion) that route orders to solvers rather than exposing them to the public mempool.

### Agentic Web3: AI Meets On-Chain Execution

- The convergence of AI agents with Web3 infrastructure constitutes an emergent paradigm in 2024-2026. Account abstraction (ERC-4337, EIP-7702) enables AI agents to hold Ethereum smart accounts with programmable key management—rotatable keys, session keys scoped to specific dApps, gas-sponsored operations—without the single-private-key brittleness of EOAs. Agents monitoring multiple chains (Solana, Polygon, Arbitrum simultaneously) can execute cross-DEX arbitrage, yield optimisation across Aave and Curve, and liquidation defence autonomously. EigenLayer's AI verification AVS category ($280+ projects in 2025) attempts to bring trust-minimised attestation to AI model execution, enabling on-chain disputes about AI behaviour. W3C DIDs combined with ENS subnames are proposed as canonical on-chain agent identity layers. The five-layer agentic Web3 architecture proposed in the literature comprises: physical infrastructure (DePIN protocols), identity and agency (W3C DIDs, ENS, reputation capital), cognitive tooling (RAG, MCP integrations), economic settlement (account abstraction, stablecoins), and collective governance (Agentic DAOs with multi-agent voting). Key unresolved challenges include legal personality for autonomous agents transacting on-chain, key custody (who controls the private key ultimately), liability for agent-executed MEV or front-running, and adversarial prompt injection targeting Web3 agents.

### Critiques: Centralisation, Gambling Framing, and Web2 Comparison

- Web3 has attracted substantive structural critique beyond the dismissive "crypto = speculation" framing. Marlinspike's 2022 essay identified three technical mechanisms of re-centralisation: (1) lightweight clients (mobile, browser) cannot validate the chain themselves and must trust API providers (Infura, Alchemy) who can and do censor; (2) NFT metadata is off-chain and controlled by whoever hosts the URI in the token contract, meaning OpenSea deletion propagates to all wallets using its metadata API; (3) application-layer client software (MetaMask) is a centralised product that complies with sanctions, restoring state censorship at the UX layer. ARK Invest's "Big Ideas 2022" framing distinguished the monetary (Bitcoin), financial (DeFi), and internet (Web3) revolutions as three separate phenomena conflated by speculative framing. The gambling and scam framing—elevated by the 2022 FTX collapse, the Terra/LUNA wipeout ($40B+), and persistent rug-pull statistics—is statistically grounded: a 2023 Chainalysis report found that illicit addresses received $24.2B in crypto in 2023. The comparison to **Tim Berners-Lee's Solid Project** is instructive: Solid uses standard web protocols (HTTP, Linked Data, WebID) to give users a Personal Online Datastore (POD) with granular access control over third-party apps, achieving data sovereignty without blockchains, token mechanics, or gas fees. Solid's lack of financial primitive (no native token) has limited its traction but also its speculative distortion; Web3 proponents argue that without token-economic coordination, public goods provision and infrastructure incentivisation are structurally harder.

### Use Cases / Major Families

#### DeFi Protocols

- The canonical DeFi protocol families include: AMM DEXs (Uniswap, Curve, Balancer); money markets (Aave, Compound, Morpho); stablecoin issuance (MakerDAO/Sky, Frax, Liquity); decentralised derivatives (dYdX, GMX, Synthetix); yield aggregators (Yearn Finance, Convex Finance); cross-chain bridges (Stargate, Across Protocol, LayerZero OFT); and structured products (Pendle Finance for yield tokenisation). Composability—smart contracts calling other smart contracts atomically within a single transaction—enables flash loans (unsecured borrow-and-repay within one transaction block) and complex multi-protocol yield strategies impossible in traditional finance.

#### NFT Ecosystems

- NFT use cases mature beyond speculation include: gaming asset interoperability (Immutable X, Ronin Network for Axie Infinity); digital art and creative provenance (Art Blocks, Foundation, SuperRare); music royalties and fan engagement (Royal, Sound.xyz); event ticketing (GET Protocol, preventing scalping via programmable transfer rules); domain names (ENS .eth, Unstoppable Domains .crypto); and real-world asset (RWA) tokenisation (BlackRock BUIDL fund, tokenised Treasuries on Ethereum reaching $1.3B+ TVL in 2024).

#### DAOs and On-Chain Governance

- Governance DAOs span protocol governance (Compound, Aave, Uniswap, MakerDAO), investment collectives (MetaCartel Ventures, The LAO), public goods funding (Gitcoin, Protocol Guild), community ownership (Friends With Benefits, FWB), and media co-operatives (Forefront). Innovations in governance design include vote-escrow tokenomics (veCRV model rewarding long-term lockups with boosted voting power), delegate systems (enabling expertise-driven representation), and futarchy (market-based governance proposals).

### Academic Context

- The foundational academic literature on Web3 spans cryptography (Nakamoto 2008 Bitcoin whitepaper; Buterin 2014 Ethereum whitepaper; Wood 2014 Ethereum Yellow Paper), distributed systems (Fischer, Lynch, Paterson 1985 FLP impossibility; Castro & Liskov 1999 PBFT; Lamport 1998 Paxos), mechanism design (Roughgarden 2021 EIP-1559 analysis), and game theory (Selfish Mining, Ghosh & Roughgarden 2020 MEV formalisation). The emergence of ERC-4337 account abstraction motivated a sub-literature on smart account security including a 2024 ICNC measurement paper ("A Measurement Investigation of ERC-4337 Smart Contracts on Ethereum Blockchain") analysing smart account deployment patterns across the Ethereum mainnet. MEV research is consolidated via the Flashbots Collective and Titan Builder publications. Protocol economics (tokenomics) has emerged as a discipline at the intersection of mechanism design and blockchain engineering, with the "3Ds of Token Design" (produced in collaboration between Outlier Ventures and Imperial College London) establishing a structured framework for token design.

### Current Landscape (2026)

- As of mid-2026, the Web3 landscape is characterised by: (1) **Layer 2 dominance**—the majority of Ethereum transaction activity migrated to rollups (Base, Arbitrum, Optimism, zkSync, Linea), with Base (Coinbase) exceeding Ethereum mainnet in daily transactions; (2) **Account abstraction maturation**—40M+ smart accounts deployed, EIP-7702 live post-Pectra, passkey wallets entering mainstream; (3) **RWA tokenisation**—real-world assets (Treasuries, private credit, real estate) reaching $10B+ on-chain TVL in 2025, with BlackRock, Franklin Templeton, and Fidelity active; (4) **Restaking expansion**—EigenLayer at $18B TVL with 1,900+ operators; (5) **AI-agent integration**—autonomous agents holding on-chain wallets, executing DeFi strategies, and participating in DAO governance; (6) **Regulatory clarity creeping in**—US crypto market structure legislation advanced in 2025, UK FCA digital asset regime implementation, EU MiCA full enforcement from January 2025; (7) **Wallet UX convergence**—major CEX wallets (Coinbase, Robinhood) and consumer apps integrating embedded Web3 wallets. Persistent challenges include MEV centralisation, governance plutocracy, cross-chain security (bridge hacks totalling $2B+ historically), and the fundamental Marlinspike critique of infrastructure centralisation.

### UK Context (Imperial / Edinburgh / UCL / Cambridge / Manchester)

- The UK Web3 ecosystem is anchored by several institutional nodes. **Outlier Ventures** (London, founded Jamie Burke 2013) is Europe's leading Web3 accelerator and venture fund, running the Base Camp and Open Metaverse accelerators and conducting original research including the Web3 Toolbox and Token Design frameworks. Outlier Ventures signed a 3-year R&D partnership with **Imperial College London's Centre for Cryptocurrency Research and Engineering (IC3RE)** to explore the convergence of blockchain with deep tech (IoT, machine learning, autonomous systems), supervised by Prof William Knottenbelt and Dr Catherine Mulligan; the collaboration produced the award-winning "3Ds of Token Design" framework. **Imperial College London** additionally hosts the IOTA-Foundation-backed Distributed Technology Research laboratory (£1M endowment) for DLT research. **University College London (UCL) Centre for Blockchain Technologies** (CBT) conducts interdisciplinary research spanning consensus protocols, digital currencies, and governance. **University of Edinburgh** hosts the Blockchain Technology Laboratory (BTL) under Prof Aggelos Kiayias (IOG Chief Scientist, lead designer of the Ouroboros proof-of-stake protocol underpinning Cardano). **University of Cambridge** hosts the Cambridge Centre for Alternative Finance (CCAF), producers of the Cambridge Crypto Asset Benchmarking studies and Bitcoin Electricity Consumption Index (CBECI). **Alan Turing Institute** supports blockchain and distributed systems research across partner universities. The Northern England cluster includes **University of Manchester's** Blockchain Research Group and industry activity in Manchester's growing digital tech sector (MediaCityUK); **University of Sheffield** and **Newcastle University** research blockchain for supply chain and industrial IoT applications. The UK FCA has operated a Cryptoasset Registration regime since January 2020 and is implementing the full digital asset regulatory framework under the Financial Services and Markets Act 2023.

### Future Directions (2026-2030)

- Several trajectories are projected for the 2026-2030 period. **Full danksharding** (Ethereum EIP-4844 proto-danksharding live March 2024; full danksharding targeting 2026-2027) will reduce L2 data costs by 10-100×, enabling sub-cent transaction fees at scale. **Verkle trees and stateless clients** (planned Ethereum upgrade post-Pectra, "Glamsterdam") will enable lightweight clients to verify state without full chain download, directly addressing Marlinspike's light-client critique. **Proposer-Builder Separation (PBS) enshrinement** and **attester-proposer separation (APS)** aim to decentralise block building at the protocol layer, mitigating MEV centralisation. **Trustless cross-chain interoperability** via ZK light client bridges (Succinct, Polymer Protocol) replaces trusted multisig bridges, eliminating the most common attack vector ($2B+ in bridge hacks historically). **Decentralised physical infrastructure networks (DePIN)**—Helium (wireless), Hivemapper (mapping), DIMO (vehicle data)—extend Web3 tokenisation to physical-world data collection. **Agentic DAOs** with AI agent delegates participating in governance votes, executing treasury management strategies, and operating DeFi positions autonomously are expected to mature as account abstraction and agent frameworks converge. **ENSv2** on Ethereum mainnet (2026) and standardised cross-chain name resolution will make cryptographic identity ubiquitous. Post-quantum cryptography transitions (NIST PQC standard finalised 2024) will eventually require Ethereum's ECDSA signature scheme replacement, though timelines remain speculative.

### Research & Literature

- Nakamoto, S. (2008). Bitcoin: A Peer-to-Peer Electronic Cash System. bitcoin.org.
- Buterin, V. (2014). Ethereum: A Next-Generation Smart Contract and Decentralised Application Platform. ethereum.org.
- Wood, G. (2014). ĐApps: What Web 3.0 Looks Like. gavwood.com/dappsweb3.html.
- Wood, G. (2014). Ethereum: A Secure Decentralised Generalised Transaction Ledger (Yellow Paper). gavwood.com.
- Marlinspike, M. (2022). My first impressions of web3. moxie.org/2022/01/07/web3-first-impressions.html.
- Robinson, D. and Konstantopoulos, G. (2020). Ethereum is a Dark Forest. medium.com/flashbots/ethereum-is-a-dark-forest.
- Daian, P. et al. (2020). Flash Boys 2.0: Frontrunning in Decentralised Exchanges, Miner Extractable Value, and Consensus Instability. IEEE S&P 2020.
- Fischer, M. J., Lynch, N. A., and Paterson, M. S. (1985). Impossibility of distributed consensus with one faulty process. Journal of the ACM, 32(2), 374–382.
- Buterin, V. et al. (2021). EIP-4337: Account Abstraction Using Alt Mempool. eips.ethereum.org/EIPS/eip-4337.
- Buterin, V., Wilson, S., and Dietrichs, A. (2024). EIP-7702: Set EOA Account Code. eips.ethereum.org/EIPS/eip-7702.
- Ethereum Foundation. (2025). Pectra Mainnet Announcement (epoch 364032, 7 May 2025). blog.ethereum.org.
- Roughgarden, T. (2021). Transaction Fee Mechanism Design for the Ethereum Blockchain: An Economic Analysis of EIP-1559. EC '21.
- Lin, X. et al. (2024). A Measurement Investigation of ERC-4337 Smart Contracts on Ethereum Blockchain. ICNC 2024.
- Kiayias, A. et al. (2017). Ouroboros: A Provably Secure Proof-of-Stake Blockchain Protocol. CRYPTO 2017.
- Ghosh, M. and Roughgarden, T. (2020). An Axiomatic Approach to Formalized Blockchain Transaction Ordering. arXiv:2012.00714.
- Turner, A. et al. (Outlier Ventures / Imperial College London, 2022). The 3Ds of Token Design. outlierventures.io.
- Szabo, N. (1997). Formalizing and Securing Relationships on Public Networks. First Monday.
- Johnson, N. et al. (2023). The Agent Economy: A Blockchain-Based Foundation for Autonomous AI Agents. arXiv:2602.14219.
- ESMA. (2025). Maximal Extractable Value: Implications for Crypto Markets. ESMA50-481369926-29744.
- Chainalysis. (2024). Crypto Crime Report 2024. chainalysis.com.
- Messari. (2025). State of Filecoin Q1 2025. messari.io.
- Knottenbelt, W. and Mulligan, C. (Imperial College London / Outlier Ventures, 2023). Blockchain Deep Tech Convergence Research Programme. outlierventures.io.
- Berners-Lee, T. (2016). Solid: Empowering Users Through an Open, Interoperable Ecosystem. MIT CSAIL.
- Török, J. and Kertész, J. (2017). Cascading collapse of online social networks. Scientific Reports, 7(1).
- Edelman Trust Barometer. (2022/2023). Annual Global Survey of Institutional Trust. edelman.com.

## Metadata

- **domain-correction:** none (domain correctly identified as blockchain throughout)

### Provenance

