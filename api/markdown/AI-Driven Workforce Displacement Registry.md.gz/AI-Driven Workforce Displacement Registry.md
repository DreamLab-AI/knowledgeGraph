A curated record of mass layoffs in the technology sector from 2023 onwards, cataloguing headcount reductions at major firms alongside UK government estimates that AI automation may displace 10–30% of existing jobs. The tracker contextualises how AI adoption—particularly large language models and agentic AI—is accelerating workforce restructuring across white-collar roles.

### Semantic Classification

### Content

- automatically published

# Most threatened roles

- UK dept of education [10-30% can be automated away.](https://assets.publishing.service.gov.uk/media/656856b8cc1ec500138eef49/Gov.UK_Impact_of_AI_on_UK_Jobs_and_Training.pdf#:~:text=It%20has%20been%20estimated%20that%2010-30%25%20of%20jobs,the%20potential%20benefits%20advances%20in%20AI%20will%20bring.)

# Mass Layoff tracker

- 2023
  - Recent layoffs at [Microsoft](https://www.theverge.com/2023/1/18/23560315/microsoft-job-cuts-layoffs-2023-tech) (10,000 jobs or 5 percent of the workforce),
  - [Amazon](https://www.theverge.com/2023/1/18/23560874/amazon-layoffs-18000-january-november) (18,000 jobs / 6 percent)
  - [Meta](https://www.theverge.com/2022/11/9/23448926/meta-layoffs-2022) (11,000 / 13 percent).
  - [Google lays off hundreds working on its voice-activated assistant | Semafor](https://www.semafor.com/article/01/10/2024/google-lays-off-hundreds-working-on-its-voice-activated-assistant)
  - [Duolingo's AI-driven jobs cuts are a no brainer – here's why | ITPro](https://www.itpro.com/technology/artificial-intelligence/duolingos-ai-driven-jobs-cuts-are-a-no-brainer-heres-why)
- 2024 so far
  - PayPal cuts 9% of workforce
  - UPS cuts +12,000 roles
  - Microsoft cuts +1,900 roles
  - Twitch cuts 35% of workforce
  - Unity Software 25%
  - Brex 20%
  - Discord 17%
  - Wayfair 13%
  - Riot Games 11%
  - Duolingo 10%
  - Rent the Runway 10%
  - eBay 9%
  - Blackrock 3%
  - Citigroug cuts 20,000 roles
  - Google cuts +1,000
  - Amazon cuts several hundred roles

### Provenance

