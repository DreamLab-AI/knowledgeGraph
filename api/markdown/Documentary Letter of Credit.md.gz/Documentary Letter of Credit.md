A documentary letter of credit, also called a documentary credit, is a bank's undertaking to pay a seller against presentation of documents that comply with the terms of the credit.[^1][^2]

Article 2 of the ICC's Uniform Customs and Practice for Documentary Credits (UCP 600) defines a credit as any arrangement, however named or described, that is irrevocable and thereby constitutes a definite undertaking of the issuing bank to honour a complying presentation.[^1] A complying presentation is one in accordance with the terms and conditions of the credit, the applicable provisions of the rules and international standard banking practice.[^1] UCP 600 adds that a credit is irrevocable even if there is no indication to that effect.[^1]

## How it works

The US International Trade Administration describes a letter of credit as a commitment by a bank on behalf of the applicant, the importer, that payment will be made to the beneficiary, the exporter, provided the stated terms and conditions are met, as evidenced by the presentation of specified documents.[^2] The guide says the letter of credit is a separate contract from the sales contract, so banks are not concerned with the quality of the goods, and that the bank's obligation is conditioned only on compliance of the documents with the credit: banks deal in documents only, not goods.[^2] A second bank can add its engagement to pay, which the guide calls confirmation.[^2]

## Cost and use

ITA lists the main drawbacks as a labour-intensive process and a relatively expensive method in terms of transaction costs.[^2] UK Government guidance recommends considering a letter of credit when exports are high value and payment certainty cannot be had by another method.[^3] See [[Trade Payment Method]].

## Scope and distinctions

The UK page describes a letter of credit as a guarantee from a bank on behalf of the buyer, promising to pay if the buyer cannot.[^3] That wording differs from the UCP 600 definition, where the bank's undertaking is to honour a complying presentation, and from the US guide, where it is a commitment to pay against documents. The ITA guide also states that an LC is always irrevocable unless its conditions state otherwise, whereas UCP 600 makes every credit irrevocable.[^1][^2]

## What the sources do not establish

UCP 600 is cite-only and only its definitions were read. Escrow and payment systems, covered at [[Escrow System]] and [[Payment System]], were not researched for this page.[^1]

[^1]: International Chamber of Commerce, “Uniform Customs and Practice for Documentary Credits” (UCP 600), ICC Digital Library. https://library.iccwbo.org/content/tfb/RULES/tfb-ucp600-rules.htm
[^2]: US International Trade Administration, “Trade Finance Guide: A Quick Reference for U.S. Exporters”, updated 2021 (PDF). https://www.trade.gov/sites/default/files/2021-03/Trade%20Finance%20Guide%20Updated%20030421%20FINAL.pdf
[^3]: UK Government (business.gov.uk), “Managing payment terms for export orders”. https://www.business.gov.uk/export-from-uk/learn/categories/funding-financing-and-getting-paid/get-paid/decide-when-get-paid-export-orders/

