
An agent task is a well-defined action unit exchanged between agents, declared as `Task` in the core module of the Agent Ontology.[^1] The threat-model module restates it and notes that it corresponds to the task graph.[^2] visionGraph places it under [[Task Planning]].

An agent performs a task through `performsTask`, and an agent can hand one on with `delegatesTask`. A task requires capabilities through `requiresCapability`, whose range is [[Agent Capability]]; this differs from an agent having capabilities through `hasCapability`, and the two relations are kept apart. A task points to subtasks through `hasSubtask`, which expresses hierarchical [[Task Decomposition]].

Task structure as a dependency graph is carried by the separate classes [[Task Node]] and `TaskDependency`. A task handed from one agent to another is a [[Task Delegation]]. An [[Agent Intent]] can be aligned with the task it authorises or motivates through `IntentAlignsWithTask`.[^3]

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl
[^3]: Semantic Agent Communication Community Group, “Security Binding Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/security-binding.ttl

