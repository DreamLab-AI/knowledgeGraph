A coordinate reference system (CRS) is a framework that defines how positions are described and measured on or near the Earth's surface, combining a datum, a coordinate system, and often a map projection. It enables consistent interpretation of spatial coordinates by anchoring them to a known model of the Earth. CRSs are essential for aligning geospatial data sets and for accurate location computations.

### Overview

- Without a declared CRS, a pair of numbers like a latitude and longitude is ambiguous because different datums place the same coordinate at slightly different physical points.
- Geographic CRSs express position as angular coordinates on an ellipsoid; projected CRSs flatten them onto a plane for mapping and measurement.
- CRSs are commonly identified by registry codes so that software can resolve their full definition unambiguously.
- Transforming data between CRSs is a routine and accuracy-critical operation in spatial pipelines.

### Key aspects

- Datum: the reference surface and orientation that ties coordinates to the real Earth.
- Coordinate system: the axes and units used to express position.
- Projection: the mathematical mapping from the curved surface to a flat plane, where applicable.
- Identifier: a registry code that uniquely names the CRS for interoperability.

### Mechanisms

- Coordinate transformation converts positions from one datum or projection to another.
- Reprojection re-renders data so that overlapping layers align spatially.
- Satellite positioning via [[GPS]] supplies coordinates that must be interpreted within a known CRS.
- Standards registries publish authoritative CRS definitions for consistent use.

### Applications

- Aligning multiple [[Geospatial Data]] layers in a [[Geographic Information System]].
- Anchoring augmented and [[Spatial Computing]] content to real-world locations.
- Performing accurate distance, area, and routing calculations.
- Exchanging location data across organisations using shared CRS identifiers.

### Provenance

