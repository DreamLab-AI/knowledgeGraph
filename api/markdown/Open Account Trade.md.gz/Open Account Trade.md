Open account trade is a sale in which the goods are shipped and delivered before payment is due, which in international sales is typically 30, 60 or 90 days.[^1][^2]

The US International Trade Administration says this option is advantageous to the importer in terms of cash flow and cost but is a risky option for an exporter, who bears substantial risk because the buyer could obtain the goods and default on payment.[^1] It says exporters can substantially mitigate the risk of non-payment by using trade finance techniques such as export credit insurance, factoring and standby letters of credit, and that the extension of credit by the seller to the buyer is more common abroad.[^1] UK Government guidance calls open account the simplest method of payment.[^2]

## Scale and oversight

A GOV.UK handbook on trade-based money laundering says open account accounts for approximately 80% of all international trade transactions, and that it is based on trust between exporter and importer, with almost no additional oversight by financial institutions.[^3] The handbook gives no date or source for the share, so it is a statement from a compliance document and not a statistic.

## Related finance

The Standard Definitions for Techniques of Supply Chain Finance say supply chain finance is typically applied to open account trade.[^4] See [[Supply Chain Finance]]. OpenStax links the two: it says most trade credit is offered to a company with an open account that has a credit limit up to which it can buy without paying cash up front.[^5] See [[Trade Credit]].

## Scope and distinctions

Open account is one of the methods covered at [[Trade Payment Method]]. It differs from [[Documentary Letter of Credit]], where a bank undertakes to pay against documents, and from cash in advance, where payment precedes shipment.[^1]

## What the sources do not establish

The ITA guide is written for exporters and the UK pages for exporters, so they describe the seller's risk rather than the buyer's. None of the opened sources gives a dated measure of the share of trade on open account, and none covers domestic open account sales.[^1][^2][^3]

[^1]: US International Trade Administration, “Trade Finance Guide: A Quick Reference for U.S. Exporters”, updated 2021 (PDF). https://www.trade.gov/sites/default/files/2021-03/Trade%20Finance%20Guide%20Updated%20030421%20FINAL.pdf
[^2]: UK Government (business.gov.uk), “Managing payment terms for export orders”. https://www.business.gov.uk/export-from-uk/learn/categories/funding-financing-and-getting-paid/get-paid/decide-when-get-paid-export-orders/
[^3]: UK Government (GOV.UK), “Trade-Based Money Laundering (TBML) handbook - Common techniques of trade-based money laundering”. https://www.gov.uk/guidance/trade-based-money-laundering-tbml-handbook/common-techniques-of-trade-based-money-laundering
[^4]: Global Supply Chain Finance Forum (ICC Banking Commission, BAFT, Euro Banking Association, Factors Chain International and ITFA), “Standard Definitions for Techniques of Supply Chain Finance”, 2016 (Internet Archive copy of the ICC PDF). https://web.archive.org/web/2023/https://cdn.iccwbo.org/content/uploads/sites/3/2017/01/ICC-Standard-Definitions-for-Techniques-of-Supply-Chain-Finance-Global-SCF-Forum-2016.pdf
[^5]: OpenStax, “19.2 What Is Trade Credit?”, Principles of Finance. https://openstax.org/books/principles-finance/pages/19-2-what-is-trade-credit

