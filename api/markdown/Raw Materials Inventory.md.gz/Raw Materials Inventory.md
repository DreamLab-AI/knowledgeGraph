Raw materials inventory is the stock of raw materials or purchased parts that an organisation holds before they enter production.[^1]

An open operations text lists raw materials or purchased parts among the very common types of inventory.[^1] Georgia Tech class notes describe raw materials as incoming to the organisation, as opposed to work in process, which is internal, and finished goods, which are outgoing.[^2] An open managerial accounting text defines raw materials inventory as the total cost of materials that will be used in the production process, and says it is usually made up of several accounts, with purchases increasing the inventory and raw materials sent into production reducing it.[^3]

## Role in production

According to the accounting text, in most production facilities the raw materials are moved from the raw materials inventory into the work in process inventory, where labour and overhead convert them into finished goods.[^4] It also says companies need raw materials inventory on hand to respond quickly to production needs, because management does not want to stop production to wait for raw materials to be delivered.[^4]

## Scope and distinctions

Raw materials inventory is the first stage in the sequence raw materials, work in process, finished goods; see [[Inventory Type]], [[Work-in-Progress Inventory]] and [[Finished Goods Inventory]]. The accounting text counts the cost of the materials, and the operations text describes the physical items.[^3][^1]

Spare parts, tools and supplies are kept as a separate type in the operations text, so they are not part of this page.[^1]

## What the sources do not establish

None of the sources discusses how much raw material to hold. Safety stock for purchased items is covered at [[Safety Stock]], and the order policies at [[Inventory Policy]].

[^1]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.1: Types of Inventory”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.01%3A_Types_of_Inventory
[^2]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf
[^3]: OpenStax (Rice University), Principles of Accounting, Volume 2: Managerial Accounting, “4.3 Use the Job Order Costing Method to Trace the Flow of Product Costs through the Inventory Accounts”. https://openstax.org/books/principles-managerial-accounting/pages/4-3-use-the-job-order-costing-method-to-trace-the-flow-of-product-costs-through-the-inventory-accounts
[^4]: OpenStax (Rice University), Principles of Accounting, Volume 2: Managerial Accounting, “4.2 Describe and Identify the Three Major Components of Product Costs under Job Order Costing”. https://openstax.org/books/principles-managerial-accounting/pages/4-2-describe-and-identify-the-three-major-components-of-product-costs-under-job-order-costing

