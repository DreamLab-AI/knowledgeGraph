A bill of materials (BOM) is a record of the components needed to make a product, and in manufacturing planning it identifies the finished product, its subassemblies and its components and the quantity of each.[^1][^2][^3]

Oracle's JD Edwards documentation says a bill of material identifies the manufacture of finished products (end items), subassemblies and components, and distinguishes planning, batch, percent and manufacturing bills.[^1] It describes a planning bill as one that facilitates master scheduling and material planning by categorising product features or options, with the ratio of each item taken from sales history.[^1] A University of North Carolina Wilmington module says a BOM specifies assemblies and subassemblies, parts and raw materials, and the amounts of each needed to make a single unit of finished product.[^2]

Gallego calls the product structure records bill of material records, and says they hold information on every item or assembly required to produce end items, such as part number, description, quantity per assembly, next higher assembly and lead times.[^3] He defines the level of an item as the maximum number of stages of assembly needed to get the item into an end product.[^3] Gershwin's MIT lecture shows the BOM as a tree whose top level is the end item, with items given a low-level code corresponding to the lowest level at which they appear, and says the BOM must be maintained as the product mix changes.[^4]

## Scope and distinctions

MRP walks back along each branch of the BOM from the due date of the end item, according to Gershwin, because more than one component may be needed at an operation.[^4] See [[Planning Master Data]] and [[Material Requirements Planning]].

## What the sources do not establish

These sources concern manufacturing planning. They do not cover engineering and manufacturing bill distinctions, software bills of materials or product data standards, which this page leaves aside.[^1][^2][^3][^4]

[^1]: Oracle, JD Edwards EnterpriseOne Applications Product Data Management documentation, “4 Setting Up Bills of Material”. https://docs.oracle.com/cd/E16582_01/doc.91/e15128/set_up_boms.htm
[^2]: Terry Janicki, University of North Carolina Wilmington, OPS 370 course module, “Materials Requirements Planning Module 11”. https://csbapp.uncw.edu/janickit/ops370/modules/Module11.pdf
[^3]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “Material Requirements Planning (MRP)”. http://www.columbia.edu/~gmg2/4000/pdf/lect_06.pdf
[^4]: Stanley B. Gershwin, MIT 2.853/2.854 Introduction to Manufacturing Systems lecture slides (MIT OpenCourseWare), “Material Requirements Planning”. https://ocw.mit.edu/courses/2-854-introduction-to-manufacturing-systems-fall-2016/4eec617bb52d64f4ea1bed6d9905bc00_MIT2_854F16_MatrialRequire.pdf

