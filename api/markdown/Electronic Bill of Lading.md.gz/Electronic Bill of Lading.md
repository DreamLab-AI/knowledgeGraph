An electronic bill of lading (eBL) is a bill of lading issued and transferred as an electronic record, in a setting where law or standards let that record do the work of the paper original.[^1][^2]

The Digital Container Shipping Association describes a standards-based electronic bill of lading applicable to both original bills of lading and seaway bills, and says that with original paper bills stakeholders must physically courier the originals to the importer.[^1] The association lists increased efficiency and fraud prevention among the benefits; these are its own claims and the other sources do not test them.[^1]

## Legal recognition in the UK

The Electronic Trade Documents Act 2023 treats information in electronic form as an electronic trade document if it would be a paper trade document on paper, and a reliable system is used to identify the document so it can be distinguished from copies, to protect it against unauthorised alteration and to secure that only one person can exercise control of it at any one time, among other requirements.[^3][^4] A person may possess, indorse and part with possession of an electronic trade document, and it has the same effect as the equivalent paper document.[^2] Section 3 came into force on 20 September 2023.[^2] A bill of lading is among the Act's examples of documents commonly used in trade.[^3]

## International model law

UNCITRAL's Model Law on Electronic Transferable Records aims to enable the legal use of electronic transferable records at home and across borders, and says transferable documents typically include bills of lading.[^5] It treats control as the functional equivalent of possession and is technology neutral, accommodating registries, tokens and distributed ledgers.[^5] See [[Distributed Ledger]]. The explanatory note records that delivery of goods typically requires surrender of a bill of lading, which is the function an electronic record must reproduce.[^6]

## Scope

See [[Bill of Lading]] for the document itself and [[Trade Document]] for the wider class.

## Evidence limits

No adoption figures are used. Sources are one industry body, one UK Act (sections 1 to 3) and two UNCITRAL texts; electronic signature and credential technologies named in the corpus links were not described in them.[^1][^5]

[^1]: Digital Container Shipping Association, Bill of Lading standard (web page). https://dcsa.org/standards/bill-of-lading
[^2]: UK Parliament, “Electronic Trade Documents Act 2023”, section 3. https://www.legislation.gov.uk/ukpga/2023/38/section/3
[^3]: UK Parliament, “Electronic Trade Documents Act 2023”, section 1. https://www.legislation.gov.uk/ukpga/2023/38/section/1
[^4]: UK Parliament, “Electronic Trade Documents Act 2023”, section 2. https://www.legislation.gov.uk/ukpga/2023/38/section/2
[^5]: United Nations Commission on International Trade Law, “UNCITRAL Model Law on Electronic Transferable Records (2017)”. https://uncitral.un.org/en/texts/ecommerce/modellaw/electronic_transferable_records
[^6]: United Nations Commission on International Trade Law, Model Law on Electronic Transferable Records, explanatory note (PDF). https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/mletr_ebook_e.pdf

