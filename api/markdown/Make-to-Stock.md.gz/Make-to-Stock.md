Make-to-stock is a production strategy in which goods are produced in anticipation of customer demand, usually from a sales forecast, and held in stock until orders arrive.[^1][^2]

An open operations management text says these products are generally made in larger amounts and put into storage to wait for customer orders, and that they are standardised rather than customised.[^1] Because goods are available when the customer places the order, lead times are short. Unit cost may be lower because of large production volumes, but there may be losses from forecast error, excess inventory, obsolescence and theft.[^1]

An MIT capstone gives the same picture: make-to-stock is suited to standardised, high-volume products with stable demand, enabling quick delivery but risking excess inventory and obsolescence.[^3] A queueing paper puts it as offering a lower possibility of customisation but less expensive products than make-to-order.[^4]

## Scope and distinctions

Make-to-stock is the stock-holding end of the order-trigger spectrum described at [[Production Strategy]]. Its counterpart is [[Make-to-Order]], and [[Assemble-to-Order]] holds components rather than finished goods.

Some texts treat make-to-stock and mass production as the same thing. One open text defines mass production as the practice of producing high volumes of identical goods at a cost low enough to price them for large numbers of customers, and calls it the make-to-stock strategy, with goods made in anticipation of future demand and kept in inventory for later sale.[^2] This corpus keeps [[Mass Production]] as a production system type and make-to-stock as a strategy; the two commonly occur together but the sources do not require it.

## What the sources do not establish

None of the sources gives measures for when stock-holding beats order-driven production. The MIT capstone reports that hybrid arrangements are common, so a single product family can be held to stock for some customers and made to order for others.[^3]

[^1]: Engineering LibreTexts (Introduction to Operations Management, 1st Ed.), “6.2: Make-to-order and Make-to-stock”. https://eng.libretexts.org/Under_Construction/Purgatory/Introduction_to_Operations_Management_1st_Ed./06:_Process_Design/6.02:_Make-to-order_and_Make-to-stock
[^2]: eCampusOntario Pressbooks (Introduction to Canadian Business), “Operations Management”. https://ecampusontario.pressbooks.pub/bus108g/chapter/opsmanagement/
[^3]: MIT Center for Transportation and Logistics (Pooja Kashyap, capstone), “Optimizing Hybrid Assembly Strategies in Supply Networks: Evaluation of Make-to-Stock and Make-to-Order Models”. https://ctl.mit.edu/sites/default/files/documents/optimizing-hybrid-assembly-strategies-in-supply-networks-evaluation-of-make-to-stock-and-make-to-order-models-capstone.pdf
[^4]: Production (Associação Brasileira de Engenharia de Produção), Ghalehkhondabi and Suer, via Redalyc, “Production line performance analysis within a MTS/MTO manufacturing framework: a queueing theory approach”. https://www.redalyc.org/journal/3967/396754754007/html/

