The International Organisation for Standardisation (ISO) is an independent, non-governmental international body comprising the national standards institutes of 167 countries, responsible for developing and publishing voluntary international standards across virtually every sector of industry, technology, and commerce. ISO standards are produced by technical committees composed of experts nominated by member bodies and are adopted through a consensus-based process requiring defined levels of national body approval. ISO standards span quality management, environmental management, information security, robotics, artificial intelligence, financial services, and hundreds of other domains. Published standards carry normative authority in many regulatory and procurement frameworks worldwide.

### Overview

- ISO was founded in 1947 in Geneva as successor to the interwar ISA (International Federation of the National Standardizing Associations), inheriting a mandate to create a universal technical language for post-war industrial reconstruction and international commerce.
- The organisation is formally independent of governments but maintains close liaison relationships with intergovernmental bodies including the WTO, UN agencies, and regional blocs. ISO standards are referenced within WTO Technical Barriers to Trade (TBT) agreements as the preferred basis for national regulation.
- Membership is structured at three levels: full member (one per country, with full voting rights), correspondent member (developing countries, observation rights), and subscriber member (very small economies, reduced fees). The 167 full members include ANSI (USA), BSI (UK), DIN (Germany), AFNOR (France), CEN (Europe), SAC (China), and BIS (India).
- ISO does not itself enforce compliance — standards are voluntary by design. Their normative authority arises when governments incorporate them into legislation, procurement mandates, or trade agreements, or when industry bodies require them for certification schemes.

### Key Components

- **Technical Committees (TCs)** — ISO operates approximately 800 technical committees and subcommittees. Each TC is responsible for a defined domain (e.g. TC 37 for terminology, TC 176 for [[Quality Management]], TC 262 for [[Risk Management]]). TC members are national body delegations that include industry, academia, and government experts.
- **[[ISO/IEC JTC 1]]** — The Joint Technical Committee with the [[IEC]] handles all information technology standards, with subcommittees covering AI (SC 42), cloud computing (SC 38), cybersecurity (SC 27), and data management (SC 32).
- **[[ISO High Level Structure]] (HLS / Annex SL)** — Introduced with ISO/IEC Directives Part 1 Supplement, the HLS provides a common framework and identical core text for all [[Management System Standard]] documents, enabling integrated implementation of ISO 9001, ISO 14001, ISO 45001, and ISO/IEC 27001 within a single management system.
- **Standards Lifecycle** — A standard progresses through: New Work Item Proposal → Working Draft → Committee Draft → Draft International Standard → Final Draft International Standard → International Standard → Periodic Review (every five years).
- **[[National Standards Body]]** — Each ISO member body (e.g. BSI, ANSI, DIN) convenes mirror committees that translate ISO positions into national votes and adopt published ISO standards as national standards (e.g. BS EN ISO, DIN EN ISO).
- **[[Conformity Assessment]]** — ISO/IEC 17000-series standards define the framework for testing, inspection, and certification schemes that verify conformance to ISO standards. Certification bodies are accredited by national [[Accreditation Body]] members of IAF/ILAC.

### Major Standards Families

- **[[Quality Management]] — ISO 9001** — The world's most widely deployed management system standard; provides a process-based framework for customer satisfaction and continual improvement. Used by over 1 million certified organisations globally.
- **Environmental Management — ISO 14001** — Specifies requirements for an [[Environmental Management System]], integrated with ISO 9001 via the HLS.
- **Information Security — [[ISO/IEC 27001]]** — Specifies requirements for an information security management system (ISMS); the globally dominant information security certification standard, referenced heavily in financial regulation and [[Cybersecurity Framework]] design.
- **AI Management — [[ISO/IEC 42001]]** — The first international management system standard for AI, published 2023; provides requirements and guidance for organisations developing, deploying, or using AI systems, with explicit linkage to [[AI Governance]] and the [[EU AI Act]].
- **AI Risk — ISO/IEC 23894** — Guidance on [[Risk Management]] for AI systems, complementing ISO/IEC 42001 and aligned with ISO 31000.
- **Robotics — ISO 10218 / ISO 13482** — ISO 10218 covers safety requirements for industrial robots; ISO 13482 addresses personal care robots. Both are key normative references for [[Robotics]] safety regulation.
- **Financial Messaging — ISO 20022** — The dominant global standard for financial messaging, underpinning real-time gross settlement (RTGS), payment infrastructure modernisation, and cross-border payment interoperability.
- **Supply Chain — ISO 28000** — Specifies requirements for a security management system for the [[Supply Chain Management]] context.
- **Occupational Health — ISO 45001** — Requirements for occupational health and safety management systems, replacing OHSAS 18001.
- **Energy Management — ISO 50001** — Framework for organisations to establish energy performance improvement processes.

### Applications and Use Cases

- **Regulatory harmonisation** — Governments and regional bodies (EU, ASEAN, African Union) reference ISO standards in directives and regulations to avoid creating unique national technical requirements that would fragment global trade. The EU Machinery Regulation and Radio Equipment Directive both rely on harmonised EN ISO standards.
- **Procurement and supply chain qualification** — ISO 9001 certification is a default supply-chain entry requirement across aerospace, automotive, defence, and healthcare sectors. ISO/IEC 27001 is mandated or strongly preferred in financial services and public sector IT procurement.
- **AI regulation compliance** — ISO/IEC 42001 certification provides organisations with a structured pathway to demonstrating conformance with AI system governance requirements under the EU AI Act and comparable national AI regulations.
- **Cross-border financial infrastructure** — ISO 20022 adoption by SWIFT, TARGET2, and national RTGS systems enables structured, rich-data payment messaging; critical for anti-money-laundering screening and [[Supply Chain Management]] finance.
- **Cybersecurity assurance** — ISO/IEC 27001 underpins national cybersecurity strategies and sector-specific frameworks (NIS2 Directive, UK Cyber Essentials Plus, Singapore MAS TRM).
- **Interoperability in emerging technology** — ISO/IEC JTC 1 SC 42 is developing standards for AI terminology, bias, explainability, and trustworthiness that will shape interoperability between AI systems across jurisdictions.
- **Healthcare and medical devices** — ISO 13485 (quality management for medical devices) and ISO 14971 (risk management for medical devices) are referenced in FDA and EU MDR regulatory pathways.

### Standards and Governance Context

- ISO standards are produced under the ISO/IEC Directives, which govern the structure, drafting, and balloting procedures. The Directives are revised periodically to incorporate new drafting conventions, and the HLS / Annex SL framework is embedded within them.
- ISO maintains formal liaison with ITU (International Telecommunication Union), OECD, UNCTAD, and WTO. This liaison network ensures ISO standards are coherent with intergovernmental policy frameworks, especially in areas such as AI, climate, and digital trade.
- ISO Publicly Available Specifications (PAS), Technical Specifications (TS), and Technical Reports (TR) provide pre-normative or informative outputs at earlier stages of technology maturity — relevant for rapidly evolving fields such as quantum computing, blockchain, and AI trustworthiness.
- The ISO TC 307 committee addresses [[Blockchain]] and distributed ledger technology standards, including ISO 22739 (blockchain terminology) and ISO 23257 (reference architecture), linking ISO governance to [[Distributed Systems]] and [[Distributed Collaboration]] domains.
- ISO SC 42 (AI) directly interfaces with the [[EU AI Act]] harmonisation process; EU Standardisation Request M/623 tasks CEN/CENELEC and ISO/IEC with producing harmonised standards that provide presumption-of-conformity pathways for high-risk AI systems.
- CASCO (ISO Committee on Conformity Assessment) develops [[Conformity Assessment]] standards (ISO/IEC 17000 series) and coordinates with IAF (International Accreditation Forum) and ILAC (International Laboratory Accreditation Cooperation) to maintain the global accreditation infrastructure.

### Current Landscape (2026)

- ISO's headline governance move of this period is ISO/IEC 42001:2023, the world's first certifiable AI management system standard (developed with IEC via JTC 1/SC 42), which through 2024-2026 became the reference framework organisations use to operationalise responsible AI governance on the familiar Plan-Do-Check-Act / Annex SL backbone.
- The AI governance family expanded around it: ISO/IEC 42005:2025 (AI system impact assessment) and ISO/IEC 42006 (requirements for bodies certifying AI management systems) matured the certification ecosystem, with ISO/IEC 42001 and 42005 now marketed as a paired responsible-AI toolkit.
- ISO/IEC 42001 is increasingly positioned as the practical "how" companion to the EU AI Act's "what" — commentary through 2025 pairs it with the Act as GPAI obligations began applying from 2 August 2025 and earlier prohibitions took effect in February 2025.
- On sustainability governance, ISO and the UNDP are developing ISO/UNDP 53001, a management system standard for embedding the UN SDGs into organisational governance, expected mid-2026 and building on the ISO/UNDP PAS 53002:2024 guidelines; it was profiled at COP30 as supporting the Baku to Belem Roadmap.
- Following the 2021 London Declaration, ISO amended all new and existing management system standards to require consideration of climate change, a change that propagated across the MSS catalogue during 2024.
- Governance leadership shifted: Sung Hwan Cho (Republic of Korea) served as ISO President for 2024-2025, and Khaled Soufi (Egypt) took over as President for a three-year term from 1 January 2026, while Sergio Mujica continues as Secretary-General steering the decade-long ISO Strategy 2030 (AI and climate as core priorities, ~173 member-country input).
- Open challenges as of 2026 include enabling equitable participation by developing countries in standards development, keeping standards current against fast-moving AI and quantum technology, and closing the gap between voluntary certification and hardening regulatory mandates.

### References

- 1. ISO/IEC (2023-2025). ISO/IEC 42001 AI management systems (overview and explainer). https://www.iso.org/artificial-intelligence/ai-management-systems
- 2. ISACA (2025). ISO/IEC 42001 and EU AI Act: A Practical Pairing for AI Governance. https://www.isaca.org/resources/news-and-trends/industry-news/2025/isoiec-42001-and-eu-ai-act-a-practical-pairing-for-ai-governance
- 3. ISO (2025). Responsible AI governance and impact standards package (ISO/IEC 42001 and ISO/IEC 42005:2025). https://www.iso.org/publication/PUB200420.html
- 4. UNDP (2025). UNDP and ISO Advance New Global Partnership to Build 'Impact Economies' at COP30 (ISO/UNDP 53001, expected mid-2026). https://sdgfinance.undp.org/news-events/undp-and-iso-advance-new-global-partnership-build-impact-economies-cop30
- 5. ISO (2024-2026). Principal Officers (Sung Hwan Cho, Khaled Soufi, Sergio Mujica). https://www.iso.org/principal-officers.html

### Provenance

