Advanced planning and scheduling (APS) software is planning software, in the Petropoulos handbook described as advanced planning systems, that integrates different modules and algorithms to tackle real-world planning problems.[^1]

Glock and Zheng's handbook section says addressing the entire planning task at once is often not possible, and that advanced planning systems provide a framework that integrates modules and algorithms.[^1] As decision support systems, they extract data from enterprise resource planning systems, generate high-quality solutions and relay decisions back to the ERP for execution.[^1]

## Structure and vendors

Modules of an advanced planning system operate on constructional and organisational hierarchies, addressing complex planning problems by decomposing them into simpler sub-problems and coordinating across distinct functional areas.[^1] The handbook says numerous vendors offer such solutions, including Oracle, SAP, i2 and AspenTech.[^1] Scheduling, the second half of the name, appears in the Zaidi, Amanton and Sanlaville classification as part of the planning class of logistics information systems.[^2]

## Scope and distinctions

This page sits beside [[Supply Chain Planning System]], the broader category. The handbook treats the system as a layer that reads from and writes back to enterprise resource planning, so it is not itself the system of record.[^1] See [[Enterprise Resource Planning]].

## What the sources do not establish

Evidence is thin. The description rests on one handbook section, and no dictionary or standards-body definition was reachable. The sources do not say that these systems schedule against finite capacity or constraints, which the catalogue note suggests, so the page does not claim it. They also give no results on how well the systems perform, and the classification preprint mentions scheduling only as a member of the planning class.[^1][^2]

[^1]: Fotios Petropoulos et al., “Operations & Supply Chain Management: Principles and Practice”, arXiv:2503.05749, section on planning problems by Christoph H. Glock and Ting Zheng. https://arxiv.org/pdf/2503.05749
[^2]: Fares Zaidi, Laurent Amanton and Eric Sanlaville, “Towards a Novel Cooperative Logistics Information System Framework”, arXiv:1905.00687. https://arxiv.org/pdf/1905.00687

