
A task node is a node in a task dependency graph, the unit of work that the graph orders. The Agent Ontology declares it as `TaskNode`.[^1][^2]

The property `hasDependency`, whose domain and range are both Task Node, "represents a dependency between task nodes". The same ordering can be reified as a [[Task Dependency]], so a dependency may be stated directly between nodes or as an object that can be annotated.[^1]

A node stands for an [[Agent Task]], and visionGraph relates the two. The task graph is intended to be a directed acyclic graph, the essential structure of a task DAG, so a node never depends on itself through any chain of dependencies.[^2] visionGraph places Task Node under [[Dependency Graph]], as the vertex of that graph.

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl

