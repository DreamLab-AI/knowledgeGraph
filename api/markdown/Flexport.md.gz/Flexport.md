Flexport is a freight forwarder and customs broker that sells its services through a software platform. Flexport describes itself as a freight forwarder, customs broker, and fulfillment provider with the infrastructure and expertise to move goods across 135 countries, a company claim that the page makes about itself.[^1]

## Independent description

CNBC reported in 2022 that founder and CEO Ryan Petersen started Flexport in 2013 because he figured there had to be a better way to manage the flow of goods that get put on cargo ships, planes, trucks and railroads and transported all over the world.[^2] It added that the company's freight forwarding and brokerage services are in the cloud.[^2]

CNBC added that Flexport had more than 10,000 clients and suppliers in 112 countries and had doubled its revenue the previous year; these are the 2022 figures reported by the press and are not current.[^2]

## Role in the supply chain

Flexport is a [[Freight Forwarder]] in this vault, as both sources use the freight forwarding label, and it also acts as a customs broker, which this vault treats as a separate role (see [[Customs Broker]]).[^1][^2] See also [[Machine Learning]].

## What the sources do not establish

Sources do not show whether Flexport holds the licences that its forwarding and brokerage activity requires, and they give no figures on revenue, staff or shipments that were checked independently. The CNBC article is a business-press profile from 2022 and the company page is promotional in tone. Neither source states a headquarters. The 135-country figure and similar numbers on the company page are the company's own.[^1][^2]

[^1]: Flexport, “About Flexport”. https://www.flexport.com/about
[^2]: CNBC, “Flexport: 2022 CNBC Disruptor 50”. https://www.cnbc.com/id/107048090

