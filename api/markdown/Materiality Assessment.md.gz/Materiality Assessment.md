Materiality assessment is the structured process by which an organisation identifies and prioritises the environmental, social and governance topics that are significant enough to influence its decisions or the decisions of its stakeholders. It establishes which sustainability matters warrant disclosure, management attention and resource allocation. Double materiality extends the concept to consider both financial impact on the firm and the firm's impact on society and the environment.

- Materiality assessment is the structured process by which an organisation identifies and prioritises the [[ESG]] topics significant enough to influence its decisions or those of its stakeholders.
- It determines which sustainability matters warrant [[Disclosure]], management attention and resource allocation.
- The concept of [[Double Materiality]] broadens the lens to capture both the financial impact on the firm and the firm's impact on the wider world.
- It sits at the heart of credible [[Sustainability Reporting]] and informs [[Risk Management]] priorities.

### Overview

- Materiality is borrowed from financial accounting, where an item is material if its omission or misstatement could influence the economic decisions of users. In sustainability practice the principle is extended across a far wider set of impacts and dependencies.
- A materiality assessment typically begins with a long list of candidate topics drawn from sector frameworks, peer benchmarking and regulatory expectations. These are then evaluated against two axes: significance to the business and significance to stakeholders.
- The output is usually visualised as a materiality matrix that plots topics by importance, guiding where the organisation should focus disclosure and action.
- Regulators and standard setters have increasingly converged on the double materiality view, requiring organisations to report both how sustainability issues affect enterprise value and how the enterprise affects people and the planet.

### Key aspects

- Topic identification drawing on standards, sector guidance and stakeholder input.
- Stakeholder mapping and engagement to capture external perspectives.
- Impact and dependency analysis across the value chain.
- Prioritisation against financial and impact thresholds.
- Documentation and assurance to support audit and disclosure.
- Periodic refresh to reflect changing risks and stakeholder concerns.

### Mechanisms

- Surveys, interviews and workshops with internal and external stakeholders.
- Scenario analysis to test the salience of climate and transition risks.
- Quantitative scoring models that combine likelihood, magnitude and stakeholder concern.
- Cross-referencing against [[ISSB]], [[TCFD]] and sector taxonomies.

### Applications

- Defining the content boundary of annual sustainability and ESG reports.
- Prioritising decarbonisation, social and governance initiatives.
- Informing board oversight and enterprise risk registers.
- Aligning corporate strategy with stakeholder expectations and regulatory disclosure regimes.

### Provenance

