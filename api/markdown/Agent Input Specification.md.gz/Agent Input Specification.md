
An agent input specification describes what an agent accepts as input, declared as `InputSpec` in the agent module of the Agent Ontology.[^1] The Agent Ontology declares the class without a definition; this one follows from its position. visionGraph places it under [[Data Schema]] and as part of an [[Agent Operational Profile]], which reaches it through `input`.

It is a declared contract for the data an agent receives, separate from the [[Agent Trigger]] that starts the agent. A caller reads it to learn what to send; the agent's runtime uses it to validate what arrives. The shape of the schema it points to is chosen by the implementer, so it can be JSON Schema, a SHACL shape or any other form.

Its counterpart on the other side of the profile is [[Agent Output Specification]]. Both describe the type of data in general, whereas the [[Input State]] of an [[Execution Context]] records the actual input of one run.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

