Container shipping, also called liner shipping, is the provision of regular, scheduled services for the carriage of cargo by container.[^1]

The European Commission, in a 2017 merger decision recalling its earlier practice, says this market can be distinguished from non-liner shipping, such as tramp and specialised transport, because of the regularity and frequency of the service. It adds that the use of container transportation separates it from other non-containerised transport, such as bulk cargo.[^1] The World Bank describes container shipping lines as operating liner services on fixed schedules, based on fixed port turnaround times.[^2]

## Connectivity and ships

The World Bank notes that the Liner Shipping Connectivity Index published by UNCTAD indicates a port's position within the liner shipping network, and that the index is generated from container ship deployment data with six components: weekly calls, competing carriers, services, the size of the largest ship that calls, deployed container carrying capacity and the number of other ports connected through direct services.[^2] The Glossary for transport statistics defines a container ship as a ship fitted throughout with fixed or portable cell guides for the exclusive carriage of containers.[^3] USC Sea Grant says container vessels are often described by the number of boxes they can carry, in twenty-foot equivalent units (TEU), and have grown from 2,000 TEU in early days to 24,000 TEU for the newest.[^4]

## Related markets

The Commission records a possible narrower market for refrigerated goods, limited to reefer containers or including conventional reefer vessels, and says sea freight forwarders are among the most important customers of container liner shipping companies.[^1]

## Scope and distinctions

Container Shipping is a form of [[Ocean Freight]]. Related pages are [[Shipping Container]], [[Freight Containerisation]], [[Reefer Container]] and [[Freight Service]].

## What the sources do not establish

Sources opened here give no market shares, alliance structures or freight rates, and the UNCTAD publications could not be opened. The Commission's wording defines a competition-law market, not a general term.

[^1]: European Commission, Case M.8594 - COSCO SHIPPING / OOIL, Commission decision of 5 December 2017 (public version). https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX%3A32017M8594
[^2]: World Bank, “The Container Port Performance Index 2020: A Comparable Assessment of Container Port Performance”, 2021. https://documents1.worldbank.org/curated/en/099645006082227512/pdf/P1758330e0760804c082810d112b2854b09.pdf
[^3]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^4]: University of Southern California Sea Grant (Fawcett), “2. The Box: An Inside Look at the Shipping Container”, 2020. https://dornsife.usc.edu/uscseagrant/2020/05/29/2-the-box-an-inside-look-at-the-shipping-container/

