Property rights are the legally and institutionally recognised entitlements that determine who may use, transfer, exclude others from, or derive value from a resource — whether physical, digital, or intellectual. They form the foundational incentive structure of market economies, specifying the bundle of rights (usus, fructus, abusus) attached to an asset. In digital and blockchain contexts, property rights extend to on-chain ownership records, smart-contract-enforced exclusivity, NFT-based title deeds, and virtual land parcels, requiring mechanisms for interoperability, provenance tracking, and dispute resolution that operate across jurisdictions.

### Overview

- Property rights define the relationship between agents (persons, organisations, algorithms) and scarce resources. They are enforceable entitlements that create incentives for investment, maintenance, and exchange.
- The concept originates in [[Institutional Economics]] (Coase, Alchian, Demsetz) where well-defined rights reduce transaction costs and enable efficient resource allocation.
- In digital settings, the absence of natural scarcity requires artificial enforcement mechanisms — copy protection, licensing, and increasingly [[Blockchain]]-based provenance chains.
- The transition from analogue to digital property rights creates new challenges: jurisdiction ambiguity, copy-perfect reproduction, pseudonymous ownership, and [[Interoperability]] across platforms.
- [[Decentralised Finance]] and the broader [[Digital Economy]] depend on robust property-rights primitives to function without a central enforcing authority.

### Key Components

- **Bundle of Rights** — the composite entitlement comprising use, income, transfer, and exclusion rights; partial bundles give rise to licences, easements, and usufruct.
- **Title and Registration** — mechanisms (land registries, company share registers, [[Land Registry]] systems, [[NFT]] records) that make ownership legible and transfer auditable.
- **[[Smart Contract]]** — self-executing code on a [[Blockchain]] that automates enforcement of property conditions such as royalty payments, licence expiry, and conditional transfers.
- **[[NFT]] (Non-Fungible Token)** — a blockchain-native title deed that attaches a unique identifier to a digital or physical asset, enabling provenance tracking and peer-to-peer transfer.
- **[[Tokenization]]** — the process of representing fractional ownership of an asset as fungible or semi-fungible tokens, enabling divisible property rights over high-value assets.
- **[[Cryptographic Proof]]** — zero-knowledge proofs, digital signatures, and hash-based commitments that verify ownership claims without revealing sensitive information.
- **[[Identity Management]]** — decentralised identifiers (DIDs) and verifiable credentials that bind ownership records to authenticated legal persons or organisations.
- **[[Dispute Resolution]]** — on-chain arbitration protocols, decentralised courts (e.g. Kleros), and traditional legal systems that adjudicate competing claims.
- **[[Consensus Mechanism]]** — the distributed agreement protocol (PoW, PoS, BFT) underpinning the ledger on which property records are stored, determining finality and immutability guarantees.

### Mechanisms of Enforcement

- **Exclusion** — the right-holder can prevent others from accessing or using the resource; technically implemented through [[Access Control]], licence keys, or blockchain-gated assets.
- **Transfer** — rights can be sold, gifted, inherited, or licensed; on-chain this is a signed transaction recorded immutably on the ledger.
- **Collateralisation** — tokenised property rights can be pledged as collateral in [[Decentralised Finance]] lending protocols (e.g. MakerDAO, Aave), creating capital efficiency.
- **Royalty Streams** — [[Smart Contract]] logic can embed perpetual royalty obligations into an asset's transfer history, automatically compensating original [[Creator Economy]] participants.
- **Fractional Ownership** — via [[Tokenization]], a single asset (real estate, artwork, IP) can be divided into tradeable fractions, democratising access to high-value holdings.

### Applications and Use Cases

- **Virtual Real Estate** — platforms such as Decentraland and The Sandbox use [[NFT]]-backed land parcels to grant owners exclusive development and monetisation rights within [[Virtual Land]] environments.
- **Music and Creative IP** — on-chain licensing protocols (Royal, Catalog) embed property rights directly into audio files, enabling direct fan investment and automated royalty distribution to support the [[Creator Economy]].
- **Physical Asset Tokenization** — real-world assets (real estate, commodities, art) are tokenised on [[Blockchain]] to enable fractional ownership, improving liquidity via [[Tokenization]].
- **Supply Chain Provenance** — property rights over goods are tracked through production and distribution via [[Supply Chain Management]] solutions, reducing counterfeiting and fraud.
- **AI-Generated Content** — emerging frameworks tackle ownership of works produced by [[AI-Generated Content]] systems, where authorship, training-data rights, and output ownership intersect novel legal questions.
- **Data Ownership** — [[Data Sovereignty]] frameworks give individuals property-like rights over their personal data, enabling consent-based monetisation and portability.
- **Decentralised Autonomous Organisations** — [[Decentralised Autonomous Organisation]] governance tokens represent property rights over treasury assets and protocol parameters, exercised through on-chain voting.
- **Cross-border Transactions** — [[Regulatory Compliance]] frameworks (MiCA in the EU, proposed US stablecoin bills) are establishing jurisdictional clarity for digital property transfers.

### Theoretical Foundations

- **Coase Theorem** — when property rights are well-defined and transaction costs are low, parties bargain to efficient outcomes regardless of initial allocation; forms the theoretical justification for strong property rights in economics.
- **Demsetz Theory of Rights** — property rights emerge to internalise externalities; digital property rights arise as the costs of excluding non-payers fall through cryptographic enforcement.
- **Ostrom's Commons** — Elinor Ostrom demonstrated that common-pool resources can be sustainably governed without privatisation, providing the theoretical basis for [[Commons]]-based digital governance as an alternative to strict property rights.
- **Lockean Proviso** — the labour theory of property (Locke) undergirds creators' claims to their digital outputs, but is complicated when [[AI-Generated Content]] blurs the human-labour origin of works.
- **Institutional Economics** — [[Governance]] frameworks (North, Williamson) stress that property rights must be embedded in credible enforcement institutions, whether state courts or decentralised [[Consensus Mechanism]] networks.

### Standards and Regulatory Context

- **ERC-721 / ERC-1155** — Ethereum token standards defining the interface for non-fungible and semi-fungible tokens that encode property title on the EVM; widely implemented across [[NFT]] ecosystems.
- **ERC-2981 (Royalty Standard)** — specifies on-chain royalty information, enabling marketplaces to honour creator rights automatically.
- **W3C Verifiable Credentials** — a standard for expressing digital ownership claims in a portable, cryptographically verifiable format, binding [[Identity Management]] to property records.
- **MiCA (Markets in Crypto-Assets Regulation)** — EU regulation (2024 implementation) establishing legal treatment of crypto-asset property rights within the single market, a key [[Regulatory Compliance]] landmark.
- **UNIDROIT Digital Assets Principles (2023)** — international private-law principles for the treatment of digital assets in insolvency, conflict of laws, and transfer, providing cross-border property-rights clarity.
- **WIPO Internet Treaties** — the WIPO Copyright Treaty (WCT) and WIPO Performances and Phonograms Treaty (WPPT) extend intellectual property rights to digital transmissions, foundational to [[Intellectual Property Rights Framework]].
- **ISO/TC 307** — standards committee developing blockchain and distributed ledger technology standards relevant to digital property record keeping.

### Contrasts and Tensions

- **Property Rights vs [[Open Access]]** — strict exclusion rights can generate deadweight loss when marginal cost of access is zero (e.g. digital goods); open licences (Creative Commons) balance creator incentives with broad access.
- **Property Rights vs [[Commons]]** — Ostrom's polycentric governance shows that collective stewardship can outperform privatised property for rivalrous-but-excludable resources.
- **On-chain vs Off-chain Enforcement** — smart-contract enforcement is deterministic but lacks equitable discretion; real-world courts offer flexibility but require bridging mechanisms (oracles, legal wrappers) to interact with [[Blockchain]] records.
- **Interoperability vs Sovereignty** — [[Interoperability]] across metaverse platforms may require standardised property representations that conflict with platform-specific competitive interests.

### Provenance

