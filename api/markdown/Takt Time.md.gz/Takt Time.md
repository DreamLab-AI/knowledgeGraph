Takt time is a calculation of the available production time divided by customer demand.[^1]

The Lean Enterprise Institute gives a worked example: a widget factory operating 480 minutes per day, with customers demanding 240 widgets per day, has a takt time of two minutes. It says the purpose is to match production precisely with demand, and calls takt the heartbeat of a lean production system.[^1] An open textbook describes it as a calculated value that determines the rate at which a firm needs to process its product to meet customer demand, also known as the drum beat of the operation.[^2]

## History

The Institute says takt was first used as a production management tool in the German aircraft industry in the 1930s, where it was the interval at which aircraft were moved ahead to the next production station, and that the word is German for a precise interval of time such as a musical meter. It says the concept was widely used within Toyota in the 1950s and throughout the Toyota supply base by the late 1960s.[^1]

## Scope and distinctions

Takt time is the required pace; cycle time is the actual pace. The open textbook defines cycle time as the rate at which an operation is actually producing each unit, measured as the time between completion of each unit, and contrasts it with the calculated takt time.[^2]

Line balancing literature uses cycle time differently. A university journal article defines cycle time as the maximum time allowed for any task at any workstation, gives the formula cycle time equals total time available divided by demand for the period, and describes it as the time between units.[^3] That is the same calculation the Institute names takt time. The sources do not comment on the difference, so this corpus keeps takt time for the calculation as lean sources use it and treats the line balancing usage under [[Line Balancing]].

Takt time is one of the three operating elements of just-in-time, with the pull system and continuous flow; see [[Just-in-Time Production]].[^4] It sits within [[Lean Production]] and is related to [[Kanban]].

## What the sources do not establish

No source gives guidance on setting takt for high-mix, low-volume operations, and the only review interval mentioned is Toyota's, which the Institute says is typically monthly for a process.[^1]

[^1]: Lean Enterprise Institute, “Takt Time (Lean Lexicon)”. https://www.lean.org/lexicon-terms/takt-time/
[^2]: Business LibreTexts (Introduction to Operations Management, NWTC), “6.5: Some important "Times" to be familiar with”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/06:_Process_Design/6.05:_Some_important_Times_to_be_familiar_with-
[^3]: University of North Carolina Asheville and Mars Hill University (Lovejoy-Henkel, Lee, Parsons and Yearout), Industrial and Systems Engineering Review 4(1), 2016, “Systematic Pedagogy to Line Balancing with EXCEL”. https://westpointpressjournals.westpoint.edu/index.php/iser/article/download/34/pdf_12/260
[^4]: Lean Enterprise Institute, “Just-in-Time Production (Lean Lexicon)”. https://www.lean.org/lexicon-terms/just-in-time-production/

