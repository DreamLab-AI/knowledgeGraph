The Hyperledger Foundation is an open-source collaborative initiative hosted by the Linux Foundation, founded in December 2015, that stewards a portfolio of enterprise-grade distributed ledger frameworks, identity toolkits, and interoperability libraries. Its flagship projects include Hyperledger Fabric (a modular permissioned DLT with pluggable consensus and chaincode-based smart contracts), Hyperledger Besu (an Ethereum-compatible client for public and private enterprise networks), Hyperledger Aries (a decentralised identity and verifiable credentials stack), and Hyperledger Cacti (a cross-ledger interoperability framework). The Foundation operates under an open-governance model with a Technical Steering Committee, project lifecycle governance (Incubation, Graduated, Dormant), and membership tiers spanning major technology vendors, financial institutions, and government bodies worldwide.

### Overview

- Founded in 2015 as a Linux Foundation project, Hyperledger emerged from the recognition that enterprise use-cases — trade finance, supply chain provenance, healthcare data exchange — required [[Permissioned Blockchain]] infrastructures with deterministic finality, auditability, and participant identity, properties absent from public proof-of-work chains.
- The Foundation acts as a neutral convener: it hosts code, governs project lifecycles (Incubation → Graduated → Dormant), organises working groups, and ensures intellectual-property clarity under Apache 2.0 licensing.
- Membership spans technology companies (IBM, Intel, SAP), financial institutions (JPMorgan, Deutsche Bank, American Express), consulting firms (Accenture, Deloitte), and national governments, giving the Foundation unusual breadth for an open-source body.
- Unlike a single product, Hyperledger is a federated ecosystem: each sub-project has its own maintainer community, Technical Steering Committee representation, and release cadence.
- The Foundation's work is closely aligned with standards from [[World Wide Web Consortium]] (DIDs, Verifiable Credentials) and the [[Internet Engineering Task Force]] (TLS, gRPC transport) to maximise interoperability.

### Key Components

- **Hyperledger Fabric**
  - The flagship [[Permissioned Blockchain]] framework; modular architecture with pluggable ordering services (Raft-based since Fabric 2.x), endorsement policies, and chaincode ([[Smart Contracts]]) executing in Docker containers or Kubernetes pods.
  - Channels provide data segregation: only channel members see transaction data, enabling multi-tenant deployments on shared infrastructure.
  - The execute-order-validate (EOV) transaction flow separates simulation from ordering, allowing higher throughput than traditional order-execute architectures.
  - Private data collections (PDC) allow a subset of channel members to share off-chain data with on-chain hashes, supporting confidential [[Supply Chain Blockchain]] workflows.
- **Hyperledger Besu**
  - A full [[Ethereum]] client written in Java, supporting public Mainnet, testnets, and permissioned private networks.
  - Consensus options include IBFT 2.0, QBFT, and Clique for private networks; Proof of Stake on public Ethereum post-Merge.
  - Bridges enterprise organisations into the broader Ethereum ecosystem while retaining permissioning controls via enterprise plugins (EEA compliant).
  - Relevant to organisations needing [[Smart Contracts]] compatible with the Ethereum Virtual Machine (EVM) in a compliant, access-controlled deployment.
- **Hyperledger Aries**
  - A [[Decentralised Identity]] and [[Verifiable Credential]] framework implementing W3C DID specifications and the DIDComm v2 messaging protocol.
  - Provides agent frameworks, wallets, and credential exchange protocols enabling [[Self Sovereign Identity]] without central identity providers.
  - Underpins real-world deployments for national digital identity (British Columbia's Verifiable Organisations Network), academic credentialing, and healthcare credentialing.
  - Works alongside Hyperledger AnonCreds (now a standalone project) for privacy-preserving ZKP-based credential presentation.
- **Hyperledger Cacti**
  - A cross-ledger interoperability framework (merger of Hyperledger Cactus and Weaver), enabling asset and data transfers between heterogeneous [[Distributed Ledger Technology]] networks.
  - Supports Fabric, Besu, Corda, and UTXO-based ledgers via pluggable connector architecture.
  - Addresses one of enterprise blockchain's core challenges: siloed ledger ecosystems that cannot natively communicate.
- **Supporting Tooling**
  - [[Hyperledger Caliper]]: performance benchmarking framework for measuring TPS, latency, and resource consumption across DLT platforms.
  - Hyperledger Explorer: a web-based blockchain data visualisation dashboard for Fabric networks.
  - Hyperledger Bevel: Kubernetes Helm-chart based deployment automation for spinning up production-grade Fabric and Besu networks.

### Applications / Use Cases

- **Trade Finance and Capital Markets**
  - Hyperledger Fabric underpins platforms such as we.trade (European trade finance consortium) and Voltron (now Contour), replacing documentary credit workflows with [[Smart Contracts]] that automate letter-of-credit issuance, matching, and settlement.
  - DTCC and Broadridge have piloted Fabric-based post-trade settlement to reduce counterparty risk and T+2 settlement latency.
- **Supply Chain Provenance**
  - IBM Food Trust (built on Fabric) enables food traceability from farm to supermarket shelf, reducing outbreak investigation time from weeks to seconds.
  - Walmart mandates supplier participation for certain leafy-green categories, making [[Supply Chain Blockchain]] provenance a compliance requirement.
  - Maersk TradeLens (now sunset) demonstrated large-scale shipping document digitalisation on Fabric, informing subsequent industry designs.
- **Healthcare**
  - Fabric-based systems manage consent for patient data sharing across health networks, providing an immutable audit trail aligned with GDPR and HIPAA requirements.
  - Pharmaceutical supply-chain serialisation (track-and-trace) for drug anti-counterfeiting leverages Fabric's private data collections.
- **Digital Identity and Credentials**
  - Governments and universities deploy [[Hyperledger Aries]] stacks for issuing verifiable diplomas, professional licences, and national identity attributes as [[Verifiable Credential]].
  - The British Columbia government's OrgBook and Verifiable Organisations Network represent a large-scale production deployment.
- **Financial Services Infrastructure**
  - Central banks exploring wholesale CBDC settlement layers have evaluated Hyperledger Besu for its Ethereum-compatibility and enterprise permissioning, enabling integration with existing EVM toolchains.

### Governance & Project Lifecycle

- The Technical Steering Committee (TSC) is the primary technical governance body, composed of maintainers elected from the contributor community, with seats reserved for Governing Members.
- Projects follow a defined lifecycle: **Proposal → Incubation → Graduated → Dormant/End-of-Life**, with Graduated status requiring stable API, active maintainers, adequate test coverage, and a diversity of contributing organisations.
- Working Groups address cross-cutting concerns: Identity, Performance and Scale, Learning Materials, and Architecture.
- The Hyperledger Foundation is a Directed Fund under the Linux Foundation, meaning Governing Members pay tiered dues that fund staff, infrastructure, and events (Hyperledger Global Forum).
- [[Open Governance]] principles — Apache 2.0 licensing, public roadmaps, open mailing lists, recorded TSC meetings — differentiate Hyperledger from proprietary DLT offerings.

### Standards & Context

- Hyperledger Aries implements **W3C Decentralised Identifiers (DIDs) v1.0** and **W3C Verifiable Credentials Data Model v2.0**, ensuring portability across identity ecosystems.
- Hyperledger Besu is compliant with the **Enterprise Ethereum Alliance (EEA) Client Specification**, enabling common API surfaces across enterprise Ethereum clients (Besu, Quorum).
- Hyperledger Fabric's peer-to-peer and client APIs use **gRPC** and **Protocol Buffers**, with TLS for transport security aligned with IETF standards.
- The **DIDComm v2** messaging protocol (DIF specification) governs Aries agent-to-agent communication, providing end-to-end encryption independent of transport layer.
- Hyperledger participates in the **Trust over IP (ToIP) Foundation** (also a Linux Foundation project) and the **Decentralised Identity Foundation (DIF)**, co-developing specifications for credential exchange, peer DID methods, and Wallet interoperability.
- ISO/TC 307 (Blockchain and Distributed Ledger Technologies) references Hyperledger implementations in its technical reports, acknowledging Fabric as a reference architecture for permissioned DLT.

### Provenance

