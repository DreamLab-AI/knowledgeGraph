Reverse logistics is the management of flows of goods, materials and related information back from the point of use or consumption towards a producer, a point of recovery or a point of proper disposal.[^1]

De Brito and Dekker set out to define and compare definitions of reverse logistics.[^1] They quote Pohlen and Farris, who define it as the movement of goods from a consumer towards a producer in a channel of distribution.[^1] They quote Rogers and Tibben-Lembke, whose wording describes planning, implementing and controlling the flow of raw materials, in-process inventory, finished goods and related information from the point of consumption to the point of origin for the purpose of recapturing value or proper disposal.[^1]

## Differences between definitions

De Brito and Dekker also quote the European Working Group on Reverse Logistics, RevLog, which defines it as the process of planning, implementing and controlling flows of raw materials, in-process inventory and finished goods from a manufacturing, distribution or use point to a point of recovery or point of proper disposal.[^1] The authors say this is broader than the earlier wording because it does not refer to a point of consumption.[^1] They add that the diversity of definitions with respect to recovery practices is a well-recognised source of misconception in research and in practice.[^1]

## Regulatory examples

Reverse flows are often set by regulation. Under the EU directive on waste electrical and electronic equipment, systems must be set up allowing final holders and distributors to return such waste at least free of charge, and distributors supplying a new product must ensure that old equipment of an equivalent type can be returned on a one-to-one basis.[^2] The UK deposit return scheme will introduce a refundable deposit on single-use drinks containers.[^3] See [[Product Take-Back Scheme]] and [[Deposit Return Scheme]].

## Scope and limits

Reverse logistics supports the loops described at [[Circular Supply Chain]]. This page draws its definitions from one paper; the Rogers and Tibben-Lembke wording belongs to a professional framework and is reported only as quoted there. The sources do not give volumes or costs of returns.

[^1]: Marisa P. de Brito and Rommert Dekker, Econometric Institute Report EI 2002-38, Erasmus University Rotterdam, 2002, “Reverse Logistics – a framework”. https://repub.eur.nl/pub/543/feweco20021018095304.pdf
[^2]: European Parliament and Council of the European Union, Directive 2012/19/EU of 4 July 2012, “Directive 2012/19/EU of the European Parliament and of the Council on waste electrical and electronic equipment (WEEE)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32012L0019
[^3]: UK Government, with the Scottish Government and DAERA, policy statement, “Deposit Return Scheme for drinks containers: policy statement”. https://www.gov.uk/government/publications/deposit-return-scheme-for-drinks-containers-policy-statement/deposit-return-scheme-for-drinks-containers-policy-statement

