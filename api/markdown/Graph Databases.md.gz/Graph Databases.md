Graph databases are database management systems that represent and store data as a network of nodes (entities) and edges (relationships), with both capable of carrying named property sets. Unlike relational models that encode relationships through foreign-key joins, graph databases make adjacency a first-class storage primitive, enabling traversal-based queries that navigate multi-hop paths in near-constant time per hop. They implement the property-graph or RDF triple-store data models, and are queried via languages such as Cypher, Gremlin, or SPARQL. Their native graph storage and index-free adjacency make them especially suited to domains where relationships are as semantically rich as the entities themselves.

### Overview

- Graph databases emerged in the mid-2000s as practitioners encountered the impedance mismatch between highly connected domain models and the tabular structure of [[Relational Databases]].
- The central insight is that relationships are first-class data: rather than computing a join between two tables, the database follows a pointer already embedded in the node record.
- Two dominant data models exist side by side:
  - **Property Graph** — nodes and directed edges, both with key-value property bags and type labels. The model used by Neo4j, TigerGraph, Amazon Neptune (PG mode), and SAP HANA Graph.
  - **RDF / Triple Store** — data expressed as subject-predicate-object triples conforming to W3C standards. Used by Stardog, GraphDB, Blazegraph, and Neptune (RDF mode).
- These models are complementary: property graphs excel at operational workloads and exploratory traversal; RDF stores excel at formal [[Ontology Engineering]] and interoperability via [[Linked Data]] standards.
- Graph databases sit within the broader [[NoSQL Databases]] movement but differ from document stores and key-value stores by treating the schema of relationships as semantically meaningful.

### Key Components

- **Nodes (Vertices)**
  - Represent entities: people, products, documents, concepts, events.
  - Carry one or more type labels (e.g. `Person`, `Account`).
  - Hold a property map (string → scalar or list).
- **Edges (Relationships)**
  - Directed, typed arcs connecting two nodes (e.g. `KNOWS`, `TRANSFERRED_TO`).
  - Also carry property maps enabling temporal, weighted, or annotated edges.
  - Directionality can be traversed in either direction at query time.
- **[[Index-Free Adjacency]]**
  - Each node stores a direct pointer (or linked list) to its incident edges.
  - Traversal cost is O(degree) per hop, independent of total graph size — contrast with a relational join whose cost scales with table cardinality.
- **[[Graph Query Language]]**
  - [[Cypher Query Language]] (openCypher / ISO GQL draft) — declarative, pattern-matching syntax native to Neo4j and adopted broadly.
  - [[Gremlin Traversal Language]] — imperative, functional traversal API from Apache TinkerPop; vendor-neutral.
  - [[SPARQL]] — W3C standard for querying RDF triple stores; path extensions in SPARQL 1.1 support graph traversal.
  - GQL (ISO/IEC 39075, published 2024) — international standard unifying property-graph query.
- **Graph Storage Engine**
  - Native graph storage serialises node and edge records in adjacency-list format, optimising pointer chasing.
  - Non-native stores (e.g. graph layer over a relational or key-value engine) trade traversal performance for storage flexibility.
- **[[Graph Algorithms]]**
  - Shortest path (Dijkstra, A*), community detection (Louvain, Label Propagation), centrality (PageRank, Betweenness), similarity (Jaccard, cosine via embeddings).
  - Typically exposed via a Graph Data Science library alongside the query engine.

### Applications / Use Cases

- **[[Knowledge Graphs]]**
  - Enterprise knowledge graphs (Google Knowledge Graph, Microsoft Satori, Meta TAO) integrate heterogeneous facts and support question-answering, entity disambiguation, and [[Semantic Search]].
- **[[Fraud Detection]]**
  - Financial institutions model accounts, transactions, devices, and IP addresses as graphs; circular payment rings and synthetic identity clusters emerge as unusual subgraph patterns invisible to row-level analytics.
- **[[Recommendation Systems]]**
  - Collaborative filtering over bipartite user-product graphs or session graphs; graph traversal replaces matrix factorisation for cold-start and real-time scenarios.
- **[[Social Network Analysis]]**
  - Influence propagation, community structure, shortest path between users, and churn prediction modelled directly on the social graph.
- **Identity and Access Management**
  - Role-permission-resource graphs enable recursive group membership resolution and policy impact analysis that would require complex recursive CTEs in SQL.
- **Supply Chain and Logistics**
  - Multi-tier supplier dependency graphs expose single points of failure; path queries answer "what would a disruption at node X affect downstream?"
- **Life Sciences**
  - Drug-target interaction networks, protein-protein interaction graphs, and clinical pathway modelling stored as [[Knowledge Graphs]] for biomedical research.
- **[[Network Analysis]] and IT Operations**
  - Infrastructure topology graphs (servers, switches, services) accelerate root-cause analysis by graph-walking dependency chains.
- **[[Ontology Engineering]] and the Semantic Web**
  - RDF triple stores are the canonical storage backend for OWL2 ontologies, enabling reasoners (HermiT, Pellet, ELK) to derive implicit class membership and detect inconsistencies.

### Standards & Context

- **W3C RDF / SPARQL stack** — Resource Description Framework (RDF 1.1), SPARQL 1.1, OWL2, SHACL, and ShEx form the normative standards for triple-store graph databases; governed by the W3C RDF Working Group.
- **ISO/IEC 39075:2024 — GQL** — the first international standard for property-graph query languages, consolidating Cypher, PGQL, and G-CORE proposals. Parallel to ISO SQL which gained SQL/PGQ (property graph query) extensions in SQL:2023.
- **openCypher** — open-source specification of the Cypher query language maintained by the openCypher project; basis for GQL standardisation.
- **Apache TinkerPop** — vendor-neutral graph computing framework providing [[Gremlin Traversal Language]]; adopted by Amazon Neptune, JanusGraph, TigerGraph, and others.
- **Linked Data Principles** — Tim Berners-Lee's four rules (use URIs, use HTTP URIs, provide useful data, include links) underpin [[Linked Data]] and the RDF triple-store ecosystem.
- **SHACL / ShEx** — constraint languages for validating RDF graphs against structural shapes; analogous to JSON Schema for property graphs.
- **Property Graph Schema (PG-Schema)** — emerging ISO supplement defining schema and type constraints for property graphs.

### Notable Implementations

- **Neo4j** — dominant native property graph database; Cypher query language; enterprise and AuraDB cloud editions.
- **Amazon Neptune** — managed cloud service supporting both property graph (Gremlin/openCypher) and RDF (SPARQL) in a single engine.
- **TigerGraph** — massively parallel native graph analytics at scale; GSQL query language.
- **JanusGraph** — open-source distributed graph over pluggable storage backends (Cassandra, HBase, BerkeleyDB); Apache TinkerPop.
- **Stardog** — enterprise [[Knowledge Graphs]] and reasoning platform; strong OWL2 and SHACL support.
- **GraphDB** — RDF triple store with OWL2 reasoning; popular in life sciences and government [[Linked Data]] portals.
- **Wikidata** — the world's largest open property-graph knowledge base, queryable via SPARQL at query.wikidata.org.
- **Azure Cosmos DB for Apache Gremlin** — serverless graph over Microsoft's multi-model Cosmos DB.

### Connections to Machine Learning

- [[Graph Neural Network]] (GNNs) operate directly on graph-structured data; graph databases serve as the storage and feature-extraction layer feeding GNN pipelines.
- [[Knowledge Graphs]] stored in graph databases act as structured external memory for large language models via retrieval-augmented generation (RAG).
- Node embedding methods (Node2Vec, GraphSAGE, TransE) produce vector representations of graph entities, bridging graph databases and [[Semantic Search]] via vector indices.

### Provenance

