The Global Location Number (GLN) is the GS1 identifier for a location or a party. The General Specifications define it separately as the identifier for a physical location that may be fixed or mobile, for a party that is a legal entity or department or function, and for a digital location.[^1]

GS1's overview page lists the same four things a GLN can identify: a legal entity, a function, a physical location and a digital location.[^2] GS1 Belgium & Luxembourg, a member organisation of GS1, describes the GLN as a globally standardised identification code used to uniquely and unambiguously identify locations.[^3] Its examples include a company, a branch or a department as a legal entity, and a truck as a mobile location.[^3]

## Use

That member organisation says GLNs are most commonly used in Electronic Data Interchange and Peppol, and that the benefits apply to any company, especially in cross-sector or cross-border transactions.[^3] That statement comes from a single national organisation, and the Peppol network itself was not opened for this page.

## Scope and distinctions

The GLN is one of the identification keys described at [[GS1 Identification Key]]. GS1 sets it against the [[Global Trade Item Number]], which identifies products and services, and the [[Serial Shipping Container Code]], which identifies logistics units: GS1 gives companies, warehouses, factories and stores as examples of what a GLN identifies.[^4]

A GLN names a place or party, not a movement.[^1] The events that happen at a location are recorded by other standards, for example [[GS1 EPCIS]].[^5]

## What the sources do not establish

All three sources are GS1 or a GS1 member organisation, so the page rests on one standards family. None of them describes how GLNs are allocated, reused or retired, and none compares the GLN with other party or location codes.[^1][^2][^3]

[^1]: GS1, “GS1 General Specifications Standard”, release 26.0. https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf
[^2]: GS1, Global Location Number (GLN) overview page. https://www.gs1.org/standards/id-keys/gln
[^3]: GS1 Belgium & Luxembourg, “Global Location Number (GLN)”. https://gs1belu.org/en/locations-gln
[^4]: GS1, “GS1 identification keys”. https://www.gs1.org/standards/id-keys
[^5]: GS1, “EPCIS & CBV”. https://www.gs1.org/standards/epcis

