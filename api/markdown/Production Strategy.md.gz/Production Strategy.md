A production strategy states how production is triggered relative to the customer order: made ahead to a forecast, finished or assembled after the order, or designed and made only once the order exists.[^1][^2]

Production strategies are usually framed by the customer order decoupling point. A review of operations and supply chain management quotes a definition of it as the point at which a product becomes earmarked for a particular customer: downstream of that point customer orders drive the control of materials flow, and upstream forecasts and plans do.[^1] A queueing paper gives the same idea as a point where each product is dedicated to a specific order of a known customer, attributes it to Olhager (2003), and notes that some researchers call it the customer order decoupling point.[^2]

## Named positions

That review lists five positions that have been distinguished in the literature: make to stock, assemble to order, make to order, purchase and make to order, and engineer to order. The first delivers from inventory when an order arrives, and the last starts engineering and purchasing only once an order arrives, so delivery lead time, product specificity and the work done after ordering differ widely.[^1] This corpus has pages for four of them: [[Make-to-Stock]], [[Make-to-Order]], [[Assemble-to-Order]] and [[Engineer-to-Order]].

## Trade-offs

An open textbook sets make-to-order against make-to-stock: the first allows exact customisation and lower inventory, at the cost of time to acquire materials and schedule the order, while the second gives short lead times from stock with the risk of forecast error and obsolescence.[^3] A capstone from the MIT Center for Transportation and Logistics adds that many firms now adopt hybrid make-to-stock and make-to-order models.[^4]

Textbooks also use the term for the whole choice of process. One open text compares three basic types of process, make-to-order, mass production and mass customisation.[^5] See [[Mass Customisation]] for the third.

## What the sources do not establish

Neither original paper defining the decoupling point was opened; the review and the queueing paper both cite them second hand.[^1][^2]

[^1]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: Production (Associação Brasileira de Engenharia de Produção), Ghalehkhondabi and Suer, via Redalyc, “Production line performance analysis within a MTS/MTO manufacturing framework: a queueing theory approach”. https://www.redalyc.org/journal/3967/396754754007/html/
[^3]: Engineering LibreTexts (Introduction to Operations Management, 1st Ed.), “6.2: Make-to-order and Make-to-stock”. https://eng.libretexts.org/Under_Construction/Purgatory/Introduction_to_Operations_Management_1st_Ed./06:_Process_Design/6.02:_Make-to-order_and_Make-to-stock
[^4]: MIT Center for Transportation and Logistics (Pooja Kashyap, capstone), “Optimizing Hybrid Assembly Strategies in Supply Networks: Evaluation of Make-to-Stock and Make-to-Order Models”. https://ctl.mit.edu/sites/default/files/documents/optimizing-hybrid-assembly-strategies-in-supply-networks-evaluation-of-make-to-stock-and-make-to-order-models-capstone.pdf
[^5]: eCampusOntario Pressbooks (Introduction to Canadian Business), “Operations Management”. https://ecampusontario.pressbooks.pub/bus108g/chapter/opsmanagement/

