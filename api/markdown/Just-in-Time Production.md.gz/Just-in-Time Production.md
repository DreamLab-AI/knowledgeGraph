Just-in-time production is a system of production that makes and delivers just what is needed, just when it is needed, and just in the amount needed.[^1]

The Lean Enterprise Institute names just-in-time and jidoka as the two pillars of the Toyota Production System, says just-in-time relies on heijunka as a foundation, and says it comprises three operating elements: the pull system, takt time and continuous flow.[^1] Toyota's own account agrees on the pillars: it describes the second as just-in-time, based on synchronising production processes and linking all plants in a continuous flow by making only what is needed, when it is needed, and in the amount needed.[^2]

## Aims and mechanisms

The Institute says just-in-time aims for the total elimination of all waste to achieve the best possible quality, lowest possible cost and use of resources, and the shortest possible production and delivery lead times.[^1] An open textbook gives the main goal as eliminating anything that does not add value from the customer's perspective. It contrasts a push system with a demand-pull system, in which work flows to a work centre only if that centre needs more work, and it names quick setups to reduce lot sizes among the principles.[^3] The same text names [[Kanban]] as a tool used to coordinate activities between workstations, and identifies uncertainty as the enemy of just-in-time.[^3] See also [[Takt Time]].

## Sources disagree on origin

The Lean Enterprise Institute credits the idea to Kiichiro Toyoda, the founder of Toyota Motor Corporation, during the 1930s.[^1] The open textbook says just-in-time is a management philosophy that originated in the 1970s and credits Taiichi Ohno with developing it and perfecting it for Toyota's plants.[^3] The two statements are not necessarily in conflict, since one dates the idea and the other the developed practice, but neither source says so.

## Scope and distinctions

Just-in-time is filed under [[Lean Production]]. This page covers the production system; it does not cover just-in-time delivery by suppliers, which none of these sources defines, nor the software term just-in-time compilation.

## What the sources do not establish

No source measures how much inventory just-in-time removes, and they do not say when it fails. The textbook says uncertainty is the enemy of just-in-time and recommends flexible resources as a defence, but it offers no figures.[^3]

[^1]: Lean Enterprise Institute, “Just-in-Time Production (Lean Lexicon)”. https://www.lean.org/lexicon-terms/just-in-time-production/
[^2]: Toyota Motor Corporation, “Toyota Production System”. https://global.toyota/en/company/vision-and-philosophy/production-system/
[^3]: Business LibreTexts (Introduction to Operations Management, NWTC), “10.3: Just-In-Time (JIT) Systems”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/10:_Just_in_Time_Lean_Systems/10.03:_Just-In-Time_(JIT)_Systems

