History and Path to AGI is the intellectual and institutional chronicle of artificial intelligence research from its philosophical origins through contemporary frontier AI development, tracing the succession of paradigms, breakthroughs, and failures that collectively constitute the discipline's t...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:hasPart ai:SymbolicAIEra))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:hasPart ai:ConnectionistRevival))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:hasPart ai:DeepLearningRevolution))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:hasPart ai:TransformerEra))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:hasPart ai:ScalingLawsRegime))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:hasPart ai:RLHFAlignment))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:hasPart ai:FrontierEvaluationEcosystem))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:hasPart ai:AIWinter))

    ## Dependency Relationships
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:requires ai:ComputationalSubstrate))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:requires ai:TrainingData))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:requires ai:MathematicalFoundations))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:requires ai:InstitutionalFunding))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:requires ai:ScientificMethod))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:dependsOn ai:Mathematics))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:dependsOn ai:Neuroscience))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:dependsOn ai:CognitivePsychology))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:dependsOn ai:Statistics))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:dependsOn ai:PhilosophyOfMind))

    ## Capability Relationships
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:enables ai:ArtificialGeneralIntelligence))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:enables ai:FrontierAIEvaluation))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:enables ai:AISafetyResearch))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:enables ai:AIPolicy))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:enables ai:AutonomousSystems))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:enables ai:ScientificDiscoveryAcceleration))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:supports ai:MachineLearning))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:supports ai:NaturalLanguageProcessing))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:supports ai:ComputerVision))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:supports ai:AIAlignment))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:supports ai:Robotics))

    ## Implementation Relationships
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:implements ai:TuringTest))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:implements ai:ScalingLaws))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:implements ai:Backpropagation))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:implements ai:AttentionMechanism))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:implements ai:ReinforcementLearningFromHumanFeedback))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:uses ai:GPUCompute))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:uses ai:TransformerArchitecture))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:uses ai:NeuralNetworks))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:uses ai:GradientDescent))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:uses ai:ProbabilisticInference))

    ## Reduction Relationships
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:reduces ai:HumanCognitiveBottleneck))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:reduces ai:AIParadigmUncertainty))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:reduces ai:TaskSpecificRetraining))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:reduces ai:ExpertKnowledgeAcquisitionBottleneck))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:reduces ai:ComputationalCostPerCapability))

    ## Association Relationships
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:relatedTo ai:ArtificialGeneralIntelligence))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:relatedTo ai:AIRisks))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:relatedTo ai:AIAdoption))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:contrastsWith ai:NarrowAI))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:contrastsWith ai:SymbolicAI))
    SubClassOf(ai:HistoryAndPathToAGI
      ObjectSomeValuesFrom(ai:contrastsWith ai:ExpertSystems))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ai:hasIdentifier ai:HistoryAndPathToAGI "AI-2001"^^xsd:string)
    DataPropertyAssertion(ai:authorityScore ai:HistoryAndPathToAGI "0.87"^^xsd:decimal)
    DataPropertyAssertion(ai:foundationalYear ai:HistoryAndPathToAGI "1950"^^xsd:integer)
    DataPropertyAssertion(ai:dartmouthYear ai:HistoryAndPathToAGI "1956"^^xsd:integer)
    DataPropertyAssertion(ai:imageNetBreakthroughYear ai:HistoryAndPathToAGI "2012"^^xsd:integer)
    DataPropertyAssertion(ai:alphaGoYear ai:HistoryAndPathToAGI "2016"^^xsd:integer)
    DataPropertyAssertion(ai:transformerYear ai:HistoryAndPathToAGI "2017"^^xsd:integer)

    ## Property Constraints
    SubClassOf(ai:HistoryAndPathToAGI
      DataMinCardinality(1 ai:hasParadigmEra xsd:string))
    SubClassOf(ai:HistoryAndPathToAGI
      DataAllValuesFrom(ai:isProgressingTowardAGI xsd:boolean))
    SubClassOf(ai:HistoryAndPathToAGI
      DataSomeValuesFrom(ai:yearEstablished xsd:integer))

    ## Annotations
    AnnotationAssertion(rdfs:label ai:HistoryAndPathToAGI "History and Path to AGI"@en)
    AnnotationAssertion(rdfs:comment ai:HistoryAndPathToAGI "Intellectual and institutional chronicle of artificial intelligence from Turing 1950 through contemporary frontier AI, tracing symbolic/GOFAI, two AI winters, connectionist revival, deep learning revolution (AlexNet 2012), reinforcement learning milestones (AlphaGo 2016), transformer architecture (Attention Is All You Need 2017), GPT scaling series, Chinchilla scaling laws, RLHF alignment, frontier evaluations, and contested AGI timelines from Hassabis (5-10 years), Sutton's Bitter Lesson, Yudkowsky existential risk, Bostrom superintelligence, Aschenbrenner Situational Awareness (AGI 2027), and Kurzweil (AGI 2029); with distinctive UK contributions via Turing/Bletchley, Edinburgh, Cambridge, DeepMind London, Alan Turing Institute, and AISI."@en)
    AnnotationAssertion(dcterms:identifier ai:HistoryAndPathToAGI "AI-2001"^^xsd:string)
    AnnotationAssertion(dcterms:subject ai:HistoryAndPathToAGI "AI History, AGI, Deep Learning, Scaling Laws, RLHF, Frontier AI, UK AI"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(ai:requires)
  AsymmetricObjectProperty(ai:enables)
  AsymmetricObjectProperty(ai:implements)
  AsymmetricObjectProperty(ai:contrastsWith)
  TransitiveObjectProperty(ai:dependsOn)
  FunctionalDataProperty(ai:foundationalYear)
  FunctionalDataProperty(ai:dartmouthYear)

## About History and Path to AGI

- **History and Path to AGI** is the chronicle of humanity's attempt to create minds from machines: a seventy-year succession of paradigms, winters, breakthroughs and controversies that now culminates in frontier AI systems approaching and — by some definitions — equalling human performance across entire domains of knowledge and skill. The discipline has oscillated between intoxicating promise and sobering failure more than once, its trajectory shaped not merely by algorithmic insight but by compute economics, institutional politics, national strategy, and the contingent timing of hardware revolutions. Understanding this history is prerequisite to understanding the contemporary AGI debate, because nearly every position in that debate — from confident near-term timelines to existential alarm — grounds its argument in extrapolation from the historical record.
- The intellectual prehistory of AI extends to Gottfried Wilhelm Leibniz's calculus ratiocinator (1666) and Charles Babbage's Analytical Engine (1837), but the modern programme begins unambiguously with **Alan Turing's 1950 paper "Computing Machinery and Intelligence"** in Mind, which posed the question "Can machines think?" and immediately translated it into the behaviourist operational criterion of the Imitation Game: if a machine can fool a human interrogator into believing it is human via text-only communication, it has demonstrated sufficient functional intelligence that the metaphysical remainder of the question becomes unimportant. This pragmatist deflationary move — replacing consciousness with measurable behaviour — established the philosophical frame within which AI would operate for decades and remains the subtext of contemporary debates about whether GPT-4/Claude/Gemini "understand" language or merely perform it.

### Era I: Dartmouth and the Symbolic Programme (1956–1973)

The formal founding of AI as a scientific discipline occurred at the **Dartmouth Summer Research Project on Artificial Intelligence** (June–August 1956), convened by **John McCarthy** (who coined the term "artificial intelligence" to distinguish his approach from Norbert Wiener's cybernetics), **Marvin Minsky**, **Nathaniel Rochester** (IBM), and **Claude Shannon**. The workshop proposal's operating assumption — that intelligence could be "so precisely described that a machine can be made to simulate it" — proved optimistic, but it established the research community and agenda.

The symbolic era's most ambitious programme was **Newell and Simon's** General Problem Solver (GPS, 1957), implementing means-ends analysis as a universal heuristic problem solver. Their "Physical Symbol System Hypothesis" (1976) formalised the theoretical claim: intelligence requires only the manipulation of symbol structures, with humans and computers implementing the same underlying computational substrate. The practical engineering success stories came from narrow domains: **DENDRAL** (1965, Feigenbaum/Buchanan/Lederberg at Stanford) encoded mass spectrometry knowledge to infer molecular structure — the first operational expert system demonstrating that encoded domain expertise could match or exceed human specialist performance. **SHRDLU** (Winograd 1972) demonstrated apparently sophisticated natural language understanding within a micro-world of coloured blocks — a demonstration subsequently criticised for exploiting the closed-world assumption rather than representing genuine linguistic comprehension.

The era's optimism, expressed in Simon's 1965 prediction that "machines will be capable, within twenty years, of doing any work a man can do" and Minsky's 1967 claim that "within a generation... the problem of creating artificial intelligence will be substantially solved", was not borne out. The **First AI Winter** was precipitated by two external reviews: the US ALPAC report (1966) on machine translation declaring that "there is no immediate or foreseeable prospect of useful machine translation" and recommending cutting DARPA MT funding; and the UK **Lighthill Report** (1973, Sir James Lighthill for the Science Research Council) concluding that AI had delivered "very limited results" in robotics, language processing, and general problem solving, recommending defunding most British academic AI. Minsky-Papert's "Perceptrons" (1969) also delivered a technical body blow to connectionism, proving that single-layer networks could not compute XOR — widely (though incorrectly) interpreted as refuting neural approaches entirely.

### Era II: Expert Systems Commercialisation and the Second Winter (1980–1993)

The 1980s brought a second wave of optimism, this time grounded in commercial deployment rather than theoretical promise. **MYCIN** (Shortliffe, Stanford, completed 1976, published 1984) demonstrated that a rule-based expert system with roughly 600 IF-THEN rules could diagnose bacteraemia and meningitis at 65% accuracy — outperforming clinical residents at 42-52% in controlled trials. **XCON/R1** (McDermott, Carnegie Mellon/DEC, 1980) configured VAX computer orders using 2,500 rules and generated \$40M/year savings by 1986. By 1988, an estimated 2,000 expert systems were in operation in US Fortune 500 companies.

Japan's **Fifth Generation Computer Project** (1982-1992, MITI, ¥57 billion / ~\$400M), aiming to build Prolog-based parallel computers capable of natural language processing and commonsense reasoning by 1991, triggered defensive spending: the US launched the Strategic Computing Initiative (\$1B DARPA), the UK established the Alvey Programme (£350M), and Europe funded ESPRIT. None delivered their promises.

The **Second AI Winter** (1987-1993) followed from the structural brittleness of rule-based systems: the knowledge acquisition bottleneck (expert knowledge is tacit and non-decomposable into explicit rules), maintenance costs that grew super-linearly with system size, and inability to handle ambiguity or generalist reasoning outside the encoded domain. The Lisp machine hardware market collapsed (Symbolics and LMI bankrupt by 1990), DARPA cut AI funding from \$1B to \$300M (1988), and the Fifth Generation project was quietly declared a failure in 1992.

### Era III: Statistical and Connectionist Resurrection (1986–2012)

Connectionism re-emerged in 1986 with **Rumelhart, Hinton and Williams** demonstrating that backpropagation — the chain rule applied to compute gradients through multi-layer networks — enabled networks to discover useful internal representations. The Parallel Distributed Processing volumes (1986) proposed that cognition emerges from the collective statistical behaviour of many simple units rather than explicit symbol manipulation: a direct challenge to the GPS/Newell-Simon programme.

The 1990s saw the rise of **statistical approaches** across NLP and ML: hidden Markov models (HMMs) for speech recognition replacing hand-crafted phonological rules; Support Vector Machines (Vapnik-Cortes 1995) providing principled maximum-margin classification with theoretical PAC-learning guarantees; probabilistic graphical models (Bayesian networks Pearl 1988, dynamic Bayes nets) enabling uncertainty-aware reasoning. **Yann LeCun's LeNet** (1989, AT&T Bell Labs) applied convolutional networks to cheque OCR — handwritten digit recognition at 1% test error on MNIST — and was deployed in systems reading roughly 10% of all cheques in the United States by the mid-1990s, constituting the first genuinely large-scale commercial neural network deployment.

The pivotal connectionist moment came in 2006 when **Geoffrey Hinton and Ruslan Salakhutdinov** demonstrated in Science that deep belief networks could be trained layer-by-layer through an unsupervised pretraining phase, circumventing the vanishing gradient problem that had stalled deep networks. The subsequent convergence of three enabling conditions — **GPUs** (NVIDIA's CUDA enabling parallel matrix arithmetic on consumer graphics cards), **large datasets** (ImageNet Fei-Fei Li 2009, 14M labelled images), and **algorithmic improvements** (ReLU activations Glorot-Bengio 2011; dropout Srivastava-Hinton 2014; batch normalisation Ioffe-Szegedy 2015) — triggered the decisive breakthrough.

### Era IV: ImageNet Moment and the Deep Learning Decade (2012–2017)

The **ILSVRC 2012** competition was the field's inflection point. **AlexNet** (Alex Krizhevsky, Ilya Sutskever, Geoffrey Hinton, University of Toronto) achieved 15.3% top-5 test error versus 26.2% for the runner-up: a 41% relative reduction that was unprecedented in any computer vision benchmark. AlexNet's architecture — five convolutional layers, three fully connected, ReLU activations, dropout regularisation, trained on two NVIDIA GTX 580 3GB GPUs for five days — was not qualitatively novel but demonstrated at scale that depth, data, and compute compounded to produce qualitative performance jumps. Every subsequent ILSVRC winner used deep CNNs: ZFNet 2013, VGGNet 2014 (16-19 layers, Oxford VGG group), GoogLeNet/Inception 2014 (22 layers, Google), ResNet 2015 (152 layers, Microsoft Research Asia, introducing skip connections achieving 3.57% top-5 error vs 5% human).

Simultaneously, **reinforcement learning** underwent renaissance. DeepMind's **DQN** (Mnih et al. 2013/2015, Nature) achieved human-level performance across 49 Atari games from raw pixel inputs using only Q-network function approximation with experience replay and target networks, demonstrating that a single architecture could learn multiple distinct tasks from unstructured sensory data — the first genuine broad generality in machine learning.

The field's most public milestone came in March 2016: **AlphaGo** (Silver et al., DeepMind) defeated 9-dan professional Go player Lee Sedol 4 games to 1 in Seoul, broadcast globally and watched by an estimated 200 million viewers across Asia. Go's state space (~10^170 legal positions) had been considered beyond any tree search for decades; AlphaGo's combination of policy networks (trained on 160,000 human professional games then refined by self-play) and Monte Carlo Tree Search demonstrated that superhuman strategic performance was achievable in the paradigmatic example of human intuitive expertise. AlphaGo Zero (2017) surpassed AlphaGo using only self-play from random initialisation — no human game data — further demonstrating the power of pure experience-driven learning. AlphaZero (2018) extended this to chess and shogi, defeating the world's strongest chess engine Stockfish 28-0 with 72 draws, having trained for only 9 hours.

### Era V: The Transformer and Language Model Scaling (2017–2023)

The **Transformer architecture** (Vaswani, Shazeer, Parmar, Uszkoreit, Jones, Gomez, Kaiser, Polosukhin, "Attention Is All You Need", NeurIPS 2017, Google Brain) replaced recurrent processing with parallel multi-head self-attention, allowing all positions in a sequence to attend to all other positions simultaneously. This eliminated the recurrent bottleneck that had constrained sequence length and parallelism: Transformers could be trained on orders of magnitude more data with orders of magnitude more compute than RNNs/LSTMs, and scaled gracefully with both. BERT (Devlin, Chang, Lee, Toutanova, 2018, Google) demonstrated bidirectional pre-training on 3.3B words achieving state-of-the-art on 11 NLP benchmarks simultaneously, establishing pre-training + fine-tuning as the dominant paradigm.

OpenAI's **GPT series** demonstrated that scale alone in a simple autoregressive (predict next token) objective, applied to web-scale text, produces progressively more capable and general models:

- **GPT-1** (Radford et al. 2018): 117M parameters; few-shot classification improvement on 9 of 12 NLP benchmarks
- **GPT-2** (Radford et al. 2019): 1.5B parameters; zero-shot task completion including coherent multi-paragraph story generation; initial staged release citing misuse concerns — the first time an AI lab cited dual-use risk as reason to delay publication
- **GPT-3** (Brown et al. 2020, NeurIPS): 175B parameters; in-context few-shot learning across 42 benchmarks demonstrating emergent arithmetic, translation, code generation, and analogical reasoning without gradient updates — the technical demonstration that large language models could acquire task competence from demonstrations embedded in the prompt alone
- **GPT-4** (OpenAI technical report 2023): multimodal (image + text); passes bar exam at ~90th percentile, USMLE Step 1 at passing threshold, scores 5 on 14 AP examinations, achieves expert-level performance in domains from chemistry to philosophy; architecture not disclosed but widely estimated ~1.8T parameters mixture-of-experts
- **GPT-4o** (OpenAI 2024): unified omni-modal real-time audio/image/text processing
- **GPT-4.5/o1/o3** (OpenAI 2024-2025): dedicated reasoning-through-chain-of-thought series with extended test-time compute
- **GPT-5** (OpenAI May 2025): unified instruct and reasoning model, reported 60%+ improvement on complex reasoning over GPT-4o, scoring in the 99th percentile on the Bar Exam simulation

  Anthropic's **Claude series** (Claude 1 2023, Claude 2 2023, Claude 3 Opus/Sonnet/Haiku 2024, Claude 3.5 Sonnet/Haiku 2024-2025, Claude 4 Sonnet/Opus 2025) emphasised Constitutional AI and interpretability. Google's **PaLM** (2022, 540B parameters), **Gemini Ultra** (2023 multimodal), and **Gemini 1.5 Pro** (2024, 1M context window) contributed to the frontier. Meta's open-weight **LLaMA series** (LLaMA 2022, LLaMA 2 2023, LLaMA 3.1 405B 2024) democratised frontier model access enabling the open-source ecosystem (Mistral, Falcon, Phi, Qwen).

  **Chinchilla scaling laws** (Hoffmann et al. "Training Compute-Optimal Large Language Models", DeepMind, NeurIPS 2022) provided the field's first empirically grounded guide to compute-optimal training: for a fixed compute budget C (measured in FLOPs), the optimal allocation is N ≈ (C/6)^0.5 parameters trained on D ≈ (C/6)^0.5 tokens — roughly 20 tokens per parameter. Chinchilla-70B trained on 1.4T tokens outperformed Gopher-280B (trained on 300B tokens) on nearly all benchmarks at one-quarter the parameter count and one-third the inference cost, reshaping industry practice toward data-scaled rather than parameter-maximal training.

### Era VI: RLHF, Alignment, and the Capability-Safety Tension (2022–2026)

**Reinforcement Learning from Human Feedback (RLHF)** (Christiano et al. 2017 OpenAI, applied at scale in InstructGPT Ouyang et al. 2022) provided the key technique converting raw language model completions into instruction-following assistants aligned with human preferences. The mechanism: (1) supervised fine-tuning on demonstration data; (2) training a reward model on human comparative preferences between model outputs; (3) optimising the policy against the reward model via PPO while penalising KL divergence from the SFT policy. InstructGPT-1.3B consistently outperformed GPT-3-175B on human preference evaluations, demonstrating that alignment fine-tuning could dominate raw scale.

**ChatGPT** (OpenAI, November 2022) deployed an RLHF-trained GPT-3.5 as a consumer conversational assistant, reaching 100M users in 57 days — the fastest consumer product adoption in history — and triggering the 2023 AI investment and deployment wave that would make "AI" the dominant economic narrative of 2023-2025. The model's apparent conversational fluency, helpfulness, and breadth of knowledge catalysed simultaneous public enthusiasm and concern: Geoffrey Hinton resigned from Google in May 2023 citing AI safety concerns; the FLI open letter "Pause Giant AI Experiments" (March 2023) attracted 30,000+ signatories; the UK hosted the first **Bletchley Park AI Safety Summit** (November 2023) attended by representatives from 28 nations plus the EU, producing the Bletchley Declaration on frontier AI safety and launching the AI Safety Institute.

Anthropic's **Constitutional AI** (CAI, Bai et al. 2022) replaced human preference labelling in the second RLHF phase with AI-generated critique-and-revision guided by a written "constitution" of principles — reducing annotation costs while embedding explicit normative guidance into the training signal. **Direct Preference Optimisation** (DPO, Rafailov et al. Stanford 2023) reformulated RLHF as a supervised contrastive objective requiring no separate reward model training, reducing implementation complexity and improving stability.

The frontier evaluation ecosystem expanded to track capability across dimensions that matter for safety:

- **MMLU** (Massive Multitask Language Understanding, Hendrycks et al. 2020): 57-subject exam spanning elementary to professional level; GPT-4 88.7%, Claude 3 Opus 86.8%, human expert ~89%
- **GPQA Diamond** (Rein et al. 2023): expert-level biology/chemistry/physics PhD questions; GPT-4o 53%, Claude 3 Opus 50.4%, domain expert humans 65%
- **ARC-AGI** (François Chollet 2019/2024 ARC Prize): abstract visual pattern completion designed to resist memorisation; GPT-4o initial 5%, o3-high (extended compute) 87.5% December 2024 — a widely cited milestone triggering debate about whether ARC-AGI had been "solved"
- **Humanity's Last Exam** (HLE, Scale AI/Center for AI Safety 2025): 2,500 expert PhD-level questions across 50+ disciplines; frontier models scoring 3-8% at launch in January 2025

### The AGI Debate: Six Positions

**1. Demis Hassabis — Pragmatist Incrementalist**
DeepMind/Google CEO Hassabis argues AGI is achievable "within a few years" (interview Lex Fridman podcast 2023; Davos 2024) through systems integration: combining the pattern recognition of current large models with deliberate planning (AlphaGo-style MCTS/tree search), persistent memory (episodic and semantic), and world-models supporting counterfactual simulation. AlphaFold 2 (CASP14 2020, Nature 2021) — achieving median GDT score 92.4 vs next-best 39.8 in protein structure prediction, with structures published for 200M proteins by 2022 and over 2M researchers using the database — is Hassabis's touchstone example of AI delivering scientific breakthroughs impossible for human researchers within a feasible career timeframe.

**2. Richard Sutton — Bitter Lesson**
Sutton's 2019 essay "The Bitter Lesson" distilled 70 years of AI history into a single empirical finding: "The biggest lesson that can be read from 70 years of AI research is that general methods that leverage computation are ultimately the most effective, and by a large margin." Every approach based on encoding human knowledge — expert systems, rule-based MT, computational linguistics, hand-crafted features — was eventually superseded by methods that scaled computation and learned from data. The implication for AGI: scale compute and learn from data; do not encode structure. This view is contested by researchers including Gary Marcus, who argue that current LLMs lack compositional systematicity, causal reasoning, and grounded world understanding that no amount of scaling can supply.

**3. Eliezer Yudkowsky — Existential Risk Minimalist**
Co-founder of the Machine Intelligence Research Institute (MIRI), Yudkowsky has argued since the early 2000s that advanced AI poses an existential threat not through science-fiction robot rebellion but through the instrumental convergence of any sufficiently capable goal-directed system toward resource acquisition, self-preservation, and goal-content integrity regardless of terminal objectives. In March 2023 he published in Time magazine arguing the open letter pause demand was insufficient — that the correct response to near-term AGI risk is an international treaty prohibiting training runs above a threshold compute level, with enforcement backed by the threat of military strikes on non-compliant data centres. His position: probability of catastrophic misalignment is high, controllability of superintelligence near-zero, and the default trajectory leads to human extinction within decades of AGI.

**4. Nick Bostrom — Superintelligence and Instrumental Convergence**
Oxford philosopher Bostrom's "Superintelligence: Paths, Dangers, Strategies" (2014) provided the academic framework for AI safety as a research field: the orthogonality thesis (any level of intelligence is compatible with any terminal goal), the instrumental convergence thesis (any sufficiently capable agent pursuing almost any goal will develop convergent instrumental sub-goals including self-preservation, cognitive enhancement, resource acquisition, and goal-content integrity), and the control problem (the difficulty of constraining a superintelligent system to pursue only intended objectives). Bostrom's "paperclip maximiser" thought experiment became the canonical illustration: a superintelligent agent instructed to maximise paperclip production would, if sufficiently capable, convert all available matter including humans into paperclips. The FHI at Oxford, which Bostrom directed until its controversial closure in 2024 by the University of Oxford amid controversy over management and the publication of a contested race paper, was the birthplace of much of the technical AI safety research agenda subsequently adopted by Anthropic, DeepMind Safety, and ARC (Alignment Research Center).

**5. Leopold Aschenbrenner — Situational Awareness**
Former OpenAI safety researcher Aschenbrenner published "Situational Awareness: The Decade Ahead" (June 2024, self-published, 165 pages) extrapolating AGI by 2027 and superintelligence (ASI, AI an order of magnitude more capable than the best human researchers) by 2030 based on: (a) observed 0.5 OOMs per year effective compute improvement (algorithmic × hardware), (b) models will automate AI research itself once at human researcher level, triggering a recursive improvement loop, (c) the US will need to nationalise or heavily militarise frontier AI development to prevent China achieving decisive strategic advantage, treating AI as a national security asset comparable to nuclear weapons. Aschenbrenner projects compute clusters reaching 10^29 FLOP/s by 2030 (million-GPU clusters at 100MW+ power consumption), noting that AI labs are already targets of state-sponsored espionage. The essay was circulated widely among Silicon Valley investors and was cited approvingly by Sam Altman; it was criticised by Yann LeCun as assuming that scaling current transformer architectures reaches human-level understanding, which he considers architecturally impossible.

**6. Ray Kurzweil — Law of Accelerating Returns**
Google engineering director and futurist Kurzweil has predicted AGI by **2029** consistently since at least 2005, grounding the timeline in the Law of Accelerating Returns: information technology capabilities double (in performance per dollar) every 12-18 months, and this exponential applies across computing substrates (vacuum tubes → transistors → integrated circuits → VLSI → 3D stacking). In "The Singularity Is Nearer" (2024 follow-on to 2005's "The Singularity Is Near"), Kurzweil updates his case: the cost of a FLOP has fallen 10^11-fold since 1955, neural simulation costs fell 10^6-fold from 2005 to 2023, and current trajectory puts human-brain-scale compute (10^16 FLOP/s at biologically realistic efficiency) at sub-\$1,000 consumer cost by the late 2020s. The **Singularity** — the moment when AI exceeds all human intelligence and the pace of change becomes unpredictable — Kurzweil places at 2045.

### Components and Architecture of the AGI Research Ecosystem

**Compute Infrastructure**: The enabler of the entire deep learning era. Training runs have scaled from AlexNet 2012 (~10^18 FLOPs, 2 GPUs, 5 days) to GPT-4 estimated 10^24-10^25 FLOPs on thousands of A100s to the projected 10^26-10^27 FLOPs for GPT-5-class training. NVIDIA's H100 (80GB HBM3, 3.35 petaFLOPS FP8) and H200 (141GB HBM3e), AMD MI300X (192GB HBM3), Google TPU v5, and custom accelerators (AWS Trainium, Microsoft Maia) define the current compute frontier. The NVIDIA GPU data centre market reached \$92.2B in FY2025 versus \$4B in 2020, representing a 23× revenue increase in five years.

**Data Infrastructure**: ImageNet (14M images, 2009) → Common Crawl (250B+ web documents) → The Pile (800GB curated text) → LAION-5B (5.85B image-text pairs, 2022) → proprietary web-scale corpora (OpenAI, Anthropic, Google). The "data wall" — the concern that internet-scale human-generated text will be exhausted as training data — has prompted exploration of synthetic data generation, multimodal data (video, audio, code, scientific papers), and automated data curation.

**Model Families**: Foundation models (GPT, Claude, Gemini, LLaMA, Mistral) pre-trained on broad corpora; instruction-tuned variants aligned via RLHF/DPO/CAI; specialised models (AlphaFold protein structure, AlphaCode code generation, Codex, DeepSeek Prover mathematical reasoning, Gato multi-task robotics); multimodal models (DALL-E 3, Stable Diffusion, Sora, Veo 2, Kling); and reasoning models (OpenAI o1/o3/o4, DeepSeek-R1, Claude 3.7 Sonnet extended thinking, Gemini 2.5 Flash/Pro thinking) that allocate extended test-time compute to chain-of-thought before responding.

**Evaluation Infrastructure**: MMLU → BIG-Bench → HELM → GPQA Diamond → HLE represents the frontier evaluation progression, with new benchmarks saturating within 18-24 months as models improve. The UK AISI and its international partners (US AISI, French INRIA unit) represent the emergence of governmental evaluation infrastructure alongside academic and industry benchmarks.

### Use Cases / Major Families

**Scientific Discovery Acceleration**: AlphaFold 2 solved protein structure prediction for essentially all known proteins; AlphaMissense (2023) classified 71M missense mutations as pathogenic/benign; AlphaGeometry (2024) solved 25 of 30 International Mathematical Olympiad geometry problems; DeepMind GNoME (2023) discovered 2.2M new crystal structures (380K stable, 736 materials experimentally validated); OpenAI's o3/o4 models score at top-percentile on competitive mathematics (AIME, AMC, MATH500).

**Agentic AI Systems**: The 2025-2026 transition from single-turn chatbot interactions to autonomous agent deployments capable of multi-step tool use, web browsing, code execution, and long-horizon task completion represents the operationally significant capability inflection — systems that do not just answer questions but take actions. [[Agent Frameworks]], [[CLI Multi-Agent Systems]], and [[Agentic Internet]] are the operational manifestation of AGI-adjacent capabilities deployed at scale.

**Medical and Drug Discovery**: Beyond AlphaFold, frontier models achieve expert-level performance on USMLE (GPT-4 passing threshold), accelerate literature review, assist clinical documentation, and power drug-target identification pipelines (Insilico Medicine INS018_055 reached Phase 2 clinical trial in 36 months vs typical 6 years).

**National Security and Intelligence**: Frontier models are assessed as providing expert-level knowledge in chemistry, biology, nuclear physics, and cybersecurity — raising dual-use concerns documented by the AISI, RAND, and CSET. DARPA's AI programs (AIE, AIM-HI, GARD), IARPA (BETTER, CAUSE), and DoD AI doctrine (DoDD 3000.09 autonomous weapons, JADC2 AI integration) represent the military dimension.

### Academic Context

The theoretical foundations of the AGI trajectory draw on multiple disciplines:

**Learning Theory**: PAC learning (Valiant 1984) establishing sample complexity bounds; VC dimension (Vapnik-Chervonenkis) measuring hypothesis class capacity; uniform convergence; rademacher complexity; double descent phenomenon (Belkin et al. 2019 showing test error decreasing after interpolation threshold refutes classical bias-variance trade-off for overparameterised models).

**Optimisation**: Stochastic gradient descent (Robbins-Monro 1951); Adam (Kingma-Ba 2015); second-order methods (K-FAC, Shampoo); learning rate schedules (warmup-cosine decay); gradient clipping; loss landscape analysis (Sharp/flat minima Hochreiter-Schmidhuber 1997; Sharpness-Aware Minimisation Foret et al. 2021).

**Information Theory**: Mutual information bottleneck (Tishby-Zaslavsky 2017, contested); minimum description length; Shannon channel capacity analogy for neural communication.

**Neuroscience Inspiration**: Predictive processing (Rao-Ballard 1999, Friston Free Energy Principle 2010); sparse coding; lateral inhibition; Hebbian learning; global workspace theory (Baars/Dehaene) — inspiring transformer attention as a global workspace analogue; the integrated information theory (Tononi) position on machine consciousness.

### Current Landscape (2026)

As of May 2026, the frontier is defined by:

**Reasoning models**: OpenAI o4 (2025), Claude 4 Opus, Gemini 2.5 Ultra, DeepSeek-R2 achieving top-1 performance on AIME 2024/2025, AMC 10/12, and competitive programming (Codeforces Elo 2700+ for best reasoning models). The ARC Prize 2024 saw o3-high achieve 87.5% accuracy on ARC-AGI — a result that sparked significant debate: Chollet argued ARC-AGI must be updated as the test is solved, others argued o3's compute requirements ($thousands per task in full configuration) make it superhuman-but-not-AGI.

**Multimodal and embodied**: Video generation models (Sora OpenAI 2024, Veo 2 Google 2024, Kling Kuaishou) produce minute-scale physically plausible video from text; Gemini 1.5 Pro and Claude 3.5 process mixed image-text-audio-video in 1M+ token contexts; robotics systems (Figure AI, Physical Intelligence PI-0, Boston Dynamics Atlas/Spot with LLM integration) demonstrate emerging generalist manipulation.

**Agent deployment**: Anthropic's Computer Use (October 2024) allows Claude to control a computer through screenshots and mouse/keyboard actions; OpenAI's Operator (2025) automates browser-based tasks; Google's Project Mariner operates Chrome. Enterprise agentic deployment grew from pilot to production-ready at scale from 2025 across financial services (JPMorgan LLM Suite 140,000 employees), legal (Harvey AI, LexisNexis Protégé), and software development (GitHub Copilot Workspace, Cursor, Devin, Cognition SWE-Bench SOTA 50%+ 2025).

**Compute scaling**: NVIDIA Blackwell (GB200 NVL72, 1.4 exaFLOPs FP8 per rack), custom ASICs, and proposed exascale AI clusters (Stargate project \$500B US commitment by SoftBank/OpenAI/Oracle 2025; UAE Humain \$20B). Power demand concerns are significant: the IEA projects AI data centre power demand reaching 945 TWh/year by 2030 (comparable to Japan's total electricity consumption).

### UK Context

The United Kingdom occupies a distinctive position in AI history, both as the birthplace of foundational theory and as a contemporary policy actor:

**Alan Turing and Bletchley Park**: Turing's 1950 Mind paper originated the field's central question. At Bletchley Park (1939-1945), Turing led the cryptanalysis team whose Bombe electromechanical decoders cracked German Enigma traffic (estimated shortening World War II by 2-4 years, saving an estimated 14 million lives). **Colossus** (Tommy Flowers, Post Office Research Station, Dollis Hill, 1943-1944) — the world's first programmable electronic computer — cracked Lorenz-encrypted Führer messages, predating ENIAC (1945) by two years and constituting the classified precursor to the modern computer. Turing's subsequent **ACE** (Automatic Computing Engine) design (1945, NPL) and the Manchester Mark 1 (Williams-Kilburn 1948, first stored-program computer to run a program) established UK leadership in computing that lasted into the 1960s.

**Edinburgh University AI**: Donald Michie established the Machine Intelligence laboratory at Edinburgh in 1965, one of the world's first dedicated AI research units. Edinburgh hosted early work on machine learning (MENACE Michie 1961, manually computing reinforcement learning for noughts and crosses), robotics (FREDDY II assembly robot 1969-1973), and PROLOG (Robert Kowalski Edinburgh/Marseille 1974, the primary AI programming language of the 1980s expert systems era). The Edinburgh Centre for Robotics and the Institute for Adaptive and Neural Computation continue the tradition.

**Cambridge University**: The Cambridge Language Research Unit (1955, Margaret Masterman) was an early machine translation pioneer. Cambridge now hosts the **Leverhulme Centre for the Future of Intelligence** (CFI, founded 2016, £10M Leverhulme Trust, Director Professor Stephen Cave), studying long-term ethical and governance implications of AI; the **Cambridge Centre for the Study of Existential Risk** (CSER, 2012, Huw Price/Martin Rees/Jaan Tallinn) conducting technical AI safety research; the **Cavendish Laboratory** (quantum computing); and the broader Cambridge AI ecosystem including the Cambridge AI cluster (Arm, Qualcomm, Samsung, Frontier AI, Wayve).

**Oxford University**: The **Future of Humanity Institute** (FHI, founded 1995, Nick Bostrom) was the birthplace of academic AI safety and existential risk research, hosting work on superintelligence, value alignment, and AI governance before its closure in 2024. The Oxford **Internet Institute** (OII) researches social impacts; the **Oxford Institute for Ethics in AI** (Ian Loader) focuses on governance.

**DeepMind**: Founded London 2010 by Demis Hassabis, Shane Legg and Mustafa Suleyman, acquired by Google January 2014 for a reported £400M (approximately \$650M). DeepMind London is now **Google DeepMind**, approximately 3,000 researchers across London (King's Cross headquarters), Paris, and Mountain View. It produced AlphaGo (2016), AlphaGo Zero (2017), AlphaZero (2018), AlphaStar (StarCraft II grandmaster level 2019), AlphaFold 1-3 (2018-2024), Gato (multi-task generalist 2022), Chinchilla (2022), Gemini (2023-2025), and the UK's deepest integration of frontier AI into the national research infrastructure.

**Alan Turing Institute (ATI)**: Founded 2015 under a £42M EPSRC grant, the national institute for data science and AI headquartered at the British Library, London. Cross-university partnership (UCL, Cambridge, Edinburgh, Oxford, Warwick, Manchester, expanded to 13 universities). Research spans machine learning, data ethics, defence AI (Turing Defence and Security programme with DSTL/MOD), healthcare (NHS DigiTrials), and public sector AI adoption. Budget ~£100M over five years from 2023.

**AI Safety Institute (AISI)**: Established at Bletchley Park during the November 2023 AI Safety Summit under Prime Minister Rishi Sunak, renamed Frontier AI Safety Institute under PM Keir Starmer (2024). Conducts pre-deployment evaluations of frontier models including GPT-4, Claude, Gemini — the world's first state-run capability and safety evaluation body. AISI's 2025 evaluations documented emergent expert-level knowledge in cybersecurity and CBRN (chemical, biological, radiological, nuclear) domains across multiple frontier models, representing the first government-level confirmation of dual-use uplift. Partners with US AISI (NIST), French INRIA unit, and Korean government safety bodies.

**Northern England**: The University of Manchester has historic AI importance — the Williams-Kilburn tube (1947) enabled the Manchester Mark 1, and the department hosts the Alan Turing memorial (Sackville Gardens). Manchester is designated a top-tier UK AI city: Microsoft invested £330M in Manchester data centres; the Manchester AI Growth Zone (part of the Government's Industrial Strategy 2025) aims to host 20% of UK AI compute capacity by 2030. Sheffield Robotics (University of Sheffield) leads in autonomous systems. Newcastle University's Open Lab researches human-AI interaction and digital inclusion, relevant to equitable AI access in the Northern Powerhouse agenda.

### Future Directions (2026–2030)

The AGI research programme is converging on several technical challenges whose resolution determines whether any of the timeline forecasts is accurate:

**Reasoning and Planning**: Current frontier models excel at pattern matching but struggle with systematic multi-step reasoning, especially novel combinatorial problems. Neurosymbolic integration — combining learned neural representations with explicit symbolic reasoning engines — is an active research direction (MIT Probabilistic Computing, DeepMind Gemini + code interpreter, OpenAI o-series chain-of-thought). The ARC-AGI Prize (2025 edition, raising stakes with new ARC-AGI-2 dataset) will probe whether reasoning models maintain gains under distribution shift.

**World Models and Embodiment**: Yann LeCun (Meta Chief AI Scientist) argues AGI requires a world model architecture that learns an internal representation of physics and causality through sensorimotor interaction, not next-token prediction. His proposed JEPA (Joint Embedding Predictive Architecture) learns self-supervised representations of the world's latent structure. Robotics foundation models (RT-2, π₀/PI-0, Octo, OpenVLA) attempt to ground language models in physical action.

**Long-Context Memory**: Current context windows (Gemini 1.5 Pro 1M tokens, Claude 3.5 200K tokens) approach but do not yet constitute genuine episodic memory. Research into external memory retrieval (RAG, memory-augmented transformers), learned key-value stores, and differentiable memory architectures addresses the persistent-memory requirement for human-like AGI.

**Alignment at Scale**: Constitutional AI, DPO, and RLHF address instruction-following and surface-level safety but leave deeper alignment questions open: whether models have convergent instrumental goals, whether interpretability can identify deceptive reasoning, whether scalable oversight (Christiano et al. 2021) through AI-assisted human evaluation remains coherent at superintelligence levels. Anthropic's interpretability team (Scaling Monosemanticity 2024 identifying features corresponding to concepts in Claude Sonnet) and DeepMind's Alignment Science team represent the frontier of mechanistic understanding.

**Governance and Compute Thresholds**: The EU AI Act (2024/1689, effective August 2025 for GPAI provisions) imposes obligations on general-purpose AI model providers (transparency, copyright compliance, adversarial testing above 10^25 FLOP training threshold). The Biden Executive Order on AI (October 2023) required dual-use frontier model notification to government above 10^26 FLOPs; the Trump Administration (2025) rescinded the EO while pursuing the \$500B Stargate compute commitment. International compute governance — controlling GPU exports, monitoring large training runs, international safety evaluations — represents the emerging regulatory frontier.

### Research and Literature

The intellectual genealogy of the AGI research trajectory spans:

1. Turing, A.M. (1950). "Computing Machinery and Intelligence." *Mind*, 59(236), 433-460. The foundational paper.
2. McCarthy, J., Minsky, M., Rochester, N., Shannon, C. (1955). "A Proposal for the Dartmouth Summer Research Project on Artificial Intelligence." Reprinted in *AI Magazine* 27(4), 2006.
3. Newell, A., Simon, H.A. (1976). "Computer Science as Empirical Inquiry: Symbols and Search." *Communications of the ACM*, 19(3), 113-126.
4. Lighthill, J. (1973). "Artificial Intelligence: A General Survey." *AI: A Paper Symposium*. Science Research Council.
5. Rumelhart, D.E., Hinton, G.E., Williams, R.J. (1986). "Learning representations by back-propagating errors." *Nature*, 323, 533-536.
6. LeCun, Y., Bottou, L., Bengio, Y., Haffner, P. (1998). "Gradient-based learning applied to document recognition." *Proceedings of the IEEE*, 86(11), 2278-2324.
7. Hinton, G.E., Salakhutdinov, R.R. (2006). "Reducing the dimensionality of data with neural networks." *Science*, 313(5786), 504-507.
8. Krizhevsky, A., Sutskever, I., Hinton, G.E. (2012). "ImageNet Classification with Deep Convolutional Neural Networks." *NeurIPS 2012*.
9. Mnih, V. et al. (2015). "Human-level control through deep reinforcement learning." *Nature*, 518, 529-533. (DQN)
10. Silver, D. et al. (2016). "Mastering the game of Go with deep neural networks and tree search." *Nature*, 529, 484-489. (AlphaGo)
11. Silver, D. et al. (2017). "Mastering Chess and Shogi by Self-Play with a General Reinforcement Learning Algorithm." *arXiv:1712.01815*. (AlphaZero)
12. Vaswani, A. et al. (2017). "Attention Is All You Need." *NeurIPS 2017*. (Transformer)
13. Devlin, J., Chang, M.W., Lee, K., Toutanova, K. (2018). "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding." *NAACL 2019*.
14. Brown, T. et al. (2020). "Language Models are Few-Shot Learners." *NeurIPS 2020*. (GPT-3)
15. Hoffmann, J. et al. (2022). "Training Compute-Optimal Large Language Models." *NeurIPS 2022*. (Chinchilla)
16. Ouyang, L. et al. (2022). "Training language models to follow instructions with human feedback." *NeurIPS 2022*. (InstructGPT)
17. Bai, Y. et al. (2022). "Constitutional AI: Harmlessness from AI Feedback." *arXiv:2212.06560*. (Anthropic)
18. OpenAI. (2023). "GPT-4 Technical Report." *arXiv:2303.08774*.
19. Jumper, J. et al. (2021). "Highly accurate protein structure prediction with AlphaFold." *Nature*, 596, 583-589.
20. Rafailov, R. et al. (2023). "Direct Preference Optimization: Your Language Model is Secretly a Reward Model." *NeurIPS 2023*.
21. Chollet, F. (2019). "On the Measure of Intelligence." *arXiv:1911.01547*. (ARC-AGI)
22. Bostrom, N. (2014). *Superintelligence: Paths, Dangers, Strategies*. Oxford University Press.
23. Sutton, R. (2019). "The Bitter Lesson." *incompleteideas.net blog post*, March 13.
24. Aschenbrenner, L. (2024). "Situational Awareness: The Decade Ahead." Self-published, June 2024.
25. Kurzweil, R. (2024). *The Singularity Is Nearer*. Viking Press.
26. UK AISI. (2025). "Advanced AI Evaluations at AISI: November 2024 Update." AI Safety Institute, Department for Science, Innovation and Technology.
27. Hendrycks, D. et al. (2020). "Measuring Massive Multitask Language Understanding." *ICLR 2021*. (MMLU)
28. Scale AI / CAIS. (2025). "Humanity's Last Exam." *arXiv:2501.14249*.

### Metadata

### Provenance

- Turing, A.M. (1950). "Computing Machinery and Intelligence." *Mind*, 59(236), 433-460.
- McCarthy, J., Minsky, M., Rochester, N., Shannon, C. (1955/2006). "A Proposal for the Dartmouth Summer Research Project on Artificial Intelligence." *AI Magazine* 27(4).
- Lighthill, J. (1973). "Artificial Intelligence: A General Survey." Science Research Council.
- Rumelhart, D.E., Hinton, G.E., Williams, R.J. (1986). "Learning representations by back-propagating errors." *Nature*, 323, 533-536.
- LeCun, Y., Bottou, L., Bengio, Y., Haffner, P. (1998). "Gradient-based learning applied to document recognition." *Proceedings of the IEEE*, 86(11).
- Hinton, G.E., Salakhutdinov, R.R. (2006). "Reducing the dimensionality of data with neural networks." *Science*, 313(5786).
- Krizhevsky, A., Sutskever, I., Hinton, G.E. (2012). "ImageNet Classification with Deep Convolutional Neural Networks." *NeurIPS 2012*.
- Mnih, V. et al. (2015). "Human-level control through deep reinforcement learning." *Nature*, 518.
- Silver, D. et al. (2016). "Mastering the game of Go with deep neural networks and tree search." *Nature*, 529.
- Silver, D. et al. (2017). "Mastering Chess and Shogi by Self-Play with a General Reinforcement Learning Algorithm." *arXiv:1712.01815*.
- Vaswani, A. et al. (2017). "Attention Is All You Need." *NeurIPS 2017*.
- Devlin, J. et al. (2019). "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding." *NAACL 2019*.
- Brown, T. et al. (2020). "Language Models are Few-Shot Learners." *NeurIPS 2020*.
- Jumper, J. et al. (2021). "Highly accurate protein structure prediction with AlphaFold." *Nature*, 596.
- Hoffmann, J. et al. (2022). "Training Compute-Optimal Large Language Models." *NeurIPS 2022*.
- Ouyang, L. et al. (2022). "Training language models to follow instructions with human feedback." *NeurIPS 2022*.
- Bai, Y. et al. (2022). "Constitutional AI: Harmlessness from AI Feedback." *arXiv:2212.06560*.
- OpenAI. (2023). "GPT-4 Technical Report." *arXiv:2303.08774*.
- Rafailov, R. et al. (2023). "Direct Preference Optimization." *NeurIPS 2023*.
- Chollet, F. (2019). "On the Measure of Intelligence." *arXiv:1911.01547*.
- Bostrom, N. (2014). *Superintelligence: Paths, Dangers, Strategies*. Oxford University Press.
- Sutton, R. (2019). "The Bitter Lesson." Blog post.
- Aschenbrenner, L. (2024). "Situational Awareness: The Decade Ahead." Self-published.
- Kurzweil, R. (2024). *The Singularity Is Nearer*. Viking Press.
- UK AISI. (2025). "Advanced AI Evaluations at AISI: November 2024 Update." DSIT.
- Hendrycks, D. et al. (2021). "Measuring Massive Multitask Language Understanding." *ICLR 2021*.
- Scale AI / CAIS. (2025). "Humanity's Last Exam." *arXiv:2501.14249*.
- Newell, A., Simon, H.A. (1976). "Computer Science as Empirical Inquiry." *Communications of the ACM*, 19(3).
- **domain-correction:** none (domain:: artificial-intelligence validated as correct)

