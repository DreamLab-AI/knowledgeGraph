A supply chain risk type is a category into which sources of supply chain risk are sorted, and the sources opened here do not agree on one classification.[^1]

Christopher and Peck say that supply chain risks can be categorised in many different ways and from different perspectives.[^1] Building on a framework by Mason-Jones and Towill, they propose three groups divided into five categories: process and control risk inside the firm, demand and supply risk outside the firm but inside the supply chain network, and environmental risk outside the network.[^1]

## Five categories

Process risk relates to disruptions to the firm's processes, and control risk arises from the application or misapplication of the rules that govern them.[^1] Demand risk relates to potential or actual disturbances to the flow of product, information and cash between the focal firm and the market.[^1] Supply risk is its upstream equivalent, concerning disturbances to flows from upstream of the focal firm.[^1] Environmental risk covers disturbances to the business environment such as wars, epidemics and earthquakes.[^1]

## Other splits

The Task Force on Climate-related Financial Disclosures divides climate-related risk into transition risk, from policy, legal, technology and market changes in moving to a lower-carbon economy, and physical risk, which can be event driven (acute) or a longer-term shift (chronic).[^2] It notes that physical risks can have indirect effects through supply chain disruption.[^2] The UK Climate Change Committee sorts climate risks to supply chains by where they arise: failure of infrastructure services, direct effects on output and locations, and effects felt through markets.[^3]

These are classifications by cause or by channel, and they cut across the five categories rather than replacing them. Specific types have their own pages: [[Supply Risk]], [[Supplier Concentration Risk]], [[Geopolitical Supply Chain Risk]] and [[Climate-Related Supply Chain Risk]]. The parent field is [[Supply Chain Risk and Resilience]].

## What the sources do not establish

No opened source gives a standard list of supply chain risk types. The Mason-Jones and Towill framework itself was not opened, so the five-way split is reported as Christopher and Peck present it.[^1]

[^1]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^2]: Task Force on Climate-related Financial Disclosures, “Recommendations of the Task Force on Climate-related Financial Disclosures, Final Report, June 2017”. https://assets.bbhub.io/company/sites/60/2020/10/FINAL-2017-TCFD-Report-11052018.pdf
[^3]: UK Climate Change Committee, “Resilient Supply Chains (briefing, 2022)”. https://www.theccc.org.uk/wp-content/uploads/2022/10/Resilient-Supply-Chains-.pdf

