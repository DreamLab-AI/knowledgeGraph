Wormhole is a decentralised, generic cross-chain messaging and asset-transfer protocol that connects heterogeneous blockchain networks by relying on a permissioned guardian network whose supermajority attestations produce signed Verified Action Approval (VAA) messages. On-chain core contracts on each supported network verify VAAs to lock, mint, or burn assets and to route arbitrary data payloads, making Wormhole a general-purpose interoperability layer rather than a simple token bridge. Originally launched in 2020 as a Solana–Ethereum wrapped-asset bridge by Certus One, it has expanded to support over 30 layer-1 and layer-2 ecosystems under stewardship of the independent Wormhole Foundation.

### Overview

- Wormhole addresses the fundamental challenge of [[Cross-Chain Interoperability]]: enabling assets and messages to move securely between independent blockchains with incompatible consensus and execution environments.
- Rather than constructing cryptographic proofs of source-chain state (as in [[IBC Protocol]] or [[Light-Client Bridge]] designs), Wormhole delegates trust to its guardian network — a fixed, named set of reputable validators who monitor every supported chain and co-sign state attestations.
- This design choice prioritises broad ecosystem coverage and operational simplicity over trustlessness, allowing rapid integration with new chains without waiting for light-client implementations.
- The protocol is structured around the concept of the VAA (Verified Action Approval): a message encoding the source chain, emitter address, sequence number, consistency level, and an arbitrary payload, signed by a guardian supermajority and verifiable on any destination chain by checking the guardian set's aggregate signature.
- Wormhole's generic messaging capability distinguishes it from earlier narrow-purpose token bridges, enabling complex cross-chain applications such as cross-chain governance, cross-chain NFT minting, and cross-chain oracle data delivery.

### Key Components

- **Guardian Network** — 19 independent validator nodes operated by reputable ecosystem participants (exchanges, infrastructure providers, DeFi protocols). Each guardian independently observes emitted events on every supported chain and contributes a signature when threshold criteria are met. See [[Guardian Network]].
- **Core Contract** — a canonical [[Smart Contract]] deployed on each supported chain; it emits messages from on-chain transactions and verifies incoming VAAs against the current guardian set's public keys. See [[Bridge Contract]].
- **Verified Action Approval (VAA)** — the canonical attested message format carrying payload, metadata, and a BFT-quorum signature. VAAs are the fundamental primitive that destination-chain contracts verify before executing bridged logic.
- **Token Bridge** — a higher-level application contract built on the core messaging layer, implementing the [[Lock-and-Mint Mechanism]]: locking native assets on the source chain and minting wrapped representations on the destination chain (e.g. Wormhole-wrapped ETH on Solana). See [[Token Bridging]].
- **NFT Bridge** — extends the token bridge to support [[Non-Fungible Token]] transfers, preserving metadata URIs across chains. See [[NFT Bridging]].
- **Relayer Network** — an optional off-chain service that submits VAAs to destination chains on behalf of users, enabling automated delivery without requiring the user to interact with the destination chain. See [[Cross-Chain Relayer]].
- **Wormhole Gateway** — a Cosmos-SDK chain that acts as a routing hub for IBC-connected ecosystems, bridging the guardian-attested world to the [[IBC Protocol]] world.
- **Connect SDK** — a developer toolkit providing abstractions over the messaging layer, simplifying [[Cross-Chain Messaging]] integration for application developers.

### Mechanisms

- **Two-Step Attestation Flow**
  - Step 1 — Emitter: a user or application calls the source-chain core contract, which emits a structured event logged on-chain.
  - Step 2 — Guardian observation: each guardian node detects the event on the source chain and checks that the configured consistency level (block finality or confirmation depth) has been met before signing.
  - Step 3 — VAA assembly: once 13 of 19 guardians have signed, any party (a relayer or the user) can assemble the VAA and submit it to the destination-chain core contract.
  - Step 4 — Destination execution: the core contract verifies the guardian signatures and, if valid, executes the encoded payload (release tokens, trigger logic, deliver data). See [[Quorum Consensus]].
- **Guardian Set Upgrades** — the guardian set itself is governed by the existing guardian set issuing a governance VAA; this allows rotating compromised or inactive guardians without a hard fork.
- **Consistency Levels** — the protocol supports configurable finality thresholds, enabling fast (pre-finality) or safe (post-finality) VAA issuance depending on application risk tolerance.
- **Zero-Knowledge Verification (emerging)** — research efforts explore replacing guardian-signature verification with [[Zero-Knowledge Proof]] circuits that prove source-chain state cryptographically, reducing trust assumptions substantially. See [[ZK Bridge]].
- **Intent-Based Bridging Integration** — newer integrations pair Wormhole messaging with [[Intent-Based Bridging]] solvers (e.g. Mayan Finance) that use Wormhole VAAs to settle user intents cross-chain, improving user experience and capital efficiency.

### Applications and Use Cases

- **DeFi Cross-Chain Liquidity** — [[Decentralised Finance]] protocols use Wormhole to move liquidity across chains, enabling unified yield strategies and cross-chain lending markets (e.g. [[Uniswap]] governance cross-chain, [[Stargate Finance]] predecessor designs).
- **Wrapped Asset Issuance** — Wormhole wrapped tokens (e.g. wETH on Solana, wSOL on Ethereum) provide unified representations of native assets, enabling cross-chain trading on [[Decentralised Exchange]]s.
- **NFT Portability** — creators and platforms use the NFT bridge to move digital collectibles across chains without losing provenance or metadata, leveraging [[Non-Fungible Token]] standards on multiple ecosystems.
- **Oracle Data Delivery** — the [[Pyth Network]] price oracle uses Wormhole to broadcast verified price feeds from its aggregation chain to over 40 destination chains in near real-time, making Wormhole a critical [[Oracle Network]] substrate.
- **Cross-Chain Governance** — DAO protocols use Wormhole messages to synchronise governance decisions (e.g. parameter updates, upgrades) across deployments on multiple chains. See [[On-Chain Governance]].
- **Gaming and Metaverse Assets** — [[Blockchain Gaming]] projects use Wormhole to port in-game items represented as NFTs across different chain environments, increasing asset utility and market liquidity.
- **Institutional Cross-Chain Settlement** — institutional participants use the protocol for cross-chain settlement flows in tokenised asset markets, exploiting its broad chain coverage relative to bespoke bilateral bridges.

### Security and Risk Profile

- **Guardian Trust Model** — security depends on the honest majority of the 19-guardian set. A ≥ 13-guardian compromise or collusion enables forged VAAs and total protocol insolvency. This is a weaker trust model than [[Light-Client Bridge]] designs that rely on the destination chain's validator set.
- **2022 Exploit** — In February 2022, an attacker exploited a signature-verification vulnerability in the Solana core contract to forge a VAA without legitimate guardian signatures, draining 120,000 wETH (approximately $320 million at the time). Jump Crypto recapitalised the bridge to make users whole within 24 hours.
- **Smart Contract Risk** — the protocol's attack surface spans core contracts on every supported chain; a vulnerability in any single deployment can potentially affect the entire protocol. Regular audits by firms such as Trail of Bits and Neodyme address this risk. See [[Smart Contract Audit]].
- **Relayer Censorship** — while any party can submit a VAA, dependence on the optional relayer network introduces liveness risks if relayers are unavailable or censored. Self-relaying is always an option for users with destination-chain accounts.
- **Governance Centralisation** — guardian set membership and governance VAA issuance are controlled by the existing guardian set, creating a degree of operational centralisation that contrasts with fully on-chain decentralised governance models. See [[Decentralised Governance]].

### Standards and Context

- Wormhole does not implement a formal external standard but publishes open specifications for its VAA format, core contract interfaces, and Connect SDK under the Apache 2.0 licence.
- The [[Wormhole Foundation]], established in 2023 as an independent steward of the protocol, coordinates guardian set membership, protocol upgrades, and ecosystem grants.
- The **W governance token** was launched in April 2024 via a community airdrop to Solana and Ethereum ecosystem participants; it governs protocol parameters and foundation treasury allocation.
- Wormhole is referenced in academic and industry discussions of cross-chain interoperability alongside [[LayerZero]], [[Axelar]], [[Connext]], and [[Synapse Protocol]] as a principal representative of the guardian/oracle-based bridge category (distinct from the light-client and relay-market categories).
- Security audits covering the protocol's Solana and EVM contracts have been published by Trail of Bits, Neodyme, and OtterSec. The exploit post-mortem is cited in cross-chain security research as a reference case for validator-set attack surfaces.

### Provenance

