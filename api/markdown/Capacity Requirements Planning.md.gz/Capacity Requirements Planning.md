Capacity requirements planning (CRP) is the verification that enough capacity is available to meet the capacity requirements of the material requirements plan.[^1][^2]

Oracle's Capacity User's Guide says CRP verifies that sufficient capacity is available for MRP plans and is a shorter-term tool than rough-cut capacity planning. Like RCCP, it is used by marketing and production to balance required and available capacity and to negotiate changes to the master schedule or to capacity requirements. It is more detailed than RCCP because it considers scheduled receipts and on-hand inventory when calculating requirements, so the detailed plan states the capacity needed to meet net production requirements.[^1]

Infor's System21 guide says CRP operates using finite capacity scheduling by individual order and schedule but assumes infinite capacity of the facilities used, and that it is the planner's responsibility to fine-tune the workload to optimise the loading factor. It takes suggested orders from master scheduling and MRP and actual orders from production control, in any combination.[^2]

## Scope and distinctions

Oracle's JD Edwards World documentation says the same batch program generates capacity planning information for RCCP and CRP, and that the only difference is in the work centres identified in the data selection.[^3] Gallego notes that MRP implicitly assumes infinite capacity, that advanced MRP systems provide more detailed capacity analysis proposing alternative schedules when the current plan is not feasible, and that CRP is among the functions added by MRP II.[^4] See [[Rough-Cut Capacity Planning]], [[Manufacturing Resource Planning]], [[Capacity Planning]] and [[Supply Planning]].

## What the sources do not establish

Two of the three descriptions are vendor documentation, and Gallego names CRP without defining it, so the page rests mainly on product guides.[^1][^2][^4]

[^1]: Oracle, Oracle Capacity User's Guide, “Capacity Requirements Planning (CRP)”. https://docs.oracle.com/cd/E18727_01/doc.121/e15189/T473818T474891.htm
[^2]: Infor, Infor System21 product guide, “Infor System21 Capacity Requirements Planning Product Guide”. https://docs.infor.com/s21/3.1/en-us/useradminlist/Infor%20System21%2031%20CP%20Capacity%20Requirements%20Planning%20Product%20Guide_50049.pdf
[^3]: Oracle, JD Edwards World Material Planning documentation, chapter 20, “Validate Master Schedules”. https://docs.oracle.com/cd/E26228_01/doc.93/e21770/ch_validate_mstr_sched.htm
[^4]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “Material Requirements Planning (MRP)”. http://www.columbia.edu/~gmg2/4000/pdf/lect_06.pdf

