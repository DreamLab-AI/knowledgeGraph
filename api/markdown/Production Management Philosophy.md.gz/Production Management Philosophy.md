A production management philosophy is a system of management beliefs and practices for running production, for example the Toyota Production System, which Toyota describes as based on a philosophy.[^1]

No source opened here defines the term as a class. This page is bounded by what organisations and teachers say about production approaches they describe as philosophies or systems.

## Examples in the sources

Toyota describes its production system as based on the philosophy of achieving the complete elimination of waste in pursuit of the most efficient methods, and says that philosophy rests on two pillars, jidoka and Just-in-Time. Just-in-Time is based on synchronising production processes in a continuous flow by making only what is needed, when it is needed, and in the amount needed.[^1] See [[Just-in-Time Production]] and [[Kaizen]].

The Lean Enterprise Institute defines lean as a way of thinking about creating needed value with fewer resources and less waste, and as a practice of continuous experimentation, and says thinking and practice occur together.[^2] See [[Lean Production]].

A 1999 teaching article by Mukherjee and Wheatley names Just In Time and Total Quality Management as techniques the Japanese used successfully, says the Theory of Constraints has been proposed and used by companies in the United States, and says the techniques of JIT and TQM are widely taught in operations management courses.[^3] See [[Total Quality Management]] and [[Theory of Constraints]].

## Scope and distinctions

One article calls these techniques, Toyota calls its approach a philosophy and a production system, and the Lean Enterprise Institute calls lean a way of thinking and a practice. The sources therefore use the labels interchangeably, and this page groups them for navigation only.[^1][^2][^3] A philosophy in this sense is broader than a single tool such as [[Kanban]] or [[Takt Time]], and unlike a production strategy it does not decide when production is triggered; see [[Production Strategy]].

## What the sources do not establish

No source says which approach is better in a given setting, and none claims that the approaches are mutually exclusive. The article is a teaching paper from 1999 and does not describe current practice.

[^1]: Toyota Motor Corporation, “Toyota Production System”. https://global.toyota/en/company/vision-and-philosophy/production-system/
[^2]: Lean Enterprise Institute, “What is Lean?”. https://www.lean.org/explore-lean/what-is-lean/
[^3]: Arup Mukherjee and Walter J. Wheatley, Developments in Business Simulation and Experiential Learning 26, 1999, “The ABC’s of Teaching the Theory of Constraints to Undergraduate Business Students”. https://absel-ojs-ttu.tdl.org/absel/article/view/976/945

