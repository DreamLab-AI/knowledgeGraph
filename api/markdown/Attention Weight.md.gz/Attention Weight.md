A scalar coefficient produced by an attention mechanism that quantifies the relevance of one position (key/value) to another (query) in a sequence or across modalities. Attention weights are computed via a softmax over scaled dot-products of query and key vectors, and govern how much each value contributes to the output representation. They are the core computational primitive of Transformer-based models.

### Semantic Classification

### Content

## Compositional Relationships (Components)
  ```
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:hasPart ai:SoftmaxFunction))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:hasPart ai:QueryKeyValue))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:partOf ai:AttentionMechanism))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:partOf ai:TransformerArchitecture))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:partOf ai:MultiHeadAttention))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:partOf ai:SelfAttention))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:partOf ai:CrossAttention))
  ```
## Dependency Relationships
  ```
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:requires ai:MatrixMultiplication))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:requires ai:Embedding))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:requires ai:PositionalEncoding))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:dependsOn ai:Backpropagation))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:dependsOn ai:GradientDescent))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:uses ai:NeuralNetwork))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:uses ai:EncoderDecoderArchitecture))
  ```
## Capability Relationships
  ```
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:enables ai:LargeLanguageModels))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:enables ai:ExplainableAI))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:enables ai:MachineTranslation))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:enables ai:ImageCaptioning))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:enables ai:SpeechRecognition))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:enables ai:NaturalLanguageProcessing))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:enables ai:SequenceToSequenceLearning))
  ```
## Implementation Relationships
  ```
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:implements ai:ScaledDotProductAttention))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:implements ai:SoftmaxNormalisation))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:supports ai:ComputerVision))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:supports ai:MultimodalAI))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:supports ai:GraphNeuralNetwork))
  ```
## Reduction Relationships
  ```
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:reducesTo ai:ScalarCoefficient))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:reducesTo ai:ProbabilityDistribution))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:contrastsWith ai:RecurrentNeuralNetwork))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:contrastsWith ai:StateSpaceModel))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:contrastsWith ai:LongShortTermMemory))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:relatedTo ai:BERT))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:relatedTo ai:GPT))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:relatedTo ai:MixtureOfExperts))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:relatedTo ai:LayerNormalisation))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:supports ai:SpeechRecognition))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:uses ai:FeedForwardNetwork))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:bridges ai:MultimodalAI))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:bridges ai:ComputerVision))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:implements ai:SequenceToSequenceLearning))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:relatedTo ai:GraphNeuralNetwork))
  SubClassOf(ai:AttentionWeight
    ObjectSomeValuesFrom(ai:enables ai:ImageCaptioning))
  ```

## About

Attention weights are the fundamental computational currency of the [[Transformer Architecture]] family and, by extension, of the [[Large Language Model]] that have come to dominate [[Natural Language Processing]] since 2017. As scalar probability values summing to one over the source positions for each target position, they act as a differentiable, learned selection mechanism: the model is trained end-to-end via [[Backpropagation]] to assign high attention weights to source positions whose [[Embedding]] representations are most relevant for predicting or generating each output element. This contrasts sharply with the fixed, position-by-position processing of [[Recurrent Neural Network]] and [[Long Short Term Memory]] architectures, where information from distant positions must survive many sequential state transitions — a process that degrades signal strength and makes long-range dependencies difficult to learn. By learning to place high weight on relevant positions regardless of distance, attention weights elegantly sidestep this bottleneck, enabling models to handle sequences of arbitrary length in a single forward pass (subject only to the quadratic memory cost of the full attention matrix).

The mathematical derivation of attention weights begins with projecting an input sequence x ∈ ℝ^{n×d_model} into query Q = xW_Q, key K = xW_K, and value V = xW_V matrices through learned weight matrices W_Q, W_K, W_V ∈ ℝ^{d_model×d_k}. The raw (logit) attention scores are the matrix A_raw = QKᵀ / √d_k ∈ ℝ^{n×n}. Dividing by √d_k prevents the dot products from growing large in high-dimensional spaces, which would push the [[Softmax Function]] into saturation regions where [[Gradient Descent]] becomes ineffective due to vanishingly small gradients. The final attention weight matrix is A = softmax(A_raw) ∈ ℝ^{n×n}, where softmax is applied row-wise so each row sums to one. The output for the attention layer is then simply Z = AV, a weighted combination of the value vectors. In practice, a causal mask is applied for autoregressive generation (as in [[GPT]]) to prevent positions from attending to future positions, setting masked logit entries to −∞ before the softmax so their resulting weights are zero. After computing Z, the result passes through a [[Layer Normalisation]] sublayer followed by a [[Feed Forward Network]] with residual skip connections — the standard [[Encoder-Decoder]] block structure — before the combined representation advances to the next layer.

The computational cost of full attention is O(n²d) in time and O(n²) in memory, where n is the sequence length and d is the head dimension. For a model processing a 128K-token context with 96 heads, this yields attention weight matrices with 128K × 128K = 16.4 billion entries per head per layer — far exceeding VRAM capacity if materialised naively. Flash Attention solves this by decomposing the computation into tiles that fit in fast on-chip SRAM, computing the softmax incrementally using the online softmax algorithm of Milakov and Gimelshein (2018), and never writing the full attention matrix to slow DRAM. This hardware-aware implementation achieves exact (non-approximated) attention results while dramatically reducing memory bandwidth requirements — a prerequisite for the very-long-context capability of models like Gemini 1.5 Pro and Claude 3 Opus. Flash Attention 4, released March 2026 with NVIDIA B200 GPU support, achieves approximately 1,605 TFLOPs/s with 71% hardware utilisation.

The debate over whether attention weights constitute valid explanations for model decisions has produced a rich and technically sophisticated sub-literature that has matured into the broader mechanistic interpretability programme. Jain and Wallace (2019) demonstrated that attention weights over input tokens can be permuted or replaced with adversarial distributions without substantially changing model predictions, calling into question the naive reading of attention weights as causal feature importances. Wiegreffe and Pinter (2019) challenged these conclusions, arguing that the definition of "explanation" matters — under a functional characterisation, attention distributions that produce the same outputs as human-interpretable distributions do constitute a form of explanation. Serrano and Smith (2019) showed that zeroing out the highest-attention input tokens does affect predictions more than zeroing low-attention tokens, suggesting some signal is present even if not causally sufficient. Pruthi et al. (2020) demonstrated that models can be trained to produce deceptively plausible attention distributions that bear no relationship to actual prediction-relevant computation, further cautioning against uncritical use of attention weights as explanations.

By 2025–2026, the mechanistic interpretability programme (Elhage et al. 2021; Sharkey et al. 2025; Conmy et al. 2023) has moved definitively beyond raw attention weight inspection toward circuit-level analysis. Rather than reading off which tokens received high attention weights, circuit analysis identifies which attention heads implement which computational operations by intervening on activations: patching the output of one forward pass into another (activation patching), decomposing the residual stream into additive contributions from each layer and head (path patching), and tracing information flow through the model (logit lens analysis). Using these techniques, researchers have characterised specific functional head types: induction heads that detect and continue repeating patterns by attending to tokens that previously followed the current token; name-mover heads that copy entity names to the current output position; duplicate token heads that attend to other occurrences of the current token; negative heads that suppress the most likely next token to force consideration of alternatives. The [[Explainable AI]] implications of these findings are significant: rather than expecting raw attention weights to be interpretable, the field now understands that the interpretable unit is the circuit — a composition of attention heads, [[Feed Forward Network]] MLP layers, and residual stream interactions that collectively implement a well-defined algorithm.

The relationship between attention weights and [[Graph Neural Network]] architectures deserves specific note. Attention-weighted message aggregation in Graph Attention Networks (GATs, Veličković et al. 2018) applies the same scaled dot-product attention paradigm to graph-structured data: for each node, attention weights are computed over its neighbours' feature representations, determining how much each neighbour contributes to the updated node embedding. This unification of sequence attention and graph attention has enabled cross-pollination of architectural advances — including multi-head graph attention, sparse graph attention, and hierarchical graph transformers — that extend the attention weight primitive beyond sequence modelling into relational reasoning over structured knowledge graphs.

[[Multimodal AI]] systems introduce [[Cross Attention]] as the inter-modal bridge: a vision encoder (typically a ViT — Vision Transformer — which applies [[Self Attention]] over image patches) produces a sequence of patch-level representations that serve as keys and values, while the language decoder generates queries that attend into this visual context via cross-attention. The attention weights in these cross-attention layers constitute the model's learned visual grounding mechanism — the mapping between language tokens and image regions. When a model correctly answers a question about a photograph, the cross-attention weights ideally concentrate on the image region that is relevant to the question. This interpretability property, though subject to the same caveats as text attention, has made cross-attention weight visualisation a standard diagnostic tool in [[Computer Vision]] and visual question answering research.

## Components and Architecture

The [[Query Key Value]] triple is the architectural foundation of scaled dot-product attention. Each token (or patch, or node) in the sequence is mapped to three learned vectors through separate linear projections:

- **Query (Q)**: represents what this position is "looking for" — the comparison vector that is matched against keys across all source positions.
- **Key (K)**: represents what information this position "advertises" — the label that other positions' queries match against to determine relevance.
- **Value (V)**: represents the actual content this position contributes when selected — the information payload transferred to the output when this position receives high attention weight.

  The scaled dot-product attention computation proceeds through the following steps:

- Project input representations into Q, K, V: Q = xW_Q, K = xW_K, V = xW_V
- Compute pairwise similarity logit matrix: A_raw = QKᵀ / √d_k ∈ ℝ^{n×n}
- Apply optional masking: causal masks (−∞ for future positions in autoregressive generation), padding masks (−∞ for padding tokens to prevent attention to non-content positions)
- Apply [[Softmax Function]] row-wise to obtain normalised attention weights: A = softmax(A_raw), where each row sums to 1.0
- Compute output as weighted combination of values: Z = AV ∈ ℝ^{n×d_v}
- The output Z is the context-aware representation of each input position, incorporating information from all positions weighted by their computed relevance.

  In [[Multi-Head Attention]] (MHA), this entire computation is replicated h times in parallel using independently learned projection matrices:

- Head_i output: Z_i = Attention(xW_Q^i, xW_K^i, xW_V^i) for i = 1, ..., h
- Concatenate: Concat(Z_1, ..., Z_h) ∈ ℝ^{n×(h·d_v)}
- Project to model dimension: MHA(x) = Concat(Z_1,...,Z_h) · W_O
- This produces h distinct attention weight matrices A_1,...,A_h per layer
- Modern frontier models (GPT-4 class) use h = 96 heads with d_k = d_v = 128, yielding 96 distinct n×n attention weight matrices per layer per forward pass.
- Each head specialises on different aspects of the input relationship: syntactic heads, semantic heads, positional heads, copy heads, induction heads — as revealed by mechanistic interpretability studies.

  [[Positional Encoding]] interacts with attention weights by injecting sequence order information into the query and key representations:

- Without positional information, dot-product scores would be permutation-invariant — the model would treat "the dog bit the man" and "the man bit the dog" as identical.
- Absolute sinusoidal positional encodings (original Vaswani et al. 2017): add fixed position vectors to input embeddings before attention.
- Learned absolute positional embeddings (BERT, GPT-2): learn position-specific embedding additions.
- Relative positional encodings (Shaw et al. 2018; T5 relative bias): add position-relative bias terms to attention logits before softmax.
- Rotary Positional Embedding / RoPE (Su et al. 2024): rotate Q and K vectors in embedding space by angles proportional to position, encoding relative distance as dot-product phase; the resulting attention weights naturally decay with positional distance and generalise to contexts much longer than training sequences.
- RoPE is now standard across Llama 3, Mistral, Phi-3, Gemma, and most 2024–2026 model families.

  [[Layer Normalisation]] and residual connections provide the training stability context within which attention weights are learned:

- Each transformer layer applies: x = LayerNorm(x + MHA(x)) followed by x = LayerNorm(x + FFN(x))
- Residual connections (He et al. 2016) allow gradients to flow directly from output layers to early layers during [[Backpropagation]], enabling reliable training of deep stacks of 96+ attention layers.
- Layer normalisation stabilises the scale of activations entering attention weight computation, preventing the softmax from saturating due to abnormally large or small logit magnitudes.
- The resulting attention weights are learned in an implicit coordination environment: each head's weights develop in the context of what other heads are attending to, mediated through the shared residual stream.

  ## Variants and Major Families

  **Self-Attention**: queries, keys, and values all derive from the same sequence. Used in encoder layers of [[BERT]] and all layers of decoder-only models like [[GPT]]. The resulting n×n attention weight matrix is the full pairwise relevance map of the sequence — each token can attend to every other token, enabling capture of arbitrary long-range syntactic and semantic dependencies. In bidirectional models (BERT), this is computed without masking; in autoregressive models (GPT), a causal mask zeros out future positions.

  **[[Cross Attention]]**: queries come from the decoder or target modality; keys and values from encoder output or a different source modality. The core of [[Encoder-Decoder]] models such as T5 (text-to-text) and Whisper ([[Speech Recognition]]), enabling the decoder to selectively retrieve information from the encoded source. In [[Multimodal AI]] vision-language models, cross-attention weights map language token queries to visual patch keys, providing the inter-modal grounding mechanism. The attention weight matrix in cross-attention has shape (target_len × source_len) rather than the square (n × n) of self-attention.

  **[[Multi-Head Attention]] (MHA)**: the canonical extension splitting the model dimension into h parallel attention heads, each with its own projection matrices. A single attention head can only attend to one type of relationship at a time; multiple heads allow the model to simultaneously track syntactic heads, semantic roles, coreference chains, and positional patterns. The outputs of all h heads are concatenated and linearly projected. Grouped Query Attention (GQA, Ainslie et al. 2023) reduces KV-cache memory by sharing keys and values across groups of query heads — a critical inference efficiency optimisation deployed in LLaMA 3, Gemma, and Mistral class models.

  **Sparse Attention**: instead of attending to all n positions (O(n²) cost), only a structured or learned subset of positions receive non-zero weight. Implementations include: local windowed attention (each position attends to a fixed window of k neighbours); strided attention (alternating full and windowed heads, as in Sparse Transformers, Child et al. 2019); global-plus-local patterns (Longformer, Beltagy et al. 2020); and learned sparse patterns identified by token importance scoring. Sparse attention post-training (Conmy et al. 2024) forces models to concentrate their weights into sparser distributions, aiding circuit discovery by making attention routing choices more explicit and interpretable.

  **Flash Attention (v1–v4)**: not a different attention weight scheme mathematically, but a hardware-aware implementation that avoids materialising the full n×n attention matrix in GPU HBM by computing attention in tiles using fast on-chip SRAM. Flash Attention 4 (March 2026) achieves approximately 1,605 TFLOPs/s on NVIDIA B200 GPUs with 71% hardware utilisation, making exact softmax attention computation at context lengths exceeding one million tokens economically practical. This advance was a prerequisite for Gemini 1.5 Pro's 1M-token context window and Claude 3's 200K-token context.

  **Linear Attention**: approximates softmax attention using kernel feature maps (e.g. the Performer, Choromanski et al. 2021), reducing computational cost from O(n²) to O(n) — enabling sequence lengths in the millions. The trade-off is accuracy: linear attention cannot exactly replicate the peaked, sparse distributions that softmax produces, making it less suitable for tasks requiring precise token-level disambiguation. This motivates hybrid architectures that interleave full attention layers with linear-complexity [[State Space Model]] layers (as in Mamba-Attention hybrid models), achieving the best of both paradigms: full attention for global context capture and state space linear-time layers for processing very long spans.

  **Rotary Positional Embedding (RoPE) interaction**: While not a separate attention variant, RoPE (Su et al. 2024) substantially changes how attention weights encode position. Rather than adding positional signals to the embedding before attention, RoPE rotates query and key vectors in embedding space by angles proportional to their absolute positions. The result is that dot products between rotated Q and K vectors automatically encode relative position, and the attention weight between two positions decays with relative distance in a learned, continuous manner. RoPE enables extrapolation to sequence lengths much longer than those seen during training, explaining its universal adoption in post-2023 LLMs.

  ## Academic Context

  The concept of neural attention as differentiable soft selection was introduced in [[Machine Translation]] by Bahdanau, Cho, and Bengio (2015), who proposed aligning decoder states to encoder outputs via a learned alignment function — the first published neural attention mechanism. In their formulation, an alignment model (a small feedforward network) computed a scalar score e_{ij} = a(s_{i-1}, h_j) between decoder hidden state s_{i-1} and encoder hidden state h_j for each source position j, then normalised these scores with a softmax to produce attention weights α_{ij} = softmax(e_{ij}). The resulting system was the first to enable neural machine translation without the information bottleneck of a fixed-length context vector, dramatically improving translation of long sentences. Luong, Pham, and Manning (2015) proposed two simplified variants: "dot" attention (e_{ij} = s_i · h_j) and "general" attention (e_{ij} = s_i^T W_a h_j), avoiding the MLP alignment network and proving that simple dot-product similarities between state vectors suffice.

  Vaswani et al. (2017) in "Attention Is All You Need" made the decisive architectural leap: eliminating recurrence entirely and building a model purely from stacked [[Multi-Head Attention]] layers interleaved with position-wise [[Feed Forward Network]] sublayers. By scaling the dot product by 1/√d_k and applying multi-head projections, they achieved state-of-the-art performance on WMT 2014 English-to-German translation (28.4 BLEU) and English-to-French (41.0 BLEU) — surpassing all prior ensemble models — while training in a fraction of the time due to full parallelism. The paper has accumulated over 173,000 citations as of 2025, making it the most cited work in machine learning history. It launched the transformer paradigm that now underlies virtually every frontier AI system.

  The subsequent wave of pre-trained transformer models all use attention weights as their primary information routing mechanism. [[BERT]] (Devlin et al. 2019) applied bidirectional [[Self Attention]] to masked language modelling pretraining, producing contextual token representations that transfer to 11 NLP benchmarks with fine-tuning. [[GPT]] (Radford et al. 2018; GPT-2, 2019; GPT-3, Brown et al. 2020) used causal masked [[Self Attention]] in a decoder-only architecture and demonstrated that scaling alone — more parameters, more data — produced emergent few-shot capabilities. T5 (Raffel et al. 2020) unified virtually all NLP tasks under a text-to-text [[Encoder-Decoder]] with cross-attention linking encoder and decoder. AlphaFold 2 (Jumper et al. 2021) applied attention weights over amino acid pair interactions to achieve near-experimental accuracy in protein structure prediction, demonstrating that the attention weight primitive generalises from language to biology.

  The attention weight interpretability debate produced a precise technical literature with lasting methodological impact. Jain and Wallace (2019) showed that gradient-based feature importances and attention weights are poorly correlated and that counterfactual attention distributions (using a randomised or adversarial assignment) produce similar model outputs — challenging the assumption that high-weight positions are causally important. Wiegreffe and Pinter (2019) responded that interpretability requires specifying what the explanation is for: if attention weights reliably select the same positions a human annotator would consider relevant (in a diagnostic sense), they constitute an explanation under a functional definition even without causal sufficiency. Serrano and Smith (2019) introduced a zeroing test showing that erasing high-attention positions degrades output more than erasing low-attention positions. Pruthi et al. (2020) demonstrated that adversarial training can produce models that compute plausible-looking but deliberately misleading attention patterns while achieving the same accuracy, showing that attention weight patterns are not robust to adversarial manipulation.

  Mechanistic interpretability research, pioneered at Anthropic and DeepMind among others, resolved the debate in a more fundamental way by asking not "are attention weights explanations?" but "what computation do attention heads implement?" Elhage et al. (2021) published a mathematical framework for transformer circuits showing that a two-layer attention-only transformer already implements sophisticated algorithms: induction heads — pairs of heads across consecutive layers where the first head attends to the previous token and the second head attends to positions following that token in the context, enabling in-context learning. Conmy et al. (2023) automated circuit discovery using edge attribution patching, identifying the minimal subgraph of attention heads and MLP layers responsible for a specific model behaviour. Sharkey et al. (2025) identified open problems in mechanistic interpretability at the frontier model scale, including the challenge that real attention head functions are often polysemantic (implementing multiple superposed algorithms) rather than monosemantically clean.

  ## Current Landscape (2026)

  As of June 2026, attention weights remain the dominant routing mechanism in frontier AI models, though their position is increasingly challenged and complemented by linear-complexity alternatives. The largest deployed models — GPT-4o (OpenAI), Claude 3.5 and 3.7 (Anthropic), Gemini 1.5 Pro and 2.0 (Google DeepMind), Llama 3.1 405B (Meta), and Mistral Large — all employ [[Multi-Head Attention]] in decoder-only or encoder-decoder configurations, with context windows ranging from 128K tokens (GPT-4o) to over 1 million tokens (Gemini 1.5 Pro, Gemini 2.0 Flash). The widespread adoption of Grouped Query Attention (GQA) as a replacement for full Multi-Head Attention has substantially reduced the KV-cache memory cost of serving large models at long contexts: GQA shares key and value projections across groups of query heads (typically groups of 4–8), reducing KV-cache size by that factor while preserving most of the expressiveness of full MHA. This optimisation is now standard across the Llama 3, Mistral, Gemma, and Falcon model families.

  Flash Attention 4, released in March 2026 with native NVIDIA B200 (Blackwell) GPU support, provides exact softmax attention computation at approximately 1,605 TFLOPs/s with 71% hardware utilisation — near the theoretical maximum for NVIDIA's latest silicon. By fusing the attention computation into a single CUDA kernel with asynchronous memory transfers and warp specialisation, it eliminates the HBM bandwidth bottleneck that previously made very long context windows impractical even when parameter counts were manageable. This advance directly enables the million-token context windows now offered in production by Gemini 2.0 and comparable systems.

  Hybrid architectures interleaving full attention layers with [[State Space Model]] (SSM) or Mamba layers represent the most active 2026 research frontier for long-context processing. Pure SSMs (Mamba, Gu and Dao 2023) achieve O(n) time and memory complexity with a fixed-size recurrent state but struggle to match transformer attention on tasks requiring precise retrieval from long contexts. Hybrid models (e.g. Jamba by AI21 Labs, Zamba by Zyphr AI) alternate between attention layers (for high-precision cross-position lookup) and Mamba layers (for efficient long-range compression), achieving context lengths of millions of tokens with competitive quality and substantially lower inference cost. The attention weight matrices in these hybrid models remain the primary mechanism for precise content-based retrieval; the SSM layers handle the complementary function of maintaining compressed long-range context state.

  The interpretability of attention weights has matured from a philosophical debate into an engineering programme. Sparse attention post-training (Conmy et al. 2024; Kamath et al. 2025) forces models to concentrate their weights into sparser distributions, enabling automated circuit discovery: the sparse weight matrices directly reveal the computational graphs that implement model behaviours. The "Interpreting Transformers Through Attention Head Intervention" programme (Basile et al. 2026) uses Simultaneous Orthogonal Matching Pursuit (SOMP) to discover which vocabulary token directions best explain each attention head's function, producing vocabulary-level maps of head specialisation across language and vision-language models. Layer-wise Relevance Propagation (LRP) methods have also been revisited in 2026, with positional attribution emerging as a previously missing ingredient: a June 2026 preprint demonstrates that incorporating positional relevance scores alongside token-level relevance substantially improves the faithfulness of attribution explanations for transformer decisions. These tools are finding practical application in [[Explainable AI]] compliance contexts, where regulators (EU AI Act, UK DSIT) require high-stakes AI decisions to be accompanied by human-interpretable justifications.

  The Hugging Face Hub hosts over 2 million models as of Q2 2026 across 50,000+ organisations, the overwhelming majority implementing some variant of scaled dot-product attention. [[Multimodal AI]] systems using [[Cross Attention]] as the inter-modal bridge — combining vision encoders with language decoders — are commercially deployed at scale: Google Gemini, OpenAI GPT-4o with vision, Meta Llama 3.2 multimodal, Anthropic Claude with vision, and Microsoft Phi-3 Vision. The cross-attention weight matrices in these systems, mapping language generation tokens to image region keys, are increasingly used as visual grounding indicators in [[Computer Vision]] and visual question answering, providing a mechanism for humans to verify what the model is "looking at" when generating each word.

  ## UK Context

  The United Kingdom is a globally significant contributor to attention mechanism research through a combination of world-leading AI companies, strong university research groups, and an active national AI strategy (the UK National AI Strategy and subsequent AI Opportunities Action Plan 2025).

  **DeepMind (London)**: Google DeepMind, headquartered in London's King's Cross, is one of the world's foremost contributors to transformer and attention research. Key DeepMind contributions include: the development of multi-query attention (Shazeer 2019) and grouped-query attention (Ainslie et al. 2023) as memory-efficient alternatives to standard MHA; research into long-range transformer efficiency; and the AlphaFold 2 application of attention to protein structure prediction — arguably the most scientifically significant single application of attention weights outside NLP. DeepMind is also a founding contributor to the mechanistic interpretability of attention, publishing circuit-level analyses of induction head function and contributing to the framework for understanding attention head circuits.

  **University of Cambridge**: The Cambridge NLP group and Machine Learning Group maintain active research on attention in [[Natural Language Processing]], including sequence labelling, biomedical entity recognition, and low-resource language modelling. Researchers at Cambridge have published on the interpretability of attention weights in clinical text processing contexts, where the ability to explain which parts of a clinical note drove a model prediction is a patient safety requirement.

  **University of Edinburgh**: The Edinburgh NLP group (home to the Statistical Machine Translation group that pre-dated the transformer era) maintains one of the UK's strongest attention-mechanism and machine translation research programmes. Edinburgh researchers have contributed to evaluation of attention weight distributions in multilingual models, analysis of cross-lingual transfer mechanisms in attention heads, and efficient attention for morphologically rich languages — topics directly relevant to the properties of attention weight matrices across language families.

  **Imperial College London**: Imperial's Computing and Electrical Engineering departments conduct research on attention for [[Computer Vision]] and multimodal tasks. Work includes vision transformers (ViT) applied to medical imaging, cross-modal attention for image-text alignment in radiology report generation, and efficient sparse attention for high-resolution pathology image analysis.

  **University of Manchester**: Manchester's Department of Computer Science and Turing Institute node conduct machine learning research applying attention to healthcare AI, including attention-guided clinical note processing in partnership with NHS trusts, and attention-based time-series analysis for patient deterioration early warning. The 2025 NHS England AI strategy explicitly references Manchester as a centre for trustworthy AI in secondary care, with explainability of attention weights a priority for regulatory acceptance.

  **University of Leeds and Newcastle University**: Both institutions contribute to [[Speech Recognition]] research employing attention-based sequence-to-sequence models, with Leeds working on accent-robust ASR and Newcastle contributing to accessibility technology for regional dialect speakers. Newcastle's Digital Institute has collaborated on attention-based NLP for heritage language processing and accessibility applications.

  Northern England's emerging AI industrial cluster — anchored in Manchester's NOMA district (AstraZeneca AI centre, Amazon AWS Manchester, Siemens AI lab), the Leeds Digital Festival ecosystem, and the Sheffield-Hallam Industrial AI Hub — increasingly deploys attention-based models for financial services fraud detection, NHS secondary care analytics, and legal document processing. The Northern Powerhouse Partnership's 2025 AI roadmap identifies attention-based [[Large Language Model]] as a priority deployment target for regional enterprise adoption, with the Manchester-Leeds corridor hosting over 400 AI-active companies by Q1 2026.

  ## Future Directions (2026–2030)

  The trajectory of attention weight research over the next four years points toward several convergent and occasionally competing themes, shaped by the dual pressures of frontier model capability scaling and increasing regulatory demand for explainability:

  **Mechanistic completeness at scale**: The mechanistic interpretability programme has achieved detailed circuit-level understanding of specific behaviours in models up to approximately 7 billion parameters. Extending this methodology to frontier models (100B–1T parameters) remains a major open challenge: the number of potential circuits grows super-exponentially, and current automated circuit discovery methods (edge attribution patching) are computationally expensive relative to model scale. Research priorities include developing scalable superposition decomposition techniques (sparse autoencoders applied to residual stream directions), hierarchical circuit abstractions that summarise macro-behaviour without enumerating every micro-circuit, and formal verification methods that certify properties of attention head function rather than merely observing them empirically.

  **Sparse and adaptive attention**: The field is moving from static sparse patterns (Longformer, BigBird, Sparse Transformer) toward dynamically computed sparsity — systems where the model learns which query-key pairs require full attention based on content, allocating full-precision attention weights only to the most informative interactions. Approaches include learned token routing (routing each key to a subset of queries), content-based recall mechanisms (the model first identifies candidate positions using a fast lookup, then applies full attention only to those), and hierarchical attention with coarse-then-fine selection. These methods could reduce effective attention cost from O(n²) toward O(n log n) or O(n × k) for constant k retrieved positions, enabling practical attention over document-scale contexts of millions of tokens.

  **Structured and relational attention**: Incorporating domain-specific structural inductive biases into attention weight computation — tree-structured attention for parsing, graph-structured attention for knowledge graphs and molecular graphs, temporal-hierarchical attention for time-series and genomic sequences — allows the attention weight matrices to encode relational structure rather than treating all position pairs as equally plausible. Integration with [[Graph Neural Network]] architectures is particularly active: graph transformer models (Graphormer, Kreuzer et al.; GT, Dwivedi et al.) apply attention weights over graph-adjacent nodes, enabling transformer-style [[Self Attention]] to operate over irregularly structured data including protein interaction networks, knowledge graphs, and social network graphs.

  **Neuromorphic and energy-efficient attention**: At the trillion-parameter scale, the energy cost of attention weight computation becomes a significant environmental and economic constraint. Research into event-driven, asynchronous attention on neuromorphic processors (Intel Loihi, IBM NorthPole) aims to achieve orders-of-magnitude energy efficiency gains by computing attention weights only when input spikes arrive rather than synchronously at every time step. This requires fundamentally rethinking the synchronous matrix multiplication at the heart of scaled dot-product attention, potentially through spike-timing-dependent plasticity analogues.

  **Regulatory compliance and certified explainability**: The EU AI Act (applicable from August 2026) classifies high-risk AI systems in healthcare, education, employment, and critical infrastructure as requiring human oversight and explainability for consequential decisions. The UK DSIT's AI Regulation Pro-Innovation Approach positions sector regulators (FCA for finance, CQC for healthcare, Ofsted for education) as primary AI oversight bodies, each developing their own explainability requirements. This creates demand for principled, auditable methods of extracting human-interpretable explanations from attention weight matrices — or, where attention weights cannot provide this, developing alternative explanation methods (SHAP, LIME, saliency maps) that meet legal standards of sufficient explanation. Research into "legally admissible attention" — attention weight summaries that satisfy specific evidential standards for regulatory submissions — is a nascent but commercially important area.

  **Attention in multiagent and agentic systems**: As AI agents interact with tools, external memory stores, and other agents, the attention mechanism must extend beyond intra-sequence self-attention to cross-agent and cross-context attention. Retrieval-augmented generation (RAG) systems apply attention weights over retrieved document chunks; memory-augmented transformers apply attention over persistent external memory banks; multi-agent communication protocols require models to attend over other agents' outputs. The [[Large Language Model]] underpinning agentic systems will increasingly use attention weights as the mechanism for prioritising which pieces of retrieved or agent-communicated information to incorporate, making the reliability and interpretability of cross-context attention weights a critical property for trustworthy agentic AI systems.

  ## Attention Weights in Domain Applications

  The attention weight mechanism has been applied far beyond its original [[Machine Translation]] context, enabling transformative capabilities across a diverse range of domains that collectively demonstrate the generality of the differentiable, learned-relevance primitive:

  **[[Natural Language Processing]] and understanding**: Attention weights are the core mechanism enabling [[BERT]]'s bidirectional context representation, [[GPT]]'s autoregressive language modelling through [[Causal Language Modelling]], and T5's [[Sequence-to-Sequence Learning]] across multiple NLP tasks. In named entity recognition, the attention weights over a token's context determine what surrounding information is incorporated into the token's contextual representation — enabling the model to resolve entity boundary ambiguity, coreference, and entity type disambiguation. In [[Machine Translation]], cross-attention weights map source language token representations to target language generation steps, providing a learned alignment between source and target sequences. In document summarisation, attention weights over a long source document determine which passages contribute to each token of the generated summary — the primary mechanism enabling abstractive summarisation that goes beyond extractive sentence selection.

  **[[Computer Vision]] with Vision Transformers**: The [[Vision Transformer]] (ViT, Dosovitskiy et al. 2021) applies attention weights over sequences of fixed-size image patches, enabling the model to identify which patches are most relevant to the classification task. Unlike convolutional [[Neural Network]] receptive fields, attention weights in ViT are not spatially constrained — a patch in the top-left corner can attend to a patch in the bottom-right corner with the same computational cost as attending to an adjacent patch. This global receptive field enables ViT to capture long-range spatial dependencies critical for scene-level understanding. The attention weight matrices in ViT are particularly amenable to visualisation as attention maps — showing which image regions the model attends to when making predictions — providing a natural interface for [[Explainable AI]] in visual applications. Attention maps have been used in medical imaging to validate that diagnostic AI systems are attending to clinically relevant image regions rather than imaging artefacts.

  **[[Protein Structure Prediction]]**: [[AlphaFold]] 2 (Jumper et al. 2021) applied attention weights over amino acid pair interactions within its Evoformer module, enabling the model to integrate evolutionary co-variation signals (from multiple sequence alignments of homologous proteins) with pairwise structural geometry predictions. The attention weights in AlphaFold encode which residue pairs have evolutionarily correlated mutations — a signal that implies structural contact — and propagate this information through iterative attention refinement. The result was prediction accuracy approaching experimental crystallography for many protein families, a landmark achievement enabled by the attention mechanism's ability to integrate information over arbitrary-length amino acid sequences without the positional locality constraints of convolutional architectures.

  **[[Speech Recognition]]**: Sequence-to-sequence attention models (Listen, Attend, and Spell; LAS) and CTC-attention hybrid models use cross-attention weights to align acoustic frame representations with output character or subword token predictions. The attention weights provide an implicit learned alignment between the input audio spectrum (represented as a sequence of acoustic features) and the output transcript — effectively replacing the explicit alignment step required by traditional HMM-based ASR systems. Transformer-based ASR systems (wav2vec 2.0, Whisper) now achieve near-human word error rates on clean English speech and competitive performance on accented and dialectal speech variants relevant to UK [[Speech Recognition]] applications (including Scottish, Northern English, and Welsh accents).

  **[[Graph Neural Network]] integration**: Graph Attention Networks (GATs, Veličković et al. 2018) apply attention weights over graph neighbourhoods — for each node, computing attention coefficients over its adjacent nodes' feature representations, then aggregating neighbour features weighted by these coefficients. The attention mechanism enables the model to selectively weight the influence of different neighbours, allowing semantically meaningful but irregularly structured graph data (protein interaction networks, knowledge graphs, social networks, molecular graphs) to be processed through the same differentiable routing paradigm as sequence data. Graph transformers extend this further by applying full attention over all node pairs (not just graph-adjacent ones), enabling the model to discover structural relationships beyond the immediate graph topology.

  **[[Multimodal AI]] and [[Image Captioning]]**: Cross-attention between visual and linguistic representations is the key mechanism enabling models to generate captions for images ([[Image Captioning]]), answer questions about photographs (visual QA), generate images from text descriptions (text-to-image generation via diffusion transformers), and integrate speech, vision, and text in unified multimodal systems. In image captioning, attention weights over visual patch representations determine which visual regions contribute to each generated caption word — providing a natural alignment between linguistic and visual content that can be visualised and evaluated for correctness. The [[Cross Attention]] weight matrices in these systems are increasingly used as visual grounding evidence in explainability contexts.

  ## The Interpretability Landscape: From Attention Weights to Circuits

  The question of what attention weights reveal about model behaviour has evolved considerably since the initial debates of 2019. Three distinct positions now coexist in the research community:

  The **attention-as-explanation** position holds that attention weights provide at least partial, functional-level explanation of model behaviour. In this view, an attention weight matrix that places high weight on the subject noun when predicting the main verb correctly identifies the causal structure underlying a subject-verb agreement prediction, even if it does not constitute a complete mechanistic account. Proponents argue that this is sufficient for practical [[Explainable AI]] applications where the goal is to support human understanding and oversight rather than provide a complete causal chain.

  The **attention-as-symptom** position (dominant in the mechanistic interpretability community) holds that raw attention weights are an artefact of the computational substrate rather than the explanatory level of interest. What matters is not which positions receive high attention weights but what algorithm the attention head is implementing — and that algorithm is identified by circuit analysis (activation patching, path decomposition) rather than weight inspection. Under this view, attention weight visualisations may correlate with model behaviour in many cases but can be systematically misleading when heads implement complex, indirect computations. This position motivates the development of mechanistic interpretability as a distinct discipline focused on identifying and verifying the computational circuits that implement [[Large Language Model]]' capabilities.

  The **attention-as-probe** position holds that attention weights are a useful diagnostic signal when interpreted with appropriate caution: not as complete explanations, but as lightweight probes that can quickly identify whether a model is attending to expected features, flag potential failure modes, and guide deeper investigation. Under this view, attention weight visualisation is most valuable as a first-pass diagnostic in [[Explainable AI]] workflows — sufficient to identify obvious failures (e.g. an [[Image Captioning]] model ignoring the described object) and to generate hypotheses for more rigorous circuit-level investigation.

  These positions have practical implications for how attention weights are used in production AI systems. Healthcare AI applications (clinical NLP tools used in NHS trusts, for example) often use attention weight visualisations as evidence summaries — showing clinicians which parts of a note the model used when generating a risk score. The evidential validity of these summaries is contested: they may be accurate representations of the model's focus (supporting the attention-as-probe position) or potentially misleading if the underlying computation relies on distributed, superposed representations that the attention matrix does not directly capture (supporting the attention-as-symptom position). UK regulatory guidance on AI explainability (from DSIT and the NHS AI Lab) is beginning to engage with this technical debate, with implications for how AI product documentation must characterise the role of attention weight visualisations in clinical decision support workflows.

  The integration of attention weight analysis with [[Transfer Learning]] and [[Self-Supervised Learning]] pre-training paradigms has created the modern foundation model ecosystem. Models pre-trained via [[Backpropagation]] on massive corpora develop attention weight matrices that encode rich linguistic and world knowledge through the statistics of co-occurrence. [[Retrieval-Augmented Generation]] systems extend this by providing an explicit external memory — retrieved document chunks — that is integrated into the model's context via cross-attention weight allocation, effectively allowing the model to decide how much weight to give each retrieved document passage when generating an answer. The attention weights in RAG systems thus serve a dual function: as information routing within the model's context window and as an implicit document relevance re-ranking that could in principle be inspected to understand why the model drew on certain sources over others.

  [[Dropout]] regularisation, applied during training, has a subtle but important interaction with attention weight learning: by randomly zeroing out value vectors during training, dropout prevents the model from over-relying on any single attention head's information pathway, encouraging redundant representations across multiple heads that together constitute a more robust overall routing strategy. [[Batch Normalisation]] is not typically applied within transformer attention (replaced by [[Layer Normalisation]] which normalises across features rather than across batch), but the normalisation philosophy — preventing statistical covariate shift that would destabilise attention weight distributions across layers — is critical to the trainability of very deep transformer stacks.

  ## Research and Literature

  1. Bahdanau, D., Cho, K., & Bengio, Y. (2015). Neural Machine Translation by Jointly Learning to Align and Translate. *ICLR 2015*. arXiv:1409.0473.
  2. Luong, M.-T., Pham, H., & Manning, C. D. (2015). Effective Approaches to Attention-based Neural Machine Translation. *EMNLP 2015*. arXiv:1508.04025.
  3. Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, L., & Polosukhin, I. (2017). Attention Is All You Need. *NeurIPS 2017*, 30, 5998–6008. arXiv:1706.03762.
  4. Devlin, J., Chang, M.-W., Lee, K., & Toutanova, K. (2019). BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding. *NAACL-HLT 2019*. arXiv:1810.04805.
  5. Jain, S., & Wallace, B. C. (2019). Attention is not Explanation. *NAACL-HLT 2019*. arXiv:1902.10186. https://aclanthology.org/N19-1357/
  6. Wiegreffe, S., & Pinter, Y. (2019). Attention is not not Explanation. *EMNLP 2019*. arXiv:1908.04626. https://aclanthology.org/D19-1002/
  7. Serrano, S., & Smith, N. A. (2019). Is Attention Interpretable? *ACL 2019*. arXiv:1906.03731.
  8. Clark, K., Khandelwal, U., Levy, O., & Manning, C. D. (2019). What Does BERT Look at? An Analysis of BERT's Attention. *BlackboxNLP 2019*. arXiv:1906.04341.
  9. Radford, A., Wu, J., Child, R., Luan, D., Amodei, D., & Sutskever, I. (2019). Language Models are Unsupervised Multitask Learners. *OpenAI Blog*.
  10. Raffel, C., et al. (2020). Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer. *JMLR*, 21(140), 1–67. arXiv:1910.10683.
  11. Dao, T., Fu, D. Y., Ermon, S., Rudra, A., & Ré, C. (2022). FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness. *NeurIPS 2022*. arXiv:2205.14135.
  12. Elhage, N., et al. (2021). A Mathematical Framework for Transformer Circuits. *Transformer Circuits Thread*. https://transformer-circuits.pub/2021/framework/
  13. Conmy, A., Mavor-Parker, A., Lynch, A., Heimersheim, S., & Garriga-Alonso, A. (2023). Towards Automated Circuit Discovery for Mechanistic Interpretability. *NeurIPS 2023*. arXiv:2304.14997.
  14. Dosovitskiy, A., et al. (2021). An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale. *ICLR 2021*. arXiv:2010.11929.
  15. Ainslie, J., et al. (2023). GQA: Training Generalised Multi-Query Transformer Models from Multi-Head Checkpoints. *EMNLP 2023*. arXiv:2305.13245.
  16. Su, J., et al. (2024). RoFormer: Enhanced Transformer with Rotary Position Embedding. *Neurocomputing*, 568. arXiv:2104.09864.
  17. Gu, A., & Dao, T. (2023). Mamba: Linear-Time Sequence Modelling with Selective State Spaces. *arXiv*:2312.00752.
  18. Sharkey, L., et al. (2025). Open Problems in Mechanistic Interpretability. *arXiv*:2501.16496.
  19. Kamath, A., et al. (2025). Weight-Sparse Transformers have Interpretable Circuits. *arXiv*:2511.13653.
  20. Conmy, A., et al. (2024). Sparse Attention Post-Training for Mechanistic Interpretability. *arXiv*:2512.05865.
  21. Basile, V., et al. (2026). Interpreting Transformers Through Attention Head Intervention. *arXiv*:2601.04398.
  22. Dao, T. (2024). FlashAttention-3: Fast and Accurate Attention with Asynchrony and Low-precision. *arXiv*:2407.08608.
  23. Pruthi, D., Gupta, M., Dhingra, B., Neubig, G., & Lipton, Z. C. (2020). Learning to Deceive with Attention-Based Explanations. *ACL 2020*. arXiv:1909.07913.
  24. Choromanski, K., et al. (2021). Rethinking Attention with Performers. *ICLR 2021*. arXiv:2009.14794.
  25. Beltagy, I., Peters, M. E., & Cohan, A. (2020). Longformer: The Long-Document Transformer. *arXiv*:2004.05150.
  26. Child, R., Gray, S., Radford, A., & Sutskever, I. (2019). Generating Long Sequences with Sparse Transformers. *arXiv*:1904.10509.
  27. Chefer, H., Gur, S., & Wolf, L. (2021). Transformer Interpretability Beyond Attention Visualization. *CVPR 2021*. arXiv:2012.09838.

### Provenance

