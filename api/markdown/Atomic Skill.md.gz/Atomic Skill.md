
An atomic skill is an "atomic, machine-executable operation with defined parameters", declared as `Skill` in the Agent Ontology's capability module.[^1] The same comment states that a capability "is composed of one or more Skills", and the `hasSkill` property links an [[Agent Capability]] to the skills that implement it.

Skills are the low-level half of the ontology's split between high-level semantic capabilities and executable skills. A skill has a `skillId` and a `description`, takes zero or more [[Skill Parameter]] values through `hasParameter`, and may depend on other skills through `dependsOnSkill`.[^1] The schema.org mapping module declares `Skill` a subclass of `schema:Action`.[^2]

This is not the packaged prompt skill described at [[Agent Skill]]. The ontology's skill is an executable operation with typed parameters, whereas an agent skill in that other sense is a bundle of instructions an agent loads.

[^1]: Semantic Agent Communication Community Group, “Capability Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/capability.ttl
[^2]: Semantic Agent Communication Community Group, “Agent Ontology to Schema.org Mapping” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/schema-org-mapping.ttl

