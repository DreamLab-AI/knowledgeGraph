A type system is a formal component of a programming language that classifies values and expressions into types and defines rules constraining how they may be combined. It is enforced by a checker that rejects programs violating these rules, preventing classes of errors before or during execution. Type systems vary along axes such as static versus dynamic checking, strength, and expressiveness, trading safety guarantees against flexibility.

- A type system classifies the values of a [[Programming Language]] into types and constrains their use, with a checker rejecting ill-typed programs. It is often enforced by the [[Compiler]] and is exemplified by gradually typed languages such as [[TypeScript]].

### Overview

- Types give names and structure to the data a program manipulates, letting the language reason about correctness before code runs.
- A type checker uses the system's rules to prove that operations are applied only to compatible values, ruling out whole categories of bugs.
- Design choices span static versus dynamic checking, nominal versus structural typing, and the richness of features such as generics and inference.

### Mechanisms

- Type inference deduces types from context so developers annotate less while retaining checking.
- A static checker, typically inside the [[Compiler]], verifies the program against typing rules ahead of execution.
- Generics and parametric polymorphism let a single definition operate over many types safely.
- Structural typing matches values by shape, underpinning flexible [[Interface]] and [[API]] contracts.

### Applications

- Catching errors at build time across large [[Software Engineering]] codebases.
- Documenting and enforcing module and [[API]] boundaries.
- Enabling editor tooling such as autocompletion and refactoring.
- Supporting [[Quality Assurance]] by encoding invariants in types.

### Provenance

