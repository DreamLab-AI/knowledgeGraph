On-time in-full (OTIF) is a delivery performance measure of the extent to which shipments are delivered to their destination according to both the quantity and the schedule specified on the order.[^1]

McKinsey reports that in practice there is no standard definition for OTIF, so different supply chain participants may interpret the metric in significantly different ways.[^1] It lists the open questions. Does on-time mean the date requested by the retailer or the date promised by the manufacturer? Does it mean a specific delivery slot or any time inside a broader agreed window? Should in-full be measured at the level of complete orders, line items or individual cases?[^1]

## A proposed standard

McKinsey and the Trading Partner Alliance surveyed 24 major retailers and consumer-goods makers in North America in 2019. Of those companies, 92 percent agreed that an industry standard for OTIF would create value.[^1] The working definition drawn from the survey is a case quantity that is delivered to the destination by the requested delivery date, calculated as a percentage of the ordered quantity.[^1] McKinsey presents this as a proposal for consideration, not as an adopted standard.[^1]

## Why it matters

McKinsey says manufacturers must keep track of changing OTIF definitions because retailers impose financial penalties for noncompliance.[^1] The measure sits under [[Delivery Performance Measure]], next to [[Fill Rate]]. McKinsey says the consumer industry moved away from the traditional “case-fill rate” towards OTIF.[^1]

## Relation to SCOR

SCOR 12.0 lists Perfect Order Fulfillment at level 1 and, at level 2, % of Orders Delivered In Full and Delivery Performance to Customer Commit Date.[^2] The quick reference guide opened gives only these names, so this page does not say whether any of them is equivalent to OTIF.

## What the sources do not establish

Evidence is one consultancy article reporting one survey, plus SCOR metric names. The survey is a sample of 24 companies in North America, and McKinsey notes that it found no consensus on the window within which a delivery counts as on time.[^1] The page makes no claim about typical OTIF levels or penalty sizes.

[^1]: McKinsey & Company (Alan Davies, Shruti Lal, Fernando Perez and Sanjhali Potdar), “Defining ‘on-time, in-full’ in the consumer sector”, 13 June 2019 (Internet Archive copy). https://web.archive.org/web/2024/https://www.mckinsey.com/capabilities/operations/our-insights/defining-on-time-in-full-in-the-consumer-sector
[^2]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf

