Direct procurement is, in the usual supply chain sense, the purchasing of materials that are incorporated into the product being made, as against indirect procurement of what is consumed or used around production.[^1][^2]

No opened source defines the phrase direct procurement. The nearest sourced distinction is in United States customs rules, which define a material as a good incorporated into another good as a result of production, including parts, ingredients, subassemblies and components, and define indirect materials as goods used in production, testing or inspection but not physically incorporated, such as fuel and energy, tools, dies and molds, and spare parts.[^1] Those rules are written for determining origin, not for purchasing, so they bound the sense rather than define the term.[^1]

An abstract of an undergraduate honors thesis at Western Michigan University says indirect procurement suffers from a confusing nomenclature and has largely been ignored in scholarly research because it represents a small portion of a firm's expenditures; it points to maintenance, repair and operations and information technology purchasing as the main research areas.[^2]

## Scope and distinctions

In public procurement law, direct has a different meaning. UNCITRAL defines direct solicitation as solicitation addressed directly to one supplier or contractor or a restricted number of them, excluding solicitation to a limited number following pre-qualification or pre-selection.[^3] See [[Indirect Procurement]], [[Procurement]] and [[Bill of Materials]].

## What the sources do not establish

This page rests on a customs definition and a thesis abstract, and no purchasing source defining direct procurement was opened, so the private-sector sense is inferred from the contrast with indirect materials.[^1][^2]

[^1]: US Code of Federal Regulations, 19 CFR 102.1 (rules of origin), Cornell Legal Information Institute copy, “19 CFR § 102.1 - Definitions”. https://www.law.cornell.edu/cfr/text/19/102.1
[^2]: Daniel Israel, Western Michigan University honors thesis (ScholarWorks record with abstract), “Trends in the Study of Indirect Procurement”. https://scholarworks.wmich.edu/honors_theses/3190/
[^3]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf

