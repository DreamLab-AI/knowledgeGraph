
An agent delegation is a structured transfer of authority that allows one agent to act, under a bounded and semantically defined scope, on behalf of another.[^1] visionGraph places it under [[Agent Relationship]] and [[Authorisation]].

The core module defines the relation with `delegatesTo` and `delegatedBy`, both ranging over agents.[^2] The delegation module adds a `delegationId`, a `note`, and a `delegationScope` whose value is a [[Delegation Scope]]. It also links the delegation to the actions it permits and to trace records. The threat-model module describes the same relation as an assignment of authority or responsibility between agents, with `delegatedTo` and `delegatedFrom`.[^3]

Delegations can be strung together in a [[Delegation Chain]]. A task handed on in this way is a [[Task Delegation]], and an [[Agent Trace Event]] can record the hand-over.

The term is unrelated to proof-of-stake [[Delegation]]; the two contrast, and the agent sense takes this title.

[^1]: Semantic Agent Communication Community Group, “Delegation Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/delegation.ttl
[^2]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^3]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl

