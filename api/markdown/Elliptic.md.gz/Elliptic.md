Elliptic is a blockchain analytics and financial crime compliance company that provides software tools to trace, analyse, and risk-score cryptocurrency transactions across multiple blockchain networks. Its technology maps on-chain flows to real-world entities — exchanges, darknet markets, ransomware wallets, and sanctioned addresses — enabling financial institutions, crypto businesses, and law enforcement to detect and prevent money laundering, terrorist financing, and sanctions evasion. Elliptic's transaction monitoring and wallet screening solutions are used by regulated virtual-asset service providers globally to satisfy AML/CFT obligations under frameworks such as the FATF Travel Rule and MiCA.

### Overview

- Elliptic was among the first dedicated cryptocurrency compliance companies, emerging from the recognition that the pseudonymous nature of [[Bitcoin]] and other cryptocurrencies created both risk and investigative opportunity.
- Rather than viewing blockchain transparency as a privacy threat, Elliptic treats it as a compliance asset: every transaction is permanently recorded on a public ledger, making historical tracing possible in ways unavailable with traditional cash.
- The company operates primarily as a B2B software and data provider, serving [[Cryptocurrency Exchange]]s, [[Financial Institution]]s, custodians, payment processors, and government agencies.
- Its core product lines cover:
  - **Wallet screening** — real-time risk assessment of counterparty wallets before a transaction is accepted or executed.
  - **Transaction monitoring** — post-trade surveillance of flows to detect patterns consistent with [[Money Laundering]], ransomware payments, or [[Terrorist Financing]].
  - **Investigations** — case management and visualisation tools used by compliance officers and law enforcement for forensic tracing.
- Elliptic is headquartered in London, with offices in New York, Singapore, and Tokyo, reflecting the global spread of [[Cryptocurrency]] regulation.

### Key Components

#### Data Layer

- **On-Chain Data Ingestion** — Elliptic ingests full [[Blockchain]] history for [[Bitcoin]], [[Ethereum]], and many other networks, maintaining a continuously updated ledger database.
- **Entity Attribution Database** — a proprietary intelligence dataset mapping clusters of addresses to named entities (exchanges, darknet markets, mixing services, sanctioned persons). This is built from open-source intelligence, court records, industry feeds, and internal research.
- **Cross-Chain Coverage** — the platform extends beyond Bitcoin to cover [[Ethereum]], [[Stablecoins]] (USDT, USDC), [[Decentralised Finance]] protocols, and NFT markets, reflecting the breadth of modern [[Digital Asset]] activity.

#### Analytics Engine

- **[[Heuristic Clustering]]** — the co-spend (common-input ownership) heuristic groups addresses that appear together as inputs in a transaction, inferring they share a private key holder. This is the foundational technique for de-anonymising [[Bitcoin]] UTXO graphs.
- **[[Graph Analytics]]** — transaction flows are modelled as directed graphs; Elliptic applies graph traversal and [[Network Analysis]] algorithms to follow funds across multiple hops, identifying indirect exposure to illicit sources.
- **Subgraph-level [[Machine Learning]]** — recent capabilities apply graph neural networks to classify subgraphs of transaction activity, improving detection of novel laundering typologies not captured by rule-based heuristics.
- **[[Risk Scoring]]** — each wallet and transaction receives a composite risk score derived from direct and indirect exposure to flagged entities, weighted by proximity in the transaction graph.

#### Compliance Workflows

- **API Integration** — RESTful APIs allow crypto businesses to embed real-time screening into their onboarding and transaction processing pipelines.
- **Case Management** — an investigator dashboard provides visualisation of transaction flows, evidence collection, and audit trails for regulatory reporting.
- **[[Suspicious Activity Report]] (SAR) Assistance** — tools help compliance teams draft and file SARs with financial intelligence units such as the UK's [[National Crime Agency]] or the US [[FinCEN]].

### Applications and Use Cases

#### Virtual Asset Service Provider Compliance

- Crypto exchanges, brokers, and custodians use Elliptic's wallet screening API to check deposit and withdrawal addresses against its entity database at onboarding and in real time, fulfilling obligations under the [[FATF Travel Rule]] and local [[Anti-Money Laundering]] directives.

#### Bank Correspondent Compliance

- Banks offering crypto-friendly correspondent services or acquiring merchant payment processors use Elliptic to assess the risk profile of counterparty VASPs, satisfying de-risking and [[Know Your Customer]] requirements without blanket exclusion of crypto businesses.

#### Law Enforcement Investigations

- National cybercrime units and financial intelligence units use Elliptic's investigation tools to trace ransomware payments, darknet market proceeds, and fraud funds, producing evidence-grade reports for prosecution. Notable investigations have used blockchain tracing to recover seized crypto assets.

#### DeFi and NFT Risk

- As illicit actors shift to [[Decentralised Finance]] protocols and NFT markets to launder funds, Elliptic has extended coverage to smart-contract-based flows, detecting wash trading, mixer usage, and cross-protocol layering.

#### Sanctions Compliance

- Following OFAC designations of cryptocurrency addresses (e.g. Tornado Cash in 2022), Elliptic provides real-time screening against OFAC, EU, UN, and FATF sanctions lists, enabling clients to block transactions with designated wallets.

#### Stablecoin Monitoring

- With the growth of [[Stablecoins]] as settlement assets, Elliptic tracks USDT and USDC flows, including freeze-list lookups tied to issuer blacklists maintained by Tether and Circle.

### Standards and Regulatory Context

- **[[FATF Travel Rule]]** (Recommendation 16) — requires VASPs to share originator and beneficiary information on transfers above a threshold. Elliptic provides data to support Travel Rule compliance by enriching counterparty VASP profiles.
- **[[EU Fifth Anti-Money Laundering Directive]]** (5AMLD) and **[[MiCA]]** — European frameworks bringing crypto assets under AML supervision. Elliptic's European clients use its tools to satisfy obliged-entity requirements under these regulations.
- **[[Bank Secrecy Act]]** and FinCEN guidance — in the United States, money services businesses and exchanges must file SARs and maintain transaction monitoring programmes; Elliptic supports both.
- **[[OFAC]]** Sanctions Programme — Elliptic's sanctions screening covers OFAC's SDN list and designations of specific cryptocurrency addresses, enabling clients to block prohibited transactions.
- **[[ISO 20022]]** — as blockchain-based payment systems converge with traditional payment messaging standards, Elliptic's data enrichment feeds into compliance workflows that must align with richer ISO 20022 structured data fields.
- Elliptic is a member of the **[[Global Digital Finance]]** (GDF) industry body and contributes to typology guidance developed by the [[Egmont Group]] and [[FATF]].

### Competitive Landscape

- The blockchain analytics market includes several specialist firms:
  - **[[Chainalysis]]** — the largest by market share, US-headquartered, with strong law enforcement partnerships and government contract revenue.
  - **[[CipherTrace]]** — acquired by Mastercard in 2021, integrating blockchain intelligence into traditional card network compliance workflows.
  - **[[TRM Labs]]** — focuses heavily on DeFi and cross-chain risk, with rapid growth in the US government sector.
  - **[[Merkle Science]]** — Asia-Pacific focused, with localised entity coverage for exchanges in that region.
- Elliptic differentiates through its London base (EMEA regulatory expertise), depth of DeFi coverage, and academic research partnerships with institutions such as MIT.

### Provenance

