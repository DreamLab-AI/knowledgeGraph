Multi-tier supply chain mapping is the practice of identifying and charting the suppliers that sit behind a firm's direct suppliers, to the second, third and further tiers upstream.[^1]

Sedex describes visibility beyond tier 1 as an organisation's ability to understand and monitor the suppliers that sit behind its direct suppliers, including tier 2, tier 3 and further upstream entities.[^1] In its usage tier 1 suppliers are the companies a buyer buys from directly, tier 2 are suppliers to those, and tier 3 are suppliers further upstream, often providing raw materials or basic processing.[^1] It says that visibility means knowing who is involved, where they are located and what risks may exist, even without a direct commercial relationship.[^1] Sedex is a practitioner body, and its article is a guide, not a standard.

## Why it is done

Christopher and Peck, writing for supply chain resilience, say that a fundamental pre-requisite is an understanding of the network that connects a business to its suppliers and their suppliers and to its downstream customers, and that mapping tools can help in the identification of pinch points and critical paths.[^2] NIST asks enterprises in its cybersecurity guidance to attempt to identify single points of failure and risk among primes and lower-level entities, and it points to upstream dependencies such as fourth- and fifth-party suppliers.[^3]

## Difficulties

The Center for Climate and Energy Solutions lists limited supplier transparency and poor data quality among the barriers to integrating climate risk into supply chain resilience work.[^4] That finding is about climate risk assessment, but it indicates the same data problem that limits mapping.

## Scope and limits

Mapping supports [[Supply Chain Risk Management]] and the study of propagation at [[Ripple Effect]]. It also supports the identification of [[Supplier Concentration Risk]], which depends on knowing which sub-tier firms are shared.

None of the opened sources specifies a method, a standard data model or a measure of completeness for a multi-tier map, and none reports how far beyond tier 1 firms typically map. This page is therefore a description of intent and difficulty, not of method.

[^1]: Sedex (Supplier Ethical Data Exchange), article, “Supply Chain Visibility Beyond Tier 1: How to Achieve It”. https://www.sedex.com/blog/supply-chain-visibility-beyond-tier-1/
[^2]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^3]: National Institute of Standards and Technology, NIST Special Publication 800-161r1-upd1 (May 2022, updated), “Cybersecurity Supply Chain Risk Management Practices for Systems and Organizations”. https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-161r1-upd1.pdf
[^4]: Center for Climate and Energy Solutions (C2ES), September 2025, “Assessing the Landscape of Climate Risk and Supply Chain Resilience: A Primer for Corporate Leaders and Climate Risk Professionals”. https://www.c2es.org/wp-content/uploads/2025/09/Climate-Risk-and-Supply-Chain-Report_FINAL_v3.pdf

