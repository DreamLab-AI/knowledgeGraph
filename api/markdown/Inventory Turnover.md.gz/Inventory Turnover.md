Inventory turnover is a ratio that measures the number of times an average quantity of inventory was bought and sold during a period.[^1]

OpenStax's accounting textbook computes it by dividing cost of goods sold by average inventory, and describes the result as the number of times inventory rotated through the sales cycle for the period.[^1] A higher figure means more rotations of the average stock in the period.[^1]

## Reading the figure

OpenStax's worked example shows a company whose turnover is lower in the second year than the first, which it calls not a positive trend. It says such a result would alert management that the inventory balance might be too high to be practical for the volume of sales, and that comparison should also be made to competitor and industry ratios.[^1] A single figure therefore has little meaning without a comparator.

## Related measures

That chapter pairs turnover with number of days' sales in inventory, computed by dividing average merchandise inventory by the average daily cost of goods sold.[^1] SCOR 12.0 expresses a similar idea as a time measure, Inventory Days of Supply, and also lists Costs of Goods Sold among its level-1 cost metrics.[^2] See [[Inventory Performance Measure]].

## Scope and distinctions

Its formula comes from financial accounting, where inventory and cost of goods sold are statement items.[^1] The aliases Stock Turn and Inventory Turns do not appear in the sources opened here, and the sources do not discuss using sales instead of cost of goods sold in the numerator, or averaging over more than two balances.

## What the sources do not establish

Evidence is one open textbook, and SCOR adds only metric names. The sources give no benchmark ranges, no industry comparisons and no guidance on seasonality. A turnover figure is therefore a ratio to be read against the same firm's earlier periods and its peers, and this page states no target.[^1][^2]

[^1]: OpenStax, “10.5 Examine the Efficiency of Inventory Management Using Financial Ratios”, Principles of Accounting, Volume 1: Financial Accounting. https://openstax.org/books/principles-financial-accounting/pages/10-5-examine-the-efficiency-of-inventory-management-using-financial-ratios
[^2]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf

