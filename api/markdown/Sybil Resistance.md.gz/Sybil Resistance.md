Sybil resistance is a security property of distributed and decentralised networks that constrains the ability of a single adversary to gain disproportionate influence by fabricating multiple pseudonymous or fake identities. The property is foundational to any permissionless system where voting power, reputation, resource allocation, or participation rights are tied to the concept of a unique participant. Mechanisms achieving sybil resistance range from resource-binding consensus protocols — proof-of-work and proof-of-stake — to cryptographic proof-of-personhood schemes and social trust-graph analysis, each balancing security guarantees against privacy requirements.

### Overview

- Sybil resistance emerged as a formalised concern alongside early peer-to-peer overlay networks (Gnutella, Chord, Pastry) where routing tables could be manipulated by flooding the network with adversary-controlled nodes. The concept became central to [[Blockchain]] design because all major consensus mechanisms must ensure that no single entity controls enough "votes" — whether measured in hashing power or staked capital — to rewrite the ledger.
- The fundamental challenge is that in an open, pseudonymous network there is no a priori way to distinguish one real participant controlling many accounts from many independent participants. Any effective sybil-resistance mechanism must introduce a **cost** or **binding** that makes mass identity creation prohibitively expensive, physically impossible, or cryptographically detectable.
- Three broad approaches exist:
  - **Resource binding**: tie identity to scarce real-world resources (compute, capital, bandwidth).
  - **Social/graph attestation**: use a trust graph structure where real humans vouch for each other, making it hard to bootstrap many synthetic identities.
  - **Biometric or cryptographic proof-of-personhood**: bind one digital identity to one biological human, using cryptographic protocols that preserve privacy.

### Key Mechanisms

- **[[Proof of Work]]** — Satoshi Nakamoto's original solution: each unit of influence costs proportional computation. A sybil attacker must control more than 50% of total network hash rate to achieve a [[51 Percent Attack]], which is economically prohibitive in large networks. Downside: high energy consumption and centralisation into mining pools.
- **[[Proof of Stake]]** — influence proportional to staked capital. Sybil attacks require acquiring a majority share of the total staked value, which is expensive and market-visible. Variants include delegated proof-of-stake and liquid staking derivatives.
- **[[Proof of Personhood]]** — cryptographic protocols asserting that each public key corresponds to a unique living human, without necessarily revealing which human. Examples:
  - *BrightID*: social graph-based, using connection patterns to attest uniqueness.
  - *Proof of Humanity* (PoH): video submission plus community vouching, anchored on [[Ethereum]].
  - *Worldcoin / World ID*: iris-scan biometric enrolled at dedicated hardware orbs, producing a [[Zero-Knowledge Proof]] of uniqueness.
  - *Idena*: synchronised CAPTCHA ceremony where participants must simultaneously solve AI-hard tasks, exploiting the physical timing constraint to limit bot participation.
- **[[Web of Trust]]** — decentralised trust propagation where identities gain credibility from endorsements by already-trusted nodes. Used in PGP key signing, and more recently in [[Nostr]] relay trust policies. Susceptible to collusion within cliques.
- **Trust-graph analysis** — graph-theoretic detection of clustering patterns characteristic of bot farms: abnormally dense cliques, star topologies originating from a seed account, and low betweenness-centrality paths. Used by platforms like [[Twitter]] / X in bot detection and by academic tools such as SybilGuard and SybilLimit.
- **[[Verifiable Credential]]** / KYC-linked DID** — a [[Decentralised Identity]] (DID) anchored to a government-issued credential or liveness check. Provides strong sybil resistance at the cost of reduced pseudonymity. Used in regulated DeFi contexts and enterprise blockchain permissioning.
- **Stake-weighted admission** — nodes must post a bond (slashable on misbehaviour) before participating. The economic risk of losing the bond deters sybil identity creation at scale.

### Applications & Use Cases

- **[[Blockchain]] consensus**: all major public chains (Bitcoin, Ethereum, Solana) rely on resource-binding mechanisms as their primary sybil-resistance layer.
- **[[Decentralised Autonomous Organisation]] governance**: DAOs distributing governance tokens to unique humans require sybil-resistant identity verification to prevent plutocratic capture through synthetic wallets. Projects such as Gitcoin Grants use [[Quadratic Voting]] backed by Passport (a composable identity aggregator combining multiple sybil-resistance signals).
- **Universal Basic Income protocols**: Circles UBI and Proof of Humanity distribute tokens on a one-person-one-stream basis; sybil resistance is existential to the fairness of the distribution.
- **[[Fair Airdrop]] distribution**: token projects airdropping to early users must filter bot wallets; sybil scoring (on-chain activity analysis, social attestation) is used to weight eligibility.
- **Peer-to-peer network routing**: DHT-based overlays (Kademlia) are vulnerable to routing table poisoning by sybil nodes; academic proposals (SybilGuard, SybilRank) use social graph structure to bound sybil node influence.
- **Federated machine learning**: in [[Federated Learning]], a sybil adversary can inject many poisoned model updates; sybil-resistance mechanisms (reputation weighting, Byzantine-robust aggregation) are applied at the aggregation layer.
- **Content moderation and reputation**: anti-review-bomb policies on platforms depend on detecting and discounting sybil accounts that coordinate to inflate or depress ratings.
- **[[Zero-Knowledge Proof]] identity**: anonymous credential systems use ZKPs to prove "I am a unique verified human" without revealing identity, bridging strong sybil resistance with pseudonymity — an active research area in [[Privacy-Preserving Computation]].

### Standards & Context

- **W3C DID Core**: the [[Decentralised Identifier]] (DID) specification provides the identity substrate that sybil-resistance schemes operate upon. DIDs are method-agnostic; different methods (did:ethr, did:key, did:web) carry different sybil-resistance guarantees.
- **W3C Verifiable Credentials Data Model**: [[Verifiable Credential]] issuers can bind credentials to proof-of-personhood attestations, enabling sybil-resistant claims in interoperable ecosystems.
- **EIP-4337 (Account Abstraction)** on [[Ethereum]]: allows social recovery and multi-factor identity schemes that can incorporate sybil-resistance signals without sacrificing user experience.
- **Gitcoin Passport**: a composable sybil-resistance score aggregating stamps from multiple providers (BrightID, ENS, POAP, Coinbase Verification), used for Gitcoin Grants quadratic funding rounds.
- **ISO/IEC 24760 (Identity Management)**: international identity management framework relevant to the identity-binding layer of sybil resistance in enterprise contexts.
- **IETF RFC 8693 (Token Exchange)**: used in federated identity flows that may carry sybil-resistance attestations across trust domains.
- Academic landmark: Douceur, J. (2002) "The Sybil Attack", IPTPS — the canonical reference that named and formalised the problem.

### Privacy–Security Trade-off

- A fundamental tension in sybil resistance is between **verifiability** and **privacy**. The strongest schemes (KYC-linked credentials, biometric proof-of-personhood) provide maximal sybil resistance but require linkage to real-world identity, enabling surveillance and exclusion of pseudonymous participants. Lighter approaches (social vouching, on-chain activity scoring) are more privacy-preserving but weaker and gameable.
- [[Zero-Knowledge Proof]] systems are the most promising avenue for resolving this tension: a user can prove membership in a set of verified unique humans without revealing which member they are. Projects like [[Semaphore]] (an Ethereum ZK group-membership protocol) enable exactly this pattern and are being adopted as a privacy layer above proof-of-personhood registries.
- The choice of sybil-resistance mechanism should be threat-model-driven: high-value governance decisions warrant stronger (more expensive) schemes; low-stakes community actions can tolerate weaker (more privacy-friendly) controls.

### Provenance

