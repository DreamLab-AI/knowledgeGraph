A retrospective is a recurring, facilitated meeting in which a team reflects on a recent period of work to identify what went well, what did not, and concrete improvements to try next. It is a cornerstone agile practice that institutionalises continuous improvement by turning shared experience into actionable changes to process, tooling and collaboration. Retrospectives are increasingly run on collaborative whiteboards so distributed teams can participate equally.

### Overview

- A retrospective closes an iteration by giving a team protected time to inspect its own way of working and adapt it. A facilitator guides the group through gathering observations, generating insight about root causes, and deciding on a small number of improvement actions with clear owners. Common formats include Start-Stop-Continue, the 4Ls and timeline reviews, frequently surfaced as sticky notes on a physical or collaborative whiteboard so that quieter and remote voices contribute equally. The output feeds directly into the next cycle's planning, creating an explicit feedback loop that distinguishes agile delivery from one-off process change. Psychological safety is the precondition: without it, the meeting degrades into superficial agreement.

### Key aspects

- Time-boxed, facilitated reflection at the end of an iteration.
- Structured into gathering data, generating insight and deciding actions.
- Produces a small set of owned, trackable improvement actions.
- Relies on psychological safety for honest contribution.
- Often run on collaborative whiteboards with sticky notes for equity.

### Applications

- Sprint and iteration retrospectives in agile teams.
- Incident and post-mortem reviews adapting operations.
- Project and milestone reviews capturing lessons learned.
- Distributed-team improvement using shared online boards.

### Provenance

