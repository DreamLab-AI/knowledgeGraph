
An agent operational profile gives the triggers, input schema and output schema of an agent, declared as `OperationalProfile` in the agent module of the Agent Ontology.[^1] visionGraph places it under [[Specification]].

An [[Agent]] reaches its profile through `operationalTriggersAndIO`. Three properties connect it to its parts: `trigger` leads to an [[Agent Trigger]], `input` to an [[Agent Input Specification]] and `output` to an [[Agent Output Specification]]. These three are its components, so the profile is the complete statement of when an agent starts, what it takes in and what it returns.

The profile is a descriptor, not a runtime record. The state of one particular run is captured elsewhere, in the [[Input State]] and [[Output State]] of an [[Execution Context]]. It is one of several descriptor facets of an agent, alongside [[Agent Purpose and Role]], which states what the agent is for and who owns it.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

