The Payment Card Industry Data Security Standard (PCI-DSS) is a security standard governing the handling of cardholder data by organisations that store, process, or transmit payment card information. It defines a set of requirements covering network security, encryption, access control, monitoring, and vulnerability management to reduce the risk of card data breaches. Compliance is mandated by the major card brands and verified through self-assessment questionnaires or external audits depending on transaction volume.

### Overview

- PCI-DSS originated from the consolidation of separate card-brand security programmes into a single industry baseline maintained by the PCI Security Standards Council.
- Its scope covers the cardholder data environment (CDE) — any system component that stores, processes, or transmits primary account numbers and related authentication data.
- Validation levels scale with transaction volume, ranging from self-assessment questionnaires for small merchants to on-site assessment by a Qualified Security Assessor for large processors.

### Key aspects

- Build and maintain a secure network through firewalls and the removal of vendor-default credentials.
- Protect stored cardholder data using strong [[Encryption]] and limit retention to what is operationally necessary.
- Encrypt transmission of cardholder data across open, public networks.
- Maintain a [[Vulnerability Management]] programme including anti-malware controls and secure software development.
- Implement strong [[Access Control]] measures restricting data access on a need-to-know basis.
- Regularly monitor and test networks, logging access to data and systems.

### Applications

- E-commerce checkout flows that must protect card data in transit and at rest.
- Point-of-sale terminals and the payment processors that clear card transactions.
- [[Tokenization]] services that substitute card numbers with non-sensitive tokens to reduce CDE scope.
- Audit and certification engagements verifying merchant and service-provider compliance.

### Provenance

