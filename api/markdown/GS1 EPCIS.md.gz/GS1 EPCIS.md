GS1 EPCIS (Electronic Product Code Information Services) is a GS1 standard that lets applications create and share visibility event data, both within and across enterprises.[^1][^2][^3]

GS1 calls EPCIS its flagship data sharing standard for visibility, and says it helps provide the what, when, where, why and how of products and other assets, enabling the capture and sharing of interoperable information about status, location, movement and chain of custody.[^1] The standard's introduction defines the data it carries as visibility events, each of which is the record of the completion of a specific business process step acting upon one or more objects.[^3] Objects can be physical, such as trade items, logistic units and returnable assets, or digital.[^3]

## Versions and companion standards

ISO publishes the standard as ISO/IEC 19987:2024, which defines version 2.0 of EPCIS.[^2] The Core Business Vocabulary is a companion standard that provides definitions of data values used to populate the EPCIS data structures.[^1] GS1 says version 2.0 adds support for sensor data, certification details, linked online definitions, JSON and JSON-LD syntax, a REST API for capture and query, and GS1 Digital Link syntax for identifiers within event data.[^1]

## Scope and distinctions

EPCIS takes its name from the Electronic Product Code, but the standard states that EPCIS does not require Electronic Product Codes or RFID data carriers, and does not even require instance-level identification.[^3] It defines interfaces for capturing and querying event data.[^3] The identifiers that can appear in events are covered at [[GS1 Identification Key]]. EPCIS is a kind of [[Traceability Data Standard]].

## What the sources do not establish

Sources opened here are GS1's own pages, the ISO catalogue record and the standard's introduction. They say nothing about how widely EPCIS is deployed, in which industries, or under which regulations, so the page makes no such claims. The use of EPCIS for sensor data in cold chains is given by GS1 as an example of the version 2.0 features, not as evidence of adoption.[^1][^2][^3]

[^1]: GS1, “EPCIS & CBV”. https://www.gs1.org/standards/epcis
[^2]: ISO, “ISO/IEC 19987:2024 - Information technology — EPC Information Services (EPCIS)” (catalogue record). https://www.iso.org/standard/85557.html
[^3]: GS1, “EPCIS Standard”, version 2.0, section 1 Introduction. https://ref.gs1.org/standards/epcis/

