The IATA Temperature Control Regulations (TCR) are a manual published by the International Air Transport Association that sets out requirements and standards for the transport and handling of pharmaceutical products, with temperature-sensitive shipments by air as its subject.[^1][^2]

IATA's publication page says the TCR contains the information and requirements needed to ship compliant temperature-sensitive products. Its contents include applicability, government regulations and carrier regulations, pharmaceutical facts and product types, packaging, documentation and labelling, acceptance and control, traceability and tracking, and air transport logistics.[^2] IATA's programme page says the manual provides requirements and standards for the transport and handling of pharmaceutical products, including the compulsory use of the Time and Temperature Sensitive Label.[^1]

## Labels and checklists

IATA's Time and Temperature Sensitive Label has been mandatory from July 2012. It must be affixed to all shipments booked as time and temperature sensitive cargo and indicate the external transportation temperature range, and the shipper, or a designated agent under a service agreement, is responsible for applying it properly.[^1] Since July 2013 an acceptance checklist has been a requisite for the transport of time and temperature-sensitive healthcare shipments.[^1]

## Scope and distinctions

It is sometimes stated that the TCR covers perishables generally, that compliance with the whole manual is mandatory for carriers and shippers, and that the CEIV Pharma scheme is part of it. The opened sources support less. IATA describes healthcare and pharmaceutical products, not perishables generally.[^2][^1] The WHO's 2011 guidance on time- and temperature-sensitive pharmaceuticals names chapter 17 of the IATA Perishable Cargo Regulations for the air-freight label; the opened sources do not say how that publication relates to the TCR.[^3] IATA's programme page lists CEIV Pharmaceutical Logistics under its own heading, describing a Center of Excellence for Independent Validators created to improve the transport and handling of these products; the opened sources do not place it inside the TCR.[^1] What the sources make compulsory is the label and the acceptance checklist; they do not state that the whole manual binds every carrier and shipper.[^1]

## In practice

A supplier of temperature-monitoring equipment says airlines and freight forwarders handling pharmaceutical cargo follow the TCR, and that it outlines minimum standards for cargo acceptance checks, facility storage conditions, loading procedures and transfer protocols.[^4] See [[Cold Chain Monitoring]], [[Pharmaceutical Logistics]] and [[Air Freight]].

## Evidence limits

Apart from the WHO document, which names a different title, every description of the manual comes from IATA itself or from a commercial supplier. The page therefore rests on the publisher's own account, and the full manual, which is sold by IATA, was not opened. IATA's page lists changes for the 15th edition (2027).[^2][^4][^3]

[^1]: International Air Transport Association, “IATA - Pharma & Healthcare”. https://www.iata.org/en/programs/cargo/pharma
[^2]: International Air Transport Association, “IATA - Temperature Control Regulations (TCR)”. https://www.iata.org/en/publications/manuals/temperature-control-regulations/
[^3]: World Health Organization, Technical Report Series No. 961, Annex 9, model guidance for the storage and transport of time- and temperature-sensitive pharmaceutical products, 2011. https://cdn.who.int/media/docs/default-source/medicines/norms-and-standards/guidelines/distribution/trs961-annex9-modelguidanceforstoragetransport.pdf
[^4]: Eupry, “Guide: Pharmaceutical air freight temperature monitoring”. https://eupry.com/temperature-monitoring/air-cargo-monitoring/

