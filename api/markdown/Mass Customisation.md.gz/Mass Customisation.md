Mass customisation is a production strategy that combines the low cost of high-volume output with orders customised to each customer's specification.[^1][^2]

An open operations management text describes it as a hybrid of process types in which each customer order is customised, usually enabled by computer-aided manufacturing, and says that a key requirement for success is a modular design that allows quick change from one product to the next.[^1] A second open text says it combines the advantages of customised products with those of mass production, requires the company to interact with the customer to find out what is wanted, and often works by mass-producing a product up to a cut-off point and then customising it for different customers.[^2]

## Mechanisms

Feitzinger and Lee, writing about Hewlett-Packard, state that the key to mass-customising effectively is postponing the task of differentiating a product for a specific customer until the latest possible point in the supply network. They also say a product should be designed so that it consists of independent modules.[^3] A review of operations and supply chain management says modularisation allows firms to pursue a mass customisation strategy that aims to target individual customer requirements with near-mass production efficiency, citing Pine (1993).[^4]

## Scope and distinctions

Sources call mass customisation an approach or a hybrid process type; this corpus files it under production strategy. It is neither [[Mass Production]], which produces high volumes of identical goods, nor pure [[Make-to-Order]], which is low volume and high variety.[^2] The open text places it among the hybrid process types rather than among the pure ones.[^1] See also [[Production Strategy]] and [[Assemble-to-Order]], which defers final assembly in a similar way.

A second open text cautions that mass customisation does not work for all types of goods, as most people do not care about customised detergents or paper products, and that customised clothes, footwear or sunglasses command higher prices that buyers are often unwilling to pay.[^2]

## What the sources do not establish

A previous body of this page, written in the robotics domain, attributed the strategy to robotics, additive manufacturing and digital twins. No opened source supports those claims, so they are not repeated. Pine's original work was not opened; his view is known here only through the review's citation.[^4]

[^1]: Business LibreTexts (Introduction to Operations Management, NWTC), “6.3: Process Types”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/06:_Process_Design/6.03:_Process_Types
[^2]: eCampusOntario Pressbooks (Introduction to Canadian Business), “Operations Management”. https://ecampusontario.pressbooks.pub/bus108g/chapter/opsmanagement/
[^3]: Edward Feitzinger and Hau L. Lee, Harvard Business Review, January-February 1997 (Georgia Tech course copy), “Mass Customization at Hewlett-Packard: The Power of Postponement”. https://www2.isye.gatech.edu/~jvandeva/Classes/6203/2006/MassCustomizationLee.pdf
[^4]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

