Token issuance is the process by which a blockchain protocol or smart contract creates and distributes new digital tokens into circulation, establishing the initial and ongoing supply available to network participants. It encompasses the technical minting of token units according to predefined rules as well as the economic policies governing distribution, vesting schedules, and supply caps. Issuance mechanisms range from one-time generation events to continuous emission programmes tied to staking rewards or protocol activity.

### Overview

- Issuance defines the supply side of a token economy. A protocol specifies whether tokens are pre-minted in full at genesis, released gradually through emission schedules, or created on demand by smart-contract actions such as collateral deposits or staking. The chosen model shapes inflation, holder incentives, and long-term scarcity.
- Distribution mechanisms determine who receives newly issued tokens: founders and investors via vesting contracts, validators via block rewards, liquidity providers via yield programmes, or the public via sales and airdrops. Transparent, on-chain issuance rules underpin trust in a token's economic model.

### Mechanisms

- Fixed-supply issuance mints the entire supply once, after which no further tokens can be created without governance intervention.
- Inflationary issuance emits new tokens continuously to reward [[Validator]] participation and secure the network, balanced against burning or sinks.
- Algorithmic and elastic issuance adjust supply dynamically in response to demand signals or peg targets.
- Vesting and lock-up contracts schedule the gradual release of allocated tokens to align stakeholder incentives over time.

### Applications

- [[Initial Coin Offering]] and token generation events bootstrap project funding and community ownership.
- Staking-reward issuance compensates [[Validator]] nodes for securing proof-of-stake networks.
- [[Liquidity]] mining programmes issue tokens to incentivise capital provision in decentralised markets.
- [[Governance Token]] distribution issues voting rights to align control with participation.

### Provenance

