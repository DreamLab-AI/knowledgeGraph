A liquid staking token (LST) is a transferable token issued to a user in exchange for assets staked through a liquid-staking protocol, representing a claim on the underlying stake plus accrued rewards. It frees staked capital from the usual lock-up by remaining tradable and composable across decentralised-finance applications while the principal continues to secure the network. The token's value tracks the staked position, accruing yield either through a rising exchange rate or a growing balance.

- A Liquid Staking Token is a tradable claim issued through [[Liquid Staking]] in exchange for [[Staking|staked]] assets, representing principal plus rewards while a [[Validator Node]] continues to secure a [[Proof of Stake]] network.
- It restores [[Liquidity]] to otherwise locked stake and stays composable across [[Decentralised Finance]].

### Overview

- Staking secures proof-of-stake networks but normally locks capital, which cannot be moved or used elsewhere while bonded. Liquid staking solves this by issuing a token that represents the staked position, letting holders retain liquidity even as the underlying assets keep validating.
- The protocol pools user deposits, runs or delegates to validators, and mints liquid staking tokens to depositors. As the validators earn rewards, the token captures that yield, either by appreciating against the underlying asset through a rising exchange rate, or by increasing the holder's token balance via a rebasing model.
- Because the token is transferable and standards-compliant, it can be lent, used as collateral, or traded across DeFi, effectively letting one unit of capital both secure the chain and remain economically active. This composability also concentrates stake in major protocols, raising centralisation concerns.

### Key aspects

- The token is a transferable claim on pooled stake plus accrued rewards.
- Yield accrues through either a rising exchange rate or a growing balance.
- Composability lets the token serve as collateral and liquidity across DeFi.
- The holder inherits exposure to validator performance, including slashing risk.
- Withdrawal and redemption rules govern how the token is converted back to the underlying asset.

### Applications

- Earning staking rewards while keeping capital liquid and usable.
- Collateral and liquidity in lending, trading, and yield protocols.
- Protocols such as Lido issuing liquid staking tokens for networks like Ethereum.
- Strategies that layer additional yield on top of base staking returns.

### Provenance

