
Capability provenance records the "origin, version, or derivation lineage of a capability". It is declared as `CapabilityProvenance` in the Agent Ontology's capability module.[^1]

An [[Agent Capability]] points to its provenance through the `provenance` property. The class has a `sourceSpec` property whose range is `xsd:anyURI`, naming the specification a capability comes from, and a `capabilityVersion` string.[^1] Together these let a statement that an agent has a capability carry a pointer to where the capability was defined and which version is meant.

The ontology states nothing further about how provenance is verified. It records the lineage as data and leaves checking to other layers, such as the security-binding and ledger modules.

[^1]: Semantic Agent Communication Community Group, “Capability Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/capability.ttl

