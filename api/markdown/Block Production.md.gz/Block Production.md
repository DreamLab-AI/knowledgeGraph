Block production is the process by which a blockchain network assembles pending transactions into a new block, orders them, and proposes that block for inclusion in the canonical chain. In proof-of-stake and similar systems, validators are selected to produce blocks for given slots or epochs, executing the consensus protocol that determines who may extend the chain and when. Block production is the heartbeat of a blockchain, governing throughput, latency and the fair ordering of transactions.

### Overview

- Every blockchain advances by appending blocks, and block production is the mechanism that creates those blocks. A producer (a miner under proof-of-work or an elected validator under proof-of-stake) collects unconfirmed transactions from the mempool, applies ordering rules, executes them against current state, and packages the result into a candidate block referencing its predecessor. The consensus protocol then decides whether that block becomes part of the canonical chain. The cadence and fairness of block production directly determine a chain's throughput, confirmation latency and resistance to manipulation.
- Because the block producer chooses which transactions to include and in what order, block production is also where economic value and centralisation pressures concentrate. Maximal extractable value arises from the producer's ordering power, and mitigations such as proposer-builder separation aim to keep this power from undermining decentralisation. The protocol's fork-choice and finality rules then ensure the network converges on a single canonical history.

### History and context

- Block production began with Bitcoin's proof-of-work mining, where computational puzzles selected producers. Proof-of-stake systems later replaced energy-intensive mining with stake-weighted validator selection, and designs such as proposer-builder separation refined who assembles versus who proposes blocks.

### Mechanisms

- Proposer selection: choosing which validator or miner may produce the block for a given slot, by stake-weighted lottery or proof-of-work.
- Transaction selection and ordering: drawing from the mempool and ordering transactions, which exposes maximal extractable value.
- State execution: applying the chosen transactions to compute the new chain state and block hash.
- Block propagation: broadcasting the new block so other nodes can validate and adopt it.
- Fork choice and finality: rules that resolve competing blocks and progressively finalise history.
- Incentives: block rewards and transaction fees that compensate producers and secure the network.

### Applications

- Securing public blockchains such as Ethereum and Solana through validator-driven block production.
- Proposer-builder separation designs that decouple ordering from block assembly.
- Layer-2 sequencers that produce blocks before settling to a base layer.
- Throughput and latency tuning in high-performance chains.

### Challenges and considerations

- Centralisation pressure: economies of scale in production can concentrate power.
- Maximal extractable value: ordering power enables value extraction that may harm users.
- Latency versus security: faster block times raise throughput but can increase forks.
- Liveness: the network must keep producing blocks even under validator failures.

### Examples

- Ethereum validators proposing blocks for assigned slots under proof-of-stake.
- Solana leaders producing blocks in a high-throughput rotating schedule.
- Layer-2 sequencers producing blocks before settling to a base chain.

### Provenance

