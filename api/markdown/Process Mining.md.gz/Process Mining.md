Process mining is a family of data-driven techniques that reconstruct, analyse, and improve real business processes by extracting knowledge from event logs recorded in enterprise information systems. It encompasses process discovery, which infers a process model from observed event sequences; conformance checking, which compares the discovered behaviour against a reference model; and enhancement, which enriches models with performance and frequency data. By grounding analysis in actual recorded execution rather than idealised documentation, it reveals bottlenecks, deviations, and automation opportunities.

### Overview

- Information systems such as ERP, CRM, and case-management platforms record timestamped events describing which activity occurred, when, and for which case. Process mining treats these traces as the ground truth of organisational behaviour.
- Discovery algorithms (alpha miner, heuristic miner, inductive miner) infer a process model — often a Petri net, BPMN diagram, or directly-follows graph — from the ordering of events.
- Conformance checking aligns observed traces against a normative model to quantify deviations, rework, and policy violations.
- Enhancement overlays performance metrics such as waiting time, throughput, and resource utilisation onto the model, turning a static map into a diagnostic instrument.

### Key aspects

- Event log quality: completeness, correct case identifiers, and accurate timestamps determine the reliability of every downstream result.
- The three pillars: discovery, conformance, and enhancement.
- Object-centric and predictive variants extend classical control-flow mining toward multi-entity and forward-looking analysis.
- Privacy and access control, since event logs frequently contain sensitive operational and personal data.

### Applications

- Identifying bottlenecks and rework loops in procure-to-pay and order-to-cash processes.
- Prioritising candidates for [[Robotic Process Automation]] by quantifying repetitive, rule-based activity.
- Auditing compliance by detecting paths that violate segregation-of-duties controls.
- Continuous monitoring of service-level adherence in customer operations.
- Benchmarking process variants across regions or business units.

### Provenance

