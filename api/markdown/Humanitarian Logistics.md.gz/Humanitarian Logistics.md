Humanitarian logistics is the logistics of humanitarian operations: the transport, warehousing and distribution of aid in disasters and crises, together with the planning around them.[^1][^2]

A review chapter by Jahre and Besiou says humanitarian operations constitute a relatively new field of research in operations management, and that they are not only about the response: the logistics involved in mitigation, preparedness and recovery are equally important parts of the disaster management cycle.[^1] It describes a typical supply chain of activities that starts with assessing and publishing needs and budgeting, followed by sourcing and procurement, transport, warehousing and distribution.[^1]

## Operating conditions

That chapter says humanitarian operations often take place in resource-austere settings with limited access to power and clean water, poor transport links, disrupted supply chains, a limited cold chain and political volatility.[^1]

## Coordination and common services

The Logistics Cluster says it is responsible for providing coordination, information management and access to common logistics services so that an effective and efficient logistics response takes place in humanitarian emergency missions. It records that the IASC has designated the World Food Programme as the Logistics Cluster global lead agency.[^2] Services such as warehousing and cargo transport may be made available to humanitarian organisations on a free-to-user or cost-recovery basis, for a limited duration only.[^2] WFP says it operates a global logistics network that spans land, air and sea, and a global network of 380 warehouses and logistics hubs to store food, and that the Logistics Cluster it leads provides coordination and information management during emergency responses.[^3]

## Scope and distinctions

Humanitarian Logistics is a form of [[Sector Logistics]]. Related pages are [[Disaster Response]] and [[Flood Mapping]].

## What the sources do not establish

This page rests on a review chapter and two organisation pages. Academic papers that propose a formal definition were not opened, so the definition above is drawn from descriptions of the work. WFP's account of its own network is a self-description and no independent figure was opened to check it.

[^1]: arXiv (Petropoulos and colleagues), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: Logistics Cluster, “The Logistics Cluster”. https://logcluster.org/en/about-us
[^3]: World Food Programme, “Supply chain”. https://www.wfp.org/logistics

