A trade body is an association through which businesses in an industry or trade act together, for example to promote shared interests. The UK Competition and Markets Authority puts it this way in its guidance: trade associations play an important role in promoting their members' interests.[^1]

## What the sources say

No opened source gives a formal definition of the term. The Competition and Markets Authority guidance does not define the term and concentrates on legal risks: if a trade association is used as a means to create or encourage an infringement of competition law, both the association and its members can face serious consequences.[^1]

Two organisations show the range. FIATA describes itself as founded on 31 May 1926 in Vienna, Austria, and as the global voice of freight logistics, representing and connecting the international forwarding and logistics community.[^2] The International Chamber of Commerce calls itself the world's business organisation and the institutional representative of 45 million companies in more than 170 countries.[^3] See [[International Chamber of Commerce]] for that organisation.

## Scope and distinctions

A trade body differs from an [[Intergovernmental Trade Organisation]], whose members are governments; for example the WTO is run by its member governments.[^4] It also differs from a [[Standards Body]], although a trade body may publish rules or standards; ICC publishes the Incoterms rules, now in the 2020 version.[^5] See also [[GS1]].

## What the sources do not establish

Evidence for this page is thin. The CMA guidance and the two self-descriptions are the only material opened, and none of them states a definition, a membership rule or a legal form. The sources do not say how trade bodies differ from chambers of commerce, professional bodies or federations of associations, although FIATA's own name describes it as an international federation of freight forwarders associations. The membership figures quoted by ICC are its own and were not checked against an independent count.[^3][^2]

[^1]: UK Competition and Markets Authority on GOV.UK, “What do trade associations need to know about competition law?”. https://www.gov.uk/government/publications/competition-law-dos-and-donts-for-trade-associations/what-do-trade-associations-need-to-know-about-competition-law
[^2]: FIATA, International Federation of Freight Forwarders Associations, home page. https://fiata.org/
[^3]: International Chamber of Commerce, About ICC page. https://iccwbo.org/about-us/
[^4]: World Trade Organization, “Who we are”. https://www.wto.org/english/thewto_e/whatis_e/who_we_are_e.htm
[^5]: Business.gov.uk, “Choosing the right incoterms”. https://www.business.gov.uk/export-from-uk/learn/categories/selling-across-borders-product-and-services-regulations-licensing-and-logistics/logistics-and-freight-forwarders/incoterms/

