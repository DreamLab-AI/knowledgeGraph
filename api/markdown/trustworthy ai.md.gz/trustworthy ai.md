Trustworthy AI denotes artificial intelligence systems designed, developed, and operated in accordance with a multi-criteria framework of lawfulness, ethical soundness, technical robustness, fairness, transparency, accountability, and societal wellbeing, ensuring they produce reliable and safe outcomes throughout their full lifecycle. The concept is most concretely codified in the EU High-Level Expert Group on AI's seven requirements for trustworthy AI and operationalised through the EU AI Act's risk-tiered conformity obligations and the NIST AI Risk Management Framework. Achieving trustworthy AI demands convergent technical measures—such as explainability, robustness testing, and bias mitigation—alongside governance instruments including impact assessments, model documentation, algorithmic audits, and meaningful human oversight mechanisms. It functions as an integrating standard that bridges AI safety, AI ethics, and AI regulation into a coherent assurance regime applicable across the full AI system lifecycle.

### Overview

- Trustworthy AI emerged as a governance concept in the late 2010s in response to growing concerns about opaque decision-making, discriminatory outcomes, and misuse of AI systems in high-stakes domains such as healthcare, criminal justice, and employment.
- The EU's 2019 "Ethics Guidelines for Trustworthy AI" published by the [[EU High-Level Expert Group on AI]] provided the first internationally influential structured treatment, identifying seven non-negotiable requirements that AI systems must satisfy to earn societal trust.
- The concept is simultaneously a technical standard (requiring specific engineering properties), an ethical commitment (to fairness, non-maleficence, and human dignity), and a regulatory instrument (providing the normative backbone of the [[EU AI Act]] and informing the [[NIST AI Risk Management Framework]]).
- Unlike narrower notions of [[AI Safety]] (which focuses on preventing catastrophic failures) or [[Responsible AI]] (often limited to ethical guidelines), trustworthy AI encompasses the full spectrum from technical reliability to democratic accountability.
- It applies across the AI system lifecycle: from problem framing and [[Training Data]] curation, through model development and validation, to deployment monitoring, decommissioning, and redress mechanisms.
- Growing AI deployment in critical infrastructure, financial services, and public administration has made trustworthy AI a practical necessity rather than an aspirational ideal, driving regulatory mandates in the EU, UK, and increasingly the US.

### Key Requirements

- The EU HLEG framework identifies seven foundational requirements:
  - **Human agency and [[Human Oversight]]**: AI must support users' ability to understand, challenge, and override AI decisions; autonomous systems must have meaningful human control mechanisms.
  - **Technical robustness and [[AI Safety]]**: Systems must be reliable, secure against adversarial manipulation, resilient to errors, and able to handle edge cases without catastrophic failure.
  - **[[Privacy by Design]] and data governance**: Personal data must be protected through technical and organisational measures; data collection must be minimised and purposefully limited.
  - **[[Transparency]]**: Systems, their data, and their reasoning must be explainable to relevant stakeholders; opacity must be justified and minimised.
  - **Diversity, non-discrimination, and [[Fairness]]**: AI must avoid unfair bias, be accessible to all, and promote inclusion; [[Fairness-Aware Machine Learning]] methods operationalise this requirement technically.
  - **Societal and environmental wellbeing**: AI must not harm broader society or the environment; lifecycle environmental impacts (energy, resources) must be assessed.
  - **[[Algorithmic Accountability]]**: Clear lines of responsibility must exist; [[Algorithmic Auditing]] and redress mechanisms must be available to affected parties.
- Each requirement maps onto both technical measures (model design, testing, monitoring) and governance measures (documentation, auditing, certification).

### Technical Mechanisms

- **[[Explainable AI]] (XAI)**: Methods such as SHAP (SHapley Additive exPlanations) and LIME (Local Interpretable Model-agnostic Explanations) provide post-hoc local feature attributions; attention visualisation, saliency maps, and concept-based explanations address different stakeholder needs.
- **[[Bias Mitigation]]**: Pre-processing techniques (re-weighting, re-sampling), in-processing constraints (fairness regularisation, adversarial debiasing), and post-processing corrections (threshold adjustment, calibration) address disparate impact across protected characteristics.
- **[[Robustness Testing]]**: Adversarial robustness evaluation (e.g., using PGD or AutoAttack), distributional shift testing, stress testing under out-of-distribution inputs, and formal verification for safety-critical components.
- **Privacy-preserving techniques**: [[Differential Privacy]] for training data protection, [[Federated Learning]] for decentralised model training without raw data sharing, and [[Homomorphic Encryption]] for privacy-preserving inference.
- **[[Model Card]]**: Structured documentation artefacts (originating from Google, now widely adopted) that record training data, evaluation results, intended uses, limitations, and ethical considerations for individual models.
- **[[AI Impact Assessment]]**: Structured pre-deployment analysis frameworks analogous to [[Environmental Impact Assessment]] or [[Data Protection Impact Assessment]], identifying risks before deployment in high-stakes contexts.
- **Monitoring and logging**: Continuous post-deployment monitoring for distributional drift, performance degradation, and emergent biases; audit logging to support after-the-fact accountability.

### Governance Instruments

- **[[EU AI Act]]**: The world's first comprehensive AI regulation, enacted in 2024, classifies AI systems by risk level (unacceptable, high, limited, minimal) and mandates technical and governance requirements for high-risk systems including conformity assessments, registration, and incident reporting.
- **[[NIST AI Risk Management Framework]]**: The US National Institute of Standards and Technology's AI Risk Management Framework (published 2023) provides a voluntary, flexible structure for organisations to identify, assess, and manage AI risks across four functions: Govern, Map, Measure, Manage.
- **[[ISO/IEC 42001]]**: The international standard for AI management systems (published 2023), providing certifiable requirements for organisations establishing responsible AI governance.
- **[[ISO/IEC JTC1 SC42]]**: The international standardisation committee developing the family of AI standards (42xxx series) addressing terminology, bias, robustness, and trustworthiness.
- **[[Algorithmic Auditing]]**: Independent third-party assessment of AI systems' behaviour, including [[Red Teaming]], conformance testing, and impact auditing; increasingly mandated for high-risk deployments.
- **[[AI Certification]]**: Formal conformity assessment schemes, analogous to CE marking in product safety, verifying that AI systems meet defined trustworthiness criteria before market placement.

### Applications and Use Cases

- **Healthcare**: Trustworthy AI requirements are essential for clinical decision support, diagnostic imaging AI, and patient triage systems where errors can cause direct patient harm; requires robustness certification, explainability for clinicians, and bias testing across demographic groups.
- **Financial services**: Credit scoring, fraud detection, and algorithmic trading systems must satisfy fairness requirements (e.g., non-discrimination in lending), transparency obligations under existing financial regulation (MiFID II, GDPR), and robustness against adversarial manipulation.
- **Criminal justice**: Recidivism prediction, facial recognition for law enforcement, and bail decision support systems are subject to heightened scrutiny; trustworthy AI frameworks demand fairness audits, human review requirements, and clear accountability chains.
- **Employment and HR**: Automated CV screening, interview analysis, and performance management AI must comply with non-discrimination law; bias mitigation and explainability are legally mandated in jurisdictions including the EU.
- **Public administration**: Benefits processing, tax fraud detection, and urban planning AI deployed by governments require democratic accountability, transparency to citizens, and effective redress mechanisms.
- **Autonomous systems**: Self-driving vehicles, autonomous drones, and robotic systems require technical robustness and safety certification alongside human override capabilities and clear liability frameworks.
- **Education**: Adaptive learning platforms, automated essay grading, and student performance prediction must be fair, transparent, and avoid reinforcing educational inequalities.

### Standards and Regulatory Context

- **EU Ethics Guidelines for Trustworthy AI (2019)**: The foundational policy document from the [[EU High-Level Expert Group on AI]], establishing the seven-requirements framework; influenced AI policy globally.
- **[[EU AI Act]] (2024)**: Translates trustworthy AI principles into binding legal obligations for AI system providers and deployers operating in the EU market; introduces the Conformity Assessment procedure for high-risk AI.
- **[[NIST AI Risk Management Framework]] (2023)**: US voluntary framework for AI risk management; widely adopted by US federal agencies and private sector; complements but does not conflict with EU frameworks.
- **[[ISO/IEC 42001]] (2023)**: First internationally harmonised AI management system standard; enables [[AI Certification]] against certifiable requirements.
- **IEEE 7000 series**: Standards addressing ethically aligned design, algorithmic bias considerations, and transparency of autonomous systems; complement the ISO/IEC family.
- **UK AI Safety Institute**: The UK government's body for advanced AI safety evaluation; its testing frameworks inform trustworthy AI assessment methodologies.
- **OECD AI Principles**: The 2019 OECD Recommendation on Artificial Intelligence, adopted by 42 countries, provides internationally agreed principles for trustworthy AI that influenced both the EU HLEG guidelines and the NIST AI RMF.
- **G7 Hiroshima AI Process**: International coordination mechanism for trustworthy AI governance among G7 nations, producing voluntary codes of conduct for advanced AI development.

### Challenges and Limitations

- **Tension between performance and interpretability**: High-performing deep learning models are often inherently opaque; post-hoc explainability methods provide approximations that may not faithfully represent the model's actual decision process.
- **Context-dependency of fairness**: Different formal definitions of [[Fairness]] (equalised odds, demographic parity, calibration) are mathematically incompatible in general; the appropriate fairness criterion depends on the specific application context and societal values.
- **Measurement difficulties**: Trustworthiness is a composite, multi-dimensional property; no single metric captures it; standardised evaluation benchmarks are nascent.
- **Regulatory fragmentation**: Divergent requirements across the EU, UK, US, and other jurisdictions create compliance complexity for globally deployed AI systems.
- **Scalability of oversight**: As AI systems proliferate and operate at scale, meaningful [[Human Oversight]] of individual decisions becomes impractical; systemic oversight mechanisms must substitute.
- **General-purpose AI**: Foundation models and large language models deployed in diverse contexts pose novel trustworthy AI challenges, as their downstream uses cannot be fully anticipated at development time.

### Current Landscape (2026)

- The EU AI Act (Regulation (EU) 2024/1689), the world's first comprehensive AI law and the anchor of "trustworthy AI" policy, entered into force on 1 August 2024 and became broadly applicable on 2 August 2026; GPAI obligations applied from 2 August 2025 and Commission enforcement powers began on 2 August 2026, with fines up to EUR 35M or 7% of global turnover.
- The "Digital Omnibus on AI" (COM(2025) 836), politically agreed on 7 May 2026, pushes high-risk deadlines back to 2 December 2027 (Annex III) and 2 August 2028 (Annex I) while leaving substantive obligations unchanged; a new prohibition on non-consensual explicit content takes effect December 2026.
- Standards have matured rapidly: ISO/IEC 42001 (the first certifiable AI management-system standard) was adopted as EN ISO/IEC 42001:2026 on 17 March 2026, and on 30 October 2025 prEN 18286 (Quality Management System for AI Act purposes) became the first harmonised AI standard to enter public enquiry under CEN-CENELEC JTC 21.
- Certification is now a competitive differentiator: Microsoft achieved ISO/IEC 42001 recertification in March 2026 across eight AI systems (including Microsoft 365 Copilot, GitHub Copilot and Security Copilot) with zero non-conformities, having first certified in March 2025.
- In the US, NIST released a concept note on 7 April 2026 launching an AI RMF "Trustworthy AI in Critical Infrastructure Profile" (energy-focused, covering TEVV, adversarial robustness, AIBOMs and agent guardrails), and on 29 July 2026 published a "Zero Draft" for public-facing AI documentation.
- Stanford HAI's 2026 AI Index reports responsible-AI practice lagging capability: documented AI incidents rose to 362 in 2025 (up from 233 in 2024), hallucination rates across 26 top models span 22-94%, and the Foundation Model Transparency Index average fell to 40 in 2025 after reaching 58 in 2024.
- Frontier safety remains uneven: the Future of Life Institute's Summer 2026 AI Safety Index again ranked Anthropic, OpenAI and Google DeepMind highest while xAI, DeepSeek and Mistral received failing grades, and the International AI Safety Report 2026 flagged growing reward-hacking and oversight-undermining behaviours as key open challenges.

### References

- 1. European Commission (2026). AI Act — Shaping Europe's digital future. https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai
- 2. Baker Botts (2026). AI Regulatory Update for Energy: New Timelines in the EU, New Standards in the US. https://www.bakerbotts.com/thought-leadership/publications/2026/may/ai-regulatory-update-for-energy-new-timelines-in-the-eu-new-standards-in-the-us
- 3. European Commission (2026). Standardisation of the AI Act (CEN-CENELEC JTC 21, prEN 18286). https://digital-strategy.ec.europa.eu/en/policies/ai-act-standardisation
- 4. Stanford HAI (2026). Responsible AI — The 2026 AI Index Report. https://hai.stanford.edu/ai-index/2026-ai-index-report/responsible-ai
- 5. Microsoft (2026). Recertified: How Microsoft 365 Copilot continues to earn trust (ISO/IEC 42001). https://techcommunity.microsoft.com/blog/microsoft365copilotblog/recertified-how-microsoft-365-copilot-continues-to-earn-trust-and-what-changed-i/4521693
- 6. Future of Life Institute (2026). AI Safety Index — Summer 2026. https://futureoflife.org/wp-content/uploads/2026/07/AI-Safety-Index-Summer-2026-Digital.pdf

### Provenance

