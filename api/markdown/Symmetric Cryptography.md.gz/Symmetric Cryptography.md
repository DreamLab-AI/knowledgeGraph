Symmetric cryptography is a class of cryptographic techniques in which the same secret key is used for both encryption and decryption. It includes block ciphers and stream ciphers and underpins fast bulk data protection and authenticated encryption. Its security depends on keeping the shared key secret and on secure key distribution, which is often handled by asymmetric methods.

### Overview

- A single shared key both encrypts and decrypts, giving high throughput for bulk data.
- Block ciphers operate on fixed-size blocks under modes such as GCM, while stream ciphers process data continuously.
- Authenticated encryption combines confidentiality with integrity in one primitive.
- Secure key establishment typically relies on asymmetric key exchange before symmetric data transfer.

### Key aspects

- **Block ciphers** — Algorithms transform fixed-size blocks, with modes of operation extending them to arbitrary-length messages.
- **Stream ciphers** — Keystream generators combine with plaintext for low-latency, byte-wise encryption.
- **Authenticated encryption** — Modes such as AES-GCM provide confidentiality and integrity together, resisting tampering.
- **Key management** — Generation, distribution, rotation and destruction of shared keys govern overall security.

### Applications

- Bulk encryption of data at rest on disks and in databases.
- Protecting payload confidentiality within TLS sessions after key exchange.
- Securing messaging and file transfer with authenticated encryption.
- Disk and volume encryption in operating systems and devices.

### Provenance

