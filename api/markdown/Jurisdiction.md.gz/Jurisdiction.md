Jurisdiction is the authority of a legal or governmental body to interpret and apply law, exercise control, and adjudicate disputes within a defined territorial, personal, or subject-matter scope. In digital systems it determines which national or regional laws govern data, transactions, and conduct, and which courts or regulators may assert competence. Conflicts arise when data, parties, or services span multiple jurisdictions with divergent legal regimes.

### Overview

- Jurisdiction may be grounded in territory (where conduct occurs), nationality (who the parties are), or effects (where consequences are felt).
- Digital services frequently trigger overlapping claims of jurisdiction because data is stored, processed, and accessed across borders.
- Choice-of-law and choice-of-forum clauses attempt to make the governing regime predictable, but mandatory public-policy rules can override them.

### Key aspects

- Territorial jurisdiction binds activity to a geographic boundary such as a nation state or region.
- Personal jurisdiction concerns authority over specific individuals or organisations.
- Subject-matter jurisdiction limits a body to particular categories of dispute.
- Extraterritorial reach, as seen in some data-protection and sanctions regimes, extends authority beyond physical borders.

### Applications

- Determining which data-protection regime (e.g. GDPR) applies to a cross-border service.
- Resolving where a smart-contract dispute or platform liability claim may be heard.
- Structuring cloud deployments to satisfy data-localisation and sovereignty requirements.

### Provenance

