A customs duty is a tax charged by a government on goods when they are imported or exported.[^1][^2]

The WTO says customs duties on merchandise imports are called tariffs, that they give a price advantage to locally produced goods over similar imported goods, and that they raise revenue for governments.[^1] It adds that members have listed commitments to cut and bind tariffs on goods schedules.[^1] Maersk's glossary defines duty as a tax levied by governments on the import, export or consumption of goods, usually based on value but sometimes on weights or quantities.[^2]

## Terms in the Union Customs Code

The Code defines import duty as customs duty payable on the import of goods, export duty likewise on export, and a customs debt as the obligation to pay the amount of import or export duty that applies to specific goods under the customs legislation.[^3] Release for free circulation entails the collection of any import duty due.[^3] The European Commission adds that the date of acceptance of the customs declaration is the date used to calculate and apply the amount of import duty.[^4]

## In the UK

GOV.UK says that once the commodity code is known the Trade Tariff shows the rate of duty or import VAT, depending on what the goods are and where they are from.[^5] Duty may be nil or reduced depending on what the goods are and what is done with them, and a preference agreement with the exporting country may reduce it.[^5] See [[Tariff Classification]] and [[Rules of Origin]].

## Evidence limits

No rates are quoted from these sources and none is used here. The WTO equates customs duties on imports with tariffs, while the UK and EU texts speak of duty and import duty.[^1][^3][^5]

[^1]: World Trade Organization, “WTO | Tariffs”. https://www.wto.org/english/tratop_e/tariffs_e/tariffs_e.htm
[^2]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms
[^3]: European Parliament and Council, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code (recast)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^4]: European Commission, “Importation - Taxation and Customs Union - European Commission”. https://taxation-customs.ec.europa.eu/customs/customs-procedures-import-and-export/importation_en
[^5]: HM Revenue and Customs, “Check if you can pay a reduced amount of Customs Duty - GOV.UK”. https://www.gov.uk/guidance/check-if-you-can-pay-a-reduced-rate-of-customs-duty

