A production system type is a class of production process distinguished by the variety and volume of what it makes and by how work and equipment are arranged.[^1][^2]

An open operations management text lists the process types as project, job shop, batch, repetitive, continuous and hybrids, and states that process types depend on the variety and volume of production.[^1] Georgia Tech class notes take a layout view instead: plant layouts divide into five general types according to two characteristics, the number of different products manufactured and the number of units made of each product type, also called the batch or lot size.[^2] The notes describe the more units made of each product, the more efficient and specialised the process can be, and the more different products, the more flexible the system.[^2]

## Two taxonomies

Neither source uses the other's classes. The textbook names project, job shop, batch, repetitive and continuous processes plus hybrids.[^1] The class notes describe a mass production flow shop, continuous production, a job shop with a process layout, a project layout, and a cellular layout associated with batch production.[^2] The pages in this corpus are [[Job Shop Production]], [[Batch Production]] and [[Mass Production]]. Where the sources differ on the boundary, the individual pages say so.

## Scope and distinctions

A production system type is a feature of how the work is arranged. It is separate from a production strategy, which concerns when production is triggered relative to the customer order; see [[Production Strategy]]. The textbook ties the job shop to make-to-order work, so the two classifications are related but not identical.[^1]

In continuous production, the notes say, products flow through directly connected operations without intermediate storage or material movement, and that it is usually applicable only to bulk, gas or liquid products.[^2]

## What the sources do not establish

No standard taxonomy is established. Both sources are teaching material. The class notes define manufacturing efficiency as the percentage of the time a plant is actually producing and give figures for each layout; the figures depend on shifts worked and are not used here.[^2]

[^1]: Business LibreTexts (Introduction to Operations Management, NWTC), “6.3: Process Types”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/06:_Process_Design/6.03:_Process_Types
[^2]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design Class Notes, Chapter 12. Manufacturing Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/Logistics%20Systems%20Design/Full%20Text%20PDF/Manufacturing%20Systems.pdf

