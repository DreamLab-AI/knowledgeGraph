Safety stock is the additional quantity of an item held in inventory beyond the expected demand during the lead time, kept to prevent stockouts.[^1][^2]

A Utah open textbook says it acts as insurance against demand spikes or delays in replenishment, and that its primary goal is to prevent stockouts and maintain service levels without excessively increasing holding costs.[^1] An APICS magazine article puts it as inventory carried to prevent stockouts, which stem from factors such as fluctuating customer demand, forecast inaccuracy and variability in lead times for raw materials or manufacturing.[^2] MIT lecture slides say safety stock exists to protect against uncertainty in demand, in lead times and in yields, and serves as a counter measure to uncertainty and disruption in the supply chain.[^3]

## What drives the amount

The Utah text says the amount of safety stock needed increases with both the variability of demand and the desired level of customer service, and names lead time variability as the inconsistencies in the time it takes to receive replenishment orders.[^1] A review of operations and supply chain management says safety stocks are calculated to buffer against forecasting errors, lead time variability or other uncertainties.[^5] The Penn State note adds that a periodic review system needs more safety inventory than a continuous review system for the same availability target; see [[Periodic Review Policy]].[^4]

## Scope and distinctions

The APICS article says safety stock determinations are not intended to eliminate all stockouts, only the majority of them.[^2] The Utah text separates safety stock from buffer inventory, which it says focuses on internal variability such as normal fluctuations in production rates, setup times and process yields.[^1] This corpus lists buffer stock as an alias, but the Utah text does not treat the two as the same.

Safety stock is one of the role-based types at [[Inventory Type]]; see also [[Reorder Point Policy]].

## What the sources do not establish

Formulas for safety stock are not reproduced, since they depend on the demand distribution and service measure chosen. The APICS article is a cite-only source and is paraphrased.

[^1]: Utah Pressbooks (Introduction to Operational Excellence), “Inventory MGT in Uncertainty”. https://uen.pressbooks.pub/opexintro/chapter/inventory-mgt-in-uncertainty/
[^2]: Peter L. King, APICS magazine, July/August 2011 (copy hosted by MIT 2.810), “Understanding safety stock and mastering its equations”. https://web.mit.edu/2.810/www/files/readings/King_SafetyStock.pdf
[^3]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf
[^4]: J. E. Tyworth, Penn State Smeal College of Business SCM 810 technical note, February 2014, “Basic Multi-period Inventory Systems”. https://courses.smeal.psu.edu/SCM810/scm_810_module_3/Multi%20Period%20Inventory%20Systems%20Teaching%20Note.pdf
[^5]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

