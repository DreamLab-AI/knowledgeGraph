The component of a robot navigation system that converts a global route into safe, kinematically feasible velocity commands over a short horizon, reacting in real time to obstacles detected by onboard sensors. Operating at control rates of five to twenty hertz over a rolling window of a few metres, a local planner evaluates candidate trajectories against a local costmap and the robot's kinodynamic limits, selecting commands that make progress along the global path while avoiding collisions. Classic realisations include the Dynamic Window Approach, Timed Elastic Bands, and sampling-based controllers such as MPPI; in sampling-based roadmap methods the same term names the routine that checks whether two configurations can be connected by a simple collision-free motion.

### Semantic Classification

### Content

## Definition

Mobile-robot [[Navigation]] is conventionally split into two cooperating layers. A global planner searches a map for a route from start to goal — an A* or Dijkstra path over a costmap, or a roadmap query — but that route is computed against a static, possibly stale world model. The **local planner** closes the gap with reality: running continuously at control rate, it consumes the robot's current pose from [[Localisation]], a local costmap built from live sensor data, and the next stretch of the global path, and emits velocity commands that follow the route while steering around pedestrians, furniture, and anything else the map never knew about.

The dominant designs are trajectory-sampling controllers. The Dynamic Window Approach (DWA) samples velocity pairs reachable within the robot's acceleration limits, forward-simulates each for a short horizon, and scores the resulting arcs on path adherence, goal progress, and obstacle clearance. Timed Elastic Band (TEB) planners instead deform a time-parameterised trajectory under attractive and repulsive forces, handling car-like kinematics gracefully. Model Predictive Path Integral (MPPI) and other MPC-style controllers, now the default in ROS 2 Nav2, optimise over thousands of sampled rollouts on the fly. All are exercises in constrained [[Trajectory Planning]] compressed into a few tens of milliseconds.

The term carries a second, older sense in sampling-based motion planning: in a [[Probabilistic Roadmap]], the "local planner" is the subroutine that attempts to connect two sampled configurations with a simple motion (usually a straight line in configuration space) and reports whether it is collision-free. Both senses share the same essence — solving the easy, short-range piece of a planning problem cheaply and often, so a more expensive global method can treat it as a primitive.

## Technical Details

- **Inputs**: global path segment, local costmap (rolling window, typically 3–10 m), current pose and velocity estimate, robot footprint and kinodynamic limits.
- **Outputs**: body velocity commands (linear and angular), typically published at 10–20 Hz to a [[Velocity Control]] loop.
- **ROS ecosystem**: `base_local_planner` (DWA) and `teb_local_planner` in ROS 1; Nav2's controller server in ROS 2 hosts DWB, Regulated Pure Pursuit, and MPPI as plugins behind a common interface.
- **Failure handling**: when no admissible trajectory exists, navigation stacks trigger recovery behaviours — costmap clearing, in-place rotation, or requesting a global replan.

  ## Current Landscape

- **MPPI is the shipped default**: as of the ROS 2 Kilted release (2025) and Rolling, MPPI is the default controller in Nav2's controller server configuration, confirmed by the Nav2 maintainers in June 2025; DWB and Regulated Pure Pursuit remain available as plugins from Humble onwards.
- **Major performance rewrite**: in January 2025 the Nav2 team announced a full reimplementation of the MPPI optimiser from xtensor to Eigen, yielding roughly 45-50% speedups — over 120 Hz CPU-only on an i7-1365U, and user reports of 55-60 Hz on NVIDIA Jetson Orin — and enabling ARM processors without wide SIMD support. The rewrite landed in Kilted/Rolling and was not backported to Jazzy.
- **New MPPI capabilities**: the Kilted-to-L-turtle cycle added a trajectory-validator plugin for the MPPI controller (collision, obstacle-margin, and progress checks on the output trajectory), an open-loop initial-state option for high-latency odometry, and optional publication of the full optimal `nav2_msgs/Trajectory` for downstream multi-stage control.
- **Stack-level changes**: Kilted moved all velocity command topics from `Twist` to `TwistStamped` by default, released the new Route Server for global routing, and Smac planner traversal-function optimisations delivered a further 20-25% planning speedup (backported to Jazzy).

  **Sources**:

- https://docs.nav2.org/migration/Jazzy.html
- https://docs.nav2.org/migration/Kilted.html
- https://github.com/ros-navigation/navigation2/issues/5244
- https://discourse.openrobotics.org/t/nav2-speedups-in-mppi-smac-planner/41667

### Provenance

