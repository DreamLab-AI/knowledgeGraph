Supply chain provenance is information about the origin and history of goods as they pass through a supply chain, and no source opened here defines the term in that sense, so the page is bounded by a general definition of provenance and by what traceability sources record.[^1][^2]

The W3C PROV data model defines provenance as information about entities, activities and people involved in producing a piece of data or thing, which can be used to form assessments about its quality, reliability or trustworthiness.[^1] The model is domain-agnostic but has extensibility points allowing domain-specific information to be included.[^1] It is a data model for any kind of thing and not specific to supply chains.

## What supply chain sources record

GS1 says traceability can relate to the origin of materials and parts, the processing history, and the distribution and location of the product after delivery.[^2] Those are the kinds of information a provenance record would hold. GS1's EPCIS standard is described as enabling the capture and sharing of interoperable information about status, location, movement and chain of custody.[^3]

The Ecodesign for Sustainable Products Regulation defines a digital product passport as a set of data specific to a product, accessible through a data carrier, and a unique product identifier that enables a web link to it.[^4] See [[Ecodesign For Sustainable Products Regulation]].

## Scope and distinctions

Provenance is a record of origin and history; [[Supply Chain Traceability]] is the capability to trace goods, and [[Supply Chain Transparency]] concerns disclosure of such information. The individual product case is [[Product Provenance]]. The two provenance pages overlap closely, and the sources opened do not distinguish them, so a merge is a question for the corpus owner. No source opened addresses how provenance claims are verified.

[^1]: World Wide Web Consortium, W3C Recommendation, 30 April 2013, “PROV-DM: The PROV Data Model”. https://www.w3.org/TR/prov-dm/
[^2]: GS1, Global Traceability Standard Release 2.0 (ratified August 2017), “GS1 Global Traceability Standard”. https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard
[^3]: GS1, “EPCIS & CBV”. https://www.gs1.org/standards/epcis
[^4]: European Parliament and Council of the European Union, Regulation (EU) 2024/1781 of 13 June 2024, “Regulation (EU) 2024/1781 of the European Parliament and of the Council establishing a framework for the setting of ecodesign requirements for sustainable products”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1781

