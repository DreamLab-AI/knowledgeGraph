Cradle-to-cradle design is a design framework in which products are conceived so that their materials can circulate as safe nutrients for biological or technical cycles, instead of ending as waste.[^1]

Architect William McDonough and chemist Michael Braungart presented the framework in their 2002 book Cradle to Cradle: Remaking the Way We Make Things, which put forward a design framework characterised by three principles derived from nature.[^1] The overview document says everything can be designed to be disassembled and safely returned to the soil as biological nutrients, or reutilised as high quality materials for new products as technical nutrients.[^1] It says that rather than seeking to minimise the harm we inflict, the framework reframes design as a positive, regenerative force.[^1]

## Certification

MBDC created a certification programme in 2005 to recognise achievement in applying the principles.[^1] The document is prepared by the leading accredited assessor of that programme, so it is the framework's own account.

## Relation to the circular economy

The Ellen MacArthur Foundation describes the circular economy as a system where materials never become waste and nature is regenerated, based on three principles, driven by design.[^2] That page describes a wider movement and does not discuss Cradle to Cradle, so the two are related by theme and not shown here to be the same thing. See [[Circular Supply Chain]] and [[Material Flow Analysis]].

## What the sources do not establish

No independent assessment of the framework or of certified products was opened. The three principles are not set out in the extracted text of the overview beyond the nutrient cycle quoted above, so the page does not list them. Claims about how many products have been certified, or their effect on supply chains, are not made.

[^1]: MBDC (McDonough Braungart Design Chemistry), overview document, “Cradle to Cradle Certified: The Product Quality Standard for the Circular Economy”. https://mbdc.com/wp-content/uploads/C2C-Certified-Product-Standard_v3.1_compiled.pdf
[^2]: Ellen MacArthur Foundation, “The Circular Economy: Definition & Model Explained”. https://www.ellenmacarthurfoundation.org/topics/circular-economy-introduction/overview

