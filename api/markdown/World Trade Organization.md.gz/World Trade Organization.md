The World Trade Organization (WTO) is the intergovernmental organisation, established in 1995 as successor to the GATT, that administers the multilateral rules governing trade between its 166 members. It provides the negotiated agreements covering goods, services, and intellectual property, a forum for further trade negotiations, a binding dispute-settlement mechanism, and monitoring of members' trade policies, anchored in the principles of non-discrimination (most-favoured-nation and national treatment), tariff bindings, and transparency.

### Semantic Classification

### Content

## Definition

The **World Trade Organization** is the rules-based backbone of the multilateral trading system. Created by the Marrakesh Agreement in 1995, it absorbed and extended the General Agreement on Tariffs and Trade (GATT, 1947), adding services (GATS), intellectual property (TRIPS), and a far stronger dispute-settlement system. Headquartered in Geneva, it counts 166 members accounting for roughly 98% of world trade; decisions are taken by consensus of the entire membership, with the biennial Ministerial Conference as the top decision-making body and a General Council conducting business in between.

Its legal architecture rests on a few load-bearing principles that shape [[International Trade]] law world-wide. *Most-favoured-nation* treatment obliges each member to extend its best tariff terms to all members; *national treatment* forbids discriminating against imported goods once inside the border; *tariff bindings* cap each member's tariffs at negotiated ceilings; and transparency obligations require trade regimes to be published and notified. Exceptions are built in for free-trade agreements, development (special and differential treatment), and public-policy carve-outs such as health and security. The dispute-settlement mechanism — panels with appellate review and authorised retaliation for non-compliance — was long regarded as the most effective court in international economic law, handling over 600 disputes since 1995.

The WTO occupies a distinct niche among the Bretton Woods-era institutions: where the [[International Monetary Fund]] lends to stabilise balances of payments and the World Bank finances development, the WTO makes and enforces rules; and unlike the [[OECD]], a rich-country think-tank and standard-setter without binding enforcement, WTO commitments are legally enforceable obligations spanning developed and developing members alike.

## Current Landscape

The organisation is in a prolonged stress test. The Doha Round of negotiations effectively collapsed, pushing rule-making towards plurilateral and regional agreements; and since December 2019 the Appellate Body has been paralysed by a US block on appointments, allowing losing parties to appeal "into the void". A subset of members operates the interim MPIA arbitration arrangement as a workaround. Meanwhile subsidy races, national-security tariffs, export controls, and industrial policy have moved much of trade politics outside WTO disciplines. Reform debates centre on restoring binding appellate review, updating rules for subsidies and state enterprises, and recalibrating developing-country status.

## Current Landscape

- **MC14 (Yaoundé, Cameroon) failed**: the 14th Ministerial Conference ended on 29 March 2026 with no final declaration and no agreement on the core reform package — the EU attributed the failure to geopolitical fragmentation and rising trade tensions. Modest decisions were adopted on integrating small economies and on SPS/TBT implementation, but substantive reform was deferred to a post-MC14 work plan with no timeline.
- **The e-commerce moratorium lapsed**: the multilateral moratorium on customs duties for electronic transmissions (in place since 1998) expired at MC14 without a universal replacement. As a partial workaround, 66 members covering ~70% of global trade adopted an interim declaration committing not to impose such duties, but major economies including India and the US did not sign.
- **Dispute settlement still broken**: the Appellate Body has now been non-functional for over six years. In February 2025 the US blocked, for the 84th time, a proposal (tabled by Colombia on behalf of 130 members) to start Appellate Body selection. Reform talks on appellate review had "all but ceased" by mid-2025 and were not expected to advance under the Trump administration.
- **MPIA is the working substitute**: the Multi-Party Interim Appeal Arbitration Arrangement continues to provide binding appellate-style review among its participants — its membership grew in 2025 as Paraguay, Malaysia, the United Kingdom, and Vietnam joined, and it now covers roughly 60% of world trade.
- The WTO retains real function through the Trade Facilitation Agreement, the 2022 Fisheries Subsidies Agreement, the Investment Facilitation for Development Agreement (nearly incorporated at MC14), and its monitoring and statistics — still the reference record of world trade policy. Its membership remains 166.

  **Sources**:

- https://policy.trade.ec.europa.eu/news/outcome-14th-wto-ministerial-conference-2026-03-30_en
- https://www.bruegel.org/policy-brief/plan-revitalise-world-trade-organization
- https://taxscape.deloitte.com/article/wto-mc14--what-has-been-agreed-and-what-does-it-mean-for-businesses-.aspx

