A Global Navigation Satellite System (GNSS) is a constellation of satellites that broadcast timed signals enabling receivers to compute their absolute position, velocity and time anywhere on Earth. GPS, Galileo, GLONASS and BeiDou are the principal systems, with receivers trilaterating position from signal travel times across multiple satellites. In robotics, GNSS provides global geo-referenced localisation that anchors local sensor-based estimates to an absolute coordinate frame.

### Overview

- GNSS delivers absolute positioning by measuring how long coded signals take to reach a receiver from satellites with precisely known orbits and clocks. Augmentation techniques such as RTK and PPP refine accuracy from metres to centimetres, while integration with inertial measurement units bridges signal outages. For robots and vehicles, GNSS is the global anchor that complements relative, drift-prone onboard estimation.

### Mechanisms

- Trilateration: solving position from pseudorange measurements to four or more satellites.
- Constellations: GPS, Galileo, GLONASS and BeiDou, each providing independent satellite signals.
- Augmentation: RTK, PPP and SBAS corrections that improve accuracy and integrity.
- Inertial fusion: tight or loose coupling with IMU data via Kalman filtering to handle outages and high dynamics.
- Error sources: ionospheric delay, multipath, satellite geometry and urban canyon signal blockage.

### Applications

- Outdoor autonomous vehicle and drone navigation with global geo-referencing.
- Precision agriculture and surveying requiring centimetre-level positioning.
- Anchoring SLAM and dead-reckoning estimates to an absolute frame.
- Fleet tracking, logistics and timing synchronisation across distributed systems.

### Provenance

