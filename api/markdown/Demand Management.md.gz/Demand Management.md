Demand management is the supply chain management process that balances customers' requirements with the capabilities of the supply chain.[^1]

Croxton, Lambert, Garcia-Dastugue and Rogers write that with the right process in place, management can match supply with demand proactively and execute the plan with minimal disruptions. They say the process is not limited to forecasting but includes synchronising supply and demand, increasing flexibility and reducing variability.[^1]

A PUC-Rio dissertation, summarising Croxton and colleagues, says the process includes forecasting demand and synchronising it with production, procurement and distribution capabilities, that finding ways to reduce demand variability and improve operational flexibility is an important component, and that reduced variability aids consistent planning while flexibility helps the firm respond quickly to internal and external events.[^2]

## Scope and distinctions

Jatta separates forecasting, whose objective is to predict demand, from demand planning, whose objective is to shape demand and produce a resource requirement plan, citing Malpass and Shah.[^3] He adds that the demand plan serves as the strategy from which other plans in the supply chain are generated and that it weighs heavily on upstream performance, including manufacturing, logistics, capacity and safety stock decisions.[^3] Goetschalckx notes that demand planning is an often-used alternative term for short-term forecasting.[^4] See [[Demand Forecasting]], [[Demand Planning]] and [[Demand Sensing]].

## What the sources do not establish

Its definition rests on one journal abstract, and the dissertation that restates it is derivative, so no independent second definition was found.[^1][^2] Jatta and Goetschalckx treat the neighbouring terms and use them differently, so the boundary between demand management and demand planning is not fixed by the sources.[^3][^4]

[^1]: Keely L. Croxton, Douglas M. Lambert, Sebastian J. Garcia-Dastugue and Dale S. Rogers, International Journal of Logistics Management, 2002 (Arizona State University research record, abstract), “The Demand Management Process”. https://asu.elsevierpure.com/en/publications/the-demand-management-process
[^2]: PUC-Rio dissertation (chapter 4, file 32829_5.PDF), chapter 4, Key Components of Demand Driven Supply Chain, of a PUC-Rio dissertation. https://www.maxwell.vrac.puc-rio.br/32829/32829_5.PDF
[^3]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content
[^4]: Marc Goetschalckx, Georgia Institute of Technology course text, “Chapter 2. Forecasting”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/forecasting/forecasting.pdf

