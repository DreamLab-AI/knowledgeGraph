
An agent genesis record is the record of an agent's creation, declared as `GenesisRecord` in the lifecycle module of the Agent Ontology.[^1] The Agent Ontology declares the class without a definition; this one follows from its position. visionGraph places it under [[Lifecycle Management]] and as part of an [[Agent Lifecycle Record]].

A lifecycle record reaches it through `genesisRecord`. It opens the lifecycle that the [[Agent Decommission Record]] closes, with the [[Health Check]] specification and the current state describing the period between.

A genesis record is the natural place to state who created the agent, when, and from which configuration. The class itself carries no properties, so a deployment adds whichever of those fields it needs. It is the anchor from which an agent's later history can be traced. See also [[Lifecycle Management]].

[^1]: Semantic Agent Communication Community Group, “Lifecycle Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/lifecycle.ttl

