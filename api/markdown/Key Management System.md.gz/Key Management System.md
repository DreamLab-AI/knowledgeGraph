A key management system (KMS) is a service or appliance that generates, stores, rotates, distributes and revokes cryptographic keys over their full lifecycle. It enforces access policies and isolates key material, often backed by hardware security modules, so that applications can perform cryptographic operations without directly handling private keys. A KMS is foundational to secure identity, encryption and digital-asset custody.

### Content

- Core functions include secure generation, hardware-backed storage, controlled distribution, scheduled rotation, and auditable revocation. Strong KMS implementations separate duties, log all key operations and meet standards such as FIPS 140 and KMIP, providing the trust anchor on which encryption, signing and authentication ultimately depend.

## SAC-CG Agent Ontology

The draft SAC-CG Agent Ontology declares `KeyManagementSystem` in its identity module as "A system responsible for managing cryptographic keys for an Agent".[^sac-1] This is narrower than the general sense on this page: it is the key manager of one agent. The `managedByKMS` property links an [[Agent Identity]] to it, and the `kmsEndpoint` property gives its endpoint URI. An [[Identity Binding]] names the same system, so an identity can be traced to its key manager either through the class or through the binding. The ontology is a Community Group draft, not a W3C Recommendation.

[^sac-1]: Semantic Agent Communication Community Group, “Identity Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/identity.ttl

