A Cross-Chain Bridge is a protocol-level interoperability artefact — comprising on-chain smart contracts on each connected blockchain plus an off-chain attestation, relay, or proving infrastructure — that enables the trust-minimised transfer of fungible tokens, non-fungible tokens, arbitrary mess...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:BridgeContract))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:Relayer))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ValidatorSet))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:LightClient))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:CryptographicProofSystem))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:MessageVerificationModule))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:LiquidityPool))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:SettlementContract))

    ## Dependency Relationships
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:requires blockchain:SmartContract))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:requires blockchain:ConsensusMechanism))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:requires blockchain:DigitalSignature))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:requires blockchain:SourceChainFinality))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:requires blockchain:DestinationChainExecution))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:CryptographicHashFunction))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:MerkleProof))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:ThresholdSignatureScheme))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:MultiPartyComputation))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:isSubClassOf blockchain:BlockchainInteroperability))

    ## Capability Relationships
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:enables blockchain:CrossChainAssetTransfer))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:enables blockchain:WrappedToken))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:enables blockchain:CrossChainComposability))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:enables blockchain:OmnichainApplication))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:enables blockchain:MultiChainDeFi))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:enables blockchain:CrossChainSwap))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:enables blockchain:ChainAbstraction))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:supports blockchain:CrossChainDEX))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:supports blockchain:CrossChainNFT))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:supports blockchain:BridgedStablecoin))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:supports blockchain:TokenisedRealWorldAssetTransfer))

    ## Implementation Relationships
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:implements blockchain:LockAndMintMechanism))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:implements blockchain:BurnAndMintMechanism))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:implements blockchain:AtomicSwap))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:implements blockchain:HashTimeLockedContract))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:implements blockchain:LiquidityPoolBridge))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:implements blockchain:IntentBasedBridge))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:implements blockchain:OptimisticVerification))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:implements blockchain:ZeroKnowledgeLightClient))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:uses blockchain:MultiSignature))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:uses blockchain:ZKSNARK))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:uses blockchain:DecentralisedVerifierNetwork))

    ## Reduction Relationships
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:reduces blockchain:LiquidityFragmentation))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:reduces blockchain:UserSwitchingCost))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:reduces blockchain:EcosystemSilos))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:introduces blockchain:CentralisedTrustAssumption))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:introduces blockchain:CustodialAttackSurface))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:introduces blockchain:SmartContractRisk))

    ## Association Relationships
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:LayerZero))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:Wormhole))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:Axelar))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:ChainlinkCCIP))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:CentralisedExchangeBridging))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:SideChain))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:NativeRollupInterop))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:ERC7683))
    SubClassOf(blockchain:CrossChainBridge
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:ERC7281))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(blockchain:hasIdentifier blockchain:CrossChainBridge "BC-0441"^^xsd:string)
    DataPropertyAssertion(blockchain:authorityScore blockchain:CrossChainBridge "0.87"^^xsd:decimal)
    DataPropertyAssertion(blockchain:cumulativeBridgeHackLossesUSD blockchain:CrossChainBridge "2800000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:largestSingleHackUSD blockchain:CrossChainBridge "625000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:largestSingleHackName blockchain:CrossChainBridge "Ronin Bridge March 2022"^^xsd:string)
    DataPropertyAssertion(blockchain:dominantVendorCount blockchain:CrossChainBridge "7"^^xsd:integer)
    DataPropertyAssertion(blockchain:WBTCMarketCapUSD2025 blockchain:CrossChainBridge "9000000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:LayerZeroCumulativeVolumeUSD blockchain:CrossChainBridge "100000000000"^^xsd:integer)

    ## Property Constraints
    SubClassOf(blockchain:CrossChainBridge
      ObjectMinCardinality(2 blockchain:connectsChain))
    SubClassOf(blockchain:CrossChainBridge
      ObjectMinCardinality(1 blockchain:hasTrustModel))
    SubClassOf(blockchain:CrossChainBridge
      ObjectMinCardinality(1 blockchain:hasMechanismType))

    ## Annotations
    AnnotationAssertion(rdfs:label blockchain:CrossChainBridge "Cross-Chain Bridge"@en)
    AnnotationAssertion(rdfs:comment blockchain:CrossChainBridge "Protocol artefact comprising on-chain smart contracts on each connected blockchain plus off-chain attestation/relay/proving infrastructure enabling trust-minimised transfer of tokens, NFTs, and arbitrary message payloads between sovereign chains. Mechanism families: lock-and-mint, burn-and-mint, atomic swap, liquidity-pool, intent-based. Trust models: natively-verified (IBC, NEAR Rainbow, Polymer, zkBridge), externally-verified (Wormhole Guardians, Axelar validators), MPC-based, federated multisig, optimistic, restaking-secured. Dominant 2025-2026 vendors: LayerZero V2, Wormhole, Axelar, Chainlink CCIP, Hyperlane, Across, Stargate. Historically most catastrophic Web3 attack surface — $2.8B+ cumulative bridge theft 2021-2024 per Chainalysis incl. Ronin $625M, BNB $570M, Wormhole $325M, Nomad $190M, Multichain $130M, Orbit $82M. Standardised by ERC-7683 cross-chain intents and ERC-7281 sovereign bridged tokens."@en)
    AnnotationAssertion(dcterms:identifier blockchain:CrossChainBridge "BC-0441"^^xsd:string)
    AnnotationAssertion(dcterms:subject blockchain:CrossChainBridge "Blockchain Interoperability, Cross-Chain Bridges, Wrapped Tokens, Bridge Hacks, Chain Abstraction"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(blockchain:requires)
  AsymmetricObjectProperty(blockchain:enables)
  AsymmetricObjectProperty(blockchain:implements)
  AsymmetricObjectProperty(blockchain:contrastsWith)
  TransitiveObjectProperty(blockchain:dependsOn)
  FunctionalDataProperty(blockchain:largestSingleHackUSD)
  FunctionalDataProperty(blockchain:cumulativeBridgeHackLossesUSD)

## About Cross-Chain Bridges

- A **Cross-Chain Bridge** is the concrete product-level instantiation of the broader [[Blockchain Interoperability]] paradigm: where interoperability names the general capability of sovereign blockchains to exchange state, a bridge names a specific protocol artefact — a deployed pair (or set) of smart contracts plus an off-chain verification infrastructure — that performs that exchange for a particular asset class, message type, or chain pair. The distinction is not merely terminological. Interoperability is an architectural property of the multi-chain ecosystem; a bridge is a piece of software with version numbers, audits, custodians, attack surfaces, and an on-chain TVL figure. This page focuses on the artefact: its mechanism, trust assumptions, vendor landscape, and historical security record.
- The bridge problem appeared the moment Ethereum-incompatible chains accumulated economic significance. Bitcoin holders wanted yield on Ethereum DeFi; Ethereum users wanted Solana's throughput; Cosmos zones wanted Ethereum stablecoins. The naïve solution — sending tokens directly — was impossible: Bitcoin has no smart contracts capable of representing wrapped Bitcoin's mint authority, Ethereum has no native awareness of Cosmos consensus, Solana's account model is foreign to the EVM. Bridges solved this by introducing a trusted (or trust-minimised) third party that observed events on a source chain and instructed corresponding mint/release actions on a destination chain. By 2022 the bridge industry collectively secured tens of billions of dollars of user assets; by 2024 it had lost roughly $2.8 billion of those assets to exploits, key compromises, and protocol failures.
- Bridges are not a single technology. They are a **product category** at the security-performance-decentralisation trilemma frontier, with engineering choices spanning multiple orthogonal axes. The mechanism axis (how value moves) is distinct from the trust axis (who attests to that movement) — Wormhole's lock-and-mint mechanism is secured by a 19-Guardian externally-verified committee, while NEAR's Rainbow Bridge also performs lock-and-mint but is secured by Ethereum light-client verification on NEAR plus a NEAR light client (with optimistic challenge) on Ethereum. The economic axis (whether bridge operators have skin-in-the-game) introduces yet another dimension: LayerZero V2's DVN-based model lets each application choose its attestor set with stake-weighted security, while EigenLayer-secured bridges leverage restaked ETH as cryptoeconomic collateral. Understanding any specific bridge requires reading along all three axes simultaneously.

### Mechanism Families

Bridges differ first in **how value moves** between chains. Five canonical mechanisms dominate 2025-2026 deployments:

#### Lock-and-Mint (Wrapped Tokens)

The original bridge mechanism: source-chain user locks asset A in a bridge contract; bridge operators attest to the lock; destination-chain contract mints a wrapped representation A' equal 1:1 to the locked asset. Reversal burns A' on destination and unlocks A on source. The wrapped token A' has no native fungibility with A — it exists only because the bridge custodian (or contract) holds the underlying.

**Production examples (2025-2026)**:

- **WBTC** (Wrapped Bitcoin): Bitcoin locked with BitGo + BiT Global custody, ERC-20 minted on Ethereum. Largest wrapped Bitcoin (~$9B TVL 2025) but controversial August 2024 custody transition (BitGo → 50/50 BitGo + BiT Global) prompted MakerDAO to debate WBTC collateral status and stimulated growth of alternatives.
- **tBTC** (Threshold Network): decentralised threshold-signature wrapped Bitcoin (~100-of-100 signing group ECDSA threshold) eliminating single-custodian risk, ~$200M circulating 2025.
- **cbBTC** (Coinbase Wrapped Bitcoin): launched September 2024 with Coinbase as sole custodian (regulated US qualified custodian), grew to ~$2B within 6 months — a centralised but regulated alternative to WBTC.
- **FBTC** (Ignition Wrapped Bitcoin): multi-custodian federation model (~$300M circulating), backed by Mantle network and Antalpha.
- **renBTC**: defunct November 2022 with Alameda Research collapse (Ren was acquired by Alameda before FTX implosion); cautionary tale of custodian counterparty risk.
- **Polygon PoS Bridge**: lock-and-mint of ERC-20 tokens between Ethereum L1 and Polygon PoS chain; secured by 5-of-8 federated multisig of Polygon validator set.
- **Avalanche Bridge**: 6-of-8 multisig running inside Intel SGX trusted execution environments providing remote attestation; secured ~$5B at peak.

  The lock-and-mint mechanism is most exposed to **custodian counterparty risk** — if the multisig or MPC group holding source-chain assets is compromised, the wrapped tokens become unbacked claims.

  #### Burn-and-Mint (Canonical Issuer Model)

  Reverses the custodial logic: the **token issuer** retains mint authority across all chains; bridge protocols are merely permissioned to invoke that authority based on cross-chain attestation. The user burns canonical tokens on the source chain; the issuer mints fresh canonical tokens on the destination chain. No locked collateral exists — the issuer's balance sheet (or contract logic) guarantees redemption.

  **Production examples**:

- **Circle CCTP** (Cross-Chain Transfer Protocol, launched 2023): USDC burnt on source chain, minted on destination. Native USDC on every supported chain — no wrapped USDC.e variants. Eliminates ~$3B+ of legacy wrapped USDC exposure as users migrate.
- **LayerZero OFT** (Omnichain Fungible Token): token issuer deploys OFT contract on each chain with shared mint authority gated by LayerZero messages. Adopted by Stargate STG, Radiant RDNT, Pendle PT/YT tokens, PancakeSwap CAKE multi-chain.
- **Wormhole NTT** (Native Token Transfers, launched 2024): equivalent to OFT but secured by Wormhole Guardians; adopted by Lido stETH multi-chain, Wormhole W token, Jito JTO.
- **xERC20 / ERC-7281**: standardises burn-and-mint for arbitrary tokens with per-bridge minting limits set by the issuer (rate-limit prevents catastrophic bridge compromise from destroying token economics).

  Burn-and-mint is structurally safer than lock-and-mint because the **issuer absorbs the trust assumption** rather than the bridge — at the cost of requiring issuer participation.

  #### Atomic Swaps (Hash Time-Locked Contracts)

  Two counterparties on two chains lock funds in HTLCs (Hash Time-Locked Contracts) that release upon revelation of a shared cryptographic preimage. The first party to claim must reveal the preimage on-chain, which the second party then uses to claim. If either fails to act, time-locks return funds. Trustless, but requires direct counterparty matching and active monitoring.

  **Production examples**:

- **Bitcoin-Litecoin atomic swaps** (Decred 2017 original demonstration; Komodo BarterDEX 2017).
- **COMIT Network**: HTLC-based protocol for Bitcoin↔Ethereum atomic swaps, limited commercial uptake.
- **Atomex**: HTLC atomic-swap DEX between Tezos, Bitcoin, Ethereum, Bitcoin Cash, Litecoin.
- **Submarine swaps** (Lightning Network ↔ on-chain Bitcoin): HTLC-based bridging between LN and Bitcoin L1.
- **Lightning ↔ Ethereum** via TeleportDAO and others (experimental).

  Atomic swaps are the most trust-minimised mechanism but suffer from **liquidity fragmentation** (requires counterparty match), **front-running** vulnerability, and **slow settlement** (limited by both chains' confirmation times). They have largely been displaced by intent-based bridges that offer similar guarantees with better UX.

  #### Liquidity-Pool / Liquidity-Network Bridges

  Source and destination chains each maintain liquidity pools of the same asset. User deposits asset on source chain pool; the destination chain pool releases funds to the recipient. Pools rebalance via LP incentives, periodic rebalancing transactions, or LayerZero-style guaranteed-finality algorithms (Stargate's Delta).

  **Production examples**:

- **Hop Protocol**: AMM exit pools on each Ethereum L2 for "h-tokens" (hETH, hUSDC); bonders front user funds for instant transfer; rollups settle to L1 periodically. ~$15B cumulative volume.
- **Synapse Protocol**: nUSD and nETH metapools on 25+ chains; cross-chain swaps via curve-style stableswap; pioneered Synapse Cross-Chain Communication framework for arbitrary messages.
- **Stargate Finance**: built on LayerZero, Delta algorithm guarantees instant finality and unified pools; native USDC/USDT/ETH/FRAX pools across 15+ chains; ~$10B cumulative volume.
- **Connext / Chain Abstraction**: xCall liquidity networks plus xERC20 (ERC-7281) standard; integrates Across, Hyperlane, Wormhole as pluggable transport options.
- **Symbiosis Finance**: curve-style stableswap across EVM and non-EVM (BSC, TRON, Bitcoin); meta-router for cross-chain stablecoin swaps.

  Liquidity-pool bridges trade capital-efficiency (LP capital sits idle in pools) for **fast finality** (no need to wait for source-chain finality before destination-chain release).

  #### Intent-Based Bridges

  User signs an off-chain intent: "I want X output on chain B given Y input on chain A". Solver/relayer network competitively fills the intent: a solver fronts capital on destination chain, then claims source-chain assets via settlement contract enforced by an oracle or fraud-proof mechanism. The user experiences instant fill; the solver bears finality and settlement risk.

  **Production examples**:

- **Across Protocol**: pioneered intent-based bridging; uses UMA Optimistic Oracle for dispute resolution; lowest-fee Ethereum-rollup bridge by 2024-2025 ($30B+ cumulative); originated ERC-7683 cross-chain intents standard co-authored with Uniswap Labs.
- **UniswapX cross-chain mode**: 2024-2025 extension of UniswapX to multi-chain via ERC-7683 settlement.
- **CowSwap Cross-Chain**: CoW Protocol extended to cross-chain via ERC-7683.
- **deBridge DLN** (deBridge Liquidity Network): solver-fulfilled intents with no TVL slashing risk; competitive solver model.
- **Bungee Auto Mode**: Socket-powered intent router selecting optimal solver path.

  Intent-based bridges have become the dominant paradigm for Ethereum-rollup transfers since 2024 because they decouple **user latency** from **source-chain finality** while preserving cryptographic settlement guarantees.

### Trust Models

Orthogonal to mechanism, bridges differ in **who attests to cross-chain events**. The Connext / Arjun Bhuptani trust-minimisation taxonomy (2021, updated 2024) partitions bridges into six trust families:

#### Natively-Verified (Light Client / ZK Light Client)

Destination chain executes a cryptographic light client of source chain and verifies state-transition proofs trustlessly. No external attestor needed — but light-client verification on-chain is expensive (historically 5-15M gas per Ethereum header verification).

- **IBC** (Inter-Blockchain Communication, Cosmos 2021): canonical light-client bridge with TAO (Transport/Authentication/Ordering) layers; 100+ Cosmos zones.
- **NEAR Rainbow Bridge**: Ethereum light client on NEAR plus NEAR light client on Ethereum (optimistic challenge model for gas reduction).
- **Polymer Hub**: launched 2024 as IBC hub for Ethereum rollups, brings native IBC light-client verification to Optimism, Base, Arbitrum via Polymer chain plus succinct ZK proofs.
- **zkBridge implementations**: Succinct Labs SP1 (general-purpose zkVM enabling cheap light-client proofs), Polyhedra Network (ZK light clients for 25+ chains), Telepathy (Ethereum beacon chain light client).
- **IBC v2 / Eureka** (2024-2025): Ethereum-Cosmos light-client interop via Ethermint and Polymer Hub.

  ZK light-client verification reduces gas costs ~95% by 2024-2025, making natively-verified bridges economically viable on Ethereum for the first time.

  #### Externally-Verified (Validator / Oracle Committee)

  External committee attests to source-chain events; destination-chain bridge contract trusts attestations meeting threshold (M-of-N signatures).

- **Wormhole**: 19-Guardian network (Jump Crypto, Coinbase, Certus One, Everstake, Figment, Forbole, P2P, Chorus One, etc.); 13-of-19 threshold; recovered from Feb 2022 $325M exploit via Jump Trading capital injection.
- **Axelar**: ~75 PoS validators (delegated stake-weighted); GMP arbitrary cross-chain calls; Interchain Token Service for canonical tokens.
- **Original LayerZero (V1)**: Oracle (Chainlink) + Relayer (LayerZero Labs) two-of-two model — superseded by V2 DVN architecture.
- **Defunct examples**: Ronin Bridge (5-of-9 validators, compromised March 2022 by Lazarus Group), Harmony Horizon (2-of-5 multisig compromised June 2022).

  Externally-verified bridges achieve **lower gas cost and broader chain support** than natively-verified ones, at the cost of a **new M-of-N trust assumption** beyond either chain's native consensus.

  #### MPC-Secured (Multi-Party Computation)

  Threshold key shared via MPC among bridge operators; signing requires t-of-n cooperation but no individual operator holds the private key.

- **ChainSafe ChainBridge**: open-source MPC bridge framework.
- **Fireblocks MPC custody bridges**: institutional cross-chain via Fireblocks MPC.
- **Multichain MPC** (defunct July 2023): MPC keys lost following CEO arrest in China; $130M user funds frozen — illustrating that MPC alone doesn't prevent operator-level catastrophic failure.

  #### Federated Multisig

  Fixed committee of identified signers (often the bridge developer organisation plus partners) hold m-of-n multisig keys.

- **Polygon PoS Bridge**: 5-of-8 multisig.
- **Avalanche Bridge**: 6-of-8 multisig running inside Intel SGX TEEs with remote attestation — innovative hybrid combining multisig with hardware-enforced computation integrity.
- **Orbit Chain**: 7-of-10 multisig — compromised January 2024 ($82M loss).

  Federated multisig bridges are the simplest but most-exploited trust model — concentration of signing authority in identifiable individuals creates targets for key compromise.

  #### Optimistic Verification

  Default to accepting attestations; permissionless watchers can submit fraud proofs during a challenge window (typically 30 minutes to 7 days). Source-chain assets released only after window closes.

- **Across Protocol**: optimistic relay with UMA Optimistic Oracle, 30-minute (configurable) challenge window for relayer reimbursement.
- **Hyperlane Optimistic ISM**: configurable optimistic Interchain Security Module.
- **Polygon AggLayer pessimistic proofs**: novel variant where unified bridge contract verifies pessimistic proofs covering all AggLayer chains.
- **Nomad (pre-hack)**: optimistic verification but initialisation flaw August 2022 enabled mass replay attack ($190M lost in a coordinated free-for-all).

  Optimistic bridges achieve **low cost and permissionless participation** but introduce **withdrawal latency** equal to challenge window duration.

  #### Economic / Restaking-Secured

  Slashable cryptoeconomic stake collateralises message integrity.

- **LayerZero V2 DVNs**: application chooses any combination of Decentralised Verifier Networks (Google Cloud, Polyhedra ZK, Animoca, Nethermind, Horizen, etc.) with stake-weighted security.
- **EigenLayer AVS bridges**: ETH-restaking secures cross-chain messaging Actively Validated Services.
- **Chainlink CCIP Risk Management Network (RMN)**: independent secondary verifier built on separate client implementation; both DON and RMN must agree before message executes.

### Vendor Landscape (2025-2026)

Production bridge market has consolidated around seven dominant general-purpose vendors plus a long tail of specialist protocols and chain-native bridges:

#### LayerZero V2

Launched Q1 2024 replacing V1's Oracle+Relayer model with **Decentralised Verifier Networks (DVNs)**: each application owner chooses any combination of attestor DVNs (Google Cloud Oracle, Polyhedra ZK, Animoca, Nethermind, Horizen, LayerZero Labs, Stargate DVN, etc.) creating per-application security profiles. Coverage: 100+ chains by 2025. Cumulative bridged volume: $100B+. Anchors Stargate (stablecoin pools), Radiant Capital (cross-chain lending), Pendle (cross-chain yield), PancakeSwap (multi-chain DEX). Standards: **OFT** (Omnichain Fungible Token), **OApp** (Omnichain Application). Funded $263M total (a16z, Sequoia, FTX (pre-collapse), Christie's), valued ~$3B 2024.

#### Wormhole

Solana-originated multichain protocol spanning 30+ chains incl. Solana, Ethereum, Sui, Aptos, Polygon, Cosmos, Algorand. Secured by 19-Guardian externally-verified committee. ~$60B cumulative volume. Native Token Transfers (NTT) framework launched 2024. ZK light-client roadmap 2025. Recovered from Feb 2022 $325M exploit via Jump Trading capital injection — the largest single-incident bridge restoration in DeFi history. Wormhole Foundation tokenised W token April 2024.

#### Axelar

PoS-secured general message passing (GMP) network with ~75 validators. **Interchain Token Service (ITS)** enables canonical token deployment across chains. Squid Router built on Axelar GMP delivering chain-abstraction one-click swap+bridge. Enterprise integrations: J.P. Morgan Onyx, Microsoft Azure Marketplace. AXL token, ~$1.5B FDV 2025.

#### Chainlink CCIP

Enterprise-focused cross-chain interoperability protocol launched 2023 mainnet. Transport via Decentralised Oracle Networks (DONs). **Risk Management Network (RMN)** provides independent secondary verification using separate client implementation — both DON and RMN must agree before message executes (dual-verifier defence-in-depth). Powering the SWIFT cross-chain pilot announced 2023-2024 with **ANZ Bank, BNP Paribas, BNY Mellon, Citi, Clearstream, Lloyds Banking Group, DTCC**, marking the first major institutional adoption of cross-chain messaging for traditional finance.

#### Hyperlane

Permissionless modular interoperability launched 2022. Distinguishing feature: **configurable Interchain Security Modules (ISMs)** — deployers choose multisig, optimistic, aggregate, or ZK ISMs per route. Covers 100+ chains. Nexus token launched 2024.

#### Across Protocol

Founded 2021 by Risk Labs (UMA team). Intent-based architecture with competitive relayer fills and UMA Optimistic Oracle dispute resolution. Lowest-fee Ethereum-rollup bridge by 2024-2025 ($30B+ cumulative). Pioneered ERC-7683 cross-chain intents standard co-authored with Uniswap Labs (finalised 2024).

#### Stargate Finance

Built on LayerZero. **Delta algorithm** guarantees instant finality and unified pools. Native USDC/USDT/ETH/FRAX/sUSD pools across 15+ chains. ~$10B cumulative volume. STG token governance.

#### Second-Tier and Specialist Protocols

- **Connext / Chain Abstraction**: xCall + ERC-7281 (xERC20) sovereign bridged tokens.
- **Synapse Protocol**: AMM nUSD/nETH metapools, 25+ chains, ~$50B cumulative volume.
- **Squid Router**: Axelar-powered chain abstraction; powers Coinbase Wallet Pay, Sushi cross-chain.
- **Symbiosis**: EVM/non-EVM stableswap (TRON, Bitcoin, BSC).
- **deBridge DLN**: intent-based liquidity network with competitive solvers.
- **Wanchain**: secure MPC bridge serving primarily Asian markets.
- **Polygon zkEVM Bridge**: ZK-proof L1↔L2 verification; ~1-hour finality.
- **Optimism Bedrock standard bridge**: 7-day challenge window (optimistic rollup default); supplemented by fast-bridges (Across, Hop) for low-latency withdrawals.
- **Arbitrum native bridge**: Outbox + ArbSys; 7-day withdrawal; fast-withdrawal via Across/Hop/Stargate.
- **zkSync L1 bridge**: native zk-rollup bridge with ~1-3 hour finality.
- **Polymer Hub**: IBC for Ethereum L2 ecosystem.

### Bridge Hack Compendium (2021-2024)

Cross-chain bridges represent the single most catastrophic attack surface in Web3 history. Chainalysis 2024 Crypto Crime Report tallies cumulative bridge theft 2021-2024 at approximately **$2.8 billion**, representing roughly **two-thirds of all DeFi losses** across the period. The major incidents:

| Date | Bridge | Loss (USD) | Root Cause |
|------|--------|-----------|------------|
| Aug 2021 | Poly Network | $611M (recovered) | Smart contract privilege escalation; whitehat returned funds |
| Jan 2022 | Qubit Bridge | $80M | Deposit function logic flaw |
| Feb 2022 | Wormhole | $325M | Signature verification bypass; Jump Trading capital injection restored |
| Mar 2022 | Ronin Bridge | $625M | 5-of-9 validator key compromise via Lazarus Group North Korea spear-phishing |
| Jun 2022 | Harmony Horizon | $100M | 2-of-5 multisig key compromise |
| Aug 2022 | Nomad | $190M | Trusted-root initialisation flaw; mass replay-attack swarm |
| Oct 2022 | BNB Chain Bridge | $570M | IAVL Merkle proof forgery; emergency chain halt |
| Jul 2023 | Multichain | $130M | CEO arrest in China; MPC key custody lost; effective protocol exit |
| Nov 2023 | Heco/HTX | $112M | Hot wallet compromise; Justin Sun ecosystem |
| Jan 2024 | Orbit Chain | $82M | 7-of-10 multisig key compromise |
| Aug 2024 | Ronin redux | $12M | Second incident; whitehat MEV searcher partial recovery |

**Aggregate**: ~$2.8B cumulative theft. Externally-verified bridges (Wormhole, Ronin, Harmony, Orbit) suffered disproportionate losses — six of the ten largest incidents stem from compromise of small-committee attestor sets. The data directly motivated the industry's 2023-2025 pivot toward natively-verified (zkBridge, IBC), economically-secured (LayerZero V2 DVNs, EigenLayer AVS), and intent-based (Across, ERC-7683) architectures.

**Recovery patterns**: Wormhole's Jump Trading bailout ($325M) and Poly Network's whitehat return ($611M) are exceptions. Most exploits result in permanent loss — Ronin's recovery via Sky Mavis equity dilution (~$150M returned via token issuance) and Multichain's frozen funds (~$130M still inaccessible 2025) represent the modal outcome.

### Mitigations and Defence-in-Depth

In response to the bridge-hack ledger, an ecosystem of mitigation primitives has emerged:

#### Bridge Insurance

- **Nexus Mutual**: smart contract cover (~$50M capacity); covers specific bridge protocols; pays out on confirmed exploit events.
- **InsurAce**: parametric cover with cross-chain exposure.
- **Sherlock**: audit-insurance combined model where Sherlock audits AND insures the same protocol.
- **Unslashed Finance**: tokenised insurance market.
- Standard premiums: 1.5-5% APY of covered amount.

  Coverage capacity remains tiny relative to bridge TVL — only ~$50-100M of bridge-specific cover available across all insurers, against $50B+ of bridged assets. Bridge insurance is therefore largely **boutique protection for whales** rather than systemic risk mitigation.

  #### Bridge Aggregators

- **LI.FI**: B2B SDK powering 300+ wallets/apps, integrates 30+ bridges; abstracts vendor selection behind a single API.
- **Jumper Exchange**: consumer-facing LI.FI UI.
- **Bungee**: Socket-powered multi-bridge router.
- **Rango Exchange**: cross-chain DEX aggregator with bridge optimisation.
- **Socket Protocol**: backend infrastructure for Bungee and many wallets.
- **XY Finance**: cross-chain swap aggregator.

  Aggregators reduce **vendor-selection risk** (single bridge failure doesn't trap user funds) but introduce **routing trust** (the aggregator's choice of bridge embeds its own risk model).

  #### Security Audits and Formal Verification

- **Spearbit**: distributed security collective; audited Wormhole, Across, Hyperlane.
- **Trail of Bits**: audited Polygon PoS, Optimism, Arbitrum bridges.
- **Halborn**: audited BNB Bridge pre-hack (controversial; demonstrates audits are necessary but not sufficient).
- **Certora**: formal verification of LayerZero, Stargate contract logic.
- **OpenZeppelin**: bridge components in Compound, Aave deployments.
- **ChainSecurity**: CowSwap cross-chain audits.
- **Code4rena, Sherlock**: competitive audit platforms with bridge-protocol bug bounties.

  Audit budgets for major bridges now reach $1-3M per protocol, with formal verification (Certora-style symbolic execution) increasingly mandated for production deployment.

  #### Standards-Based Risk Reduction

- **ERC-7683** (Cross-Chain Intents, finalised 2024): standardises Order/CrossChainOrder/SettlementContract interfaces enabling solver competition rather than bridge lock-in.
- **ERC-7281** (xERC20 Sovereign Bridged Tokens, Connext-authored 2023): token issuer designates approved bridges with **per-bridge minting rate-limits** preventing a single bridge compromise from destroying token economics. Adopted by Frax, Alchemix, Dolomite, Goldfinch.

### Academic Context

Academic study of cross-chain bridges has produced a small but high-impact literature concentrated in distributed systems venues (CCS, NDSS, S&P, USENIX Security, FC, AFT, DSN) plus blockchain-specific conferences (Stanford BPASE, Financial Cryptography). The canonical references:

- **Belchior et al. (2021)** "A Survey on Blockchain Interoperability: Past, Present, and Future Trends" *ACM Computing Surveys* — most-cited bridge survey (1,500+ citations); proposed the public-connectors / blockchain-of-blockchains / hybrid-connectors taxonomy.
- **Zamyatin et al. (2019)** "XCLAIM: Trustless, Interoperable, Cryptocurrency-Backed Assets" *IEEE S&P 2019* — Imperial College + Kings College authored foundational trust-minimised cross-chain framework; basis for Interlay's interBTC product.
- **Lee et al. (2023)** "SoK: Not Quite Water Under the Bridge: Review of Cross-Chain Bridge Hacks" *IEEE ICBC 2023* — systematic analysis of 16 bridge exploits 2021-2023.
- **Buterin (2021)** "Why Cross-Chain Applications Are Not Worth the Trouble" — influential blog post arguing that **51% attacks** propagate catastrophically across bridged chains, motivating preference for native rollup interop.
- **Bhuptani (2021, updated 2024)** "Connext Trust-Minimisation Taxonomy" — practitioner taxonomy partitioning bridges into natively-verified / externally-verified / optimistically-verified / locally-verified.

### Current Landscape (2026)

**Market structure (2026 estimates)**:

- Total bridge TVL: ~$30B across major protocols.
- Annual bridged volume: ~$500B across all bridges.
- Dominant vendors by volume: LayerZero (35%), Stargate (15%, LayerZero-based), Wormhole (12%), Across (10%), Axelar (8%), Hyperlane (5%), CCIP (5%), all others (10%).
- Bridge aggregator share: ~40% of retail flows route through LI.FI / Jumper / Bungee / Squid.

  **Recent developments (2024-2026)**:

- **LayerZero V2 DVN model** displaced V1 oracle/relayer architecture industry-wide.
- **Wormhole NTT** and **LayerZero OFT** converging on burn-and-mint as dominant token-bridging primitive.
- **ERC-7683** adopted by UniswapX, CowSwap, Bungee, Across, Wormhole; first cross-bridge standard with broad uptake.
- **ERC-7281** xERC20 adopted by Frax, Alchemix; first sovereign-bridged-token standard.
- **Circle CCTP V2** (2024) added hooks for composable cross-chain calls, not just transfers.
- **Polymer Hub** brought native IBC to Ethereum rollups.
- **Polygon AggLayer v0.2-v0.3** unified Polygon-chain liquidity via pessimistic proofs.
- **Optimism Superchain interop** rolled out mainnet 2025 for OP Stack chains.
- **Chainlink CCIP** integrated with SWIFT cross-border pilot involving 7 major banks.
- **EigenLayer-secured bridges** emerging via AVSs (Eigenpie, Renzo, Puffer cross-chain).

### UK Context

British academic, industrial, and regulatory contributions to the cross-chain bridge ecosystem span three principal clusters: **London academic research**, **Northern English industrial activity**, and **UK regulatory and security guidance**.

#### London Academic Research

- **Imperial College London CCRE** (Centre for Cryptocurrency Research and Engineering): William Knottenbelt's group produced **XCLAIM** (Zamyatin et al. 2019, IEEE S&P) — the foundational trust-minimised cross-chain framework using vault-based collateral economics, basis for Interlay's interBTC product on Polkadot. Ongoing research into cross-chain MEV (Maximal Extractable Value) and bridge economic security.
- **University College London Centre for Blockchain Technologies (UCL CBT)**: Paolo Tasca and Rafael Belchior produced "A Survey on Blockchain Interoperability" (Belchior et al. 2021 ACM Computing Surveys), the most-cited bridge survey (1,500+ citations). CBT also hosts the annual Blockchain Bridge Security workshop.
- **University of Cambridge Centre for Alternative Finance (CCAF)**: 2023 analysis of Travel Rule applicability to cross-chain VASP flows; 2024 report on cross-border CBDC bridging mechanisms.
- **University of Edinburgh Blockchain Technology Lab**: Aggelos Kiayias's group on light-client design and succinct cross-chain proofs.
- **King's College London**: co-authored XCLAIM and follow-up cross-chain composability work.

  #### Northern English Industrial Activity

- **Manchester**: Manchester Blockchain Society (~6,000 members); Hut Group's blockchain payments division; UK Web3 Conference Manchester annual event covering bridge security.
- **Leeds**: Leeds Digital Festival regularly includes cross-chain security panels; ATB Financial UK exploring institutional bridge usage; Channel 4's blockchain pilot programmes.
- **Sheffield**: Yorkshire Blockchain Society; University of Sheffield Cybersecurity Research Group's bridge-attack modelling work.
- **Newcastle**: Open Lab cross-disciplinary research touching IoT-blockchain bridging; Newcastle University Cyber Security Centre.
- **Liverpool**: LJMU Cyber Security Research Institute analysing bridge attack vectors and Lazarus Group attribution.

  #### UK Regulatory and Security Guidance

- **National Cyber Security Centre (NCSC)**: 2022-2023 advisories on supply-chain attacks against bridge developers (relevant to Ronin spear-phishing); 2024 guidance on private key custody for cross-chain protocols.
- **Financial Conduct Authority (FCA)**: cross-chain VASP guidance under MLR 2017 (Money Laundering Regulations) amendments; FCA registration requirements treating bridge operators as cryptoasset businesses where applicable.
- **Bank of England / HM Treasury Cryptoassets Working Group**: 2024 consultation responses addressing cross-chain stablecoin bridging implications for the Digital Pound design.
- **Chainalysis UK office** (Canary Wharf, London): operational bridge forensics team that produced public attribution analysis for Ronin Bridge attack and Multichain exit.
- **Elliptic** (London-headquartered): "State of Cross-Chain Crime" annual report; primary commercial source for bridge exploit forensics and laundering pattern analysis.

  #### UK Industry Deployments

- **Copper.co**: institutional digital asset infrastructure with multi-chain custody and bridge connectivity for institutional flows.
- **Fnality International** (UK-launched, Lloyds-backed): institutional payment rails with cross-chain interoperability implications for tokenised commercial bank money.
- **Archax**: FCA-regulated digital exchange providing cross-chain settlement for tokenised securities.
- **Interlay** (Imperial spinout): interBTC trustless Bitcoin-Polkadot bridge based on XCLAIM research.

### Future Directions (2026-2030)

Five trajectories define the bridge ecosystem's evolution through 2030:

#### ZK Light-Client Universalisation

Succinct Labs SP1 (general-purpose zkVM), RISC Zero, Polyhedra Network, and Telepathy are commoditising ZK light-client proofs. By 2027 expect natively-verified bridges to be **default** for new deployments — externally-verified committees survive only for chains lacking ZK support. Cost of Ethereum-IBC light-client verification expected to drop from ~5M gas (2023) to <500K gas (2027) via succinct proof aggregation.

#### Intent-Based Dominance

ERC-7683 adoption accelerates: by 2028 expect **80%+ of retail cross-chain flows** to route through intent-based solvers rather than direct bridge contracts. Bridge protocols become **commodity transport** beneath solver competition layers. Across, UniswapX, CowSwap, deBridge DLN, Bungee Auto Mode lead this transition.

#### Native Rollup Interop Displacement

Polygon AggLayer, Optimism Superchain, Arbitrum Orbit, zkSync HyperChain, Polymer Hub all converge toward **native cross-rollup messaging** within shared ecosystems — partially displacing standalone bridges for intra-ecosystem flows. Cross-ecosystem flows (Polygon ↔ Optimism, Arbitrum ↔ Solana) continue requiring standalone bridges.

#### Restaking-Secured Bridges

EigenLayer AVS bridges, Symbiotic, Karak network restake ETH (and other assets) to collateralise bridge operations with slashable economic security. By 2027 expect **$5-10B of restaked capital** specifically allocated to bridge AVSs.

#### Institutional Cross-Chain Settlement

Chainlink CCIP SWIFT pilot, J.P. Morgan Onyx + Axelar integration, Microsoft Azure + Axelar mark the entry of institutional finance into cross-chain settlement. By 2028 expect **5-10 major banks** running production cross-chain pilots for tokenised securities, cross-border payments, and CBDC bridging. UK regulatory frameworks (FCA, Bank of England) likely to formalise bridge-operator licensing during 2026-2028.

**Aggregate 2030 projections**:

- Total bridge TVL: $150B (5× 2026 level).
- Annual bridged volume: $5T (10× 2026 level).
- Native ZK-light-client bridges: 60% market share.
- Intent-based flows: 80% of retail volume.
- Federated multisig bridges: largely deprecated for new deployments.
- Cumulative bridge insurance capacity: $1B (vs $100M 2026).
- Institutional bridge deployments: 100+ major banks/asset managers.

### Research and Literature

**Foundational Works**:
1. Buterin, V. (2016). Chain Interoperability. *R3 Reports*. [Earliest systematic exposition of bridge problem]
2. Herlihy, M. (2018). Atomic Cross-Chain Swaps. *PODC 2018: Proceedings of the 2018 ACM Symposium on Principles of Distributed Computing*, 245-254. arXiv:1801.09515 [Formal model of atomic swaps]
3. Zamyatin, A., Harz, D., Lind, J., Panayiotou, P., Gervais, A., & Knottenbelt, W. (2019). XCLAIM: Trustless, Interoperable, Cryptocurrency-Backed Assets. *IEEE Symposium on Security and Privacy (S&P 2019)*, 193-210. [Imperial CCRE foundational cross-chain framework]
4. Zamyatin, A., Al-Bassam, M., Zindros, D., Kokoris-Kogias, E., Moreno-Sanchez, P., Kiayias, A., & Knottenbelt, W. (2021). SoK: Communication Across Distributed Ledgers. *Financial Cryptography (FC 2021)*. [Systematisation of cross-chain communication]

**Surveys and Reviews**:
5. Belchior, R., Vasconcelos, A., Guerreiro, S., & Correia, M. (2021). A Survey on Blockchain Interoperability: Past, Present, and Future Trends. *ACM Computing Surveys*, 54(8), Article 168. DOI: 10.1145/3471140 [UCL CBT-affiliated; most-cited bridge survey, 1500+ citations]
6. Augusto, A., Belchior, R., Correia, M., Vasconcelos, A., Zhang, L., & Hardjono, T. (2024). SoK: Security and Privacy of Blockchain Interoperability. *IEEE Symposium on Security and Privacy 2024*. [2024 update covering ZK bridges, restaking-secured bridges]
7. Lee, S.S., Murashkin, A., Derka, M., & Gorzny, J. (2023). SoK: Not Quite Water Under the Bridge: Review of Cross-Chain Bridge Hacks. *IEEE International Conference on Blockchain and Cryptocurrency (ICBC 2023)*. [Systematic analysis of 16 bridge exploits]

**Bridge-Specific Whitepapers**:
8. Buchman, E., Kwon, J., Milosevic, Z. (2018). The Inter-Blockchain Communication Protocol: An Overview. *Cosmos Whitepaper*. [Original IBC specification]
9. LayerZero Labs (2024). LayerZero V2 Whitepaper: Endpoint-Centric Omnichain Interoperability with Decentralized Verifier Networks. [DVN architecture]
10. Hilmes, B., Hentschel, K., et al. (2022). The Wormhole Whitepaper. *Jump Crypto*. [Wormhole Guardian architecture]
11. Axelar Network (2021). Axelar Network: Connecting Application and Blockchain Ecosystems. [Axelar GMP foundational whitepaper]
12. Chainlink Labs (2023). CCIP Whitepaper: Cross-Chain Interoperability Protocol. [DON + RMN dual-verifier model]
13. Hyperlane (2023). Hyperlane Whitepaper: Permissionless Interoperability. [ISM-modular interop]
14. Risk Labs / Across (2022). Across Protocol Whitepaper. [Optimistic intent-based bridging]

**ZK Light-Client and Trust-Minimised**:
15. Xie, T., Zhang, J., Cheng, Z., Zhang, F., Zhang, Y., Jia, Y., Boneh, D., & Song, D. (2022). zkBridge: Trustless Cross-chain Bridges Made Practical. *ACM CCS 2022*, 3003-3017. arXiv:2210.00264 [Foundational zkBridge paper]
16. Polyhedra Network (2024). zkBridge Whitepaper. [Production zkBridge across 25+ chains]
17. Succinct Labs (2024). SP1: A Performant, 100% Open-Source, Contributor-Friendly zkVM. [General-purpose zkVM for light clients]

**Standards**:
18. Bagaria, V., Fish, B., Khanduja, K., Lee, K., Lobban, T., et al. (2024). ERC-7683: Cross-Chain Intents Standard. *Ethereum Improvement Proposals*. [Across+Uniswap+OpenZeppelin authored]
19. Bhuptani, A., Heller, B., et al. (2023). ERC-7281: Sovereign Bridged Tokens (xERC20). *Ethereum Improvement Proposals*. [Connext-authored]

**Bridge Hack Analyses**:
20. Chainalysis (2024). 2024 Crypto Crime Report: Cross-Chain Bridge Hacks. [Aggregate $2.8B 2021-2024 figure]
21. Elliptic (2024). State of Cross-Chain Crime 2024. [London-headquartered forensics]
22. Halborn Security (2022). Ronin Bridge Hack Postmortem. [5-of-9 validator compromise analysis]
23. Trail of Bits (2022). Wormhole Solana Bridge Audit Findings. [Pre-hack audit retrospective]

**Practitioner Taxonomies and Critiques**:
24. Buterin, V. (2021). Why Cross-Chain Applications Are Not Worth the Trouble. *vitalik.eth.limo blog* [51%-attack contagion argument]
25. Bhuptani, A. (2021, updated 2024). Connext Trust-Minimisation Taxonomy. *Connext blog* [Natively-verified / externally-verified / optimistically-verified taxonomy]

**UK and Regulatory**:
26. Cambridge Centre for Alternative Finance (2023). Cross-Border Cryptoasset Travel Rule Implementation. *CCAF Report*. [VASP Travel Rule analysis]
27. UK Financial Conduct Authority (2024). Cryptoasset Promotions and Cross-Chain VASP Guidance. *FCA Policy Statement*.

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review during Phase 6 enrichment sprint
- **Verification**: Bridge mechanism types and trust-model taxonomy cross-referenced against Belchior et al. 2021, Augusto et al. 2024 IEEE S&P, Connext/Bhuptani 2024 taxonomy update, and primary vendor whitepapers (LayerZero V2, Wormhole, Axelar, CCIP, Hyperlane, Across). Bridge-hack figures sourced from Chainalysis 2024 Crypto Crime Report, Elliptic State of Cross-Chain Crime 2024, and rekt.news leaderboard. Vendor market-share estimates derived from DeFiLlama bridge dashboard and Dune Analytics LayerZero/Wormhole/Across dashboards.
- **Regional Context**: UK research (Imperial CCRE-XCLAIM, UCL CBT-Belchior survey, Cambridge CCAF Travel Rule analysis, Edinburgh BTL light clients, King's London), UK regulatory (NCSC bridge-attack advisories, FCA cross-chain VASP guidance, Bank of England Digital Pound consultation), UK forensics (Chainalysis Canary Wharf, Elliptic London), UK industry (Copper.co, Fnality, Archax, Interlay), Northern English clusters (Manchester, Leeds, Sheffield, Newcastle, Liverpool).
- **Sibling Page Disambiguation**: This page covers the **bridge artefact** — protocol, mechanism, vendor, security record. The broader paradigm of inter-chain communication is covered at [[Blockchain Interoperability]]. Cross-linked via `is-subclass-of:: [[Blockchain Interoperability]]`.
- **Production-Ready**: Complete OWL formal semantics, comprehensive coverage of mechanism families / trust models / vendor landscape / hack compendium / mitigations / UK context / 2026-2030 trajectories, 27 numbered bibliography references.
- **Authority Score**: 0.87 (foundational interoperability primitive, $50B+ bridged TVL, $2.8B+ hack history defining Web3 security frontier, mature vendor ecosystem with 7+ dominant production protocols, active 2024-2026 standards activity ERC-7683/7281, broad academic engagement).

### Provenance

