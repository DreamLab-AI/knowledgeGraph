A sequencer is a component in a blockchain rollup or layer-2 system that receives user transactions, orders them into a canonical sequence, and produces blocks or batches for execution and settlement. By fixing transaction order off-chain before posting to the base layer, the sequencer enables fast confirmations and low fees. Sequencer design directly governs liveness, fairness, and the centralisation risk of a rollup.

- A sequencer orders user transactions into a canonical sequence and batches them for a [[Rollup]], enabling fast confirmations before settling to [[Ethereum]].
- It is a defining component of [[Layer 2 Scaling]] and a major determinant of a rollup's liveness, fairness and [[Decentralisation]].

### Overview

- In a rollup, users submit transactions to the sequencer rather than directly to the base chain. The sequencer assigns an order, executes them off-chain, and produces blocks that are eventually posted to [[Ethereum]] for settlement.
- Because ordering is fixed off-chain, users receive near-instant soft confirmations while the base layer provides final security through [[Data Availability]] and dispute resolution.
- A single, operator-run sequencer is simple and fast but introduces centralisation and censorship risk, motivating shared and decentralised sequencer designs.
- Control over transaction order also gives the sequencer influence over [[MEV]], making fairness a key design concern.

### Key aspects

- Transaction ordering: fixing a canonical sequence that downstream execution and proofs rely upon.
- Soft confirmations: giving users fast acknowledgement ahead of base-layer settlement on [[Ethereum]].
- Batching: compressing many transactions into batches posted for [[Data Availability]].
- Liveness and fairness: ensuring the sequencer cannot indefinitely censor or reorder, supporting [[Censorship Resistance]].

### Mechanisms

- The sequencer executes transactions against rollup state and emits ordered blocks that feed [[Optimistic Rollup]] settlement.
- Batches are committed to the base layer, where a [[Fraud Proof]] window allows challenges to invalid state transitions.
- Decentralised and shared-sequencer schemes rotate ordering authority to reduce reliance on a single operator and improve [[Decentralisation]].

### Applications

- Optimistic rollups such as [[Optimism]] and [[Arbitrum]] that depend on a sequencer for ordering and throughput.
- General [[Layer 2 Scaling]] stacks offering low-fee, high-frequency transactions.
- Cross-rollup coordination through shared sequencing for atomic interoperability.

### Provenance

