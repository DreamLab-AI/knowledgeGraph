Last-mile delivery is the last leg of the supply chain, in which goods are moved to their final destinations.[^1]

The LaMiLo project report from Cross River Partnership uses the same wording for last mile logistics and says that getting the last mile right will improve delivery efficiency and so reduce the environmental, economic and social cost of delivery.[^1] A 2024 review from the University of Melbourne states that it is widely known in the literature that last-mile delivery is the supply chain's most expensive and least efficient leg.[^2]

## Demand and policy

The World Economic Forum report of January 2020 says that demand for last-mile delivery is soaring and is expected to grow by 78% globally by 2030. It examines 24 interventions and says the solutions explored by companies and cities generally fall into six categories: vehicle change, secure delivery, customer movement, consolidation, last-leg change and delivery environment.[^3]

## Alternative delivery points

One class of last-mile initiative substitutes a more accessible, sustainable and secure location for the customer's exact delivery address. The Melbourne review calls these alternative delivery points and defines them as locations or facilities other than the customer's primary address where parcels can be collected and delivered.[^2] Types include click-and-collect points, pick-up points and smart parcel lockers.[^2] A Cardiff review says parcel lockers offer a promising solution that integrates digital technology with secure parcel handling.[^4] See [[Parcel Locker]] and [[Click and Collect]].

## Scope and distinctions

Last-Mile Delivery is the final stage within [[Warehousing and Distribution]]. Related pages are [[Parcel Carrier]], [[Autonomous Delivery]], [[Unmanned Aerial Vehicle]], [[Ground Robot]], [[Path Planning]] and [[Logistics Optimisation]].

## What the sources do not establish

Definitions opened here place the last mile at the end of the supply chain but do not fix where it begins. They do not establish robots, drones or route optimisation as the principal automation routes, or the last mile's share of delivery cost and carbon footprint, so the page does not claim them.

[^1]: Cross River Partnership (LaMiLo project), “LaMiLo Public Sector Influence on Last Mile Logistics. Action 8. Output 5. FINAL report”. https://crossriverpartnership.org/wp-content/uploads/2019/03/LaMiLo-Public-Sector-Influence-on-Last-Mile-Logistics.-Action-8.-Output-5.-FINAL-report.pdf
[^2]: University of Melbourne (Mohri and colleagues), Transportation Research Part E 192, 2024, “Contextualizing alternative delivery points in last mile delivery”. https://minerva-access.unimelb.edu.au/rest/bitstreams/a4100875-4af3-46bd-9e31-5638559a10e4/retrieve
[^3]: World Economic Forum, “The Future of the Last-Mile Ecosystem: Transition Roadmaps for Public- and Private-Sector Players”, January 2020. https://www3.weforum.org/docs/WEF_Future_of_the_last_mile_ecosystem.pdf
[^4]: Cardiff University (Zhang and Demir), Frontiers in Future Transportation 6, 2025, “Parcel locker solutions for last mile delivery: a systematic literature review and future research directions”. https://www.frontiersin.org/journals/future-transportation/articles/10.3389/ffutr.2025.1654621/pdf

