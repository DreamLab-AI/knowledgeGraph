Deepfakes and fraudulent content denote synthetic audio, image, video and text artefacts produced by deep generative models (notably GAN-based face-swap pipelines DeepFaceLab/Faceswap/StyleGAN3, diffusion-based face-conditioning ReActor/Roop/InstantID/PhotoMaker/IP-Adapter-Face, lip-sync video ge...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:hasPart society:FaceSwap))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:hasPart society:VoiceClone))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:hasPart society:LipSyncGeneration))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:hasPart society:RealTimeAvatar))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:hasPart society:NonConsensualIntimateImagery))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:hasPart society:SyntheticDisinformation))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:hasPart society:SyntheticIdentityDocument))

    ## Dependency Relationships
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:requires ai:GenerativeModel))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:requires ai:TrainingData))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:requires infra:GPUCompute))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:requires society:DistributionPlatform))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:dependsOn ai:GenerativeAdversarialNetworks))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:dependsOn ai:DiffusionModel))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:dependsOn ai:Autoencoder))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:dependsOn ai:TextToSpeech))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:dependsOn ai:FaceRecognition))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:dependsOn ai:Wav2Lip))

    ## Capability Relationships
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:enables security:SocialEngineering))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:enables society:ElectionInterference))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:enables society:RomanceFraud))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:enables security:BusinessEmailCompromise))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:enables society:ImageBasedSexualAbuse))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:enables finance:MarketManipulation))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:enables security:KYCBypass))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:supports society:DisinformationCampaign))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:supports society:InfluenceOperation))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:supports society:PigButcheringScam))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:supports society:Sextortion))

    ## Implementation Relationships
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:implements society:IdentityImpersonation))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:implements society:AudiovisualForgery))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:implements society:RealTimePuppetry))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:implements security:VoiceCloningAttack))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:uses tool:DeepFaceLab))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:uses tool:FaceSwap))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:uses tool:ReActor))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:uses tool:InstantID))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:uses tool:ElevenLabs))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:uses tool:HeyGen))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:uses tool:Wav2Lip))

    ## Reduction Relationships
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:reduces society:MediaTrust))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:reduces society:InstitutionalLegitimacy))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:reduces society:BiometricAuthenticationReliability))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:reduces society:VictimAgency))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:reduces society:ElectoralIntegrity))

    ## Association Relationships
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:relatedTo society:ContentAuthenticity))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:relatedTo society:MediaForensics))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:relatedTo security:CyberSecurity))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:relatedTo society:ElectionIntegrity))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:contrastsWith society:Shallowfake))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:contrastsWith society:CGIVFX))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:contrastsWith society:AuthenticUGC))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:contrastsWith society:DisclosedSyntheticMedia))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:standardizedBy standard:C2PA))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:standardizedBy regulation:EUAIActArticle50))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:standardizedBy regulation:TAKEITDOWNAct))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:standardizedBy regulation:UKOnlineSafetyAct))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:detectedBy detector:RealityDefender))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:detectedBy detector:SensityAI))
    SubClassOf(society:DeepfakesAndFraudulentContent
      ObjectSomeValuesFrom(society:detectedBy detector:Pindrop))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(society:hasIdentifier society:DeepfakesAndFraudulentContent "SOC-1207"^^xsd:string)
    DataPropertyAssertion(society:authorityScore society:DeepfakesAndFraudulentContent "0.87"^^xsd:decimal)
    DataPropertyAssertion(society:emergenceYear society:DeepfakesAndFraudulentContent "2017"^^xsd:integer)
    DataPropertyAssertion(society:globalFraudLossUSD2025 society:DeepfakesAndFraudulentContent "12500000000"^^xsd:integer)
    DataPropertyAssertion(society:arupFraudLossUSD2024 society:DeepfakesAndFraudulentContent "25000000"^^xsd:integer)
    DataPropertyAssertion(society:projectedDeepfakeFraudUSD2027 society:DeepfakesAndFraudulentContent "40000000000"^^xsd:integer)
    DataPropertyAssertion(society:detectionMarketUSD2025 society:DeepfakesAndFraudulentContent "180000000"^^xsd:integer)

    ## Property Constraints
    SubClassOf(society:DeepfakesAndFraudulentContent
      DataMinCardinality(1 society:hasGenerativeMethod xsd:string))
    SubClassOf(society:DeepfakesAndFraudulentContent
      DataAllValuesFrom(society:isUnconsented xsd:boolean))
    SubClassOf(society:DeepfakesAndFraudulentContent
      DataSomeValuesFrom(society:targetModality xsd:string))

    ## Annotations
    AnnotationAssertion(rdfs:label society:DeepfakesAndFraudulentContent "Deepfakes and Fraudulent Content"@en)
    AnnotationAssertion(rdfs:comment society:DeepfakesAndFraudulentContent "Synthetic audiovisual artefacts produced by deep generative models (GAN face-swap DeepFaceLab/Faceswap/StyleGAN3, diffusion ReActor/InstantID/PhotoMaker, lip-sync Wav2Lip/MuseTalk/LatentSync, voice clone ElevenLabs/Resemble/OpenAI Voice Engine, avatars Synthesia/HeyGen/D-ID) deployed without consent for impersonation, NCII, social engineering, election interference, identity fraud and market manipulation; documented harms 2024-2026 include $25M Arup CFO fraud Hong Kong Feb 2024, Taylor Swift NCII X-platform Jan 2024 (47M views), fake Biden NH primary robocall Jan 2024, Slovakian election audio Sep 2023, UK Sadiq Khan/Starmer audio 2023, Le Pen videos Mar 2024, Crosetto Italian DefMin €1M Feb 2025; countered by C2PA Content Credentials provenance, SynthID/Stable Signature watermarking, Reality Defender/Sensity/Pindrop detection; regulated by EU AI Act Article 50 (Aug 2026), TAKE IT DOWN Act May 2025, UK Online Safety Act 2023, China Deep Synthesis Provisions Jan 2023, South Korea amendment Sep 2024."@en)
    AnnotationAssertion(dcterms:identifier society:DeepfakesAndFraudulentContent "SOC-1207"^^xsd:string)
    AnnotationAssertion(dcterms:subject society:DeepfakesAndFraudulentContent "Synthetic Media, AI Misuse, Online Harms, Information Integrity, Identity Fraud, Election Security, Content Provenance"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(society:enables)
  AsymmetricObjectProperty(society:contrastsWith)
  AsymmetricObjectProperty(society:detectedBy)
  AsymmetricObjectProperty(society:standardizedBy)
  TransitiveObjectProperty(society:dependsOn)
  FunctionalDataProperty(society:emergenceYear)

## About Deepfakes and Fraudulent Content

- **Deepfakes** are synthetic media — most commonly face-swapped video, lip-synced video, voice-cloned audio, or full-body avatar puppetry — generated by deep neural networks trained on reference samples of a target identity, then deployed (typically without consent) to misrepresent that identity. The portmanteau "deepfake" originated in late 2017 from the Reddit user u/deepfakes who posted pornographic celebrity face-swaps generated using a custom autoencoder pipeline; the r/deepfakes subreddit grew to 90,000+ subscribers before Reddit banned it on 7 February 2018 alongside Pornhub, Twitter and Discord enforcement actions. The technology nonetheless escaped into open-source distribution through the DeepFaceLab (iperov, since renamed sf-editor1) and Faceswap (deepfakes/faceswap on GitHub) repositories, both forks of the original u/deepfakes code, accruing 50,000+ combined GitHub stars by 2025.
- The term has since broadened from its original face-swap meaning to encompass any **deep-learning-generated synthetic media used adversarially against an identifiable person**: voice clones executing CEO fraud, full-body diffusion-generated avatars producing romance-scam catfishing, lip-synced footage placing fabricated speech in real politicians' mouths, and synthetic identity documents bypassing know-your-customer (KYC) checks at financial institutions. The boundary with legitimate creative synthetic media (Synthesia corporate training avatars, Disney VFX de-aging, BBC R&D archival voice restoration) is determined by **consent and disclosure** rather than the underlying technology — the same StyleGAN-derived pipelines power both.
- Deepfakes occupy a distinctive position in the threat landscape because they **simultaneously industrialise three previously distinct attack surfaces**: (1) **identity impersonation** (previously requiring skilled human impersonators, sophisticated VFX, or stolen credentials), (2) **scale-out social engineering** (previously bottlenecked by attacker labour), and (3) **plausible-deniability disinformation** (the "liar's dividend" — even authentic incriminating footage can now be dismissed as a possible deepfake, eroding evidentiary norms). The Sumsub *2024 Identity Fraud Report* documented a 245% year-on-year increase in deepfake fraud attempts against KYC providers between 2023 and 2024, with crypto and fintech sectors most affected. Deloitte forecasts annual deepfake fraud losses reaching **$40B in the United States by 2027** (up from $12.3B in 2023, 32% CAGR).

### Origins and the 2017-2018 Inflection Point

The technical preconditions for consumer deepfakes assembled gradually through the mid-2010s. **Autoencoder-based face-swap** had been demonstrated in academic VFX research (Suwajanakorn et al. 2017 "Synthesizing Obama" at SIGGRAPH 2017 producing lip-synced footage of President Obama from audio), and **face-aligned GAN training** had been shown feasible for celebrity datasets (Karras et al. 2018 Progressive GAN producing 1024² photorealistic CelebA-HQ faces). What was missing was a **packaged consumer pipeline** combining face detection (dlib/MTCNN), face alignment, paired-encoder/dual-decoder training, and back-warping into a turnkey tool.
This arrived in **late 2017** when a Reddit user posting under the handle **u/deepfakes** released a Python pipeline using a shared encoder + two decoders (one per identity) trained on aligned face crops; running the encoder on Subject A's frames then decoding with Subject B's decoder produced face-swapped output that, after Poisson blending, approached photorealism on tightly cropped face regions. The r/deepfakes subreddit launched November 2017 and grew explosively as users posted celebrity-pornography face-swaps. The phenomenon attracted mainstream media attention through **Motherboard/Vice journalist Samantha Cole's 11 December 2017 article "AI-Assisted Fake Porn Is Here and We're All Fucked"** and the follow-up January 2018 piece documenting the **FakeApp** desktop tool. Platform bans cascaded in early February 2018: Reddit (7 February), Pornhub, Twitter and Discord all prohibiting non-consensual deepfake imagery within a 14-day window.
The bans did not eliminate the technology — they fragmented it. The u/deepfakes original codebase was forked into the **deepfakes/faceswap** repository (now Faceswap project, 51K GitHub stars 2025), and a more aggressive performance-focused fork by iperov became **DeepFaceLab** (then **DeepFaceLive** for real-time application, 47K combined stars). Both ship pre-built executables, video-frame extraction utilities, automated training loops with masking and colour-correction stages, and one-click conversion pipelines. By 2020 DeepFaceLab was being used to produce 95%+ of identifiable deepfake content on the open web according to Sensity AI tracking.

### Generation Technology Stack (2024-2026)

The 2024-2026 deepfake stack spans four distinct technological generations operating in parallel.

#### Face-Swap GAN/Autoencoder Lineage

- **DeepFaceLab** (iperov, 2018-): Reference open-source pipeline. Encoder-decoder architecture with optional StyleGAN-style refinement (DF-UDT, DF-SAEHD models). Requires 5K-20K aligned face frames per identity, 24-72 hour training on RTX 3090/4090. Outputs include native face-swap and full-head replacement modes. Underlies the majority of identifiable deepfake content.
- **Faceswap** (deepfakes/faceswap, 2018-): Community-maintained fork with broader model zoo (LightWeight, DLight, Phaze-A, Dfaker, Original). GUI-based, lower barrier to entry than DeepFaceLab.
- **DeepFaceLive** (iperov, 2021-): Real-time webcam face-swap derivative of DeepFaceLab, processing 1080p at 30 FPS on RTX 3080+. Enables live video-call impersonation — the technology underlying the 2024 Arup Hong Kong fraud.
- **StyleGAN3 face inversion** (Karras et al. 2021; Roich et al. 2022 PTI): Project target identity into W+ space, edit attributes, regenerate. Lower temporal coherence than autoencoder approaches but superior identity preservation on still images.

  #### Diffusion-Era Face Conditioning (2023-2026)

- **ReActor / Roop** (s0md3v, Hillobar 2023; banned upstream 2023, forked widely): Face-swap node for ComfyUI/A1111 Stable Diffusion, using InsightFace embedding to inject target identity into generated frames. Sub-second per frame on RTX 4090.
- **InstantID** (Wang et al. 2024, InstantX/Xiaohongshu): Identity-preserving image generation from a single reference photo, using face embedding + landmark control. Eliminates the multi-thousand-frame training requirement of autoencoder methods. Open-source, 11K GitHub stars.
- **PhotoMaker** (Tencent ARC Lab 2024): Stacked identity embedding approach producing controllable identity-conditioned generation with text prompts. Released under research licence.
- **IP-Adapter Face** (Tencent AILab 2023): Lightweight image-prompt adapter for SD/SDXL accepting face references; widely used in ComfyUI deepfake workflows.
- **PuLID / PuLID-FLUX** (ByteDance 2024-2025): Pure-and-Lightning identity customisation, contrastive alignment producing high-fidelity identity transfer at FLUX.1 quality.

  #### Video Lip-Sync and Talking-Head Generation

- **Wav2Lip** (Prajwal et al. 2020, IIIT Hyderabad): GAN-based audio-driven lip synthesis, dominant 2020-2023. Produces convincing lip-sync at 96×96 face crop resolution; the workhorse of low-budget deepfake video.
- **SadTalker** (Tencent 2023): Audio-driven 3D-motion coefficients producing full talking-head video from a single still photo.
- **MuseTalk** (Tencent Music 2024): Real-time high-resolution lip-sync (256×256, 30+ FPS) using latent-space inpainting.
- **LatentSync** (ByteDance 2024): Diffusion-based audio-conditional video editing, state-of-the-art lip-sync quality and temporal coherence as of 2024.
- **KEEP** (KEEP authors 2024): Kalman-filter-Enhanced face restoration for cross-modal generation, improving identity preservation in lip-sync pipelines.
- **EMO** (Alibaba HumanAIGC 2024) **and HeyGen real-time avatars 2024-2025**: Diffusion-based audio-to-video producing expressive talking-head footage from a single reference image plus driving audio. Demonstrated photorealistic singing/speaking footage of historical figures. HeyGen's Interactive Avatars (2024) provide real-time conversational deepfake avatars at $30K-$200K/year enterprise tiers.

  #### Voice Cloning

- **ElevenLabs** (London, 2022-, $80M Series B 2024, $1.1B valuation 2024, $3.3B Series C reported 2025): Industry-leading multilingual voice cloning. Instant Voice Clone requires 30 seconds of source audio; Professional Voice Clone uses 30+ minutes. API and Studio tooling. Deployed across audiobooks, gaming, accessibility — and the **fake Biden New Hampshire robocall (Steve Kramer/Lingo Telecom, January 2024)**.
- **Resemble AI** (Toronto/SF 2019-): Enterprise voice synthesis with localisation and watermarking (Resemble Detect 2024).
- **PlayHT (Play.ht)** (San Francisco): Voice cloning + TTS with API distribution.
- **OpenAI Voice Engine** (limited preview March 2024): 15-second sample voice cloning. OpenAI deliberately delayed wider release citing election-year misuse risk; preview partners include Age of Learning, HeyGen, Dimagi.
- **Cartesia Sonic** (Berkeley 2024): Sub-200ms time-to-first-byte streaming TTS, designed for real-time voice agents. State-space-model architecture (Mamba derivative).
- **Meta Voicebox** (research preview 2023, not publicly released): Few-second voice cloning + context-aware speech editing. Meta withheld release citing misuse risk.
- **Microsoft VALL-E / VALL-E X / VALL-E 2** (research papers 2023-2024): 3-second voice cloning with cross-lingual capability; research-only.
- **F5-TTS / E2-TTS / OpenVoice / XTTS-v2** (open-source 2023-2024): Coqui XTTS-v2 (Coqui-AI, company shut down December 2023 but model widely distributed), MyShell.AI OpenVoice, F5-TTS released to Hugging Face with 100K+ weekly downloads. The open weights commoditised voice cloning by mid-2024.

  #### Full-Body Avatars and Synthetic Identity Documents

- **DeepMotion** (Animate 3D, 2014-): Video-to-motion-capture avatar animation.
- **Synthesia** (London, $90M Series C 2023, $2.1B valuation 2024): 230+ stock avatars + custom avatar capture; enterprise focus (Reuters, BBC, Tiffany, Vodafone, AT&T, 60K+ enterprise users). Watermarks all outputs and prohibits political/news use.
- **HeyGen** (Los Angeles, $60M Series A 2024, $500M valuation): Avatar video + Interactive Avatars + AI-powered video translation/dubbing.
- **D-ID** (Israel): Photo-to-talking-head animation, integrated into Microsoft Teams.
- **Hour One** (NYC/Tel Aviv): Avatar video synthesis for corporate communications.
- **Synthetic identity document generators** (criminal marketplace tooling 2024-2025): Diffusion-based passport/driver-licence template generators with name/photo/DoB controls, used to bypass automated KYC at fintechs and crypto exchanges. Sumsub identified deepfake KYC attempts increasing 4× year-on-year 2023→2024 with crypto (88% of incidents) and fintech (8%) the dominant targets.

### Detection Technology

Deepfake detection has matured into a multi-layer industry covering **forensic signal analysis** (frequency-domain GAN-fingerprint detection, blinking-rate analysis, eye-region inconsistency, head-pose-versus-facial-orientation mismatch, biological signals from remote-photoplethysmography heart-rate inference), **deep-learning classifiers** trained on benchmark datasets (FaceForensics++ Rössler et al. 2019 with 1,000 manipulated videos across DeepFakes/Face2Face/FaceSwap/NeuralTextures methods; Deepfake Detection Challenge DFDC organised by Facebook/Microsoft/AWS 2020 with 100K videos and $1M prize pool; DeeperForensics-1.0 Jiang et al. 2020; Celeb-DF Li et al. 2020), **commercial detection-as-a-service platforms**, and **provenance / camera-attestation infrastructure**.

#### Classical Forensic Methods

- **Frequency-Domain Analysis**: GAN-generated images exhibit characteristic spectral artefacts in DCT/DFT representations; up-sampling convolutions introduce periodic high-frequency patterns absent in natural images (Zhang et al. 2019, Frank et al. 2020, Durall et al. 2020). Effective against StyleGAN family but partially neutralised by subsequent re-compression and downstream editing.
- **Blinking and Physiological Inconsistency** (Yang et al. 2019 *"Exposing AI Created Fake Videos by Detecting Eye Blinking"*, Li et al. 2018): Early deepfakes exhibited unnaturally low blinking rates because training datasets contained few closed-eye frames. Modern pipelines have largely corrected this; the technique remains useful as part of multi-signal ensembles.
- **Head-Pose Versus Face-Pose Mismatch** (Yang et al. 2019): Face-swap pipelines decouple the swapped facial region from underlying head pose; pose estimation on the swapped versus surrounding regions can reveal discrepancies.
- **rPPG / Heart-Rate Signal**: Authentic video contains subtle skin colour oscillations driven by cardiac pulse; deepfakes typically lack coherent rPPG signal (FakeCatcher, Intel 2022).

  #### Deep-Learning Classifiers and Benchmarks

- **FaceForensics++** (Rössler et al. 2019, ICCV 2019): The reference benchmark, releasing 1,000 source videos manipulated by four methods, paired with detection baselines achieving 80-99% AUC depending on compression.
- **DFDC (Deepfake Detection Challenge)**: Facebook AI + Microsoft + AWS + Partnership on AI, $1M prize 2019-2020, 100K videos. Winning ensemble (Selim Seferbekov) achieved 65.18% precision on the private test set — far below academic benchmarks, revealing the **generalisation gap** between training distributions and real-world deepfakes.
- **DeepFake-O-Meter** (UB Media Forensics Lab, Lyu et al. 2021): Multi-model ensemble running 10+ open-source detectors as a public web service.
- **DeeperForensics-1.0** (Jiang et al. CVPR 2020): 60K videos with controlled perturbations (compression, blur, transmission noise) for robustness benchmarking.
- **Celeb-DF v2** (Li et al. CVPR 2020): 5,639 high-quality deepfakes with improved blending, exposing fragility of earlier detection benchmarks.

  #### Commercial Detection Platforms (2024-2026)

- **Reality Defender** (New York, $33M Series A 2024, OnPoint Technologies + Booz Allen led): Multi-model ensemble (image, video, audio, document) deployed via API. Customers include HSBC, Mastercard, BNY Mellon, ITV. US Department of Defense and Department of Homeland Security contracts; Cisco Live 2024 partnership.
- **Sensity AI** (Amsterdam, founded 2018 as Deeptrace): Synthetic-media monitoring identifying 100K+ deepfake videos per quarter across social platforms. Enterprise KYC defence (banks, crypto exchanges).
- **Pindrop** (Atlanta): Voice deepfake detection specialised for banking call-centres; protecting 80% of US-top-five banks. Deepfake Voice Detection Module launched 2023.
- **Hive AI Moderation** (San Francisco): General content-moderation API with deepfake detection module; powers Reddit, Quizlet, Vimeo trust-and-safety.
- **Microsoft Video Authenticator** (Microsoft AI for Good, 2020-): Frame-level confidence scoring; deployed via Microsoft's Defending Democracy programme.
- **Truepic** (San Diego): Camera-side cryptographic attestation (truepic.com Vision SDK), used by Ford, BMW, Synchrony, insurance underwriters. Now C2PA core contributor.
- **Get Real Labs** (Hany Farid spin-out, 2024): Founded by UC Berkeley's leading media-forensics academic; multi-modal detection focusing on audio-visual coherence.
- **DuckDuckGoose AI** (Netherlands): EU-focused deepfake detection serving law enforcement, media organisations, financial services.
- **Veridas** (Spain): Identity verification with deepfake injection-attack detection (3DLivenessNet, voice anti-spoofing).
- **Sentinel** (Estonia): EU + NATO StratCom deepfake detection for government and defence.
- **AI or Not / Optic / Fake Image Detector**: Consumer/journalist-focused free or freemium image detectors.

  #### Content Authenticity and Watermarking

- **C2PA (Coalition for Content Provenance and Authenticity)**: Industry standard founded 2021 by Adobe, Microsoft, BBC, New York Times, Sony, Intel, Truepic; merged the Content Authenticity Initiative (CAI) and Project Origin tracks. C2PA 2.0 specification finalised 2024. **Camera firmware integration**: Sony Alpha A1 II / A9 III / A7R V (firmware updates November 2023-2024), Leica M11-P (October 2023, first C2PA-native camera), Nikon Z9 (2024 firmware roadmap), Canon EOS R5C (2024-2025 pilot). **AI generator integration**: OpenAI DALL-E 3 (signed metadata on all outputs from February 2024), Adobe Firefly, Microsoft Bing Image Creator, Google Pixel Magic Editor. **Platform display**: TikTok labelled C2PA-credentialed content from May 2024; LinkedIn from 2024; Meta announced full deployment 2025.
- **SynthID** (Google DeepMind 2023, extended 2024): Imperceptible watermark for Imagen-generated images (2023), Lyria-generated audio (2024), and text via output-token biasing (2024). Open-sourced text watermarking 2024.
- **Stable Signature** (Meta FAIR 2023, Fernandez et al.): Watermark fine-tuned into Stable Diffusion decoder; survives common image manipulations.
- **Tree-Ring Watermarks** (Wen et al. 2023): Diffusion-process watermarking embedded in the noise initialisation.
- **Imatag, Steg.AI, Digimarc**: Commercial invisible-watermarking vendors.

### Documented Fraud and Abuse Incidents (2024-2026)

The 2024-2026 period saw deepfakes transition from research curiosity and amateur celebrity face-swap to **systematic deployment in commercial fraud, election interference, and image-based sexual abuse**. The following incidents are documented in regulatory filings, court records, and major-press reporting.

#### Enterprise / Financial Fraud

- **Arup CFO Deepfake Video-Call Fraud, Hong Kong, January-February 2024**: A finance employee at the Hong Kong office of UK engineering firm **Arup** (designer of the Sydney Opera House and Beijing Olympic stadium) was deceived in late January 2024 by a video call appearing to include the UK-based CFO and several other colleagues — all deepfake puppets, likely DeepFaceLive-class real-time face-swap. The employee executed **15 transfers totalling HK$200 million (≈ $25.6 million USD)** to five Hong Kong bank accounts before discovering the fraud through follow-up with corporate HQ. Hong Kong Police announced the incident on 4 February 2024; Arup confirmed publicly on 17 May 2024 it was the target. **Largest publicly confirmed deepfake-enabled corporate fraud to date.**
- **Ferrari CEO Voice-Clone Attack, July 2024**: An attacker impersonated CEO Benedetto Vigna via WhatsApp voice messages to a senior Ferrari executive, attempting to authorise an "acquisition" wire transfer. The executive grew suspicious of the slightly accented Italian and challenged the caller with a personal question only Vigna would know, defeating the attack.
- **Italian Defence Minister Crosetto Voice-Clone Fraud, February 2025**: Italian businessmen including former Inter Milan president **Massimo Moratti**, Prada CEO Patrizio Bertelli and Armani Group executives transferred funds totalling **€1 million** to a Hong Kong account on the basis of voice-cloned calls purportedly from Defence Minister Guido Crosetto and senior officials seeking funds for an "Italian journalist hostage release". Italian Postal Police froze the account and recovered funds; arrests followed in Sardinia and Spain.
- **WPP CEO Mark Read Deepfake Attempt, May 2024**: Attackers used WhatsApp + Microsoft Teams with a YouTube-sourced photo of Read combined with voice cloning to attempt to set up a new business and extract funds from a WPP agency executive. Read described the incident publicly in an internal memo (later leaked) as the basis for industry warnings.
- **Bland AI Phone-Calling Platform Investigations 2024**: The Bland AI platform (real-time autonomous voice agents) was used in unauthorised marketing calls; CFPB and FCC examined platform misuse alongside the Lingo Telecom Biden-robocall case.
- **Pig-Butchering and Romance Fraud with Live Deepfake Puppetry 2024-2025**: FBI IC3 *2024 Internet Crime Report* (published April 2025) documented $5.6B confirmed crypto-investment fraud losses, predominantly pig-butchering schemes increasingly using **live-deepfake video chat** to maintain personas across weeks-to-months grooming. Aggregate fraud losses across all categories: $12.5B (up 22% YoY).

  #### Election and Political Interference

- **Slovakian Parliamentary Election Audio Deepfake, 29-30 September 2023**: 48 hours before voting, audio deepfakes of **Progresívne Slovensko leader Michal Šimečka** and journalist Monika Tódová circulated on Facebook discussing electoral fraud. Released during Slovakia's 48-hour pre-election silence period preventing rebuttal. Progresívne Slovensko narrowly lost to populist Robert Fico's SMER. The incident became the canonical example of **late-stage deepfake election interference** cited throughout EU AI Act drafting.
- **Fake Biden New Hampshire Robocall, 21 January 2024**: ElevenLabs-cloned audio of President Biden urging Democrats not to vote in the New Hampshire primary, distributed via 5,000-25,000 robocalls. Investigation by AG John Formella + FCC identified Texas-based **Lingo Telecom** as transmitter and political consultant **Steve Kramer** as commissioner. **FCC declared AI-generated robocalls unlawful under TCPA on 8 February 2024** (FCC-24-17A1). Lingo Telecom settled for $1M; Kramer was indicted and fined $6M, faces 13 felony voter-suppression charges (NH).
- **UK Labour Sadiq Khan Armistice Day Deepfake, November 2023**: Audio deepfake of London Mayor Sadiq Khan appearing to disparage Armistice Day and prioritise pro-Palestinian marches circulated on TikTok and X. Khan referred to the Metropolitan Police; under-then-existing UK law no specific offence applied, contributing to amendments to the Online Safety Bill.
- **UK Labour Keir Starmer Conference Audio Deepfake, October 2023**: Audio deepfake of party leader Keir Starmer berating staff posted to X by an account labelled "@Leo_Hutz", garnering 1.4M views in 24 hours.
- **UK MP Deepfake Political Advertisements, 2024**: Multiple UK MPs (Penny Mordaunt, James Cleverly, Wes Streeting, Rishi Sunak) were targets of deepfake-image and deepfake-video political ads on Facebook/X in the run-up to the July 2024 general election. The Online Safety Act's foreign-interference offence provisions activated for the first time.
- **Le Pen Family Deepfake Videos, March 2024**: TikTok-spread deepfake videos of Marine Le Pen, Marion Maréchal-Le Pen and Jean-Marie Le Pen in fabricated dance and party scenes ahead of June 2024 EU elections. EU Commission flagged content moderation gaps under DSA enforcement.
- **Kari Lake / Donald Trump Deepfakes during US 2024 Elections**: Multiple AI-generated images and audio circulated; Lake announced she would sue X over an alleged deepfake of herself. Trump deepfake images depicted endorsements from Taylor Swift (Swift publicly endorsed Harris in response citing the deepfake) and arrest scenarios.
- **Marco Rubio Signal/Voice Impersonation, June-July 2024**: An attacker contacted at least five foreign ministers and US politicians via Signal and voice cloning impersonating then-Senator (and incoming Secretary of State) Marco Rubio. State Department issued a 9 July 2025 cable warning.
- **Indonesian, Indian, Bangladeshi 2024 Election Deepfakes**: Resurrection of deceased politician Suharto (Indonesia February 2024) endorsing Golkar; multiple deepfake political ads across Indian state elections; Bangladesh January 2024 deepfake of US diplomats commenting on the election.

  #### Image-Based Sexual Abuse and Non-Consensual Intimate Imagery

- **Taylor Swift NCII Deepfake Crisis, X (Twitter), 24-26 January 2024**: Diffusion-generated explicit deepfake images of Taylor Swift originating from a Telegram channel posted to X reached **47 million views in 17 hours** before takedown. X temporarily disabled search for "Taylor Swift" 26-29 January 2024. The incident catalysed federal US legislation: the **TAKE IT DOWN Act** (originally introduced June 2024 by Senators Cruz and Klobuchar) passed and was signed 19 May 2025 by President Trump, criminalising publication of NCII (real or AI-generated) and requiring platform takedown within 48 hours.
- **Telegram "Deepfake Room" Scandal, South Korea, August-September 2024**: Investigative journalism by the Hankyoreh and the Korea JoongAng Daily exposed Telegram channels generating deepfake pornography of identifiable South Korean schoolgirls — at least 220 schools confirmed affected, victims as young as 12. National outrage prompted **emergency amendment to the Act on Special Cases concerning Sexual Crimes** (September 2024) criminalising possession and viewing of deepfake pornography (previously only production and distribution were offences).
- **UK School-Based Deepfake NCII Incidents 2023-2025**: Internet Watch Foundation reports documented increasing incidence of male pupils generating deepfake NCII of female classmates and teachers using mobile apps including Clothoff, NudeAI and Deep Nude variants. The UK's **Online Safety Act 2023** made non-consensual sharing of synthetic intimate images an offence; the **Criminal Justice Bill 2024** added a creation offence (Royal Assent late 2024).
- **Spanish Almendralejo Schoolgirls Deepfake Incident, September 2023**: Generative "nudifying" apps used by boys in Almendralejo (Extremadura) to produce NCII of 20+ female classmates aged 11-17. Spanish Data Protection Agency AEPD launched investigation; cases prosecuted under existing child sexual abuse imagery statutes.

  #### Synthetic-Identity and KYC-Bypass Fraud

- **Sumsub 2024 Identity Fraud Report**: Deepfake-attempt rates against KYC at financial institutions rose 245% year-on-year 2023→2024 globally; concentrated in crypto (88% of deepfake fraud), fintech (8%), gambling (2.5%). Bypass techniques include diffusion-generated synthetic ID documents combined with face-swap presentation against liveness checks.
- **Crypto Exchange KYC Bypasses 2024**: OKX, Bybit and Bitget all disclosed bulk-account-creation campaigns using deepfake KYC bypass; collective remediation took down 250,000+ accounts in 2024.
- **OnlyFans/Pornhub Synthetic-Talent Fraud 2024-2025**: Diffusion-generated "creators" used to upload generic content at scale, claiming royalties; OnlyFans introduced biometric capture mandates in 2024.
- **Camera-Injection Attacks**: Modified phones running custom OS layers feeding pre-rendered deepfake video into camera APIs, defeating naïve liveness checks. iProov and Veridas reported 31× growth in camera-injection attacks 2023→2024.
- **iProov *2024 Threat Intelligence Report***: Documented organised crime-as-a-service deepfake-fraud kits sold on Telegram/dark-web markets at $300-$3,000 per kit including pre-trained models, distribution tooling, and "operator" guides.

  #### Targeted Reputation and Market Manipulation

- **Synthetic CEO Statements**: Multiple incidents 2024-2025 of deepfake audio of public-company CEOs distributed via X/Telegram timed to market open, intended to move stock price. SEC issued investor alert May 2024.
- **Deepfake Endorsement Scams**: Martin Lewis (UK), Elon Musk, Andrew Forrest, Holly Willoughby deepfakes used in cryptocurrency-investment Facebook/Instagram ads; Meta sued by Forrest in Australian Federal Court 2022-2024.
- **Insurance Claim Deepfakes**: Allianz, AXA reported 2024 increase in synthetic accident/damage photographs submitted with claims; major UK insurers introduced AI-image-detection 2024-2025.

  #### Aggregate Loss Estimates

- **Deloitte Center for Financial Services (2024)**: Forecasts US deepfake-related fraud losses reaching **$40B by 2027**, up from $12.3B in 2023 (32% CAGR).
- **FBI IC3 *2024 Internet Crime Report***: Total reported internet-crime losses of $16.6B (33% YoY increase); pig-butchering / crypto investment fraud at $5.6B is the fastest-growing category, with FBI explicitly identifying **deepfake video-chat puppetry** as the principal new attack vector since 2023.
- **Sumsub 2025 Identity Fraud Report**: Global deepfake-enabled fraud impact estimated at £2.6 billion (≈ $3.2B) in 2024-2025 economic damage to consumers and enterprises.
- **Onfido / Entrust 2024 Identity Fraud Report**: 31× increase in deepfake-based identity-document fraud attempts 2022→2023, sustained growth through 2024.

### Academic Context: Threat Modelling and Forensics Literature

Deepfake research spans computer vision (face-swap and lip-sync generation, detection), speech processing (voice cloning, anti-spoofing), human-computer interaction (deepfake-perception studies), media forensics (provenance and watermarking), security (KYC injection attacks, biometric anti-spoofing), socio-legal scholarship (NCII, electoral integrity), and an emerging political-science thread on the **liar's dividend** (the second-order effect where the *existence* of deepfakes lets authentic incriminating recordings be dismissed as forgeries, eroding evidentiary norms — coined by Chesney & Citron 2019 California Law Review).

#### Foundational Period (2017-2019)

- **Suwajanakorn, Seitz & Kemelmacher-Shlizerman (SIGGRAPH 2017)**: "Synthesizing Obama" — pre-deepfake academic VFX precursor demonstrating audio-to-lip-sync at near-photoreal quality.
- **Korshunov & Marcel (Idiap 2018)**: Earliest published academic threat assessment of consumer-grade deepfakes against face recognition systems.
- **Chesney & Citron (California Law Review 2019)**: "Deep Fakes: A Looming Challenge for Privacy, Democracy, and National Security" — foundational legal scholarship articulating the liar's-dividend concept.
- **Yang, Li & Lyu (ICASSP 2019)** + **Li, Chang & Lyu (WIFS 2018)**: Head-pose and eye-blink forensic detectors — seminal early detection literature.

  #### Detection-Benchmarks Era (2019-2021)

- **FaceForensics++ (Rössler et al., ICCV 2019)**: 1,000-video benchmark with four manipulation methods; remains the canonical evaluation set 2019-2025.
- **Deepfake Detection Challenge (DFDC, 2020)**: Facebook/Microsoft/AWS, $1M prize, 100K videos, demonstrated the persistent generalisation gap (65% precision on out-of-distribution test set).
- **Celeb-DF (Li et al., CVPR 2020)**: Improved blending revealing fragility of prior benchmarks.
- **Frequency-domain detection (Frank et al. ICML 2020, Zhang et al. ICASSP 2020)**: Exploited up-sampling-convolution spectral artefacts.

  #### Audio-Deepfake and Anti-Spoofing

- **ASVspoof Challenge series 2015-2024 (Edinburgh, Idiap, EURECOM, NEC, NII)**: Established the audio-anti-spoofing benchmarking community. ASVspoof 2024 introduced cross-lingual and partial-spoof tracks.
- **WaveFake (Frank & Schönherr, NeurIPS 2021)**: Benchmark dataset for audio deepfakes covering MelGAN, WaveGlow, Parallel WaveGAN voices.
- **AudioDeepfake-Eval (2023-2024)**: Open evaluation framework adding modern voice-clone systems.

  #### Provenance and Watermarking Research

- **C2PA Specification 1.0 (2022) and 2.0 (2024)**: Industry-standard cryptographic provenance; merged Content Authenticity Initiative (Adobe-led, 2019) and Project Origin (BBC/Microsoft/CBC/NYT, 2020) tracks.
- **Stable Signature (Fernandez et al., ICCV 2023)**: Meta watermark fine-tuned into Stable Diffusion decoder.
- **Tree-Ring Watermarks (Wen et al., NeurIPS 2023)**: Watermark via noise-initialisation patterning, robust to JPEG and crops.
- **SynthID-Text (Dathathri et al., Nature October 2024)**: Google DeepMind statistical watermarking of LLM outputs published in *Nature*, deployed across Gemini family.

  #### Socio-Legal and Threat-Landscape Research

- **Europol Innovation Lab (2022, 2024 update)**: "Facing Reality? Law enforcement and the challenge of deepfakes" — EU LEA operational doctrine.
- **Sumsub Identity Fraud Reports (annual 2022-2025)**: Industry data series tracking deepfake-attempt rates against KYC providers; the principal industry source on attack-frequency trends.
- **Onfido / Entrust Identity Fraud Report (annual)**: Document-fraud and biometric injection-attack data.
- **Vaccari & Chadwick (Social Media + Society 2020)**: Empirical study showing deepfakes increase uncertainty more than they actively deceive — supporting the liar's-dividend hypothesis.
- **Oxford Internet Institute / COMPROP**: Quantitative tracking of synthetic-media-amplified influence operations 2020-2024.

### Current Landscape (2026)

As of May 2026, deepfakes occupy a paradoxical position in the information ecosystem: simultaneously a **mass-market consumer technology** (Synthesia, HeyGen, ElevenLabs serving 60K+ enterprises with consensual use-cases), a **maturing fraud-economy vector** (Deloitte $40B 2027 forecast for US alone, Sumsub 245% YoY KYC-attack growth 2023→2024), and the **subject of newly-binding statute** (EU AI Act Article 50 full applicability August 2026, TAKE IT DOWN Act signed May 2025, Ofcom OSA Illegal Content Codes effective March 2025).

#### Market and Threat Position

- **Generative-AI Market 2026**: $50-65B aggregate (Gartner, McKinsey). Synthetic-media subset (avatars, voice, video) ≈ $4-6B 2026 rising toward $20-30B 2030, with the *consensual* enterprise share dominant in revenue (Synthesia, HeyGen, ElevenLabs, Descript, Runway) and the *adversarial* share dominant in social harm (fraud, NCII, disinformation).
- **Deepfake Fraud Loss 2025**: ≈ £2.6B / $3.2B global economic damage (Sumsub 2025); projected $40B US-only 2027 (Deloitte 2024).
- **Detection Market 2025**: ≈ $180M (Reality Defender + Sensity + Pindrop + Hive + Get Real Labs revenue aggregate); projected ~$1.5B 2030.
- **Provenance Adoption 2026**: ~25-30% of new flagship smartphones with attested-capture support (Sony pro cameras, Leica M11-P, pilots on Pixel and iPhone Pro lines); ~60% of frontier AI image/audio generators producing C2PA-credentialed output.

  #### Production-Stack Maturity (May 2026)

- **Real-time avatar latency**: HeyGen Interactive Avatars / EMO-class systems achieving 150-300ms round-trip on optimised cloud infrastructure; sufficient for live video-call impersonation against unsuspecting targets.
- **Voice-clone fidelity**: Cartesia Sonic, ElevenLabs Turbo v3, F5-TTS achieving MOS ≥ 4.4 (versus reference human 4.8) with sub-200ms TTFB; commodity quality.
- **Detection accuracy in the wild**: 85-95% AUC on benchmark sets, 60-80% on novel generators — generalisation gap unresolved.
- **Cost-to-attack**: A credible voice-clone CEO-fraud campaign costs <$50 in compute + API fees (ElevenLabs Instant Voice Clone subscription). A credible deepfake video-call attack of the Arup variant costs $200-$2,000 in setup. The asymmetry favours attackers.

  #### Regulatory Enforcement Activity (2025-2026)

- **EU Commission DSA proceedings**: Active investigations against X, Meta, TikTok and Temu touching synthetic content moderation.
- **Ofcom Online Safety Act**: First non-compliance investigations Q2 2025; expected enforcement decisions late 2025-2026.
- **FCC and FBI**: Steve Kramer / Lingo Telecom prosecutions providing legal precedent for the Biden-robocall pattern.
- **Italian Postal Police**: Crosetto-case arrests 2025 demonstrate operational law-enforcement capability against voice-clone fraud rings.
- **South Korean prosecutions**: Telegram deepfake-room operators charged 2024-2025 under amended statutes.

### Regulatory Landscape (2023-2026)

Statutes specifically targeting synthetic-media abuse moved from concept to enforcement across 2023-2026 in every major jurisdiction.

#### European Union

- **EU AI Act (Regulation 2024/1689, in force 1 August 2024, Article 50 fully applicable 2 August 2026)**: Article 50 imposes transparency obligations: providers of generative AI systems must mark outputs in a machine-readable format as artificially generated (favouring C2PA), and deployers of deepfake systems generating image/audio/video constituting "deepfake" content must disclose to natural persons that content is artificially generated, except where use is permitted by law (criminal prosecution) or constitutes obvious satire/art with disclosure not undermining the work. AI Office (DG CNECT, established 2024) coordinates national enforcement.
- **EU Digital Services Act (Regulation 2022/2065)**: Very Large Online Platforms (Meta, X, TikTok, YouTube, Instagram) face risk-mitigation obligations covering systemic risks including manipulation of electoral processes. **Commission proceedings opened against X under Article 18 December 2023** citing deepfake-related disinformation gaps; against Meta April 2024 citing election-related synthetic content. DSA election-integrity guidelines March 2024 specifically require deepfake-labelling and rapid-response procedures during election windows.
- **EU Code of Practice on Disinformation (2022, voluntary)**: Signatories include Meta, Google, Microsoft, TikTok, Twitch; commitments to demonetise disinformation and label synthetic content. X withdrew from the Code May 2023, contributing to the Commission's subsequent DSA proceedings.

  #### United States

- **TAKE IT DOWN Act (signed 19 May 2025)**: Federal criminalisation of publishing NCII (authentic or AI-generated) with 48-hour platform takedown requirement. Sponsored by Sen. Cruz (R-TX) and Sen. Klobuchar (D-MN), strongly supported following the January 2024 Taylor Swift X incident. Enforced by Federal Trade Commission.
- **NO FAKES Act (Nurture Originals, Foster Art, and Keep Entertainment Safe)**: Introduced bipartisan 2024 (Coons, Blackburn, Klobuchar, Tillis), re-introduced 2025. Establishes federal right against AI-generated voice/likeness replicas without consent. Industry support from RIAA, Motion Picture Association, SAG-AFTRA (post-2023 strikes that included AI-replica concerns).
- **FCC Ruling on AI-Generated Robocalls (FCC-24-17A1, 8 February 2024)**: Declared AI-generated voices in robocalls subject to the Telephone Consumer Protection Act 1991; **$1M Lingo Telecom settlement and $6M penalty against Steve Kramer** for the Biden NH primary call.
- **State Laws 2023-2025**: California AB-602 (NCII deepfakes 2019), AB-730/SB-751 (political deepfakes); Texas SB-751 (political deepfakes); New York S5536 (NCII); Tennessee ELVIS Act (March 2024 voice/likeness protection); Minnesota election deepfakes statute (2023); Florida HB-919 (2024); Illinois deepfake civil action (2023).
- **Executive Order 14110 (Biden, October 2023, partially revoked by Trump January 2025)**: NIST guidance on content provenance + watermarking. The Trump administration's January 2025 Executive Order on AI rescinded portions but retained the National Security Memorandum on AI.
- **DEFIANCE Act (Disrupt Explicit Forged Images and Non-Consensual Edits)**: Passed Senate July 2024 establishing civil right of action against NCII deepfakes; House status pending throughout 2024-2025.

  #### United Kingdom

- **Online Safety Act 2023 (Royal Assent 26 October 2023, Ofcom enforcement from December 2024)**: Schedule 7 priority offences include "sharing intimate photographs without consent" extended in 2024 to cover synthetic intimate images. Section 188 Criminal Justice Bill 2024 added a "creation of intimate deepfake" offence with up to 2 years imprisonment. **Ofcom Illegal Content Codes** entered force 17 March 2025, with platforms required to implement systems addressing priority illegal content including NCII deepfakes; Ofcom investigations against non-compliant platforms began Q2 2025.
- **NCSC Deepfake Guidance (October 2024)**: National Cyber Security Centre published practical detection and incident-response guidance for organisations facing CEO-fraud-style attacks. Aligned with NPSA (National Protective Security Authority) personnel security guidance.
- **UK AI Security Institute** (renamed from AI Safety Institute, May 2024): Research arm housed at DSIT (Department for Science, Innovation and Technology); deepfake threat modelling for elections and critical national infrastructure.
- **Sentencing Council Deepfake Aggravator**: Guidance from 2024 treating deepfake-deployment as aggravating factor in offences involving threats and harassment.
- **Ofcom Online Safety Act enforcement 2025+**: Codes of Practice include child-sexual-abuse content (in force from January 2025) and adult illegal content (March 2025); deepfake CSAM material treated under existing CSA imagery statutes (Protection of Children Act 1978, Coroners and Justice Act 2009).

  #### Asia-Pacific

- **China — Provisions on Administration of Deep Synthesis Internet Information Services (effective 10 January 2023)**: First major national deepfake-specific regulation. Requires conspicuous synthetic-content labels, real-name registration for providers, content security review, and ban on dissemination of deepfakes that violate "core socialist values". Cyberspace Administration of China (CAC) enforcement.
- **South Korea — Sexual Crimes Act Amendment (September 2024)**: Criminalises possession and viewing of deepfake pornography (previously only production/distribution). Triggered by August 2024 Telegram deepfake-room scandal exposing 220 schools.
- **South Korea — Election Law Amendment (January 2024)**: Bans AI-generated election content 90 days before voting.
- **Singapore — Online Safety (Miscellaneous Amendments) Act, Protection from Online Falsehoods and Manipulation Act**: Deepfake-related codes from IMDA, primarily addressing election interference.
- **Australia — Criminal Code Amendment (Deepfake Sexual Material) Act 2024 (Royal Assent September 2024)**: Federal criminalisation of producing and sharing sexual deepfakes.
- **India — IT (Intermediary Guidelines) Amendment 2023, Draft DPDP Rules 2024-2025**: Notice-and-takedown for deepfakes; election commission advisories during 2024 elections required labelling.

### Defenders: The Counter-Industry

By 2025-2026 a coherent counter-industry had emerged across detection, provenance, watermarking, governance and victim-support layers.

#### Detection-as-a-Service
Reality Defender (NYC, banks/defence), Sensity AI (Amsterdam, monitoring at scale), Pindrop (Atlanta, voice for banks), Hive AI Moderation (SF, platform trust-and-safety), Microsoft Video Authenticator (gov + media), Truepic (camera attestation), Get Real Labs (Hany Farid spin-out, multimodal), Sentinel (Estonia, NATO/EU governments), Veridas (Spain, identity verification), DuckDuckGoose (NL, EU LEA focus), AI or Not / Optic (consumer/journalists). Aggregate market $180M 2025 → projected $1.5B 2030.

#### Provenance / Camera Attestation

- **C2PA (Adobe, Microsoft, BBC, NYT, Sony, Intel, Truepic)**: Industry-standard cryptographic provenance metadata. 2024-2025 saw camera-firmware integration (Sony, Leica) and AI-generator integration (DALL-E 3, Firefly).
- **CAI (Content Authenticity Initiative, since 2019, Adobe-led)**: Adoption advocacy and educational arm.
- **JPEG Trust (ISO/IEC working group, finalising 2024-2025)**: Standardising trust metadata in JPEG-1 / JPEG-XL.

  #### Government and Civil-Society Defenders

- **BBC R&D Synthetic Media Research Programme (London + MediaCityUK Salford)**: Editorial policy + technical research on archival authenticity, deepfake detection in news, synthetic-voice voice-actor protection. The BBC was a founding C2PA member.
- **UK National Cyber Security Centre (NCSC)**: 2024 deepfake guidance for organisations; alignment with NPSA personnel security.
- **UK AI Security Institute**: Election-window threat modelling, evaluations of frontier models for deepfake-generation capability.
- **Microsoft Threat Analysis Center (MTAC, Clint Watts)**: Public reporting on Russian (Storm-1516, Doppelganger), Chinese (Spamouflage Dragon) and Iranian deepfake influence operations.
- **US CISA**: Tactics-techniques-procedures bulletins on deepfake-enabled phishing.
- **EU Commission DG CNECT + ENISA**: AI Act enforcement; ENISA threat-landscape publications.
- **NATO StratCom Centre of Excellence (Riga)**: Adversarial-narrative monitoring including deepfake influence operations.

  #### Academic Forensics Labs
  UC Berkeley (Hany Farid, now also at Get Real Labs), University at Buffalo (Siwei Lyu, DeepFake-O-Meter, MediaForensics Lab), University of Naples Federico II (Cozzolino, Verdoliva), Idiap Research Institute (Sébastien Marcel anti-spoofing), Politecnico di Milano (Bestagini), Università di Firenze, Purdue (Edward Delp), MIT Media Lab (Pattie Maes), Imperial College London Trustworthy Media, UCL Information Security, Edinburgh Forensic Computing.

### UK Context: Academic Leadership, Industry, and Regulators

The United Kingdom has assembled one of Europe's strongest deepfake-research and policy ecosystems, anchored by world-class media-forensics research, distinctive public-service-broadcasting leadership through the BBC, dedicated regulators (Ofcom, NCSC, ICO), and a deep cluster of victim-protection NGOs.

#### Academic Institutions

- **Imperial College London — Trustworthy Media Initiative + Department of Computing**: Multi-modal deepfake detection, audio-visual coherence analysis, fairness across demographics. PI: **Stefanos Zafeiriou** (face analysis, StyleGAN face inversion 3,000+ citations). UKRI-funded **£8M "Trustworthy Generative AI in Healthcare and Society"** programme (2023-2027) covers deepfake detection workstream. Industry partners include BBC R&D, ITN, Reuters.
- **UCL Information Security Research Group**: Cryptographic provenance, watermark security, adversarial robustness of deepfake detectors. **George Danezis** (anonymity systems, now Mysten Labs / advisory), Steven Murdoch (security engineering), Yvo Desmedt. Joint work with Alan Turing Institute on synthetic-media governance.
- **University of Edinburgh — Forensic Computing + School of Informatics**: Audio-deepfake detection, speaker verification anti-spoofing. **Sébastien Le Maguer**, collaboration with EURECOM and Idiap on ASVspoof Challenge series 2015-2024. **Vassilios Pipidis** (forensic computing).
- **University of Manchester, Leeds, Sheffield AI-Safety Research**: Manchester School of AI working with the BBC R&D MediaCityUK Salford on archival-authenticity and synthetic-voice detection. Leeds + Northumbria forensic image enhancement for regional police forces. Sheffield NLP group on text-deepfake (LLM impersonation) detection.
- **University of Surrey Centre for Vision, Speech and Signal Processing (CVSSP)**: Audio-visual synthesis-and-detection research, partnership with BBC R&D.
- **University of Oxford — Oxford Internet Institute (Philip Howard, Bence Kollanyi, COMPROP)**: Computational propaganda research including deepfake-amplification analysis. Now spun into Cambridge Internet Policy Research Network.
- **University of Cambridge — Centre for the Future of Democracy + Leverhulme Centre for the Future of Intelligence**: Policy-focused research on AI and electoral integrity.
- **King's College London**: NCII research and victim-support evidence base, working with the Revenge Porn Helpline.
- **Alan Turing Institute**: Defence & Security Programme covers deepfake threat assessment; AI Safety Institute partnerships.

  #### UK Industry and Public Sector

- **BBC R&D (Broadcast Centre, London + MediaCityUK Salford)**: Founding C2PA member, BBC News editorial standards on synthetic media (2020-, updated 2024), Trusted News Initiative coordination with major broadcasters, archival voice-restoration projects (BBC archive). Synthetic-media policy unit publishes practical guidelines.
- **Ofcom (London)**: Online Safety Act enforcement from December 2024, Illegal Content Codes effective March 2025; investigative powers against platforms hosting unmitigated deepfake harm. Significant uplift to ~1,200 staff with synthetic-media specialism developing.
- **ICO (Wilmslow, Cheshire)**: Data-protection enforcement covering training-data scraping and biometric reproduction. **2024 enforcement against Clearview AI** continued. Joint guidance with Ofcom on generative-AI personal-data risks (2024).
- **NCSC + NPSA**: Deepfake operational guidance 2024 for organisations facing CEO-fraud, threat actor tracking.
- **AI Security Institute (DSIT)**: Pre-deployment frontier-model evaluations including deepfake-generation capability uplift.
- **Synthesia (London)**: $2.1B unicorn 2024, leadership role in industry self-regulation — bans political/news use of platform avatars, watermarks all outputs, partners with Reality Defender for monitoring abuse.
- **ElevenLabs (London, $3.3B valuation 2025)**: Voice-cloning incumbent, post-Biden-robocall incident introduced: voice cloning blocklist for political figures, AI Speech Classifier (free public deepfake detection for ElevenLabs-generated audio), partner integration with Reality Defender. Co-developed AI Safety Coalition.
- **Reality Defender UK Operations**: London office serving HSBC and UK financial-services customers.
- **DeepMind (London) — SynthID team**: Imperceptible watermarking research extended from images to text and audio 2024.
- **ITV + Sky + Channel 4**: Detection adoption (Reality Defender at ITV) and adherence to BBC-led Trusted News Initiative.
- **Get Safe Online + UK Finance + Cifas**: Consumer and enterprise fraud-awareness campaigns increasingly featuring deepfake-specific scenarios.
- **Revenge Porn Helpline (SWGFL Charity)**: 6,000+ deepfake-NCII cases handled 2023-2025; key Ofcom and DSIT stakeholder on enforcement design.

  #### Northern English Hubs

- **MediaCityUK Salford**: BBC R&D + ITV Studios + Dock10 collaborating on synthetic-media research and post-production C2PA pipelines. Hosts BBC Synthetic Media Research Group.
- **Manchester**: GCHQ-North + GMP Cyber Crime + Manchester Metropolitan University Centre for Digital Innovation working on regional fraud response including deepfake-enabled romance fraud.
- **Leeds**: Northern Police Forces' Regional Organised Crime Unit (NERSOU) co-located deepfake-fraud investigations; University of Leeds + Leeds Digital Festival deepfake-awareness programmes.
- **Sheffield**: University of Sheffield NLP Group on synthetic-text impersonation detection; Advanced Manufacturing Research Centre on industrial-IP voice-impersonation threat models.
- **Newcastle**: Northumbria Police forensic-image enhancement (court-admissibility under Criminal Procedure Rules); Newcastle University on industrial-control-system spoofing including operator-voice attacks.

### Future Directions (2026-2030)

Deepfakes and the counter-industry are entering an arms-race equilibrium with several distinct strategic trajectories.

#### Generation-Side Trajectories

- **Real-Time Multi-Modal Avatars**: HeyGen Interactive Avatars and EMO-style audio-conditional video generation reaching <100ms latency by 2026-2027, enabling fully autonomous deepfake video-call agents (the Arup attack at scale).
- **Open-Source Catching Up**: Each commercial release (HeyGen, Synthesia, ElevenLabs Professional Voice Clone) is followed within 6-18 months by open-source equivalents (OpenVoice, F5-TTS, LatentSync). The capability gap is narrowing, not widening.
- **Custom Identity Fine-Tuning at the Edge**: Diffusion LoRA training of celebrity/politician identities continues to industrialise — 1-2 hour fine-tunes on consumer GPUs produce identity-preserving generators.
- **Multi-Modal Coherence**: Joint audio-video generation (EMO, OmniHuman) eliminates the most reliable detection signal (audio-visual desynchronisation).

  #### Detection-Side Trajectories

- **Generalisation Gap Persists**: DFDC and follow-on benchmarks have repeatedly demonstrated detection accuracy collapses on out-of-distribution deepfakes. Detection-vs-generation favours generation in the open-set adversarial setting.
- **Shift to Provenance**: Recognition by the industry that purely detection-based defences are losing — leading to C2PA / camera-attestation as the strategic centre of gravity. Approximately 60% of new smartphone models (2026 projection) ship with attested-capture capability.
- **Active Watermarking Mandates**: EU AI Act Article 50 (Aug 2026) effectively mandates watermarking for compliant providers. SynthID-style techniques become contractual requirements.
- **Biometric Liveness Hardening**: 3D-liveness, challenge-response (head movements, randomised on-screen prompts) and infrared/depth sensors deployed against KYC injection attacks.

  #### Regulatory Trajectories

- **EU AI Act Article 50 Enforcement (from August 2026)**: First Commission decisions on synthetic-media non-labelling expected 2026-2027.
- **UK Codes of Practice Iterations**: Ofcom is expected to add deepfake-specific provisions to OSA Codes through 2025-2027 amendments.
- **US Federal Patchwork Continues**: TAKE IT DOWN Act + NO FAKES Act (likely passes 2025-2026) + state laws form patchwork; expect Supreme Court First Amendment challenges to political-deepfake prohibitions.
- **Liability Regimes**: AI Liability Directive (EU, expected 2025-2026 vote), insurance products specifically covering deepfake-CEO-fraud (Lloyd's underwriters introduced 2024-2025).

  #### Market Trajectories

- **Deepfake Fraud Loss (Deloitte 2024 forecast)**: US $40B by 2027 (32% CAGR from $12.3B 2023).
- **Detection Market**: $180M 2025 → $1.5B 2030 (Reality Defender's growth trajectory representative).
- **Provenance / C2PA**: Camera-attestation in 60%+ of new smartphones by 2028; news-organisation adoption universal among major outlets by 2027.
- **Voice-Cloning Defence**: Pindrop and similar tools become standard at banking call-centres by 2027.

  #### Socio-Technical Trajectories

- **The Liar's Dividend Crystallises**: Increasing prevalence of "it's a deepfake" defences against authentic incriminating recordings. Courts develop deepfake-authentication procedures (US Federal Rules of Evidence 901(b)(9) amendments under discussion 2024-2025).
- **Media Literacy at Scale**: BBC Reality Check, AP Fact Check, FullFact UK, EU Vera, NewsGuard ramp deepfake-specific journalism training and public-education programmes.
- **Victim-Support Infrastructure**: Revenge Porn Helpline, Cyber Civil Rights Initiative (US), Reset.tech scale operations as NCII volumes rise.
- **Insurance Market Maturation**: Lloyd's of London syndicates underwriting deepfake-fraud cover from 2024; expect standalone "social engineering with synthetic media" cyber-policy endorsements to proliferate by 2027.
- **Identity-Verification Industrialisation**: Banks shift from password + SMS to multi-factor with hardware-key (FIDO2), biometric + liveness + behavioural signals, with voice-call authorisation becoming untrustable for high-value transactions.

  #### Aggregate Adoption Trajectory Estimates

  **2026 Baseline**:

- Documented deepfake-fraud loss: ≈ £2.6B / $3.2B global; US $12.3-15B
- Detection market: $180M
- Provenance camera adoption: 25-30% flagship smartphones
- Enforced regimes: EU AI Act Art 50, TAKE IT DOWN Act, UK OSA, China Deep Synthesis Provisions, South Korea NCII

  **2028 Projections**:

- US deepfake fraud loss: $25-30B (Deloitte trajectory)
- Detection market: $700M
- Provenance adoption: 45-55% flagship smartphones
- Regulatory: AI Liability Directive in force EU, NO FAKES Act federal US, expanded UK OSA codes

  **2030 Projections**:

- US deepfake fraud loss: $40B+
- Detection market: $1.5B
- Provenance adoption: 70%+ flagship smartphones, near-universal news-organisation adoption
- Insurance market: dedicated deepfake-fraud cover at all major Lloyd's syndicates

### Research and Literature

**Foundational Generation Methods**:
1. Goodfellow, I. et al. (2014). Generative Adversarial Nets. *NeurIPS 2014*. arXiv:1406.2661 [Theoretical foundation enabling later face-swap GANs]
2. Suwajanakorn, S., Seitz, S.M., & Kemelmacher-Shlizerman, I. (2017). Synthesizing Obama: learning lip sync from audio. *ACM Transactions on Graphics 36(4) SIGGRAPH 2017*. [Pre-deepfake VFX precursor]
3. Karras, T., Laine, S., & Aila, T. (2019). A Style-Based Generator Architecture for Generative Adversarial Networks (StyleGAN). *CVPR 2019*. arXiv:1812.04948 [StyleGAN face synthesis foundation]
4. Prajwal, K.R., Mukhopadhyay, R., Namboodiri, V.P., & Jawahar, C.V. (2020). A Lip Sync Expert Is All You Need for Speech to Lip Generation in the Wild (Wav2Lip). *ACM Multimedia 2020*. arXiv:2008.10010 [Workhorse lip-sync model]
5. Wang, Q. et al. (2024). InstantID: Zero-shot Identity-Preserving Generation in Seconds. *arXiv:2401.07519* [Diffusion-era identity conditioning]
6. Tian, L. et al. (2024). EMO: Emote Portrait Alive — Generating Expressive Portrait Videos with Audio2Video Diffusion Model under Weak Conditions. *Alibaba HumanAIGC*. arXiv:2402.17485 [Audio-conditional talking-head]

**Detection Methods and Benchmarks**:
7. Yang, X., Li, Y., & Lyu, S. (2019). Exposing Deep Fakes Using Inconsistent Head Poses. *ICASSP 2019*. arXiv:1811.00661 [Pose-based forensics]
8. Li, Y., Chang, M.C., & Lyu, S. (2018). In Ictu Oculi: Exposing AI Created Fake Videos by Detecting Eye Blinking. *WIFS 2018*. arXiv:1806.02877 [Eye-blink forensics]
9. Rössler, A., Cozzolino, D., Verdoliva, L., Riess, C., Thies, J., & Nießner, M. (2019). FaceForensics++: Learning to Detect Manipulated Facial Images. *ICCV 2019*. arXiv:1901.08971 [Benchmark dataset]
10. Dolhansky, B., Bitton, J., Pflaum, B., Lu, J., Howes, R., Wang, M., & Ferrer, C.C. (2020). The DeepFake Detection Challenge (DFDC) Dataset. *arXiv:2006.07397* [Facebook/Microsoft/AWS challenge]
11. Li, Y., Yang, X., Sun, P., Qi, H., & Lyu, S. (2020). Celeb-DF: A Large-scale Challenging Dataset for DeepFake Forensics. *CVPR 2020*. arXiv:1909.12962 [High-quality deepfake benchmark]
12. Frank, J., Eisenhofer, T., Schönherr, L., Fischer, A., Kolossa, D., & Holz, T. (2020). Leveraging Frequency Analysis for Deep Fake Image Recognition. *ICML 2020*. arXiv:2003.08685 [Frequency-domain forensics]
13. Korshunov, P., & Marcel, S. (2018). DeepFakes: a New Threat to Face Recognition? Assessment and Detection. *Idiap Research Report*. arXiv:1812.08685 [Early threat assessment]
14. Verdoliva, L. (2020). Media Forensics and DeepFakes: an overview. *IEEE Journal of Selected Topics in Signal Processing 14(5)*. DOI: 10.1109/JSTSP.2020.3002101 [Comprehensive review]

**Provenance, Watermarking, and Defence**:
15. C2PA (2024). C2PA Specification 2.0. *Coalition for Content Provenance and Authenticity*. https://c2pa.org/specifications/specifications/2.0/ [Industry standard]
16. Fernandez, P., Couairon, G., Jégou, H., Douze, M., & Furon, T. (2023). The Stable Signature: Rooting Watermarks in Latent Diffusion Models. *ICCV 2023*. arXiv:2303.15435 [Meta watermarking]
17. Wen, Y., Kirchenbauer, J., Geiping, J., & Goldstein, T. (2023). Tree-Ring Watermarks: Fingerprints for Diffusion Images that are Invisible and Robust. *NeurIPS 2023*. arXiv:2305.20030 [Diffusion watermarking]
18. Dathathri, S. et al. (2024). Scalable watermarking for identifying large language model outputs (SynthID-Text). *Nature 634, 818-823*. DOI: 10.1038/s41586-024-08025-4 [Google DeepMind SynthID text]

**Threat-Landscape Reports and Industry Surveys**:
19. Sumsub (2024). *Identity Fraud Report 2024*. Sumsub Insights. [Identity-fraud trend data]
20. Sumsub (2025). *Identity Fraud Report 2025*. [Updated figures including £2.6B global loss estimate]
21. Deloitte Center for Financial Services (2024). *Deepfake Banking Fraud Forecast 2024-2027*. [$40B US 2027 forecast]
22. FBI Internet Crime Complaint Center (2025). *2024 Internet Crime Report*. FBI IC3. [Pig-butchering $5.6B, total $16.6B]
23. Entrust / Onfido (2024). *2024 Identity Fraud Report*. [Document-fraud trend including 31× deepfake increase 2022-2023]
24. Europol (2022, updated 2024). *Facing reality? Law enforcement and the challenge of deepfakes*. Europol Innovation Lab. [EU LEA threat assessment]

**Regulatory and Policy**:
25. European Parliament + Council (2024). Regulation (EU) 2024/1689 (AI Act). *Official Journal of the European Union*, Article 50. [EU AI Act deepfake transparency]
26. United States 119th Congress (2025). *TAKE IT DOWN Act, S.146*. [NCII federal criminalisation, signed 19 May 2025]
27. FCC (2024). *Declaratory Ruling on Calls Made with AI-Generated Voices, FCC-24-17A1*. [AI robocalls TCPA ruling]
28. UK Parliament (2023). *Online Safety Act 2023*. [Schedule 7 priority offences including synthetic intimate imagery]

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review during Phase 6 enrichment sprint
- **Verification**: Academic sources verified against arXiv, IEEE Xplore, ICCV/CVPR/NeurIPS/ICASSP proceedings; industry incident detail verified against Hong Kong Police press conferences (Arup case, 4 February 2024), Arup public statement (17 May 2024), FCC rulings (FCC-24-17A1), Sumsub Identity Fraud Reports 2024-2025, FBI IC3 2024 Internet Crime Report, EU Regulation 2024/1689 Official Journal text, US Public Law TAKE IT DOWN Act enrolled bill, UK Online Safety Act 2023 statute text.
- **Regional Context**: UK academic institutions (Imperial College London Trustworthy Media, UCL Information Security, Edinburgh Forensic Computing/CSTR, Manchester School of AI, Leeds, Sheffield, Surrey CVSSP, Oxford OII, Cambridge Centre for the Future of Democracy, King's College, Alan Turing Institute); UK industry (BBC R&D, Synthesia, ElevenLabs, Reality Defender UK, DeepMind SynthID); UK regulators (Ofcom, NCSC, NPSA, AI Security Institute, ICO); Northern English hubs (MediaCityUK Salford, Manchester GMP, Leeds NERSOU, Sheffield, Newcastle).
- **Domain Correction**: Original frontmatter classified deepfakes under `infrastructure` — reclassified to `society` reflecting the canonical placement of deepfakes as a socio-technical harm category within online-harms / information-integrity / media-policy domains (technical generators GAN/Diffusion live under `artificial-intelligence`; the *misuse* category is a society-domain concept). IRI/URI rewritten to society namespace.
- **Production-Ready**: Complete OWL formal semantics, comprehensive content coverage (origin and 2017-2018 inflection; full 2024-2026 generation stack; detection technology; documented fraud and election incidents; full regulatory landscape across EU/US/UK/China/South Korea; defender counter-industry; UK context with academic, industrial and regulatory cluster detail; future directions), 28 academic, industry and regulatory citations spanning 2014-2025.
- **Authority Score**: 0.87 (foundational online-harms / synthetic-media-fraud reference, documented multi-billion-pound annual economic harm 2024-2026, dedicated statute across all major jurisdictions, mature counter-industry with defined commercial players, ongoing research and policy relevance).

### Provenance

- **domain-correction:** infrastructure → society (original misclassification; deepfakes-as-harm-category canonically belongs to society/online-harms/information-integrity)

