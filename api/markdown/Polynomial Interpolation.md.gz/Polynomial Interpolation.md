Polynomial interpolation is the construction of the unique polynomial of degree at most n-1 that passes through n given data points, most commonly computed via Lagrange or Newton forms. It underlies Shamir secret sharing, where a secret is encoded as the constant term of a random polynomial and reconstructed only when enough evaluated points, or shares, are combined via interpolation. The same technique underlies Reed-Solomon error-correcting codes, which treat message symbols as polynomial coefficients and use redundant evaluated points to recover data despite loss or corruption.

### Provenance

