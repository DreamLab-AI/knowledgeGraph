A supply chain execution system is software that carries out the day-to-day operations of a supply chain, as distinct from software that plans them.[^1]

Zaidi, Amanton and Sanlaville define the execution class of logistics information systems as warehouse management systems, manufacturing execution systems and transportation management systems, and list supply chain planning separately as product lifecycle management, scheduling and production planning.[^1]

## Examples from the sources

In a warehouse, the Georgia Tech course text says that on receipt of a customer order the warehouse must verify that inventory is available, produce pick lists, produce shipping documentation and schedule the order-picking and shipping, and that these activities are typically accomplished by a warehouse management system.[^2] See [[Warehouse Management System]].

On the factory floor, ISA-95 places manufacturing execution systems at Level 3, where they manage manufacturing operations.[^3] See [[Manufacturing Execution System]].

For freight, the US General Services Administration describes its TMSS 2.0 as providing services and management tools for shipment creation, planning, tendering, execution and reporting.[^4] See [[Transportation Management System]].

IBM describes an order management system as a digital way to manage the lifecycle of an order, tracking order entry, inventory management, fulfilment and after-sales service.[^5] See [[Order Management System]] and [[Global Trade Management System]].

## Scope and distinctions

Planning systems decide what should happen and execution systems carry it out, but the sources show the border is not fixed: the TMSS description includes planning and tendering inside a transportation system, so a single product can span both.[^4] See [[Supply Chain Planning System]] and [[Supply Chain Information Systems]].

## What the sources do not establish

That preprint's execution class lists three systems, whereas this domain's catalogue also files order management and global trade management software here, and no opened source says so. The sources are a preprint, a course text, a standards-body overview, a government product page and a vendor explainer.[^1][^2][^3][^4][^5]

[^1]: Fares Zaidi, Laurent Amanton and Eric Sanlaville, “Towards a Novel Cooperative Logistics Information System Framework”, arXiv:1905.00687. https://arxiv.org/pdf/1905.00687
[^2]: John J. Bartholdi III and Steven T. Hackman, “Warehouse & Distribution Science”, Release 0.1.2 (Georgia Tech course text, revised 24 May 2002). https://www2.isye.gatech.edu/~spyros/courses/IE6202/Fall-2002/Bartholdi-Hackman.pdf
[^3]: International Society of Automation, “ISA-95 Standard: Enterprise-Control System Integration”. https://www.isa.org/standards-and-publications/isa-standards/isa-95-standard
[^4]: US General Services Administration, “TMSS 2.0”. https://www.gsa.gov/buy-through-us/products-and-services/transportation-and-logistics-services/transportation-programs/tmss-20
[^5]: IBM, “What is Order Management?”. https://www.ibm.com/think/topics/order-management

