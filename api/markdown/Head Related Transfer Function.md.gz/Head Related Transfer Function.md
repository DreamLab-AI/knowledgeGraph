A head-related transfer function (HRTF) describes how sound from a point in space is filtered by the listener's head, torso and outer ears before reaching each eardrum. It captures the frequency-dependent level, time and spectral cues that the auditory system uses to localise sound. Convolving a mono source with the appropriate left and right HRTFs synthesises a convincing three-dimensional position over headphones, making the HRTF the mathematical core of binaural and spatial audio rendering.

### Overview

- The head-related transfer function is the frequency-domain expression of how an individual's anatomy colours sound arriving from a given direction; its time-domain counterpart is the head-related impulse response. Differences between the left and right HRTFs supply interaural time and level cues, while peaks and notches imposed by the pinna give elevation and front-back cues. Rendering spatial audio over headphones convolves each source with the HRTF pair for its intended direction, optionally updated by head tracking. HRTFs may be measured individually in an anechoic chamber, drawn from generic datasets, or personalised from anthropometry, with personalisation improving localisation accuracy and externalisation.

### Mechanisms

- Encodes interaural time and level differences for azimuth perception.
- Pinna-induced spectral notches provide elevation and front-back cues.
- Applied by convolving a source with direction-specific left and right filters.
- Measured individually, generic, or personalised from anthropometry.
- Combined with head tracking for stable, dynamic spatialisation.

### Applications

- Binaural rendering for virtual and augmented reality.
- Spatial audio in games and immersive media.
- Headphone-based teleconferencing with positioned talkers.
- Auditory display and accessibility tools.

### Provenance

