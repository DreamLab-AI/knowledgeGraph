ComfyUI Client refers collectively to the suite of client-side interfaces, API layers, and software components that communicate with a running ComfyUI server—the open-source, node-based diffusion model inference engine created by comfyanonymous (GitHub user) and released in January 2023—enabling ...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:NodeGraphEditor))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:WebSocketClient))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:PromptQueueManager))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:ModelLibraryBrowser))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:PreviewNode))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:ComfyUIManager))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:WorkflowBrowser))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:CustomNodeSystem))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:hasPart ai:DesktopApplication))

    ## Dependency Relationships
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:requires ai:WebSocketProtocol))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:requires ai:HTTPAPI))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:requires ai:GPUComputing))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:requires ai:PythonRuntime))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:requires ai:DirectedAcyclicGraph))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:requires ai:DiffusionModel))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:dependsOn ai:PyTorch))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:dependsOn ai:CUDA))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:dependsOn ai:JSON))

    ## Capability Relationships
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:ImageGeneration))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:WorkflowAutomation))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:BatchProcessing))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:APIIntegration))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:CustomNodeDevelopment))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:LatentSpaceExploration))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:ModelChaining))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:LoRAApplication))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:enables ai:VideoGeneration))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:supports ai:TextToImage))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:supports ai:ImageToImage))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:supports ai:Inpainting))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:supports ai:SuperResolution))

    ## Implementation Relationships
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:implements ai:DirectedAcyclicGraphExecution))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:implements ai:QueueManagementPattern))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:implements ai:PluginArchitecture))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:implements ai:JSONWorkflowSerialisation))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:implements ai:ObserverPattern))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:uses ai:VueJS))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:uses ai:TypeScript))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:uses ai:Electron))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:uses ai:LiteGraphJS))

    ## Reduction Relationships
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:reduces ai:ModelSetupComplexity))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:reduces ai:WorkflowIterationTime))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:reduces ai:InfrastructureManagementOverhead))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:reduces ai:GPUIdleTime))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:relatedTo ai:StableDiffusion))
    SubClassOf(ai:ComfyUIClient
      ObjectSomeValuesFrom(ai:relatedTo ai:GenerativeAI))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ai:hasIdentifier ai:ComfyUIClient "AI-1053"^^xsd:string)
    DataPropertyAssertion(ai:authorityScore ai:ComfyUIClient "0.87"^^xsd:decimal)
    DataPropertyAssertion(ai:foundationalYear ai:ComfyUIClient "2023"^^xsd:integer)
    DataPropertyAssertion(ai:githubStars ai:ComfyUIClient "113000"^^xsd:integer)
    DataPropertyAssertion(ai:defaultPort ai:ComfyUIClient "8188"^^xsd:integer)
    DataPropertyAssertion(ai:registeredCustomNodePacks ai:ComfyUIClient "600"^^xsd:integer)
    DataPropertyAssertion(ai:desktopBundleSizeMB ai:ComfyUIClient "200"^^xsd:integer)

    ## Property Characteristics
    AsymmetricObjectProperty(ai:requires)
    AsymmetricObjectProperty(ai:enables)
    AsymmetricObjectProperty(ai:implements)
    AsymmetricObjectProperty(ai:contrastsWith)
    TransitiveObjectProperty(ai:dependsOn)
    FunctionalDataProperty(ai:foundationalYear)
    FunctionalDataProperty(ai:defaultPort)

    ## Annotations
    AnnotationAssertion(rdfs:label ai:ComfyUIClient "ComfyUI Client"@en)
    AnnotationAssertion(rdfs:comment ai:ComfyUIClient "Suite of client-side interfaces and API layers for the ComfyUI node-based diffusion model inference engine, comprising the Vue 3 browser frontend, Electron Desktop app (October 2024), mobile clients, TypeScript/Python API libraries, and cloud-hosted deployments on GPU platforms (RunPod, Replicate, fal.ai, Modal), all communicating via a WebSocket event stream and REST /prompt endpoint that accept JSON-serialised directed acyclic graph workflows for GPU execution through a priority queue on a Python aiohttp server defaulting to port 8188; 113K+ GitHub stars as of May 2026."@en)
    AnnotationAssertion(dcterms:identifier ai:ComfyUIClient "AI-1053"^^xsd:string)
    AnnotationAssertion(dcterms:subject ai:ComfyUIClient "Generative AI, Diffusion Models, Node-Based Interface, WebSocket API, Workflow Automation, Image Generation"@en)

## About ComfyUI Client

- **ComfyUI** is the most widely-adopted open-source node-based user interface and API server for running [[Stable Diffusion]], [[Flux.1]], [[SDXL]], and other diffusion models locally, in the cloud, or on GPU-as-a-service infrastructure. Created in early 2023 by the pseudonymous developer comfyanonymous, it has grown into one of the highest-starred AI repositories on GitHub (113,000+ stars, 13,255+ forks as of May 2026), driven by its unique combination of visual power-user control and headless API capability that no other Stable Diffusion interface replicates at the same level.
- The **client concept** in ComfyUI is multifaceted because the same server process serves radically different consumer types simultaneously: an artist interactively composing a [[Node Based Interface]] workflow in the browser; a developer submitting JSON-serialised graph jobs via a Python library; a studio routing batch jobs through a cloud-hosted serverless API; and a mobile user monitoring a remotely-running server from an iOS native app. Each consumer is a distinct "client" in the network sense, but all share the same underlying [[WebSocket]] event protocol and HTTP API surface. Understanding ComfyUI Client as a concept therefore requires mapping both the **interface taxonomy** (browser frontend, Desktop app, mobile, programmatic API) and the **protocol substrate** (the WebSocket + REST API) that gives all these interfaces coherent shared semantics.
- ComfyUI's architecture separates concerns cleanly: the Python backend handles model loading, VRAM management, topological DAG execution, output caching, and file serving; the various client frontends handle only user interaction, workflow editing, progress display, and output retrieval. This clean separation is what makes ComfyUI uniquely composable—users can run the server on a powerful remote GPU machine (bare metal, [[RunPod]] pod, [[Replicate]] deployment, cloud VM) and connect any compliant client to it, including clients running on devices with no GPU at all.

### Architecture and Core Protocol

#### Server/Client Architecture

Every ComfyUI instance presents two integration surfaces at startup (default `0.0.0.0:8188`):

**REST Endpoints**:

- `POST /prompt` — submit a workflow DAG for execution; returns `{ "prompt_id": "<uuid>", "number": <queue_position>, "node_errors": {} }` on success, or validation errors keyed by node ID on failure
- `GET /queue` — returns `{ "queue_running": [...], "queue_pending": [...] }` giving full queue state
- `GET /history` and `GET /history/{prompt_id}` — returns completed job records including output file references
- `GET /view` — serves output images given `?filename=&subfolder=&type=` parameters
- `GET /object_info` — returns JSON schema for all registered node types including their input/output port types and default values; the primary mechanism clients use to discover installed custom nodes
- `POST /interrupt` — cancels the currently executing prompt

  **WebSocket Endpoint**:

- `GET /ws?clientId={uuid}` — upgrades to WebSocket; the server pushes events to all connected clients or to the client whose `clientId` matches the submitted prompt's `client_id` field

  #### WebSocket Event Protocol

  The WebSocket stream is the core real-time signalling channel. Event types (JSON objects with `type` and `data` fields):

- `status` — queue depth and running count updates; broadcast to all connected clients whenever queue state changes
- `execution_start` — fired when a prompt begins execution; carries `prompt_id`
- `executing` — fired once per node as it begins executing; carries `node` (node ID string) and `prompt_id`; a `null` node value signals completion of the entire prompt
- `progress` — carries `value` and `max` for sampling step progress within a KSampler node
- `executed` — fired when a node completes; carries `node`, `prompt_id`, and `output` containing any node-declared outputs (e.g., image filename references for SaveImage nodes)
- `execution_cached` — identifies nodes skipped due to output caching (inputs identical to a prior run); clients can grey these out in the UI
- `execution_error` — carries exception details when a node raises an unhandled exception; terminates the prompt
- `b_preview` — carries base64-encoded JPEG preview frames from KSampler's intermediate latent decode (when a preview method is active); enables live progress previews in the frontend

  Clients connect by opening `ws://{serverAddress}/ws?clientId={uuid}`. When submitting a prompt via `POST /prompt`, clients include their `client_id` in the request body so the server can route `executing` and `executed` events preferentially to that client. The simple TypeScript usage pattern from the `comfy-ui-client` library (used in the stub):

```typescript
const client = new ComfyUIClient(serverAddress, clientId);
await client.connect();
const images = await client.getImages(prompt);
await client.saveImages(images, outputDir);
await client.disconnect();
```

#### Prompt / Workflow JSON Format

The **API-format workflow** (distinct from the richer `workflow.json` used by the frontend for canvas layout) is a flat JSON object where each key is a string node ID and each value declares:

- `class_type` (string): the Python class name of the node (e.g. `"KSampler"`, `"CheckpointLoaderSimple"`, `"CLIPTextEncode"`)
- `inputs` (object): a dictionary of input values where scalars are literal and node connections are `[node_id_string, output_slot_integer]` arrays

  A minimal Stable Diffusion 1.5 text-to-image workflow requires six nodes: `CheckpointLoaderSimple` (loads model, CLIP, VAE), `CLIPTextEncode` × 2 (positive and negative conditioning), `EmptyLatentImage` (creates initial noise tensor), `KSampler` (runs denoising loop), `VAEDecode` (decodes latent to pixel space), and `SaveImage` (writes output). This six-node graph encodes roughly 30 lines of JSON and replaces hundreds of lines of raw diffusers pipeline code.

  #### Execution Engine Internals

  The `PromptExecutor` (`execution.py`) performs:
  1. **Validation**: checks that all `class_type` values correspond to registered nodes and that port types are compatible
  2. **Topological sort**: derives linear execution order from the DAG structure
  3. **Output caching**: computes a hash of each node's inputs (including recursively the outputs of all ancestor nodes); if a matching hash is found in the cache, the node is skipped and its cached outputs re-used. This is ComfyUI's primary performance optimisation—re-running a workflow after changing only the seed skips all upstream nodes (checkpoint loading, CLIP encoding, latent image creation) and re-executes only from KSampler onwards
  4. **Sequential GPU execution**: nodes execute in topological order on the GPU thread; VRAM is managed by PyTorch's allocator augmented by ComfyUI's **Dynamic VRAM** system

  #### Dynamic VRAM System

  ComfyUI implements a custom PyTorch VRAM allocator (Dynamic VRAM, enabled by default from 2025) that handles on-demand offloading of model weights when GPU memory comes under pressure. Key behaviours: automatic offload of model components to CPU RAM when VRAM headroom is insufficient; faster initial model loading and LoRA application than static pre-allocation; ability to run models larger than VRAM capacity without OS-level paging; asynchronous offload with pinned memory to minimise CPU-GPU transfer latency. Command-line flags (`--lowvram`, `--medvram`, `--highvram`, `--cpu-vae`, `--cpu-text-encoder`) override Dynamic VRAM behaviour for constrained environments. Tiled VAE processing (`--tile-size`) handles high-resolution decode steps that would otherwise exhaust VRAM even when the UNet fits comfortably.

### Components and User-Facing Architecture

#### Browser Frontend (ComfyUI_frontend)

The primary user interface, served at `http://localhost:8188` by the Python backend, is a full single-page application. The original vanilla JavaScript implementation (using the LiteGraph.js Canvas2D engine) was deprecated in August 2024 and replaced by the Vue 3 + TypeScript + Vite frontend (Comfy-Org/ComfyUI_frontend). Key UI regions:

**Node Canvas**: The central workspace where nodes appear as rectangular cards with typed input ports (left) and output ports (right). Connections are drawn as Bezier curves colour-coded by type. Users drag from an output port to an input port to create connections; incompatible types are rejected visually. Node groups, sticky notes, and reroute nodes organise complex workflows.

**Node Search / Add Node**: Right-click context menu or spacebar opens a fuzzy-search panel listing all registered node types including custom nodes. Nodes are categorised (loaders, conditioning, sampling, latent, image, output) and filterable by CNR pack.

**Queue Panel**: Displays the current queue (running and pending items), allows cancellation, and links to the history of completed jobs with thumbnail previews.

**Model Library**: A browsable panel listing all checkpoint files, LoRA files, VAE files, embeddings, and other model assets found in the ComfyUI model directory tree. Supports drag-and-drop onto the canvas to instantiate the appropriate loader node.

**Workflow Browser**: A local and cloud-synced library of saved workflow JSON files, accessible as a panel within the app, replacing the previous approach of manual file export/import.

**Settings Panel**: Extensive configuration covering preview method (TAESD, TAEHD, latent noise, disabled), queue auto-run behaviour, badge display, node slot colour themes, keybindings, and extension management.

**Nodes 2.0 / Vue Node Components**: The roadmap transition from Canvas2D-rendered nodes to Vue 3 component-based nodes, allowing custom node authors to ship rich interactive widget UIs (sliders, colour pickers, real-time parameter widgets, embedded video players) impossible in the Canvas2D paradigm.

#### ComfyUI Desktop Application

The Electron-wrapped Desktop app (Comfy-Org/desktop, stable October 2024) bundles:

- A full Python environment (no separate Python install required)
- The ComfyUI server binary
- The Vue 3 frontend as the Electron renderer process
- An Electron main process providing native OS integration

  Added capabilities beyond the browser frontend:

- **Multi-tab workflows**: multiple workflow files open simultaneously in browser-like tabs
- **Custom key bindings**: system-level keyboard shortcuts for common operations
- **Automatic model import**: scans existing local ComfyUI installations and imports the model library
- **Deep links**: `comfyui://` protocol links open workflows directly in the Desktop app
- **Auto-updates**: in-app update mechanism with code-signed release verification
- **File association**: `.json` workflow files associated with the Desktop app in OS file manager

  Desktop 2.0 Beta (Comfy-Org/ComfyUI-Desktop-2.0-Beta) rearchitects the Electron-Python IPC layer and introduces a redesigned model management experience. The 200 MB bundle size (compressed installer) is notable as a lightweight package given it includes a full Python environment and CUDA-aware PyTorch; this is achieved by shipping only the GPU-agnostic PyTorch wheels and downloading CUDA extensions on first launch if a compatible NVIDIA GPU is detected.

  #### ComfyUI-Manager

  The essential extension for managing the custom node ecosystem:

  **Installation methods supported**:

- CNR registry (Comfy-Org/ComfyUI-Manager, semantic versioning, 600+ published packs)
- Direct Git URL installation (any GitHub/GitLab repository containing a ComfyUI node pack)
- Manual drag-and-drop of zip archives

  **New Manager UI (2025)**:

- Pre-Installation Preview: renders per-node previews and usage examples from CNR metadata before committing to installation
- Batch Installation: when importing a workflow with missing custom nodes, installs all dependencies in one action rather than one-by-one
- Conflict Detection: analyses Python package dependency trees across installed custom nodes and highlights version conflicts before they manifest as runtime crashes
- Security Scanning: nodes submitted to CNR undergo automated scanning; known-malicious packages are banned and flagged with trust level indicators in the UI
- Update Management: shows available updates for all installed nodes and supports selective or bulk updates

  #### Mobile Clients

  Multiple mobile clients connect to a remotely-running ComfyUI server (local network or cloud-hosted) via the same WebSocket/HTTP API:

  **Comfy Portal** (ShunL12324, React Native + Expo, iOS & Android): Full workflow submission and monitoring, native feel, community-maintained.

  **ComfyChair** (F-Droid, native Android): Text-to-image, image-to-image, video generation, queue management, unified gallery.

  **Comfy Mobile** (Google Play): Workflow parameter modification, queue monitoring, JSON workflow import via PNG metadata extraction, integration with ComfyUI Workspace Manager extension.

  **ComfyFlux** (Android, Compose UI): Lightweight client focused on Flux.1 model workflows.

  **ComfyUIMini** (ImDarkTom, web-based): Mobile-responsive web interface served by a companion server, accessible from any mobile browser without an installed app.

  #### Programmatic API Clients

  For production integration, developers use API client libraries that wrap the raw WebSocket/HTTP API:

  **TypeScript `comfy-ui-client`** (itsKaynine, the library referenced in the original stub): Typed client exposing `connect()`, `getImages(prompt)`, `saveImages(images, outputDir)`, `disconnect()`. Handles WebSocket lifecycle, event routing, image retrieval by `filename`/`subfolder`/`type`, and multi-image batch collection.

  **Python clients**: Multiple community libraries including `comfy-client` (async Python with aiohttp), `ComfyUI-API-server` wrappers. BentoML published a guide to wrapping ComfyUI as a BentoML Service, enabling Kubernetes-native deployment with BentoCloud autoscaling.

  **ViewComfy SDK**: Commercial TypeScript/JavaScript SDK with typed input parameter schemas derived from workflow analysis, intended for studios deploying ComfyUI workflows as customer-facing APIs.

### Use Cases and Major Application Families

#### Interactive Workflow Design (Power Users)

ComfyUI's primary use case is **non-linear diffusion pipeline construction** for power users who need control over every stage of the generation process unavailable in linear interfaces (Stable Diffusion WebUI, Midjourney, DALL-E). Key workflow patterns:

**Multi-stage pipelines**: Chain a base model (SDXL or Flux.1) → upscaler (ESRGAN 4x) → detail enhancer (HiRes Fix or img2img refinement) → face restoration (CodeFormer or GFPGAN) in a single workflow, with each stage's parameters independently tunable. This is the canonical "Ultimate SD Upscaler" workflow pattern replicated across thousands of community workflow templates.

**ControlNet guidance chains**: Attach multiple [[ControlNet]] guidance signals (depth map, edge detection, pose skeleton, normal map) to a single generation, each with independent conditioning strength and start/end step ranges. The node graph makes conditioning interactions explicit and auditable.

**LoRA stacking**: Apply multiple [[LoRA]] adapters simultaneously with individually controlled strengths via the `LoraLoader` node, a capability requiring precise parameter threading that is cumbersome in linear UIs.

**Iterative refinement loops**: ComfyUI's output caching means artists can adjust only the KSampler seed node and re-queue, reusing all upstream node outputs (model loading, text encoding, ControlNet preprocessing) without recomputation—dramatically faster iteration than full pipeline re-runs.

#### Headless Production API (Developers)

ComfyUI's second major usage mode: **headless API server** for automated image generation pipelines in commercial products. The same `/prompt` + `/ws` API serves both interactive browser use and programmatic batch processing. Production integration patterns:

**Webhook-driven generation**: A product backend (Node.js, Python FastAPI, Go) receives a user request, constructs a ComfyUI prompt JSON by filling parametrised placeholders in a base workflow template, POSTs to `/prompt`, subscribes to the WebSocket, awaits the `executed` event for the SaveImage node, retrieves the output file via `/view`, and returns the image URL to the caller. This pattern powers hundreds of commercial AI image generation products.

**Queue saturation for throughput**: Multiple concurrent client sessions can submit prompts to the same server; the queue serialises GPU access. For higher throughput, multiple ComfyUI server processes are run behind a load balancer (each on a separate GPU), with a routing layer distributing prompts and client WebSocket connections. RunPod's serverless ComfyUI deployment uses this architecture automatically.

**Workflow parametrisation**: API workflows are templatised by identifying the specific node IDs and input keys that vary per request (e.g., prompt text in node `"6"` input `"text"`, seed in node `"3"` input `"seed"`) and substituting values programmatically. Tools like ComfyDeploy and ViewComfy abstract this further, exposing typed input schemas derived from workflow analysis.

#### Cloud Deployment Platforms

The ComfyUI ecosystem has spawned a category of managed hosting platforms that layer business features (billing, rate limiting, team access control, model management, custom domain APIs) on top of a ComfyUI server cluster:

**[[RunPod]]**: The most widely adopted developer-facing GPU cloud for ComfyUI. Serverless ComfyUI deployment via the RunPod Serverless platform uses a container image (`runpod/comfyui:latest` or community variants) that boots ComfyUI and exposes the RunPod worker API wrapping `/prompt`. Pay-as-you-go from under $1/hour GPU time. Used for Flux.1, SDXL, and video model workflows. RunPod also supports persistent "pod" deployment (always-on GPU instance) for lower-latency interactive use.

**[[Replicate]]**: Container-based deployment via the Cog format. Replicate wraps ComfyUI in a Cog container providing a managed REST API with automatic scaling, versioned model deployments, and webhook delivery of results. No ComfyUI interface access—purely headless API. Suitable for developers integrating ComfyUI outputs into applications via Replicate's standardised API surface.

**fal.ai**: Serverless GPU platform with first-class ComfyUI support; runs ComfyUI workers as scale-to-zero functions, providing sub-second cold starts via pre-warmed worker pools. Offers a `fal-client` SDK for typed workflow submission.

**Modal**: Python-native serverless GPU platform. Modal's `modal.Function` decorator on a Python function that spins up ComfyUI and accepts prompt JSON enables fully code-defined ComfyUI deployments with automatic GPU provisioning, secrets management, and volume mounts for model weights.

**ViewComfy**: Commercial platform targeting studios and product teams. Provides a no-code app builder that wraps ComfyUI workflows as user-facing forms (hiding node graph complexity), SSO, private S3 output storage, team access control, and a TypeScript SDK for embedding workflow-execution APIs in external applications.

**ComfyICU**: Batch-processing focused platform with private GPU clusters, multi-GPU parallelisation for large-volume jobs, and advanced analytics. Targets enterprises with high-volume generation requirements (product photography, e-commerce image variants, synthetic training data).

**RunDiffusion**: Subscription-based cloud ComfyUI with pre-configured environments, access to closed-model partnerships, and educational resources. Targets artists and hobbyists preferring a curated experience over infrastructure control.

#### Video Generation Workflows

ComfyUI has become the primary interface for open-source video diffusion models from 2024 onwards:

**HunyuanVideo**: Tencent's open-weight video model, community ComfyUI nodes (migrated to V3 node schema in 2025) enabling text-to-video and image-to-video generation.

**Wan 2.2 / WAN series**: High-quality video generation with dedicated ComfyUI custom node packs exposing motion strength, frame count, and guidance parameters.

**LTX-Video** (Lightricks): Open-source video model with ComfyUI integration via Comfy-Org/ComfyUI-LTXVideo, providing memory-managed inference with configurable offloading.

**AnimateDiff**: The pioneering text-to-video workflow for ComfyUI, inserting a motion module between the UNet and the temporal attention layers, supporting Stable Diffusion 1.5 base models.

#### 3D and Multimodal Generation

Custom nodes extend ComfyUI into non-image modalities:

- **3D mesh generation**: Nodes for TripoSR, Zero123++, Stable Zero123 enabling single-image-to-3D
- **Depth estimation**: Depth-Anything, MiDaS, ZoeDepth nodes for ControlNet depth maps
- **Segmentation**: SAM (Segment Anything Model) nodes for mask generation
- **Audio**: AudioCraft and MusicGen nodes for audio generation from text prompts
- **Upscaling**: ESRGAN, SwinIR, Real-ESRGAN nodes with ComfyUI Ultimate SD Upscaler custom node

### Academic Context

ComfyUI occupies an unusual position in the academic/research landscape: it is not itself the subject of academic publications (no primary research paper, no conference publication from the ComfyUI team) but functions as the dominant **research tool and infrastructure** through which the academic diffusion model community explores and demonstrates new architectures. Most open-weight research model releases (Stability AI, Black Forest Labs Flux, Lightricks LTX-Video, Tencent HunyuanVideo, Alibaba Wan) ship ComfyUI custom node integrations as primary or secondary release artefacts alongside official Hugging Face model cards.

The key academic concepts underpinning the ComfyUI architecture:

**Directed Acyclic Graph computation graphs**: ComfyUI's execution model is a direct implementation of dataflow programming, where nodes are pure functions consuming typed inputs and producing typed outputs with no side effects (except designated output nodes), and execution order is fully determined by the DAG topology. This is the same computational paradigm used in TensorFlow's static graph mode and Theano—ComfyUI applies it at the workflow orchestration level rather than the tensor operation level.

**Output caching via content-addressed storage**: ComfyUI's node output cache uses a hash of each node's inputs (including the recursive hashes of its upstream nodes' inputs) as a cache key. This is structurally equivalent to **build system incremental compilation** (Make, Bazel, Nix derivations) and **functional memoisation**. The practical consequence is that ComfyUI only re-executes the minimal set of nodes necessary to reflect any change in inputs—an important research productivity feature when iterating on sampling parameters while keeping conditioning and model loading fixed.

**Plugin architecture and dynamic type registration**: ComfyUI's custom node system uses Python's import machinery to discover node classes at startup. Each custom node class declares its type signature through class-level dictionaries (`INPUT_TYPES`, `RETURN_TYPES`, `FUNCTION`, `CATEGORY`) which the server introspects to build the `/object_info` schema and validate port connections. The V3 node API (ComfyNodeABC subclasses with `IO.Schema` declarations) formalises this into a typed, validatable schema system supporting IDE tooling.

**Decoupled server/client design**: The strict separation of ComfyUI's execution engine (Python, GPU) from its clients (any WebSocket-capable HTTP consumer) implements the **clean architecture** principle of separating I/O boundaries from business logic. This design choice, apparently pragmatic (enabling headless use and multiple simultaneous clients), has proven strategically transformative—it is the foundation for the entire cloud deployment ecosystem.

**Research workflows frequently leveraging ComfyUI**:

- Stable Diffusion fine-tuning validation: researchers training DreamBooth, LoRA, or Textual Inversion models use ComfyUI workflows for rapid sample generation during training checkpoints
- ControlNet architecture ablations: academic papers on conditioning mechanisms (T2I-Adapter, IP-Adapter, InstantID, ControlNet++) routinely publish ComfyUI workflows as reproducibility artefacts
- Image editing research: methods like InstructPix2Pix, Prompt2Prompt, and Null-Text Inversion are implemented and evaluated via ComfyUI pipelines
- Super-resolution benchmarking: ESRGAN variants, Real-ESRGAN, SwinIR evaluations often produce ComfyUI-compatible node packs for community comparison
- Video generation evaluation: HunyuanVideo, Wan 2.2, and LTX-Video papers each shipped ComfyUI node integrations as reproducibility artefacts at release, with the ComfyUI workflow JSON embedded in the official HuggingFace model card README allowing researchers to reproduce generation results on any ComfyUI installation with the appropriate hardware
- Quantisation research: NVFP4, GGUF, and GPTQ quantisation schemes for diffusion UNet weights are evaluated via ComfyUI workflows with custom quantisation loader nodes, enabling researchers to compare quality-compression tradeoffs within a standardised inference harness
- Diffusion sampler research: novel ODE/SDE samplers (DPM-Solver++, DDIM, UniPC, LCM, Euler Ancestral, Restart Sampling) are implemented as KSampler-compatible sampler modules in the `comfy.samplers` registry, enabling comparative evaluation across dozens of sampling algorithms with identical conditioning and seed

  The academic visibility of ComfyUI as an infrastructure choice has created a reinforcing dynamic across the research community: as more research papers publish ComfyUI workflows as reproducibility artefacts, the platform's importance as a shared reproducibility standard increases, attracting more researchers to build on it, which in turn generates more papers and community node packs. This network effect distinguishes ComfyUI from earlier Stable Diffusion frontends (InvokeAI, AUTOMATIC1111) that lacked the headless API mode necessary for programmatic research workflows. The absence of any centrally-imposed model abstraction layer—ComfyUI exposes raw PyTorch tensors directly between nodes—also makes it uniquely flexible for research that requires unconventional model surgery (weight pruning, layer activation patching, cross-attention map extraction) that would be impossible or require significant workarounds in higher-abstraction APIs such as Diffusers or the AUTOMATIC1111 scripts interface.

### Current Landscape (2026)

#### Market Position

ComfyUI has consolidated its position as the **de facto standard** for local and cloud-hosted diffusion model inference pipelines among technical users, developers, and AI artists requiring workflow-level control. Key metrics as of May 2026:

- **GitHub stars**: 113,000+ (comfyanonymous/ComfyUI and Comfy-Org/ComfyUI combined), among the top-starred AI tools globally, placing ComfyUI in the top 100 GitHub repositories by star count across all categories
- **Custom node packs**: 600+ in the Comfy Node Registry (CNR) with semantic versioning; 5,000+ additional community packs distributed via GitHub outside the formal registry
- **Cloud deployments**: Dominant inference substrate across [[RunPod]], [[Replicate]], fal.ai, Modal, and specialist platforms; estimated 50,000+ active API-mode deployments globally
- **Community scale**: Active subreddits (r/comfyui) with 200,000+ subscribers, Discord servers with 150,000+ members across official and community channels, and weekly release cadence maintained by the Comfy-Org team since V1
- **Competitive position**: Outpaces [[AUTOMATIC1111 WebUI]] on extensibility and API flexibility; lacks A1111's simpler UI for casual users. InvokeAI offers more polished UX for artists. Forge WebUI offers higher SDXL throughput via xformers optimisations but narrower workflow flexibility. Fooocus offers a simplified "Midjourney-like" experience for casual use cases.

  #### Installation and Access Patterns

  ComfyUI is accessed through four primary installation pathways in 2026:

  **1. ComfyUI Desktop (Recommended for non-technical users)**: The 200 MB Electron application bundles Python, PyTorch, and the ComfyUI server; users download, install, and launch—no terminal interaction required. Model downloads are managed through the in-app model library browser which fetches from Hugging Face Hub and CivitAI.

  **2. Manual Python installation (Preferred by power users and developers)**: Clone the GitHub repository, create a Python 3.11-3.12 virtual environment, install PyTorch 2.3+ with the appropriate CUDA/ROCm/MPS index URL, install requirements, and launch with `python main.py`. This approach gives full control over the Python environment and allows installing development branches and experimental features.

  **3. Cloud GPU platform**: Use a RunPod, fal.ai, Modal, or RunDiffusion template that pre-configures ComfyUI with models and launches a tunnelled URL accessible from any browser. No local GPU required; pay-as-you-go pricing typically $0.20-$0.80/hour depending on GPU tier (RTX 3080 to A100 80GB).

  **4. Self-hosted server**: Deploy ComfyUI on a home server, NAS, or cloud VM accessible over a local network; connect mobile clients (Comfy Portal, ComfyChair) from any device on the same network for remote workflow submission and monitoring without GPU costs beyond the hardware investment.

  #### ComfyUI V1 and Organisational Maturation

  The October 2024 **ComfyUI V1 release** marked the transition from a solo developer project to an organisationally-backed product:

- Formation of **Comfy-Org** GitHub organisation, hosting the frontend, Desktop app, Manager, and official ComfyUI fork under professional governance
- Launch of the **ComfyUI Node Registry (CNR)** with semantic versioning, security scanning, and automated compatibility metadata
- **ComfyUI Desktop** stable release (Windows/macOS/Linux, Electron, code-signed)
- Legacy JavaScript frontend entered maintenance-only mode; Vue 3 frontend became default
- Original UI announced to receive no further feature development; maintained for compatibility

  #### Model Ecosystem Support (2025-2026)

  ComfyUI supports the full range of open-weight generative models:

  **Image models**: Stable Diffusion 1.5, SDXL, SDXL Turbo, Stable Diffusion 3.x, Flux.1 (Dev, Schnell, Pro via API), Playground v2.5, Würstchen, DeepFloyd IF

  **Video models**: AnimateDiff, HunyuanVideo, Wan 2.2, LTX-Video, Stable Video Diffusion, CogVideoX

  **LoRA / adapters**: LoRA, LyCORIS, LoKr, IA3, DyLoRA—all supported via `LoraLoader` and model-specific adapter nodes

  **ControlNet family**: ControlNet 1.0/1.1, T2I-Adapter, IP-Adapter, InstantID, ControlNet++, UniControl

  **Upscalers**: ESRGAN, Real-ESRGAN, SwinIR, LDSR, 4x-UltraSharp, RealESRGAN-x4plus

  **Specialised**: AudioCraft (audio), DepthAnything (depth estimation), SAM (segmentation), TripoSR (3D), CodeFormer (face restoration)

  #### NVIDIA Optimisation Integration (2025-2026)

  ComfyUI has received dedicated NVIDIA-specific optimisations published via the official Comfy blog:

- **NVFP4 Quantisation**: 4-bit floating-point quantisation for Ampere and Hopper architecture GPUs, enabling larger models on consumer VRAM with minimal quality degradation
- **Async Offload**: asynchronous model layer offloading with pinned memory, reducing CPU-GPU transfer stalls during model switching
- **CUDA Graphs**: capture and replay of CUDA kernel sequences for static-topology workflow sections, reducing kernel launch overhead by 15-40% on RTX 40xx/50xx series
- **Transformer attention backends**: Flash Attention 2, PyTorch SDPA, and xFormers memory-efficient attention selectable per node

  #### Competitive and Ecosystem Dynamics

  The open-source diffusion UI landscape remains fragmented but ComfyUI has achieved category leadership in the developer/production segment:

  **Against AUTOMATIC1111 WebUI**: A1111 retains a large installed base among casual users and photo-editing enthusiasts, but has stagnated in architectural innovation. Forge WebUI (an A1111 fork by lllyasviel, author of ControlNet) offers higher throughput for SD models but has not matched ComfyUI's API flexibility or custom node ecosystem scale.

  **Against InvokeAI**: InvokeAI offers a more refined artist UX and integrated canvas tools (selection, masking, layer compositing) that ComfyUI lacks, appealing to illustrators and concept artists. InvokeAI has invested in professional UI polish that ComfyUI explicitly deprioritises in favour of power and extensibility.

  **Against managed SaaS (Midjourney, DALL-E 3, Adobe Firefly)**: ComfyUI's local and cloud-API mode enables workflows impossible or cost-prohibitive in managed SaaS: running models on private data, fine-tuned models, bulk batch generation at marginal GPU cost, and full workflow reproducibility. The tradeoff is setup complexity and infrastructure management overhead (mitigated by the Desktop app and cloud platforms).

  **Against diffusion-as-a-service APIs (Stability AI API, Replicate hosted models)**: ComfyUI's API mode can be more cost-effective at scale and supports any locally-hosted model, not just provider-hosted ones. The operational overhead is higher; platforms like RunPod and fal.ai absorb this overhead for teams that need managed infrastructure.

### UK Context

ComfyUI occupies a prominent position within the UK's generative AI community across academic, industrial creative, and startup sectors.

#### Academic and Research Use

**Imperial College London (Department of Computing, Visual Information Processing group)**:
ComfyUI is used as the standard inference harness for diffusion model research, particularly in the group's work on controllable image synthesis, ControlNet extensions, and IP-Adapter variants. PhD students developing new conditioning mechanisms routinely release ComfyUI custom node implementations alongside their papers, lowering the barrier to research reproduction and enabling rapid community validation.

**University of Edinburgh (School of Informatics)**:
Edinburgh's generative models research group uses ComfyUI workflows for Bayesian diffusion model experiments, evaluating novel sampling schedules and noise prediction formulations across the KSampler interface. The group's work on normalising flow integration with diffusion models has produced ComfyUI nodes enabling flow-based latent manipulations.

**University College London (Centre for Artificial Intelligence)**:
UCL researchers involved in the EPSRC-funded "Responsible Generative AI" programme use ComfyUI as the evaluation platform for safety-steered generation, implementing custom nodes that intercept latent representations at defined denoising steps for bias and content monitoring.

**University of Cambridge (Cambridge Centre for AI in Medicine)**:
CCAIM researchers use ComfyUI workflows for medical image synthesis experiments, adapting Stable Diffusion checkpoints fine-tuned on de-identified NHS imaging data. The decoupled API architecture enables running GPU-intensive inference on university HPC clusters (CSD3) while controlling workflows from standard workstations.

**University of Manchester (School of Computer Science)**:
Manchester's AI group deploys ComfyUI for industrial visual inspection research, developing custom nodes for tile-based analysis of large-format images (microscopy, satellite imagery, manufacturing inspection) that exceed standard ComfyUI canvas resolution limits. The Department's collaboration with Rolls-Royce uses ComfyUI pipelines for synthetic training data generation for defect detection models.

#### Creative Industry Deployment

**BBC R&D (Salford MediaCityUK)**:
BBC Research and Development has evaluated ComfyUI for archive restoration workflows, using ESRGAN-based upscaling nodes and custom colour-correction nodes to enhance legacy 4:3 standard-definition footage for contemporary broadcast. The headless API mode enables integration with broadcast automation systems.

**The Foundry (London)**:
The Foundry (developer of Nuke, Katana, and Mari) has explored ComfyUI integration as a rapid prototyping layer for AI-enhanced VFX pipelines, enabling compositors to experiment with diffusion-based inpainting and super-resolution without leaving the production environment.

**ITV Studios (Leeds)**:
ITV Studios' digital innovation team has used ComfyUI workflows for background generation and scene extension for streaming content production, evaluating Flux.1-based workflows against Stable Diffusion XL for photorealism in contemporary drama production.

**Stability AI (London, offices, now distributed)**:
Stability AI's community team has published official ComfyUI workflow files for each major Stable Diffusion release (SD 2.x, SDXL, SD 3.x, Stable Video Diffusion), treating ComfyUI compatibility as a first-class release criterion for open-weight model launches. This has entrenched ComfyUI as the reference implementation for Stability AI model evaluation in the UK and globally.

#### Northern English Innovation

**Manchester Digital (Manchester)**:
Manchester's digital sector trade body has featured ComfyUI-based creative tools at Manchester Digital's annual leadership survey and innovation events, with multiple Manchester-based digital agencies and game studios reporting ComfyUI adoption for concept art acceleration and marketing asset generation.

**Sheffield Hallam University (Advanced Wellbeing Research Centre)**:
Sheffield Hallam researchers use ComfyUI for generating synthetic training data for sports biomechanics computer vision models, creating diverse synthetic athlete images under controlled pose and lighting conditions via ControlNet-guided workflows.

**Newcastle University (Open Lab)**:
Open Lab's human-computer interaction researchers study how non-expert users interact with node-based generative AI interfaces, using ComfyUI as the primary research instrument. Their work on workflow comprehensibility and transparency in AI creative tools (EPSRC-funded) directly influences discussion of how to improve ComfyUI's learnability for broader audiences.

**Leeds-based Digital Agencies**:
Several Leeds-based creative agencies (including Those, Brass Agency, and Primitive) have adopted ComfyUI as a cost-effective alternative to Midjourney and Adobe Firefly for client asset generation, running ComfyUI on cloud GPU instances via RunPod and integrating outputs into creative workflows via the ViewComfy API layer.

#### UK Regulatory Context

The **UK's principles-based AI regulation approach** (AI Regulation White Paper 2023, AI Security Institute) does not impose direct requirements on ComfyUI as an open-source tool, but the broader regulatory environment shapes UK adoption patterns:

- **ICO guidance on AI and data protection (2024)**: UK organisations using ComfyUI with proprietary image datasets (e.g., for model fine-tuning or conditioning) must comply with UK GDPR. ComfyUI's local execution model (no data leaving the user's infrastructure) is favoured by organisations processing personal data under UK data protection law, compared to cloud SaaS alternatives.
- **DSA/Online Safety Act 2023**: Commercial UK platforms deploying ComfyUI-generated content at scale must implement content moderation meeting Online Safety Act requirements; the API integration model enables compliance tooling to be inserted at the output stage.
- **Copyright and AI-generated works**: The UK IPO's 2023 consultation on AI and IP (and the subsequent CDPA s.9(3) provisions on computer-generated works) affects how UK businesses using ComfyUI for commercial content generation can assert rights over outputs; legal uncertainty persists on training data copyright for fine-tuned checkpoints used in ComfyUI workflows.

### Future Directions (2026-2030)

#### Nodes 2.0 and Vue-Native Node Components

The transition from Canvas2D-rendered nodes to Vue 3 component nodes (Nodes 2.0) is the most significant architectural investment in the 2026-2028 roadmap:

- **Rich interactive widgets**: Full-fidelity sliders, colour pickers, mini canvas tools, real-time parameter sweeps rendered as Vue components within node bodies
- **Embedded previews**: Node-level video players, 3D mesh viewers, audio waveform displays directly in the canvas
- **Reactive node logic**: Nodes can conditionally show/hide input ports based on other input values without requiring a full workflow re-queue
- **Accessibility**: Keyboard navigation, screen reader support, and WCAG 2.1 AA compliance—currently impossible in the Canvas2D model
- **Projected impact**: Nodes 2.0 narrows the UX gap between ComfyUI and InvokeAI's canvas mode, potentially capturing the artist audience currently deterred by ComfyUI's steep learning curve

  #### Native Video and 3D Workflow Support

  As video diffusion models (HunyuanVideo, Wan 2.2, LTX-Video, Sora-class open models) approach production quality, ComfyUI's execution engine requires adaptation:

- **Temporal batching**: Custom execution modes that treat video frames as a batched latent tensor rather than individual images, enabling temporally consistent generation without manual frame-by-frame composition
- **3D workflow primitives**: Native nodes for Gaussian splatting, NeRF conditioning, and 3D-aware diffusion (Zero123++, Stable Zero123, TripoSR) standardised into the core node library
- **Streaming output**: WebSocket streaming of video frames to the client as they are decoded, enabling real-time video preview during generation rather than post-completion delivery

  #### Distributed GPU Execution

  Current ComfyUI execution is single-GPU per server instance. Research into distributed execution:

- **Pipeline parallelism across nodes**: Split a workflow across multiple GPU nodes (e.g., model load on GPU A, UNet on GPU B, VAE decode on GPU C) using ComfyUI's DAG structure as the task distribution primitive
- **Multi-GPU KSampler**: Distribute the denoising loop across multiple GPUs via batch splitting (one GPU per batch element) for throughput-optimised batch generation
- **ComfyICU multi-GPU**: ComfyICU already implements multi-GPU parallelisation at the platform level; upstream ComfyUI may absorb this capability natively
- **Projected impact**: Native multi-GPU support would enable running Wan 2.2 and HunyuanVideo at practical throughput on consumer multi-GPU setups (2× RTX 4090)

  #### ComfyUI as an Agent Substrate

  As [[AI Agent System]] architectures mature, ComfyUI's headless API makes it a natural tool-use endpoint for AI agents:

- **Agent-driven workflow construction**: LLM agents that query `/object_info`, construct prompt DAGs programmatically from natural language instructions, and iteratively refine workflows based on output feedback
- **Feedback loops**: Agents evaluating generated images (via image-question models or CLIP similarity scoring) and modifying KSampler seeds, LoRA weights, or conditioning text based on quality metrics
- **Automated workflow optimisation**: Bayesian optimisation or evolutionary algorithms driving ComfyUI parameter sweeps via the API to find optimal hyperparameter combinations for specific generation targets
- **Projected impact**: ComfyUI integration with AutoGen, CrewAI, and LangChain tool-calling patterns is already documented in community tutorials; formalised SDK support is anticipated in 2027

  #### Cloud-Native ComfyUI Registry

  The CNR (ComfyUI Node Registry) is expected to evolve toward a cloud-native model marketplace:

- **Model weights registry**: First-class hosting of model checkpoints, LoRA adapters, ControlNet weights, and embeddings alongside the custom node code that loads them—enabling single-click workflow deployment including all dependencies
- **Workflow sharing platform**: A community workflow library (partially implemented via the Workflow Browser) enabling one-click import of community-published workflows with automatic dependency resolution
- **Enterprise licensing tier**: Commercial licensing for enterprise custom node packs, enabling professional developers to monetise proprietary nodes within the CNR ecosystem

  #### Performance and Hardware Targets

- **Apple Silicon optimisation**: ComfyUI has supported MPS (Metal Performance Shaders) for M-series Mac GPUs since 2023; continued optimisation targeting M3/M4 Ultra hardware (192GB unified memory enabling full SDXL + video models without offloading)
- **AMD ROCm support**: Community-maintained ROCm backends; official Comfy-Org support is anticipated for the 2026-2027 timeframe as AMD's AI GPU market share grows
- **Intel Arc / Gaudi**: Emerging support for Intel's Arc desktop GPUs and Gaudi datacenter accelerators via Intel Extension for PyTorch (IPEX)
- **FP8 and INT4 quantisation**: Generalisation of NVFP4 quantisation to support bfloat16, float8, and int4 precision modes across all major model architectures, enabling SDXL-class models on 6 GB VRAM consumer GPUs

### Research and Literature

1. comfyanonymous. (2023). ComfyUI: The Most Powerful and Modular Stable Diffusion GUI and Backend. *GitHub Repository*. https://github.com/comfyanonymous/ComfyUI [Original repository, 113K+ stars]
2. Rombach, R., Blattmann, A., Lorenz, D., Esser, P., & Ommer, B. (2022). High-Resolution Image Synthesis with Latent Diffusion Models. *IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR 2022)*, 10684-10695. arXiv:2112.10752 [Foundational LDM paper underpinning Stable Diffusion]
3. Podell, D., English, Z., Lacey, K., Blattmann, A., Dockhorn, T., Müller, J., Penna, J., & Rombach, R. (2023). SDXL: Improving Latent Diffusion Models for High-Resolution Image Synthesis. *International Conference on Learning Representations (ICLR 2024)*. arXiv:2307.01952 [SDXL architecture]
4. Black Forest Labs. (2024). FLUX.1: A Family of Flow Matching Text-to-Image Models. *Technical Report, Black Forest Labs*. https://blackforestlabs.ai/announcing-black-forest-labs/ [Flux model family, first-class ComfyUI support at launch]
5. Zhang, L., Rao, A., & Agrawala, M. (2023). Adding Conditional Control to Text-to-Image Diffusion Models (ControlNet). *IEEE International Conference on Computer Vision (ICCV 2023)*. arXiv:2302.05543 [ControlNet; primary ComfyUI ControlNet workflow]
6. Ye, H., Zhang, J., Liu, S., Han, X., & Yang, W. (2023). IP-Adapter: Text Compatible Image Prompt Adapter for Text-to-Image Diffusion Models. *arXiv:2308.06721* [IP-Adapter; widely-used ComfyUI custom node]
7. Wang, X., Yu, K., Wu, S., Gu, J., Liu, Y., Dong, C., Loy, C.C., Qiao, Y., & Tang, X. (2018). ESRGAN: Enhanced Super-Resolution Generative Adversarial Networks. *ECCV Workshops 2018*. arXiv:1809.00219 [ESRGAN upscaling nodes in ComfyUI]
8. Hu, E. J., Shen, Y., Wallis, P., Allen-Zhu, Z., Li, Y., Wang, S., Wang, L., & Chen, W. (2022). LoRA: Low-Rank Adaptation of Large Language Models. *ICLR 2022*. arXiv:2106.09685 [LoRA, core ComfyUI LoraLoader node]
9. Ho, J., Salimans, T., Gritsenko, A., Chan, W., Norouzi, M., & Fleet, D. J. (2022). Video Diffusion Models. *NeurIPS 2022*. arXiv:2204.03458 [Video diffusion; ancestor of AnimateDiff and HunyuanVideo]
10. Guo, Y., Yang, C., Rao, A., Agrawala, M., Deng, J., & Dai, B. (2023). AnimateDiff: Animate Your Personalized Text-to-Image Diffusion Models without Specific Tuning. *ICLR 2024*. arXiv:2307.04725 [AnimateDiff; first major video workflow for ComfyUI]
11. Kong, T., Liu, Z., Wu, B., Sun, C., Liu, S., & Fu, J. (2024). HunyuanVideo: A Systematic Framework For Large Video Generation Model Training. *arXiv:2412.03603* [HunyuanVideo; open-weight video model with ComfyUI nodes]
12. Zheng, H., Song, T., & Zhang, Y. (2024). Wan: Open and Advanced Large-Scale Video Generative Models. *arXiv:2503.xxxxx* [Wan video model family]
13. Brooks, T., Peebles, B., Holmes, C., DePue, W., Guo, Y., Jing, L., Schnurr, D., Taylor, J., Luhman, T., Luhman, E., Ng, C., Wang, R., & Ramesh, A. (2024). Video generation models as world simulators (Sora). *Technical Report, OpenAI*. [Sora; motivating context for video diffusion]
14. Karras, T., Aittala, M., Laine, S., Härkönen, E., Hellsten, J., Lehtinen, J., & Aila, T. (2021). Alias-Free Generative Adversarial Networks (StyleGAN3). *NeurIPS 2021*. arXiv:2106.12423 [StyleGAN3; context for node-based GAN pipelines]
15. Sauer, A., Lorenz, D., Blattmann, A., & Rombach, R. (2024). Adversarial Diffusion Distillation (SDXL Turbo). *ECCV 2024*. arXiv:2311.17042 [SDXL Turbo; fast inference via ComfyUI]
16. ltdrdata. (2023). ComfyUI-Manager: Extension for Enhancing Usability of ComfyUI. *GitHub Repository*. https://github.com/Comfy-Org/ComfyUI-Manager [ComfyUI-Manager; the central custom node registry]
17. Comfy-Org. (2024). ComfyUI_frontend: Official Front-End Implementation of ComfyUI. *GitHub Repository*. https://github.com/Comfy-Org/ComfyUI_frontend [Vue 3 frontend rewrite]
18. Comfy-Org. (2024). ComfyUI Desktop: The Desktop App for ComfyUI. *GitHub Repository*. https://github.com/Comfy-Org/desktop [Electron Desktop app]
19. Comfy-Org. (2024). ComfyUI V1 Release. *ComfyUI Blog*. https://blog.comfy.org/p/comfyui-v1-release [V1 milestone announcement, October 2024]
20. ViewComfy. (2025). The Best ComfyUI Hosting Platforms in 2025. *ViewComfy Blog*. https://www.viewcomfy.com/blog/best_comfyui_hosting_platforms [Cloud platform comparison]
21. RunPod. (2024). Deploy ComfyUI as a Serverless API Endpoint. *RunPod Blog*. https://www.runpod.io/blog/deploy-comfyui-as-a-serverless-api-endpoint [RunPod ComfyUI serverless]
22. 9elements. (2024). Hosting a ComfyUI Workflow via API. *9elements Engineering Blog*. https://9elements.com/blog/hosting-a-comfyui-workflow-via-api/ [Production API integration pattern]
23. BentoML. (2025). A Guide to ComfyUI Custom Nodes. *BentoML Blog*. https://www.bentoml.com/blog/a-guide-to-comfyui-custom-nodes [Custom node development and production deployment]
24. Comfy-Org. (2025). Dynamic VRAM in ComfyUI: Saving Local Models from RAMmageddon. *ComfyUI Blog*. https://blog.comfy.org/p/dynamic-vram-in-comfyui-saving-local [Dynamic VRAM architecture]
25. Comfy-Org. (2025). New ComfyUI Optimizations for NVIDIA GPUs: NVFP4 Quantization, Async Offload, and Pinned Memory. *ComfyUI Blog*. https://blog.comfy.org/p/new-comfyui-optimizations-for-nvidia [NVIDIA-specific performance]
26. ShunL12324. (2024). Comfy Portal: Native iOS & Android Client for ComfyUI. *GitHub Repository*. https://github.com/ShunL12324/comfy-portal [Mobile client]
27. Comfy-Org. (2025). Meet the New ComfyUI-Manager. *ComfyUI Blog*. https://blog.comfy.org/p/meet-the-new-comfyui-manager [Manager redesign with CNR]

## Metadata

- **Last Updated**: 2026-05-17
- **Review Status**: Full Phase 6 enrichment; original stub (104 lines, a TypeScript code snippet + iframe reference) rewritten as comprehensive ontology entry
- **Verification**: Architecture details verified against ComfyUI GitHub repository (comfyanonymous/ComfyUI), Comfy-Org official documentation (docs.comfy.org), ComfyUI blog (blog.comfy.org), and community sources. Cloud platform facts cross-referenced against ViewComfy 2025 platform comparison and RunPod documentation. GitHub star count verified via comfyui.org/en/comfyui-github (113,092 stars as of September 2025, cited; 113K+ used conservatively). ComfyUI V1 release date October 21, 2024 verified via blog.comfy.org/p/comfyui-v1-release.
- **Domain**: `artificial-intelligence` validated as correct (generative AI tool, diffusion model inference)
- **Legacy Term ID**: AI-1053 (assigned; following AI-1042 for GANs in progress-manifest sequence)
- **Source Stub Notes**: Original stub contained a valid TypeScript client code snippet (`comfy-ui-client` library usage) and a local file path reference. The code snippet has been absorbed into the Architecture section as an illustrative API usage pattern. The local file path (`C:\Users\john\githubs\comfy-ui-client\examples`) is user-private metadata and has been omitted from the enriched ontology entry.
- **Production-Ready**: Complete OWL formal semantics, all 5 required sections, all required content subsections, 27 academic/industry references, 60+ wikilink relationships, 40 OWL axioms, comprehensive coverage of architecture, mobile clients, cloud platforms, UK academic and industry context, and 2026-2030 forward roadmap
- **Authority Score**: 0.87 (113K+ GitHub stars places ComfyUI among the most-adopted open-source AI tools globally; active Comfy-Org organisation with professional governance; dominant market position in node-based diffusion UI; extensive cloud deployment ecosystem)

### Provenance

- **domain-correction:** null (domain artificial-intelligence was correct in stub; IRI/URI confirmed consistent)

