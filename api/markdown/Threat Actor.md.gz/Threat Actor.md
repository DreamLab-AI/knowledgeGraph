A Threat Actor is an individual, organised group, or nation-state entity that possesses the intent, capability, and opportunity to exploit vulnerabilities in digital systems. Actors are classified by motivation (financial, ideological, strategic, personal) and sophistication tier (opportunistic script-kiddies through state-sponsored APTs), with attribution performed via TTPs, infrastructure patterns, and targeting behaviour.

### Semantic Classification

### Content

## Definition

A **Threat Actor** is an individual, group, organization, or nation-state with the intent, capability, and opportunity to exploit vulnerabilities and conduct attacks against systems, networks, or organizations.

## Threat Actor Taxonomy

### By Motivation

#### Financial

- **Cybercriminals**: Profit-driven attacks (ransomware, theft, fraud)
- **Organized Crime**: Sophisticated criminal enterprises
- **Fraud Operators**: Scams, Ponzi schemes, fake services
- **Insider Traders**: Exploiting information asymmetry

  #### Ideological

- **Hacktivists**: Political/social cause-driven attacks
- **Terrorists**: Disruption and intimidation campaigns
- **Extremists**: Ideologically motivated destruction
- **Protestors**: Virtual sit-ins and disruption

  #### Strategic

- **Nation-States**: Geopolitical and military objectives
- **Corporate Espionage**: Competitive intelligence gathering
- **Industrial Spies**: Stealing trade secrets and IP
- **Military Units**: Cyber warfare operations

  #### Personal

- **Disgruntled Insiders**: Revenge against employers
- **Griefers**: Causing disruption for entertainment
- **Trolls**: Harassment and social disruption
- **Script Kiddies**: Learning and reputation building

  ### By Sophistication

  #### Tier 1: Low Sophistication

- **Script Kiddies**: Using pre-built tools without understanding
- **Opportunistic Attackers**: Exploiting widely-known vulnerabilities
- **Automated Bots**: Mass scanning and exploitation
- **Characteristics**: High volume, low targeting, easily detected

  #### Tier 2: Moderate Sophistication

- **Skilled Hackers**: Understanding vulnerabilities and tools
- **Organized Crime Groups**: Coordinated multi-stage attacks
- **Hacktivist Collectives**: Planned ideological campaigns
- **Characteristics**: Selective targeting, moderate stealth, adaptable

  #### Tier 3: High Sophistication

- **Advanced Persistent Threats (APTs)**: Long-term stealthy campaigns
- **Nation-State Actors**: State-sponsored cyber operations
- **Elite Cybercrime Groups**: Highly skilled criminal enterprises
- **Characteristics**: Strategic targeting, advanced techniques, well-resourced

  #### Tier 4: Elite/Zero-Day

- **Nation-State Intelligence**: Top-tier government agencies
- **Zero-Day Brokers**: Discovering and selling unknown vulnerabilities
- **Advanced Research Teams**: Creating novel attack techniques
- **Characteristics**: Custom tools, previously unknown methods, near-undetectable

  ## Cross-Domain Actor Profiles

  ### Artificial Intelligence Domain

  #### Model Thieves

- **Profile**: Competitors or adversaries stealing proprietary AI models
- **Methods**: API abuse, membership inference, model extraction
- **Targets**: Commercial AI services, research organizations
- **Impact**: IP theft, competitive disadvantage, privacy violations

  #### Data Poisoners

- **Profile**: Actors manipulating training data or feedback systems
- **Methods**: Injecting malicious data, label flipping, backdoor insertion
- **Targets**: Public datasets, crowdsourced labeling, federated learning
- **Impact**: Model corruption, biased outputs, hidden backdoors

  #### Adversarial Researchers

- **Profile**: Ethical hackers or malicious actors testing model robustness
- **Methods**: Adversarial perturbations, prompt injection, jailbreaking
- **Targets**: LLMs, computer vision systems, autonomous decision systems
- **Impact**: Model failure, safety violations, unintended behavior

  ### Blockchain Domain

  #### Cryptocurrency Thieves

- **Profile**: Criminals stealing digital assets through exploits
- **Methods**: Smart contract exploits, private key theft, bridge hacks
- **Targets**: DeFi protocols, exchanges, individual wallets
- **Impact**: Financial loss, protocol insolvency, market instability

  #### 51% Attackers

- **Profile**: Well-resourced actors controlling consensus mechanisms
- **Methods**: Hash power concentration, validator coordination
- **Targets**: Smaller proof-of-work or proof-of-stake networks
- **Impact**: Double-spending, chain reorganization, network trust loss

  #### Front-Runners

- **Profile**: Traders exploiting transaction ordering for profit
- **Methods**: MEV extraction, sandwich attacks, transaction reordering
- **Targets**: DEX trades, NFT mints, time-sensitive transactions
- **Impact**: User value extraction, market inefficiency

  ### Robotics Domain

  #### Industrial Saboteurs

- **Profile**: Actors disrupting manufacturing or critical infrastructure
- **Methods**: Control system compromise, sensor manipulation, firmware attacks
- **Targets**: Factory automation, power grids, transportation systems
- **Impact**: Production loss, safety incidents, economic damage

  #### Robotics Researchers (Malicious)

- **Profile**: Individuals exploiting research robots for demonstrations
- **Methods**: Sensor spoofing, command injection, physical tampering
- **Targets**: Academic research labs, prototype systems
- **Impact**: Safety concerns, research disruption, reputation damage

  ### Metaverse Domain

  #### Virtual Griefers

- **Profile**: Individuals disrupting immersive social experiences
- **Methods**: Harassment, virtual property destruction, exploit abuse
- **Targets**: Virtual communities, social VR spaces, gaming environments
- **Impact**: User experience degradation, community exodus

  #### NFT/Property Thieves

- **Profile**: Criminals stealing valuable virtual assets
- **Methods**: Account compromise, smart contract exploits, phishing
- **Targets**: High-value virtual property, rare NFTs, virtual currencies
- **Impact**: Financial loss, market manipulation, trust erosion

  ### Telecommunications Domain

  #### Meeting Bombers (Zoombombers)

- **Profile**: Disruptors joining video conferences uninvited
- **Methods**: Shared link exploitation, weak authentication bypass
- **Targets**: Public meetings, educational sessions, corporate calls
- **Impact**: Disruption, harassment, privacy violations

  #### VoIP Fraudsters

- **Profile**: Criminals conducting toll fraud and service abuse
- **Methods**: PBX hacking, SIP trunk exploitation, caller ID spoofing
- **Targets**: Business phone systems, telecommunications providers
- **Impact**: Financial loss, service abuse, reputation damage

  ## Threat Actor Attribution

  ### Attribution Challenges

- **Anonymity Technologies**: VPNs, Tor, proxies obscuring origin
- **False Flags**: Deliberate misdirection and planted evidence
- **Infrastructure Sharing**: Multiple actors using same tools/servers
- **Proxy Actors**: State-sponsored groups operating under cover

  ### Attribution Indicators

- **Tactics, Techniques, Procedures (TTPs)**: Characteristic methods
- **Infrastructure**: Command and control server patterns
- **Targeting**: Victim selection and objectives
- **Timing**: Operational hours and campaign schedules
- **Language**: Code comments, malware strings, communications
- **Capabilities**: Tool sophistication and technical knowledge

  ## Defensive Strategies by Actor Type

  ### Against Low-Sophistication Actors

- **Basic Security Hygiene**: Patching, strong passwords, MFA
- **Network Filtering**: Blocking known bad IPs and signatures
- **User Awareness**: Training against common attacks
- **Automated Detection**: IDS/IPS with signature-based detection

  ### Against Moderate-Sophistication Actors

- **Defense in Depth**: Multiple security layers
- **Behavioral Analysis**: Detecting anomalous activities
- **Threat Intelligence**: Leveraging known actor TTPs
- **Incident Response**: Prepared procedures for breach containment

  ### Against High-Sophistication Actors

- **Advanced Threat Hunting**: Proactive adversary search
- **Zero Trust Architecture**: Assume breach mentality
- **Deception Technologies**: Honeypots and canary tokens
- **Intelligence Sharing**: Collaboration with peers and government
- **Continuous Monitoring**: 24/7 SOC operations

  ### Against Nation-State Actors

- **Assume Breach**: Plan for compromise inevitability
- **Critical Asset Isolation**: Air-gapped sensitive systems
- **Supply Chain Security**: Rigorous vendor vetting
- **Government Cooperation**: CISA, FBI, IC coordination
- **Resilience Focus**: Recovery over prevention

  #### Related Concepts

- [[Attack Vector]]: Methods threat actors use to exploit systems
- [[Vulnerability]]: Weaknesses threat actors exploit
- [[Resilience]]: System ability to withstand threat actor activities
- [[Security]]: Overall framework for defending against threat actors
- [[Risk]]: Potential impact of threat actor success

  #### References

- MITRE ATT&CK: Threat actor tactics and techniques catalog
- Diamond Model of Intrusion Analysis: Threat actor analysis framework
- Lockheed Martin Cyber Kill Chain: Attack lifecycle model
- Mandiant APT Reports: Nation-state threat actor intelligence
- CISA: Government threat actor alerts and advisories

  ### Relationships

### Provenance

