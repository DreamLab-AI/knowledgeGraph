Organisational learning is the process by which a group, team or enterprise creates, retains and transfers knowledge to improve its collective performance over time. It encompasses how experience is encoded into routines, how lessons from success and failure are shared, and how the organisation adapts its mental models and practices in response. As a discipline it bridges knowledge management, continuous improvement and organisational culture.

- Organisational learning is how a group creates, retains and transfers knowledge to improve collective performance over time. It is a discipline within [[Knowledge Management]] that enables [[Continuous Improvement]] and [[Knowledge Transfer]], depending on healthy [[Knowledge Sharing]] and structured [[Feedback Loop]] practices.

### Overview

- Organisations learn not only through the individuals within them but through shared routines, processes, tools and culture that outlast any single person.
- Learning operates at multiple levels: individual insight, team practice, and embedded organisational memory codified in procedures, documentation and systems.
- A central distinction is between single-loop learning, which corrects actions within existing assumptions, and double-loop learning, which questions and revises the underlying assumptions themselves.
- The learning organisation is one deliberately designed to acquire and act on knowledge faster than competitors, treating reflection and adaptation as core capabilities.

### Mechanisms

- Capturing tacit knowledge held in people's experience and converting it into explicit, shareable form.
- After-action reviews and blameless retrospectives that extract lessons from both incidents and successes.
- Feedback loops connecting outcomes back to decisions so that practice adapts to evidence.
- Knowledge repositories, communities of practice and mentoring that diffuse expertise across the organisation.

### Applications

- Learning from operational events through [[Incident Reporting]] and structured review.
- Onboarding and skill development via [[Training]] grounded in captured organisational knowledge.
- Sustaining [[Continuous Improvement]] cycles in engineering, manufacturing and service delivery.
- Strengthening distributed [[Collaboration]] by making knowledge accessible across time zones and teams.

### Key aspects

- Psychological safety is a precondition: people share lessons from failure only when it is safe to do so.
- Knowledge decays and must be actively maintained, curated and re-validated.
- Culture and incentives determine whether learning is genuinely embedded or merely performed.

### Provenance

