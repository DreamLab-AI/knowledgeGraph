Line balancing is the process of assigning work to stations based upon the demand.[^1]

In the academic literature the standard form is the simple assembly line balancing problem, known as SALBP. A preprint by Moreira and Costa describes the setting: products are assembled by the successive execution of tasks in workstations, each task has an execution time and precedence relationships with other tasks, and the problem concerns allocating tasks to workstations while respecting the partial ordering of the tasks.[^2] Castellucci and Costa say the main rationale behind assembly lines is the division of labour, done by partitioning the tasks among a number of workers or workstations.[^3]

## Cycle time and the two versions

A journal article from the University of North Carolina Asheville defines cycle time as the maximum amount of time that can be allowed to perform any specific task on any one workstation, not the time to complete a task but the time required between units, calculated as total time available divided by the demand for the period.[^1] The Moreira and Costa preprint states that the problem is known as SALBP-1 when the goal is to minimise the number of workstations m given a maximum allowed cycle time c, and SALBP-2 when the goal is to minimise c given a fixed m.[^2]

## Scope and distinctions

Lean literature calls the same ratio of available time to demand takt time, and an open textbook distinguishes cycle time as the actual rate of producing each unit from the calculated takt time.[^5][^4] The sources do not address the difference. See [[Takt Time]].

Both SALBP and its worker-assignment variant assume deterministic execution times for each task, so the line's throughput is dictated by the most loaded workstation, and the preprint authors add that the hypotheses of the simple problem are rarely valid in practical contexts.[^3] The journal article describes assembly line balancing algorithms as heuristic methods.[^1] Line balancing is part of [[Production Planning and Control]]; see also [[Mass Production]].

## What the sources do not establish

No source gives a single industry standard for the objective, and the preprints treat the topic as an optimisation problem rather than a shop-floor practice. The article offers a spreadsheet method for teaching rather than evidence of results in industry.[^1]

[^1]: University of North Carolina Asheville and Mars Hill University (Lovejoy-Henkel, Lee, Parsons and Yearout), Industrial and Systems Engineering Review 4(1), 2016, “Systematic Pedagogy to Line Balancing with EXCEL”. https://westpointpressjournals.westpoint.edu/index.php/iser/article/download/34/pdf_12/260
[^2]: arXiv (Moreira and Costa), “Simple heuristics for the assembly line worker assignment and balancing problem”. https://arxiv.org/pdf/1003.3676
[^3]: arXiv (Castellucci and Costa), “A new look at the bowl phenomenon”. https://arxiv.org/pdf/1211.6406
[^4]: Business LibreTexts (Introduction to Operations Management, NWTC), “6.5: Some important "Times" to be familiar with”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/06:_Process_Design/6.05:_Some_important_Times_to_be_familiar_with-
[^5]: Lean Enterprise Institute, “Takt Time (Lean Lexicon)”. https://www.lean.org/lexicon-terms/takt-time/

