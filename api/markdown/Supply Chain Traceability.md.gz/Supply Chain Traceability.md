Supply chain traceability is the tracing of goods, materials or components across the organisations in a supply chain, using identifiers and records of the events that happen to them.[^1][^2]

GS1 says its approach to enabling supply chain traceability is focused on open standards that provide visibility of objects relevant to supply chains.[^1] The core of its model is two concepts: critical tracking events, the actual events that happen to traceable objects during their lifecycle, such as receiving, transforming, packing, shipping and transporting, and key data elements, the pieces of data that describe instances of those events.[^1] EPCIS, GS1's data sharing standard, is described as enabling the capture and sharing of interoperable information about status, location, movement and chain of custody.[^3] See [[Critical Tracking Event]].

## Legal requirements

In the European Union, Regulation (EC) No 178/2002 requires that traceability of food, feed and substances intended to be incorporated into them be established at all stages of production, processing and distribution.[^2] In the United States, the FDA's Food Traceability Rule requires persons who manufacture, process, pack or hold foods on the Food Traceability List to maintain records containing key data elements associated with specific critical tracking events, and to provide information to the FDA within 24 hours or a reasonable agreed time.[^4]

## Sustainability use

The UN Global Compact guide describes traceability as a tool to assure and verify sustainability claims, and states that it is not a substitute for due diligence.[^5] See [[Supply Chain Due Diligence]] and [[Chain of Custody Model]].

## Scope and limits

This page covers traceability across a chain; the generic capability is [[Traceability]], and the identifiers that support it are at [[Traceability and Product Identification]]. None of the opened sources ties supply chain traceability to any particular technology, and none measures how much of a given chain is traceable in practice. These sources describe food regulation most fully; other sectors are not covered.

[^1]: GS1, Global Traceability Standard Release 2.0 (ratified August 2017), “GS1 Global Traceability Standard”. https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard
[^2]: European Parliament and Council of the European Union, Regulation (EC) No 178/2002 of 28 January 2002, “Regulation (EC) No 178/2002 of the European Parliament and of the Council laying down the general principles and requirements of food law”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32002R0178
[^3]: GS1, “EPCIS & CBV”. https://www.gs1.org/standards/epcis
[^4]: U.S. Food and Drug Administration, “FSMA Final Rule on Requirements for Additional Traceability Records for Certain Foods”. https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-requirements-additional-traceability-records-certain-foods
[^5]: United Nations Global Compact and BSR, 2014, “A Guide to Traceability: A Practical Approach to Advance Sustainability in Global Supply Chains”. https://www.unglobalcompact.org/docs/issues_doc/supply_chain/Traceability/Guide_to_Traceability.pdf

