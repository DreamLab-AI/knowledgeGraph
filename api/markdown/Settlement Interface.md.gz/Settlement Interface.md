
A settlement interface is a description of the technical and semantic requirements for settling a payment. The Agent Ontology declares it as `SettlementInterface`.[^1]

A [[Payment Intent]] reaches it through the property `hasSettlementInterface`. Two string properties describe it: `acceptedMethod`, naming a payment method the interface accepts, and `category`, which classifies the interface. Neither carries a closed list of values, so methods and categories are named in whatever terms the settling party uses.

The class separates the statement of intent, which says who pays whom and how much, from the means by which payment is completed. A payee can therefore publish what it accepts without committing to any one payment rail.

visionGraph places Settlement Interface under [[Settlement]], the general concept of completing a transfer, and relates it to [[Payment Protocol]], where the concrete protocols are collected.

[^1]: Semantic Agent Communication Community Group, “Payment Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/payment.ttl

