
An organisational agent is an agent that is an organisation. The Agent Ontology declares it as `Organization` in its agent module, a subclass of the core `Agent`, with the comment "An agent that is an organization."[^1]

The ontology gives `Organization` no properties of its own. Everything it can say about it comes from [[Agent]], including identity, profile, capabilities, delegations in which it is a party, and the tasks and actions attributed to it. The sibling class is [[Human Agent]], declared in the same module.

The schema.org mapping module aligns `Organization` with `schema:Organization` using `rdfs:subClassOf`.[^2]

Because the ontology places organisations in the same hierarchy as people and software, an organisation can be named as the granting or receiving party of a delegation in the same way as any other agent. The agent module's `PurposeRole` class also carries an `owner` string, which is one place an organisation may appear as text, though the ontology does not link that string to this class.[^1]

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl
[^2]: Semantic Agent Communication Community Group, “Agent Ontology to Schema.org Mapping” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/schema-org-mapping.ttl

