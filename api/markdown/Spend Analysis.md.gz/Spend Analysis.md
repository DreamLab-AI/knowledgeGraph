Spend analysis is the examination of what an organisation spends, on what and with whom, as an evidence base for procurement decisions.[^1][^2]

The Making Spend Matter guide, produced by a European city network under the URBACT programme, calls spend analysis a powerful tool that gives places and organisations an evidence base to understand how they carry out public procurement and how their economy works, using facts and data to provide insights into a specific situation in time. It says spend analysis is not the end goal in itself but a starting point for becoming more strategic in public procurement.[^1] The Office of Federal Procurement Policy's notice ties spend analysis to strategic sourcing: critically analysing an organisation's spending and using the information to make business decisions about acquiring commodities and services.[^2]

## Categorising spend

The UK Cabinet Office Common Areas of Spend definitions say the spend captured should be the total value of payments made to third-party suppliers for goods and services, and that it should be captured against UNSPSC or CPV level 4 coding for product groups so that it can be mapped to a procurement categorisation structure.[^3]

It says procurement spend excludes payroll, non-cash expenditure such as depreciation, grants and benefit payments, accruals and receipts, but includes capital expenditure.[^3]

See [[Strategic Sourcing]], [[Category Management]] and [[Indirect Procurement]].

## What the sources do not establish

No source opened gives a technical definition of spend analysis or a standard method, and the sources are public-sector guidance, so the page does not describe data cleansing or the tools used.[^1][^3][^2]

[^1]: Making Spend Matter network (URBACT III, European Regional Development Fund), Preston City Council copy, “Basic Spend Analysis Guide: A step by step methodology (September 2020)”. https://www.preston.gov.uk/media/4590/Spend-analysis-guide/pdf/Spend_Analysis_Guide_MakingSpendMatter_Sep2020.pdf?m=637399344878130000
[^2]: Office of Federal Procurement Policy, Federal Register, 7 October 2016, “Category Management”. https://www.federalregister.gov/documents/2016/10/07/2016-24054/category-management
[^3]: UK Cabinet Office, Common Areas of Spend definitions (Crown copyright), “Common Areas of Spend Procurement Standard Definition Release 9 v1”. https://assets.publishing.service.gov.uk/media/607e85b0d3bf7f01343a06e0/Procurement_CAS_Definition_Release_9_v1__2_.pdf

