
An agent output specification describes what an agent produces as output, declared as `OutputSpec` in the agent module of the Agent Ontology.[^1] The Agent Ontology declares the class without a definition; this one follows from its position. visionGraph places it under [[Data Schema]] and as part of an [[Agent Operational Profile]], which reaches it through `output`.

It is a declared contract for the data an agent returns, so a caller can know what to expect before invoking the agent. The schema language is chosen by the implementer. What an agent returns in one run is an [[Agent Artefact]]; the specification describes the form such artefacts take, not any particular one.

It mirrors [[Agent Input Specification]], and the two together with the [[Agent Trigger]] make up the operational profile. The [[Output State]] of an [[Execution Context]] records the actual output of a single run.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

