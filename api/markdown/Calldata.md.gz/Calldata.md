Calldata is the read-only, immutable byte array supplied with a transaction or message call on the Ethereum Virtual Machine, carrying the function selector and ABI-encoded arguments that tell a smart contract what to execute. Because it lives outside contract storage and is comparatively cheap to include, calldata is the primary channel through which external inputs reach contracts. It is especially significant for rollups, which post compressed transaction batches as calldata to the base layer to inherit its data availability and security.

### Overview

- When an account or contract invokes another contract, the input it sends is calldata: a packed sequence beginning with a four-byte function selector followed by ABI-encoded parameters.
- Calldata is immutable within a call and cannot be written to; the EVM exposes opcodes to read its size and copy slices into memory. It is cheaper than storage and, historically, cheaper per byte than other persistent data channels.
- For Layer 2 scaling, optimistic and zero-knowledge rollups publish their compressed transaction data as calldata on Ethereum, so anyone can reconstruct L2 state and challenge or verify it.
- This made calldata the dominant cost component for rollups, motivating EIP-4844 blob transactions as a cheaper, dedicated data channel.

### Mechanisms

- The leading four-byte selector identifies which contract function to dispatch.
- ABI encoding lays out arguments in a deterministic, padded layout the contract decodes.
- EVM opcodes read calldata size and copy regions into memory for processing.
- Gas is charged per byte, with zero bytes cheaper than non-zero bytes.

### Applications

- Encoding function calls and arguments for every contract interaction.
- Posting compressed rollup batches to the base layer for data availability.
- Passing immutable parameters to view and pure functions efficiently.
- Carrying signed messages and proofs into verifier contracts.

### Provenance

