An intergovernmental trade organisation is an international organisation, established by governments, that sets or administers rules for trade or transport. No opened source defines the combined term, so the page builds it from the definition of an international organisation. The UN International Law Commission defines an international organisation as one established by a treaty or other instrument governed by international law and possessing its own international legal personality, and adds that international organisations may include as members, in addition to States, other entities.[^1]

## Examples in the sources

The World Trade Organization says that it is run by its member governments.[^2] The International Maritime Organization describes itself as the United Nations specialized agency with responsibility for the safety and security of shipping and the prevention of marine and atmospheric pollution by ships.[^3] The United Nations describes the specialized agencies as autonomous international organizations working with the United Nations, and lists the IMO among them with its headquarters in London.[^4]

This vault also holds the [[World Customs Organization]] and the [[International Maritime Organization]] under this role, and the [[World Trade Organization]] is the related organisation for trade rules.

## Scope and distinctions

This class differs from a [[Trade Body]], whose members are businesses. It also differs from a private standards body: the ICC, for instance, is described as a business organisation, not a body of governments.[^5]

## What the sources do not establish

The ILC definition is given for the purposes of its draft articles on the responsibility of international organizations, so it is a definition for a particular legal purpose. The sources opened here do not say which international organisations count as trade organisations, or whether an organisation that is not a UN agency, such as the WTO, should be described the same way as one that is. No source gives the number of such bodies.[^1][^4]

[^1]: United Nations International Law Commission, “Draft articles on the responsibility of international organizations” (2011). https://legal.un.org/ilc/texts/instruments/english/draft_articles/9_11_2011.pdf
[^2]: World Trade Organization, “Who we are”. https://www.wto.org/english/thewto_e/whatis_e/who_we_are_e.htm
[^3]: International Maritime Organization, “Introduction to IMO”. https://www.imo.org/en/About/Pages/Default.aspx
[^4]: United Nations, “UN System”. https://www.un.org/en/about-us/un-system
[^5]: International Chamber of Commerce, About ICC page. https://iccwbo.org/about-us/

