Warehousing and distribution covers the storage of goods in dedicated facilities and the steps taken to move and store a product from the supplier stage to the customer stage of a supply chain.[^1][^3]

A review of operations and supply chain management defines warehousing as the intermediate storage of goods in a dedicated facility, and gives its fundamental purpose as decoupling the time and place of production or supply from the time and place of consumption between successive supply chain stages.[^1] Georgia Tech's open textbook describes warehouses as the points in the supply chain where product pauses, however briefly, and is touched.[^2] A Northwestern University paper defines distribution as the steps taken to move and store a product from the supplier stage to a customer stage.[^3]

## Reasons for warehouses

The Georgia Tech text lists uses that include consolidating product to reduce transportation costs and provide customer service. With many vendors and many stores, direct shipment means many small shipments at less-than-truckload rates, whereas an intermediate aggregator such as a distribution centre or crossdock means fewer, larger shipments.[^2] The review adds that e-commerce and omnichannel retailing have turned warehouses from a marginal element into a mission-critical supply chain stage.[^1]

## Scope

This branch covers [[Warehouse Facility Type]], [[Warehouse Operation]], [[Warehouse Storage System]] and [[Distribution Strategy]]. Last-mile delivery is covered at [[Last-Mile Delivery]], and stock policy at [[Inventory Management]]. Warehouse automation is covered at [[Warehouse Automation]] and robotics at [[Warehouse Robotics]].

## What the sources do not establish

No source gives a count of facilities or a standard boundary between a warehouse and a distribution centre. A US statistical committee records that the term distribution centre is applied to very different establishments.[^4] See [[Distribution Centre]].

[^1]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^3]: Northwestern University, Kellogg School of Management (Sunil Chopra), “Designing the Distribution Network in a Supply Chain”. https://transportation.northwestern.edu/docs/research/core-topics/logistics-and-supply-chain-management/Chopra_DistributionSupplyChain.pdf
[^4]: US Census Bureau, Economic Classification Policy Committee, “Recommendation for Classification of Distribution Centers in North American Industry Classification System (NAICS) Revisions for 2012”. https://www2.census.gov/library/reference/naics/federal-register/supporting/distribution_centers.pdf

