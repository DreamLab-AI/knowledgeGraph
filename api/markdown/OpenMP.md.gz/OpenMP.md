An open standard API for shared-memory parallel programming in C, C++, and Fortran, in which developers annotate sequential code with compiler directives (pragmas) such as parallel regions, work-sharing loops, and tasks, and the compiler and runtime distribute the work across threads. Governed by the OpenMP Architecture Review Board since 1997, the specification has grown from simple loop-level parallelism to encompass explicit tasking, SIMD vectorisation, and offloading to GPUs and other accelerators via target directives. Its incremental, directive-based model makes it the dominant intra-node parallelisation approach in scientific and high-performance computing, commonly paired with MPI for communication between nodes.

### Semantic Classification

### Content

## Definition

**OpenMP** (Open Multi-Processing) is the de facto standard for exploiting multicore, shared-memory hardware from C, C++, and Fortran. Its distinguishing idea is incrementality: rather than rewriting a program around threads, the developer marks hot loops and regions with directives — `#pragma omp parallel for` in C/C++, `!$omp` sentinels in Fortran — and a conforming [[Compiler]] generates the thread management, work distribution, and synchronisation. Code without OpenMP support simply ignores the pragmas and runs sequentially, so a single source tree serves both serial and parallel builds.

The execution model is fork-join over [[Shared Memory]]: a master thread forks a team at a parallel region, the team divides iterations or tasks between cores, and threads rejoin at an implicit barrier. Data-sharing clauses (`shared`, `private`, `firstprivate`, `reduction`) control which variables are replicated per thread and which are visible to all — the central discipline for avoiding data races. Later revisions added explicit tasking with dependencies (3.0, 4.0), `simd` directives for vectorisation, and `target` offloading that maps regions and data onto GPUs, taking the standard well beyond its loop-parallel origins; the OpenMP 6.0 specification (released November 2024) continues to refine accelerator and memory-management support.

OpenMP occupies the intra-node half of the classic HPC pairing: it parallelises within a single machine's cores, while the [[Message Passing Interface]] handles distributed-memory communication between nodes. The hybrid "MPI + OpenMP" pattern remains standard on supercomputers, and OpenMP alone powers a large share of multithreaded [[Scientific Computing]] codes, numerical libraries, and engineering simulations.

## Technical Details

- **Core constructs**: `parallel` (fork a team), `for`/`do` (work-share loops with `schedule(static|dynamic|guided)`), `sections`, `single`, `task`/`taskwait` with `depend` clauses, `critical`, `atomic`, `barrier`, and `reduction` for safe accumulation.
- **Runtime control**: `OMP_NUM_THREADS`, `omp_get_thread_num()`, nested parallelism, and processor affinity via `OMP_PLACES`/`OMP_PROC_BIND` — affinity tuning is often decisive for NUMA machines.
- **Implementations**: GCC (libgomp), LLVM/Clang (libomp), Intel oneAPI, NVIDIA HPC SDK, and Cray/AMD compilers; coverage of the newest offload features varies by vendor.
- **Trade-offs**: minimal code intrusion and excellent loop-level scaling on a node, but no distributed-memory story (that is MPI's role), and false sharing or race conditions remain the programmer's responsibility.

  ## Current Landscape

- **OpenMP 6.0 released at SC24 (14 November 2024)**: a major upgrade over 5.2 enacting 415 issues, headlined by free-agent threads (a logical thread pool where unassigned threads can execute tasks via a `threadset` clause), transparent tasks that extend where dependences may be expressed, a `taskgraph` directive for recorded/replayable task graphs, and loop-transformation directives (fusion, reversal, interchange).
- **Latest language support**: 6.0 adds full support for C23, C++23 and Fortran 2023, including C23/C++ attribute-style directive syntax, and removes features deprecated back in 5.0–5.2.
- **Implementation status**: first 6.0 features shipped in GCC 14 (full C23/C++23/Fortran 2023) and Intel oneAPI/ifx 2025.0 (e.g. the `groupprivate` directive and `interop` clause); coverage of the newest offload features still varies by vendor.
- **Ongoing evolution**: the ARB published OpenMP 6.0 errata and 6.0/6.0.1 examples in November 2025, plus Technical Report 14, the public-comment draft of OpenMP 6.1.

  **Sources**:

- https://www.openmp.org/home-news/openmp-arb-releases-openmp-6-0-for-easier-programming/
- https://www.openmp.org/specifications/
- https://www.openmp.org/articles/openmp-6/

### Provenance

