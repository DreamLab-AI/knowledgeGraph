Product provenance is the provenance of an individual product, meaning the recorded information about where it came from and what was done to it, and no source opened here defines the term, so the page combines a general definition of provenance with identification standards.[^1]

The W3C PROV data model defines provenance as information about entities, activities and people involved in producing a piece of data or thing, which can be used to form assessments about its quality, reliability or trustworthiness.[^1]

## Identifying the individual product

GS1's Global Traceability Standard says that instance-level identification, combining a product number with a serial number, makes it possible to identify each product instance individually, so that each can be tracked or traced individually.[^2] GS1 Digital Link is the standardised method for encoding identifiers along with batch numbers, serial numbers and expiry dates.[^3]

The Ecodesign for Sustainable Products Regulation defines a digital product passport as a set of data specific to a product, accessible by electronic means through a data carrier.[^4] A unique product identifier is a unique string of characters that identifies a product and enables a web link to the passport.[^4]

## Scope and distinctions

Product provenance is a narrower case of [[Supply Chain Provenance]], which concerns goods across a chain. The two pages overlap so closely that the sources opened do not separate them, and a merge is a question for the corpus owner. Related pages are [[Supply Chain Traceability]] and [[Traceability and Product Identification]].

None of the sources opened describes how a product's provenance is verified or what happens when records conflict. The ESPR text defines the passport but leaves its contents to delegated acts, which were not opened.

[^1]: World Wide Web Consortium, W3C Recommendation, 30 April 2013, “PROV-DM: The PROV Data Model”. https://www.w3.org/TR/prov-dm/
[^2]: GS1, Global Traceability Standard Release 2.0 (ratified August 2017), “GS1 Global Traceability Standard”. https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard
[^3]: GS1, “GS1 Digital Link”. https://www.gs1.org/standards/gs1-digital-link
[^4]: European Parliament and Council of the European Union, Regulation (EU) 2024/1781 of 13 June 2024, “Regulation (EU) 2024/1781 of the European Parliament and of the Council establishing a framework for the setting of ecodesign requirements for sustainable products”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1781

