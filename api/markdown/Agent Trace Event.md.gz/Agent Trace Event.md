
An agent trace event is a verifiable record linking an agent, an action and contextual constraints. This wording is the ontology's own definition of `TraceEvent`.[^1]

The class is declared in the core module. The property `recordedIn` links an `Action` to its trace record ("its verifiable trace record"), and the datatype property `timestamp` gives the date and time of the event. The delegation module reuses the class: its `recordedIn` property has a `Delegation` as domain and a `TraceEvent` as range, so an [[Agent Delegation]] can itself be logged.[^2]

The mechanism that makes a record verifiable, such as a signature or hash chain, is left to implementers. visionGraph places the class under [[Event]]: trace events are the entries of an [[Audit Trail]].

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Delegation Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/delegation.ttl

