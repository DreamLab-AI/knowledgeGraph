Air freight is freight carried by aircraft; the Glossary for transport statistics notes that air freight and air mail combined are sometimes referred to as air cargo.[^1]

Glossary entries define an all-freight and mail air service as a scheduled or non-scheduled air service performed by aircraft carrying revenue loads other than revenue passengers, that is freight and mail.[^1] Eurostat says the role of air transport in freight is less significant than in passenger transport, because aircraft are an expensive mode in terms of tonne-kilometres and only competitive for longer distances and relatively light high-value or perishable goods.[^2]

## Scale

In 2024, 14.3 million tonnes of freight and mail were transported by air in the EU, and extra-EU transport was 83.3% of the total.[^2] Air had 0.2% of EU freight transport performance in tonne-kilometres, 16 billion tonne-km, in each year from 2014 to 2024.[^3]

## Role in trade

An April 2009 briefing from the International Air Transport Association says the heavier, lower unit value bulk commodities and oil will always be shipped by sea or possibly land, and that some 30-35% of US exports by value were shipped by air with around 20-25% of imports arriving by air freight. It also notes a declining trend, with air freight tonne kilometres rising on average 2% a year less than world trade, together with a cycle.[^4] The briefing is more than ten years old and describes the United States.

## Scope and distinctions

Air Freight is a [[Freight Transport Mode]]. A related page is [[Unmanned Aerial Vehicle]].

## What the sources do not establish

Sources opened here give no current world share of air freight by volume or value, since the ICAO page and a current IATA release could not be opened. The EU figures are for freight and mail transported by air in the EU, and the US value shares are for 2009 and earlier.

[^1]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^2]: Eurostat, Statistics Explained, “Air freight transport statistics”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Air_freight_transport_statistics
[^3]: Eurostat, Statistics Explained, “Freight transport statistics - modal split”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Freight_transport_statistics_-_modal_split
[^4]: International Air Transport Association, economic briefing of April 2009 on air freight and world trade. https://www.iata.org/en/iata-repository/publications/economic-reports/air-freight-and-world-trade

