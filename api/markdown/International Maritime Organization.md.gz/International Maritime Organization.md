The International Maritime Organization (IMO) is the United Nations specialized agency with responsibility for the safety and security of shipping and the prevention of marine and atmospheric pollution by ships. That is the organisation's own description, and the United Nations lists the IMO among its specialized agencies, which it describes as autonomous international organizations working with the United Nations, with the IMO's headquarters in London.[^1][^2]

## History and aims

The IMO's own history page says the Convention establishing the Inter-Governmental Maritime Consultative Organization (IMCO) was adopted at the Geneva conference opened in February 1948, on 6 March 1948, and that the name was changed in 1982 to International Maritime Organization.[^3] The aims summarised in Article 1 of the Convention included providing machinery for co-operation among Governments in the field of governmental regulation and practices relating to technical matters of all kinds affecting shipping engaged in international trade.[^3]

## Role in the supply chain

The IMO describes itself as the global standard-setting authority for the safety, security and environmental performance of international shipping.[^1] It is an [[Intergovernmental Trade Organisation]] in this vault, and the pages on [[Ocean Carrier]] and [[Container Shipping]] cover the operations it regulates. The official spelling International Maritime Organization is kept as the title; International Maritime Organisation is an alias.

## What the sources do not establish

Its self-description as the global standard-setting authority is its own claim, and the sources opened give no independent assessment of its reach. They do not list the conventions the IMO administers in this vault's terms, and they give no member count or budget. The United Nations page is a general listing and describes the IMO only briefly.[^1][^2]

[^1]: International Maritime Organization, “Introduction to IMO”. https://www.imo.org/en/About/Pages/Default.aspx
[^2]: United Nations, “UN System”. https://www.un.org/en/about-us/un-system
[^3]: International Maritime Organization, “Convention on the International Maritime Organization”. https://www.imo.org/en/About/Conventions/Pages/Convention-on-the-International-Maritime-Organization.aspx

