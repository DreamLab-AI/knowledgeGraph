Supply chain master data is the shared reference data about the items, parties and locations that take part in a supply chain, held as one agreed record that other systems use.[^1][^2]

GS1's Global Traceability Standard defines master data as the single source of common business data used across all systems, applications and processes for an entire organisation.[^1] It says static master data typically exists to describe products, parties, locations and assets, and that master data about supply chain relations typically describes an organisation's suppliers and customers, specified by product category and location.[^1] A presentation hosted on the Interoperable Europe portal, with Gartner's definitions, describes master data as a consistent and uniform set of identifiers and attributes that describe the core entities of the enterprise and are used across multiple business processes.[^2] It defines master data management as a technology-enabled discipline in which business and IT work together to ensure the uniformity, accuracy, stewardship, semantic consistency and accountability of the enterprise's official, shared master data assets.[^2]

## Sharing between firms

GS1 describes its Global Data Synchronisation Network as the world's largest product data network, through which a company shares master product information by subscribing to a certified data pool.[^3] Its stated five-step flow is loading company data, registering it, subscribing to the seller's data pool, publishing the data and confirming receipt.[^4] See [[Global Trade Item Number]], [[Global Location Number]] and [[Product Information Management]].

## Scope and distinctions

Master data differs from the transactions that refer to it: GS1 separates static data and relation data from transaction data, which are recorded as a result of business transactions such as orders and invoices.[^1] See [[Master Data Management]] and [[Supply Chain Data]].

## What the sources do not establish

Both definitions are close but come from a standards body and a consultancy's slides. The sources do not set out data quality rules or governance models. The GDSN pages are GS1's own description of its network, with no independent evaluation or adoption figures.[^1][^2][^3][^4]

[^1]: GS1, “GS1 Global Traceability Standard”. https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard
[^2]: Dimitris Geragas, “The value and implications of Master Data Management (MDM) and metadata management” (presentation hosted on the Interoperable Europe portal, European Commission; slides carry Gartner 2015 definitions). https://interoperable-europe.ec.europa.eu/sites/default/files/event/attachment/presentation_by_dimitris_geragas_-_the_value_and_implications_of_master_data_management_mdm_and_metadata_management.pdf
[^3]: GS1, “GS1 Global Data Synchronisation Network (GS1 GDSN) - Services”. https://www.gs1.org/services/gdsn
[^4]: GS1, “How GS1 GDSN works”. https://www.gs1.org/services/gdsn/how-gdsn-works

