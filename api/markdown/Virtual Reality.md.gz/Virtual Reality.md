Virtual Reality (VR) is a fully immersive, computer-generated simulation technology that replaces the user's physical environment with an interactive three-dimensional world, experienced through head-mounted displays that deliver stereoscopic rendering, spatial audio, and six-degrees-of-freedom motion tracking. VR systems generate a sense of presence by maintaining sub-20 ms motion-to-photon latency, high-refresh-rate displays, and positional tracking of the user's head and hands. As a foundational modality within Extended Reality (XR), VR is architecturally distinguished from Augmented Reality by occluding the real world entirely rather than overlaying digital content upon it. Applications span entertainment, professional training, tele-presence collaboration, clinical therapy, and spatial computing platforms.

### Overview

- VR emerged from military flight simulators and Ivan Sutherland's 1968 "Sword of Damocles" prototype, reaching commercial viability in the 2010s with the Oculus Rift and maturing into stand-alone, inside-out-tracked headsets by the early 2020s.
- The defining perceptual criterion is **presence**: the user's brain accepts the simulated world as real, which requires low-latency rendering, accurate tracking, and coherent multisensory feedback.
- Modern consumer platforms (Meta Quest series, PlayStation VR2, Apple Vision Pro) embed all compute inside the headset, removing the requirement for an attached PC.
- Enterprise adoption accelerated for training, design review, and remote collaboration, where VR reduces physical risk and travel costs.
- The technology sits at the intersection of [[Computer Graphics]], [[Human-Computer Interaction]], cognitive psychology, and [[Spatial Computing]].

### Key Components

- **Head-Mounted Display (HMD)**
  - Delivers two offset images (one per eye) to create stereoscopic [[3D Model]] depth cues via micro-OLED, LCD, or pancake-lens optics.
  - Refresh rates of 90–120 Hz and sub-20 ms motion-to-photon latency are minimum thresholds for comfortable use. See [[Real-Time Rendering]].
- **[[Motion Tracking]]**
  - Inside-out tracking uses onboard cameras to compute headset pose via SLAM without external beacons.
  - [[Six Degrees of Freedom]] (6DoF) — three translational axes and three rotational — is required for natural locomotion and presence.
  - Hand tracking and controller tracking extend the input surface to natural gestures.
- **[[Spatial Audio]]**
  - Head-related transfer functions (HRTFs) spatialise sound to match visual geometry, reinforcing the sense of environment.
  - Acoustic room modelling and occlusion simulation contribute to realism.
- **[[Foveated Rendering]]**
  - [[Eye Tracking]] identifies the user's gaze point; full resolution is rendered only in that foveal region, reducing GPU load by up to 50%.
  - Enables photorealistic peripheral rendering without proportional compute cost.
- **[[Haptic Feedback]]**
  - Vibrotactile controllers, gloves, and full-body suits deliver tactile sensations aligned with virtual collisions and textures.
  - Haptics significantly increase training transfer and emotional engagement.
- **[[Physics Simulation]]**
  - Rigid-body, soft-body, and fluid dynamics engines provide physical plausibility for object interactions, collisions, and environmental effects.
  - Real-time physics must stay within per-frame budgets without disrupting rendering cadence.
- **Rendering Engines and Runtime**
  - [[Game Engine]] platforms (Unreal Engine, Unity) provide scene management, shader pipelines, and plugin ecosystems for VR content creation.
  - [[OpenXR]] is the cross-vendor API standard that abstracts hardware differences for developers.

### Applications and Use Cases

- **Entertainment and Gaming**
  - Room-scale and full-locomotion games exploit embodiment and agency in ways impossible on flat screens.
  - Social VR platforms create persistent shared spaces for avatar-mediated interaction.
- **Professional Training and Simulation**
  - [[Virtual Training Simulation]] for surgery, aviation, military, and emergency response delivers repeated high-fidelity rehearsal without physical risk.
  - Skills transfer measurably to real-world performance; failure modes can be practised safely.
- **[[Immersive Collaboration]]**
  - Distributed teams meet as avatars in shared virtual workspaces, manipulating 3D assets and spatial whiteboards.
  - VR collaboration platforms address the absence of spatial and gestural cues in video conferencing.
- **Architecture and Design**
  - Architects and product designers walk through 1:1 scale models before construction or manufacture, enabling ergonomic and aesthetic decisions impossible in CAD viewports.
  - Integration with [[Digital Twin]] streams allows live building data to be reviewed in context.
- **Clinical Therapy**
  - Exposure therapy for phobias, PTSD, and anxiety disorders uses VR to present controlled stimuli in a safe context.
  - Chronic pain management and motor rehabilitation are active clinical research areas.
- **Education**
  - Embodied learning in historical environments, molecular biology, and astronomy increases engagement and retention compared to video.
- **Remote Presence and Telepresence**
  - [[Presence and Telepresence]] research shows that high-quality VR links can convey social cues more effectively than video for complex collaborative tasks.

### Standards and Context

- **[[OpenXR]]** (Khronos Group, ratified 2019; v1.1 active) — cross-platform API unifying device abstraction for VR and AR runtimes. Adopted by Meta, Microsoft, Valve, and Sony.
- **WebXR Device API** (W3C) — browser-native access to XR hardware, enabling zero-install immersive web experiences without app-store distribution.
- **MPEG-I (ISO/IEC 23090)** — immersive video coding standards including 360-video (Part 2) and volumetric video (Part 5) for VR content delivery over networks.
- **IEEE VR** — flagship academic conference and standards forum for VR research, benchmarking, and best-practice dissemination.
- **ISO/IEC JTC 1/SC 24** — standardises computer graphics, image processing, and VR environment representations.
- **VESA DisplayHDR** — display certification relevant to HMD visual quality benchmarks.
- Regulatory considerations include health and safety guidelines for extended use, cybersickness mitigation, privacy rules for biometric gaze data, and age-gating for social VR platforms.

### Semantic Classification

### Current Landscape (2026)

- Apple refreshed the Vision Pro on 15 October 2025 with the M5 chip, a 120 Hz micro-OLED display and a Dual Knit Band, running visionOS 26; it held its 3,499 US dollar starting price before a rise to 3,699 on 25 June 2026, and remains a premium professional niche device.
- Meta continues to dominate consumer VR, controlling roughly 75 per cent of the headset market (IDC) largely via the 299 dollar Quest 3S and the Quest 3, both on Qualcomm's Snapdragon XR2 Gen 2; a Quest 4 on the newer 3nm Snapdragon XR4-class silicon is emerging for 2026-2027.
- The field broadened in 2026 with Samsung's Galaxy XR (circa 1,799 dollars), the first device shipping Google's Gemini-powered Android XR OS, the 107-gram Bigscreen Beyond 2, and Valve's confirmed Steam Frame for summer 2026.
- Standards consolidated around Khronos' OpenXR (version 1.1, April 2024, folding hand-tracking and scene-understanding extensions into core), now backed by 30-plus vendors, while W3C's WebXR reached Candidate Recommendation and became an Interop 2026 focus area for genuine cross-browser, install-free experiences.
- Regulation and safety frameworks matured: ISO/IEC 5927:2024 covers AR/VR safety and vection, the US Leadership in Immersive Technology Act of 2025 (H.R. 2321/S. 1106) proposes a Commerce advisory panel, and the FDA now recognises certain VR exposure-therapy platforms as reimbursable treatments.
- Market estimates for 2026 diverge widely, from Mordor Intelligence's 15.64 billion dollars to Fortune Business Insights' 26.71 billion, with the broader XR market around 10.64 billion and 40-plus per cent forecast CAGR to 2031.
- Open challenges as of 2026 include sub-12ms passthrough latency for convincing mixed reality, thermal build-up and cybersickness limiting session length, biometric-data privacy for eye and hand tracking (EU AI Act scrutiny), and a still-struggling social metaverse as Meta trims Horizon Worlds' in-headset creation tools.

### References

- 1. Wikipedia (2026). Apple Vision Pro. https://en.wikipedia.org/wiki/Apple_Vision_Pro
- 2. Mordor Intelligence (2026). Extended Reality (XR) Market Size and Share Analysis. https://www.mordorintelligence.com/industry-reports/extended-reality-xr-market
- 3. jacar.es (2026). XR, AR and VR in 2026: the honest state after the cycle. https://jacar.es/en/xr-ar-and-vr-in-2026-the-honest-state-after-the-cycle/
- 4. Hololight (2026). OpenXR vs OpenVR: The Enterprise Developer's Guide. https://hololight.com/news/openxr-vs-openvr
- 5. vr.org (2026). WebXR Is Finally Becoming a Real Cross-Browser Standard. https://vr.org/articles/webxr-interop-2026-cross-browser-standard
- 6. vr.org (2026). Upcoming VR Headsets 2026: New Releases and What's Coming Next. https://vr.org/upcoming-vr-headsets-2026

### Provenance

