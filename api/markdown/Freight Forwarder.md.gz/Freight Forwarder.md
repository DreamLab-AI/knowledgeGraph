A freight forwarder is a person or business that arranges the carriage of goods on behalf of a shipper or consignee, usually without operating the transport itself. The Industrial Ontologies Foundry records the GS1 wording: “The party that arranges the carriage of goods including connected services and/or associated formalities on behalf of the shipper (consignor) or consignee”.[^1]

## What forwarders do

The IOF ontology also quotes an APICS description of the forwarder as a “middle man” between the carrier and the organization shipping the product.[^1] HM Revenue and Customs describes freight forwarders as moving goods around the world for importers and arranging the clearing of goods through customs.[^2]

In United States maritime law an ocean freight forwarder is a person that, in the United States, dispatches shipments from the United States via a common carrier and books or otherwise arranges space for those shipments on behalf of shippers, and that processes the documentation or performs related activities incident to the shipments.[^3][^4] The Federal Maritime Commission requires such forwarders to hold a licence, and treats them as a separate kind of ocean transportation intermediary from non-vessel-operating common carriers (NVOCCs). An NVOCC holds itself out to the public to provide ocean transportation, issues its own house bill of lading or equivalent document, does not operate the vessels, and is a shipper in its relationship with the vessel-operating carrier.[^4]

## Where the sources differ

Sources do not use one meaning. The IOF, GS1 and Federal Maritime Commission wordings describe an agent acting for the shipper. The federal statute on interstate transportation defines a freight forwarder differently: a person holding itself out to the public to provide transportation of property for compensation that assembles and consolidates shipments, assumes responsibility for the transportation from the place of receipt to the place of destination, and uses a carrier for part of the transportation.[^5] The same statute lists the freight forwarder among the kinds of “carrier”.[^5] In this vault [[Freight Carrier]] and Freight Forwarder are separate roles under [[Logistics Service Provider]], although the statute treats a forwarder that assumes responsibility for carriage as a carrier.[^5][^4]

Consolidating shipments is one forwarder activity named in the statute; see [[Freight Consolidation]].[^5]

## What the sources do not establish

Definitions here come from the IOF ontology and from United States and United Kingdom official sources. The opened sources do not give the global industry body's own definition, and they give no figures on the number or size of forwarders.

[^1]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^2]: HM Revenue and Customs on GOV.UK, “Get someone to deal with customs for you”. https://www.gov.uk/guidance/appoint-someone-to-deal-with-customs-on-your-behalf
[^3]: Cornell Law School Legal Information Institute, “46 U.S. Code § 40102 - Definitions”. https://www.law.cornell.edu/uscode/text/46/40102
[^4]: US Federal Maritime Commission, “Ocean Transportation Intermediaries”. https://www.fmc.gov/resources-services/ocean-transportation-intermediaries/
[^5]: Cornell Law School Legal Information Institute, “49 U.S. Code § 13102 - Definitions”. https://www.law.cornell.edu/uscode/text/49/13102

