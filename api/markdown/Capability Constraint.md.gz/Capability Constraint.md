
A capability constraint is a set of "restrictions on the use of a capability, including safety, context limitations, or policy-bound execution gates". It is declared as `CapabilityConstraint` in the Agent Ontology's capability module.[^1]

An [[Agent Capability]] attaches constraints through `hasConstraint`. The constraint class has three string properties: `allowedContext`, the contexts in which execution is permitted; `prohibitedContext`; and `requiresPermission`. visionGraph places the class under [[Constraint]] and as a part of [[Agent Capability]].[^1]

A capability constraint limits what a capability may be used for. That is different from the [[Delegation Scope]], which limits what one agent has authorised another to do, and from the [[Execution Constraint]] that applies to a particular delegated execution.

[^1]: Semantic Agent Communication Community Group, “Capability Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/capability.ttl

