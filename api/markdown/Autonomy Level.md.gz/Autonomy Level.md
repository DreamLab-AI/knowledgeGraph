A graded classification (typically 0–5) quantifying the degree to which an agent perceives, decides, and acts without human intervention, ranging from fully manual operation through partial and conditional autonomy to full self-governance, with domain-specific scales for AI, robotics, blockchain DAOs, and multi-agent systems.

### Semantic Classification

### Content

## Definition

**Autonomy Level** quantifies the degree to which an [[Agent]] can:

- **Perceive** its environment independently
- **Decide** on actions without human input
- **Execute** actions without human approval
- **Adapt** to changing conditions autonomously
- **Recover** from failures without intervention

  ## Autonomy Spectrum

  ### Five-Level Classification (General Agents)

```
Level 0: No Autonomy (Manual)
  ↓
Level 1: Assisted (Human decides, agent executes)
  ↓
Level 2: Partial Autonomy (Agent suggests, human approves)
  ↓
Level 3: Conditional Autonomy (Agent acts, human monitors)
  ↓
Level 4: High Autonomy (Agent acts independently, human available)
  ↓
Level 5: Full Autonomy (Agent operates completely independently)
```

### Detailed Level Descriptions

#### Level 0: No Autonomy

- **Description**: Fully manual operation, agent is merely a tool
- **Human Role**: Makes all decisions and executes all actions
- **Agent Role**: None or passive execution only
- **Example**: Manual teleoperation of a robot

  #### Level 1: Driver Assistance

- **Description**: Agent provides assistance but human controls all actions
- **Human Role**: Maintains full control, receives agent suggestions
- **Agent Role**: Monitors environment, provides alerts and recommendations
- **Examples**:
- AI: Autocomplete suggestions
- BC: Transaction fee estimators
- RB: Lane departure warnings
- MV: Pathfinding hints
- TC: Workflow suggestions

  #### Level 2: Partial Autonomy

- **Description**: Agent can perform specific tasks, human approves major decisions
- **Human Role**: Monitors agent, approves critical actions
- **Agent Role**: Executes routine tasks, escalates edge cases
- **Examples**:
- AI: Email filters (user trains spam detector)
- BC: Automated trading with approval thresholds
- RB: Adaptive cruise control
- MV: NPC patrol routes with scripted behaviors
- TC: Document routing with human approval gates

  #### Level 3: Conditional Autonomy

- **Description**: Agent handles most situations, human intervenes when requested
- **Human Role**: Available for edge cases, monitors alerts
- **Agent Role**: Autonomous operation with exception handling
- **Examples**:
- AI: Chatbots with human escalation
- BC: DAO voting with quorum requirements
- RB: Autonomous vehicles (highway only)
- MV: Dynamic quest generation with oversight
- TC: Automated workflows with audit logs

  #### Level 4: High Autonomy

- **Description**: Agent operates independently in defined domains
- **Human Role**: Sets goals and constraints, reviews outcomes
- **Agent Role**: Full autonomy within operational design domain
- **Examples**:
- AI: Personal AI assistants (scheduling, email)
- BC: Fully automated smart contracts
- RB: Warehouse robots, delivery drones
- MV: Advanced NPC companions
- TC: Multi-agent coordination without human coordination

  #### Level 5: Full Autonomy

- **Description**: Agent operates completely independently across all domains
- **Human Role**: None (may set high-level goals)
- **Agent Role**: Complete self-governance
- **Examples**:
- AI: Hypothetical AGI (not yet achieved)
- BC: Fully autonomous DAOs
- RB: General-purpose humanoid robots
- MV: Sentient NPCs (fictional)
- TC: Self-organizing agent networks

  ## Domain-Specific Autonomy Levels

  ### Artificial Intelligence (AI)

  **SAE-Inspired AI Agent Levels**:

  **Examples**:

- **Level 1**: GitHub Copilot suggests code
- **Level 2**: ChatGPT generates content, human edits
- **Level 3**: LangChain agents with human approval nodes
- **Level 4**: AutoGPT, BabyAGI (limited domains)
- **Level 5**: Not yet achieved

  ### Blockchain (BC)

  **DAO Governance Autonomy**:
  ```solidity
  enum DAOAutonomyLevel {
  Manual,           // Multisig wallet (human approves all)
  Assisted,         // Proposal templates
  Supervised,       // Token voting required
  Conditional,      // Automatic execution above quorum
  HighAutonomy,     // Autonomous contracts with parameters
  FullAutonomy      // Self-evolving smart contracts
  }
  ```

  **Examples**:

- **Level 0**: Multisig wallets (3-of-5 approval)
- **Level 1**: DAO voting tools (Snapshot)
- **Level 2**: Token-weighted voting (Compound)
- **Level 3**: Automatic execution after vote (MakerDAO)
- **Level 4**: Algorithmic monetary policy (Ampleforth)
- **Level 5**: Fully autonomous DAOs (future goal)

  ### Robotics (RB)

  **SAE J3016 Levels (Autonomous Vehicles)**:
  ```
  Level 0: No Automation
  Level 1: Driver Assistance (cruise control, lane keeping)
  Level 2: Partial Automation (hands off, eyes on)
  Level 3: Conditional Automation (hands off, eyes off in some situations)
  Level 4: High Automation (no driver needed in defined areas)
  Level 5: Full Automation (no driver needed anywhere)
  ```

  **General Robotics Autonomy**:

- **Level 0**: Remote teleoperation (surgical robots)
- **Level 1**: Assisted operation (power steering, stabilization)
- **Level 2**: Supervised autonomy (obstacle detection, human confirms)
- **Level 3**: Conditional autonomy (warehouse robots with human oversight)
- **Level 4**: High autonomy (delivery robots in mapped areas)
- **Level 5**: Full autonomy (hypothetical general-purpose robots)

  ### Metaverse (MV)

  **NPC Autonomy Levels**:
  ```javascript
  const NPCAutonomyLevel = {
  SCRIPTED: 0,           // Fixed behavior trees
  REACTIVE: 1,           // Respond to player actions
  GOAL_ORIENTED: 2,      // Pursue objectives
  ADAPTIVE: 3,           // Learn from player behavior
  EMERGENT: 4,           // Complex interactions with world
  SENTIENT: 5            // Fully autonomous (sci-fi)
  };
  ```

  **Examples**:

- **Level 0**: Minecraft villagers (fixed trades)
- **Level 1**: Skyrim NPCs (scripted schedules)
- **Level 2**: The Sims (goal-based behavior)
- **Level 3**: Shadow of Mordor Nemesis system
- **Level 4**: Red Dead Redemption 2 NPCs
- **Level 5**: Westworld-style hosts (fictional)

  ### Trusted Collaboration (TC)

  **Multi-Agent Coordination Autonomy**:
  ```python
  class CollaborationAutonomyLevel(Enum):
  MANUAL = 0          # Human coordinates all agents
  ASSISTED = 1        # System suggests coordination
  SUPERVISED = 2      # Agents coordinate, human approves
  CONDITIONAL = 3     # Agents coordinate within rules
  HIGH = 4            # Agents self-organize
  FULL = 5            # Fully emergent organization
  ```

  **Examples**:

- **Level 0**: Email threads (manual coordination)
- **Level 1**: Shared calendars (suggested meeting times)
- **Level 2**: Workflow automation (Zapier with approval steps)
- **Level 3**: Multi-agent systems with policies
- **Level 4**: Swarm robotics, autonomous drone fleets
- **Level 5**: Self-organizing agent economies (theoretical)

  ## Measuring Autonomy

  ### Quantitative Metrics

  #### Human Intervention Frequency
  ```
  Autonomy Score = 1 - (Interventions / Total Actions)

  Example:
  - 1000 actions taken
  - 10 human interventions
  - Autonomy Score = 1 - (10/1000) = 0.99 (99% autonomous)
  ```

  #### Decision Complexity
  ```
  Complexity Score = Σ (Decision Branches × Uncertainty)

  Higher complexity with autonomy = Higher autonomy level
  ```

  #### Operational Design Domain (ODD)
  ```
  ODD Score = (Handled Scenarios / Total Scenarios)

  Broader ODD at same autonomy = Higher capability
  ```

  ### Qualitative Dimensions

  #### Sheridan Scale (10 Levels)
  1. Computer offers no assistance
  2. Computer suggests alternatives
  3. Computer selects one alternative and executes if human approves
  4. Computer executes if human approves, or
  5. Computer allows human a restricted time to veto
  6. Computer executes automatically, then informs human
  7. Computer informs human only if asked
  8. Computer informs human only if it decides to
  9. Computer decides and acts autonomously, ignoring human
  10. Computer decides everything and acts autonomously

  ## Cross-Domain Autonomy Patterns

  ### Autonomy Dependencies

  ### Domain Comparisons

| Aspect | AI | BC | RB | MV | TC |
|--------|----|----|----|----|-----|
| **Current Max** | Level 3-4 | Level 3-4 | Level 3-4 | Level 4 | Level 3-4 |
| **Constraint** | Alignment | Consensus | Safety | Realism | Trust |
| **Enabler** | LLMs | Smart contracts | Sensors | Game engines | Protocols |
| **Bottleneck** | General reasoning | Scalability | Physical world | Compute | Coordination |

## Autonomy and Other Concepts

### Relationship with Goals

- **Low Autonomy**: Human specifies goals explicitly and frequently
- **High Autonomy**: Agent infers or generates goals from high-level directives

  ### Relationship with Learning

- **Low Autonomy**: Fixed behavior, no learning
- **High Autonomy**: Continuous learning and adaptation

  ### Relationship with Trust

- **Low Autonomy**: Low trust requirements (human verifies)
- **High Autonomy**: High trust requirements (agent acts independently)

  ## Implementation Considerations

  ### Choosing Appropriate Autonomy Level

  **Factors to Consider**:
  1. **Safety Criticality**: Higher risk → Lower autonomy
  2. **Environment Complexity**: More complex → May need higher autonomy
  3. **Task Repetitiveness**: Repetitive → Benefits from higher autonomy
  4. **Cost of Errors**: High cost → Lower autonomy
  5. **Human Availability**: Low availability → May need higher autonomy

  **Decision Framework**:
  ```python
  def select_autonomy_level(task):
  score = 0

  # Add points for autonomy enablers
  if task.is_repetitive: score += 2
  if task.environment_is_structured: score += 2
  if task.human_unavailable: score += 1

  # Subtract points for autonomy barriers
  if task.is_safety_critical: score -= 3
  if task.has_legal_implications: score -= 2
  if task.requires_creativity: score -= 1
  if task.is_high_stakes: score -= 2

  # Map score to level
  if score < 0: return AutonomyLevel.LEVEL_1
  elif score < 3: return AutonomyLevel.LEVEL_2
  elif score < 5: return AutonomyLevel.LEVEL_3
  elif score < 7: return AutonomyLevel.LEVEL_4
  else: return AutonomyLevel.LEVEL_5
  ```

  ### Gradual Autonomy Increase
  ```python
  class GradualAutonomyAgent:
  def __init__(self):
      self.autonomy_level = AutonomyLevel.LEVEL_1
      self.performance_history = []

  def evaluate_performance(self):
      # Track success rate, error rate, user satisfaction
      if self.should_increase_autonomy():
          self.autonomy_level = min(self.autonomy_level + 1, 5)
      elif self.should_decrease_autonomy():
          self.autonomy_level = max(self.autonomy_level - 1, 1)

  def should_increase_autonomy(self):
      return (self.success_rate > 0.95 and
              self.error_rate < 0.01 and
              self.user_trust > 0.8)
  ```

  ## Challenges and Risks

  ### Autonomy-Related Risks

  #### Technical Risks

- **Misalignment**: Agent goals diverge from human intent
- **Unpredictability**: Emergent behaviors in complex environments
- **Brittleness**: Failure in out-of-distribution scenarios
- **Escalation**: Small errors compound into major failures

  #### Ethical and Legal Risks

- **Accountability**: Who is responsible for autonomous agent actions?
- **Transparency**: Can we explain why the agent acted?
- **Fairness**: Do autonomous agents perpetuate biases?
- **Control**: Can we override or shut down autonomous agents?

  ### Mitigation Strategies
  1. **Bounded Autonomy**: Limit operational design domain
  2. **Human-in-the-Loop**: Require approval for critical actions
  3. **Monitoring and Logging**: Track all agent decisions
  4. **Kill Switches**: Emergency stop mechanisms
  5. **Gradual Rollout**: Increase autonomy incrementally
  6. **Formal Verification**: Prove safety properties
  7. **Diverse Testing**: Extensive simulation and red-teaming

  ## Future Trends

  ### Increasing Autonomy

- **AI**: Progress toward Level 4-5 agents in narrow domains
- **BC**: More sophisticated DAOs with adaptive governance
- **RB**: Widespread Level 4 autonomous vehicles
- **MV**: NPCs with believable, emergent personalities
- **TC**: Self-organizing multi-agent systems

  ### Research Frontiers

- **Safe AGI**: Achieving Level 5 AI autonomy safely
- **Decentralized Autonomy**: Blockchain-based agent coordination
- **Explainable Autonomy**: Transparent autonomous decision-making
- **Human-Agent Teaming**: Optimal division of labor

  ## Relationships

  ### Parent Concepts

- [[Agent Property]] - Broader category of agent characteristics

  #### Related Concepts

- [[Agent]] (DT-1008) - Entity exhibiting autonomy
- [[Goal]] (DT-1010) - What autonomous agents pursue
- [[BDI Model]] (DT-1012) - Architecture for autonomous reasoning
- [[Human in the Loop]] - Counterpoint to full autonomy
- [[Trust]] - Required for accepting agent autonomy
- [[Alignment]] - Ensuring autonomous agents serve human values

  ## Best Practices

  ### For Designers
  1. **Start Low**: Begin with minimal autonomy, increase gradually
  2. **Clear Boundaries**: Define operational design domain explicitly
  3. **Fallback Plans**: Design for graceful degradation
  4. **Transparency**: Log all autonomous decisions
  5. **User Control**: Allow users to adjust autonomy level

  ### For Users
  1. **Understand Limits**: Know what autonomy level means
  2. **Monitor Initially**: Watch agent behavior closely at first
  3. **Provide Feedback**: Help agents learn appropriate autonomy
  4. **Maintain Oversight**: Don't abdicate responsibility completely
  5. **Test Boundaries**: Verify agent behavior at edge cases

  ## Applications

  ### Cross-Domain Scenarios
  1. **Autonomous Supply Chains**: Level 4 coordination across AI, BC, RB
  2. **Smart Cities**: Level 3-4 infrastructure management
  3. **Healthcare**: Level 2-3 diagnosis assistants, Level 4 robotic surgery
  4. **Finance**: Level 3-4 algorithmic trading with human oversight
  5. **Education**: Level 2-3 personalized tutoring agents

  #### References
  ### Standards and Guidelines

- SAE J3016 - Taxonomy for Autonomous Vehicles
- ISO 21448 - SOTIF (Safety Of The Intended Functionality)
- EU AI Act - Risk-based regulation by autonomy level

  ### Academic

- Parasuraman et al. - "Model for Types and Levels of Human Interaction"
- Sheridan & Verplank - "Human and Computer Control of Undersea Teleoperators"
- Beer et al. - "Toward a Framework for Levels of Robot Autonomy"

  ## Tags

  #autonomy-level #agent-property #cross-domain #independence #self-governance #human-in-the-loop #supervision #control #sae-levels #autonomous-systems #trust #safety #alignment #scalability

  ---

  **See Also**: [[Agent]], [[Goal]], [[Objective]], [[BDI Model]], [[Human in the Loop]], [[Trust]], [[Safety]]

### Provenance

