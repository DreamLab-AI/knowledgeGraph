Supply chain segmentation is a segmented approach to supply chain strategy, in which strategy is developed for segments of demand that have been identified by their characteristics.[^1]

The Warwick abstract of Godsell and colleagues says there are a plethora of theoretical ideas on the approach but a paucity of empirical data. It reports a case study of a fast moving consumer goods company and finds that demand profiling at item level, using volume and variability classifiers, was the primary driver of supply chain strategy. The authors also introduce “filters” as a way of turning the profiling results into a segmented strategy.[^1] The results rest on a single case, and the authors say it is the approach, not the specific solution, that transfers to other contexts.[^1]

In her Cranfield thesis, Godsell studied three contrasting supply chains: a small UK manufacturer of toiletry and detergent products, a logistics provider managing the European operations of an electronics manufacturer, and a UK retailer of health and beauty products.[^2] She concluded that traditional methods of segmentation, for example by sales value, do not provide a natural link to supply chain strategy and limit customer responsiveness, and that the challenge for management is to identify the right bases for segmentation.[^2] Her framework includes the concepts of contextual drivers, supply chain strategy drivers and internal mechanisms.[^2]

## Scope and distinctions

Fisher's earlier product-based matching is a related but different basis. He says a functional product with stable demand needs an efficient supply chain and an “innovative” product with volatile demand needs a responsive one, and that pairing them the other way round is a mismatch.[^3] See [[Efficient Supply Chain]] and [[Responsive Supply Chain]].

## What the sources do not establish

Evidence comes from one research group, and one of the two Godsell records is an abstract only. No source opened here gives a general definition of segmentation or a test for choosing the number of segments, so this page is thinly evidenced.[^1][^2]

[^1]: Janet Godsell and colleagues, International Journal of Physical Distribution and Logistics Management, 2011 (Warwick Research Archive record, abstract only), “Enabling supply chain segmentation through demand profiling”. https://wrap.warwick.ac.uk/id/eprint/57124
[^2]: Janet Godsell, Cranfield University thesis, 2008 (Cranfield repository record with abstract), “Developing Customer Responsive Supply Chain Strategy: An Empirical Investigation of the Relationship between Market Segmentation and Supply Chain Strategy”. https://dspace.lib.cranfield.ac.uk/handle/1826/3488
[^3]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf

