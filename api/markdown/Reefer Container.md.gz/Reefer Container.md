A reefer container is a temperature-controlled freight container: an insulated box that either carries its own refrigeration unit or relies on an external supply of cold air.[^1][^2]

The Container Handbook of the German Insurance Association says there are two basic types. Porthole containers, also called insulated or Conair containers, have no refrigeration unit of their own and rely on an external supply of cold air. Integral containers have an integrated refrigeration unit, which is generally powered by a three-phase electric supply.[^1] The handbook says the integral container is the prevalent type in use today, with the unit secured to the end wall.[^3] The US Department of Agriculture's Economic Research Service describes reefers as 20-foot or 40-foot boxes with their own refrigeration units, which use ship-generated power and can be carried alongside standard containers on general-purpose containerships.[^2]

## How an integral reefer works

Cold air flows through and around the goods in the container. When fruit is carried, air flows through the goods because fruit and vegetables generate respiration heat internally that has to be dissipated.[^4]

## Standards and markets

ISO 1496-2 specifies series 1 thermal containers for international exchange and for conveyance of goods by road, rail and sea. The 2008 edition is withdrawn and the catalogue page points to a 2018 edition as the new version.[^5] The European Commission has treated the transport of refrigerated goods as a possible narrower market, limited to reefer containers only or including conventional reefer vessels.[^6] The USDA paper, whose trade data run to fiscal 1999, puts the reefer share of refrigerated cargo at about 44 percent, about 22 million tons annually, and says controlled atmosphere technologies extended the range of perishables that can be shipped in reefers.[^2]

## Scope and distinctions

Reefer Container is a [[Shipping Container]] and serves [[Cold Chain Logistics]]. The ontology links it to [[Internet of Things]].

## What the sources do not establish

This page rests on a practitioner handbook and a historical government paper, with the standard and the Commission decision only naming the term. The sources give no current count or trade share of reefers, and the ISO 1496-2 text was not opened.

[^1]: German Insurance Association (GDV), “Container Handbook”, Section 7 Refrigerated containers. https://containerhandbuch.de/chb_e/wild/wild_07_00.html
[^2]: US Department of Agriculture, Economic Research Service (Coyle, Hall and Ballenger), “Transportation Technology and The Rising Share of U.S. Perishable Food Trade”. https://ers.usda.gov/media/12267/transportation-technology-and-the-rising-share-of-us-perishable-food-trade.pdf?v=40805
[^3]: German Insurance Association (GDV), “Container Handbook”, Section 7.2 Integral refrigerated containers. https://containerhandbuch.de/chb_e/wild/wild_07_02.html
[^4]: German Insurance Association (GDV), “Container Handbook”, Section 7.2.1 How do integral refrigerated containers work?. https://containerhandbuch.de/chb_e/wild/wild_07_02_01.html
[^5]: International Organization for Standardization, “ISO 1496-2:2008 - Series 1 freight containers — Specification and testing — Part 2: Thermal containers” (catalogue page, withdrawn edition). https://www.iso.org/standard/45621.html
[^6]: European Commission, Case M.8594 - COSCO SHIPPING / OOIL, Commission decision of 5 December 2017 (public version). https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX%3A32017M8594

