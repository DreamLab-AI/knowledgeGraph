A digital product passport is, in the EU Ecodesign for Sustainable Products Regulation, a set of data specific to a product that includes the information specified in the applicable delegated act and that is accessible via electronic means through a data carrier.[^1]

Regulation (EU) 2024/1781 of 13 June 2024 contains the definition. Article 9 says the information requirements shall provide that products can only be placed on the market or put into service if a digital product passport is available, and that the delegated acts for each product group specify the data, the data carriers, the layout, whether the passport is set at model, batch or item level, and who may read and update it.[^1] Those requirements are meant to improve the traceability of products along the value chain.[^1] CIRPASS, an EU-funded project, describes the passport as a tool for managing the information requirements and says it will complement non-digital forms such as a manual or label.[^2]

## Technical requirements

Article 10 says a passport must be connected through a data carrier to a persistent unique product identifier, and that the data carrier must be physically present on the product, its packaging or accompanying documentation.[^1] All data in the passport must be based on open standards and developed with an interoperable format.[^1]

Article 2 defines a data carrier as a linear barcode symbol, a two-dimensional symbol or another automatic identification data capture medium that can be read by a device, and a unique product identifier as a unique string of characters that also enables a web link to the passport.[^1] See [[Automatic Identification and Data Capture]]. GS1 states in a support article that the regulation names the Global Trade Item Number as one acceptable identifier, which is an industry reading and not the legal text.[^3] See [[Global Trade Item Number]].

## Scope and distinctions

Within the [[Ecodesign For Sustainable Products Regulation]] the passport is a tool for its information requirements, not a separate regulation.[^1][^2] What each product group must carry, and from when, depends on delegated acts that were not opened for this entry.

## What the sources do not establish

Text searches of the regulation find none of the terms blockchain, distributed ledger, verifiable credential or semantic web, so technology choices are not fixed there beyond open standards and interoperable formats.[^1] The CIRPASS summary describes the 2022 proposal, not the adopted text, so it is used only for the purpose of the passport.[^2] No source opened here describes how many passports exist or how they are used in practice.

[^1]: European Parliament and Council, “Regulation (EU) 2024/1781 of the European Parliament and of the Council of 13 June 2024 establishing a framework for the setting of ecodesign requirements for sustainable products, amending Directive (EU) 2020/1828 and Regulation (EU) 2023/1542 and repealing Directive 2009/125/EC”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1781
[^2]: CIRPASS project, “The Digital Product Passport as defined in the Proposal for Eco-design for Sustainable Product Regulation (ESPR)”, short summary. https://cirpassproject.eu/wp-content/uploads/2023/03/ESPR-short-summary-Final.pdf
[^3]: GS1, “Does the Ecodesign for Sustainable Products Regulation (ESPR) refer to the GS1 GTIN?”, GS1 GO Customer Service Portal. https://support.gs1.org/support/solutions/articles/43000758755-does-the-ecodesign-for-sustainable-products-regulation-espr-refer-to-the-gs1-gtin-

