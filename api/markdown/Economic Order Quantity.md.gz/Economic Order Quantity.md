Economic order quantity, or EOQ, is the order size that minimises the sum of the average fixed ordering cost and the average holding cost per unit of time when demand is constant.[^1][^2]

Columbia University lecture notes explain the trade-off: the primary driver to hold inventories is a fixed ordering cost incurred every time an order is placed, producing or ordering in large quantities reduces the average fixed cost, and what prevents quantities from becoming too large is that it costs money to hold inventories.[^1] MIT lecture slides state the same trade-off as batch size too large, with too much average inventory, versus batch size too small, with too much ordering cost.[^2]

## Cost function

The MIT slides write total average cost as average holding cost plus average order cost, and give it as hQ/2 plus Kλ/Q plus cλ, where h is the holding cost per unit per time, K the fixed order cost, λ the demand rate and c the purchase cost per unit.[^2] They give the derivative as h/2 minus Kλ/Q squared; setting it to zero gives the optimal quantity, the square root of 2Kλ divided by h.[^2] The Columbia notes call the time between consecutive orders the cycle length, or order interval.[^1]

## Assumptions

An open operations text lists the conditions for the model: the item is ordered from an outside supplier, demand is fixed per unit of time, the lead time is constant, the same amount is ordered every time, and the ordering cost is a fixed cost per order.[^3] The Bazargan textbook adds that orders arrive all at once and that no shortage occurs.[^4] The Columbia notes assume demand is constant and continuous over an infinite horizon.[^1]

## Scope and distinctions

That review of operations and supply chain management says the model started inventory management research.[^5] Where demand is random, see [[Newsvendor Model]] and [[Reorder Point Policy]]. The MIT slides note that with constant demand and zero lead time safety stock is not beneficial; see [[Safety Stock]].[^2]

## What the sources do not establish

Sources give the formula but no empirical evidence on how often its assumptions hold. Variants are not described here.

[^1]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “The EOQ and Extensions”. https://www.columbia.edu/~gmg2/4000/pdf/lect_02.pdf
[^2]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf
[^3]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.4: Inventory Models for Certain Demand - Economic Order Quantity (EOQ)”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.04%3A_Inventory_Models_for_Certain_Demand_-_Economic_Order_Quantity_(EOQ)
[^4]: Hamid Bazargan, BCcampus Open Education, November 2021, “Classical Topics in Inventory Control”. https://opentextbc.ca/oerdiscipline/wp-content/uploads/sites/213/2018/09/Classical-Topics-in-Inventory-Control.pdf
[^5]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

