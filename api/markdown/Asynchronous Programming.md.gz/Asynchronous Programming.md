Asynchronous programming is a concurrency model in which operations that would otherwise block — such as input/output, network calls or timers — are initiated without halting the executing thread, allowing other work to proceed until results become available. It uses constructs such as callbacks, promises, futures and async/await to express continuations cleanly. The approach improves responsiveness and throughput for input/output-bound workloads without the overhead of one thread per task.

- Asynchronous programming lets a program initiate long-running operations without blocking, expressing continuations through promises, futures and async/await as a form of [[Concurrency]].
- It is widely supported in languages such as [[Python]] and underpins responsive [[Software Development]].

### Overview

- Rather than waiting synchronously for slow operations, asynchronous code registers what should happen when a result arrives and yields control in the meantime.
- This is especially valuable for input/output-bound work, where a single thread can manage many in-flight operations efficiently.
- It contrasts with thread-per-request models and with CPU-bound [[Parallel Processing]], which seeks simultaneous execution rather than overlap.

### Key aspects

- Non-blocking operations that return immediately and complete later.
- Event loops or schedulers that dispatch continuations when results are ready.
- Promises and futures as placeholders for not-yet-available values.
- async/await syntax that makes asynchronous flow read like sequential code.
- Cooperative scheduling that avoids much of the cost of pre-emptive threads.

### Mechanisms

- An event loop polls for completed operations and resumes their continuations.
- Callbacks were the original mechanism; promises and async/await tamed nesting.
- Cancellation and timeout primitives bound the lifetime of pending work.
- [[Multithreading]] may complement the model for genuinely CPU-bound tasks.

### Applications

- High-concurrency web servers and API gateways.
- User interfaces that remain responsive during background work.
- Network clients, message consumers and streaming pipelines.
- Cloud-native services coordinating many remote calls.

### Provenance

