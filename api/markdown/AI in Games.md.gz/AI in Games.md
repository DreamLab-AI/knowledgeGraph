AI in Games is the interdisciplinary research and engineering field encompassing the design, implementation, and study of computational systems that perceive, decide, learn, and generate within interactive entertainment software, spanning classical symbolic techniques (finite-state machines FSM d...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:BehaviourTrees))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:FiniteStateMachine))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:GOAP))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:HTNPlanning))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:Pathfinding))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:NavigationMesh))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:InfluenceMap))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:MonteCarloTreeSearch))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:hasPart ai:ProceduralContentGeneration))

    ## Dependency Relationships
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:requires ai:GameEngine))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:requires ai:RealTimeConstraints))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:requires ai:GameStateRepresentation))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:requires ai:ContentAuthoringPipeline))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:dependsOn ai:ReinforcementLearning))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:dependsOn ai:SearchAlgorithms))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:dependsOn ai:PlanningAlgorithms))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:dependsOn ai:GameTheory))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:dependsOn ai:LargeLanguageModels))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:dependsOn ai:GenerativeAI))

    ## Capability Relationships
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:enables ai:EmergentGameplay))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:enables ai:DynamicDifficultyAdjustment))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:enables ai:ProceduralReplayability))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:enables ai:BelievableNPCBehaviour))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:enables ai:DynamicNarrative))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:enables ai:AutomatedPlaytesting))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:supports ai:UnityMLAgents))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:supports ai:UnrealEngine))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:supports ai:NVIDIAACE))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:supports ai:InworldAI))

    ## Implementation Relationships
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:AStarSearch))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:RecastNavmesh))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:UtilityAI))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:ProximalPolicyOptimization))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:MuZero))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:DreamerV3))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:AlphaZero))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:PerlinNoise))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:implements ai:WaveFunctionCollapse))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:uses ai:MarkovDecisionProcess))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:uses ai:SelfPlay))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:uses ai:CurriculumLearning))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:uses ai:ImitationLearning))

    ## Reduction Relationships
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:reduces ai:ContentAuthoringCost))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:reduces ai:QATestingBurden))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:reduces ai:NPCScriptingEffort))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:reduces ai:LevelDesignTime))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:reduces ai:PlayerOnboardingFriction))

    ## Association Relationships
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:relatedTo ai:ComputationalCreativity))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:relatedTo ai:PlayerModelling))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:relatedTo ai:Esports))
    SubClassOf(ai:AiInGames
      ObjectSomeValuesFrom(ai:relatedTo ai:AISafety))
    SubClassOf(ai:AiInGames
      DisjointWith(ai:ScriptedNPCs))
    SubClassOf(ai:AiInGames
      DisjointWith(ai:HandAuthoredDialogue))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ai:hasIdentifier ai:AiInGames "AI-1421"^^xsd:string)
    DataPropertyAssertion(ai:authorityScore ai:AiInGames "0.87"^^xsd:decimal)
    DataPropertyAssertion(ai:globalMarketSizeUSD ai:AiInGames "187700000000"^^xsd:decimal)
    DataPropertyAssertion(ai:globalPlayerBase ai:AiInGames "3400000000"^^xsd:integer)
    DataPropertyAssertion(ai:realTimeFrameBudgetMs ai:AiInGames "16.67"^^xsd:decimal)
    DataPropertyAssertion(ai:aiBudgetPerFramePercent ai:AiInGames "0.10"^^xsd:decimal)
    DataPropertyAssertion(ai:behaviourTreeTitleCount ai:AiInGames "50000"^^xsd:integer)
    DataPropertyAssertion(ai:llmNpcCommercialDeployments ai:AiInGames "120"^^xsd:integer)

    ## Property Constraints
    SubClassOf(ai:AiInGames
      DataAllValuesFrom(ai:hasRealTimeConstraint xsd:boolean))
    SubClassOf(ai:AiInGames
      DataSomeValuesFrom(ai:targetFrameRate xsd:integer))
    SubClassOf(ai:AiInGames
      DataMinCardinality(1 ai:hasAgentArchitecture xsd:string))

    ## Annotations
    AnnotationAssertion(rdfs:label ai:AiInGames "AI in Games"@en)
    AnnotationAssertion(rdfs:comment ai:AiInGames "Interdisciplinary field encompassing classical game AI (FSM, behaviour trees, GOAP, HTN, A*/navmesh, MCTS, influence maps), procedural content generation (Perlin/Simplex/Voronoi noise, dungeon/terrain/narrative generators), superhuman game-playing agents (AlphaGo/Zero, MuZero, AlphaStar, OpenAI Five, Pluribus, Cicero), modern LLM-driven NPCs (Inworld/Convai, NVIDIA ACE, NetEase Yiwen, Ubisoft NEO NPC), reinforcement-learning toolchains (PPO, IMPALA, DreamerV3, MuZero), and engine integrations (Unity ML-Agents, Unreal Engine 5, Godot, Bevy ECS). $187.7B global games market 2024, 3.4B players, 50K+ shipped behaviour-tree titles. UK leadership via UCL-Essex-York IGGI EPSRC CDT, Goldsmiths Computational Creativity, York Centre for Computer Game Studies, Sheffield Hallam Games Academy, northern industrial hubs Sumo Digital/Team17/Rare/Codemasters/Travellers Tales."@en)
    AnnotationAssertion(dcterms:identifier ai:AiInGames "AI-1421"^^xsd:string)
    AnnotationAssertion(dcterms:subject ai:AiInGames "Game AI, Procedural Content Generation, Reinforcement Learning, LLM NPCs, Game Development"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(ai:requires)
  AsymmetricObjectProperty(ai:enables)
  AsymmetricObjectProperty(ai:implements)
  AsymmetricObjectProperty(ai:reduces)
  TransitiveObjectProperty(ai:dependsOn)
  FunctionalDataProperty(ai:globalMarketSizeUSD)
  FunctionalDataProperty(ai:realTimeFrameBudgetMs)

## About AI in Games

- **AI in Games** designates the applied research and engineering field studying computational agents and content systems that act, decide, generate, and learn inside interactive entertainment software. Unlike most application domains of artificial intelligence, game AI is constrained simultaneously by hard real-time budgets (16.67 ms per frame at 60 Hz, 8.33 ms at 120 Hz competitive, 11.11 ms at 90 Hz VR), strict deterministic-replay and QA testability requirements, designer authorability constraints, certification regimes (ESRB/PEGI/USK content ratings, platform-holder TRCs/TCRs from Sony/Microsoft/Nintendo/Apple/Google), and an unforgiving cultural standard of *fun*: an AI opponent that plays optimally is usually a bad AI opponent. The field accordingly developed in parallel with mainstream academic AI rather than as a strict subset of it, with its own conferences (IEEE Conference on Games, AAAI AIIDE since 2005, FDG, EXAG), textbook canon (Yannakakis & Togelius *Artificial Intelligence and Games* MIT Press 2018, second edition Springer 2025; Millington & Funge *AI for Games* CRC Press 3rd edition 2019; *Game AI Pro* series Steve Rabin 2014/2015/2017/2024), and tooling ecosystem.
- The historical arc of the field can be summarised in four eras. The **symbolic era (1962-1995)** spans from *Spacewar!* (MIT 1962, first multiplayer space combat with simple AI opponents) through *Pong* (Atari 1972 paddle AI), *Pac-Man* (Namco 1980 four ghost personalities each running distinct FSMs — Blinky chasing, Pinky ambushing four tiles ahead, Inky vectoring against Blinky's position, Clyde alternating chase/scatter, an enduring textbook example of personality-via-behaviour-differentiation), *Civilization* (MicroProse 1991 strategic AI), *Doom* (id Software 1993 simple FSM monsters), through *Warcraft II* (Blizzard 1995 finite-state machine units with terrain-aware A* pathfinding). The **architectural-decision era (1995-2014)** sees the rise of *Half-Life* (Valve 1998 squad-coordinated marines that flanked, suppressed, and retreated based on shared blackboard observations — a landmark of believable AI), *The Sims* (Maxis 2000 utility-based autonomous agents motivated by needs), *Black & White* (Lionhead 2001 Richard Evans' belief-desire-intention creature with learning), *F.E.A.R.* (Monolith 2005 GOAP planner enabling emergent squad tactics widely studied as the canonical industry-strength planner), *Halo 2* (Bungie 2004 popularising behaviour trees through Damian Isla's AIIDE 2005 paper), *Left 4 Dead* (Valve 2008 AI Director dynamically pacing zombie hordes), *Killzone 2* (Guerrilla 2009 HTN planning), *Total War: Rome II* (Creative Assembly 2013 first commercial MCTS deployment in campaign AI), and *Alien: Isolation* (Creative Assembly 2014 dual-AI Director / Xenomorph search-based stalking that became a cult reference for emergent suspense). The **deep-learning era (2014-2022)** centres on *DQN* (Mnih et al. Nature 2015 superhuman on 49 Atari games), *AlphaGo* (DeepMind 2016 Lee Sedol 4-1), *Middle-earth: Shadow of Mordor* (Monolith 2014 Nemesis System procedural orc captains), the *AlphaZero / MuZero* lineage, *AlphaStar* StarCraft II Grandmaster 2019, *OpenAI Five* defeating Dota 2 world champions 2019, *Pluribus* six-player poker 2019, *Cicero* Diplomacy 2022. The **generative-AI era (2022-present)** opens with the public ChatGPT release November 2022 and runs through *AI Dungeon* (the original 2019 progenitor finally normalised in capability), *Inworld / Convai* in *Niantic Peridot* (2023) and *Mecha BREAK* (2024), *NVIDIA ACE* in *Inzoi* (Krafton 2025), *NetEase Yiwen* in *Justice Mobile* (June 2023, first AAA Chinese LLM NPCs), Park et al. *Generative Agents* (UIST 2023 Smallville simulation), DeepMind *Genie* (March 2024) and *Genie 2* (December 2024), Decart/Etched *Oasis* (October 2024 first playable diffusion-model game), Tencent/HKUST *GameGen-O* (NeurIPS 2024), DeepMind *DreamerV3* (Nature 2025), and projected toward AAA generative-runtime titles by 2027-2030.
- These eras are not strictly sequential — symbolic FSMs still dominate the inner loop of most shipped titles, behaviour trees remain the workhorse decision architecture, and A* over navmeshes is universal. The history is *additive*: each era added a layer to the stack rather than replacing the layers below. A modern AAA NPC may simultaneously be driven by a behaviour tree at the macro level, a utility AI at the action-selection level, GOAP for tactical planning, animation-network motion matching for locomotion, an LLM for dialogue, and an RL-trained policy for combat reflexes — orchestrated by a hand-written game director script and visualised via deterministic-replay tooling for QA.
- The discipline organises around four canonical problem families that map cleanly onto sub-areas of the ontology:
  1. **Playing the game** — autonomous agents that play (board games, video games, esports titles). Includes both *playing well* (AlphaGo lineage, AlphaStar, OpenAI Five, Pluribus, Cicero) and *playing believably* (human-like agents indistinguishable from human players in Turing-style tests, important for matchmaking, tutorial bots, and live-service population filling).
  2. **Generating content** — procedural content generation (PCG) of levels, terrain, quests, dialogue, narrative arcs, character art, music, sound effects, and increasingly entire playable spaces. Includes PCGML (PCG via Machine Learning, Summerville et al. 2018) and the post-2022 wave of generative AI content pipelines.
  3. **Modelling players** — player-experience modelling, affective computing, churn prediction, matchmaking, fraud/cheat detection, dynamic difficulty adjustment, personalisation. Active research at York's Centre for Computer Game Studies, Goldsmiths, and commercially at Riot Games, EA, Activision Blizzard, miHoYo.
  4. **Authoring tools** — AI-assisted authoring for designers (level-design copilots, dialogue writers, asset generators, automated playtesting). The 2024-2026 generative AI wave dramatically expanded this category.

### Components and Architecture

Modern game AI architectures stack the following layers from bottom-up. Lower layers consume tighter frame budgets; higher layers are typically amortised across many frames or invoked at game-state transitions.

**Perception layer** — sensors that translate game-state into agent observations. Implementations include line-of-sight raycasts, hearing models with distance attenuation and obstruction (used pervasively from Thief Looking Glass 1998 through Dishonored Arkane 2012 through Last of Us Part II Naughty Dog 2020), smell/scent trails (Halo Combat Evolved 2001 grunt squad coordination), shared blackboard observations (Squad AI in F.E.A.R. Monolith 2005, Killzone 2 Guerrilla 2009), and influence maps (Dave Mark IGDA tutorials, used in Empire Earth Stainless Steel 2001 and Total War series Creative Assembly 2000-2025).

**Pathfinding layer** — A* search (Hart-Nilsson-Raphael IEEE Transactions on Systems Science and Cybernetics 1968) remains the workhorse, executed over navigation meshes generated by Recast & Detour (Mikko Mononen 2009, open-source MIT-licensed, embedded in Unreal Engine, Unity NavMesh, CryEngine, Godot, Cyberpunk 2077, World of Warcraft Dragonflight). Hierarchical pathfinding (HPA*) and any-angle variants (Theta*) handle large open worlds. JPS (Jump Point Search, Harabor & Grastien 2011) accelerates uniform-cost grid search 10-100×. Steering behaviours (Reynolds Boids 1987, GDC 1999) handle local obstacle avoidance and crowd dynamics; ORCA (Optimal Reciprocal Collision Avoidance, van den Berg et al. 2008) is the standard for dense agent populations in MMOs.

**Decision layer** — historically dominated by **finite-state machines** (FSM): Pac-Man's four ghost personalities (1980, Iwatani/Namco), Half-Life marines (Valve 1998), and untold thousands of titles. The 2000s shifted toward **behaviour trees** (Halo 2 Bungie 2004, popularised industry-wide by Damian Isla AIIDE 2005 paper *Handling Complexity in the Halo 2 AI*), now the default in Unreal Engine 5, Unity (via NodeCanvas, Behavior Designer), CryEngine, Lumberyard, and Godot 4. **Utility AI** (Dave Mark 2010 *Behavioral Mathematics for Game AI*; The Sims series Maxis/EA 1999-2025; Red Dead Redemption 2 Rockstar 2018) scores candidate actions by weighted utility functions and selects probabilistically. **Goal-Oriented Action Planning** (GOAP, Jeff Orkin AIIDE 2005, Monolith F.E.A.R. 2005, Just Cause 2 Avalanche 2010) applies STRIPS-style backward chaining over action preconditions and effects. **Hierarchical Task Networks** (HTN, Tilo Mortelliti GDC 2009 *Killzone 2 AI*, Transformers: Dark of the Moon High Moon 2011, Horizon Zero Dawn Guerrilla 2017) decompose high-level intents into primitive task sequences. **Monte Carlo Tree Search** (MCTS, Coulom 2006, Kocsis & Szepesvári UCT 2006) entered commercial game AI via Total War: Rome II Creative Assembly 2013 campaign-layer strategy, and remains the bridge to the AlphaGo lineage.

**Animation layer** — motion matching (Ubisoft *For Honor* 2017, *Watch Dogs Legion* 2020, Naughty Dog *The Last of Us Part II* 2020), learned motion controllers (Holden et al. *Phase-Functioned Neural Networks for Character Control* SIGGRAPH 2017; *Mode-Adaptive Neural Networks for Quadruped Motion Control* SIGGRAPH 2018; DeepMind *MoCapAct* 2022), and procedural inverse kinematics (Final IK, Animation Rigging Unity, Control Rig Unreal).

**Tactical and strategic layer** — squad coordination, formation control, encounter directors (Left 4 Dead AI Director, Valve 2008, dynamic pacing via player-stress estimation; Alien: Isolation Creative Assembly 2014 dual-AI Director plus Xenomorph), and macro strategic AI (Civilization series Firaxis 1991-2025, Total War series, StarCraft II ladder bots).

**Generative layer** — procedural content generation (PCG) and generative AI. Covers terrain synthesis (Perlin/Simplex/Voronoi/diamond-square/erosion simulation), dungeon and room generation (rogue-likes, Spelunky, Diablo IV, Hades), quest and narrative generation (Versu, Bad News, AI Dungeon, NetEase Yiwen), and 2023-2026 LLM-driven NPC dialogue (Inworld/Convai, NVIDIA ACE, Replica Studios, Ubisoft NEO NPC).

**Learning layer** — reinforcement learning, imitation learning, self-play, behaviour cloning. Unity ML-Agents (Juliani et al. 2018, 23K+ GitHub stars) and Unreal Learning Agents (Epic 2023, plugin-shipped 5.3+) are the dominant productionised toolchains; research workhorses include OpenAI Gymnasium (formerly Gym, Brockman et al. 2016), DeepMind Acme, PettingZoo (Terry et al. NeurIPS 2021), Stable-Baselines3, and CleanRL.

**Dialogue and NLP layer** — pre-2022 dominated by tree-based dialogue authoring tools (Yarn Spinner, Ink, Chat Mapper, articy:draft, Twine), keyword recognisers (Façade 2005), and topic-based response selection. Post-ChatGPT the layer fragmented into hosted LLM APIs (OpenAI GPT-4o, Anthropic Claude 3.5 Sonnet, Google Gemini 1.5 Pro), specialised NPC platforms (Inworld Engine, Convai, Charisma.ai, Replika Studios), and on-device inference (NVIDIA Nemotron-Mini-4B-Instruct, Llama 3.2 3B / 1B, Microsoft Phi-3.5-mini, Mistral Ministral 3B). Speech components stack ASR (Whisper, NVIDIA Riva, Deepgram, AssemblyAI), prosody-aware TTS (ElevenLabs, NVIDIA Riva TTS, Microsoft Neural TTS, Replica Studios, Sonantic acquired by Spotify 2022), lip-sync (NVIDIA Audio2Face, Oculus LipSync, JALI), and facial-animation (Apple Live Linked Face, MetaHuman Animator).

**Memory and personalisation layer** — persistent character and player models. Vector databases (Pinecone, Weaviate, Qdrant, Chroma, pgvector) store conversation history embedded via sentence-transformers or proprietary embeddings; retrieval-augmented generation (RAG) injects relevant memories into LLM context windows; structured memory stores (knowledge graphs, JSON state) maintain canonical NPC facts (relationships, possessions, locations). Inworld's "Knowledge" and "Relationships" subsystems exemplify the productionised pattern.

**Orchestration and director layer** — meta-AI systems that schedule events, modulate difficulty, and pace experience. Examples include Left 4 Dead's AI Director (Valve 2008, monitoring player tension via damage taken / health / proximity to extract dramatic horde timing), Alien: Isolation's dual-AI Director (overarching scheduler aware of player position + reactive Xenomorph), Resident Evil 4's tension curve (Capcom 2005), and emergent quest generation systems. Modern LLM-driven director research (NetEase Yiwen, IGGI Sebastian Risi NEAT-Drama 2022) extends this layer.

### Use Cases / Major Families

- **1. Classical decision and planning AI**
  - FSM-driven NPCs (Pac-Man 1980 through modern AAA), behaviour trees (Halo 2 onwards, now industry standard), utility AI (The Sims, Red Dead Redemption 2), GOAP (F.E.A.R., Tomb Raider 2013, Middle-earth: Shadow of Mordor 2014 Nemesis System), HTN planning (Killzone 2, Horizon Zero Dawn, Transformers).
- **2. Pathfinding and navigation**
  - A* over navmeshes (Recast/Detour pervasive), HPA* hierarchical pathfinding (StarCraft, Supreme Commander), JPS for grid-based games (Total War), flow fields (Supreme Commander, Planetary Annihilation), steering behaviours and ORCA for crowd simulation.
- **3. Procedural content generation**
  - Roguelike dungeon generators (Rogue 1980, NetHack, Brogue, Caves of Qud), Spelunky-style room templates (Yu 2008, Hades 2020, Dead Cells 2018), Wave Function Collapse (Maxim Gumin 2016, Bad North Plausible Concept 2018, Townscaper Oskar Stålberg 2021), terrain via fractal noise (Minecraft, No Man's Sky, Valheim), narrative generation (Versu, Bad News, AI Dungeon, NetEase Yiwen, Suck Up! Proxima Enterprises 2023, 1001 Nights Tianhao Chen 2023).
- **4. Game-playing superhuman agents**
  - Board games: Chess (Deep Blue IBM 1997, Stockfish, AlphaZero 2018), Go (AlphaGo 2016 Lee Sedol 4-1, AlphaGo Zero 2017, KataGo Wu 2019 open-source), Shogi (AlphaZero), Diplomacy (Cicero Meta FAIR 2022).
  - Imperfect-information games: No-limit Texas Hold'em heads-up (Libratus Brown-Sandholm Science 2017), six-player (Pluribus Brown-Sandholm Science 2019), Bridge (NooK NukkAI 2022).
  - Real-time strategy and MOBA: StarCraft II (AlphaStar Vinyals et al. Nature 2019 Grandmaster 99.8 percentile), Dota 2 (OpenAI Five April 2019 defeated OG world champions, 168K games/day across 256 GPUs), MOBA bots in Honor of Kings (Tencent JueWu 2020).
  - Atari and general game-playing: DQN (Mnih et al. Nature 2015 49 Atari games human-level), Rainbow (Hessel et al. AAAI 2018), R2D2 (Kapturowski et al. ICLR 2019), Agent57 (Badia et al. ICML 2020 superhuman on all 57 games), MuZero (Schrittwieser et al. Nature 2020 learning model from scratch), DreamerV3 (Hafner et al. Nature 2025 Minecraft diamond no curriculum), GATO (Reed et al. DeepMind 2022 multi-modal generalist).
  - Modern open-world: VPT Video PreTraining (Baker et al. OpenAI NeurIPS 2022 Minecraft from YouTube + RL fine-tune obtained diamond pickaxe), Voyager (Wang et al. 2023 LLM-driven Minecraft autocurriculum).
- **5. Modern LLM-driven NPCs (2023-2026)**
  - **Inworld AI** — Series B $50M August 2023 led by Lightspeed Venture Partners + Stanford StartX; acquired Convai July 2024 (Stanford/MIT spinout, NVIDIA Inception). Deployed in Niantic Peridot (2023), Mecha BREAK (Amazing Seasun 2024), Niantic Stadium (2024), Streamlabs AI hosts (2023), and Disney Imagineering R&D. Inworld Engine GDC 2024 announcement targets full multi-agent runtime for AAA.
  - **NVIDIA ACE (Avatar Cloud Engine)** — GDC 2024 announcement, comprising Riva ASR + Audio2Face + Nemotron LLM + ElevenLabs/NVIDIA TTS + NVIDIA Maxine. Shipping in Inzoi (Krafton 2025), Mecha BREAK, Naraka: Bladepoint (NetEase 24Entertainment), and PUBG (Krafton). NVIDIA ACE Microservices on RTX 2024 enables on-device inference.
  - **NetEase Yiwen** — Justice Mobile (逆水寒手游) launched 30 June 2023 in China featuring NetEase's proprietary LLM driving NPCs; reportedly 30M+ MAU within months. First Chinese AAA-scale LLM-driven NPC deployment. NetEase Fuxi AI Lab subsequently shipped LLM NPCs across Naraka: Bladepoint and Onmyoji.
  - **Ubisoft NEO NPC (also Bloom)** — GDC 2024 R&D tech demo by Ubisoft Paris + Inworld + NVIDIA showing reactive narrative NPCs Bloom and Iron with player-aware emergent dialogue. Production deployment pending.
  - **Replica Studios** — January 2024 SAG-AFTRA agreement establishing AI voice replication framework with talent consent. Integrated into Unreal Engine 5 MetaHuman pipeline.
  - **EA SEED** — Stockholm-based generative AI research division; 2024 tech demo *Stochastic Variation* showing real-time animation generation. EA CEO Andrew Wilson May 2024 earnings: 50% of game-development processes targeted for genAI assist.
  - **Tencent Hunyuan-Game** — September 2024 release of Tencent's game-tuned LLM for Honor of Kings, PUBG Mobile, and Call of Duty Mobile NPC dialogue.
  - **Smaller / open-source / indie** — Gigax (Open-source LLM NPCs, YC W24), Suck Up! (Proxima Enterprises 2023 viral vampire-roleplay demo), 1001 Nights (Tianhao Chen 2023 itch.io), AI Dungeon (Latitude 2019 first commercial LLM game), AI Town (a16z-infra 2024 reference implementation), LARP Language-Agent Role Play (Miao AI Lab arxiv 2312.17653).
- **6. Reinforcement learning for game agents**
  - **PPO** (Schulman et al. OpenAI 2017) — default modern actor-critic algorithm; trains StarCraft II ladder bots, OpenAI Five, ML-Agents tutorials, Unreal Learning Agents.
  - **IMPALA** (Espeholt et al. DeepMind ICML 2018) — V-trace off-policy correction, scales to 8K actors; underlies DeepMind game-research pipeline.
  - **MuZero** (Schrittwieser et al. Nature 2020) — model-based MCTS+RL learning environment dynamics without rules; deployed by DeepMind for YouTube video-codec optimisation 2022.
  - **DreamerV3** (Hafner et al. Nature 2025) — world-model-based RL mastering Minecraft diamond from scratch, 150+ tasks without hyperparameter tuning.
  - **AlphaZero / MuZero lineage** — board games, Atari, general game-playing.
  - **R2D2 / Agent57** (DeepMind 2019/2020) — distributed recurrent DQN surpassing human on all 57 Atari games.
  - **Decision Transformer** (Chen et al. NeurIPS 2021) — offline RL via sequence modelling, applied to Atari and OpenAI Gym.
- **7. Procedural narrative and dynamic quest generation**
  - Versu (Inkle / Richard Evans / Emily Short 2014) — social-practice character simulation, ran until iOS deprecation.
  - Bad News (Ryan, Samuel, Mateas, Wardrip-Fruin AAAI 2017) — family-history Wizard-of-Oz performance piece.
  - AI Dungeon (Latitude 2019) — first commercial LLM-driven text adventure, GPT-3 powered.
  - NetEase Yiwen / Justice Mobile dynamic side-quests 2023.
  - Ubisoft's Quest Generation Tool (internal, leaked 2023).
  - Academic: ANGELINA (Michael Cook, Goldsmiths, AAAI 2014 paper *A Rogue Dream*), Tracery (Kate Compton 2015), Tanagra (Smith et al. 2010).
- **8. Engine integration toolchains**
  - **Unity ML-Agents** — Juliani et al. 2018, PyTorch backend, 23K+ stars, 50+ official environments. Used in academic research and select indie shipping titles.
  - **Unreal Engine 5** — Behaviour Trees, Environment Query System (EQS), Smart Objects (5.1+), Mass Entity (5.0+ data-oriented ECS), StateTree (5.2+), Learning Agents (5.3+ RL plugin), MetaHuman + Audio2Face integration. Lyra Sample Project 2022 demonstrates production-quality patterns.
  - **Godot 4** — NavigationServer3D, GDScript AI tutorials, Behaviour Tree plugins (BeehaveBT, LimboAI).
  - **Bevy** — Rust ECS engine, v0.13 Feb 2024, popular for academic / hobbyist RL research; big_brain crate for utility AI.
  - **CryEngine / Lumberyard / O3DE** — legacy navmesh, behaviour tree, AI Sequence systems.

### Academic Context

Game AI maintains a dense academic conference and journal ecosystem distinct from mainstream ML venues.

**Conferences**:

- **IEEE Conference on Games (CoG)** — formerly IEEE Conference on Computational Intelligence and Games (CIG), since 2005, primary research venue. CoG 2024 Milan, CoG 2025 Lisbon, CoG 2026 Vienna scheduled.
- **AAAI AIIDE (Artificial Intelligence and Interactive Digital Entertainment)** — since 2005, where Damian Isla's seminal *Handling Complexity in the Halo 2 AI* paper appeared. AIIDE 2024 Lexington Kentucky.
- **FDG (Foundations of Digital Games)** — since 2009, broader games-research scope including HCI and design.
- **EXAG (Experimental AI in Games)** — AIIDE workshop, since 2014, hosts cutting-edge demos.
- **DiGRA (Digital Games Research Association)** — humanities-leaning, hosted by York Centre for Computer Game Studies in 2025.
- **GDC AI Summit** — industry-facing two-day track at Game Developers Conference, since 2007, organised by IGDA AI SIG.

  **Journals**:

- *IEEE Transactions on Games* (TOG), formerly *IEEE TCIAIG*.
- *Game Studies* (humanities, since 2001).
- *Entertainment Computing* (Elsevier).

  **Canonical textbooks**:

- **Yannakakis & Togelius**, *Artificial Intelligence and Games*, Springer 2018 (1st ed.) / 2025 (2nd ed.) — definitive academic textbook, free PDF at gameaibook.org, used at IGGI, NYU Game Innovation Lab, Falmouth University, Sheffield Hallam.
- **Millington & Funge**, *AI for Games*, CRC Press 3rd ed. 2019 — industry-oriented reference.
- **Rabin (ed.)**, *Game AI Pro* series volumes 1-4 (2014/2015/2017/2024) — practitioner essay collections.
- **Shaker, Togelius & Nelson**, *Procedural Content Generation in Games*, Springer 2016 — PCG-focused.
- **Pearl**, *Heuristics*, Addison-Wesley 1984 — historical search-algorithm foundation.

### Current Landscape (2026)

As of mid-2026, the field is in the midst of its third major paradigm shift — after symbolic/scripted (1980s-2000s) and decision-architecture-driven (2000s-2010s), the LLM/generative-AI era (2022-) is reshaping content production, NPC dialogue, and authoring tools simultaneously.

**Market context**: Newzoo Global Games Market Report 2024 places global games revenue at $187.7B for 2024, with 3.4B players. Mobile $92.6B (49%), console $50.5B (27%), PC $44.6B (24%). Generative-AI tooling spend across the games industry estimated $1.1B 2024 (a16z analysis November 2024), projected $5-8B by 2028.

**LLM NPC commercial deployments**: NVIDIA Inception's tracker lists ~120 commercial titles shipping with LLM-driven NPCs as of Q1 2026, up from ~15 in Q1 2024. Categories include conversational NPCs (Inworld, Convai, NVIDIA ACE), AI Game Masters (AI Dungeon, Suck Up!, 1001 Nights), companion characters (Replika has discussed game crossovers), and live-service moderators.

**Open weights and on-device**: 2024-2025 saw rapid expansion of on-device LLM NPC inference. NVIDIA ACE Microservices on RTX (Computex 2024) targets ~7-13B parameter Nemotron-Mini and Nemotron-Mini-Instruct running locally on RTX 4070+. Llama 3.1 / 3.2 / 3.3 (Meta 2024-2025) and Mistral Small 3 / Ministral 3B (Mistral 2025) provide open-weights bases for distilled NPC models. Gigax open-source NPC engine (YC W24) and AI Town (a16z-infra) demonstrate fully local stacks.

**Generative content tools shipping**: Scenario.gg (game-asset Stable Diffusion fine-tunes, $11.5M Series A 2023), Layer (3D character genAI), Promethean AI (procedural set dressing), Rosebud AI (game generation from prompts), GameGen-O (NeurIPS 2024 open-world game model from Tencent / HKUST), Genie 2 (DeepMind December 2024 world model from single image), Oasis (Decart / Etched October 2024 first playable Minecraft-like diffusion model). Sprite Fusion (no-AI workflow tool 2024) and Fiero Game Engine (no-code AI game maker 2024) demonstrate the abstraction trend.

**Player-side controversy**: Steam's January 2024 generative-AI disclosure policy update (Valve store-page filing for content using AI) followed by softening June 2024 allowing AI-generated content with disclosure. Several titles have been refused listing or removed; the Suck Up! launch demonstrated viable LLM-NPC commercial release. Voice-actor activism (SAG-AFTRA strike July 2024 - June 2025 over AI voice replication; Replica Studios January 2024 agreement) and Concept Artist Backlash establish ongoing labour-rights tension. The 2024 Activision Blizzard QA / EA layoffs (May 2024 5% workforce) and 2024-2025 wider games-industry contraction (35,000+ jobs lost industry-wide 2023-2024 per Game Industry Layoffs tracker) coincided with the genAI wave, intensifying debate.

**Disruption thesis**: Game engines themselves are increasingly seen as ripe for disruption. Unity (founded 2004), Unreal Engine (founded 1998), and Roblox (founded 2004) all predate the modern compute substrate; AI-native engine startups (Rosebud, Hyperreal, Modl.ai for QA) target this dislocation. OpenUSD (Pixar 2016, Khronos / Alliance for OpenUSD 2023) is positioned as the interoperability layer enabling AI-native pipelines independent of monolithic engines.

### UK Context

The UK occupies a leadership position in both academic game AI research and industrial game development, with strong regional clustering across the Midlands and the North.

**Academic centres**:

- **UCL-Essex-York EPSRC Centre for Doctoral Training in Intelligent Games and Game Intelligence (IGGI)** — flagship UK game-AI CDT 2014-2024, £6.5M EPSRC funding, graduated 80+ PhDs across UCL, Essex, York, with industrial partners spanning Sony, Sega, Sports Interactive, Creative Assembly, Square Enix, Microsoft Research Cambridge, IBM Research. IGGI 2.0 EPSRC bid submitted 2024 covering 2025-2032. Key faculty: Mark Cavazza (Greenwich/Teesside), Simon Lucas (Queen Mary/Essex), Diego Pérez-Liébana (Queen Mary), Mark Nelson (Falmouth), Tommy Thompson (AI and Games YouTube + York), Vanessa Volz (modl.ai / IGGI alumna), Sebastian Risi (ITU Copenhagen / IGGI external).
- **Goldsmiths Computational Creativity Group** — Mark Cook (ANGELINA computational game design, AAAI 2014), Simon Colton (until 2017, Painting Fool), MA Computational Arts.
- **York Centre for Computer Game Studies** — humanities + design + AI, DiGRA host 2025, MSc Computer Science with Games.
- **Sheffield Hallam Games Academy** — Sheffield Games Cluster anchor, BA/MA programmes, industrial placements with Sumo Digital.
- **Falmouth University Games Academy** — large undergraduate cohort, hosted Procedural Generation Jam, Mark Nelson PCG research.
- **University of Essex Game Intelligence Group** — Simon Lucas (until 2017 then Queen Mary), GVG-AI general video-game AI competition, MicroRTS.
- **Queen Mary University of London** — Simon Lucas (Game AI Research Group 2017-), Diego Pérez-Liébana, MCTS / general video-game AI focus.
- **Falmouth MetaMakers Institute** (closed 2021) — Mike Cook procedural game-design research.
- **King's College London Game AI** — Aldeida Aleti, automated game testing.
- **University of York Centre for Game Design** — Sebastian Deterding (gamification), MSc Computer Science with Games.
- **Abertay University Dundee** — first UK university with computer games BSc (1997), Dare to be Digital competition.

  **Industrial hubs** (with regional emphasis per worker brief — Manchester / Leeds / Sheffield / Newcastle northern axis):

- **Sumo Digital** (Sheffield HQ + Newcastle + Nottingham + Pune; acquired by Tencent August 2022 £919M) — Sackboy: A Big Adventure 2020, Hood: Outlaws & Legends 2021, work-for-hire on Hogwarts Legacy, LittleBigPlanet 3.
- **Team17** (Wakefield, West Yorkshire; LSE-listed 2018) — Worms series, Overcooked! publisher, Hell Let Loose publisher.
- **Rockstar North** (Edinburgh) — Grand Theft Auto V/VI, Red Dead Redemption 2, advanced animation + AI systems.
- **Creative Assembly** (Horsham, Sussex; Sega-owned) — Total War series, Alien: Isolation 2014 (dual-AI Director), Hyenas (cancelled 2023).
- **Sports Interactive** (London; Sega-owned) — Football Manager series, deep simulation AI, IGGI industry partner.
- **Rare** (Twycross, Leicestershire; Microsoft-owned) — Sea of Thieves 2018, Everwild (in-development).
- **Codemasters** (Birmingham; EA-acquired £945M February 2021) — F1 series, DiRT, GRID; physics + AI driving models.
- **Travellers Tales / TT Games** (Knutsford, Cheshire; Warner Bros-owned) — LEGO series.
- **Cloud Imperium Games Manchester** — Star Citizen, Squadron 42; large open-world AI.
- **Frontier Developments** (Cambridge; AIM-listed) — Elite Dangerous, Jurassic World Evolution 2, Planet Coaster, F1 Manager.
- **Splash Damage** (Bromley) — Gears Tactics 2020, Halo Infinite co-dev.
- **Climax Studios** (Portsmouth) — work-for-hire, VR.
- **Roll7** (London; acquired by Take-Two 2021, closed May 2024) — OlliOlli World.
- **Mediatonic** (London; Epic-owned) — Fall Guys.
- **Hello Games** (Guildford) — No Man's Sky, procedural-generation pioneer (Sean Murray).
- **Ninja Theory** (Cambridge; Xbox Game Studios) — Hellblade series.
- **BBC Studios Games** (London) — Doctor Who, Top Gear properties; BBC R&D AI research crossover.

  **Industry support and policy**:

- **UKIE (UK Interactive Entertainment Association)** — trade body, Manchester / London offices.
- **TIGA (The Independent Game Developers' Association)** — Birmingham-based.
- **Games London** — Mayor of London games development support.
- **UK Games Fund** — Dundee-based, Video Games Tax Relief support.
- **BFI / Creative UK** — Video Games Expenditure Credit (VGEC) effective 1 January 2024 (replacing VGTR).
- **Northern Power Games** — northern English games-industry trade body.
- **InnovateUK Creative Industries Cluster** — Manchester / Sheffield / Leeds focus.

### Future Directions (2026-2030)

- **Generative engines and world models** — Genie 2 (DeepMind December 2024), Oasis (Decart/Etched October 2024), GameGen-O (Tencent/HKUST NeurIPS 2024), and OpenAI's Sora-derived world models point to a future where playable spaces are generated from prompts rather than authored asset-by-asset. By 2028, expect commercial titles with substantial generative-runtime content; full generative-engine games beyond the demo stage by ~2030.
- **On-device LLM NPCs at scale** — NVIDIA ACE Microservices on RTX 4060+ already enable 7B-class local inference; by 2028 expect 13-30B-class local NPCs across console generation 10 (PlayStation 6 ~2027, next Xbox ~2026-2027) and 70B-class via cloud-edge hybrids. Latency budgets 200-500 ms round-trip for conversational NPCs achievable today; sub-100 ms by 2027 for on-device 7B with speculative decoding.
- **Automated playtesting and QA** — Modl.ai (Copenhagen, IGGI alumna founded company), Regression Games, Activision QA-AI internal tooling, EA Frostbite Automated Testing. By 2028 expect majority of AAA studios to use RL-based test agents for coverage and regression alongside traditional QA.
- **Personalisation via player modelling** — dynamic difficulty (existing in Left 4 Dead Director 2008, Resident Evil 4 2005), expanded to dynamic narrative pacing, dynamic asset selection, dynamic monetisation (already pervasive in mobile F2P, expanding to console PC).
- **Believable agents and social simulation** — Park et al. *Generative Agents* (UIST 2023 Smallville town simulation) and successors point toward NPC social simulation at scale. Inworld, Convai, and academic projects (e.g., LARP arxiv 2312.17653) are moving in this direction.
- **AI safety, content moderation, and brand safety for LLM NPCs** — jailbreaking, prompt injection, hallucination of brand-inappropriate content, IP infringement risk. Expect dedicated brand-safety LLM-NPC guardrail standards by ~2027; possibly led by NVIDIA ACE Guardrails NeMo and Inworld safety stack.
- **AI in esports and game-analytics** — pro-tier coaching tools (Mobalytics, Blitz, Senpai.gg), match-fixing detection, cheat detection (BattlEye, Easy Anti-Cheat machine-learning augmentation), broadcast augmentation.
- **Engine disruption** — AI-native engines (Rosebud, Hyperreal, generative-first startups) challenge Unity/Unreal hegemony; OpenUSD interoperability and cloud-first architectures (PlayCanvas, Babylon.js, Three.js + WASM) reduce engine lock-in. By 2028 expect at least one major studio to ship a AAA title on a non-Unity/Unreal AI-native stack.
- **Regulatory and ethical** — UK Online Safety Act (in force March 2025 for category 1 platforms including major games), EU AI Act (general-purpose AI provisions August 2025, full effect August 2026), Children's Code (ICO Age Appropriate Design Code) implications for LLM NPCs interacting with under-18s. ESRB / PEGI ratings frameworks updating to address procedural/LLM content (PEGI announced AI content disclosure consultation Q3 2024).
- **Quantum and neuromorphic** — speculative, but DeepMind's AlphaQubit (Nature 2024) and Microsoft Majorana 1 (February 2025) point toward quantum-accelerated game AI search by ~2030.

### Business and Investment Landscape (2024-2026)

- **Funding totals** — Games + AI startup investment per a16z November 2024 analysis totalled approximately $1.6B across 2023-2024, with notable rounds including Inworld AI Series B $50M (August 2023, Lightspeed lead), Convai (acquired by Inworld July 2024 undisclosed), Charisma.ai £4M Series A (Edinburgh-based, 2023), Modl.ai €5M Series A (Copenhagen 2022), Promethean AI Series A $9M (2023), Scenario.gg $11.5M Series A (2023), Rosebud AI Series A $5M (2024), Layer Series A (2023), and Gigax (YC W24). Larger AI infrastructure beneficiaries to gaming include NVIDIA (gaming revenue $10.4B FY2024 with ACE/Omniverse strategic positioning), ElevenLabs Series C $80M January 2024, Replica Studios (private), and Inworld's $500M valuation (post-Series B).
- **Strategic M&A** — Microsoft acquisition of Activision Blizzard closed October 2023 ($69B, the largest gaming acquisition ever, with material AI strategy implications across Call of Duty / World of Warcraft / Diablo); Sony's bungie acquisition 2022 ($3.6B) brought live-service AI expertise; Tencent's Sumo Digital acquisition August 2022 (£919M); EA acquisition of Codemasters February 2021 (£945M, F1 AI driving models); Embracer Group's serial UK acquisitions 2021-2022 (Crystal Dynamics, Eidos Montréal, Square Enix Western IP).
- **Publisher-level AI strategies** — EA CEO Andrew Wilson stated on May 2024 earnings call that ~50% of EA's game-development pipeline is targeted for genAI-assisted workflows by 2027; Ubisoft's GDC 2024 NEO NPC announcement positioned Bloom + Inworld + NVIDIA as a strategic NPC stack; Take-Two Interactive (Strauss Zelnick public comments 2024) has been more conservative, citing IP-protection concerns; Activision's Call of Duty internal AI tooling (procedural voice lines, automated localisation review, AI QA bots) has been disclosed in trade press; Square Enix's January 2024 New Year statement explicitly named generative AI as a strategic priority. Nintendo (Doug Bowser 2024 interview) has been publicly cautious about generative AI, emphasising human craft. Microsoft Gaming (Phil Spencer 2024) has acknowledged AI but emphasised accessibility and authoring-tool focus.
- **Esports and live-service** — AI tools span coaching (Mobalytics 27M+ users, Blitz, Senpai.gg, Outplayed), anti-cheat (BattlEye, Easy Anti-Cheat with ML augmentation 2023, Vanguard Riot 2020, Ricochet Activision 2021), broadcast augmentation (StatsPerform, Bayes Esports, Sportradar AI for League of Legends / Counter-Strike 2 / Dota 2 broadcasts), and live-balance analytics (Riot Games internal tools, Blizzard Heroes Forge).

### Open Problems and Failure Modes

- **Believability vs optimality** — the longest-standing open problem in game AI. Players consistently rate sub-optimal but believable opponents (Halo Combat Evolved Elites flanking and grenading even when raw shoot-the-player heuristics would be more lethal; Alien: Isolation Xenomorph oscillating between predictable and surprising) as more enjoyable than optimal opponents (perfect-aim aimbots, dodge-everything AlphaStar-class agents). No general computational model of "fun opponent" exists; tuning remains craft. Pluribus poker AI's victory over six pros (2019) was carefully framed: players reported the bot was *better* than humans but did not report it was *more fun to play against*.
- **Long-horizon coherence in LLM NPCs** — current LLMs hallucinate at multi-turn scale, forget early-conversation facts (context-window limits), and drift out of character. Studio mitigations include retrieval-augmented generation (RAG) over canonical lore, persistent character memory stores (vector databases scoped per-NPC per-player), system-prompt scaffolding, and aggressive fine-tuning on style-aligned dialogue corpora. Open research at Inworld, Convai, OpenAI Custom GPTs for games, and academic labs (Park et al. Smallville architecture).
- **Brand and IP safety** — branded NPCs (Star Wars characters in Fortnite, Marvel licences, Disney IP) cannot risk generating off-brand statements. Disclosed deployment patterns use heavy system-prompt constraints, output-filtering classifiers, refusal-to-discuss-X lists, and human-in-the-loop review queues. Open question: does AAA branding require fully air-gapped (no LLM, only retrieval-from-approved-corpus) approaches?
- **Emergent gameplay vs designer control** — emergent AI (RL-driven agents, procedural narrative) by definition produces unexpected behaviour. QA cannot enumerate test cases; designers cannot guarantee narrative arcs. Industry responses include: hybrid architectures (RL within hard-coded rails), interactive constraint authoring (designer-supplied utility functions, behaviour-tree branches that override RL outputs), shadow-mode deployment (AI behaviour logged but not user-visible for weeks pre-launch), and graceful degradation (LLM dialogue with hand-authored fallback).
- **Multi-agent generalisation** — agents trained against one opponent population (self-play, MaxEnt RL) often fail catastrophically against humans (off-distribution play styles). AlphaStar required explicit league play with diverse exploiters; OpenAI Five required randomised opponent populations; Pluribus is poker-specific. No general recipe for human-robust multi-agent RL exists.
- **Sim-to-real game-to-live transfer** — RL agents trained in deterministic simulation often fail in production due to non-determinism (network lag, packet loss, server tick variance, race conditions). Live-service deployments require careful sim-real audit.
- **Evaluation** — game AI lacks the clean benchmarks of vision or NLP. Win-rate against humans is expensive and slow. Automated game-quality metrics (Engagement Index, Fun Curve) are crude. GVG-AI (General Video Game AI Competition, Simon Lucas / Diego Pérez-Liébana 2014-2022 IGGI affiliated) provides one shared benchmark for general game-playing AI. Procgen (OpenAI 2019), NetHack Learning Environment (Facebook 2020), and MineRL (Carnegie Mellon 2019-2022) provide RL benchmarks.

### Ethics, Labour, and Player Trust

- **Voice and likeness rights** — the SAG-AFTRA video-game performers' strike (July 2024 - June 2025, the longest in the union's history) centred on AI voice-replication consent, residual payments, and likeness protections. The Replica Studios SAG-AFTRA Tier-1 agreement (January 2024) and the eventual Interactive Media Agreement settlement (June 2025) establish that performer-supplied audio used to train AI voice models requires written consent, identifiable use disclosure, and per-project compensation. Independent voice actors (Steve Blum, Roger Clark, Jennifer Hale, Susan Eisenberg) have publicly objected to unconsented AI voice cloning circulating on social platforms (TikTok deepfake voice covers using actor voices for unlicensed content). UK Equity (the British performers' union) opened parallel negotiations with UK publishers Q4 2024.
- **Concept-artist labour** — community backlash against image-generation training data scraped from artist portfolios (LAION-5B controversy, *Andersen v. Stability AI* US federal case 2023-ongoing, *Getty Images v. Stability AI* High Court of Justice London 2023-ongoing) chills studio adoption of diffusion-model concept-art pipelines except via licensed datasets (Adobe Firefly, Shutterstock Generate, NVIDIA Picasso commercial-licence pools). Major UK studios (Rare, Sumo Digital, Creative Assembly, Sports Interactive, Rockstar North) have largely declined to publicly endorse Stable Diffusion-class tools for production art.
- **LLM NPC content safety** — risks include jailbreaking (player prompt-injection bypassing content filters to extract slurs, sexual content, or off-brand statements), hallucination (NPCs fabricating game lore that contradicts canon), prompt-injection from user-generated content (poisoned in-game text crafted by other players manipulating NPC behaviour), and brand-inappropriate output (NPCs endorsing competitors, making political statements, or generating defamatory content about real people). NVIDIA NeMo Guardrails, Inworld Safety, OpenAI Moderation API, and Anthropic Claude's Constitutional AI provide layered defences. Major incidents (e.g., a 2024 Roblox jailbreak incident allowing children to receive inappropriate AI responses) have intensified regulatory attention.
- **Children's online safety** — UK Online Safety Act 2023 (Category 1 services duties in force March 2025), UK Children's Code / ICO Age-Appropriate Design Code, and US COPPA all impose obligations on services interacting with under-13s. LLM NPCs raise novel issues: a fully-generative NPC cannot guarantee age-appropriate content the way a hand-authored dialogue tree can, and the Children's Code's "best interests of the child" standard suggests stricter age-gating may apply to AI-driven characters than to traditional NPCs.
- **Procedural fairness and competitive integrity** — RL-trained matchmaking bots that fill empty lobbies (used in League of Legends, Apex Legends, Halo Infinite) raise concerns about deceiving players into believing they are playing humans. Riot Games and Activision Blizzard disclose bot presence in beginner queues; full disclosure norms for live-service AI opponents are an emerging best practice.
- **Generative content moderation** — Steam's June 2024 disclosure policy requires AI-content disclosure on store pages. PEGI announced a consultation on AI-content rating criteria Q3 2024. ESRB has not formally updated its rubric but has indicated AI-generated content will be scored as the underlying content suggests rather than via a separate label. The EU AI Act (general-purpose AI provisions in force August 2025, full applicability August 2026) classifies certain generative game systems as limited-risk requiring transparency disclosures.

### Performance Engineering and Frame Budgets

- Real-time game AI is engineered to fit tight per-frame budgets. At 60 Hz the frame interval is 16.67 ms; subtracting render (typically 8-12 ms), physics (1-3 ms), audio (0.5-1 ms), animation (1-2 ms), and engine overhead leaves a typical AI budget of **0.5-2 ms per frame** for the entire AI subsystem covering all active NPCs. At 120 Hz (competitive shooters) the budget halves; at 90 Hz (VR) it is ~11.11 ms total with stricter consistency requirements (frame-time variance < 1 ms to avoid motion sickness).
- To fit, game AI uses several characteristic optimisations: **temporal amortisation** (LOD AI — NPCs further from the player run cheaper decision loops, e.g. 1 Hz vs 30 Hz update rates; aggressive distance-based deactivation), **spatial culling** (NPCs outside the player's region tick on streaming-cell loads only), **shared computations** (single navmesh query reused across squad members, shared blackboard observations), **frame-spreading** (a single behaviour-tree evaluation may be split across 2-4 frames for expensive NPCs), and **GPU offloading** (animation evaluation, particle simulation, flow-field pathfinding on GPU compute shaders).
- **LLM NPC latency budgets** are looser but still demanding. Conversational NPCs target 200-500 ms response latency for natural turn-taking; sub-100 ms achievable on-device with 7B-class models and speculative decoding (NVIDIA Inference Microservices RTX). Streaming token output reduces perceived latency by starting TTS as soon as the first sentence is produced (typical pipeline: ASR 100-200 ms → LLM first-token 200-500 ms → TTS first-audio 100-200 ms = 400-900 ms perceived latency). Production systems (Inworld, Convai, NVIDIA ACE) cache common responses, pre-compute embeddings of game lore for retrieval, and use distillation (e.g. Nemotron-Mini 4B-Instruct) for cost and latency reduction.

### Tooling and Authoring Ecosystem

- **Behaviour-tree authoring** — Behavior Designer (Unity, Opsive), NodeCanvas (Unity, Paradox Notion), Behavior Tree Editor (Unreal native), BeehaveBT and LimboAI (Godot), Bonsai (open-source). All provide visual node-based editors with debug-time inspection.
- **Dialogue authoring** — Yarn Spinner (Secret Lab, used in Night in the Woods, A Short Hike), Ink (Inkle, used in 80 Days, Heaven's Vault, Sorcery!), articy:draft (Nevigo), Chat Mapper, Twine (Chris Klimas, used in narrative games and prototyping), Dialogue System (Pixel Crushers Unity).
- **Animation and motion** — Motion Matching (Ubisoft proprietary, Unreal 5.4 plugin), Kinetica (Unity), DeepMotion, Cascadeur, Plask. Apple's RealityKit MotionMatching (visionOS 2.0 2024) brings motion matching to consumer XR.
- **Procedural-generation toolkits** — Houdini (SideFX, used by Far Cry, Ghost Recon, Spider-Man), World Machine (terrain), Gaea (QuadSpinner terrain), World Creator, Substance Designer (Allegorithmic / Adobe), Cascadeur (locomotion). Procedural-driven shipping titles: Spelunky 1 / 2 (Yu / BlitWorks), Hades (Supergiant), Slay the Spire (Mega Crit), Dwarf Fortress (Bay 12, with seven Northern English regional Steam fanbase clusters), Caves of Qud (Freehold Games), Brogue (Brian Walker / Pender), Cogmind (Grid Sage).
- **Automated QA** — Modl.ai (Copenhagen, 2018, IGGI alumna-founded, Series A €5M 2022), Regression Games (YC W23), GameDriver, Antithesis (deterministic-simulation testing). Activision's internal AI QA tools deployed across Call of Duty franchise pre-release testing.
- **Player-modelling and analytics** — Anodot, GameAnalytics (London-founded), deltaDNA (Sega), Unity Analytics, Helika (player AI insights), Mintegral / Liftoff Game Analytics. UK academic research in player modelling concentrated at York (Centre for Computer Game Studies), Goldsmiths, and IGGI alumni at Sports Interactive (player-style adaptation in Football Manager).

### Research & Literature

Key works and references underpinning the field:

1. **Yannakakis, G. N., & Togelius, J.** (2018, 2nd ed. 2025). *Artificial Intelligence and Games*. Springer. Free PDF at gameaibook.org. Canonical textbook.
2. **Millington, I., & Funge, J.** (2019). *Artificial Intelligence for Games*, 3rd edition. CRC Press.
3. **Rabin, S. (Ed.)** (2014, 2015, 2017, 2024). *Game AI Pro* volumes 1-4. CRC Press.
4. **Isla, D.** (2005). Handling Complexity in the Halo 2 AI. *Game Developers Conference / AIIDE*.
5. **Orkin, J.** (2006). Three States and a Plan: The AI of F.E.A.R. *Game Developers Conference*.
6. **Hart, P. E., Nilsson, N. J., & Raphael, B.** (1968). A Formal Basis for the Heuristic Determination of Minimum Cost Paths. *IEEE Transactions on Systems Science and Cybernetics*, 4(2), 100-107.
7. **Coulom, R.** (2006). Efficient Selectivity and Backup Operators in Monte-Carlo Tree Search. *Computers and Games 2006*.
8. **Silver, D., et al.** (2016). Mastering the Game of Go with Deep Neural Networks and Tree Search. *Nature*, 529, 484-489.
9. **Silver, D., et al.** (2017). Mastering the Game of Go Without Human Knowledge. *Nature*, 550, 354-359. (AlphaGo Zero)
10. **Silver, D., et al.** (2018). A General Reinforcement Learning Algorithm That Masters Chess, Shogi, and Go Through Self-Play. *Science*, 362(6419), 1140-1144. (AlphaZero)
11. **Schrittwieser, J., et al.** (2020). Mastering Atari, Go, Chess and Shogi by Planning with a Learned Model. *Nature*, 588, 604-609. (MuZero)
12. **Vinyals, O., et al.** (2019). Grandmaster Level in StarCraft II Using Multi-Agent Reinforcement Learning. *Nature*, 575, 350-354. (AlphaStar)
13. **OpenAI et al.** (2019). Dota 2 with Large Scale Deep Reinforcement Learning. *arXiv:1912.06680*. (OpenAI Five)
14. **Brown, N., & Sandholm, T.** (2019). Superhuman AI for Multiplayer Poker. *Science*, 365(6456), 885-890. (Pluribus)
15. **Meta FAIR Diplomacy Team** (2022). Human-Level Play in the Game of Diplomacy by Combining Language Models with Strategic Reasoning. *Science*, 378(6624), 1067-1074. (Cicero)
16. **Schulman, J., et al.** (2017). Proximal Policy Optimization Algorithms. *arXiv:1707.06347*. (PPO)
17. **Espeholt, L., et al.** (2018). IMPALA: Scalable Distributed Deep-RL with Importance Weighted Actor-Learner Architectures. *ICML*. 
18. **Hafner, D., et al.** (2025). Mastering Diverse Domains through World Models. *Nature*, 640, 647-653. (DreamerV3)
19. **Mnih, V., et al.** (2015). Human-Level Control through Deep Reinforcement Learning. *Nature*, 518, 529-533. (DQN)
20. **Juliani, A., et al.** (2018). Unity: A General Platform for Intelligent Agents. *arXiv:1809.02627*. (Unity ML-Agents)
21. **Summerville, A., et al.** (2018). Procedural Content Generation via Machine Learning (PCGML). *IEEE Transactions on Games*, 10(3), 257-270.
22. **Shaker, N., Togelius, J., & Nelson, M. J.** (2016). *Procedural Content Generation in Games*. Springer.
23. **Perlin, K.** (1985). An Image Synthesizer. *SIGGRAPH '85*.
24. **Gumin, M.** (2016). Wave Function Collapse Algorithm. GitHub mxgmn/WaveFunctionCollapse.
25. **Park, J. S., et al.** (2023). Generative Agents: Interactive Simulacra of Human Behavior. *UIST 2023*.
26. **Baker, B., et al.** (2022). Video PreTraining (VPT): Learning to Act by Watching Unlabeled Online Videos. *NeurIPS 2022*. (VPT Minecraft)
27. **Wang, G., et al.** (2023). Voyager: An Open-Ended Embodied Agent with Large Language Models. *arXiv:2305.16291*.
28. **Reynolds, C.** (1987). Flocks, Herds, and Schools: A Distributed Behavioral Model. *SIGGRAPH '87*. (Boids steering)

## Metadata

- **Domain**: artificial-intelligence
- **Legacy term ID**: AI-1421
- **IRI**: http://narrativegoldmine.com/artificial-intelligence#AiInGames
- **URI**: urn:visionclaw:concept:artificial-intelligence:ai-in-games
- **OWL class**: artificial-intelligence:AiInGames
- **OWL role**: AppliedAIField
- **Authority score**: 0.87
- **Quality score**: 0.52
- **Maturity**: production-ready
- **Version**: 2.1.0
- **Last enriched**: 2026-05-16
- **Notes**: IRI namespace upgraded from generic ontology# to artificial-intelligence# for namespace coherence with Phase 6 AI exemplars (Active Learning, AI Search, GANs). Domain artificial-intelligence retained as correct. AI-1421 legacy ID assigned per Phase 6 sequencing.

### Provenance

- Yannakakis & Togelius, *Artificial Intelligence and Games*, Springer 2018 / 2025; free at gameaibook.org
- Millington & Funge, *AI for Games*, CRC Press 3rd ed. 2019
- *Game AI Pro* volumes 1-4, ed. Steve Rabin, CRC Press 2014/2015/2017/2024
- Isla, *Handling Complexity in the Halo 2 AI*, GDC / AIIDE 2005
- Orkin, *Three States and a Plan: The AI of F.E.A.R.*, GDC 2006
- DeepMind AlphaGo / AlphaZero / MuZero / AlphaStar publications (Nature 2016/2017/2019/2020/2025)
- OpenAI Five technical report (arXiv 1912.06680, 2019)
- Brown & Sandholm Pluribus (Science 2019); Libratus (Science 2017)
- Meta FAIR Cicero Diplomacy (Science 2022)
- Schulman et al. PPO (arXiv 1707.06347, 2017)
- Hafner et al. DreamerV3 (Nature 2025)
- Unity ML-Agents (Juliani et al. arXiv 1809.02627, 2018)
- Recast & Detour open-source pathfinding library (Mikko Mononen 2009)
- Newzoo Global Games Market Report 2024 ($187.7B, 3.4B players)
- a16z Games + AI analysis November 2024
- NVIDIA GDC 2024 / GTC 2024 / Computex 2024 ACE announcements
- Inworld AI / Convai acquisition press July 2024
- NetEase Yiwen / Justice Mobile launch coverage June 2023
- Ubisoft NEO NPC tech demo GDC 2024
- Replica Studios SAG-AFTRA agreement January 2024
- SAG-AFTRA video-game strike July 2024 - June 2025 coverage
- DeepMind Genie 2 announcement December 2024
- Decart / Etched Oasis launch October 2024
- Tencent / HKUST GameGen-O NeurIPS 2024 paper
- Park et al. Generative Agents UIST 2023
- LARP: Language-Agent Role Play arXiv 2312.17653 (2023)
- IGGI EPSRC Centre for Doctoral Training in Intelligent Games and Game Intelligence — UCL / Essex / York
- UKIE Games Industry Snapshot 2024
- BFI / Creative UK Video Games Expenditure Credit guidance 2024
- Sumo Digital acquisition by Tencent August 2022
- EA acquisition of Codemasters February 2021
- **iri-correction-note:** IRI rewritten from generic ontology#AiInGames to artificial-intelligence#AiInGames for namespace coherence with Phase 6 AI exemplars (Active Learning, GANs, AI Search). domain:: artificial-intelligence retained (was already correct in original stub).

