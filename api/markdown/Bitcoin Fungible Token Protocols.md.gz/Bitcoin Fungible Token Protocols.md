Runes and Glyphs refers to two complementary Bitcoin token protocols: Runes, which encodes fungible token balances directly in Bitcoin transaction outputs using OP_RETURN data, and Glyphs, a related protocol developed by Melvin Carvalho that encodes token metadata as on-chain inscriptions compatible with the Ordinals framework. Together they extend Bitcoin's base layer with native fungible asset issuance without requiring a separate blockchain, enabling DAOs, project tokens, and programmable digital objects on Bitcoin testnet and mainnet.

### Semantic Classification

### Content

![the-future-of-bitcoin-2-tokens.pdf](assets/the-future-of-bitcoin-2-tokens_1723564035683_0.pdf)

- [Note by Melvin Carvalho (primal.net)](https://primal.net/e/note1rneeteg526e9e9zqrst35c93y46xlayzn77augvfhcsutq0d39qscga4xa) [[Bitcoin Fungible Token Protocols]]

![5882083039473943016.jpg](assets/5882083039473943016_1723118472953_0.jpg)

- [Note by Melvin Carvalho (primal.net)](https://primal.net/e/note1we622z6jpdl8xpuw2vy966ud8fgf0t40n009qxw3de4edc7gs55qrqldzp) [[Digital Objects]] [[Bitcoin Fungible Token Protocols]] [[Testnet]]
- [Testnet Glyph Explorer (testcoin.org)](https://testcoin.org/)
- [Art (npub.info)](https://pages.npub.info/glyphs/TESTNETARTAAA/)
- [flossverse/rustyGlyphs: based on Melvin Carvalho glyphs and Runes protocols (github.com)](https://github.com/flossverse/rustyGlyphs)

![photo_2024-08-14_00-40-13.jpg](assets/photo_2024-08-14_00-40-13_1723627663591_0.jpg)

- [jeasonstudio/runestone: 👁‍🗨 Ordinals runestone javascript implementation (github.com)](https://github.com/jeasonstudio/runestone) [[Bitcoin Fungible Token Protocols]]
- [jeasonstudio/runestone: 👁‍🗨 Ordinals runestone javascript implementation (github.com)](https://github.com/jeasonstudio/runestone) [[Bitcoin Fungible Token Protocols]]
- [Testcoin Glyph Explorer](https://testcoin.org/glyphs.html#) [[Melvin Carvalho Decentralised Web Advocate]] [[Testnet]] [[Bitcoin Fungible Token Protocols]]
- [glyph-protocol/glyphs: glyph protocol (github.com)](https://github.com/glyph-protocol/glyphs) [[Bitcoin Fungible Token Protocols]]
- [Testcoin Glyph Explorer](https://testcoin.org/glyphs.html#) [[Melvin Carvalho Decentralised Web Advocate]] [[Testnet]] [[Bitcoin Fungible Token Protocols]]
- [Runes Overview | Blockchain Analytics Dashboard (geniidata.com)](https://geniidata.com/user/Runes_is/runes-overview) [[Bitcoin Fungible Token Protocols]]

# DAO

- Every project, every bot, can be a DAO
- [UniSat](https://unisat.io/runes/market?tick=WORK%E2%80%A2IN%E2%80%A2PROGRESS)

### Provenance

