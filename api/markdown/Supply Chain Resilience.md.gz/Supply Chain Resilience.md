Supply chain resilience is the ability of a supply chain to return to its original state, or move to a new and more desirable one, after being disturbed.[^1]

That wording is the one Christopher and Peck adopt for supply chains: resilience is “the ability of a system to return to its original state or move to a new, more desirable state after being disturbed”, with flexibility implicit in it and adaptability added because the desired state may differ from the original.[^1] The White House 100-day review gives a shorter wording: a resilient supply chain is one that recovers quickly from an unexpected event.[^2] The two agree on recovery after disturbance, and only the first allows a changed end state.

## What builds it

The Center for Climate and Energy Solutions says that current resilience frameworks emphasize visibility, flexibility, contingency and collaboration but often overlook climate-specific risks.[^3] Christopher and Peck add that resilience will be enhanced, and indeed made possible, by a risk management culture in the organisation.[^1] The UK Climate Change Committee summarises adaptation actions that can build resilience and maintain functioning supply chains.[^4]

At the level of national policy, the World Trade Organization argues that recent experience has demonstrated how deep and diversified international markets help countries cope with unanticipated shortages by securing supplies from alternative sources.[^5]

## Scope and distinctions

Resilience is the capacity; the actions to build it are collected at [[Supply Chain Resilience Strategy]], and the process that manages the underlying exposure is [[Supply Chain Risk Management]]. Recovery speed is measured by [[Time to Recover]]. Related buffers and sourcing choices are [[Supply Chain Redundancy]] and [[Supplier Diversification]].

## What the sources do not establish

None of the sources supplies a standard measure of resilience, and the two definitions come from a 2004 research paper and a 2021 policy report, not from a standards body.

[^1]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^2]: The White House, report under Executive Order 14017, June 2021, “Building Resilient Supply Chains, Revitalizing American Manufacturing, and Fostering Broad-Based Growth: 100-Day Reviews under Executive Order 14017”. https://bidenwhitehouse.archives.gov/wp-content/uploads/2021/06/100-day-supply-chain-review-report.pdf
[^3]: Center for Climate and Energy Solutions (C2ES), September 2025, “Assessing the Landscape of Climate Risk and Supply Chain Resilience: A Primer for Corporate Leaders and Climate Risk Professionals”. https://www.c2es.org/wp-content/uploads/2025/09/Climate-Risk-and-Supply-Chain-Report_FINAL_v3.pdf
[^4]: UK Climate Change Committee, “Resilient Supply Chains (briefing, 2022)”. https://www.theccc.org.uk/wp-content/uploads/2022/10/Resilient-Supply-Chains-.pdf
[^5]: World Trade Organization, “World Trade Report 2023: Re-globalization for a secure, inclusive and sustainable future”. https://www.wto.org/english/res_e/booksp_e/wtr23_e/wtr23_e.pdf

