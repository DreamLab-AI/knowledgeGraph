
A human agent is an agent that is a person. The Agent Ontology declares it as `Person` in its agent module, a subclass of the core `Agent` with the label "Person" and the comment "An agent that is a human."[^1]

The ontology adds no properties specific to `Person`. It inherits whatever applies to [[Agent]], such as having an identity, a profile, capabilities, intents and tasks. Its sibling is [[Organisational Agent]], declared in the same module as an agent that is an organisation.

The schema.org mapping module aligns `Person` with `schema:Person` through `rdfs:subClassOf`.[^2] That mapping is a declared alignment in the ontology, not a statement about adoption by any other system.

The class matters because the ontology does not reserve the agent role for software. The core definition of an agent is an "autonomous actor", and the agent module places people and organisations in the same hierarchy, so delegation and task relations can be stated uniformly across human and non-human actors.[^3]

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl
[^2]: Semantic Agent Communication Community Group, “Agent Ontology to Schema.org Mapping” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/schema-org-mapping.ttl
[^3]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl

