A fulfilment centre is a distribution centre that receives and fills small orders from individual customers, shipping them immediately after receipt.[^1]

Georgia Tech's open textbook describes a catalog fulfillment or e-commerce distribution center as one that typically receives small orders from individuals by phone, fax or the Internet. Orders are typically small, for only one to three items, but there may be many of them, and they are to be filled and shipped immediately after receipt.[^1]

## Naming

An eCampusOntario logistics text says the name a company chooses to call its warehouses may vary, and gives the example of Amazon, which refers to its warehouses and distribution centers as fulfillment centers.[^2] The same text lists the steps in an Amazon fulfillment centre as receive, stow, pick, flow, pack, scan-label-apply-manifest and ship. Stow scans the product, checks it for damage and places it in storage, and pick retrieves the product from where it is stored, which begins outbound operations.[^2]

## Context

A review of operations and supply chain management says e-commerce and omnichannel retailing have transformed warehouses from a marginal element to a mission-critical supply chain stage.[^3] The review also notes that batching groups multiple customer orders into extended pick lists and zoning partitions a warehouse into smaller zones, techniques used to reduce travel when orders are small.[^3] See [[Order Picking]].

## Scope and distinctions

A fulfilment centre is a kind of [[Distribution Centre]]. The corpus page [[Order Fulfilment]] covers the order process as a whole, and [[Omnichannel Fulfilment]] covers fulfilment across channels; this page covers the facility.

## What the sources do not establish

Sources do not say how a fulfilment centre differs physically from other distribution centres, and the Amazon process is the operator's own description as given in a teaching text.[^2]

[^1]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^2]: eCampusOntario Pressbooks (Introduction to Logistics), “Chapter 5 – Warehousing”. https://ecampusontario.pressbooks.pub/logistics001oerfc/chapter/chapter-5-warehousing/
[^3]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

