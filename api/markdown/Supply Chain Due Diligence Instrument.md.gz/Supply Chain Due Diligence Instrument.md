A supply chain due diligence instrument is a law, regulation or standard that sets out the duties of companies to identify and address adverse impacts in their supply chains, and the instruments described here differ in subject, in who they bind and in what they require.[^1][^2]

## Instruments in the sources

Directive (EU) 2024/1760 lays down rules on obligations for companies regarding actual and potential human rights and environmental adverse impacts, in their own operations, those of their subsidiaries and those of business partners in their chains of activities, together with liability for violations and an obligation to adopt a climate transition plan.[^1] See [[Corporate Sustainability Due Diligence Directive]].

Regulation (EU) 2023/1115 prohibits the placing on the market or export of relevant commodities and products unless they are deforestation-free, produced in accordance with the legislation of the country of production, and covered by a due diligence statement.[^3] Regulation (EU) 2017/821 establishes a Union system for supply chain due diligence for importers of tin, tantalum, tungsten and gold.[^4] See [[Deforestation-Free Sourcing]] and [[Responsible Minerals Sourcing]].

In the United Kingdom, Schedule 17 of the Environment Act 2021 requires a regulated person using a forest risk commodity to establish and implement a due diligence system.[^5] Section 54 of the Modern Slavery Act 2015 requires a covered commercial organisation to prepare an annual statement of the steps it has taken to ensure slavery and human trafficking is not taking place in its supply chains.[^6]

The UN Guiding Principles on Business and Human Rights are a standard, not a law; they say business enterprises should carry out human rights due diligence.[^2]

## Differences

The EU instruments bind companies placing products on the Union market or covered companies, and add liability or market-access conditions. The UK Modern Slavery Act duty is disclosure. The Guiding Principles are principles, not legislation. The OECD Due Diligence Guidance, which several of these instruments reference, is described at [[OECD Due Diligence Guidance]].

## Scope and limits

This list is not complete: the German Supply Chain Due Diligence Act and other national laws were not opened. The page describes the texts as published, not their later amendment or enforcement, and the Official Journal text of the directive was opened as published in 2024. The parent concept is [[Supply Chain Due Diligence]].

[^1]: European Parliament and Council of the European Union, Directive (EU) 2024/1760 of 13 June 2024, “Directive (EU) 2024/1760 of the European Parliament and of the Council on corporate sustainability due diligence”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202401760
[^2]: United Nations Office of the High Commissioner for Human Rights, HR/PUB/11/4, 2011, “Guiding Principles on Business and Human Rights: Implementing the United Nations “Protect, Respect and Remedy” Framework”. https://www.ohchr.org/sites/default/files/documents/publications/guidingprinciplesbusinesshr_en.pdf
[^3]: European Parliament and Council of the European Union, Regulation (EU) 2023/1115 of 31 May 2023, “Regulation (EU) 2023/1115 of the European Parliament and of the Council on the making available on the Union market and the export from the Union of certain commodities and products associated with deforestation and forest degradation”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32023R1115
[^4]: European Parliament and Council of the European Union, Regulation (EU) 2017/821 of 17 May 2017, “Regulation (EU) 2017/821 of the European Parliament and of the Council laying down supply chain due diligence obligations for Union importers of tin, tantalum and tungsten, their ores, and gold originating from conflict-affected and high-risk areas”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32017R0821
[^5]: UK Parliament, Environment Act 2021, Schedule 17, “Environment Act 2021, Schedule 17: Forest risk commodities”. https://www.legislation.gov.uk/ukpga/2021/30/schedule/17
[^6]: UK Parliament, Modern Slavery Act 2015, section 54, “Modern Slavery Act 2015, section 54: Transparency in supply chains etc”. https://www.legislation.gov.uk/ukpga/2015/30/section/54

