A sector supply chain is a supply chain considered by the industry or product group it serves, such as food, medical or semiconductor supply chains.[^1][^2]

No source opened defines the phrase. The OECD observes that supply chain initiatives generally focus on specific sectors identified as critical or strategic, and describes measures in three: medical supply chains, critical raw materials for the green transition, and semiconductors.[^1] The European Parliament study on reshoring has a section on sector-specific potentials for reshoring, with case studies of pharmaceuticals, medical products, semiconductors and solar energy.[^2] The UK Food Security Report treats the food supply chain as built on a set of interdependent sectors.[^3]

## Scope and distinctions

Pages in the corpus that treat a single industry are children of this one, including [[Food Supply Chain]], [[Pharmaceutical Supply Chain]], [[Semiconductor Supply Chain]], [[Space Supply Chain]] and [[GPU Supply Chain]]. On medical supply chains, the OECD says resilience strategies after COVID-19 combined increased monitoring, coordination, diversification and a shift to local production.[^1] On semiconductors, it says the industry experienced recurrent shortages in 2020-2023 with root causes not limited to the pandemic and the war in Ukraine.[^1] The UK report names the Russian invasion of Ukraine as one external shock to the food chain, and looks at risks across its sectors in areas that include input dependencies, such as agricultural inputs, labour and skills, water and energy, and the movement of goods including import flows.[^3]

## What the sources do not establish

Evidence for this page is thin: the sources show that analysis is organised by sector, but none gives a definition or a rule for dividing supply chains into sectors.[^1][^2][^3]

[^1]: OECD, report on supply chain resilience, “Promoting resilience and preparedness in supply chains”. https://www.oecd.org/content/dam/oecd/en/publications/reports/2024/11/promoting-resilience-and-preparedness-in-supply-chains_c0320739/be692d01-en.pdf
[^2]: European Parliament, Policy Department for External Policies (study requested by the INTA committee), “Post Covid-19 value chains: options for reshoring production back to Europe in a globalised economy”. https://www.europarl.europa.eu/RegData/etudes/STUD/2021/653626/EXPO_STU(2021)653626_EN.pdf
[^3]: UK Department for Environment, Food and Rural Affairs, Official Statistics, “United Kingdom Food Security Report 2024: Theme 3: Food Supply Chain Resilience”. https://www.gov.uk/government/statistics/united-kingdom-food-security-report-2024/united-kingdom-food-security-report-2024-theme-3-food-supply-chain-resilience

