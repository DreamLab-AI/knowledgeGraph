An automated storage and retrieval system, or AS/RS, is a warehousing system that uses mechanised devices to store and retrieve loads in racks.[^1][^2]

A CIRRELT literature review describes such systems as using mechanised devices to accomplish the repetitive tasks of storing and retrieving parts in racks, and says that because they represent a significant investment and considerable operating costs their use must be as efficient as possible.[^1] The abstract of a survey by Roodbergen and Vis describes them as warehousing systems used for the storage and retrieval of products in both distribution and production environments.[^2]

## Form and operation

Georgia Tech's open textbook says AS/RS devices remove humans by placing a simple robotic device within each aisle, which moves horizontally and vertically to convey product to or from storage. They are typically used to store and retrieve unit loads, and because each one represents significant capital investment and is fairly inflexible, it is important to understand their capabilities, especially throughput.[^3] The 2007 literature review describes systems using mostly aisle-bound cranes that retrieve one or more unit loads, pallets or bins, and bring them to a pick position.[^4] A review of operations and supply chain management describes the traditional form as a crane-operated high-bay rack and lists carousels, vertical lift modules, puzzle-based, deep-lane and shuttle-based systems among its relatives.[^5]

## Scope and distinctions

An AS/RS is a [[Warehouse Storage System]] and a basis for [[Goods-to-Person Picking]]. See also [[Logistics Automation]]. The Roodbergen and Vis abstract says most reviewed models apply only to static scheduling and design problems.[^2]

## What the sources do not establish

Full text of the Roodbergen and Vis survey was not opened. The sources give no figures for installed systems or costs.

[^1]: Jean-Philippe Gagliardi, Jacques Renaud and Angel Ruiz, CIRRELT working paper CIRRELT-2010-58, December 2010, “Simulation Modeling Approaches for Automated Storage and Retrieval Systems – A Literature Review”. https://www.cirrelt.ca/DocumentsTravail/CIRRELT-2010-58.pdf
[^2]: Kees Jan Roodbergen and Iris F. A. Vis, European Journal of Operational Research 194(2), 2009 (Erasmus repository abstract record), “A survey of literature on automated storage and retrieval systems”. https://repub.eur.nl/pub/13640
[^3]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^4]: René de Koster, Tho Le-Duc and Kees Jan Roodbergen, European Journal of Operational Research 182(2), 2007, “Design and control of warehouse order picking: A literature review”. https://pure.eur.nl/ws/portalfiles/portal/46713708/DesignandControl_2007.pdf
[^5]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

