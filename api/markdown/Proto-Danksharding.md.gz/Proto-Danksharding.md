Proto-danksharding is an Ethereum scaling upgrade, specified in EIP-4844, that introduces blob-carrying transactions to provide cheap, temporary data availability for layer-2 rollups. It adds a new transaction type carrying large binary data blobs that are not accessible to the Ethereum Virtual Machine and are pruned after a short retention period, with KZG commitments proving their contents. It is an incremental step towards the full danksharding design.

### Overview

- Proto-danksharding addresses the dominant cost driver for Ethereum rollups: the price of posting compressed transaction data to the base layer. By introducing blobs, large data payloads that are committed to via KZG polynomial commitments but pruned after roughly a few weeks, it provides ample, low-cost data availability without bloating permanent state. The design deliberately establishes the transaction format and fee market that full danksharding will later scale across many blobs.

### Key aspects

- Blob-carrying transactions add a new data lane separate from EVM-accessible calldata.
- KZG polynomial commitments allow blob contents to be verified without storing the full data permanently.
- Blobs are retained only briefly, keeping long-term storage requirements bounded.
- A separate fee market for blob space decouples rollup data costs from execution-layer gas.

### Applications

- Reducing the cost for rollups to post data to Ethereum.
- Increasing layer-2 throughput and lowering end-user transaction fees.
- Providing a stepping stone toward full danksharding and data-availability sampling.
- Strengthening the security of rollups by anchoring data availability to the base layer.

### Provenance

