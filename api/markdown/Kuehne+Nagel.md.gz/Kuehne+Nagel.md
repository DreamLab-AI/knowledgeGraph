Kuehne+Nagel is a freight forwarding and logistics group headquartered in Switzerland. Its own site says that in 1890 August Kuehne and Friedrich Nagel founded a freight forwarding company in Bremen, Germany, and that Kuehne+Nagel is today headquartered in Switzerland with a presence all over the world.[^1]

## Independent description

The European Commission described the group in a 2018 decision on a logistics technology joint venture as a globally active logistics company with main activities in sea freight, airfreight and overland forwarding as well as contract logistics.[^2] That agrees with the company's own account of a business that began as a freight forwarder and now serves major industries worldwide, which the company describes as an evolution from a traditional shipping company to a global logistics partner.[^1][^2]

Kuehne+Nagel's own page also says that it is proud to be recognised as a leader in the 2025 Gartner Magic Quadrant for Third-Party Logistics Providers, which is the company's report of an analyst's assessment and which was not checked against the Gartner report; it does show that the group presents itself as a third-party logistics provider.[^1]

## Role in the supply chain

Kuehne+Nagel is a [[Freight Forwarder]] in this vault. The Commission's list of activities also includes contract logistics, which the vault places under [[Third-Party Logistics Provider]], so the group holds more than one logistics service provider role.

## What the sources do not establish

Sources give no revenue, staff or ranking figures that were checked independently. The company's own page contains customer and recognition claims that are not repeated here. The history is told only by the company, because the Commission decision describes activities and not origins.[^1][^2]

[^1]: Kuehne+Nagel, About Kuehne+Nagel page. https://www.kuehne-nagel.com/company/about
[^2]: European Commission, Case M.9001 Kuehne + Nagel / Temasek / JV, decision of 24 July 2018. https://ec.europa.eu/competition/mergers/cases/decisions/m9001_54_3.pdf

