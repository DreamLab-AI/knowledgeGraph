Scaling Laws are empirical power-law relationships describing how the performance of neural networks — typically measured as held-out cross-entropy loss — varies predictably as a function of model parameters (N), training data volume (D), and total compute budget (C). Foundational Kaplan et al. (2020) work established smooth, predictable loss curves across many orders of magnitude, while Hoffmann et al. (2022) Chinchilla analyses refined optimal compute allocation to roughly equal scaling of model size and training tokens. These relationships guide architectural decisions, compute budgeting, and capability forecasting for large foundation models. Scaling laws have since been extended beyond language modelling to vision transformers, multimodal architectures, and reinforcement learning from human feedback.

### Overview

- Scaling Laws emerged from systematic empirical investigations showing that neural network loss does not decrease arbitrarily or unpredictably as models grow — it follows smooth, regular curves across many orders of magnitude of scale.
- The canonical form expresses loss as a power function: L(N) ≈ A/N^α, L(D) ≈ B/D^β, and L(C) ≈ C'/C^γ, where α, β, and γ are empirically estimated exponents typically in the range 0.05–0.3 depending on the domain.
- Crucially, compute-optimal analyses (the "Chinchilla" paradigm) demonstrated that many earlier flagship models were significantly undertrained: given a fixed compute budget, the optimal strategy allocates compute roughly equally between model size and number of training tokens, rather than maximising parameters alone.
- Scaling Laws matter because they allow practitioners to predict, rather than merely discover, how good a model will be before committing to expensive training runs — enabling rigorous [[AI Infrastructure Planning]] and [[Capability Forecasting]].
- The regularity of scaling laws is sometimes disrupted by "grokking" phenomena, phase transitions, and the appearance of [[Emergent Abilities]] — capabilities that arise abruptly and non-linearly at sufficiently large scales — which remain active research frontiers.

### Key Mechanisms

- **Parameter Scaling (N axis)**
  - Loss decreases as a power law of the number of trainable parameters N, holding compute and data fixed.
  - The relationship saturates when model capacity exceeds what the training data can support, leading to [[Overfitting]] or wasted capacity.
  - Used to determine minimum viable model size for a target loss on a given domain.
- **Data Scaling (D axis)**
  - More [[Training Data]] reduces loss along a parallel power-law curve.
  - Chinchilla-style analyses show D and N must scale together: optimal N ∝ C^0.5 and D ∝ C^0.5 for a given compute budget C.
  - [[Data Efficiency]] becomes critical when high-quality data is scarce — motivating synthetic data generation and [[Data Curation]] techniques.
- **Compute Scaling (C axis)**
  - Total FLOPs consumed during training ≈ 6ND for a standard [[Transformer Architecture]] training run.
  - The C-optimal frontier identifies (N*, D*) pairs that minimise loss for each compute budget.
  - Used by labs to decide when to invest in additional [[Pre-Training]] versus investing in [[Fine-Tuning]] or [[Post-Training Alignment]].
- **Irreducible Loss (L∞)**
  - All empirical scaling laws asymptote to an irreducible floor, reflecting the inherent entropy of the data-generating distribution.
  - [[Irreducible Loss]] quantifies the information-theoretic ceiling on compression achievable by the model.
- **Power Law Exponents**
  - The precise exponents α, β, γ vary by architecture, tokenisation scheme, domain, and training procedure.
  - Estimating these exponents from small-scale "scaling runs" before committing full compute is a standard industrial practice.
  - Architectural improvements (e.g., attention variants, sparse mixtures) can shift the scaling coefficient without changing the exponent.

### Applications and Use Cases

- **Pre-training Budget Allocation**
  - Research labs use compute-optimal formulae derived from scaling laws to allocate GPU-hours between model size and training tokens before launching large training runs.
  - Informs decisions such as the choice between training one large [[Foundation Model|foundation model]] or several smaller specialist models.
- **Model Selection and Deployment**
  - Scaling law extrapolations guide decisions about whether a planned model will achieve target downstream performance at acceptable inference cost.
  - Supports trade-offs between [[Model Compression]] (distillation, quantisation) and further [[Pre-Training]].
- **Capability Forecasting**
  - Governments, safety organisations, and AI labs use scaling law projections to anticipate when models may reach capability thresholds relevant to [[AI Safety]] and governance.
  - Informing policy discussions about compute governance, export controls on [[AI Hardware]], and frontier model evaluation requirements.
- **Architecture Research**
  - [[Neural Architecture Search]] and ablation studies use scaling laws to distinguish genuine architectural gains (shifting the coefficient) from those that merely track overall parameter count.
  - Mixture-of-Experts architectures have been specifically designed to achieve better scaling coefficients by decoupling parameter count from active compute per token.
- **Domain-Specific Extensions**
  - Vision: [[Vision Transformers]] obey similar N- and D-scaling laws, enabling principled scaling of image recognition and generation systems.
  - Code: Coding models show faster loss decay per parameter than natural language, suggesting domain-specific scaling coefficients.
  - Multimodal: [[Multimodal Model]] exhibit compound scaling laws across modalities, with cross-modal interactions creating more complex Pareto frontiers.
  - Reinforcement Learning: Policy gradient methods and [[Reinforcement Learning from Human Feedback]] show scaling with environment interactions and reward model quality, though the functional forms are less settled.

### Standards and Context

- No formal standards body governs scaling law methodology; practices are established by community consensus through peer-reviewed publications and replication studies.
- Influential foundational works include the OpenAI Kaplan et al. (2020) paper ("Scaling Laws for Neural Language Models") and the DeepMind Hoffmann et al. (2022) Chinchilla paper, both of which have been widely replicated and extended.
- The [[MLCommons]] benchmarking ecosystem indirectly standardises training conditions that underpin reproducible scaling measurements.
- AI governance bodies (e.g., US NIST AI RMF, EU AI Act compute thresholds) increasingly reference scaling-law-derived capability thresholds when defining frontier model categories subject to enhanced oversight.
- Academic benchmarks such as [[BIG-Bench]] and [[HELM]] are used to validate scaling law predictions against downstream task performance, bridging empirical loss metrics to practical capability assessments.
- Debate continues about whether scaling laws are universal physical laws, emergent statistical artefacts of gradient descent, or simply useful approximations that may break down at extreme scale or under distribution shift.

### Key Distinctions

- **Scaling Laws vs [[Emergent Abilities]]**: Scaling laws describe smooth, predictable loss curves; emergent abilities appear as sharp, discontinuous capability jumps on specific benchmarks. These two phenomena may co-exist — emergence may reflect the crossing of loss thresholds that appear sharp only when evaluated on discrete tasks.
- **Compute-Optimal vs Parameter-Efficient**: Compute-optimal scaling (Chinchilla) maximises performance per FLOP during training; parameter-efficient methods (e.g., [[LoRA]], [[Adapter Tuning]]) maximise performance per parameter at inference, creating a two-phase optimisation landscape.
- **Scaling vs [[Architecture Search]]**: Scaling laws characterise performance at fixed architecture; architectural innovations that shift the power-law coefficient are orthogonal to, and compound with, scale benefits.

### Provenance

