An agile supply chain is one able to respond rapidly to changes in demand in both volume and variety, suited to volatile and unpredictable markets where availability is the order winner.[^1][^2][^3]

Christopher offers this reading of agility: the ability of an organisation to respond rapidly to changes in demand, both in volume and in variety.[^1] Christopher and Towill quote Naylor and colleagues for a second wording, that agility means using market knowledge and a virtual corporation to exploit profitable opportunities in a volatile marketplace, and describe agility as a business-wide capability covering organisational structures, information systems, logistics processes and mindsets.[^2] Mason-Jones, Naylor and Towill state in their abstract that agile manufacturing is adopted where demand is volatile.[^3]

## Characteristics

Christopher lists distinguishing features of an agile chain. It is market sensitive, meaning it can read and respond to real demand rather than only forecasts.[^1] It aims to hold inventory in a generic form, such as standard semi-finished products awaiting final assembly or localisation, which is the concept of [[Postponement]].[^1] It uses lean methods up to the decoupling point and agile methods beyond it, and Christopher distinguishes a material decoupling point, which ideally lies as far downstream as possible, from an information decoupling point, which lies as far upstream as possible.[^1] He adds that managing the two points can reduce the bullwhip effect.[^1] See also [[Customer Order Decoupling Point]] and [[Bullwhip Effect]].

## Scope and distinctions

Agility should not be confused with leanness, in Christopher's words.[^1] Cost is the market winner for lean supply but only an important qualifier for agile supply, where availability wins orders.[^2] The two are not mutually exclusive and may be combined, for example as the “Leagile Paradigm” of Mason-Jones and colleagues.[^2][^3] See [[Lean Supply Chain]].

Sources do not fix the relationship to [[Responsive Supply Chain]]. Christopher says survival in volatile markets depends on agility, in particular on the creation of responsive supply chains, so he treats responsiveness as the means and agility as the capability.[^1] Fisher uses market-responsive for a chain matched to “innovative products” and mentions agile manufacturing only in a list of new concepts, without defining it.[^4]

## What the sources do not establish

Agreement among these sources is weaker evidence than it looks, because they come largely from one research community, the Cranfield and Cardiff logistics groups. The Cardiff record is an abstract, not the full paper. None of the sources gives a measure of agility or evidence of how widely the definitions are shared outside that community.

[^1]: Martin Christopher, Industrial Marketing Management, 2000 (Cranfield repository copy), “The Agile Supply Chain : Competing in Volatile Markets”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/3e60f75d-28c1-4659-a260-6608c0e863f2/content
[^2]: Martin Christopher and Denis Towill, International Journal of Physical Distribution and Logistics Management, 2001 (Cranfield repository copy), “An Integrated Model for the Design of Agile Supply Chains”. https://dspace.lib.cranfield.ac.uk/bitstreams/db14daf6-8518-476e-9211-b6af2f1515a5/download
[^3]: Rachel Mason-Jones, Ben Naylor and Denis R. Towill, International Journal of Production Research, 2000 (Cardiff Metropolitan University record, abstract only), “Lean, agile or leagile? Matching your supply chain to the marketplace”. https://pure.cardiffmet.ac.uk/en/publications/lean-agile-or-leagile-matching-your-supply-chain-to-the-marketpla/
[^4]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf

