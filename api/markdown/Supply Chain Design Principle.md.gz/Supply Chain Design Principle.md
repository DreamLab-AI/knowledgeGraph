A supply chain design principle is a structural rule of thumb for how a supply chain is built so that it meets the demand it faces. No source opened here defines the term, so this page is bounded by the principles that individual sources state for themselves.[^1][^2][^3]

## Principles stated in the sources

Match the chain to the product. Fisher argues that the root cause of many supply chain problems is a mismatch between the type of product and the type of chain, and that a physically efficient chain suits functional products while a market-responsive chain suits “innovative” ones.[^1]

Match the strategy to the uncertainty. Lee's abstract says companies need first to understand the uncertainties faced by the demand and supply of their products and then match them with the right supply chain strategies.[^2]

Place a decoupling point and change strategy across it. Mason-Jones, Naylor and Towill propose using “a different paradigm on either side of the material flow de-coupling point”, an approach they call the “Leagile Paradigm”.[^4] Christopher puts it as lean strategies up to the decoupling point and agile strategies beyond it, with the material point as far downstream as possible and the information point as far upstream as possible.[^3] See [[Customer Order Decoupling Point]].

Postpone differentiation. Christopher recommends carrying inventory in a generic form, standard semi-finished products awaiting final assembly or localisation, a concept he calls postponement and a vital element of an agile strategy.[^3] Fisher's table likewise lists modular design that postpones product differentiation for as long as possible as a feature of the responsive chain.[^1] See [[Postponement]].

Segment the product range. Christopher and Towill suggest that the products which generate most of the volume are likely to be more predictable and suit lean methods, and that the remainder should be managed differently, with agile methods.[^5] See [[Supply Chain Segmentation]].

## Scope and distinctions

These principles overlap with [[Supply Chain Strategy Type]], which names the postures, and with [[Supply Chain Network Design]], which decides where the facilities go. Christopher also reports that managing the two decoupling points can reduce the bullwhip effect, linking design to [[Bullwhip Effect]].[^3]

## What the sources do not establish

This is the thinnest page in its branch. Its principles come from a small group of management papers, and the Lee article was available only as an abstract. No source opened here lists design principles as a set, ranks them, or tests them against one another. The Cranfield and Cardiff papers cited share a research community, so their agreement is weaker evidence than the number of citations suggests.[^3][^5][^4]

[^1]: Marshall L. Fisher, Harvard Business Review, March-April 1997 (reprint hosted by the University of Patras), “What Is the Right Supply Chain for Your Product?”. https://eclass.upatras.gr/modules/document/file.php/MECH1277/%CE%95%CE%A1%CE%93%CE%91%CE%A3%CE%99%CE%95%CE%A3-PAPERS%20%CE%91%CE%9D%CE%9F%CE%99%CE%9E%CE%97%202024/2-Right%20Supply%20Chain%20B.pdf
[^2]: Hau L. Lee, California Management Review, Spring 2002 (abstract page), “Aligning Supply Chain Strategies with Product Uncertainties”. https://cmr.berkeley.edu/2002/05/44-3-aligning-supply-chain-strategies-with-product-uncertainties/
[^3]: Martin Christopher, Industrial Marketing Management, 2000 (Cranfield repository copy), “The Agile Supply Chain : Competing in Volatile Markets”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/3e60f75d-28c1-4659-a260-6608c0e863f2/content
[^4]: Rachel Mason-Jones, Ben Naylor and Denis R. Towill, International Journal of Production Research, 2000 (Cardiff Metropolitan University record, abstract only), “Lean, agile or leagile? Matching your supply chain to the marketplace”. https://pure.cardiffmet.ac.uk/en/publications/lean-agile-or-leagile-matching-your-supply-chain-to-the-marketpla/
[^5]: Martin Christopher and Denis Towill, International Journal of Physical Distribution and Logistics Management, 2001 (Cranfield repository copy), “An Integrated Model for the Design of Agile Supply Chains”. https://dspace.lib.cranfield.ac.uk/bitstreams/db14daf6-8518-476e-9211-b6af2f1515a5/download

