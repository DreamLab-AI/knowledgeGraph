A supply chain configuration decision is a choice about how the operations of a supply chain are arranged, including what a firm makes and what it buys, and where its facilities and sources are located.[^1][^2]

No opened source defines the phrase itself. Melo, Nickel and Saldanha da Gama write that part of supply chain planning aims at finding the best possible supply chain configuration so that all operations can be performed efficiently, and that facility location has to be considered together with procurement, production, inventory, distribution and routing.[^1] Medina-Serrano and colleagues describe the make-or-buy decision as the choice between designing and manufacturing parts or services in-house, buying them from external providers, or combining both.[^2]

## Ownership and location

Eurostat defines sourcing as the total or partial movement of core or support business functions currently performed in-house to external suppliers or affiliated enterprises, located domestically or abroad.[^3] The OECD lists three geographic options for de-risking supply chains: friend-shoring, which is trading with allies or like-minded countries, near-shoring, which involves relocating operations in nearby countries, and re-shoring, which repatriates supply chain nodes. It adds that the concept of de-risking emphasises diversification without fully abandoning sourcing from countries identified as high-risk.[^4]

Child pages are [[Outsourcing]], [[Offshoring]], [[Nearshoring]], [[Reshoring]] and [[Friendshoring]]. See also [[Supply Chain Strategy]] and [[Supply Chain Network Design]].

## What the sources do not establish

Sources use different words for overlapping choices, and Eurostat itself notes that international sourcing is sometimes called off-shoring, near-shoring, delocalisation or outsourcing.[^3] The grouping on this page is an editorial one, assembled from sources that each treat one part of it.[^1][^2][^4]

[^1]: Fraunhofer ITWM (Melo, Nickel and Saldanha da Gama), report version of a review of facility location and supply chain management, “Facility Location and Supply Chain Management - A comprehensive review”. https://kluedo.ub.rptu.de/files/1985/bericht130.pdf
[^2]: Ruben Medina-Serrano and colleagues, Journal of Industrial Engineering and Management, 2020, “Strategic Sourcing: Developing a Progressive Framework for Make-Or-Buy Decisions”. https://jiem.org/index.php/jiem/article/download/2858/922
[^3]: Eurostat, Statistics Explained glossary entry, “Glossary:Sourcing”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Sourcing
[^4]: OECD, report on supply chain resilience, “Promoting resilience and preparedness in supply chains”. https://www.oecd.org/content/dam/oecd/en/publications/reports/2024/11/promoting-resilience-and-preparedness-in-supply-chains_c0320739/be692d01-en.pdf

