The Corporate Sustainability Due Diligence Directive, Directive (EU) 2024/1760, lays down rules requiring companies to address actual and potential human rights and environmental adverse impacts in their own operations, those of their subsidiaries and those of their business partners in their chains of activities.[^1]

## 2024 text

The Directive as published in 2024 lays down rules on obligations for companies regarding those adverse impacts, on liability for violations of the obligations, and on the obligation to adopt and put into effect a transition plan for climate change mitigation.[^1] It requires Member States to ensure that companies conduct risk-based human rights and environmental due diligence, including integrating due diligence into their policies and risk management systems and identifying and assessing actual or potential adverse impacts.[^1] The chain of activities covers activities of upstream business partners related to the production of goods or the provision of services, from design and sourcing to transport, storage and supply of raw materials and products.[^1]

## Amendment by the Omnibus I initiative

The European Commission records that the Directive entered into force on 25 July 2024 and has since been amended by the Omnibus I simplification initiative, including Directives (EU) 2025/794 and (EU) 2026/470.[^2] Accountancy Europe's January 2026 factsheet says that Parliament and Council reached the final agreement on the amendment on 9 December 2025, that the amended rules will apply from 26 July 2029, and that the amendment significantly narrows the scope by raising the applicability thresholds.[^3] For EU companies it says the employee threshold rises from 1,000 to 5,000 employees and the net worldwide turnover threshold from EUR 450 million to EUR 1.5 billion.[^3] The Ethical Trading Initiative likewise notes that the Directive has evolved significantly since its initial proposal in 2022.[^4]

## Scope and limits

The Directive is a [[Supply Chain Due Diligence Instrument]] and applies the process described at [[Supply Chain Due Diligence]]. This page reports the 2024 Official Journal text and, for the amendment, the Commission's summary and one professional body's factsheet; the consolidated text after amendment was not opened, so the details of scope and timing should be checked against the Official Journal before they are relied on.

[^1]: European Parliament and Council of the European Union, Directive (EU) 2024/1760 of 13 June 2024, “Directive (EU) 2024/1760 of the European Parliament and of the Council on corporate sustainability due diligence”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202401760
[^2]: European Commission, “Corporate sustainability due diligence”. https://commission.europa.eu/business-economy-euro/doing-business-eu/sustainability-due-diligence-responsible-business/corporate-sustainability-due-diligence_en
[^3]: Accountancy Europe, factsheet, January 2026, “Omnibus explained: Key changes to the CSDDD”. https://accountancyeurope.eu/wp-content/uploads/2026/01/260129-Omnibus-explained-CSDDD-factseet.pdf
[^4]: Ethical Trading Initiative, legislation factsheet, “Corporate Sustainability Due Diligence Directive [Omnibus update]”. https://www.ethicaltrade.org/sites/default/files/shared_resources/CSDDD%20legislation%20factsheet%20%28Omnibus%20update%29.pdf

