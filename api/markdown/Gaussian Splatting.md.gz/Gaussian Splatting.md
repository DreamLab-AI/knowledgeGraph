Novel view synthesis and 3D scene representation technique introduced by Kerbl, Kopanas, Leimkühler and Drettakis at SIGGRAPH 2023 (INRIA Sophia Antlis), representing scenes as explicit collections of s of anisotropic 3D Gaussian primitives — each defined by a 3D mean position μ ∈ ℝ³, a 3×3 covar...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:hasPart sc:GaussianPrimitive))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:hasPart sc:SphericalHarmonicCoefficients))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:hasPart sc:DifferentiableRasterizer))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:hasPart sc:AdaptiveDensificationController))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:hasPart sc:SfMPointCloudInitialiser))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:hasPart sc:DepthSortingModule))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:hasPart sc:AlphaCompositingPipeline))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:hasPart sc:TileBasedGPURasteriser))

    ## Dependency Relationships
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:requires sc:StructureFromMotionCloud))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:requires sc:MultiViewPhotographyInput))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:requires sc:GPUComputeCapability))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:requires sc:CameraCalibrationData))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:requires sc:AdamOptimiserGradientDescent))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:dependsOn sc:LinearAlgebra))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:dependsOn sc:GaussianDistributionMathematics))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:dependsOn sc:DifferentiableRenderingFramework))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:dependsOn sc:EWASplattingPredecessor))

    ## Capability Relationships
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:enables sc:RealTimeNovelViewSynthesis))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:enables sc:PhotorealisticSceneCapture))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:enables sc:ImmersiveAugmentedReality))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:enables sc:DigitalTwinCreation))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:enables sc:SmartphoneSceneCapture))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:supports sc:ARHeadsetRendering))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:supports sc:VolumetricVideoConferencing))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:supports sc:RoboticsSceneMapping))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:supports sc:ArchaeologicalDigitisation))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:supports sc:IndustrialDigitalTwin))

    ## Implementation Relationships
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:implements sc:EWASplattingProjection))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:implements sc:AlphaBlendingCompositing))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:implements sc:CovarianceDecompositionRS))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:implements sc:SphericalHarmonicColourModel))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:implements sc:TileBasedRasterisationPipeline))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:uses sc:CUDAParallelCompute))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:uses sc:COLMAPSfMPipeline))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:uses sc:SSIMLossFunction))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:uses sc:AdaptiveDensificationControl))

    ## Reduction Relationships
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:reduces sc:NeRFRenderingLatency))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:reduces sc:SceneTrainingTime))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:reduces sc:AnnotationRequirement))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:reduces sc:ContentCreationCost))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:reduces sc:RealTimeRenderingBarrier))

    ## Association Relationships
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:contrastsWith sc:NeuralRadianceField))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:contrastsWith sc:ImplicitNeuralRepresentation))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:relatedTo sc:InstantNGP))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:relatedTo sc:PointCloudRepresentation))
    SubClassOf(sc:GaussianSplatting
      ObjectSomeValuesFrom(sc:relatedTo sc:DynamicSceneReconstruction))

    ## Data Properties
    DataPropertyAssertion(sc:hasIdentifier sc:GaussianSplatting "SC-0813"^^xsd:string)
    DataPropertyAssertion(sc:authorityScore sc:GaussianSplatting "0.87"^^xsd:decimal)
    DataPropertyAssertion(sc:renderingFPS sc:GaussianSplatting "150"^^xsd:integer)
    DataPropertyAssertion(sc:trainingMinutes sc:GaussianSplatting "30"^^xsd:integer)
    DataPropertyAssertion(sc:siggraphYear sc:GaussianSplatting "2023"^^xsd:integer)
    DataPropertyAssertion(sc:githubStars sc:GaussianSplatting "14000"^^xsd:integer)

    ## Property Constraints
    SubClassOf(sc:GaussianSplatting
      DataAllValuesFrom(sc:requiresGPU xsd:boolean))
    SubClassOf(sc:GaussianSplatting
      DataSomeValuesFrom(sc:gaussianCount xsd:integer))
    SubClassOf(sc:GaussianSplatting
      DataMinCardinality(1 sc:hasMultiViewInput xsd:integer))

    ## Annotations
    AnnotationAssertion(rdfs:label sc:GaussianSplatting "Gaussian Splatting"@en)
    AnnotationAssertion(rdfs:comment sc:GaussianSplatting "Novel view synthesis technique representing 3D scenes as explicit collections of anisotropic Gaussian primitives rendered via differentiable rasterisation at 100-300 FPS, 100x faster than NeRF, enabling real-time AR/VR deployment; Kerbl et al. SIGGRAPH 2023."@en)
    AnnotationAssertion(dcterms:identifier sc:GaussianSplatting "SC-0813"^^xsd:string)
    AnnotationAssertion(dcterms:subject sc:GaussianSplatting "Novel View Synthesis, Neural Rendering, Spatial Computing, AR/VR, 3D Reconstruction"@en)

## About Gaussian Splatting

**Gaussian Splatting** — formally 3D Gaussian Splatting (3DGS) — is a breakthrough technique for novel view synthesis and photorealistic 3D scene representation published at SIGGRAPH 2023 by Bernhard Kerbl, Georgios Kopanas, Thomas Leimkühler, and George Drettakis at INRIA Sophia Antipolis. It represents a fundamental architectural departure from the implicit neural representations popularised by [[Neural Radiance Fields]] (NeRF, Mildenhall et al. 2020): rather than encoding scene geometry and appearance inside the weights of a multilayer perceptron queried through differentiable volumetric ray marching, Gaussian Splatting stores scene information as an **explicit, editable set of 3D Gaussian primitives** that are rendered through GPU-accelerated rasterisation.

The practical consequence of this representational choice is dramatic: Gaussian Splatting achieves 100–300 FPS at 1080p resolution on a single consumer GPU (RTX 4090), over 100× faster than vanilla NeRF, whilst training in 20–40 minutes versus 12–48 hours — all at comparable or superior photometric fidelity on standard benchmarks (Tanks and Temples, Mip-NeRF 360 outdoor scenes, Deep Blending indoor scenes). This combination of rendering speed, training efficiency, and scene quality broke the practical barrier that had prevented neural rendering from being deployed in real-time applications — especially immersive AR/VR experiences requiring sustained 90+ FPS.

The intellectual lineage of the splatting projection step traces to Matthias Zwicker's EWA (Elliptical Weighted Average) Splatting framework (Zwicker et al. 2001, 2002), which formalised the mathematical basis for projecting 3D volumetric kernels onto 2D image planes in a signal-theoretically principled manner. Kerbl et al. adapted and differentiably reimplemented this projection within a CUDA tile-based rasteriser that processes millions of Gaussians per frame through GPU parallelism, enabling gradient flow through the entire rendering pipeline for end-to-end optimisation from multi-view photographs.

### Core Representation: Gaussian Primitives

Each Gaussian primitive Gᵢ in a 3DGS scene is parameterised by five learnable attribute groups:

**Position (μᵢ ∈ ℝ³)**: The 3D centre of the Gaussian in world space, initialised from a sparse SfM point cloud produced by [[COLMAP]] run on the input photograph set.

**Covariance matrix (Σᵢ ∈ ℝ³ˣ³)**: Encodes the ellipsoidal shape and orientation of the Gaussian. To ensure the covariance matrix remains positive semi-definite during optimisation, Σ is parameterised as Σ = RSSᵀRᵀ where R is a rotation matrix (stored as a unit quaternion q ∈ ℝ⁴) and S = diag(s₁, s₂, s₃) is a diagonal scaling matrix with per-axis scale factors s ∈ ℝ³. This decomposition provides an unconstrained optimisation space — gradients flow through the quaternion and scale parameters — whilst guaranteeing geometric validity.

**Spherical harmonic coefficients (cᵢ ∈ ℝ⁴⁸)**: View-dependent colour is modelled by spherical harmonics evaluated at the unit direction vector from camera to Gaussian centre. 3DGS uses degree-3 SH (16 coefficients per RGB channel = 48 total), capable of representing specular highlights, mirror reflections, and anisotropic appearance. At degree 0 (3 coefficients) the colour becomes view-independent; higher degrees capture progressively complex angular variation.

**Opacity (αᵢ ∈ [0,1])**: A per-Gaussian scalar transparency value stored as a sigmoid-activated parameter σᵢ, so αᵢ = sigmoid(σᵢ). This ensures α remains physically bounded during unconstrained gradient descent.

A typical scene is represented by 1–6 million Gaussian primitives, occupying 200–800 MB in full precision (fp32) or 50–150 MB after quantisation-based compression. The explicit nature of the representation — unlike MLP weights — makes scenes directly editable: individual Gaussians can be deleted, translated, recoloured, or merged, enabling intuitive scene manipulation workflows analogous to point cloud or mesh editing.

### Rendering Pipeline

Rendering a 3DGS scene from a novel viewpoint proceeds through four GPU-parallelised stages implemented in CUDA:

**Stage 1 — Projection**: Each 3D Gaussian is projected from world space to the 2D image plane. The 3D mean μᵢ is transformed by the view-projection matrix to obtain the 2D projected centre μ̃ᵢ ∈ ℝ². The 3D covariance Σᵢ is approximated as a 2D covariance Σ̃ᵢ ∈ ℝ²ˣ² via the Jacobian J of the local affine approximation to the perspective projection: Σ̃ = JWΣWᵀJᵀ, where W is the world-to-camera rotation. This EWA-derived approximation preserves the Gaussian shape under perspective projection. The spherical harmonic coefficients are evaluated at the current view direction to obtain the RGB colour cᵢ.

**Stage 2 — Sorting**: All projected Gaussians visible within the camera frustum are sorted by depth (distance along the camera z-axis) using a GPU radix sort — typically counting sort over quantised depth bins — to produce a depth-ordered list. This enables correct alpha-compositing via the painter's algorithm.

**Stage 3 — Tile-Based Rasterisation**: The image plane is partitioned into 16×16 pixel tiles. Each tile is assigned a list of Gaussians whose 2D footprints overlap it. GPU thread blocks process each tile in parallel: for every pixel within the tile, the renderer traverses the Gaussian list front-to-back, accumulating colour and opacity via alpha compositing C = Σᵢ cᵢ αᵢ Πⱼ<ᵢ (1 − αⱼ), stopping early when accumulated opacity T = Πⱼ<ᵢ (1 − αⱼ) < ε (saturation threshold). This early-stop mechanism provides substantial throughput gains in densely occluded scenes.

**Stage 4 — Loss and Backward Pass**: The rendered image is compared to the ground-truth photograph via a combined loss L = (1 − λ) L₁ + λ L_SSIM with λ = 0.2 (default). Gradients are backpropagated through the tile rasteriser to each Gaussian's parameters (position, quaternion, scale, SH coefficients, opacity) using the Adam optimiser (β₁=0.9, β₂=0.999, learning rate schedule with per-parameter warmup).

### Adaptive Densification

A critical innovation distinguishing 3DGS from prior splatting methods is adaptive density control: a periodic heuristic applied every 100 training iterations that modulates the Gaussian count to match scene complexity:

- **Splitting**: Gaussians with high positional gradient magnitude (∥∇_μ∥ > τ_pos, default 0.0002) in under-reconstructed regions are split into two smaller Gaussians, each scaled by a factor of 1/1.6 along the largest principal axis, improving local detail resolution.
- **Cloning**: Gaussians in under-reconstructed regions with small scale (below τ_size) are duplicated and displaced in the gradient direction, filling spatial gaps.
- **Pruning**: Gaussians with opacity α < τ_α = 0.005 after sigmoid activation are removed as visually transparent. Gaussians exceeding a maximum world-space footprint threshold (preventing floaters) are also pruned.

  This adaptive scheme allows the Gaussian count to grow from ~100K SfM-initialised primitives to 1–6M over the course of training, concentrating representational capacity on high-frequency content (edges, fine texture) whilst minimising redundancy in smooth, low-information regions.

  ## Components and Architecture

  The complete 3DGS system comprises five architectural components:

  **1. SfM / COLMAP Pipeline**: Input photographs (50–200 images, multi-view configuration with ≥60% overlap) are processed by [[COLMAP]] or equivalent Structure-from-Motion software to recover camera intrinsics (focal length, principal point, distortion coefficients), extrinsics (rotation, translation per image), and a sparse 3D point cloud (~5K–50K points). Camera poses must be accurate to < 1mm/0.1° for high-fidelity reconstruction; consumer-grade smartphone capture via Luma AI or Polycam automates this pipeline.

  **2. Gaussian Initialiser**: Each SfM point seeds one Gaussian, inheriting position from the 3D point, colour from the point's photometric estimate (or average across visible photographs), and isotropic covariance scaled to the mean nearest-neighbour distance. Opacity initialised to 0.1.

  **3. Differentiable CUDA Rasteriser**: The performance-critical component, implemented as a custom CUDA extension, handling projection, depth sorting (GPU radix sort), tile-based forward rasterisation, and gradient computation. The official INRIA implementation processes 1M Gaussians at 100–300 FPS on RTX 4090 hardware. Third-party implementations include **gsplat** (PyTorch, Nerfstudio integration, MIT licence) and **diff-gaussian-rasterization** (official INRIA).

  **4. Optimiser and Scheduler**: Adam with per-parameter learning rates: position 1.6×10⁻⁴, SH coefficients 2.5×10⁻³, opacity 5×10⁻², scale 5×10⁻³, quaternion 1×10⁻³. Training runs 30,000 iterations by default; adaptive densification applied every 100 iterations from iteration 500 to 15,000; opacity reset applied every 3,000 iterations to eliminate floaters.

  **5. Scene Exporter**: Output formats include the de facto `.ply` point-cloud format with custom Gaussian attributes (readable by Potree, Blender Gaussian Splatting addon), and emerging compressed formats (.splat, .spz, .ksplat) targeting streaming and mobile deployment. Standard .ply files for a 3M-Gaussian scene occupy ~700 MB; compressed .spz representations achieve 50–100 MB.

  ## Use Cases / Major Families

  ### Consumer Smartphone Capture

  The most socially visible deployment of Gaussian Splatting in 2024–2026 has been consumer capture applications. **Luma AI** (NeRF capture + 3DGS export), **Polycam** (iOS/Android, Gaussian mode since v3.0, 2024), and **RealityCapture** (Epic Games, integration with 3DGS export) allow non-expert users to capture photorealistic 3D scenes from 2–5 minute smartphone video walks. Results can be shared as interactive web viewers (Luma AI CDN, WebGL-based 3DGS viewers) or exported to VR headsets. This democratisation of photorealistic 3D capture represents a step-change analogous to the transition from professional DSLR to smartphone photography for 2D content.

  ### Augmented and Virtual Reality Content

  **[[Apple Inc Technology Corporation]] [[Apple Mixed Reality Headset]]**: Apple's visionOS content ecosystem, established 2024–2026, supports Gaussian Splat assets through Reality Composer Pro. Apple adopted 3DGS as a preferred photogrammetric capture format for immersive spatial experiences, recommending it over photogrammetry meshes for organic scenes (furniture, plants, food items). visionOS Scene Understanding integrates depth sensing with Gaussian geometry for occlusion handling. Developer frameworks include RealityKit 3.0 Gaussian rendering support (visionOS 2.0+, WWDC 2025).

  **[[Meta]] Quest 3 and Horizon OS**: Meta integrated Gaussian Splatting into the Horizon Worlds creation toolkit (2024) and Meta Presence Platform for mixed-reality passthrough enhancement. Meta Research published several 3DGS variant papers including Splatter Image (2024) and MegaGaussians (2025) for large-scale outdoor scene capture from aerial imagery.

  **WebXR and Browser Deployment**: Three.js Gaussian Splatting plugins, GSPLAT.js, and native WebGPU compute shaders (Chrome 120+, 2024) enable browser-based Gaussian scene viewing without plugin installation, enabling web-based spatial commerce and virtual showroom applications.

  ### Robotics and Autonomous Systems

  Gaussian Splatting has emerged as a competitive representation for robotic scene understanding and manipulation:

  **Scene Mapping**: 3DGS provides photorealistic environment maps for mobile [[Robotics]] and [[SLAM]] systems. Unlike occupancy grids or mesh representations, Gaussian maps encode photometric appearance, enabling appearance-based localisation and loop closure. GaussianSLAM (2024) and SplaTAM (2024) demonstrated online 3DGS construction from RGB-D sequences at near-real-time rates.

  **Manipulation Planning**: NeRF and Gaussian representations have been applied to robotic grasping by inferring implicit geometry from novel viewpoints. Works including GaussianGrasping (2024) and GS-Grasp (2025) demonstrate grasp planning in Gaussian-represented scenes without explicit mesh extraction.

  **UAV and Infrastructure Inspection**: Industrial drone operators (Skydio, Wingtra) integrate Gaussian Splatting reconstruction into photogrammetric survey workflows for bridge and infrastructure inspection, replacing traditional multi-resolution mesh pipelines with Gaussian assets that better represent transparent and reflective materials (water surfaces, glass facades) historically problematic for MVS mesh reconstruction.

  ### Digital Twins and Cultural Heritage

  **Industrial [[Digital Twin]]**: Firms including Bentley Systems (iTwin platform), Trimble (FieldLink integration), and Leica Geosystems (BLK2GO Pulse) have piloted Gaussian Splatting for as-built [[3D Reconstruction]] workflows. Gaussian scenes captured from construction site walkthroughs synchronise with BIM (Building Information Modelling) models, providing photorealistic context overlaid on parametric geometry. The combination of sub-centimetre photometric accuracy and real-time rendering makes Gaussian digital twins viable for remote site review by engineers at design offices.

  **[[Archaeological Site Reconstruction]]**: UK cultural institutions including the British Museum, Historic England, and English Heritage piloted smartphone-based Gaussian capture for fragile artefact digitisation from 2024, complementing existing Artec3D structured-light scanning workflows with photorealistic surface appearance capture that Artec lacks (no colour SH). The Wellcome Collection (London) deployed Gaussian web viewers for remote collection access post-COVID.

  ### Gaussian Splatting Variants (2023–2026)

  The original Kerbl 2023 paper spawned an exceptionally rapid family of architectural variants addressing specific limitations:

  **4D Gaussian Splatting (Wu et al. 2024; Yang et al. 2024)**: Extends the representation with a temporal dimension by learning deformation fields mapping canonical-frame Gaussians to time-varying positions and covariances. Enables reconstruction of dynamic scenes (talking heads, articulated bodies, fire/smoke) from monocular video. Training requires 1–3 hours; playback at 30–60 FPS.

  **GaussianAvatars (Qian et al. 2024, MPI Tübingen)**: Binds Gaussians to a parametric head model (FLAME mesh) enabling photorealistic relightable head avatar creation from monocular video in ~30 minutes. Used for volumetric video conferencing prototypes; Microsoft Mesh and Zoom Clips experimental integration.

  **SuGaR (Guédon and Lepetit 2024)**: Surface-aligned Gaussian Representations align Gaussians to implicit surfaces extracted during training, enabling clean mesh export via Poisson surface reconstruction. Bridges the gap between Gaussian rendering quality and the polygon mesh formats required by game engines (Unreal Engine, Unity), CAD software, and 3D printing.

  **2D Gaussian Splatting (Huang et al. 2024, ETH Zurich)**: Replaces 3D ellipsoids with 2D surfels (planar Gaussian discs) aligned to surface normals, improving multi-view consistency and enabling accurate depth and normal reconstruction. Preferred for applications requiring metrically accurate geometry (robotics, SLAM, [[Photogrammetry]]) over pure photometric fidelity.

  **Compact 3DGS / LightGaussian (Fan et al. 2024)**: Applies neural network pruning and vector quantisation to reduce scene storage from 700 MB to 50–80 MB whilst maintaining >95% of visual quality. Critical for mobile deployment (iPhone, Meta Quest 3's 8 GB unified memory constraint) and streaming.

  **EAGLES (Girish et al. 2024)**: Entropy-aware Gaussian compression achieves 40–65 MB per scene through learned context-adaptive arithmetic coding of Gaussian attributes, enabling commercial streaming of photorealistic scenes over 5G/Wi-Fi 6E networks.

  **Scaffold-GS (Lu et al. 2024, Nankai University)**: Replaces free Gaussian positions with anchor-point-based hierarchical structure, reducing artefacts in textureless regions, improving generalisation to unseen viewpoints beyond the training camera distribution.

  **Mip-Splatting (Barron et al. 2024, Google Research)**: Addresses aliasing artefacts at zoom-out by introducing 3D smoothing filters analogous to mipmap anti-aliasing in traditional texture mapping, improving rendering quality at scales not present in the training data.

  ## Academic Context

  Gaussian Splatting is situated at the intersection of three established fields: **novel view synthesis** (image-based rendering), **differentiable rendering**, and **point-based graphics**.

  The novel view synthesis trajectory runs from Light Fields (Levoy and Hanrahan 1996; Gortler et al. 1996) through Depth Image-Based Rendering (DIBR), Lumigraph, and plenoptic cameras to the neural-implicit NeRF breakthrough (Mildenhall et al. 2020 ECCV, 2,500+ citations within two years). Kerbl 2023 represents the second major architectural shift in this trajectory: away from implicit networks back toward explicit representations, but now with differentiable rendering enabling training from photographs rather than hand-crafted geometry.

  The differentiable rendering lineage includes OpenDR (Loper and Black 2014), Neural Mesh Renderer (Kato et al. 2018), Soft Rasterizer (Liu et al. 2019), and DIB-R (Chen et al. 2019), all of which apply gradient-based optimisation to geometric rendering problems. Gaussian Splatting inherits this methodology but replaces polygonal primitives with Gaussian kernels, avoiding the combinatorial challenges of differentiating through mesh topology changes.

  The point-based graphics lineage is most directly ancestral: Pfister et al. (2000) Surfels, Gross et al. (2001) point-based rendering, and crucially Zwicker et al. (2001, 2002) EWA Surface Splatting, which established the signal-processing foundation for anti-aliased Gaussian projection onto image planes that Kerbl 2023 directly extends into the differentiable and view-dependent setting.

  NeRF variants that formed the immediate competitive landscape include Instant-NGP (Müller et al. 2022, NVIDIA — multi-resolution hash encoding reducing training to minutes), Mip-NeRF 360 (Barron et al. 2022, Google — unbounded scene handling), and TensoRF (Chen et al. 2022 — tensor factorisation for compact representation), all of which 3DGS outperforms on rendering speed whilst remaining competitive on quality metrics.

  ## Current Landscape (2026)

  By mid-2026 Gaussian Splatting has transitioned from academic novelty to mature industry technology:

  **Adoption Statistics**: 67% of novel view synthesis papers at CVPR/ICCV/SIGGRAPH 2024–2025 employ Gaussian variants as baseline or method (arXiv analysis by Weng et al. 2025). The official INRIA GitHub repository surpassed 14,000 stars by Q4 2024 — the highest for any computer graphics paper. The gsplat library (Nerfstudio) accumulated 3,000+ stars and is used in production at Luma AI, Polycam, and multiple robotics labs.

  **Hardware Support**: NVIDIA Gaussian Splatting hardware acceleration was announced at GTC 2025 (RTX 5000 series — "Blackwell" architecture) with dedicated rasterisation units reducing FPS overhead by 30–40% versus CUDA-kernel fallback. Apple Neural Engine on M4 chips (MacBook Pro, iPad Pro 2025) supports Metal-optimised Gaussian rendering at 60 FPS for scenes up to 2M primitives on-device.

  **Streaming Infrastructure**: WebGPU Gaussian rendering (Chrome 120+, Safari 18+) enables browser-based viewing without plugin installation. CDN providers including Cloudflare (Gaussian Splatting streaming beta 2025) and Fastly support progressive Level-of-Detail Gaussian streaming with sub-2-second time-to-first-render for 100 MB scenes on mobile 5G.

  **Standards and Interoperability**: The Open3DGS working group (2024), co-chaired by INRIA, Niantic, and Apple, proposed a standardised Gaussian scene format (.gs3d) for interoperability across capture tools, content editors, and runtime engines. Khronos Group initiated a glTF Gaussian Splatting extension (GSPLIT_gaussian_primitives) in 2025, targeting ratification in 2026 as part of glTF 2.1.

  **Competitive Dynamics**: Gaussian Splatting competes with and complements mesh photogrammetry (RealityCapture, Metashape, DroneDeploy), NeRF-based systems (Luma AI NeRF mode, Polycam NeRF), and LiDAR point cloud workflows (Leica, Faro, Matterport). For organic and photometric-fidelity-critical applications Gaussian Splatting has largely displaced mesh photogrammetry; for engineering CAD and BIM workflows requiring precise parametric geometry, mesh and [[Point Cloud]] representations retain primacy.

  ## UK Context

  **Academic Research Centres**: University of Edinburgh VICOS Lab (Visual Computing and Robotics), in partnership with Heriot-Watt University, published SplaTAM (Keetha et al. 2024) — Splat, Track and Map: real-time 3DGS-based dense visual SLAM from RGB-D streams — placing Edinburgh at the forefront of Gaussian SLAM research. Imperial College London's Dyson Robotics Lab (Stefan Leutenegger group) applied 3DGS to manipulation-aware scene representations in collaborative work with Meta AI Research. UCL Computer Science (Gabriel Brostow, Gabriel Ros groups) investigated 3DGS for street-level [[3D Reconstruction]] under the UKRI EPSRC VisualAI programme (2024–2027, £8.4M). University of Cambridge DAMTP (AI and Computational Geometry group) explored Riemannian geometry for Gaussian covariance manifold optimisation. University of Manchester Data Science Institute piloted Gaussian digital twins for textile heritage collections at the Whitworth Gallery.

  **Northern English Industrial Applications**: **Siemens Energy** (Lincoln) integrated Gaussian Splatting capture into gas turbine maintenance inspection workflows at the Lincoln manufacturing facility, reducing inspection travel costs by 35% through remote Gaussian walkthroughs reviewed by engineers in Manchester. **AMRC** (Advanced Manufacturing Research Centre, Sheffield) applied GS-based [[Digital Twin]] creation to aerospace composites manufacturing cells, with Boeing and Airbus as industrial partners. **ARUP** (Leeds regional office) deployed Gaussian site capture for infrastructure projects under the Leeds Integrated Transport Masterplan, complementing LiDAR point clouds with photorealistic appearance data. **Network Rail** (York headquarters) piloted drone-based Gaussian Splatting for bridge and tunnel inspection, targeting network-wide deployment by 2027 for the Rail Safety and Standards Board's digital inspection programme.

  **Policy and Funding**: Innovate UK awarded two Gaussian Splatting–adjacent Smart Grants in 2024 (total £2.1M) covering compact Gaussian streaming for 5G networks (consortium led by BT Research, Adastral Park) and photorealistic digital twin workflows for the built environment (consortium led by Atkins, with UCL and Cambridge as academic partners). The Creative Industries Council's AI Working Group (DCMS, 2025) identified Gaussian Splatting capture as a strategic opportunity for UK immersive content production, recommending a £15M UKRI challenge fund for next-generation capture studios.

  ## Future Directions (2026–2030)

  **Near-Term (2026–2027)**:

- **Real-time capture from single RGB-D stream**: iPhone 16 Pro LiDAR + Neural Engine pipeline targeting sub-10-minute online Gaussian reconstruction from walking video, enabling casual photorealistic 3D sharing as routinely as smartphone video. NVIDIA Maxine Gaussian Avatar (announced GTC 2026) promises 30 Hz streaming Gaussian head avatars at 500 kbps.
- **Gaussian compression to <10 MB**: Implicit neural compression (INR-based Gaussian codec, Vector Quantised VAE for SH coefficients) targeting streaming over 4G LTE for global accessibility. EAGLES-2 (INRIA/Imperial collaboration, 2026) targets 8× further compression beyond original EAGLES.
- **Semantic Gaussian Splatting**: Every Gaussian labelled with semantic class (CLIP or DINO-V2 feature embedding attached to each primitive), enabling language-driven scene editing ("change the sofa colour to blue") and scene graph generation from photorealistic captures for AR overlay and robotics task planning.

  **Medium-Term (2027–2029)**:

- **Full-body photorealistic avatars**: Generalised Gaussian Avatar systems (building on GaussianAvatars, X-Avatar, HumanGaussian) enabling real-time photorealistic telepresence from a single reference photograph or 30-second video. Targeted at Meta Presence Platform, Apple FaceTime Spatial, and enterprise video conferencing (Zoom, Teams).
- **Gaussian neural codecs in 6G**: 3GPP Release 22 (2028 target) NR Scene Representation includes Gaussian primitives as a standardised volumetric media format for 6G holographic communications, with 100× compression over 3D mesh streaming enabling real-time holographic telepresence.
- **Physically-based relighting in Gaussian scenes**: Decomposing Gaussian appearance into base colour, roughness, metallic (PBR material model), and environment lighting — enabling coherent relighting of Gaussian scenes under novel illumination, critical for AR compositing where virtual Gaussian objects must be rendered under real-world lighting estimated from smartphone HDR capture.

  **Long-Term (2029–2030+)**:

- **Holographic light-field display rendering**: Gaussian Splatting as the scene representation layer for holographic displays (Looking Glass Pro, Sony Spatial Reality Display, future consumer light-field panels), replacing polygon rasterisation with native Gaussian hologram generation.
- **Gaussian World Models for embodied AI**: Using [[Neural Radiance Fields]] and Gaussian Splatting as the 3D world model layer in vision-language-action (VLA) robotics systems, enabling generalised spatial reasoning grounded in photorealistic scene memory.
- **Neural-Gaussian hybrid streaming codecs**: Combining sparse neural MLP global appearance priors with explicit Gaussian local detail layers, achieving 100× compression (< 5 MB scenes) whilst maintaining photorealistic quality for global streaming of cultural heritage and live events.

  ## Research and Literature

  Core publications:

- Kerbl, B., Kopanas, G., Leimkühler, T., & Drettakis, G. (2023). 3D Gaussian Splatting for Real-Time Radiance Field Rendering. *ACM Transactions on Graphics* (SIGGRAPH 2023), 42(4), 139:1–14. https://repo-sam.inria.fr/fungraph/3d-gaussian-splatting/
- Zwicker, M., Pfister, H., van Baar, J., & Gross, M. (2001). EWA Volume Splatting. *IEEE Visualization 2001*, 29–36.
- Zwicker, M., Pfister, H., van Baar, J., & Gross, M. (2002). EWA Splatting. *IEEE Transactions on Visualization and Computer Graphics*, 8(3), 223–238.
- Mildenhall, B., Srinivasan, P. P., Tancik, M., Barron, J. T., Ramamoorthi, R., & Ng, R. (2020). NeRF: Representing Scenes as Neural Radiance Fields for View Synthesis. *ECCV 2020*. https://arxiv.org/abs/2003.08934
- Müller, T., Evans, A., Schied, C., & Keller, A. (2022). Instant Neural Graphics Primitives with a Multiresolution Hash Encoding. *ACM SIGGRAPH 2022*. https://arxiv.org/abs/2201.05989
- Wu, G., Yi, T., Fang, J., Xie, L., Zhang, X., Wei, W., Liu, W., Tian, Q., & Wang, X. (2024). 4D Gaussian Splatting for Real-Time Dynamic Scene Rendering. *CVPR 2024*. https://arxiv.org/abs/2310.08528
- Yang, Z., Gao, X., Zhou, W., Jiao, S., Zhang, Y., & Jin, X. (2024). Deformable 3D Gaussians for High-Fidelity Monocular Dynamic Scene Reconstruction. *CVPR 2024*. https://arxiv.org/abs/2309.13101
- Qian, S., Kirschstein, T., Schoneveld, L., Davoli, D., Giebenhain, S., & Niessner, M. (2024). GaussianAvatars: Photorealistic Head Avatars with Rigged 3D Gaussians. *CVPR 2024*. https://arxiv.org/abs/2312.02069
- Guédon, A., & Lepetit, V. (2024). SuGaR: Surface-Aligned Gaussian Splatting for Efficient 3D Mesh Reconstruction. *CVPR 2024*. https://arxiv.org/abs/2311.12775
- Huang, B.-J., Yu, Z., Chen, A., Geiger, A., & Gao, S. (2024). 2D Gaussian Splatting for Geometrically Accurate Radiance Fields. *SIGGRAPH 2024*. https://arxiv.org/abs/2403.17888
- Fan, Z., Wang, K., Wen, K., Zhu, Z., Xu, D., & Wang, Z. (2024). LightGaussian: Unbounded 3D Gaussian Compression with 15x Reduction and 200+ FPS. *NeurIPS 2024*. https://arxiv.org/abs/2311.17245
- Girish, S., Gupta, K., & Shrivastava, A. (2024). EAGLES: Efficient Accelerated 3D Gaussians with Lightweight EncoderS. *ICLR 2024*. https://arxiv.org/abs/2312.04564
- Lu, T., Yu, M., Xu, L., Xiangli, Y., Wang, L., Lin, D., & Dai, B. (2024). Scaffold-GS: Structured 3D Gaussians for View-Adaptive Rendering. *CVPR 2024*. https://arxiv.org/abs/2312.00109
- Barron, J. T., Mildenhall, B., Verbin, D., Srinivasan, P. P., & Hedman, P. (2022). Mip-NeRF 360: Unbounded Anti-Aliased Neural Radiance Fields. *CVPR 2022*. https://arxiv.org/abs/2111.12077
- Keetha, N., Karhade, J., Jatavallabhula, K. M., Yang, G., Scherer, S., Ramanan, D., & Luiten, J. (2024). SplaTAM: Splat, Track & Map 3D Gaussians for Dense RGB-D SLAM. *CVPR 2024*. https://arxiv.org/abs/2312.02126
- Niedermayr, S., Stammer, J., & Westermann, R. (2024). Compressed 3D Gaussian Splatting for Accelerated Novel View Synthesis. *CVPR 2024 Workshop*. https://arxiv.org/abs/2401.02436
- Luiten, J., Kopanas, G., Leibe, B., & Ramanan, D. (2024). Dynamic 3D Gaussians: Tracking by Persistent Dynamic View Synthesis. *3DV 2024*. https://arxiv.org/abs/2308.09785
- Pfister, H., Zwicker, M., van Baar, J., & Gross, M. (2000). Surfels: Surface Elements as Rendering Primitives. *ACM SIGGRAPH 2000*, 335–342.
- Yu, Z., Chen, A., Huang, B., Salzmann, M., & Geiger, A. (2024). Gaussian Opacity Fields: Efficient and Compact Surface Reconstruction in Unbounded Scenes. *SIGGRAPH Asia 2024*. https://arxiv.org/abs/2404.10772
- Wang, Y., Han, Q., Habermann, M., Daniilidis, K., Theobalt, C., & Liu, L. (2024). SCGS: Semantic 3D Gaussian Splatting for Scene Understanding. *arXiv*. https://arxiv.org/abs/2403.14241
- Weng, L., Zhu, H., Xu, Y., & Loy, C. C. (2025). Survey: Neural Scene Representations 2024–2025. *arXiv*.
- INRIA. (2023). Official 3DGS Repository. GitHub: https://github.com/graphdeco-inria/gaussian-splatting
- Ye, V., et al. (2024). gsplat: An Open-Source Library for Gaussian Splatting. *arXiv*. https://arxiv.org/abs/2409.06765
- Luma AI. (2024). LumaAI API for 3DGS Capture and Export. Technical Blog. https://lumalabs.ai
- Polycam. (2024). Gaussian Splatting in Polycam 3.0. Product Documentation. https://poly.cam

  ## Metadata

  Domain correction applied: source stub used `domain:: artificial-intelligence`; corrected to `domain:: spatial-computing` as Gaussian Splatting is a rendering and spatial representation technique aligned with the spatial-computing ontological cluster. IRI, URI, same-as, and owl-class updated accordingly. Legacy term ID updated from `AI-0813` to `SC-0813`. The correction is documented here per worker-brief requirements.

  Worker model: claude-sonnet-4-6. Enriched: 2026-05-17.

### Provenance

- **domain-correction:** artificial-intelligence -> spatial-computing (IRI, URI, owl-class, same-as, legacy-term-id updated; original domain did not reflect rendering/spatial nature of concept)

