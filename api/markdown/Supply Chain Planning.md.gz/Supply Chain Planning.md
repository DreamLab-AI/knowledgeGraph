Supply chain planning is the planning of the decisions a supply chain must make, grouped into strategic, tactical and operational levels according to the time horizon.[^1][^2]

Melo, Nickel and Saldanha da Gama write that three planning levels are typically distinguished by time horizon. They quote Simchi-Levi and colleagues that the strategic level deals with decisions that have a long-lasting effect on the firm, such as the number, location and capacities of warehouses and plants, or the flow of material through the logistics network.[^1] Jatta likewise names operational, tactical and strategic planning as the three stages of supply chain planning, with strategic planning at the highest level, and lists the location of manufacturing and warehousing facilities, chain topology and vendor selection among strategic decisions.[^2] He cites Gupta and Maranas for the view that effective integration of the various functions is the primary objective of supply chain planning.[^2]

## Planning horizons

An open operations management textbook ties the levels to forecast horizons: long-term (strategic), typically 1 to 5 years; medium-term (tactical), 3 to 18 months, supporting aggregate planning and sales and operations planning; and short-term (operational), from daily to six months, used to schedule production, manage inventory and coordinate order dispatching.[^3] Goetschalckx describes forecasting as an essential and basic activity in any planning process and says that effective logistics planning requires accurate estimates of the future activities of the logistics system or supply chain.[^4]

## In this domain

Planning processes treated in the corpus are [[Demand Management]], [[Supply Planning]], [[Sales and Operations Planning]], [[Aggregate Planning]], [[Master Production Scheduling]], [[Material Requirements Planning]] and [[Collaborative Planning, Forecasting and Replenishment]]. See also [[Supply Chain Network Design]].

## What the sources do not establish

No source opened defines supply chain planning as a fixed phrase, and the horizon lengths come from a teaching text on forecasting rather than from a standard.[^3]

[^1]: Fraunhofer ITWM (Melo, Nickel and Saldanha da Gama), report version of a review of facility location and supply chain management, “Facility Location and Supply Chain Management - A comprehensive review”. https://kluedo.ub.rptu.de/files/1985/bericht130.pdf
[^2]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content
[^3]: Operations Management open textbook, eCampusOntario Pressbooks, section 14.2, “Concept and Horizon of Aggregate Planning”. https://ecampusontario.pressbooks.pub/opsmgmt/chapter/14-2-concept-and-horizon-of-aggregate-planning/
[^4]: Marc Goetschalckx, Georgia Institute of Technology course text, “Chapter 2. Forecasting”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/forecasting/forecasting.pdf

