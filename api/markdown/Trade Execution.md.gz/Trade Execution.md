Trade execution is the process of converting an investment decision into a completed transaction in a market, encompassing how, when, and where an order is routed and filled. It seeks the best achievable outcome for the trader by managing factors such as price, speed, market impact, and slippage against the order book. Execution quality is a core determinant of realised returns and is governed by best-execution obligations in many jurisdictions.

- Trade execution is the process of turning an investment decision into a completed transaction, governing how, when, and where an order is routed and filled.
- It is a part of [[Market Microstructure]] and aims to achieve the best outcome across price, speed, and market impact against the [[Order Book]].
- Execution quality directly shapes realised returns and is governed by best-execution duties.

### Overview

- A trading decision only generates value once it is executed; the gap between intended and achieved price is a real cost.
- Execution manages the tension between transacting quickly and minimising the market impact of revealing demand.
- It interacts with [[Liquidity]], [[Slippage]], and the behaviour of [[Market Maker]]s on both lit and dark venues.
- Sophisticated execution uses algorithms to slice large orders over time and across venues to reduce footprint.

### Key aspects

- Order routing: selecting venues and pathways to maximise fill quality.
- Execution algorithms: VWAP, TWAP, implementation shortfall, and liquidity-seeking strategies.
- Market impact: managing the price movement caused by one's own trading.
- Best execution: regulatory obligation to obtain the most favourable terms reasonably available.
- Transaction cost analysis: measuring slippage and impact to evaluate execution performance.

### Applications

- Institutional order management routing block trades across exchanges.
- Brokerage smart-order routers seeking best price for retail and professional flow.
- Algorithmic and electronic trading desks executing systematic strategies.
- Post-trade clearing and settlement workflows initiated by completed fills.

### Provenance

