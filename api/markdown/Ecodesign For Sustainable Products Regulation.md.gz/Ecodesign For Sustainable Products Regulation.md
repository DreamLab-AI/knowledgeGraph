Regulation (EU) 2024/1781, the Ecodesign for Sustainable Products Regulation, establishes a framework for the setting of ecodesign requirements that products have to comply with to be placed on the market or put into service.[^1]

Its stated aim is to improve the environmental sustainability of products in order to make sustainable products the norm, to reduce the overall carbon footprint and environmental footprint of products over their life cycle, and to ensure the free movement of sustainable products within the internal market.[^1] It applies to any physical goods placed on the market or put into service, including components and intermediate products.[^1] An ecodesign requirement is a performance requirement or an information requirement aimed at making a product, including processes taking place throughout the product's value chain, more environmentally sustainable.[^1]

## Other instruments in the Regulation

The Regulation also establishes a digital product passport, provides for the setting of mandatory green public procurement requirements, and creates a framework to prevent unsold consumer products from being destroyed.[^1]

## Digital product passport

The Regulation defines the digital product passport as a set of data specific to a product, including the information specified in the applicable delegated act, that is accessible via electronic means through a data carrier.[^1] A data carrier is a linear barcode symbol, a two-dimensional symbol or other automatic identification data capture medium, and a unique product identifier is a unique string of characters that identifies a product and enables a web link to its passport.[^1]

The CIRPASS project, an independent initiative, says it prepared the ground for gradual piloting and deployment of digital product passports and developed roadmaps for prototypes in electronics, batteries and textiles value chains.[^2] The project's page says it ended in March 2024.[^2]

## Scope and limits

The Regulation is one of the instruments listed at [[Supply Chain Due Diligence Instrument]], although it concerns product design and information and not due diligence in the sense used there. Identifiers and data carriers are discussed at [[Traceability and Product Identification]]. The detailed requirements for each product group are set by delegated acts, which were not opened; this page therefore describes the framework only.

[^1]: European Parliament and Council of the European Union, Regulation (EU) 2024/1781 of 13 June 2024, “Regulation (EU) 2024/1781 of the European Parliament and of the Council establishing a framework for the setting of ecodesign requirements for sustainable products”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32024R1781
[^2]: CIRPASS project, “CIRPASS – Digital Product Passport”. https://cirpassproject.eu/

