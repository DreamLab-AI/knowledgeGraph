Surgical robotics is the application of robotic systems, real-time computer vision, and AI-driven control to assist surgeons or perform procedures with enhanced precision, dexterity, tremor cancellation, and minimally invasive access. Systems range from teleoperated master-slave platforms—where a surgeon's hand movements are scaled, filtered, and transmitted to slave arms—to semi-autonomous robots capable of tissue manipulation and suturing under human supervision. Key technical challenges include sub-millimetre motion tracking, intraoperative tissue deformation modelling, real-time haptic feedback, safe human-robot interaction, and regulatory compliance under medical device frameworks such as ISO 13485, IEC 62304, and EU MDR. The field sits at the intersection of mechatronics, control theory, computer vision, AI inference, and clinical medicine.

### Overview

- Surgical robotics emerged from the convergence of [[Robotics]], [[Minimally Invasive Surgery]], and computational intelligence in the 1980s–1990s, with commercial teleoperated systems entering operating theatres in the late 1990s.
- The paradigm shifts surgical practice in three ways: (1) it improves mechanical precision beyond the human hand, eliminating physiological tremor and scaling motions to sub-millimetre resolution; (2) it enables [[Minimally Invasive Surgery]] through small incisions using long, articulated instruments; (3) it opens pathways to remote and semi-autonomous procedures augmented by AI.
- Core system architecture comprises a surgeon console (master controllers, 3D display), a patient-side robotic cart (slave arms, instrument grippers), a vision system (endoscopic camera, image processing unit), and a communication link between them.
- [[Haptic Feedback]] — conveying tissue resistance and texture back to the surgeon — remains an active research frontier; most commercial systems provide visual force cues rather than true tactile sensation.
- [[Deep Learning]] and [[Computer Vision]] increasingly underpin perception layers: tissue segmentation, instrument tracking, anatomical landmark localisation, and intraoperative registration of preoperative [[Medical Imaging]] data.
- The field is now mature at the commercial teleoperation layer (laparoscopic, urological) and established-emerging at semi-autonomous and speciality levels (orthopaedic, neurosurgical, cardiac, ophthalmic).

### Key Components

- **Robotic Arms and Instruments**
  - [[Robotic Arm]] — multi-degree-of-freedom manipulators carrying interchangeable surgical tools (scissors, needle drivers, clip appliers); key metric is workspace and payload accuracy at the end-effector.
  - Wristed instruments provide 7 degrees of freedom inside the body, surpassing the 4 DOF of conventional [[Laparoscopic Surgery]] tools.
  - Actuators are typically brushless DC motors with cable-tendon or gear transmission; miniaturisation for single-port and intraluminal robots drives research into shape-memory alloys and pneumatic actuators.
- **Master Console and Input**
  - Ergonomic hand controllers translate surgeon grip, wrist rotation, and finger pinch into joint-angle commands sent to the slave arms.
  - [[Motion Scaling]] reduces large hand movements to fine instrument motion (e.g. 5:1 or 3:1 scaling).
  - Tremor filtering (low-pass or adaptive filters) suppresses physiological tremor (8–12 Hz) before transmission.
- **Vision System**
  - High-definition or 3D stereo endoscope provides the intraoperative visual field.
  - [[Image Segmentation]] algorithms delineate anatomical structures (vessels, nerves, tumour margins) in real time.
  - [[Simultaneous Localisation and Mapping]] (SLAM) tracks instrument position relative to soft tissue even under deformation.
  - Preoperative [[CT Scanning]] and [[MRI]] volumes are registered to the live endoscopic scene using surface matching or fiducial markers.
- **Haptic and Force Feedback**
  - [[Force-Torque Sensing]] at instrument tip or trocar estimates tissue interaction forces.
  - [[Haptic Feedback]] interfaces render force cues at the master console; current commercial platforms offer predominantly visual force indicators rather than kinesthetic feedback.
- **Control and Safety Architecture**
  - [[Real-Time Control]] loops (typically 1 kHz) maintain stable teleoperation under time delays.
  - Virtual fixtures (forbidden-zone constraints) prevent instruments entering sensitive anatomy.
  - Safety interlocks satisfy [[IEC 60601]] requirements for medical electrical equipment.
  - [[Sensor Fusion]] integrates proprioceptive joint encoders, force sensors, and vision data into a coherent state estimate.
- **Software and AI Layer**
  - [[Motion Planning]] computes collision-free paths for autonomous or semi-autonomous manoeuvres.
  - [[Deep Learning]] models identify tissue types, flag bleeding events, and predict optimal instrument trajectories.
  - [[Medical AI]] inference pipelines must satisfy [[IEC 62304]] software lifecycle requirements and, under EU law, qualify as high-risk AI under the [[AI Act]].

### Applications and Use Cases

- **Urological Surgery** — prostatectomy (radical prostatectomy) is the highest-volume robotic procedure globally; robotic access preserves neurovascular bundles controlling continence and potency better than open surgery in experienced hands.
- **Gynaecological Surgery** — hysterectomy, myomectomy, and sacrocolpopexy; robotic magnification and dexterity benefit procedures in the narrow pelvis.
- **General Surgery** — colorectal resection, cholecystectomy, Nissen fundoplication, hernia repair; robotic single-port platforms reduce port-site morbidity.
- **Thoracic Surgery** — lobectomy and mediastinal lymph node dissection via robotic thoracoscopy; improved visualisation of hilar structures.
- **Orthopaedic Surgery** — bone-cutting robots (haptic-guided or autonomous) in total knee arthroplasty and total hip arthroplasty achieve implant placement accuracy of ≤1 mm and ≤1°; see [[Orthopaedic Robotics]].
- **Neurosurgery** — stereotactic robot arms for electrode placement, biopsy, and endoscope positioning; sub-millimetre accuracy in [[Neurosurgical Robotics]].
- **Ophthalmic Surgery** — retinal microsurgery robots with nanometre-scale positioning to inject drugs subretinally or peel membranes off the retina; human tremor is a fundamental limiting factor obviated by robotics.
- **Cardiac Surgery** — robotic-assisted mitral valve repair and coronary anastomosis on the beating heart.
- **Remote and Battlefield Surgery** — [[Teleoperation]] over high-bandwidth low-latency links (including [[5G Networks]]) enables surgeons to operate on patients in remote locations; latency must remain below ~100 ms for safe teleoperation.
- **Training and Simulation** — robotic platforms double as surgical simulators; kinematic data enables objective performance metrics for trainee assessment.

### Enabling Technologies

- [[Computer Vision]] — endoscopic scene understanding, tissue segmentation, instrument tracking.
- [[Deep Learning]] — real-time inference for surgical phase recognition, anomaly detection, and autonomous skill transfer.
- [[Simultaneous Localisation and Mapping]] — soft-tissue SLAM to track the 3D scene despite deformation.
- [[Sensor Fusion]] — combining force, vision, and proprioception for robust state estimation.
- [[Motion Planning]] — collision-free trajectory generation respecting anatomical constraints.
- [[Haptic Feedback]] — kinesthetic and tactile rendering at the surgeon console.
- [[Augmented Reality]] — overlaying preoperative imaging onto the live view to guide incision and resection margins.
- [[Digital Twin]] — patient-specific surgical simulations for planning and intraoperative guidance.
- [[5G Networks]] and ultra-low-latency networking for [[Remote Surgery]].
- [[Medical Imaging]] — CT, MRI, ultrasound for preoperative planning and intraoperative registration.

### Standards and Regulatory Context

- **ISO 13485** — quality management systems for medical device manufacturers; governs the design, manufacturing, and post-market surveillance of surgical robotic systems.
- **IEC 62304** — medical device software lifecycle processes; mandates software classification (class A/B/C) and corresponding rigour of verification and validation for embedded and AI software in surgical robots.
- **IEC 60601-1** — general requirements for the safety and essential performance of medical electrical equipment; surgical robots must meet this with applicable collateral and particular standards (e.g. IEC 60601-1-2 for EMC, IEC 60601-1-6 for usability).
- **EU Medical Device Regulation (MDR 2017/745)** — classifies most surgical robots as Class IIb or Class III devices; requires clinical evidence, conformity assessment by a notified body, and post-market clinical follow-up.
- **EU AI Act** — AI components embedded in surgical robots that influence diagnosis or therapy qualify as high-risk AI systems under Annex III; requires conformity assessment, transparency, and human oversight.
- **FDA 510(k) / De Novo / PMA** — US regulatory pathways; novel autonomous functions typically require premarket approval (PMA) rather than 510(k) clearance.
- **ISO/TR 23372** — technical report on robotics and surgical applications; provides vocabulary and guidance for interface standards.
- Standards bodies involved: [[ISO]], [[IEC]], [[FDA]], [[EUDAMED]], [[BSI]].

### Research Frontiers

- **Autonomous execution of surgical subtasks** — autonomous suturing (Smart Tissue Autonomous Robot, STAR), tissue retraction, and clip placement under supervised autonomy.
- **Soft robotics** — flexible, continuum-body robots navigating tortuous anatomical pathways (bronchial trees, colonic lumens) without rigid links.
- **AI-guided skill transfer** — learning from demonstration to encode expert surgical technique into robot control policies via [[Imitation Learning]] and [[Reinforcement Learning]].
- **Intraoperative adaptive control** — updating motion plans in real time as tissue deforms under manipulation, using [[Simultaneous Localisation and Mapping]] and deformable tissue models.
- **Single-incision and incisionless surgery** — natural orifice transluminal endoscopic surgery (NOTES) requires highly miniaturised and flexible robotic platforms.
- **Multi-robot coordination** — two or more robotic arms operated by different surgeons or autonomously coordinating tasks (e.g. one arm retracts, another sutures).
- **Closed-loop drug delivery** — surgical robots integrating real-time [[Biosensor]] feedback to titrate haemostatic agents or anaesthetic delivery.

### Provenance

