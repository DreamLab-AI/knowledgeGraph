A digital trade platform is a shared platform for exchanging trade documents and events in electronic form.[^1][^2]

No source opened defines the term, so the page records what the sources say about digital trade. The ICC Digital Standards Initiative says it aims to accelerate the development of a globally digitalised, interoperable trade environment, and that through a renewed focus on standards, trust and identity it aims to enable plug-and-play connectivity across global trade and supply chains.[^1] An ICC Academy guide says global trade relies on four billion documents daily, with documentation for a single shipment requiring up to 50 sheets of paper exchanged with up to 30 different stakeholders, and cites the Initiative for the figure that supply chain information is frequently stored in paper documents in more than 90% of global trade.[^2]

## Legal basis

UNCITRAL's Model Law on Electronic Transferable Records aims to enable the legal use of electronic transferable records both domestically and across borders; transferable documents typically include bills of lading, bills of exchange, promissory notes and warehouse receipts.[^3] See [[Electronic Bill of Lading]].

## Events and an example

The Digital Container Shipping Association describes the cost of inconsistent event data: teams reconcile the same milestone by hand across incompatible feeds.[^4] TradeLens, a blockchain-enabled shipping platform announced in 2018, was discontinued after Maersk and IBM said it had not reached the commercial viability needed to continue.[^5] See [[TradeLens]].

## What the sources do not establish

Evidence is thin. The ICC figures are the Initiative's own and are not independently checked here, and the page offers no list of platforms or count of users. The sources do not say whether a platform must use any particular technology.[^1][^2][^3][^4][^5]

[^1]: International Chamber of Commerce, “The ICC Digital Standards Initiative”. https://dsi.iccwbo.org/
[^2]: ICC Academy, “Digital Trade 101: What you need to know”, 19 September 2024. https://academy.iccwbo.org/digital-trade/article/digital-trade-101-what-you-need-to-know/
[^3]: United Nations Commission on International Trade Law, “UNCITRAL Model Law on Electronic Transferable Records (2017)”. https://uncitral.un.org/en/texts/ecommerce/modellaw/electronic_transferable_records
[^4]: Digital Container Shipping Association, “Track & Trace”. https://dcsa.org/standards/track-trace/
[^5]: A.P. Moller - Maersk, “A.P. Moller - Maersk and IBM to discontinue TradeLens, a blockchain-enabled global trade platform”, press release, 29 November 2022. https://www.maersk.com/news/articles/2022/11/29/maersk-and-ibm-to-discontinue-tradelens

