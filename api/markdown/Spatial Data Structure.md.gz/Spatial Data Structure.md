A Spatial Data Structure is a data organisation scheme that partitions, indexes, or hierarchically organises geometric, geographic, or positional information to enable efficient queries over proximity, containment, intersection, and visibility. Classical families include space-partitioning trees (k-d trees, octrees, BSP trees, quadtrees), bounding-volume hierarchies (BVH), and spatial hash grids, each offering distinct trade-offs between construction cost, query throughput, memory footprint, and support for dynamic updates. These structures underpin performance-critical systems including real-time 3-D rendering, physics simulation, geographic information systems (GIS), robotics path planning, and spatial databases. The choice of structure is governed by data dimensionality, scene dynamism, query distribution, and hardware parallelism constraints.

### Overview

- Spatial data structures address the fundamental computational challenge of efficiently answering geometric queries — "which objects are near point P?", "does object A intersect object B?", "which primitives does this ray hit?" — over potentially millions of geometric entities.
- Without acceleration structures, answering such queries requires O(n) comparisons against every object. Space-partitioning trees reduce average query complexity to O(log n) by recursively subdividing space or grouping objects so that whole sub-trees can be rejected early.
- Two broad families exist:
  - **Space-partitioning structures** divide the embedding space itself into non-overlapping regions (e.g. [[Octree]], [[k-d Tree]], [[Quadtree]], [[BSP Tree]]). They adapt well to sparse, unevenly distributed data and enable efficient range and nearest-neighbour queries.
  - **Object-hierarchy structures** group the objects themselves into nested [[Bounding Volume|bounding volumes]] without subdividing empty space (e.g. [[Bounding Volume Hierarchy]], [[Scene Graph]] bounding boxes). They are preferred for ray-tracing acceleration and deformable-scene management.
- The choice between families depends on scene dynamism, data dimensionality, query type distribution, hardware memory bandwidth, and SIMD/GPU parallelism characteristics.
- Maturity is **mature**: k-d trees were formalised by Bentley in 1975; R-trees by Guttman in 1984; BVH-based ray acceleration has been a production standard in offline rendering for decades and in real-time hardware since NVIDIA RTX (2018).

### Key Components

#### Space-Partitioning Trees

- **[[Octree]]** — Recursively divides 3-D space into eight equal octants. Each node represents a cubic region; subdivision continues until a leaf-capacity threshold is met. Well suited to sparse volumetric data, voxel worlds, and point-cloud octree compression (e.g. the libLAS/Potree pipeline for [[LiDAR Mapping]]). Loose octrees relax strict containment boundaries to avoid double-storing objects straddling boundaries.
- **[[Quadtree]]** — The 2-D analogue of the octree, subdividing planar space into four quadrants. Widely used for terrain tiles, [[Navigation Mesh]] generation, and 2-D game-world spatial queries.
- **[[k-d Tree]]** — A binary tree alternating the splitting axis per level (or choosing the axis of maximum variance). Optimal for static, low-dimensional datasets and [[Nearest Neighbour Search]]; expensive to rebalance after dynamic insertions. The CGAL and nanoflann libraries provide production implementations.
- **[[BSP Tree]]** — Binary Space Partitioning uses arbitrary splitting hyperplanes aligned to polygon faces. Historically used for painter's-algorithm visibility ordering in early 3-D games (Doom, Quake); superseded by hardware Z-buffering for rasterisation but still relevant for constructive solid geometry (CSG) and [[Computational Geometry]] algorithms.

#### Object-Hierarchy Structures

- **[[Bounding Volume Hierarchy]] (BVH)** — Organises scene objects into a binary tree of nested [[Bounding Volume|bounding volumes]] (axis-aligned bounding boxes, AABB; oriented bounding boxes, OBB; spheres). The Surface Area Heuristic (SAH) guides tree construction to minimise expected ray-traversal cost. Hardware BVH traversal is the core of NVIDIA RTX and AMD RDNA ray-tracing pipelines, enabling [[Ray Tracing]] at real-time frame rates.
- **[[Scene Graph]]** — A directed acyclic graph encoding transformation hierarchies; spatial culling is performed via per-node bounding volumes. Scene graphs are the primary spatial data structure in game engines (Unreal Engine, Unity) and 3-D toolkits (OpenSceneGraph, three.js).

#### Hash and Grid Structures

- **[[Spatial Hash Grid]]** — Maps continuous-space coordinates to discrete hash-table cells using a spatial hash function (e.g. Teschner et al. prime-number hash). Provides O(1) average-case insertion and lookup for uniformly distributed data; memory usage is proportional to populated cells only. Widely used in particle simulations, SPH fluid solvers, and broad-phase [[Collision Detection]].
- **[[R-Tree]]** — Groups spatially proximate objects into minimum bounding rectangles (MBRs) in a balanced tree. The primary structure for [[Spatial Database]] systems (PostGIS, SpatiaLite, Oracle Spatial). Variants include R*-tree (improved insertion heuristics) and R+-tree (non-overlapping rectangles).
- **[[Morton Code]] (Z-order curve)** — Maps multi-dimensional coordinates to a 1-D index preserving spatial locality by interleaving coordinate bits. Used to impose a cache-coherent linear order on spatial data for GPU-friendly BVH construction (e.g. LBVH algorithms) and spatial sorting in [[Point Cloud Processing]].

#### Dynamic and Hybrid Approaches

- **Loose/dynamic octrees** — Extend static octrees by relaxing node-boundary constraints, allowing objects to remain in parent nodes until they fit. Reduces costly node transfers for moving objects.
- **DBVT (Dynamic Bounding Volume Tree)** — Used in the Bullet [[Physics Simulation]] engine; supports efficient incremental re-fitting as objects move, with selective sub-tree rebuilds.
- **Two-level acceleration structures** — Combine a top-level BVH (TLAS) over instances with per-instance bottom-level BVHs (BLAS), matching the DirectX Raytracing (DXR) and Vulkan Ray Tracing API model. Enables instancing without geometry duplication.
- **Parallel GPU construction** — LBVH (Linear BVH) algorithms sort primitives by [[Morton Code]] then build the BVH in a single GPU pass, achieving construction times below one millisecond for millions of triangles.

### Applications / Use Cases

- **[[Real-Time Rendering]] and [[Frustum Culling]]** — Scene graphs with per-node AABB tests cull geometry outside the view frustum before GPU submission, reducing draw-call counts by orders of magnitude in large worlds.
- **Hardware [[Ray Tracing]]** — BVH traversal is the inner loop of path tracers and RTX-accelerated hybrid renderers. Efficient SAH-BVH construction and refitting are critical performance bottlenecks.
- **Broad-phase [[Collision Detection]]** — BVH, [[Spatial Hash Grid]], and sweep-and-prune paired with spatial hashing constitute the broad phase in game physics engines (Havok, Bullet, PhysX), filtering candidate pairs before expensive narrow-phase GJK/EPA tests.
- **[[Path Planning]] in [[Robotics]]** — Octrees (e.g. the OctoMap library used with ROS) represent 3-D occupancy grids; k-d trees accelerate nearest-neighbour queries in sampling-based planners (RRT, PRM). See also [[Spatial AI]].
- **[[Geographic Information System]] (GIS)** — [[R-Tree]] indices in PostGIS underpin spatial joins, buffer queries, and map tile generation over millions of geographic features.
- **[[Point Cloud Processing]]** — [[Octree]] and k-d tree structures support surface reconstruction, normal estimation, voxel-grid downsampling, and ICP registration in LiDAR pipelines (PCL, Open3D) for [[LiDAR Mapping]] applications.
- **[[Spatial Database]] systems** — PostGIS, Oracle Spatial, SQL Server spatial extensions, and DuckDB spatial extension all rely on R-tree or similar spatial indices for predicate pushdown and efficient join ordering.
- **Augmented/Virtual Reality** — Spatial data structures underlie [[Spatial Mapping]] meshes in headsets (HoloLens, Quest), enabling fast surface queries for physics, occlusion, and [[Nearest Neighbour Search]] for anchor placement.
- **Neural Radiance Field (NeRF) and Gaussian Splatting** — Octrees and hash grids (Instant-NGP multi-resolution hash encoding) are used to organise scene radiance data for efficient query during volume rendering in [[Spatial AI]] applications.

### Standards & Context

- **ISO 19125 / OGC Simple Features** — Defines geometry types (Point, LineString, Polygon, etc.) and spatial predicate semantics (ST_Intersects, ST_Contains) that spatial indices must correctly support in [[Spatial Database]] systems.
- **DirectX Raytracing (DXR) / Vulkan Ray Tracing (VK_KHR_ray_tracing_pipeline)** — Expose hardware-accelerated BVH traversal through a two-level TLAS/BLAS model; the structure of bottom-level acceleration structures (BLAS) is driver-managed but SAH-BVH is the dominant implementation strategy.
- **OpenCL / CUDA / SYCL** — Parallel programming models used to implement GPU BVH construction algorithms (LBVH, PLOC, ATRBVH) that build acceleration structures in milliseconds over millions of primitives.
- **Computational Geometry Algorithms Library (CGAL)** — Provides production C++ implementations of k-d trees, dD range trees, and other spatial data structures under a well-defined algebraic framework.
- **OctoMap** — A widely used C++ library implementing probabilistic [[Octree]] occupancy mapping for robotics; integrated with ROS/ROS2 as the standard 3-D occupancy representation.
- **PostGIS** — PostgreSQL extension implementing OGC spatial types with GIST (Generalised Search Tree) R-tree indices; the de-facto standard for open-source geospatial databases.
- **nanoflann** — Widely adopted header-only C++ k-d tree library; benchmarks demonstrate it outperforms CGAL and FLANN on many point-cloud workloads.
- **libLAS / Potree** — Open standards and tools for hierarchical octree-based streaming of massive [[LiDAR Mapping]] point clouds in web browsers.

### Provenance

