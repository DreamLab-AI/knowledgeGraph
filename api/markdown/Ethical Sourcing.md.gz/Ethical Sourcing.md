Ethical sourcing is the practice of buying goods and services from suppliers under agreed labour and human rights standards, and the sources opened here describe codes and guidance without defining the term.[^1][^2]

The Ethical Trading Initiative Base Code is founded on the conventions of the International Labour Organisation and is described as an internationally recognised code of labour practice.[^1] Its provisions include that there is no forced, bonded or involuntary prison labour and that there shall be no new recruitment of child labour.[^1] The code says its provisions constitute minimum and not maximum standards, and that companies applying it are expected to comply with national and other applicable law.[^1]

## Programmes and reporting

The UN Global Compact and BSR guide says that developing supply chain programmes that cover all four of the Global Compact's issue areas, human rights, labour, environment and anti-corruption, remains “a daunting challenge for many”.[^2]

In the United Kingdom, government guidance for organisations says a modern slavery statement should set out what steps an organisation has taken to ensure modern slavery is not taking place in its business or supply chains.[^3] Only the guidance landing page was opened, so the legal duties it sets out are not described here.

## Scope and limits

Ethical sourcing belongs to [[Sustainable Supply Chains]]. Related practice that is more formal about identifying and acting on harm is described at [[Supply Chain Due Diligence]], and the standards that frame it include [[SA8000]] and [[OECD Due Diligence Guidance]].

None of the sources distinguishes ethical sourcing from responsible sourcing or ethical trade, and none measures whether code compliance improves conditions.

[^1]: Ethical Trading Initiative, “ETI Base Code”. https://www.ethicaltrade.org/eti-base-code
[^2]: United Nations Global Compact and Business for Social Responsibility, 2010, “Supply Chain Sustainability: A Practical Guide for Continuous Improvement”. https://www.bsr.org/reports/BSR_UNGC_SupplyChainReport.pdf
[^3]: UK Home Office, statutory guidance, “Slavery and human trafficking in supply chains: guidance for businesses”. https://www.gov.uk/government/publications/transparency-in-supply-chains-a-practical-guide/transparency-in-supply-chains-a-practical-guide

