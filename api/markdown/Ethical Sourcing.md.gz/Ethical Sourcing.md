ical Sourcing is the corporate and institutional procurement discipline that selects, qualifies and monitors suppliers across multi-tier global supply chains against verifiable human rights, labour, environmental and anti-corruption standards — operationalised through codified frameworks (

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:SupplierCodeOfConduct))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:SupplierAudit))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ThirdPartyCertification))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ChainOfCustody))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:GrievanceMechanism))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:RemediationPlan))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:RiskAssessment))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:TransparencyStatement))

    ## Dependency Relationships
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:requires blockchain:SupplyChainTransparency))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:requires blockchain:SupplierIdentification))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:requires blockchain:RiskAssessment))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:requires blockchain:ThirdPartyAudit))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:requires blockchain:StakeholderEngagement))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:requires blockchain:WorkerVoiceMechanism))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:CertificationInfrastructure))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:RegulatoryFramework))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:MultiStakeholderInitiative))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:CivilSocietyOversight))

    ## Capability Relationships
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:enables blockchain:LivingWage))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:enables blockchain:WorkerRights))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:enables blockchain:ConflictFreeMinerals))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:enables blockchain:DeforestationFreeCommodities))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:enables blockchain:ModernSlaveryEradication))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:enables blockchain:ChildLabourPrevention))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:enables blockchain:PremiumPricing))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:supports blockchain:SustainableDevelopmentGoals))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:supports blockchain:JustTransition))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:supports blockchain:IndigenousRights))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:supports blockchain:BiodiversityConservation))

    ## Implementation Relationships
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:implements blockchain:OECDDueDiligenceGuidance))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:implements blockchain:UNGuidingPrinciplesBusinessHumanRights))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:implements blockchain:ILOCoreLabourStandards))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:implements blockchain:ISO20400))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:implements blockchain:SA8000))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:implements blockchain:UNGlobalCompact))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:uses blockchain:BlockchainProvenance))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:uses blockchain:SatelliteMonitoring))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:uses blockchain:AIRiskScoring))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:uses blockchain:NLPESGAnalysis))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:uses blockchain:IoTSensorNetwork))

    ## Reduction Relationships
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:reduces blockchain:ModernSlaveryRisk))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:reduces blockchain:ChildLabourIncidence))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:reduces blockchain:DeforestationFootprint))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:reduces blockchain:ConflictMineralFlows))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:reduces blockchain:ReputationalRisk))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:reduces blockchain:RegulatoryPenaltyExposure))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:reduces blockchain:AuditDuplication))

    ## Association Relationships
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:FairTrade))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:ModernSlaveryAct2015))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:RanaPlaza))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:ConflictMinerals))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:CSDDD))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:ESGInvesting))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:CorporatePhilanthropy))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:UnauditedSelfDeclaration))
    SubClassOf(blockchain:EthicalSourcing
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:Greenwashing))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(blockchain:hasIdentifier blockchain:EthicalSourcing "BC-0453"^^xsd:string)
    DataPropertyAssertion(blockchain:authorityScore blockchain:EthicalSourcing "0.87"^^xsd:decimal)
    DataPropertyAssertion(blockchain:globalForcedLabourEstimate2021 blockchain:EthicalSourcing "27600000"^^xsd:integer)
    DataPropertyAssertion(blockchain:globalChildLabourEstimate2020 blockchain:EthicalSourcing "160000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:fairtradeProducerHouseholds blockchain:EthicalSourcing "1930000"^^xsd:integer)
    DataPropertyAssertion(blockchain:rspoCertifiedShare blockchain:EthicalSourcing "0.19"^^xsd:decimal)
    DataPropertyAssertion(blockchain:fscCertifiedHectares blockchain:EthicalSourcing "165000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:csdddEUTurnoverThresholdEUR blockchain:EthicalSourcing "450000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:ukMSA2015TurnoverThresholdGBP blockchain:EthicalSourcing "36000000"^^xsd:integer)

    ## Annotations
    AnnotationAssertion(rdfs:label blockchain:EthicalSourcing "Ethical Sourcing"@en)
    AnnotationAssertion(rdfs:comment blockchain:EthicalSourcing "Procurement discipline qualifying suppliers across multi-tier global supply chains against verifiable human rights, labour, environmental and anti-corruption standards. Operationalised through ISO 20400, SA8000, UN Global Compact, ILO Core Labour Standards, OECD Guidelines and OECD Due Diligence Guidance for minerals; enforced through UK MSA 2015 Section 54, California SB 657, Dodd-Frank 1502, EU Conflict Minerals Regulation 2017/821, Australian Modern Slavery Act 2018, Germany LkSG 2023, Norway Transparency Act 2022, EU CSDDD June 2024, and EU Forced Labour Regulation December 2024; verified through Fairtrade International, Rainforest Alliance (post-UTZ merger 2018), FSC, MSC, RSPO, RJC, RBA and RMI; augmented by blockchain provenance (Everledger, IBM Food Trust, Provenance, Circulor for EV batteries, Minespider), AI risk-scoring (Sayari, Kharon, FiscalNote), satellite monitoring (Planet Labs, Global Forest Watch) and NLP ESG analysis (Datamaran, Truvalue Labs); core focus on 3TG and battery minerals (cobalt, lithium, nickel), cocoa/coffee/cotton/palm oil/timber/fish, garments post-Rana Plaza 2013, electronics (Apple Supplier Responsibility), and EV battery supply chain. Contrasts with ESG investing (financial-markets screening), corporate philanthropy (one-off discretionary giving), and unaudited self-declaration."@en)
    AnnotationAssertion(dcterms:identifier blockchain:EthicalSourcing "BC-0453"^^xsd:string)
    AnnotationAssertion(dcterms:subject blockchain:EthicalSourcing "Ethical Sourcing, Responsible Procurement, Sustainable Procurement, Human Rights Due Diligence, Modern Slavery, Conflict Minerals, Fair Trade, ESG, CSDDD, ISO 20400, SA8000, OECD Guidelines"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(blockchain:requires)
  AsymmetricObjectProperty(blockchain:enables)
  AsymmetricObjectProperty(blockchain:implements)
  AsymmetricObjectProperty(blockchain:contrastsWith)
  TransitiveObjectProperty(blockchain:dependsOn)
  FunctionalDataProperty(blockchain:hasIdentifier)

## About Ethical Sourcing

- **Ethical sourcing** — used interchangeably with **responsible sourcing** and **sustainable sourcing**, and overlapping substantially with **sustainable procurement** as codified in **[[ISO 20400]]:2017** — is the corporate, public-sector, and institutional procurement discipline that selects, qualifies, monitors and remediates suppliers across multi-tier global supply chains against codified human rights, labour, environmental and anti-corruption standards. It is distinguished from **fair trade** (a specific 1988-origin movement and certification system centred on smallholder-producer minimum prices and social premia, embodied in Fairtrade International / FLO and the Fair Trade Foundation), from **[[ESG]] investing** (the financial-markets discipline screening listed securities against environmental, social and governance metrics for portfolio construction), from **corporate philanthropy** (one-off discretionary giving rather than systemic operational change), and from **unaudited self-declaration** (whose recurrent failures from the 1990s sweatshop era through the 2013 **[[Rana Plaza]]** collapse drove the contemporary shift toward mandatory third-party verification and statutory due diligence).
- The conceptual scope spans **upstream** (raw material extraction — mining of 3TG and battery minerals, agricultural commodities, fishing, forestry), **midstream** (smelting and refining, processing, manufacturing including tier-2 and tier-3 component suppliers), and **downstream** (assembly, distribution, retail) operations. Modern frameworks emphasise that ~80-90% of a typical FMCG or electronics company's environmental and social footprint sits in **Scope 3** upstream supply chain rather than direct operations (per CDP Supply Chain Programme 2024 data covering 24,000+ suppliers), making robust ethical sourcing the dominant lever for both regulatory compliance and authentic sustainability impact.
- The discipline operationalises a **due diligence cycle** codified in the **[[OECD Guidelines for Multinational Enterprises]]** (originally 1976, materially updated 2011 and 2023) and the **[[OECD Due Diligence Guidance for Responsible Business Conduct]]** (2018), comprising six steps: (1) embed responsible business conduct in policies and management systems; (2) identify and assess adverse impacts in operations, supply chains and business relationships; (3) cease, prevent and mitigate adverse impacts; (4) track implementation and results; (5) communicate how impacts are addressed; (6) provide for or cooperate in remediation when appropriate. The parallel **[[UN Guiding Principles on Business and Human Rights]]** (UNGPs, John Ruggie 2011 unanimous Human Rights Council endorsement) establish the "Protect, Respect, Remedy" framework that has become the lingua franca of corporate human rights policy and forms the substantive backbone of every major contemporary statute including the EU CSDDD.

### Core Conceptual Distinctions

Four bordering concepts must be carefully distinguished for unambiguous use:

**Fair Trade vs Ethical Sourcing**: Fair Trade is a *specific* movement and certification system originating in 1946 (Ten Thousand Villages) with the modern Fairtrade label launched 1988 (Max Havelaar Netherlands), centred on guaranteed minimum prices, social premium, and democratic producer-organisation principles for smallholders in low-income countries. Ethical sourcing is *broader*, encompassing fair trade as one verification mechanism alongside SA8000, RBA, RSPO, FSC, MSC and others, and applying to all suppliers irrespective of whether they are smallholder producers.

**Sustainable Sourcing vs Ethical Sourcing**: Sustainable sourcing emphasises *environmental* dimensions — carbon footprint, water stewardship, biodiversity, deforestation, regenerative agriculture — alongside social. Ethical sourcing emphasises *social* dimensions — labour rights, human rights, anti-corruption, fair compensation — alongside environmental. In contemporary corporate usage post-CSDDD adoption (June 2024), the two converge under the umbrella of **responsible sourcing** with a unified due-diligence cycle covering both pillars.

**Responsible Sourcing**: The currently-favoured umbrella term in EU regulatory and OECD discourse, explicitly encompassing both environmental and social dimensions plus governance (anti-bribery, sanctions compliance, beneficial-ownership transparency). The **[[OECD Due Diligence Guidance for Responsible Mineral Supply Chains]]** (2011, 4th edition 2023) is the prototype.

**ESG Investing vs Ethical Sourcing**: ESG investing operates at the *financial-markets screening* layer (portfolio construction, voting, engagement with listed equity issuers), whereas ethical sourcing operates at the *operational procurement* layer (supplier qualification, contract terms, audits, remediation). Both rely on shared underlying disclosure frameworks (GRI, SASB now ISSB, TCFD, TNFD) but address different stakeholders. ESG funds are end-investors of companies practising ethical sourcing.

### Regulatory Stack (Mandatory Frameworks)

The 2010s-2020s have witnessed an unprecedented expansion of mandatory supply-chain due-diligence and disclosure law. The shift from voluntary self-declaration toward statutory liability is the defining regulatory development of corporate sourcing in the post-Rana Plaza era.

#### United States

- **[[Dodd-Frank Section 1502]]** (2010, SEC final rule August 2012): Requires SEC-registered issuers to conduct reasonable country-of-origin inquiry and supply chain due diligence for tin, tungsten, tantalum, and gold ("3TG") sourced from the Democratic Republic of Congo and adjoining countries. Annual Form SD filing with Conflict Minerals Report. Despite partial 2017 SEC enforcement scaling-back, the rule remains in force and drove ~6,000+ initial annual filings, establishing the operational template for the EU's 2017/821 successor.
- **[[California SB 657]]** Transparency in Supply Chains Act (2010, effective 1 January 2012): Requires retailers and manufacturers with global revenues exceeding $100M to disclose efforts to eradicate slavery and human trafficking from direct supply chains. ~3,200 companies in scope.
- **Uyghur Forced Labor Prevention Act** (UFLPA, December 2021, effective June 2022): Rebuttable presumption that any goods produced wholly or partly in the Xinjiang Uyghur Autonomous Region of China are made with forced labour and therefore prohibited from US importation under 19 USC § 1307. Customs and Border Protection has detained $3.4B+ in shipments through 2024, primarily cotton apparel, polysilicon for solar panels, and tomato products.
- **Strategic and Critical Materials Stockpiling Act amendments** and federal procurement clauses (FAR 22.17, FAR 52.222-50) prohibiting human trafficking by federal contractors.

  #### European Union

- **[[EU Conflict Minerals Regulation 2017/821]]** (effective 1 January 2021): Direct successor to Dodd-Frank 1502, mandating EU importers of 3TG to conduct OECD-aligned five-step due diligence, with mandatory third-party audits for downstream smelters/refiners. ~600-1,000 EU importers in scope.
- **[[EU Corporate Sustainability Reporting Directive]]** (CSRD, Directive 2022/2464, applicable from fiscal 2024 phased through 2028): Mandates ESRS-based sustainability reporting covering ~50,000 EU and non-EU entities with substantial EU presence. Includes supply-chain Scope 3 emissions and human-rights value-chain disclosures.
- **[[EU Corporate Sustainability Due Diligence Directive]]** (CSDDD, "CS3D", Directive 2024/1760 adopted 13 June 2024, transposition deadline July 2026, staggered application 2027-2029): Imposes mandatory **civil liability** on companies meeting size thresholds (≥1,000 employees and €450M global net turnover, or non-EU equivalent EU-generated turnover) for adverse human-rights and environmental impacts in their "chain of activities" (the EU's compromise replacement for "value chain"). Includes climate transition plan obligation aligned with the Paris Agreement 1.5°C trajectory. Enforcement by national supervisory authorities with fines up to 5% of net worldwide turnover. The CSDDD is the most far-reaching mandatory ethical-sourcing law globally.
- **[[EU Forced Labour Regulation]]** (Regulation 2024/3015 adopted 19 November 2024, OJ published December 2024, applicable from 14 December 2027): Prohibits the placement and making available on the EU market, and the export from the EU, of products made with forced labour at any stage of production. Centralised Commission database and national-authority investigation powers. The first global supply-chain instrument with explicit customs interdiction.
- **EU Deforestation Regulation** (EUDR, Regulation 2023/1115, applicable from 30 December 2025 after 12-month delay): Prohibits placement on EU market of soy, beef, palm oil, wood, cocoa, coffee, rubber and derived products linked to post-31 December 2020 deforestation. Mandatory geolocation and DDS (Due Diligence Statement) for every consignment.

  #### National European Statutes

- **France Loi de Vigilance** (Loi 2017-399 of 27 March 2017): First national mandatory human-rights and environmental due diligence law globally. Applies to French parent and lead-contractor companies with ≥5,000 French employees or ≥10,000 worldwide. Civil-liability regime for damages from failure to publish or implement adequate vigilance plan. Total Energies, Casino, Suez and EDF have all faced litigation under the law.
- **[[Germany LkSG]]** Lieferkettensorgfaltspflichtengesetz (Supply Chain Due Diligence Act, in force 1 January 2023): Applies to companies with ≥3,000 employees in Germany (≥1,000 from 2024). Mandates risk analysis, preventive measures, complaints procedure, documentation and reporting. Enforcement by BAFA (Federal Office for Economic Affairs and Export Control) with fines up to €8M or 2% of annual global turnover for entities with >€400M turnover, plus public procurement exclusion up to three years.
- **[[Norway Transparency Act]]** Åpenhetsloven (in force 1 July 2022): Applies to all "larger enterprises" (~9,000 entities) operating in Norway. Mandates due-diligence assessments aligned to OECD Guidelines and UNGPs, public account by 30 June annually, and right-to-information for any individual or organisation. Enforcement by Norwegian Consumer Authority (Forbrukertilsynet).
- **Netherlands Child Labour Due Diligence Act** (Wet Zorgplicht Kinderarbeid, adopted 2019, enforcement pending): Requires statement of due-diligence to prevent child labour in goods/services delivered to Dutch consumers.
- **Switzerland Indirect Counter-Proposal** (in force 1 January 2022): Mandatory due-diligence on conflict minerals and child labour, with annual reporting obligations.

  #### Other Jurisdictions

- **[[UK Modern Slavery Act 2015]]**, Section 54: Annual transparency-in-supply-chains statement for commercial organisations with ≥£36M global turnover. ~17,000 entities in scope. Statements published in the central UK Modern Slavery Statement Registry (operated by Home Office, launched March 2021).
- **[[Australian Modern Slavery Act 2018]]** (Cth): Annual Modern Slavery Statement for reporting entities with consolidated revenue ≥AUD $100M. ~3,000 entities in scope. Australian Government Modern Slavery Statements Register publicly accessible.
- **Canada Fighting Against Forced Labour and Child Labour in Supply Chains Act** (Bill S-211, in force 1 January 2024): Annual reporting for government institutions and entities with ≥CAD $40M revenue.
- **Japan Guidelines on Respecting Human Rights in Responsible Supply Chains** (METI September 2022): Non-binding but with public-procurement linkage from 2023.

### International Standards and Voluntary Frameworks

- **[[ISO 20400]]:2017 Sustainable Procurement Guidance**: Voluntary, non-certifiable standard providing guidance for any organisation procuring goods and services. Defines sustainable procurement as the integration of sustainability into the procurement function from strategy to implementation. Aligned with UNGPs and OECD Guidelines.
- **[[SA8000]]:2014** (Social Accountability International): Auditable, certifiable management system standard covering ILO Core Labour Conventions plus management-system requirements. ~4,500 certified facilities in 60+ industries.
- **[[UN Global Compact]]** (launched 2000): Ten principles covering human rights, labour, environment and anti-corruption. ~16,000 corporate signatories and ~70 country networks. Communications on Progress (COP) annually published.
- **[[ILO Core Labour Standards]]**: Eight fundamental ILO Conventions covering freedom of association (87, 98), forced labour (29, 105), child labour (138, 182), and non-discrimination (100, 111), plus the 2022 addition of occupational safety and health (155, 187) to the core. Universal applicability across 187 ILO member states.
- **[[UN Guiding Principles on Business and Human Rights]]** (UNGPs, 2011): "Protect, Respect, Remedy" framework. UN Working Group on Business and Human Rights conducts country visits and reports.
- **[[OECD Guidelines for Multinational Enterprises]]** (1976, materially updated 2011 and 2023): Government-backed recommendations covering disclosure, human rights, employment, environment, anti-bribery, consumer interests, science and technology, competition, and taxation. Implemented through National Contact Points (NCPs) in 51 OECD/adherent countries providing non-judicial grievance mechanisms.
- **[[OECD Due Diligence Guidance for Responsible Mineral Supply Chains]]** (2011, 4th edition 2023): The reference framework for 3TG and cobalt (covered in Supplement on Tin, Tantalum and Tungsten 2nd edition, and Supplement on Gold). Five-step framework adopted by the LBMA Responsible Gold Guidance, RJC Code of Practices and Chain of Custody, and the Responsible Minerals Initiative RMAP.
- **GRI Standards** (Global Reporting Initiative): Most widely used sustainability disclosure framework, covering 80%+ of S&P 500 sustainability reports. GRI 414 Supplier Social Assessment and GRI 308 Supplier Environmental Assessment directly address ethical sourcing.
- **SASB / ISSB** (Sustainability Accounting Standards Board, integrated into the IFRS Foundation's International Sustainability Standards Board 2022): IFRS S1 (general sustainability) and IFRS S2 (climate) released June 2023. Industry-specific supply-chain metrics.
- **TCFD / TNFD**: Task Force on Climate-related Financial Disclosures (2017, IFRS-absorbed 2024) and Task Force on Nature-related Financial Disclosures (final v1.0 September 2023) — both include supply-chain dependencies and impacts.

### Certification Schemes (Commodity-Specific and Cross-Cutting)

- **[[Fairtrade International]]** (FLO, founded 1997): ~1.93 million Fairtrade certified producer households across 73 countries (2023 figures). Coffee (largest by volume), cocoa, banana, cane sugar, cotton, tea, flowers. Fairtrade Minimum Price + Fairtrade Premium model. The UK **[[Fairtrade Foundation]]** (founded 1992, registered charity) operates Fairtrade Fortnight and the FAIRTRADE Mark licensing in the UK.
- **[[Rainforest Alliance]]** (founded 1987, merged with UTZ Certified 2018): Sustainable agriculture standard covering ~5.1M hectares and ~2M farmers across coffee, cocoa, tea, banana, palm oil, herbs and spices. 2020 Sustainable Agriculture Standard (the post-merger unified standard) includes climate, gender equality, child labour, living wage, and assess-and-address methodology. The 2018 UTZ merger consolidated the two largest agricultural-ethics labels.
- **[[Forest Stewardship Council]]** (FSC, founded 1993): ~165 million hectares of FSC-certified forest globally. FSC Chain of Custody certification for processors and traders. FSC Forest Management Standard plus 10 Principles and 70 Criteria.
- **[[Marine Stewardship Council]]** (MSC, founded 1997, originally an Unilever–WWF partnership): Sustainable seafood certification covering ~19% of global wild marine catch (~16M tonnes annually).
- **Aquaculture Stewardship Council** (ASC, founded 2010): Sister organisation for farmed seafood.
- **[[Roundtable on Sustainable Palm Oil]]** (RSPO, founded 2004): ~19% of global palm oil supply RSPO-certified. RSPO Principles & Criteria updated 2018 (no deforestation/peat/exploitation). NDPE commitments cover ~83% of refining capacity.
- **[[Responsible Jewellery Council]]** (RJC, founded 2005): ~1,800 member companies across the diamond, gold, silver, and platinum-group-metals jewellery supply chain. RJC Code of Practices (CoP) plus Chain of Custody Standard aligned to OECD DDG and LBMA Responsible Gold Guidance.
- **[[Responsible Business Alliance]]** (RBA, formerly Electronic Industry Citizenship Coalition EICC, rebranded 2017): ~240+ electronics industry members (Apple, Dell, HP, IBM, Intel, Samsung, etc.). RBA Code of Conduct, Validated Assessment Programme (VAP) factory audits, and the Responsible Labor Initiative (RLI), Responsible Minerals Initiative (RMI) and Responsible Factory Initiative (RFI) sub-programmes.
- **[[Responsible Minerals Initiative]]** (RMI, founded 2008 as the Conflict-Free Sourcing Initiative, rebranded 2017): The Responsible Minerals Assurance Process (RMAP) operates the Conformant Smelter List for 3TG and cobalt — the de facto global standard for downstream conflict-mineral compliance. Used by all major Dodd-Frank Section 1502 and EU 2017/821 filers.
- **Fair Wear Foundation** (Netherlands, founded 1999): Multi-stakeholder initiative for garments covering ~140 brands and 2.7M workers. Living wage, factory monitoring, complaints helpline.
- **Better Cotton Initiative** (BCI, founded 2009): Largest cotton sustainability programme — ~22% of global cotton production licensed as Better Cotton (~5.5M farmers).
- **B Corp Certification** (B Lab, founded 2006): Certifies entire companies (not products) across governance, workers, community, environment, customers. ~8,200 certified B Corps globally including Patagonia, Ben & Jerry's, Allbirds, Innocent Drinks.
- **Bluesign** (textile chemicals), **Cradle to Cradle Certified** (circular design), **GOTS** (Global Organic Textile Standard), **OEKO-TEX**, **Fair for Life** (small-scale producers).

### Technology Stack: Blockchain Provenance, AI Risk Scoring, Satellite Monitoring

Modern ethical sourcing increasingly relies on a triad of technologies that together address the fundamental limits of paper-based audit: tier-N invisibility, audit gaming, audit fatigue, and lag between violation and detection.

#### Blockchain Provenance Platforms

- **[[Everledger]]** (founded 2015, UK/Australia, Leanne Kemp): Pioneering blockchain provenance for diamonds — ~2M+ diamonds digitally recorded combining synthetic carbon attributes, certification data, and chain-of-custody events. Expanded to coloured gemstones, fine wine, and battery materials. Partners with LVMH AURA platform.
- **[[IBM Food Trust]]** (commercial 2018, evolved from the 2016 Walmart-IBM pilot): Hyperledger Fabric–based shared ledger covering ~200 member organisations including Walmart (mandated leafy-greens traceability 2018), Carrefour, Nestlé, Tyson Foods, Dole, Driscoll's. Pallet-level traceback time reduced from 7 days to 2.2 seconds in Walmart trials.
- **[[Provenance Ltd]]** UK (founded 2014, Jessi Baker): Provenance Framework powering ethical sourcing claims for 800+ brands including Co-op, Unilever, Sainsbury's, M&S. Specialises in fashion (Martine Jarlgaard wool jacket — first blockchain-traced garment 2017), FMCG, beauty.
- **[[Circulor]]** (founded 2017, UK/Cambridge, Douglas Johnson-Poensgen): The leading EV battery supply-chain traceability platform. Customers include Ford, Volvo Cars, Polestar, Mercedes-Benz, Jaguar Land Rover, BHP and Total Energies. Traces cobalt from DRC artisanal sites and large-scale mines through CDM refining (Glencore Kamoto) to cathode active material (CAM) and assembled battery packs. Critical for EU Battery Regulation 2023/1542 due-diligence compliance from 18 August 2025.
- **[[Minespider]]** (Berlin, founded 2017, Nathan Williams): 3TG, copper and nickel supply-chain traceability — used by Google, Volkswagen, Ford, Minsur (tin), and the Responsible Cobalt Initiative.
- **[[Open Food Network]]** (Australia/UK, open-source cooperative): Decentralised food supply-chain network connecting producers to consumers via short-chain distribution and transparent provenance. ~2,000 enterprises in 22 countries.
- **AURA Blockchain Consortium** (LVMH, Prada Group, Cartier, OTB, Mercedes-Benz founded 2021): Luxury authenticity and ethical sourcing for handbags, jewellery, watches.
- **OriginTrail**, **TE-FOOD** (livestock and fresh produce, Vietnam), **VeChain** (general supply-chain), **AgriDigital** (Australian grain).

  #### AI Risk Scoring and ESG Intelligence

- **[[Sayari Graph]]** (Washington DC, founded 2015): Beneficial-ownership and corporate-network graph database covering ~500M entities across 250+ jurisdictions. Used by US Customs and Border Protection for UFLPA enforcement, by EU customs authorities, and by Tier-1 corporates for supply-chain forced-labour risk screening. The dominant commercial open-source intelligence (OSINT) tool for supply-chain due diligence.
- **[[Kharon]]** (Los Angeles, founded 2018 by former Treasury/OFAC staff): Sanctions, export controls, and forced-labour exposure mapping. ClearView product traces complex ownership and operational links to designated parties.
- **[[FiscalNote]]** (Washington DC, NYSE:NOTE): Regulatory and political-intelligence platform increasingly applied to ESG and supply-chain risk.
- **[[Datamaran]]** (London, founded 2015): NLP-driven materiality assessment scanning regulatory, news, NGO and social-media corpora for emerging ESG and supply-chain risks. ~200 corporate clients.
- **[[Truvalue Labs]]** (acquired by FactSet 2020, then integrated into Morningstar Sustainalytics 2020/2021): AI-driven analysis of unstructured ESG signals from news, NGO and stakeholder sources, generating real-time material ESG scores.
- **KKS Advisors** (Boston/London, founded 2014 by George Serafeim of Harvard Business School and Sakis Kotsantonis): ESG materiality advisory firm pioneering materiality-mapping methodologies underpinning SASB and ISSB.
- **RepRisk** (Zurich, founded 2006): Dataset of ~250,000 entities with daily updates on ESG and business-conduct incidents from public sources.
- **Sustainalytics** (Morningstar), **MSCI ESG Research**, **ISS ESG**, **S&P Global Sustainable1**: The four dominant institutional ESG-data providers integrating supply-chain controversy signals.

  #### Satellite Monitoring and Geospatial Verification

- **[[Planet Labs]]** (NYSE:PL, founded 2010): Operates the largest commercial Earth-observation constellation — ~200 SuperDove satellites imaging the entire terrestrial land mass daily at 3m resolution. Used by Cargill, Unilever, Mars, Nestlé and Mondelez for soy and palm-oil deforestation monitoring; by Volvo and Mercedes for cobalt mine-site verification; and by EU customs for EUDR compliance.
- **[[Global Forest Watch]]** (World Resources Institute, founded 2014): Open-access platform combining Landsat, Sentinel and Planet imagery with the Hansen-Potapov global forest change dataset (University of Maryland) and the MAAP (Monitoring of the Andean Amazon Project) deforestation-alert system. Free public access has become the universal baseline for corporate no-deforestation commitment monitoring.
- **[[SOMO]]** (Centre for Research on Multinational Corporations, Netherlands): Independent research institute applying satellite analysis and corporate-records investigation to expose supply-chain violations.
- **Trase** (Stockholm Environment Institute and Global Canopy, founded 2016): Open-data platform linking commodity flows (soy, beef, cocoa, palm oil) to specific landscapes and corporate buyers.
- **Starling** (Airbus + The Forest Trust): Operational deforestation-alert service used by Nestlé, Ferrero, L'Oréal.
- **Mighty Earth** Rapid Response: Continuous monitoring of palm-oil and cocoa supply chains with corporate accountability publications.

### Use Cases / Major Families

#### Conflict Minerals: 3TG and Beyond
Tin, tantalum, tungsten and gold ("**3TG**" — the "T" in tantalum is sometimes referred to as "coltan" for columbite-tantalite ore) plus cobalt are the canonical conflict-minerals category, originally focused on the Democratic Republic of Congo and adjoining countries where mineral revenues have historically funded armed groups during the Second Congo War (1998-2003) and successive eastern DRC conflicts. The **[[OECD Due Diligence Guidance for Responsible Mineral Supply Chains]]** (2011, 4th ed. 2023) and its supplements provide the operational framework, implemented downstream through the **[[Responsible Minerals Initiative]]** RMAP Conformant Smelter List. The 2024 4th edition explicitly extends due-diligence expectations to **cobalt, mica, copper, lithium and nickel** following the EV battery supply-chain expansion. Cobalt-specific initiatives include the Cobalt for Development partnership (BMW, BASF, Samsung SDI), the Fair Cobalt Alliance, and Apple's Glencore Kamoto Operating Limited (KOL) cobalt supply with full Circulor traceability.

#### Battery Supply Chain (Cobalt, Lithium, Nickel, Manganese, Graphite)
Rapid EV transition is driving the most intensively-scrutinised contemporary supply chain. ~70% of cobalt mined in DRC (estimated 15-30% from artisanal and small-scale mining with documented child labour by Amnesty International's 2016 "This Is What We Die For" and 2023 follow-up reports), ~60% of lithium concentrated in Australia, Chile and China, ~40% of nickel processing in Indonesia (often with significant deforestation in Sulawesi and Halmahera). The **[[EU Battery Regulation]]** (2023/1542) imposes mandatory due-diligence aligned to OECD DDG from 18 August 2025 plus Battery Passport disclosure from 18 February 2027. Major OEMs (Volvo, Polestar, Mercedes-Benz EQ, Ford F-150 Lightning, Jaguar Land Rover) have committed to full Circulor traceability for cathode-active materials.

#### Garment Industry (Post-Rana Plaza)
The 24 April 2013 collapse of the Rana Plaza building in Savar, Bangladesh killed 1,134 garment workers and injured over 2,500, becoming the deadliest accidental garment-industry disaster in history. The aftermath produced the **Accord on Fire and Building Safety in Bangladesh** (May 2013, ~200 brand signatories covering ~1,600 factories employing ~2M workers, transitioned in 2021 to the **International Accord** with country extensions to Pakistan in 2023), the parallel North American **Alliance for Bangladesh Worker Safety** (2013-2018), and substantial brand reforms. The **Bangladesh Worker Safety Initiative** (BWB) coordinates ongoing remediation. Key brands and platforms in garment-sector ethical sourcing include Inditex (Zara), H&M, M&S Plan A 2025, John Lewis Partnership, Patagonia, Eileen Fisher, Levi's, Adidas, Nike, and the Fair Wear Foundation 140-brand programme.

#### Electronics Supply Chain
The electronics sector pioneered structured supplier-conduct programmes through the **RBA** (formerly EICC). **Apple Supplier Responsibility Reports** (annual since 2007, 18th edition 2024) cover 1,000+ supplier facilities and 1.5M+ workers, with detailed metrics on overtime, underage labour, recruitment fees, environmental violations and remediation. Major contract manufacturers — **Foxconn** (Hon Hai Precision Industry), **Pegatron**, Wistron, Compal, Quanta, Inventec — operate under the RBA Code and brand-specific codes (Apple Supplier Code of Conduct). Recurring controversies (Foxconn Zhengzhou 2010 suicides and 2022 worker unrest, Pegatron Shanghai working-hours violations, Catcher Technology dormitory conditions) have driven continuous programme strengthening.

#### Cocoa, Coffee, Cotton, Palm Oil, Timber, Fish

- **Cocoa**: ~70-80% from Côte d'Ivoire and Ghana with documented child-labour incidence (NORC 2020 University of Chicago report: ~1.56M children in West African cocoa). **[[Tony's Chocolonely]]** Dutch brand operates 100%-traceable cocoa from 15,000+ farmers; **Cocoa Horizons** (Barry Callebaut); **Cocoa Life** (Mondelez); **Cocoa Plan** (Nestlé); the **World Cocoa Foundation** and the **CocoaAction** industry programme.
- **Coffee**: 25M+ smallholder coffee farmers globally. Fairtrade, Rainforest Alliance, 4C, Café Practices (Starbucks), Nespresso AAA Sustainable Quality. IBM-Farmer Connect "Thank My Farmer" blockchain app.
- **Cotton**: ~22% Better Cotton Initiative coverage. Xinjiang cotton (CCP-linked forced labour, Sheffield Hallam Helena Kennedy Centre extensive research) prohibited under UFLPA.
- **Palm Oil**: RSPO (~19% certified), POIG Palm Oil Innovation Group, NDPE commitments covering ~83% of refining capacity.
- **Timber**: FSC, PEFC, EUTR (EU Timber Regulation 995/2010), UKTR, and post-2025 the EUDR.
- **Fish/Seafood**: MSC wild capture, ASC aquaculture, Seafood Watch (Monterey Bay Aquarium), Fishery Improvement Projects. Thai seafood industry post-2014 EU yellow-card crisis and 2015 Associated Press exposé on Thai fishing-vessel forced labour drove ILO Convention 188 ratification (2019), Issara Institute Worker Voice deployment to 200,000+ migrant workers, and Royal Thai Government Port-In-Port-Out monitoring system.

  #### Critical Raw Materials Beyond 3TG

- **Mica**: ~25% of global mica from artisanal mines in Jharkhand and Bihar (India) with documented child-labour incidence. Responsible Mica Initiative (founded 2017) covers Merck, Sun Chemical, BASF, Estée Lauder, L'Oréal, Coty.
- **Rare Earth Elements (REEs)**: ~70% concentrated in Chinese processing; Mountain Pass California, Lynas Australia, and Greenland projects under enhanced due-diligence frameworks.
- **Bauxite/Aluminium**: ASI (Aluminium Stewardship Initiative) certification covering ~50% of global primary aluminium. Guinea bauxite, Brazilian alumina supply chains under scrutiny.
- **Copper**: Codelco, Anglo American, BHP committing to chain-of-custody certification under the Copper Mark (launched 2020).

  #### Pharmaceutical and Healthcare Supply Chains

- **Active Pharmaceutical Ingredients (APIs)**: ~70% global API production concentrated in China and India with significant environmental discharge concerns (antibiotic residues in wastewater documented by Changing Markets Foundation).
- **Medical devices and PPE**: Post-COVID-19 procurement reforms emphasising ethical sourcing including UK NHS Modern Slavery in Supply Chains Strategy (2024).
- **Surgical instruments**: Sialkot (Pakistan) ~70% global surgical-instrument production with documented child-labour incidence; British Association of Plastic, Reconstructive and Aesthetic Surgeons (BAPRAS) ethical-sourcing initiatives.

### Business Impact, Cost-Benefit, and Material Risk

Ethical sourcing has transitioned in the 2020s from a discretionary brand-protection activity to a financially-material risk-management discipline. Material risk dimensions, all increasingly quantified in regulatory filings and ESG-data products:

#### Direct Financial Costs of Failure

- **Regulatory penalties**: Germany LkSG fines up to €8M or 2% of global turnover; EU CSDDD up to 5% of net worldwide turnover; UFLPA shipment detentions averaging $50K-$2M per consignment with 60+ day clearance delays.
- **Litigation exposure**: Rana Plaza brand settlements (~$30M collective); Tahir Hussain v. Wm Morrison Supermarkets (UK 2018 Modern Slavery civil claim); Sherpa / Vigilance Law civil claims against Total Energies, EDF, Casino, Suez under French Loi de Vigilance.
- **Stranded inventory and supply disruption**: Xinjiang cotton exclusion forced apparel-brand restocking estimated $3-7B industry-wide 2021-2024; cobalt supply-chain disruptions estimated $200M-500M per major OEM.
- **Capital cost premium**: Sustainability-linked loans and bonds (SLB market ~$1.6 trillion outstanding 2024) increasingly price ethical-sourcing KPIs into pricing margins (typical 5-25 bps step-up/step-down).
- **Audit and certification cost**: $50,000-£200,000 per facility per annual ethical audit cycle; an aggregate ~$15-25B global commercial audit market by 2025.

  #### Operational Benefits

- **Audit consolidation**: Mutual-recognition agreements (RBA, Sedex SMETA, BSCI) reducing supplier audit fatigue by ~30-60% via shared audit reports.
- **Supplier capability building**: Long-term supplier investment yields documented productivity, quality and retention benefits — academic studies (Distelhorst, Hainmueller, Locke 2015 on Nike Bangladesh) demonstrate ~10-30% productivity gains in remediated facilities.
- **Reduced supply-chain volatility**: Verified ethical suppliers correlate with 20-40% lower disruption-event incidence (CDP Supply Chain Programme).
- **Access to finance**: ICC Banking Commission Sustainable Trade Finance Working Group documents 12-18% pricing improvement for verified ethical-sourcing trade finance.

  #### Commercial and Brand Benefits

- **Premium pricing**: 5-25% pricing premia for verifiably ethical products (per Nielsen 2023 consumer survey, McKinsey ESG premium analysis).
- **Market access**: Public procurement (representing ~14% of EU GDP) increasingly conditional on demonstrable ethical-sourcing compliance under Procurement Directive 2014/24/EU.
- **Talent attraction and retention**: Sustainability-linked brands report 15-25% advantage in graduate-recruitment metrics (Universum Most Attractive Employers).
- **Investor relations**: 85%+ of major institutional investors now incorporate ESG/ethical-sourcing factors in investment processes (PRI 2024 signatories: 5,300+ representing $128 trillion AUM).

  #### Consumer and Civil-Society Dynamics

- **Consumer awareness**: 73% of UK consumers (YouGov 2024) and 72% of EU consumers consider ethical sourcing in purchase decisions; 25-35% report having boycotted brands over ethical failures.
- **NGO investigation cycles**: ~2-week investigative-report-to-share-price-impact cycle for major exposures (e.g., Apple Catcher Technology 2018, Boohoo Leicester 2020).
- **Social-media amplification**: Twitter/X and TikTok reducing the latency from violation discovery to mainstream-media coverage; the Boohoo Leicester garment-worker exposé (Sunday Times Insight Team, July 2020) wiped £1.5B from Boohoo's market cap within five trading days.

### Implementation Architecture: From Policy to Operations

Mature ethical-sourcing programmes integrate seven operational layers:

#### 1. Governance and Policy Layer

- **Board-level ownership**: Committee charters explicitly assigning supply-chain human-rights oversight (under CSDDD, mandatory at directorial level for in-scope entities).
- **Supplier Code of Conduct**: The contractual articulation of ethical standards binding tier-1 suppliers, typically including ILO Core Conventions, anti-corruption (UK Bribery Act / FCPA), environmental, and grievance-mechanism provisions.
- **Human Rights Policy**: Stand-alone UNGP-aligned commitment, typically Board-approved with named accountable executive.

  #### 2. Risk Assessment Layer

- **Country risk mapping**: Combining ILO indicators, ITUC Global Rights Index, Transparency International CPI, Walk Free Global Slavery Index, US Trafficking in Persons Report.
- **Commodity risk mapping**: Sector-specific tools — Verisk Maplecroft, SHIFT Sector Guidance, RBA Risk Assessment Platform, OECD Sectoral Guidances.
- **Supplier-level risk**: Beneficial-ownership analysis (Sayari, OpenCorporates, OFAC SDN, UK Companies House People with Significant Control register), past-incident screening (RepRisk, BHRRC).
- **Geo-spatial risk**: Mine sites, plantations and factories overlaid with satellite-detected deforestation, fire alerts, conflict events (ACLED).

  #### 3. Supplier Due Diligence Layer

- **Self-Assessment Questionnaire (SAQ)**: Standardised templates (RBA SAQ, EcoVadis, Sedex SAQ).
- **Documentary verification**: Certificates (SA8000, ISO 14001, FSC CoC, RJC CoC, etc.), policies, training records, complaint logs.
- **On-site audit**: Independent third-party audits to RBA VAP, SMETA 4-Pillar, BSCI, SA8000 methodology — typically annual to triennial.
- **Worker interviews**: Off-site, multilingual, anonymous — under best practice WSR Network model.

  #### 4. Continuous Monitoring Layer

- **Worker voice tools**: Ulula, &Wider, Laborlink, Diginex, Issara Institute Worker Voice (Thai fishing/seafood).
- **Anonymous hotlines**: NAVEX EthicsPoint, Convercent, internally-managed.
- **Public-source surveillance**: News, NGO reports, social media monitoring via RepRisk, Datamaran, Sayari Watch.
- **Satellite alerts**: Global Forest Watch, Trase, Mighty Earth Rapid Response — automated subscription to alerts within sourcing footprint.

  #### 5. Remediation Layer

- **Corrective Action Plans (CAPs)**: Time-bound, root-cause-addressing supplier improvement plans with verification.
- **Worker remediation**: Direct remediation to affected workers — back-wages, medical care, return-to-origin assistance for trafficked workers, formal apologies.
- **Capacity-building investments**: Joint training, technical assistance, financial support to enable supplier compliance.
- **Disengagement**: Last-resort, conducted responsibly under OECD Guidelines (avoiding causing further harm to affected workers).

  #### 6. Reporting and Transparency Layer

- **Statutory disclosures**: UK MSA Section 54, Australian MSA, California SB 657, Norway Transparency Act, Germany LkSG annual reports, CSDDD reports (from 2027).
- **Voluntary disclosures**: GRI, SASB/ISSB, TCFD, TNFD reports; CDP Climate / Forests / Water responses.
- **Supplier list publication**: Increasingly standard practice (Inditex, H&M, M&S, Apple, Adidas, Nike publish supplier lists).
- **Modern Slavery Statement Registry** publication.

  #### 7. Engagement and Influence Layer

- **Multi-stakeholder initiatives**: ETI, Fair Wear Foundation, IDH, Bonsucro, GeSI, RBA, RMI participation.
- **Industry policy advocacy**: Coalition for Fair Standards, Modern Slavery Strategy Implementation Group.
- **Capacity-building partnerships**: ILO Better Work programme, IFC supplier-finance facilities.

### Academic Context

#### Foundational Theory

- **John Ruggie** (Harvard Kennedy School, UN Special Representative on Business and Human Rights 2005-2011): Architect of the **UN Guiding Principles on Business and Human Rights** (2011), the foundational text establishing the "Protect, Respect, Remedy" framework underpinning all subsequent corporate due-diligence regimes. Ruggie's 2013 *Just Business: Multinational Corporations and Human Rights* (W.W. Norton) remains the canonical academic treatment.
- **Genevieve LeBaron** (Simon Fraser University, formerly University of Sheffield): Leading academic on global supply-chain labour governance, particularly forced labour. *Combatting Modern Slavery: Why Labour Governance is Failing and What We Can Do About It* (Polity 2020). LeBaron's 2018 *Risky Business* (Sheffield/Yale collaboration) documents audit-industry failures.
- **Surya Deva** (UN Working Group on Business and Human Rights, formerly City University Hong Kong): Major academic voice on business and human rights mandatory regulation.
- **Andrew Crane** (Bath University): Co-author of *Modern Slavery* (Polity 2019) and authoritative on the political economy of forced labour in global supply chains.
- **Stephanie Barrientos** (University of Manchester Global Development Institute): Pioneering work on ethical trade, gender in global value chains, and the social dimensions of cocoa, fruit and apparel supply chains. *Gender and Work in Global Value Chains* (Cambridge UP 2019).
- **Gary Gereffi** (Duke University): Global Value Chains framework. *Global Value Chains and Development* (Cambridge UP 2018) — the foundational political-economy treatment of how value is created and captured along multi-tier production networks.

  #### Supply-Chain Operations Management

- **Hau Lee** (Stanford GSB): *The Triple-A Supply Chain* (HBR 2004); seminal work on agility, adaptability and alignment including ethical-sourcing dimensions.
- **Yossi Sheffi** (MIT Center for Transportation and Logistics): *Balancing Green: When to Embrace Sustainability in a Business* (MIT Press 2018); supply-chain risk including sustainability dimensions.
- **ChloéMikolajczak Loubière**, **Aleda Roth**, **Stephanie Eckerd**: Operations Management Society of America researchers on supplier-management for sustainability.

  #### Empirical Audit and Compliance Studies

- **Locke, Qin and Brause** (MIT 2007): *Does Monitoring Improve Labor Standards? Lessons from Nike* — landmark empirical study demonstrating limited impact of supplier audits without remediation and capacity-building.
- **Short, Toffel and Hugill** (Harvard/Yale): Studies of factory audit fraud and audit-quality predictors.
- **LeBaron and Lister** (Sheffield 2015, 2018): Critique of the audit regime, demonstrating capture by audit firms and persistent gaming by suppliers.

### Current Landscape (2026)

As of May 2026, ethical sourcing has transitioned definitively from voluntary brand-led initiative to statutorily-mandated due-diligence regime, with the EU CSDDD transposition deadline (July 2026) driving an unprecedented surge in corporate due-diligence investment.

#### Regulatory State of Play

- **EU CSDDD** transposition into national law underway across 27 Member States with Q3 2026 deadline. Germany, France and Netherlands publishing draft transposition acts; UK government considering similar legislation as part of post-Brexit regulatory alignment debate.
- **EU Forced Labour Regulation** (December 2024) entering operational preparation phase: Commission database launch, Member State competent authority designations, and corporate readiness programmes accelerating.
- **EUDR** applicable from 30 December 2025 (after 12-month delay agreed October 2024) — driving major investments in cocoa, coffee, soy, beef and palm-oil traceability platforms.
- **EU Battery Regulation** due-diligence obligations effective 18 August 2025, with Battery Passport requirements from 18 February 2027.
- **US**: UFLPA enforcement at $3.5B+ detentions through Q1 2026; bipartisan support for additional supply-chain transparency legislation; Treasury OFAC continuing Russia and Xinjiang sanctions.

  #### Industry Adoption Patterns

- **Apple Supplier Responsibility 18th edition (2024)** discloses 1,113 audited supplier facilities, 1,613,000 workers covered, 232,000 separate worker interviews conducted, 100% smelter conformance for tantalum, tungsten and gold (~85% for tin) since 2015, and the company's transition to 100% recycled cobalt by 2026 (achieved 25% in 2024 per the 2024 Environmental Progress Report).
- **Tony's Chocolonely** continues 100%-traceable cocoa from 15,000+ farmers in Ghana and Côte d'Ivoire, with the "Tony's Open Chain" platform now adopted by Albert Heijn (Delicata), Aldi (Choceur), Ben & Jerry's, Jokolade (Germany), and PLUS (Netherlands).
- **Inditex (Zara)** publishes audited supplier list (1,800+ suppliers, 8,800+ factories) under its sustainability roadmap including 100% sustainable cotton by 2025.
- **Volvo Cars** announced full Circulor traceability for cobalt across all electric vehicle production (2024) and is extending to mica, nickel and lithium.
- **Mercedes-Benz** EQ range and Polestar 4 use Circulor traceability with documented chain of custody from Kamoto Copper Company (Glencore) artisanal-mining-segregated cobalt.
- **Unilever Sustainable Living Plan 2010-2020**, succeeded by the Unilever Compass Strategy (2020-2030) targeting deforestation-free supply by end-2023 (substantially achieved with continuing residual programmes).
- **Nestlé** Cocoa Plan and Income Accelerator Programme (2022) paying conditional cash incentives directly to ~10,000 cocoa farmer families.

  #### Public Procurement

- **EU Public Procurement Directive (2014/24/EU)** sustainable-procurement provisions implemented across Member States.
- **UK Procurement Act 2023** (in force 24 February 2025) introduces mandatory social-value considerations and supplier exclusion grounds for modern slavery offences.
- **US Federal Acquisition Regulation Subpart 22.17** ("Combating Trafficking in Persons") and the 2022 **Buy Clean Initiative** for low-embodied-carbon construction materials.
- **OECD Public Procurement Toolbox** and World Bank Sustainable Public Procurement guidance.

  #### Civil Society and Worker Organisations

- **Global Union Federations**: IndustriALL, UNI Global Union, IUF (food), BWI (building/wood). Bargaining counterparts in Global Framework Agreements with multinationals.
- **Business and Human Rights Resource Centre** (BHRRC, London): Independent database tracking ~10,000 companies and 25,000+ allegations.
- **Worker-Driven Social Responsibility Network** (WSR Network): Coalition of Florida tomato Fair Food Programme, Bangladesh Accord, Lesotho denim agreements.
- **Clean Clothes Campaign** (CCC, Amsterdam-headquartered with European affiliate network): Long-running garment-industry advocacy.

### UK Context

The United Kingdom holds a defining global position in ethical sourcing through its early regulatory leadership (Modern Slavery Act 2015 — the first national statute specifically on supply-chain transparency), world-leading academic research clusters in Manchester, Nottingham, Sheffield Hallam, Cambridge and Imperial, and a corporate ecosystem encompassing FTSE 100 anchor brands (M&S, John Lewis Partnership, Unilever, Tesco, Sainsbury's, Diageo, Reckitt) plus the international consultancies (Big Four, Magic Circle law firms) that have professionalised the discipline globally.

#### Statutory and Policy Framework

- **[[UK Modern Slavery Act 2015]]**, Royal Assent 26 March 2015 (championed by Theresa May as Home Secretary): Section 54 mandatory annual transparency-in-supply-chains statement for commercial organisations with ≥£36M global turnover. ~17,000 entities in scope. Statements published in the central **UK Modern Slavery Statement Registry** (operated by the Home Office, launched March 2021). The Act also established the **Independent Anti-Slavery Commissioner** (current incumbent Eleanor Lyons, appointed November 2023 succeeding Sara Thornton 2019-2022 and Kevin Hyland 2014-2018).
- **UK Procurement Act 2023** (in force 24 February 2025): Mandatory social-value considerations and discretionary exclusion grounds for modern slavery and corruption offences.
- **UK Conflict Minerals Reporting** (GOV.UK guidance, post-Brexit non-equivalence with EU 2017/821 although materially aligned): Voluntary corporate guidance pending mandatory legislation.
- **Environment Act 2021**, Schedule 17: Forest Risk Commodities Regulations 2023/2024 implementing UK due-diligence requirements for soy, palm oil, cocoa, beef, leather and rubber linked to illegal deforestation, modelled on EUDR but Brexit-divergent in specific implementation.
- **UK Bribery Act 2010** intersects ethical sourcing through Section 7 corporate-failure-to-prevent-bribery offence, driving supplier anti-corruption due diligence.

  #### Academic and Research Institutions

- **University of Nottingham — Rights Lab** (founded 2017 by Zoe Trodd, currently Director): World's leading interdisciplinary slavery research centre, hosting ~150 researchers across humanities, social sciences, computer science and law. *Anti-Slavery Knowledge Network*. Major partnerships with the Independent Anti-Slavery Commissioner, the UK Home Office Modern Slavery Unit, and the US State Department TIP Office.
- **Sheffield Hallam University — Helena Kennedy Centre for International Justice**: Pioneering Uyghur forced labour research led by Laura Murphy. The 2020 *Uyghurs for Sale* report (with ASPI) and 2022 *In Broad Daylight: Uyghur Forced Labour and Global Solar Supply Chains* report fundamentally reshaped global understanding of Xinjiang supply-chain risk and drove the US UFLPA.
- **University of Manchester — Centre for Action on Modern Slavery (CASM)** and Global Development Institute (GDI). Stephanie Barrientos's ethical-trade and global-value-chains research; Genevieve LeBaron previously at the Manchester / Sheffield axis (now at Simon Fraser). The Manchester GDI hosts the *Capturing the Gains* and *Stretched Out Workers* programmes.
- **University of Sheffield — SPERI (Sheffield Political Economy Research Institute)**: LeBaron-founded modern-slavery and forced-labour research. *Risky Business* (2018) and *Combatting Modern Slavery* (2020).
- **Cambridge Judge Business School** — Centre for Risk Studies and the Cambridge Centre for Sustainable Leadership (CCSL): Programmes on responsible business, supply-chain risk, and corporate sustainability transformation. Mike Barry (former M&S Plan A architect) as Visiting Senior Fellow.
- **Imperial College Business School — Centre for Climate Finance and Investment / Brevan Howard Centre**: Supply-chain finance and sustainable procurement research. Imperial's Department of Civil and Environmental Engineering hosts the Centre for Environmental Policy with extensive sustainable-procurement modelling.
- **University of Bath — Centre for Business, Organisations and Society (CBOS)**: Andrew Crane's modern-slavery research and the Cambridge Judge-Bath axis on responsible business conduct.
- **University of Sussex — Institute of Development Studies (IDS)**: Long-standing global-value-chains and ethical-trade research.
- **Oxford Saïd Business School — Oxford University Centre for Corporate Reputation** and the Skoll Centre for Social Entrepreneurship.

  #### UK Industrial and Corporate Ecosystem

- **Tata Steel UK** (Port Talbot and Llanwern): UK steel-industry leader in OECD DDG-aligned mineral sourcing and (post-2024) transition to electric arc furnace production with associated scrap-steel traceability.
- **John Lewis Partnership** (employee-owned, John Lewis department stores plus Waitrose supermarkets): Pioneering UK retailer in ethical sourcing dating to founder John Spedan Lewis's 1929 Constitution. *Better Jobs* programme, Waitrose Foundation (operating in South Africa, Kenya, Ghana, supporting farmworker community projects funded by ring-fenced share of Waitrose product revenues).
- **Marks & Spencer Plan A 2025 / Plan A 2030**: Originally launched January 2007 by then-CEO Stuart Rose as a 100-commitment sustainability programme (later expanded to 180); succeeded by Plan A 2025 and now Plan A 2030. Anchor reference in UK corporate sustainability and the source of the "Plan A — because there is no Plan B" tagline.
- **Tesco**, **Sainsbury's**, **Co-op**, **Waitrose**: Major UK grocery retailers with ethical-sourcing programmes covering own-label and tier-1+ supply chains.
- **Unilever** (Anglo-Dutch dual headquarters, London-listed): Unilever Compass Strategy succeeding the 2010-2020 Unilever Sustainable Living Plan. Major investments in deforestation-free palm oil (close to 100% by 2023), sustainable tea (Lipton, PG Tips), and living-wage commitments across direct suppliers by 2030.
- **Diageo**, **Reckitt**, **BAT**: FTSE 100 consumer-goods anchors with full ESG and ethical-sourcing reporting.
- **HSBC Sustainable Finance**, **Standard Chartered**, **NatWest Group**: UK banks providing trade and supply-chain finance increasingly linked to ethical-sourcing performance ("sustainability-linked supply-chain finance").
- **Magic Circle** (Allen & Overy / A&O Shearman, Linklaters, Clifford Chance, Freshfields, Slaughter and May): All operate substantial Business and Human Rights / ESG practices advising on CSDDD implementation, modern-slavery statements, and supply-chain litigation.
- **Big Four** (KPMG, EY, PwC, Deloitte) UK practices: Operate the largest ethical-sourcing audit and advisory teams globally.
- **FTSE 100 ESG reporting**: 100% of FTSE 100 publish sustainability reports; ~95% include modern-slavery statements; ~90% include human-rights policy disclosures (FTSE Russell 2024 data).

  #### UK Multi-Stakeholder Initiatives

- **Ethical Trading Initiative** (ETI, London, founded 1998): Multi-stakeholder alliance of companies, trade unions and NGOs promoting respect for workers' rights globally. The ETI Base Code remains the most widely referenced UK ethical-trade code, drawn directly from ILO Core Conventions.
- **Fairtrade Foundation** (UK, founded 1992): UK arm of Fairtrade International, operating Fairtrade Fortnight, the FAIRTRADE Mark licensing for UK products, and the Fairtrade Schools/Universities programmes.
- **Stronger Together**: UK-headquartered programme tackling labour exploitation in the construction, agriculture and food sectors.
- **Better Buying Institute**: Cornell-affiliated initiative measuring brand purchasing practices.

### Future Directions (2026-2030)

#### Regulatory Maturation

- **2026-2027**: EU CSDDD national transpositions complete (Germany, France, Netherlands first wave; Spain, Italy, Poland second wave). First wave of large-company CSDDD reporting (2027 for ≥5,000 employees and €1.5B global turnover; 2028 for ≥3,000 employees and €900M; 2029 for ≥1,000 employees and €450M).
- **2027-2028**: EU Forced Labour Regulation operational (effective 14 December 2027) with first Commission database investigations and customs interdictions.
- **EU Battery Passport** mandatory from 18 February 2027, driving large-scale digital-product-passport infrastructure deployment.
- **UK**: Likely new mandatory due-diligence statute (the "UK CSDDD") debated through 2026-2027 with cross-party support including the Independent Anti-Slavery Commissioner's recommendations. Strengthening of Modern Slavery Act 2015 Section 54 with enforcement powers and penalties (proposed in successive Modern Slavery Bill drafts).
- **Global Convergence**: ILO Convention 190 (Violence and Harassment, 2019) ratification expanding (~40 countries by 2026). Continued sovereign-level UFLPA-style import prohibitions in Canada (Bill S-211 expansion), Australia (Modern Slavery Act 2018 review recommended additional enforcement powers), Mexico (USMCA-driven reforms).

  #### Technology Roadmap

- **Digital Product Passport (DPP)**: EU-wide deployment under the Ecodesign for Sustainable Products Regulation (ESPR, in force 18 July 2024), starting with batteries (2027), textiles, electronics, furniture. Each product carries a globally unique identifier resolving to provenance, composition, repair and end-of-life information.
- **Decentralised Identifiers (DIDs) and Verifiable Credentials (VCs)**: W3C DID standards underpin worker-controlled credentials, certification claims, and audit attestations. Hyperledger Aries / Indy and the EU's EBSI (European Blockchain Services Infrastructure) increasingly used.
- **AI-augmented supplier scoring**: Large Language Models analysing supplier disclosures, regulatory filings, news, NGO reports, court filings, sanctions lists, port records, satellite imagery — generating composite supply-chain risk scores with explanation.
- **Satellite remote sensing expansion**: Sub-1m daily revisit by 2027 (Planet Pelican constellation) enabling parcel-level deforestation and mining-site verification.
- **IoT sensor networks**: Low-cost LoRaWAN and satellite-IoT (Swarm, Hiber, Astrocast) enabling continuous environmental monitoring at smallholder farm scale.

  #### Convergence with Climate, Nature and Circularity

- **Scope 3 emissions** (supply-chain GHG): Mandatory disclosure under ISSB IFRS S2 and EU CSRD ESRS E1 driving carbon-accounting integration with social-impact tracking.
- **TNFD nature-related disclosures**: Final v1.0 (September 2023) increasingly integrated with ethical-sourcing reporting on biodiversity, land use, water and deforestation.
- **Circular economy and Right to Repair**: EU Right to Repair Directive (2024) and Battery Regulation extended-producer-responsibility provisions linking sourcing with end-of-life accountability.
- **Living wage convergence**: Joint commitments by IDH Living Wage Platform, Fair Wage Network, Anker Methodology, and the Living Income Community of Practice setting common methodologies.

  #### Worker Voice and Remediation

- **Worker-Driven Social Responsibility** (WSR Network) model — Fair Food Programme, Bangladesh Accord, Lesotho denim agreements — expanding from niche to mainstream as evidence accumulates of superior outcomes versus brand-led codes.
- **Anonymous worker feedback platforms** (Ulula, &Wider, Laborlink, Diginex): Mobile-first multilingual interfaces enabling continuous worker voice without identification risk.
- **Operational-level Grievance Mechanisms** (OGMs) increasingly tied to UNGP Principle 31 effectiveness criteria.

  #### Geopolitical and Trade Tensions

- **Critical minerals nationalism**: US Inflation Reduction Act IRA Section 30D EV tax-credit "foreign entity of concern" rules; EU Critical Raw Materials Act 2024; Australia, Canada and UK Critical Minerals Strategies — all driving relocation/diversification of mining and processing away from Chinese vertical integration.
- **Xinjiang and Russia sanctions**: UFLPA Entity List expansion; EU Forced Labour Regulation listings; UK sanctions regime — collectively reshaping cotton, polysilicon, aluminium and other supply chains.
- **Africa as alternative supply base**: ECOWAS Mineral Development Centre, Lobito Corridor (US-EU-Angola-DRC-Zambia), and Tanzania-DRC battery-mineral cooperation driving alternative cobalt/copper/lithium sourcing under enhanced due-diligence frameworks.

  #### Convergence with Tax, Trade and Sanctions

- **Beneficial-ownership transparency**: EU Anti-Money Laundering Directive 6 and the UK Economic Crime (Transparency and Enforcement) Act 2022 increasingly intersect with supply-chain due diligence on shell-company concealment of forced-labour and conflict-mineral risks.
- **Carbon Border Adjustment Mechanism** (CBAM, EU, transitional reporting from October 2023, full implementation January 2026): Importers of cement, iron and steel, aluminium, fertilisers, electricity and hydrogen must report embedded emissions and surrender certificates from 2026 — operational linkage with ethical-sourcing due-diligence data systems.
- **Sanctions screening integration**: OFAC SDN, OFSI UK consolidated list, EU restrictive measures, increasingly automated against supplier registers via Sayari, Kharon, Refinitiv World-Check, Dow Jones Risk & Compliance.
- **Critical Minerals Strategy alignment**: UK Critical Minerals Strategy (2022, refresh 2023) and the cross-government Critical Minerals Intelligence Centre (British Geological Survey) supporting ethical-sourcing diversification away from Chinese-vertically-integrated supply.

  #### The Audit-Industry Reckoning
  Academic critique (LeBaron, Lister, Locke) and high-profile failures (Bangladesh BGI fire 2012, Pakistan Ali Enterprises fire 2012, repeated Karnataka spinning-mill exposes) have generated sustained pressure for audit-industry reform. Expected trajectory through 2030 includes (i) mandatory disclosure of audit firms and reports under CSDDD; (ii) standardised audit-quality metrics; (iii) digitised continuous monitoring partially displacing periodic on-site audits; (iv) worker-driven verification gaining institutional acceptance; (v) audit-firm liability exposure increasing.

### Research and Literature

**Foundational Frameworks**:
1. Ruggie, J.G. (2011). *Guiding Principles on Business and Human Rights: Implementing the United Nations "Protect, Respect and Remedy" Framework*. UN Human Rights Council, A/HRC/17/31. [The foundational UNGP text]
2. Ruggie, J.G. (2013). *Just Business: Multinational Corporations and Human Rights*. W.W. Norton. ISBN 978-0393345292. [Canonical academic account of the UNGP development]
3. OECD (2023). *OECD Guidelines for Multinational Enterprises on Responsible Business Conduct*. OECD Publishing. DOI:10.1787/81f92357-en. [2023 major update of the 1976 Guidelines]
4. OECD (2023). *OECD Due Diligence Guidance for Responsible Mineral Supply Chains from Conflict-Affected and High-Risk Areas* (4th edition). OECD Publishing. [Reference framework for 3TG and cobalt due diligence]
5. OECD (2018). *OECD Due Diligence Guidance for Responsible Business Conduct*. OECD Publishing. [Cross-sectoral 6-step due-diligence framework]

**Regulatory Texts**:
6. European Parliament and Council (2024). Directive (EU) 2024/1760 on Corporate Sustainability Due Diligence (CSDDD). OJ L 1760, 5 July 2024.
7. European Parliament and Council (2024). Regulation (EU) 2024/3015 on Prohibiting Products Made with Forced Labour on the Union Market. OJ L December 2024.
8. European Parliament and Council (2017). Regulation (EU) 2017/821 laying down supply chain due diligence obligations for Union importers of tin, tantalum and tungsten, their ores, and gold originating from conflict-affected and high-risk areas. OJ L 130, 19.5.2017.
9. UK Parliament (2015). Modern Slavery Act 2015, c. 30. [Section 54 transparency in supply chains]
10. Bundestag (2021). Lieferkettensorgfaltspflichtengesetz (Supply Chain Due Diligence Act, LkSG). BGBl. I S. 2959.

**Academic Literature**:
11. LeBaron, G. (2020). *Combatting Modern Slavery: Why Labour Governance is Failing and What We Can Do About It*. Polity Press. ISBN 978-1509513680.
12. LeBaron, G., & Lister, J. (2015). Benchmarking global supply chains: the power of the "ethical audit" regime. *Review of International Studies*, 41(5), 905-924.
13. Locke, R.M., Qin, F., & Brause, A. (2007). Does monitoring improve labor standards? Lessons from Nike. *Industrial and Labor Relations Review*, 61(1), 3-31.
14. Crane, A., LeBaron, G., Allain, J., & Behbahani, L. (2019). Governance gaps in eradicating forced labor: from global to domestic supply chains. *Regulation & Governance*, 13(1), 86-106.
15. Barrientos, S. (2019). *Gender and Work in Global Value Chains: Capturing the Gains?* Cambridge University Press. ISBN 978-1107160064.
16. Gereffi, G. (2018). *Global Value Chains and Development: Redefining the Contours of 21st Century Capitalism*. Cambridge University Press. ISBN 978-1108458863.
17. Murphy, L.T., & Elimä, N. (2022). *In Broad Daylight: Uyghur Forced Labour and Global Solar Supply Chains*. Sheffield Hallam University Helena Kennedy Centre for International Justice.
18. Xu, V.X., et al. (2020). *Uyghurs for Sale: 'Re-education', Forced Labour and Surveillance beyond Xinjiang*. ASPI International Cyber Policy Centre, Policy Brief Report No. 26/2020.

**Industry, Standards and NGO Reports**:
19. ILO and Walk Free Foundation (2022). *Global Estimates of Modern Slavery: Forced Labour and Forced Marriage*. International Labour Organization, Geneva. [27.6M in forced labour estimate]
20. ILO and UNICEF (2021). *Child Labour: Global Estimates 2020, Trends and the Road Forward*. ILO, Geneva. [160M children in child labour]
21. NORC at the University of Chicago (2020). *Assessing Progress in Reducing Child Labor in Cocoa Production in Cocoa Growing Areas of Côte d'Ivoire and Ghana*. Final Report. [~1.56M children in West African cocoa]
22. Amnesty International (2016). *"This Is What We Die For": Human Rights Abuses in the Democratic Republic of the Congo Power the Global Trade in Cobalt*. AFR 62/3183/2016.
23. Apple Inc. (2024). *Apple Supplier Responsibility — 2024 Annual Progress Report* (18th edition).
24. Cambridge Centre for Alternative Finance (2024). *Global Cryptoasset and Sustainable Finance Benchmarking Study*. University of Cambridge Judge Business School.

**UK and European Reports**:
25. Independent Anti-Slavery Commissioner (2024). *Annual Report 2023-2024*. UK Government.
26. UK Home Office (2024). *Modern Slavery: Statutory Guidance for England and Wales* (updated). Section 49 of the Modern Slavery Act 2015.
27. European Commission (2020). *Study on Due Diligence Requirements through the Supply Chain*. DG Justice, Final Report, January 2020. [Foundational study underpinning CSDDD]
28. ETI (Ethical Trading Initiative) (2024). *Annual Impact Report*. London.
29. Business and Human Rights Resource Centre (2024). *Modern Slavery Statements Review*. London.

**Theoretical and Operational Texts**:
30. Hofmann, H., Schleper, M.C., & Blome, C. (2018). Conflict minerals and supply chain due diligence: an exploratory study of multi-tier supply chains. *Journal of Business Ethics*, 147(1), 115-141.

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review during Phase 6 enrichment sprint
- **Verification**: Standards and regulatory references verified against OECD Publishing, EU Official Journal (CSDDD Directive 2024/1760, Forced Labour Regulation 2024/3015, Conflict Minerals Regulation 2017/821, EUDR 2023/1115, Battery Regulation 2023/1542), UK legislation.gov.uk (Modern Slavery Act 2015, Procurement Act 2023), Bundestag (LkSG), ILO (global estimates 2022), Amnesty International cobalt reports 2016/2023, Apple Supplier Responsibility Reports, Cambridge CCAF, Sheffield Hallam Helena Kennedy Centre publications, Nottingham Rights Lab publications
- **Regional Context**: UK statutory framework (Modern Slavery Act 2015 Section 54, Procurement Act 2023, Environment Act 2021 Schedule 17, Bribery Act 2010 Section 7); UK academic clusters (Nottingham Rights Lab, Sheffield Hallam Helena Kennedy Centre, Manchester GDI/CASM, Sheffield SPERI, Cambridge Judge CCSL, Imperial Centre for Climate Finance, Bath CBOS, Sussex IDS, Oxford Saïd Skoll); UK corporate ecosystem (M&S Plan A 2025/2030, John Lewis Partnership / Waitrose Foundation, Tata Steel UK, Unilever Compass, Tesco/Sainsbury's/Co-op, HSBC/Standard Chartered/NatWest sustainable finance, Magic Circle law firms, Big Four UK practices); UK multi-stakeholder initiatives (Ethical Trading Initiative ETI, Fairtrade Foundation, Stronger Together)
- **Conceptual Note**: Ethical sourcing positioned in BlockchainDomain reflecting the IRI namespace (narrativegoldmine.com/blockchain#EthicalSourcing) and the legacy BC-0453 identifier, whilst recognising that the discipline is fundamentally a supply-chain / procurement / ESG concept for which blockchain provenance is one (increasingly important) verification technology among several (alongside satellite remote sensing, AI risk scoring, NLP ESG analysis). The bridges-to property explicitly surfaces the cross-domain nature
- **Production-Ready**: Complete OWL formal semantics (44 axioms across compositional/dependency/capability/implementation/reduction/association), comprehensive content coverage (conceptual distinctions among fair trade/sustainable/responsible sourcing, regulatory stack across US/EU/national European/other jurisdictions, international standards and certification schemes, blockchain provenance + AI risk scoring + satellite monitoring technology stack, commodity-specific use-case families, academic theory and empirical literature, current landscape 2026, UK context with statutory + academic + corporate detail, future directions 2026-2030), 30 academic/regulatory/NGO citations
- **Authority Score**: 0.87 (defining cross-sectoral procurement discipline addressing $150B+ annual hidden costs of unethical supply chains, ~17,000 UK MSA 2015 Section 54 reporters, ~50,000 EU CSRD reporters, EU CSDDD imposing civil liability across full chain of activities for €450M+ EU-turnover entities, foundation of multi-billion ESG-data and assurance industry)

### Provenance

- **conceptual-note:** Concept retained in BlockchainDomain per IRI namespace and BC-0453 legacy identifier; ontologically a cross-domain procurement / ESG / human-rights-due-diligence concept for which blockchain provenance is one verification technology

