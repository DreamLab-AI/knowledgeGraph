AI Video, alternatively termed generative video, neural video synthesis, text-to-video (T2V), and image-to-video (I2V), denotes the class of deep generative models and engineering systems that synthesise temporally-coherent moving imagery conditioned on natural-language prompts, reference images,...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:hasPart ai:DiffusionTransformer))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:hasPart ai:SpatiotemporalAutoencoder))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:hasPart ai:VideoTokeniser))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:hasPart ai:TextEncoder))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:hasPart ai:TemporalAttentionModule))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:hasPart ai:ClassifierFreeGuidance))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:hasPart ai:SamplingScheduler))

    ## Dependency Relationships
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:requires ai:VideoTextTrainingCorpus))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:requires ai:GPUCompute))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:requires ai:LatentDiffusion))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:requires ai:Backpropagation))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:requires ai:LargeScalePretraining))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:dependsOn ai:DiffusionModel))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:dependsOn ai:Transformer))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:dependsOn ai:VariationalAutoencoder))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:dependsOn ai:CLIP))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:dependsOn ai:OpticalFlow))

    ## Capability Relationships
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:enables ai:TextToVideoGeneration))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:enables ai:ImageToVideoGeneration))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:enables ai:VideoToVideoTranslation))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:enables ai:PerformanceCapture))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:enables ai:SyntheticPrevisualisation))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:enables ai:AIAvatarSynthesis))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:enables ai:Deepfake))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:supports ai:FilmPrevisualisation))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:supports ai:Advertising))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:supports ai:CorporateTrainingVideo))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:supports ai:SocialMediaShortForm))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:supports ai:VideoDubbing))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:supports ai:SyntheticDataGeneration))

    ## Implementation Relationships
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:implements ai:LatentVideoDiffusion))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:implements ai:SpacetimePatchTokenisation))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:implements ai:RectifiedFlowTraining))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:implements ai:ScoreBasedGenerativeModelling))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:uses ai:SelfAttention))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:uses ai:CrossAttention))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:uses ai:AdamOptimiser))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:uses ai:ThreeDimensionalCausalVAE))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:uses ai:LoRAAdapter))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:uses ai:ControlNet))

    ## Reduction Relationships
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:reduces ai:VideoProductionCost))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:reduces ai:PrevisualisationTime))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:reduces ai:ManualAnimationLabour))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:reduces ai:LocalisationCost))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:reduces ai:PhysicalShootDependency))

    ## Association Relationships
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:relatedTo ai:GenerativeAI))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:relatedTo ai:DiffusionModel))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:relatedTo ai:StableDiffusion))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:relatedTo ai:WorldModel))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:contrastsWith ai:TraditionalVFXPipeline))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:contrastsWith ai:ClassicalAnimation))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:contrastsWith ai:MotionCapture))
    SubClassOf(ai:AIVideo
      ObjectSomeValuesFrom(ai:contrastsWith ai:ProceduralAnimation))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ai:hasIdentifier ai:AIVideo "AI-1078"^^xsd:string)
    DataPropertyAssertion(ai:authorityScore ai:AIVideo "0.87"^^xsd:decimal)
    DataPropertyAssertion(ai:foundationalYear ai:AIVideo "2022"^^xsd:integer)
    DataPropertyAssertion(ai:soraDemoDate ai:AIVideo "2024-02-15"^^xsd:date)
    DataPropertyAssertion(ai:soraPublicDate ai:AIVideo "2024-12-09"^^xsd:date)
    DataPropertyAssertion(ai:marketSizeUSD2025 ai:AIVideo "1500000000"^^xsd:integer)
    DataPropertyAssertion(ai:marketSizeUSD2030 ai:AIVideo "15500000000"^^xsd:integer)
    DataPropertyAssertion(ai:maxClipDurationKling21 ai:AIVideo "120"^^xsd:integer)
    DataPropertyAssertion(ai:perSecondPricingUSD ai:AIVideo "0.20"^^xsd:decimal)
    DataPropertyAssertion(ai:deepfakeFraudLossUSD2025 ai:AIVideo "3300000000"^^xsd:integer)

    ## Property Constraints
    SubClassOf(ai:AIVideo
      DataMinCardinality(1 ai:hasDiffusionBackbone xsd:string))
    SubClassOf(ai:AIVideo
      DataMinCardinality(1 ai:hasTextEncoder xsd:string))
    SubClassOf(ai:AIVideo
      DataAllValuesFrom(ai:isTemporallyCoherent xsd:boolean))
    SubClassOf(ai:AIVideo
      DataSomeValuesFrom(ai:framesPerSecond xsd:integer))

    ## Annotations
    AnnotationAssertion(rdfs:label ai:AIVideo "AI Video"@en)
    AnnotationAssertion(rdfs:comment ai:AIVideo "Class of deep generative models synthesising temporally-coherent moving imagery conditioned on text/image/video/audio inputs, originating in Video Diffusion Models (Ho et al. 2022) and transformed by OpenAI's Sora technical report Feb 2024 introducing spacetime-patch DiT formulation, now comprising commercial systems (Sora/Sora 2, Runway Gen-3/Gen-4, Pika 2.2, Luma Ray2, Kling 2.1, Hailuo, Veo 3) and open-weights ecosystem (HunyuanVideo, Wan 2.1, CogVideoX, Open-Sora, Mochi, LTX-Video), built on diffusion transformers, spatiotemporal autoencoders, video tokenisers (MAGVIT-v2), classifier-free guidance and rectified flow, deployed across $1.5B 2025 advertising/film/social media market projected $15.5B 2030, regulated under EU AI Act Article 50, UK Online Safety Act, SAG-AFTRA digital-replica provisions, and BBC Generative AI Principles."@en)
    AnnotationAssertion(dcterms:identifier ai:AIVideo "AI-1078"^^xsd:string)
    AnnotationAssertion(dcterms:subject ai:AIVideo "Generative Video, Diffusion Transformer, Text-to-Video, Image-to-Video, Synthetic Media, Foundation Models"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(ai:requires)
  AsymmetricObjectProperty(ai:enables)
  AsymmetricObjectProperty(ai:implements)
  AsymmetricObjectProperty(ai:contrastsWith)
  TransitiveObjectProperty(ai:dependsOn)
  FunctionalDataProperty(ai:foundationalYear)
  FunctionalDataProperty(ai:soraDemoDate)

## About AI Video

- **AI Video** is the class of deep generative systems that synthesise temporally-coherent moving imagery from textual, visual or multimodal prompts. The field crystallised in 2022 with three near-simultaneous papers—Ho et al.'s *Video Diffusion Models*, Meta's *Make-A-Video*, and Google's *Imagen Video* and *Phenaki*—and reached commercial inflection in February 2024 when OpenAI's Sora technical report demonstrated 60-second 1080p clips with multi-shot continuity, recasting video as a sequence of *spacetime patches* processed by a Diffusion Transformer.
- In the 18 months following Sora's demo, the commercial frontier converged on a dozen products competing on clip duration, resolution, motion fidelity, character consistency, audio integration, and creative tooling. By mid-2025, **Kuaishou's Kling 2.0 reached 120-second clips at 1080p**, **Google's Veo 3 delivered 4K with synchronised native audio**, **Runway's Gen-4 introduced multi-shot character consistency**, and **OpenAI's Sora 2 introduced the controversial cameo feature** allowing consented personal-likeness use. Underneath the consumer-facing race, an open-weights movement emerged: **Tencent's HunyuanVideo 13B**, **Alibaba's Wan 2.1** family, **Tsinghua/Zhipu's CogVideoX**, **HPC-AI Tech's Open-Sora**, **Genmo's Mochi 1**, and **Lightricks' LTX-Video** offering inspectable architectures, reproducible training, and consumer-GPU deployment paths.
- The economic stakes are large. The generative-video market is estimated at **$1.3-1.6B 2025 growing to $14-17B by 2030** (CAGR 41-44%), with downstream impacts on advertising production (Coca-Cola's Christmas 2024 *Holidays Are Coming* remake), film pre-visualisation (Lionsgate-Runway's reported $300M training deal September 2024), corporate communications (London-based Synthesia's $1B+ AI-avatar business), and short-form social-media content. The same technology simultaneously enables a £2.6B 2025 global synthetic-media fraud economy (Sumsub), driving regulatory response: the EU AI Act Article 50, the UK Online Safety Act 2023, SAG-AFTRA's digital-replica consent provisions, the BBC R&D Generative AI Principles, and the C2PA content-provenance standard.

### Architectural Foundations

Modern AI video systems share a four-stage pipeline: **(1)** a spatiotemporal autoencoder compressing video to a low-dimensional latent representation, **(2)** a diffusion transformer learning the denoising dynamics in latent space, **(3)** a text encoder (typically T5-XXL or CLIP) and optional image/audio conditioning, and **(4)** a classifier-free guidance sampler producing the final clip.

#### Diffusion Transformers (DiT, MMDiT)

Peebles and Xie's **DiT** (ICCV 2023) replaced the convolutional U-Net of earlier diffusion models with a pure transformer operating on patch tokens, demonstrating clean compute-quality scaling laws and superior performance at scale. **MMDiT** (Esser, Rombach et al. 2024 *Scaling Rectified Flow Transformers*) generalises DiT to multimodal token streams with separate weights for image and text tokens but joint attention, powering Stable Diffusion 3 and FLUX.1. Video DiTs extend this to spatiotemporal token grids: Sora's spacetime patches treat a video as a flattened sequence of cubelet tokens; CogVideoX uses a 3D causal VAE feeding a full-attention DiT; HunyuanVideo employs full bidirectional attention across all spacetime tokens; Veo 3 uses an MMDiT-derived backbone with audio tokens interleaved.

#### Spatiotemporal Autoencoders

Pixel-space video diffusion is computationally prohibitive (a 5-second 1080p 24fps clip is 6.2 × 10⁸ pixels). Spatiotemporal VAEs compress video by typically 4-8× spatial and 4-8× temporal factors. Sora reports a 4× spatial / 4× temporal latent compression (64× total). CogVideoX uses an 8× spatial / 4× temporal compression via a 3D causal VAE preserving real-time generation properties. **MAGVIT-v2** (Yu et al. ICLR 2024) introduced **lookup-free quantisation**, replacing VQ-VAE codebooks with finite scalar quantisation, achieving 64× compression at PSNR > 32 dB and showing—per the paper's title *Language Model Beats Diffusion*—that with strong tokenisation, autoregressive language-model-style approaches can match or exceed diffusion on video quality.

#### Video Tokenisers

Discrete video tokenisation enables transformer architectures originally designed for language: **C-ViViT** (Phenaki 2022) was an early space-time ViT tokeniser; **MAGVIT** (Yu et al. CVPR 2023) and **MAGVIT-v2** (Yu et al. ICLR 2024) are the dominant modern tokenisers, the latter underpinning Google's most recent visual generation research. Continuous latent representations remain dominant in diffusion-based systems (Sora, Runway, Pika, Luma, Kling, HunyuanVideo).

#### Classifier-Free Guidance

Ho and Salimans' **classifier-free guidance** (2022) is the dominant conditioning method: a single model is trained jointly to predict noise given the prompt and unconditionally (with prompt dropout, typically 10%), and inference combines the two predictions with a guidance weight w (typically 7-15 for video). Higher w produces stronger prompt adherence at the cost of sample diversity and motion variety. Most commercial video systems expose a guidance scale or "prompt strength" parameter exposing this trade-off.

#### Rectified Flow and Score-Based Training

**Rectified Flow** (Liu et al. 2022, Esser/Rombach et al. 2024) trains networks to predict straight-line trajectories between noise and data in latent space rather than the curved trajectories of standard diffusion. Empirically yields faster sampling (4-50 steps vs 50-1000) at competitive quality, and is increasingly adopted in video models. Score-based modelling via stochastic differential equations (Song et al. ICLR 2021, co-authored by Pika's CTO Chenlin Meng) underpins the theoretical framework relating diffusion, score matching, and continuous-time generative modelling.

#### Training Data and Captioning

Foundation video models train on internet-scale video-text corpora. Disclosed training datasets include **WebVid-10M** (Bain et al. ICCV 2021, 10M video-text pairs, used extensively in early models including AnimateDiff and Stable Video Diffusion until copyright concerns), **HD-VILA-100M** (Microsoft, 100M clips), **Panda-70M** (Snap Inc., 70M clips with automatic captions), **LAION-5B** stills augmented with video-style captions, and proprietary licensed corpora. Sora's training data is undisclosed but acknowledged to include "publicly available video and licensed content"—a phrasing widely interpreted as including YouTube video at scale, prompting copyright and consent controversy. Runway's Lionsgate deal explicitly licensed 20,000+ feature films. Caption quality is the dominant scaling bottleneck: DALL-E 3 and Sora both employ AI re-captioning pipelines generating dense descriptive captions (often 100+ tokens per clip) replacing the noisy short captions of raw web data. Frontier video models (Sora, Veo 3, Kling 2.1) reportedly train at the >100M-clip / >10M-hour scale.

#### Inference Pipelines and Distillation

Production video diffusion inference combines several optimisations: classifier-free guidance with annealed weights, second-order ODE/SDE solvers (DPM-Solver++, Heun), latent-space caching across denoising steps, attention KV-caching, and progressive distillation (Salimans & Ho 2022) compressing 50-step student models from 1000-step teachers. Adversarial distillation (Sauer et al. 2024) further compresses to 4-step or single-step generation, basis for Runway Gen-3 Alpha Turbo. Modern frontier video systems deliver 5-10 seconds of 1080p output in 30-60 seconds of wall-clock time on H100 clusters, down from minutes-per-clip at the Sora demo.

### Major Models and Families (Commercial)

#### OpenAI Sora and Sora 2

- **Sora (demo Feb 2024)**: Brooks et al. *Video generation models as world simulators* — 60-second 1080p single-shot clips with multi-shot continuity. Architecture: spacetime patch DiT with separately learnt spatial and temporal positional encodings. Training compute estimated at 10K-30K H100-equivalent weeks (Epoch AI).
- **Sora Turbo (Dec 2024)**: Public release in ChatGPT Plus ($20/month, 20s @ 1080p) and ChatGPT Pro ($200/month, 60s @ 1080p, 5 simultaneous generations). Distilled version with reduced quality versus the February demo, watermarked output (visible + C2PA-compliant metadata).
- **Sora 2 (Sep 2025)**: Synchronised native audio (speech, foley, music), improved physics, the controversial **cameo feature** allowing users to deploy their consented personal likeness in clips. Triggered class-action and individual lawsuits over likeness-misuse incidents.
- **Deprecation (Apr 2026)**: OpenAI withdrew Sora general consumer access amid litigation; enterprise API remains.

  #### Runway Gen-1 → Gen-4

- **Gen-1 (Feb 2023)**: Video-to-video style transfer.
- **Gen-2 (Jun 2023)**: First mass-market text-to-video, 4-second clips at 768×448.
- **Gen-3 Alpha (Jun 2024)**: 10s clips at 1280×768, vastly improved motion fidelity and camera control. Introduced commercial text-to-video as a credible production tool.
- **Gen-3 Alpha Turbo (Jul 2024)**: 7× faster inference, $0.05/sec.
- **Gen-4 (Mar 2025)**: Multi-shot character consistency, 10s @ 1080p, deep integration into the Runway professional video editor.
- **Act-One (Oct 2024)**: Performance capture driving character animation from a webcam, blurring the line between AI video and traditional motion-capture pipelines.
- **Lionsgate partnership (Sep 2024)**: Reported $300M training-data licensing deal granting Runway access to ~20,000 Lionsgate film titles in exchange for AI pre-vis tools; *Madame Web* and *John Wick* franchises piloted.

  #### Pika 1.0 → 2.2

  Pika Labs (Palo Alto, founded April 2023 by Stanford CS PhDs Demi Guo and Chenlin Meng, $135M raised across seed/Series A Lightspeed/Series B Spark Capital) positioned itself for prosumer/Gen-Z creators. Sibling concept page [[Pika]] holds full detail.

- **Pika 1.0 (Dec 2023)**: 3s @ 720p, Discord-first.
- **Pika 1.5 (Oct 2024)**: *Pikaffects* physics-based effects (melt, explode, inflate, crush, squish), 1080p, 5s.
- **Pika 2.0 (Dec 2024)**: *Scene Ingredients* composing user-uploaded character/object/scene references.
- **Pika 2.2 (Feb 2025)**: *Pikaframes* keyframe interpolation, *Pikaswaps* object/wardrobe replacement, *Pikadditions* insert objects into existing video; 10s @ 1080p.

  #### Luma Labs Dream Machine and Ray2

  Luma Labs (San Francisco, founder Amit Jain ex-Apple AR, $43M Series B Andreessen Horowitz Jan 2024) pivoted from NeRF capture to generative video.

- **Dream Machine (Jun 2024)**: Free-tier browser text-to-video, 5s @ 720p, 30 free monthly generations, no waitlist—broke open consumer AI video access.
- **Ray2 (Jan 2025)**: 10s @ 1080p, dramatically improved physics and motion realism, audio generation added Q2 2025.

  #### Kuaishou Kling

  Beijing-based Kuaishou (TikTok competitor in China) released the first frontier non-OpenAI long-clip system.

- **Kling 1.0 (Jun 2024)**: 10s @ 1080p text-to-video, the first to demonstrate eating-pasta scenes without the *will-smith-spaghetti* identity collapse that had become a meme for early text-to-video failure.
- **Kling 1.5 (Sep 2024)**: Improved motion, 30s *master mode*.
- **Kling 1.6 (Dec 2024)**: Image-to-video refinements.
- **Kling 2.0 (Apr 2025)**: 120-second clips at 1080p, professional tier.
- **Kling 2.1 (Aug 2025)**: Multi-shot consistency, 4K upscaling, audio integration.

  #### MiniMax Hailuo

  MiniMax (Shanghai) released **Hailuo video-01** August 2024 with 6-second 1280×720 text-to-video and image-to-video, and **i2v-live** Q1 2025 with real-time interactive image-to-video.

  #### Google DeepMind Veo

- **Veo (May 2024)**: Announced at Google I/O 2024, 1080p, integrated YouTube Shorts.
- **Veo 2 (Dec 2024)**: 4K capability, improved physics, embedded SynthID watermarking.
- **Veo 3 (May 2025)**: Synchronised native audio (speech, sound effects, music), 60s, 4K, deep Gemini integration. First frontier system to crack joint video-audio generation cleanly.
- **Veo 3.1 (Q4 2025)**: Improved character consistency, longer clips.

  #### ByteDance Dreamina / Seaweed

  ByteDance released a multimodal video generator integrated into Dreamina (TikTok parent's creative platform) in late 2024; integrated into TikTok creator tooling.

  #### Adobe Firefly Video Beta

  Adobe (Oct 2024) released Firefly Video with commercially-safe training data (Adobe Stock licensed corpus), Premiere Pro integration, and indemnification—positioning for enterprise creative workflows wary of training-data litigation.

### Open-Source Landscape

The open-weights movement closed the gap with closed-source frontier through 2024-2025:

#### Tencent HunyuanVideo

Kong et al. (Dec 2024) released **HunyuanVideo**, a 13B-parameter open-weights diffusion transformer using full bidirectional attention. VBench scores competitive with Runway Gen-3 Alpha. Apache-2.0-style permissive licence.

#### Alibaba Wan 2.1

Alibaba (Feb 2025) released the **Wan 2.1** family with 14B (server) and 1.3B (consumer GPU) variants supporting both I2V and T2V. Open weights.

#### Tsinghua/Zhipu CogVideoX

Yang et al. (Aug 2024) released **CogVideoX** 5B and 2B variants under Apache-2.0; 6-second 720p; expert-transformer-style DiT with 3D causal VAE.

#### HPC-AI Tech Open-Sora

HPC-AI Tech (Mar 2024) launched **Open-Sora**, an Apache-2.0 reproduction targeting Sora's architecture; v1.2 with 1080p support in August 2024.

#### Stability AI Stable Video Diffusion

Blattmann et al. (Nov 2023) released **Stable Video Diffusion** 14/25-frame image-to-video models under a research-and-commercial-permissive licence, providing the foundational open base for early 2024 community work.

#### Genmo Mochi 1

Genmo (Oct 2024) released **Mochi 1**, a 10B-parameter Apache-2.0 *AsymmDiT* model, notable for fully permissive licensing.

#### Lightricks LTX-Video

Lightricks (Nov 2024) released **LTX-Video**, a 2B-parameter model achieving real-time 768×512 generation on consumer GPUs, Apache-2.0 licensed. First model to make local consumer-GPU video generation practical.

#### AnimateDiff and the Personalisation Ecosystem

Guo et al. (ICLR 2024) released **AnimateDiff**, a plug-in temporal-attention module compatible with any personalised Stable Diffusion 1.5 / SDXL checkpoint. AnimateDiff became the de facto standard for the **ComfyUI** community, enabling Stable Diffusion's vast personalisation ecosystem (Civitai LoRAs, custom characters, artistic styles) to extend into video without retraining the underlying generator.

### Limitations and Failure Modes (2025-2026)

Despite frontier progress, AI video systems exhibit several persistent failure modes that constrain production deployment:

#### Temporal Coherence and Multi-Shot Consistency

Character identity drift across cuts and scene changes remains weak below frontier (Runway Gen-4, Kling 2.1, Sora 2). Even at frontier, subtle clothing/hair/feature drift occurs across 30+ seconds. ID-preservation conditioning (reference-image guidance, IP-Adapter, embedding-based identity locks) partially addresses this for single-character scenes but compounds rapidly with multiple characters.

#### Physics Fidelity

OpenAI's Sora technical report explicitly acknowledged physics failures: *glass shatters before impact*, *liquids flow in inconsistent directions*, *objects pass through each other*, *cause-effect inversions*. These reflect that diffusion models learn surface visual statistics rather than physical principles. Physics-informed video diffusion research (PhysGen, physical-constraint-aware sampling) is active but not yet deployed in commercial systems.

#### Long-Form Generation

Single-pass coherent clips above 60 seconds remain challenging. Kling 2.0's 120-second commercial frontier exhibits quality degradation in the latter half. Hierarchical and autoregressive chaining accumulate drift; the field lacks a clean solution to multi-minute coherent generation.

#### Text Rendering

Embedded text in scenes (signs, books, packaging, screens) frequently garbled below frontier. Sora 2 and Veo 3 improving via dedicated text-rendering heads (analogous to DALL-E 3's character-level conditioning) but reliability not yet at production quality for branded content with text.

#### Hand/Finger and Fine Anatomy

Persistent hand/finger anatomy failures in human depictions, particularly during manipulation tasks (writing, eating, gesturing). Reduced but not eliminated in 2025-2026 frontier. Ear, tooth, and earring artefacts also common.

#### Audio-Video Synchronisation

Until Veo 3 (May 2025) and Sora 2 (Sep 2025), generative video models were silent. Lip-sync, foley, and music remain harder than visual generation; cross-modal synchronisation an active research frontier.

#### Compositional Reasoning

Models struggle with complex prompts containing multiple agents, relative spatial configurations ("the cat is on top of the box to the left of the lamp"), and counterfactual scenarios (T2V-CompBench benchmarks 2024 show frontier scores below 60% on compositional axes).

#### Computational Cost and Latency

Per-clip inference: 30 seconds to 5 minutes on H100-class infrastructure for 5-10 second clips. Training: Sora estimated 10K-30K H100s for weeks (Epoch AI). Pricing $0.05-$0.50 per second of output. Energy and carbon footprint of training and inference under scrutiny under EU CSRD and UK SECR sustainability disclosure regimes.

### Use Cases and Major Application Families

#### Advertising and Brand Marketing (≈ $620M segment 2025)

AI video became commercially mainstream in advertising during 2024, with brand spend on AI-augmented creative reaching approximately $620M globally by year-end (WARC AI Advertising Index 2025).

- **Coca-Cola Christmas 2024**: AI-generated remake of the iconic *Holidays Are Coming* campaign by Secret Level, Silverside AI and Wild Card using the Real Magic AI suite (Leonardo, Luma, Runway). The campaign drew strong professional-creative backlash for job displacement and quality regressions versus the 1995 original (where polar bears, snowflakes, and the red truck were achieved through bespoke practical effects and traditional VFX), but normalised brand AI cinema and triggered industry-wide policy formulation at major holdco agencies (WPP, Publicis, Omnicom, IPG).
- **Toys R Us (2024)**: First major brand film fully produced in OpenAI Sora, premiered at Cannes Lions June 2024. Quality criticism but established the "fully AI" production-pipeline category.
- **Mango (2024)**: AI-generated fashion campaign for the *Sunset Dream* collection, Spanish fashion retailer first major fashion brand AI rollout. Significantly cheaper than traditional photoshoots (estimated 70-90% cost reduction).
- **Nike Olympics (2024)**: AI-enhanced *Winning Isn't For Everyone* campaign elements blending AI-generated athletes with live action.
- **WPP Production Studio "Pencil" (2024)**: WPP's in-house generative AI creative platform integrated Runway, Pika, and proprietary models. Coca-Cola, Nestlé, Ford, P&G client deployments.
- **Publicis Le Truc (2024)**: Publicis Groupe AI creative studio, leveraging Adobe Firefly Video for enterprise indemnification.
- **Various Fortune 500 social campaigns**: Pika, Runway and Luma adoption across Q4 2024 and 2025 creative agency pitches; estimated 30-40% of pitch reels for global brands by Q2 2025 include AI video components.

  #### Film Pre-visualisation and Post-Production (≈ $380M segment 2025)

  Film and television studios have adopted AI video most aggressively in pre-visualisation, storyboarding, look-development, and second-unit/background work, where the cost-quality trade-off favours rapid iteration over photorealism. Full final-pixel use in theatrical content remains experimental as of 2026.

- **Lionsgate-Runway (Sep 2024)**: Reported $300M training-data licensing deal; first major Hollywood studio AI training partnership. Lionsgate provides Runway access to its 20,000+ title library (the John Wick franchise, Hunger Games, La La Land, Saw, Twilight) in exchange for Runway pre-vis and storyboarding tools deployed across Lionsgate productions. The deal effectively monetises a film studio's back-catalogue as training data, a model expected to be replicated by Sony, Disney, and Universal.
- **A24, Plan B Entertainment**: Indie-side pilots for storyboarding and pre-vis; A24 reportedly using Runway and Pika for early-development pitch reels on multiple greenlit projects.
- **BBC R&D internal experiments**: Synthetic media tooling within strict editorial guardrails per BBC Generative AI Principles 2024. BBC R&D has prototyped AI-assisted background generation for low-budget drama, AI dubbing for international distribution, and synthetic archive material recovery (colourisation, super-resolution).
- **VFX house adoption**: Mid-tier houses (Framestore London, DNEG London/Vancouver, MPC, Industrial Light & Magic) piloting AI for matte-painting, set extension, crowd generation, and rotoscoping replacement. Wētā FX (New Zealand) experimenting with AI-assisted character animation for previs only.
- **Streaming studio integration**: Netflix piloting AI shorts on platform marketing; Amazon MGM Studios using Runway for trailer cuts; Apple TV+ reported internal pilots on pre-vis.
- **Cinematographer reactions**: American Society of Cinematographers (ASC) and British Society of Cinematographers (BSC) published 2024-2025 position papers cautioning against AI replacement of camera-department craft, while endorsing AI for pre-vis and second-unit applications.

  #### Corporate Communications and AI Avatars (≈ $480M segment 2025)

  Enterprise avatar video—using a small number of trained synthetic presenters to deliver scalable, localisable training and communications content—is one of the most commercially mature AI video applications.

- **Synthesia (London)**: $1B+ unicorn 2023, 200+ AI avatars trained via GAN+diffusion hybrid pipeline; customers include Reuters, BBC, Tiffany, Vodafone, Zoom, Xerox, Heineken, BSH Home Appliances; 50,000+ enterprise users; flagship UK AI-video deployment. Synthesia's *Express* and *Studio* tiers cover individual creators through Fortune 500 internal training (compliance, onboarding, sales enablement). Avatars trained from 10-15 minutes of source video; outputs in 130+ languages. Series D $90M raised October 2023; Series E reportedly in 2025.
- **HeyGen (Los Angeles)**: $500M valuation 2024; avatar video at scale; viral *Translate* feature for personal lip-sync localisation. Growth from $1M to $35M ARR in 12 months (2023-2024). Notable for prosumer accessibility versus Synthesia's enterprise focus.
- **D-ID (Israel)**: Photo-to-video puppetry, Microsoft Teams integration, *Creative Reality Studio*. Acquired by ElevenLabs in late 2024 to form joint voice-and-face synthesis platform.
- **Hour One (New York/Israel)**: Enterprise avatar video for L&D and sales; partnership with NBC Universal.
- **Colossyan (London/Budapest)**: Workplace learning AI avatars; PwC, Vodafone enterprise customers.
- **Microsoft Mesh + Teams Avatars (2024-2025)**: Microsoft integrated AI avatar video into Teams for meetings, partially powered by D-ID and proprietary models.

  #### Video Dubbing and Localisation

- **Papercup (London)**: AI dubbing for Netflix, Sky, BBC Studios.
- **ElevenLabs Dubbing**: Voice cloning + lip-sync via complementary AI video lip-sync providers.
- **Synthesia Express**: Enterprise localisation across 130+ languages.

  #### Social Media Short-form Creator Economy

  TikTok, Instagram Reels, and YouTube Shorts saturated with AI-generated content from prosumer tools (Pika, Hailuo, Luma free tiers, Kling consumer plans). Estimated **15-20% of new short-form uploads** include some AI-generated visual element by Q4 2025 (TikTok Creator Insights).

  #### Video Game Cinematics and Pre-vis

- **Indie titles**: AI-generated cutscenes piloted in 2024-2025 (e.g. *Pawnbarian* sequel, indie horror titles).
- **AAA studios**: Cautious adoption for storyboarding only; full cutscene AI generation rejected for quality and IP reasons through 2025.
- **Unity / Unreal Engine plugins**: Generative-video integration via third-party plugins (Convai, Inworld AI character video).

  #### Synthetic Data Generation (≈ $260M segment 2025)

  AI video pipelines generate training corpora for autonomous-vehicle perception (NVIDIA DRIVE Sim + GAN/diffusion refinement, Waymo Simulation City, Cruise/GM, Wayve London), robotics (Toyota Research Institute, Tesla Optimus, Boston Dynamics, NVIDIA Cosmos world-model platform Jan 2025), and surveillance ML (Synthesis AI San Francisco, Datagen Israel). Scale: 8M+ synthetic video frames generated daily across major AV programmes. NVIDIA's Cosmos foundation-model platform (Jan 2025) explicitly positions video diffusion as the substrate for physical-AI training, accelerating sim2real transfer for autonomous systems.

  #### Video Editing and Post-Production Augmentation (≈ $190M segment 2025)

  Beyond full generation, AI video powers per-task augmentation in conventional editing pipelines:

- **Object removal and inpainting**: Runway Erase & Replace, Adobe Premiere Pro Enhance Speech and Object Selection
- **Rotoscoping replacement**: Runway Green Screen replacing manual rotoscoping for 95%+ of background removal tasks at lower-budget productions
- **Frame interpolation and slow-motion**: RIFE, DAIN, Topaz Video AI, Adobe Time Remapping AI
- **Resolution upscaling**: Topaz Video AI 4K-8K upscaling, deployed in film restoration (Disney+ archive, BBC Archive remasters)
- **Style transfer and look-development**: Runway Video-to-Video, EbSynth-style stylisation
- **Speech-driven lip-sync**: Sync Labs, Lalamu, ElevenLabs Studio dub-and-lip-sync for international distribution

  #### Education and Accessibility

- **Language learning**: AI-dubbed instructional video with synchronised lip-sync (Synthesia, HeyGen) democratising educational content across languages
- **Sign-language video generation**: Research-stage (UCL, SignAll, Microsoft Research) generating BSL/ASL avatar video from text
- **Accessibility captioning**: AI-generated audio descriptions for visually impaired audiences, paired with video understanding
- **Historical reconstruction**: Documentary and museum AI video for archaeological reconstruction (e.g. Imperial War Museum, Smithsonian pilot projects)

  #### Deepfakes and Synthetic-Media Fraud

  The same technology powering creative applications enables malicious synthetic media. **Sumsub 2025 Identity Fraud Report**: £2.6B global synthetic-media fraud losses. Landmark incidents:

- **Hong Kong CFO deepfake (Feb 2024)**: £20M heist using deepfake video conference with a senior executive impersonation.
- **Slovak election deepfake (Sep 2023)**: Late-cycle audio-video deepfake of Progressive Slovakia leader Michal Šimečka.
- **US 2024 primary cycle**: Deepfake robocall mimicking President Biden urging voters to abstain in the New Hampshire primary.
- **Indian general election 2024**: Multiple deepfake incidents across political parties.

### Academic Context: Theoretical Foundations and Research Milestones

AI video research spans roughly five years of dramatic algorithmic progress.

#### Foundational Diffusion Video Period (2022)

- **Ho, Salimans, Gritsenko, Chan, Norouzi, Fleet (NeurIPS 2022)** — *Video Diffusion Models* — first 3D U-Net extension of DDPM to space-time, factorised space-time attention.
- **Singer et al. (Meta AI, Sep 2022)** — *Make-A-Video* — text-to-video without paired video-text by lifting a text-to-image model.
- **Ho et al. (Google, Oct 2022)** — *Imagen Video* — 1280×768 cascaded video diffusion.
- **Villegas et al. (Google, Oct 2022)** — *Phenaki* — variable-length text-conditioned video with C-ViViT tokeniser and bidirectional masked transformer.

  #### Open Foundation Period (2023)

- **Esser, Chiu, Atighehchian et al. (Runway, Feb 2023)** — *Gen-1* — first commercial video-to-video.
- **Blattmann et al. (Stability AI, Nov 2023)** — *Stable Video Diffusion* — first competitive open-weights I2V model.
- **Guo et al. (Shanghai AI Lab, ICLR 2024 / Jul 2023 arXiv)** — *AnimateDiff* — plug-in motion module compatible with personalised text-to-image diffusion.
- **Peebles & Xie (ICCV 2023)** — *Scalable Diffusion Models with Transformers (DiT)* — foundational backbone for subsequent video transformers.

  #### Sora Inflection (Feb 2024)

- **Brooks et al. (OpenAI, Feb 2024)** — *Video generation models as world simulators* — Sora technical report introducing spacetime patches and demonstrating quality-compute scaling laws for video.

  #### Rapid Maturation (2024)

- **Bar-Tal et al. (Google Research / SIGGRAPH 2024)** — *Lumiere: A Space-Time Diffusion Model* — single-pass full-duration generation via Space-Time U-Net.
- **Esser, Rombach et al. (Stability AI, Mar 2024)** — *Scaling Rectified Flow Transformers for High-Resolution Image Synthesis* — MMDiT in Stable Diffusion 3, basis for many subsequent video systems.
- **Yu et al. (Google / ICLR 2024)** — *Language Model Beats Diffusion — Tokenizer is Key to Visual Generation (MAGVIT-v2)* — lookup-free quantisation tokeniser.
- **Huang et al. (CVPR 2024)** — *VBench* — 16-dimensional video generation benchmark suite.
- **Polyak et al. (Meta AI, Oct 2024)** — *Movie Gen: A Cast of Media Foundation Models* — 30B-parameter joint video+audio research model, not commercialised pending safety review.
- **Yang et al. (Zhipu/Tsinghua, Aug 2024)** — *CogVideoX* — open-weights expert-transformer DiT.
- **Kong et al. (Tencent, Dec 2024)** — *HunyuanVideo* — 13B open-weights DiT.

  #### Continued Frontier (2025-2026)

- **Alibaba Tongyi Lab (Feb 2025)** — *Wan 2.1* technical report.
- **Runway (Mar 2025)** — Gen-4 multi-shot consistency.
- **Google DeepMind (May 2025)** — Veo 3 synchronised audio.
- **OpenAI (Sep 2025)** — Sora 2 cameo and physics improvements.
- **Various** (2025-2026) — increasing focus on long-form (>2 minute) coherence, joint video-audio-text training, world-model integration (DeepMind Genie successor lineage).

### Current Landscape (2026)

As of mid-2026, the AI video field exhibits the following structural features:

#### Market Structure

- **Generative AI video market 2025**: $1.3-1.6B (Grand View Research, MarketsandMarkets).
- **Projected 2030**: $14-17B at CAGR 41-44%.
- **Frontier consolidation**: After Sora's general-access withdrawal April 2026, four frontier providers dominate paid consumer/enterprise tier — Google Veo, Runway, Kuaishou Kling, and Adobe Firefly Video; with Pika, Luma, Hailuo, and ByteDance Dreamina holding the prosumer/short-form social tier.
- **Open-weights gap**: HunyuanVideo, Wan 2.1, CogVideoX and Mochi 1 close the open-vs-closed quality gap to ~6 months lag versus frontier as of 2026.
- **Per-second pricing**: $0.05-$0.50 per second of output across platforms; cost of compute remains the dominant economic constraint.

  #### Technical State

- **Frontier clip length**: 120 seconds at 1080p (Kling 2.1), 60-90 seconds at 4K with audio (Veo 3, Sora 2 prior to withdrawal).
- **Audio-video sync**: Solved at frontier from Veo 3 (May 2025) and Sora 2 (Sep 2025).
- **Multi-shot consistency**: Solved at frontier from Runway Gen-4 (Mar 2025), Kling 2.1 (Aug 2025).
- **Persistent limitations**: long-form coherence above 60 seconds without drift, embedded text rendering, fine hand/finger anatomy during manipulation, complex compositional prompts, physics fidelity for fluids/cloth/granular materials.

  #### Regulatory State

- **EU AI Act Article 50**: Synthetic-media disclosure enforcement August 2026.
- **UK Online Safety Act 2023**: Ofcom enforcement from April 2025.
- **UK intimate-deepfake offence**: Active April 2025 under Crime and Policing Bill.
- **SAG-AFTRA digital-replica provisions**: Active in TV/Theatrical Contract November 2023; video-game performers strike resolved June 2025 with analogous provisions.
- **C2PA content provenance**: Adopted by Adobe, Microsoft, Sony, Truepic, Leica, NVIDIA, Google (SynthID interop), OpenAI (Sora watermarking).

  #### Sociopolitical State

- **Concept-artist displacement**: Concept Art Association surveys 2024-2025 report 30-40% reduction in early-pipeline roles attributable to AI image/video tools.
- **Voice-actor and performer concerns**: Continued contractual pressure for likeness consent and royalty structures.
- **News and public-service-broadcasting policy**: BBC, ITV, Channel 4 (UK), NHK (Japan), ARD (Germany) editorial frameworks prohibit synthetic media in news/factual content without exceptional justification.

### UK Context

The United Kingdom holds a disproportionate share of AI-video relevance via DeepMind's London headquarters (Veo lineage), the Synthesia unicorn, BBC R&D's pioneering editorial framework, and a strong academic base.

#### UK Academia

- **Imperial College London**: Stefanos Zafeiriou's group on face/video generation and masked diffusion; Bjoern Menze on medical video synthesis; Tatiana Tommasi (visiting) on domain adaptation; the Visual Information Processing Group.
- **University College London (UCL)**: Tim Rocktäschel's UCL DARK Lab on video world models and foundation-model RL; Niloy Mitra on Smart Geometry Processing and neural video editing; Lourdes Agapito on video 3D reconstruction; AI Centre director-level engagement.
- **University of Edinburgh**: Iain Murray on score-based generative models (foundational to diffusion theory); Hakan Bilen on video understanding; Bob Fisher's CVPR group.
- **University of Cambridge**: José Miguel Hernández-Lobato on Bayesian generative models; Andrew Fitzgibbon (formerly Microsoft) on video reconstruction; Roberto Cipolla on video understanding.
- **University of Manchester**: Tim Cootes on medical video synthesis; Sue Astley on video analysis for screening programmes; Aphrodite Galata on motion capture and synthesis.
- **University of Oxford**: Andrew Zisserman's VGG group on video understanding and generation; Andrea Vedaldi on neural rendering and generative video.

  #### UK Industry

- **DeepMind (London)**: Veo 1/2/3 development, Lumiere research, Genie world-model lineage; UK headcount ~1,200; flagship UK AI generative-video developer.
- **Synthesia (London)**: $1B+ unicorn 2023; 200+ AI avatars; 50,000+ enterprise users; UK AI-video flagship.
- **BBC R&D (Salford and London)**: Generative AI Principles 2024; internal synthesis tooling under strict editorial guardrails; public-service-broadcaster duty of trust foregrounded.
- **Faculty AI (London)**: Government and enterprise AI consultancy, including synthetic-media risk assessment.
- **Microsoft Research Cambridge**: Multimodal generation research, Z-Code video extensions.
- **Stability AI (London)**: Stable Video Diffusion lineage; financial turbulence 2024 followed by restructuring under Sean Parker and new leadership 2024-2025.
- **Papercup (London)**: AI dubbing for Netflix, Sky, BBC Studios.
- **ITV Studios**: AI dubbing trials with Synthesia and Papercup.
- **Channel 4**: AI editorial policy 2024; limited synthetic-media pilots.
- **Sky / NBCUniversal UK**: Internal pilots for sports highlights generation and advertising creative.

  #### Northern English Industrial Cluster

  The UK's regional industrial clusters provide important infrastructure and adoption channels for AI video, particularly in public-service media, advanced manufacturing visualisation, and digital production:

- **Manchester**: BBC R&D Salford campus (MediaCityUK)—core of UK public-service-broadcaster R&D, including synthetic-media tooling under Generative AI Principles 2024. ITV Manchester. Bruntwood SciTech AI scaleups including a growing cluster of generative-media startups. University of Manchester medical AI groups applying video generation to clinical training and screening. The Christie NHS Foundation Trust AI radiotherapy planning (cross-modality MRI-CT generative imaging).
- **Leeds**: Channel 4 HQ (relocated from London 2019), driving AI editorial-policy work in Northern English broadcasting. AI scaleups in legal, fintech and creative sectors. Leeds Digital Festival annual ecosystem event. University of Leeds Centre for Immersive Technologies. Bruntwood SciTech Platform at Leeds Innovation District.
- **Sheffield**: Advanced Manufacturing Research Centre (AMRC) AI applications including video-based industrial inspection and digital-twin visualisation for Boeing, Rolls-Royce, McLaren. Sheffield Hallam computer-vision groups. University of Sheffield AI for Health programme.
- **Newcastle**: National Innovation Centre for Data; Newcastle University Open Lab (HCI and digital media research); growing creative-tech cluster (Hadrian's Tower digital).
- **Liverpool**: Liverpool Film Office digital production (the UK's most-filmed city outside London); Liverpool John Moores University immersive media programmes; The Studios Liverpool generative-AI pilots.
- **York and the North East**: York University Centre for Modelling and Simulation. National Innovation Centre for Ageing applying AI video to assistive technology.

  #### UK Regulation

- **Online Safety Act 2023**: Ofcom enforcement from April 2025; user-to-user services hosting AI-generated content carry mitigation duties.
- **ICO synthetic-media guidance 2024**: UK GDPR application to training data and personal likenesses.
- **UK AI Bill 2026 (pending)**: Anticipated to bring general-purpose AI including video generators into formal regulatory scope.
- **Intimate-image deepfake offence (Apr 2025)**: Creation criminalised under Crime and Policing Bill, regardless of distribution.
- **BBC editorial guidelines 2024**: Synthetic media must be labelled; news/current-affairs prohibition without exceptional justification.
- **Ofcom Generative AI media literacy programme 2025**: Public awareness campaigns.

### Future Directions (2026-2030)

#### Long-Form Coherence

Single-pass generation above 2 minutes with maintained character/scene identity remains the dominant unsolved problem in the field. Even Kuaishou Kling 2.1's 120-second outputs exhibit subtle identity drift and occasional inconsistency in clothing, hairstyle, or facial detail across the duration. Research directions include hierarchical keyframe-then-interpolation (Lumiere-style space-time U-Net producing all frames jointly), autoregressive chunk generation with strong previous-clip conditioning (Phenaki-style with C-ViViT or MAGVIT-v2 tokenisers feeding a transformer language-model backbone), world-model latent rollout (DeepMind Genie lineage treating video as state-action sequences in a learnt simulator), dedicated long-context attention mechanisms (linear attention, Mamba-style state-space models, mixture-of-experts gating over long sequences), and explicit scene-graph or storyboard conditioning anchoring identity across cuts. **Projected**: 5-10 minute coherent clips achievable at frontier by 2028, with full-feature-film generation (>90 minutes) remaining beyond the projected 2030 horizon for end-to-end models; long-form narrative video by 2030 likely composed of chained shorter clips with cross-shot consistency guarantees.

#### Joint Video-Audio-Text Generation

Veo 3 (May 2025) and Sora 2 (Sep 2025) demonstrated synchronised audio integration as the new frontier capability. The next frontier is joint video-audio-text foundation models trained end-to-end on multimodal corpora rather than separately-trained models composed at inference. Meta's Movie Gen (Polyak et al. Oct 2024) demonstrated the 30B-parameter research recipe—joint training over video and audio tokens with shared spatiotemporal attention—but withheld commercial release pending safety review. DeepMind's Veo 3 architecture (May 2025) integrates audio tokens into the MMDiT backbone with cross-attention to the video stream. Open-weights successors (HunyuanVideo audio extension, Wan with audio) are anticipated 2026-2027. The technical challenges are non-trivial: speech requires precise phoneme-level lip-sync at 24-30 fps frame cadence; foley requires causal alignment with on-screen events; music requires longer-range temporal structure than visuals. **Projected**: Video, audio, dialogue, music, and foley jointly generated at production quality by 2027; full multilingual lip-sync localisation pipelines automated by 2028.

#### World Models and Interactive Generation

AI video systems are increasingly viewed as **world models**—learnt simulators of physical reality usable for planning, embodied AI training, robotics, and interactive media. DeepMind's Genie (Mar 2024) and Genie 2 (Dec 2024) lineage explicitly trains video models as interactive 2D and 3D world simulators with action conditioning. OpenAI's framing of Sora as a *world simulator* in the technical report title positions video diffusion as an empirical learner of physics. NVIDIA Cosmos (Jan 2025) and Wayve's GAIA-2 (London, 2024-2025) target autonomous-driving world modelling explicitly. Academic work on physics-informed video diffusion (PhysGen, MIT CSAIL 2024; Stanford physics-aware video) attempts to inject conservation laws as inductive biases. **Projected**: Interactive AI video (real-time generation responsive to user input via keyboard, controller or pose) deployed in gaming, VR, embodied-AI training and robotics simulation by 2028-2030; the line between AI video and game engines progressively dissolves.

#### Edge and Real-Time Generation

LTX-Video (Nov 2024) demonstrated real-time 768×512 generation on consumer GPUs. Distillation, quantisation (FP8, INT4), and architectural specialisation will progressively bring real-time AI video to consumer devices. **Projected**: Real-time 1080p AI video on consumer GPUs / Apple Silicon / mobile NPUs by 2027-2028, with applications in live-streaming filters, AR overlays, video conferencing avatars, and game cinematics.

#### Provenance and Watermarking at Scale

C2PA adoption, SynthID-style invisible watermarks, and regulatory enforcement (EU AI Act Article 50, UK Online Safety Act, BBC editorial framework) will progressively mandate provenance metadata for all AI-generated video. **Projected**: 90%+ of frontier-model AI video carries verifiable provenance metadata by 2028; adversarial watermark-removal countermeasures and counter-counter-measures evolve in parallel.

#### Personalisation and Fine-Tuning

LoRA-class adapters, character/style fine-tuning, and personal-likeness models with consent management (Sora 2's cameo, Synthesia's avatar training pipeline) will enable mass personalisation. **Projected**: Per-user personalised generative video models (analogous to per-user LLM fine-tuning) commercially deployed by 2027.

#### Production Pipeline Integration

Adobe Firefly Video integration with Premiere Pro (Oct 2024), Runway's professional video editor (Gen-4), and emerging Unity/Unreal Engine plugins point toward AI video as a first-class layer in professional production pipelines rather than a standalone tool. **Projected**: Generative video integrated into 60%+ of mid-tier advertising and post-production pipelines by 2028.

#### Regulatory and Labour Equilibrium

SAG-AFTRA digital-replica provisions, EU AI Act enforcement, UK AI Bill 2026, and continued litigation (Sora 2 cameo lawsuits) will shape a regulatory equilibrium balancing creative augmentation against likeness protection, training-data consent, and synthetic-media labelling. **Projected**: A consolidated international framework on synthetic-media provenance and likeness consent emerges 2027-2029.

#### Aggregate Market Trajectory

- **2026 baseline**: $2.5B annual market, ~30 million monthly active users across consumer/prosumer platforms, ~150 enterprise integrations.
- **2028 projection**: $7B annual market, ~100 million MAU, ~1,500 enterprise integrations, 20%+ of advertising pre-vis using AI video.
- **2030 projection**: $15B annual market, ~250 million MAU, ~5,000 enterprise integrations, 50%+ of mid-tier advertising and corporate communications using AI video.

### Research and Literature

**Foundational Diffusion Video Works**:
1. Ho, J., Salimans, T., Gritsenko, A., Chan, W., Norouzi, M., & Fleet, D.J. (2022). Video Diffusion Models. *Advances in Neural Information Processing Systems 35 (NeurIPS 2022)*. arXiv:2204.03458 [First 3D U-Net extension of DDPM to video]
2. Singer, U., Polyak, A., Hayes, T., Yin, X., An, J., Zhang, S., et al. (2022). Make-A-Video: Text-to-Video Generation without Text-Video Data. *Meta AI tech report*. arXiv:2209.14792 [Lifting text-to-image to video]
3. Ho, J., Chan, W., Saharia, C., Whang, J., Gao, R., Gritsenko, A., et al. (2022). Imagen Video: High Definition Video Generation with Diffusion Models. *Google tech report*. arXiv:2210.02303 [1280×768 cascaded video diffusion]
4. Villegas, R., Babaeizadeh, M., Kindermans, P.J., Moraldo, H., Zhang, H., Saffar, M.T., Castro, S., Kunze, J., & Erhan, D. (2022). Phenaki: Variable Length Video Generation From Open Domain Textual Description. *arXiv:2210.02399* [C-ViViT, variable-length generation]

**Open Foundation Models**:
5. Blattmann, A., Dockhorn, T., Kulal, S., Mendelevitch, D., Kilian, M., Lorenz, D., et al. (2023). Stable Video Diffusion: Scaling Latent Video Diffusion Models to Large Datasets. *Stability AI tech report*. arXiv:2311.15127 [First competitive open-weights I2V]
6. Guo, Y., Yang, C., Rao, A., Wang, Y., Qiao, Y., Lin, D., & Dai, B. (2024). AnimateDiff: Animate Your Personalized Text-to-Image Diffusion Models without Specific Tuning. *International Conference on Learning Representations (ICLR 2024)*. arXiv:2307.04725 [Plug-in motion module]

**Diffusion Transformers and Tokenisation**:
7. Peebles, W., & Xie, S. (2023). Scalable Diffusion Models with Transformers (DiT). *IEEE International Conference on Computer Vision (ICCV 2023)*. arXiv:2212.09748 [Foundational DiT]
8. Esser, P., Kulal, S., Blattmann, A., Entezari, R., Müller, J., Saini, H., et al. (2024). Scaling Rectified Flow Transformers for High-Resolution Image Synthesis. *International Conference on Machine Learning (ICML 2024)*. arXiv:2403.03206 [MMDiT, Stable Diffusion 3]
9. Yu, L., Lezama, J., Gundavarapu, N.B., Versari, L., Sohn, K., Minnen, D., et al. (2024). Language Model Beats Diffusion — Tokenizer is Key to Visual Generation (MAGVIT-v2). *International Conference on Learning Representations (ICLR 2024)*. arXiv:2310.05737 [Lookup-free quantisation]

**Frontier Commercial Reports**:
10. Brooks, T., Peebles, B., Holmes, C., DePue, W., Guo, Y., Jing, L., et al. (2024). Video generation models as world simulators. *OpenAI technical report*, February 2024. [Sora architecture]
11. Bar-Tal, O., Chefer, H., Tov, O., Herrmann, C., Paiss, R., Zada, S., et al. (2024). Lumiere: A Space-Time Diffusion Model for Video Generation. *ACM SIGGRAPH 2024*. arXiv:2401.12945 [Single-pass full-duration generation]
12. Polyak, A., Zohar, A., Brown, A., Tjandra, A., Sinha, A., Lee, A., et al. (2024). Movie Gen: A Cast of Media Foundation Models. *Meta AI tech report*, October 2024. arXiv:2410.13720 [30B joint video+audio]
13. Kong, W., Tian, Q., Zhang, Z., Min, R., Dai, Z., Zhou, J., et al. (2024). HunyuanVideo: A Systematic Framework For Large Video Generative Models. *Tencent tech report*, December 2024. arXiv:2412.03603 [13B open-weights]
14. Yang, Z., Teng, J., Zheng, W., Ding, M., Huang, S., Xu, J., et al. (2024). CogVideoX: Text-to-Video Diffusion Models with An Expert Transformer. *Zhipu AI / Tsinghua tech report*. arXiv:2408.06072 [Open-weights expert transformer]

**Evaluation and Benchmarks**:
15. Unterthiner, T., van Steenkiste, S., Kurach, K., Marinier, R., Michalski, M., & Gelly, S. (2018). Towards Accurate Generative Models of Video: A New Metric & Challenges (FVD). *Google tech report*. arXiv:1812.01717 [Fréchet Video Distance]
16. Huang, Z., He, Y., Yu, J., Zhang, F., Si, C., Jiang, Y., et al. (2024). VBench: Comprehensive Benchmark Suite for Video Generative Models. *IEEE Conference on Computer Vision and Pattern Recognition (CVPR 2024)*. arXiv:2311.17982 [16-dimensional video benchmark]
17. Liu, Y., Cun, X., Liu, X., Wang, X., Zhang, Y., Chen, H., et al. (2023). EvalCrafter: Benchmarking and Evaluating Large Video Generation Models. *arXiv:2310.11440* [Multi-axis video evaluation]
18. Sun, K., Huang, K., Liu, X., Wu, Y., Xu, Z., Li, Z., & Liu, X. (2024). T2V-CompBench: A Comprehensive Benchmark for Compositional Text-to-Video Generation. *arXiv:2407.14505* [Compositional reasoning benchmark]

**Theoretical Foundations**:
19. Ho, J., & Salimans, T. (2022). Classifier-Free Diffusion Guidance. *NeurIPS Workshop on Deep Generative Models*. arXiv:2207.12598 [CFG]
20. Song, Y., Sohl-Dickstein, J., Kingma, D.P., Kumar, A., Ermon, S., & Poole, B. (2021). Score-Based Generative Modeling through Stochastic Differential Equations. *International Conference on Learning Representations (ICLR 2021)*. arXiv:2011.13456 [Score-based SDE framework]
21. Ho, J., Jain, A., & Abbeel, P. (2020). Denoising Diffusion Probabilistic Models. *Advances in Neural Information Processing Systems 33 (NeurIPS 2020)*. arXiv:2006.11239 [DDPM]
22. Liu, X., Gong, C., & Liu, Q. (2022). Flow Straight and Fast: Learning to Generate and Transfer Data with Rectified Flow. *arXiv:2209.03003* [Rectified flow theory]

**Industry and Regulatory Reports**:
23. Sumsub Research (2025). *2025 Identity Fraud Report — global synthetic-media fraud losses*. Sumsub, London/Berlin.
24. Grand View Research (2025). *Generative AI Video Market Analysis 2025-2030*. Report GVR-4-68039-749-8.
25. UK Government (2023). *Online Safety Act 2023*. UK Parliament; Ofcom enforcement guidance 2025.
26. European Union (2024). *AI Act, Article 50 deepfake disclosure*. Regulation (EU) 2024/1689.
27. SAG-AFTRA (2023). *TV/Theatrical Contract AI Provisions*. November 2023.
28. BBC R&D (2024). *Generative AI Principles*. BBC editorial guidelines / R&D publication, London.
29. C2PA Consortium (2024). *Content Provenance and Authenticity Specification 2.0*. C2PA Consortium.

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review during Phase 6 enrichment sprint
- **Verification**: Academic sources verified against arXiv, IEEE Xplore, NeurIPS/ICML/CVPR/ICLR/SIGGRAPH proceedings; commercial release dates verified against vendor announcements and contemporary press coverage (Bloomberg, TechCrunch, The Verge, Fortune); industry statistics cross-referenced against Grand View Research, MarketsandMarkets, Sumsub Identity Fraud Report, Concept Art Association surveys
- **Regional Context**: UK academic institutions (Imperial College London, University of Edinburgh, UCL, University of Cambridge, University of Manchester, University of Oxford) and UK industry deployments (DeepMind, Synthesia, BBC R&D, Faculty AI, Stability AI, Papercup, Microsoft Research Cambridge), Northern English innovation hubs (Manchester, Leeds, Sheffield, Newcastle, Liverpool) detailed
- **Production-Ready**: Complete OWL formal semantics, comprehensive content coverage (architecture, commercial models, open-source landscape, applications, statistics, UK context, future directions), 29 academic and industry citations spanning 2018-2025
- **Authority Score**: 0.87 (rapidly maturing generative-AI sub-field, $1.5B 2025 market, frontier commercial deployment, mature regulatory response, active academic research frontier, foundational role in broader multimodal AI)

### Provenance

