Amazon is an online retailer that runs its own fulfilment and delivery operations. The European Commission described Amazon in a 2022 decision as based in Seattle, Washington, US, operating a range of businesses including retail, entertainment, consumer electronics and technology services.[^1]

## Logistics operations

Amazon's own operations page says that it partners with a network of delivery businesses (Delivery Service Partners), a community of independent contractors (Amazon Flex) and small business owners such as coffee shops or florists (Hub Delivery) to deliver millions of packages to customers each day.[^2] It also says that collaborative robots and new technology help sort and move billions of products and packages each year across its operations network.[^2] Those figures are company claims and were not checked against an independent count.

The Industrial Ontologies Foundry uses Amazon in several examples that show how a retailer holds logistics roles: an Amazon fulfilment centre as a consignor when it prepares an ordered item for shipping, the role of a person who uses a personal vehicle to deliver Amazon packages as an example of the transportation service provider role, defined as a logistics service provider role held by a business organisation or person when it provides a transportation service, and Amazon holding, meaning having custody of, a shipment that is out for delivery but not yet delivered.[^3] The CSCMP wording quoted in the same ontology names on-line stores like Amazon among retailers.[^3]

## Role in the supply chain

Amazon is a [[Retailer]] with its own logistics network, which the vault relates to [[Fulfilment Centre]], [[E-Commerce]] and [[Autonomous Mobile Robots]]. The ontology examples above show that the role of retailer and the roles of consignor and delivery provider can be held by one organisation.[^3] In this vault Amazon is a class under the retailer role, not an individual.

## What the sources do not establish

Sources do not give parcel volumes, site counts, fleet sizes or the share of deliveries Amazon makes itself, apart from the company's statement that delivery partners are used. The Commission's description dates from 2022 and was written for a media acquisition, so it says little about logistics.[^1][^2]

[^1]: European Commission, Case M.10349 Amazon / MGM, decision of 2022. https://ec.europa.eu/competition/mergers/cases1/202250/M_10349_8691929_626_3.pdf
[^2]: Amazon, “Amazon’s Operations” page. https://www.aboutamazon.com/what-we-do/delivery-logistics
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

