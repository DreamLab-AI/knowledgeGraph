An entropy source is a physical or computational process that produces unpredictable raw data used to seed cryptographic random number generation. Good entropy sources draw on inherently uncertain phenomena, such as electronic noise, timing jitter or radioactive decay, so that their output cannot be predicted or reproduced by an adversary. The quality of an entropy source directly determines the strength of keys, nonces and other security-critical random values derived from it.

### Overview

- Cryptographic security rests on the assumption that secret values are drawn from a space too large to search and impossible to predict. An entropy source supplies the unpredictability that makes this assumption hold. Raw entropy is typically gathered, assessed for quality, conditioned to remove bias, and then used to seed a deterministic random bit generator. Weak or predictable entropy sources are a recurring cause of catastrophic cryptographic failures.

### Mechanisms

- Physical noise sources such as thermal noise, jitter or shot noise.
- Entropy estimation measures the unpredictability of collected samples.
- Conditioning (whitening) removes statistical bias from raw output.
- Seeded deterministic generators expand collected entropy into bit streams.
- Hardware security modules and TRNGs provide high-assurance sources.

### Applications

- Generation of cryptographic keys and key pairs.
- Production of nonces and initialisation vectors for ciphers.
- Seeding session tokens and challenge values in protocols.
- Provisioning randomness for secure hardware and wallets.

### Provenance

