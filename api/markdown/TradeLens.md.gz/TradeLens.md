TradeLens was a blockchain-enabled shipping platform announced in 2018 and jointly developed by IBM and GTD Solution, a division of Maersk, to promote more efficient and secure global trade; Maersk and IBM announced its discontinuation on 29 November 2022.[^1]

Maersk's press release says TradeLens was founded on the bold vision of making a leap in global supply chain digitisation as an open and neutral industry platform.[^1] It gives the reason for closing it in these words: although a viable platform had been developed, the need for full global industry collaboration had not been achieved, and as a result TradeLens had not reached the level of commercial viability necessary to continue work and meet the financial expectations as an independent business.[^1] The intent was that the platform would go offline by the end of the first quarter of 2023.[^1]

## Reach

A trade publication reported that TradeLens had built a network of more than 300 members, including ocean carriers such as CMA CGM, MSC and Zim, together with terminals, inland depots, customs authorities and intermodal providers.[^2] The same article says other industry players had doubts about the project from the start.[^2]

## Scope and distinctions

TradeLens is an example of a [[Digital Trade Platform]]. The sources describe it as blockchain-enabled but do not describe how the blockchain was used, so the page makes no claim about the underlying technology; see [[Blockchain]] and [[Supply Chain Blockchain]].[^1] Maersk said it would continue its efforts to digitise the supply chain through other solutions.[^1] See [[Maersk]].

## What the sources do not establish

Maersk's own statement is the reason given for the closure, and the opened trade press largely repeats it. No independent analysis, nor figures for revenue or usage, were available. The member count is the trade publication's and carries no date.[^1][^2]

[^1]: A.P. Moller - Maersk, “A.P. Moller - Maersk and IBM to discontinue TradeLens, a blockchain-enabled global trade platform”, press release, 29 November 2022. https://www.maersk.com/news/articles/2022/11/29/maersk-and-ibm-to-discontinue-tradelens
[^2]: Supply Chain Movement, “Maersk and IBM pull the plug on TradeLens”, 15 December 2022. https://supplychainmovement.com/?p=26966

