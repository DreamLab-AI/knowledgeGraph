Accounts denotes the financial reporting and filing obligations of a limited company under UK law, encompassing annual accounts preparation, Companies House submission deadlines, confirmation statements, and the penalties regime for late filing.

### Semantic Classification

### Content

- For a limited company in the UK, the due dates for annual accounts are determined by your company's 'accounting reference date,' which is the end of your financial year. Here's how it typically works:
- **First Accounting Period**:
- Your first accounting period starts on the day your company is incorporated and runs until the end of the month in which the anniversary of incorporation falls, in the following year.
  - For example, if your company was incorporated in April 2022, your first accounting period would likely run until April 30, 2023.
- **Filing Deadline**:
- For your first accounts, you have 21 months from the date of incorporation to file with Companies House. This is longer than the normal deadline due to being your first year.
  - Subsequently, you have 9 months from your accounting reference date to file your accounts. So, for the accounting period ending April 30, 2023, your accounts would be due by January 31, 2024.
- **Confirmation Statement**:
- Alongside your accounts, you also need to file a confirmation statement annually. This is due 14 days after the anniversary of incorporation.
- **Penalties for Late Filing**:
- Companies House imposes penalties for late filing, which increase over time. It's crucial to adhere to these deadlines to avoid penalties.
- **Annual Return**:
- The annual return is a snapshot of company information, separate from the financial accounts, and also needs to be filed annually.
- **Staying Organized**:
- Keep track of these dates in your calendar and maintain regular communication with your accountant to ensure all filings are completed on time.
- Your accountant will be able to provide the exact dates for your specific circumstances, but this general framework should give you a good idea of what to expect.
- https://docs.google.com/spreadsheets/d/1fIM6SqpkZdfRsnAInrd1e-A5cPOG3r76CfQhRCQGeE0/edit?usp=sharing

![rawaccounts.pdf](assets/rawaccounts_1714229501722_0.pdf)

![Feb2024-flossverse-010.pdf](assets/Feb2024-flossverse-010_1717315840873_0.pdf)

![Feb2024-flossverse-011.pdf](assets/Feb2024-flossverse-011_1717315846806_0.pdf)

![Jan2024-flossverse-009.pdf](assets/Jan2024-flossverse-009_1717315853965_0.pdf)

![March2024-flossverse-012.pdf](assets/March2024-flossverse-012_1717315861420_0.pdf)

![October2023-flossverse-007.pdf](assets/October2023-flossverse-007_1717315868338_0.pdf)

![October2023-flossverse-008.pdf](assets/October2023-flossverse-008_1717315874531_0.pdf)

### Provenance

