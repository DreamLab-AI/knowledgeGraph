
An intent parameter is a typed parameter that specifies "the scope and execution conditions of an intent". It is declared as `IntentParameter` in the Agent Ontology's intent module.[^1]

An [[Agent Intent]] attaches parameters through `hasParameter`. Each parameter has three string properties: `paramName`, `paramType` and `paramValue`. Unlike a [[Skill Parameter]] (declared in the capability module), which describes the shape of an input to an [[Atomic Skill]], an intent parameter carries a value, so it states the particular conditions under which this intent is to be fulfilled.[^1]

The ontology does not say how the type string is interpreted, and does not link intent parameters to skill parameters, so any matching between the two is left to implementers.

[^1]: Semantic Agent Communication Community Group, “Intent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/intent.ttl

