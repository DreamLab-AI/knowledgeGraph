Web Technology encompasses the protocols, standards, frameworks, and distributed infrastructure that enable the authoring, delivery, and interaction of resources on the World Wide Web and its decentralised successors. It spans the foundational internet protocols (HTTP/HTTPS, DNS, TLS), client-side and server-side execution environments (browsers, JavaScript runtimes, WebAssembly), and the emerging Web3 stack (content-addressed storage, blockchain naming, decentralised identity) that shifts data sovereignty from centralised operators to individual users. Together these layers define how information is addressed, transmitted, rendered, and secured across heterogeneous networked devices at planetary scale.

### Overview

- The Web is a layered system built atop the internet's packet-switching substrate ([[TCP-IP]]). Each layer adds abstraction: [[Transport Layer Security]] secures the channel, [[HTTP]] structures request-response semantics, [[DNS]] resolves human-readable names to IP addresses, and HTML/CSS/JavaScript compose the rendered document experience.
- Web Technology is broadly divided into three generations:
  - **Web 1.0** — static, read-only hypertext documents served from centralised origins; dominated by HTML, FTP, and early [[HTTP]] versions.
  - **Web 2.0** — dynamic, read-write platforms; introduced [[AJAX]], [[REST API]], [[JavaScript]] frameworks, [[Content Delivery Network]] edge caching, and cloud-hosted databases enabling participatory social media and SaaS.
  - **Web3** — decentralised, read-write-own paradigm; built on [[Blockchain]], [[Smart Contract]] execution environments, content-addressed storage ([[IPFS]], Arweave), and self-sovereign identity ([[Decentralised Identity]], [[DIDs]]).
- Why it matters: The Web is the primary channel for information access, commerce, collaboration, and application delivery for billions of users. Advances in Web Technology directly shape the economics of software distribution, the architecture of enterprise systems, and the feasibility of new paradigms such as [[Spatial Computing]] and in-browser [[Machine Learning]].

### Key Components

#### Transport and Addressing Protocols

- [[HTTP]] / HTTP/2 / HTTP/3 (QUIC) — stateless request-response protocols defining methods (GET, POST, PUT, DELETE) and status codes.
- [[HTTPS]] — HTTP over [[Transport Layer Security]]; provides encryption, server authentication, and integrity protection via X.509 certificates.
- [[DNS]] — hierarchical name resolution translating domain labels (e.g. `example.com`) to IP addresses; a foundational dependency of the Web.
- [[TCP-IP]] — the underlying packet-switched transport on which all Web protocols operate.
- WebSocket — full-duplex persistent connection over a single TCP connection, enabling [[Real-Time Communication]] without polling.

#### Client-Side Technologies

- [[HTML]] (HyperText Markup Language) — the semantic document structure standard maintained by [[WHATWG]] as a living standard.
- [[CSS]] (Cascading Style Sheets) — declarative layout and styling language; CSS Grid, Flexbox, and Custom Properties underpin modern responsive design.
- [[JavaScript]] — the primary scripting language of the browser; standardised as ECMAScript by TC39; powers both client-side interactivity and server-side runtimes (Node.js, Deno).
- [[WebAssembly]] — a compact binary instruction format compiled from C, C++, Rust, or Go that executes at near-native speed in sandboxed browser environments; enables compute-intensive applications (3D rendering, codecs, [[Machine Learning]] inference).
- [[Progressive Web App]] — a web application enhanced with service workers, manifests, and offline caching to approximate the capabilities of [[Native Application]] installs.
- Web Components — a suite of browser APIs (Custom Elements, Shadow DOM, HTML Templates) enabling reusable, encapsulated UI components without framework dependencies.

#### Server-Side and API Layers

- [[REST API]] — architectural style using HTTP verbs and resource URIs for interoperability between services; dominant in Web 2.0 integration.
- [[GraphQL]] — query language and runtime for APIs enabling clients to specify exact data requirements, reducing over-fetching; widely adopted in [[Web3]] data indexing (The Graph protocol).
- Server-Sent Events / gRPC / Webhooks — alternative server-push and RPC mechanisms for event-driven microservice architectures.
- Edge Functions / Serverless — compute executed at [[Content Delivery Network]] edge nodes, minimising latency for global users.

#### Web3 and Decentralised Layer

- [[IPFS]] (InterPlanetary File System) — content-addressed, peer-to-peer hypermedia protocol using cryptographic multihashes; enables permanent, location-independent content retrieval.
- Filecoin / Arweave — incentivised decentralised storage networks built atop content-addressing; Filecoin uses proof-of-spacetime, Arweave uses a blockweave endowment model.
- [[ENS]] (Ethereum Name Service) — on-chain hierarchical naming system mapping human-readable `.eth` names to Ethereum addresses, IPFS content hashes, and metadata via resolver contracts.
- [[Decentralised Identity]] / [[DIDs]] — W3C specification for self-sovereign identifiers resolvable without centralised registries; paired with Verifiable Credentials for privacy-preserving attestations.
- [[Smart Contract]] — self-executing code on blockchain VMs (EVM, Solana's SVM) that governs decentralised application logic, token economics, and DAO governance without intermediaries.
- [[Decentralised Storage]] — broad category encompassing IPFS, Filecoin, Arweave, Storj, and Sia; contrasts with centralised [[Centralised Cloud]] object stores.
- WalletConnect / Web3Modal — protocols enabling [[Web Browser]]-based dApps to communicate with hardware and mobile wallets via QR-code-paired encrypted relay channels.

#### Security and Identity

- [[Transport Layer Security]] (Transport Layer Security) — cryptographic protocol securing the channel between client and server; TLS 1.3 is the current standard.
- CORS (Cross-Origin Resource Sharing) — browser-enforced policy restricting cross-origin HTTP requests; mitigates data-exfiltration attacks.
- Content Security Policy (CSP) — HTTP header restricting resource origins permitted by a page; reduces XSS attack surface.
- OAuth 2.0 / OpenID Connect — federated authentication and authorisation protocols enabling Single Sign-On across services.
- [[Decentralised Identity]] / [[DIDs]] — eliminates reliance on centralised identity providers; enables self-sovereign, cryptographically verifiable authentication.

### Applications and Use Cases

- **E-Commerce and Payments** — HTTP/2, PWA, and CDN edge caching reduce page-load latency, directly improving conversion rates on retail platforms; Web3 enables trustless on-chain payment rails.
- **Real-Time Collaboration** — WebSocket, WebRTC ([[Real-Time Communication]]), and WebTransport underpin tools such as Google Docs, Figma, and video conferencing applications.
- **In-Browser AI and ML** — [[WebAssembly]] and WebGPU enable [[Machine Learning]] model inference directly in the browser without server round-trips; frameworks like TensorFlow.js and ONNX Runtime Web exploit these primitives.
- **Spatial and Immersive Web** — WebXR API exposes VR/AR device capabilities to the browser, bridging Web Technology with [[Spatial Computing]]; A-Frame and Three.js provide declarative scene graphs.
- **Decentralised Applications (dApps)** — Web3 front-ends (React + Ethers.js) connect to [[Smart Contract]] back-ends via JSON-RPC, enabling DeFi, NFT marketplaces, and DAO governance interfaces without centralised servers.
- **Progressive Enhancement** — service workers enable offline-first architectures (e.g. news readers, maps) by intercepting network requests and serving cached responses.
- **IoT and Edge Web** — lightweight HTTP and WebSocket stacks run on microcontrollers; MQTT-over-WebSocket bridges constrained devices to Web dashboards.
- **Developer Tooling and Build Pipelines** — bundlers (Webpack, Vite, esbuild), transpilers (Babel, TypeScript), and package ecosystems (npm, Yarn) standardise the modern Web development workflow.

### Standards and Governance

- **[[World Wide Web Consortium]]** (World Wide Web Consortium) — primary standards body for HTML, CSS, WebAssembly, SVG, accessibility guidelines (WCAG), WebXR, and decentralised identity (DIDs, Verifiable Credentials).
- **[[WHATWG]]** (Web Hypertext Application Technology Working Group) — maintains the HTML Living Standard and the Fetch, URL, Encoding, and Streams specifications collaboratively with browser vendors.
- **[[IETF]]** (Internet Engineering Task Force) — publishes RFCs governing HTTP (RFC 9110–9114 for HTTP/3), [[Transport Layer Security]], [[DNS]], WebSocket (RFC 6455), and related transport protocols.
- **TC39** — Ecma International technical committee standardising ECMAScript (JavaScript); follows a staged proposal process with annual release cadence.
- **WHATWG / W3C Convergence (2019)** — W3C and WHATWG agreed a single HTML and DOM specification, ending the parallel HTML5 / HTML Living Standard duplication.
- **Web Accessibility Initiative (WAI)** — W3C programme producing WCAG, ARIA, and ATAG; accessibility compliance is legally required in many jurisdictions (EU Accessibility Act, ADA in the US).
- **Open Web Platform** — the collective label for the interoperable, royalty-free set of web standards that browser vendors (Google, Apple, Mozilla, Microsoft) implement according to W3C/WHATWG specifications.

### Evolution and Historical Context

- **1989–1991** — Tim Berners-Lee proposes and implements the first [[HTTP]] server and [[HTML]] browser at CERN; the Web launches as a hypertext document system.
- **1994** — W3C founded; Netscape Navigator popularises the graphical Web; SSL (predecessor to [[Transport Layer Security]]) introduced for secure commerce.
- **1995–2000** — [[JavaScript]] introduced by Netscape (1995); browser wars accelerate proprietary extensions; dot-com boom drives rapid adoption.
- **2004–2008** — AJAX coined; Web 2.0 era begins; Gmail and Google Maps demonstrate dynamic single-page applications; Web 2.0 frameworks (jQuery, Prototype) emerge.
- **2009–2015** — Node.js brings [[JavaScript]] server-side; responsive design and CSS media queries address the mobile shift; HTML5 canvas, WebGL, and WebSocket standardised.
- **2015–2020** — HTTP/2 deployed; ES6/ES2015 modernises [[JavaScript]]; React, Angular, Vue popularise component-based front-ends; [[WebAssembly]] reaches MVP (2017).
- **2020–present** — HTTP/3 (QUIC) rolls out; [[Web3]] ecosystem matures (DeFi, NFTs, DAOs); WebGPU standardised for GPU compute; [[Spatial Computing]] via WebXR gains traction; in-browser [[Machine Learning]] via TensorFlow.js and WebGPU accelerated runtimes.

### Current Landscape (2026)

- WebGPU reached Web Platform Baseline "Newly available" in January 2026 once Safari 26 (macOS Tahoe, iOS, iPadOS, visionOS) and Firefox (141+ on Windows, 145+ on macOS ARM64) joined Chrome/Edge; the 2025 Web Almanac put WebGPU at roughly 65% of new 3D web apps (up from about 8% two years earlier), and Three.js has shipped it as the recommended renderer since r171, effectively ending WebGL's 15-year run as the default web 3D API.
- WebAssembly 3.0 was announced in September 2025, consolidating garbage collection (WasmGC), 64-bit memory (Memory64), exception handling with exnref, tail calls, relaxed SIMD and multiple memories; the Bytecode Alliance ratified WASI 0.3.0 in June 2026, rebasing WASI onto the Component Model with native async primitives.
- The Interop 2025 project closed the year at a 97% cross-browser pass rate (Safari alone jumped from 43 to 99), making anchor positioning, same-document View Transitions, the Navigation API, URLPattern and the Popover API interoperable; Interop 2026 continued the cadence, pushing cross-document View Transitions and WebGPU to a 90%+ Web Platform Tests pass rate across all four engines within Q1.
- WebTransport (low-latency bidirectional transport over HTTP/3) crossed Baseline in March 2026 when Safari 26.4 shipped support, and WebCodecs reached near-Baseline with Safari 26 full support, underpinning production tools such as Zoom Web, Loom and Adobe Premiere Web.
- In-browser AI moved onto the platform via Chrome's built-in AI APIs (Prompt, Summariser, Writer, Rewriter, Translator, Proofreader) powered by on-device Gemini Nano and the Gemma 197M expert model, with the Prompt API reaching stable in Chrome 148; WebNN, by contrast, remains an origin trial (Chrome 147-149) with production as a default path estimated for 2027.
- The "agentic web" emerged as the dominant framing at Google I/O 2026: WebMCP (a proposed standard exposing site JavaScript functions and forms to browser agents) entered origin trial in Chrome 149, Chrome Auto Browse (Gemini 3) rolled out from late January and reached Android at OS level from late June, while OpenAI retired its standalone ChatGPT Atlas browser on 9 August 2026.
- Open challenges as of 2026: WebGPU's mobile/Linux tail (Linux Firefox and pre-A12 iPhones still fall back to WebGL2), several hardware APIs (WebUSB, WebHID, WebSerial, Speculation Rules, Document PiP) remaining permanently Chromium-only under WebKit/Mozilla negative positions, agentic-browser security (prompt injection, DLP) driving enterprise controls such as Chrome Enterprise Premium, and WebAssembly's flat real-world footprint at about 0.35% of desktop sites per the 2025 Web Almanac.

### References

- 1. Utsubo (2026). Frontier Web APIs 2026: WebGPU, WebTransport & What's Production-Ready. https://www.utsubo.com/blog/frontier-web-apis-2026-production-ready
- 2. Platform.uno / Jerome Laban (2026). The State of WebAssembly – 2025 and 2026. https://platform.uno/blog/the-state-of-webassembly-2025-2026/
- 3. WebKit (2026). Interop 2025: A year of convergence. https://webkit.org/blog/17808/interop-2025-review/
- 4. web.dev (2026). March 2026 Baseline monthly digest. https://web.dev/blog/baseline-digest-mar-2026
- 5. Chrome for Developers (2026). 15 updates from Google I/O 2026: Powering the agentic web. https://developer.chrome.com/blog/chrome-at-io26
- 6. NoHacks (2026). The Agentic Browser Landscape in 2026: A Complete Guide. https://nohacks.co/blog/agentic-browser-landscape-2026

### Provenance

