Supply chain redundancy is spare capacity, inventory or alternative sources held in a supply chain so that it can absorb a disruption, at a cost in normal times.[^1]

Christopher and Peck say that surplus capacity and inventory have conventionally been seen only as waste and are therefore undesirable.[^1] They argue that the strategic disposition of additional capacity or inventory at potential pinch points, which they describe as bottlenecks with limited capacity and no ready alternatives, can be extremely beneficial in creating resilience.[^1] They invite managers to re-examine the efficiency versus redundancy trade-off, and note that both capacity and inventory provide slack to cope with surges.[^1]

They do not advocate a return to buffering every stage with safety stock or excess capacity; they suggest that the strategic and selective use of slack may be fundamental to resilience.[^1]

## Other treatments

NIST's guidance on information and communications technology supply chains advises including requirements for excess capacity, bandwidth and redundancy in agreements with suppliers and service providers, and advises diversifying the supply base for critical products and services.[^2] The UK Climate Change Committee lists inventory buffers among actions businesses can take to adapt to climate change.[^3] Dolgui, Ivanov and Sokolov present a ripple effect control framework that includes redundancy, flexibility and resilience analysis.[^4]

## Scope and distinctions

Redundancy is one of several routes to resilience described at [[Supply Chain Resilience Strategy]]. Holding stock for crises at national scale is covered at [[Strategic Stockpile]], and spreading suppliers at [[Supplier Diversification]]. See also [[Inventory Management]].

## What the sources do not establish

These sources are recommendations, not measurements. None of them gives the cost of holding redundancy against the loss avoided, a level of slack that is adequate, or evidence on how often buffers have been used. The Dolgui abstract does not set out the framework itself, which was not opened.

[^1]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^2]: National Institute of Standards and Technology, NIST Special Publication 800-161r1-upd1 (May 2022, updated), “Cybersecurity Supply Chain Risk Management Practices for Systems and Organizations”. https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-161r1-upd1.pdf
[^3]: UK Climate Change Committee, “Resilient Supply Chains (briefing, 2022)”. https://www.theccc.org.uk/wp-content/uploads/2022/10/Resilient-Supply-Chains-.pdf
[^4]: Alexandre Dolgui, Dmitry Ivanov and Boris Sokolov, International Journal of Production Research, 2018 (IDEAS/RePEc record, abstract only), “Ripple effect in the supply chain: an analysis and recent literature”. https://ideas.repec.org/a/taf/tprsxx/v56y2018i1-2p414-430.html

