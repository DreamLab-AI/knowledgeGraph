Data Analytics is the systematic computational examination of raw data sets to uncover patterns, correlations, and actionable insights that support organisational decision-making. It spans four analytical tiers: descriptive analytics (summarising historical state), diagnostic analytics (identifying causes of past events), predictive analytics (forecasting future outcomes via statistical and machine learning models), and prescriptive analytics (recommending optimal actions). Analytics pipelines ingest data from heterogeneous sources, apply transformation and enrichment steps, execute statistical or ML algorithms, and surface results through visualisations, dashboards, and automated alerts. As a discipline, data analytics integrates elements of statistics, computer science, domain knowledge, and data engineering to create measurable business and scientific value.

### Overview

- Data Analytics emerged as a formalised discipline from the convergence of statistics, computer science, and database management, accelerated by the proliferation of digital data sources and affordable computing power. Its core value proposition is transforming raw, unstructured, or semi-structured data into structured knowledge that reduces uncertainty for decision-makers.
- The four canonical analytical modes define a progression from retrospective to proactive:
  - **Descriptive analytics** aggregates historical records to answer "what happened?" — the foundation of [[Business Intelligence]] dashboards and reporting.
  - **Diagnostic analytics** drills into historical data to answer "why did it happen?" using root-cause analysis, drill-down, and correlation techniques.
  - **Predictive analytics** applies [[Statistical Modelling]] and [[Machine Learning]] to answer "what is likely to happen?" — encompassing regression, classification, time-series forecasting, and survival analysis.
  - **Prescriptive analytics** combines predictions with optimisation to answer "what should we do?" — integrating simulation, linear programming, and reinforcement learning.
- Analytics operates within a broader [[Data Engineering]] ecosystem: raw data is ingested via [[ETL]] or ELT processes into [[Data Lake]] or [[Data Warehouse]] stores, cleansed and enriched by [[Data Quality Management]] processes, governed by [[Data Governance]] policies, and finally analysed and surfaced through [[Data Visualisation]] and reporting layers.

### Key Components

- **Data Ingestion and Storage**
  - [[Data Pipeline]] — orchestrated workflows that extract, transform, and load data from source systems
  - [[ETL]] (Extract, Transform, Load) — the classical batch pattern for moving data between systems
  - [[Data Lake]] — schema-on-read stores for raw, heterogeneous data at scale (e.g. Apache Hadoop, Amazon S3)
  - [[Data Warehouse]] — schema-on-write columnar stores optimised for analytical queries (e.g. Snowflake, BigQuery, Redshift)
  - [[Data Integration]] — combining data from disparate sources into a coherent analytical view
- **Analysis and Modelling**
  - [[Statistical Modelling]] — regression, hypothesis testing, Bayesian inference, time-series analysis
  - [[Machine Learning]] — supervised, unsupervised, and reinforcement learning applied to prediction and clustering
  - [[Descriptive Analytics]] — aggregations, pivot tables, cohort analysis, summary statistics
  - [[Predictive Analytics]] — forecasting models, propensity scoring, anomaly detection
  - [[Prescriptive Analytics]] — optimisation, simulation, recommendation engines
  - [[Diagnostic Analytics]] — root-cause analysis, funnel analysis, attribution modelling
- **Infrastructure and Tooling**
  - [[Data Processing]] — batch (Apache Spark, Flink) and stream processing (Apache Kafka) frameworks
  - [[Cloud Computing]] — elastic compute and managed analytics services (AWS, Azure, GCP)
  - [[Real-Time Analytics]] — low-latency analytical queries on streaming data (Apache Druid, ClickHouse)
  - [[Big Data]] — distributed storage and compute frameworks handling petabyte-scale data volumes
- **Governance and Quality**
  - [[Data Governance]] — policies, standards, and accountability for data assets
  - [[Data Quality Management]] — profiling, cleansing, validation, and monitoring of data accuracy and completeness
  - [[Data Lineage]] — tracking provenance of data from origin through transformations to consumption

### Applications and Use Cases

- **Financial Services** — credit scoring, fraud detection, algorithmic trading, risk modelling, customer lifetime value analysis using [[Machine Learning]] and [[Predictive Analytics]]
- **Healthcare** — patient outcome prediction, clinical trial analysis, genomic data interpretation, population health management
- **Retail and E-commerce** — demand forecasting, recommendation engines, churn prediction, personalisation pipelines
- **Manufacturing** — predictive maintenance using sensor telemetry, supply chain optimisation, quality control analytics
- **Spatial and Extended Reality** — [[Spatial Computing]] applications combining real-time sensor streams with analytics for adaptive environment management; [[Computer Vision]] pipelines feeding into analytics for scene understanding
- **Telecommunications** — network performance analytics, subscriber churn modelling, capacity planning
- **Government and Public Sector** — policy impact evaluation, tax compliance analytics, epidemiological surveillance
- **Marketing** — multi-touch attribution, A/B testing at scale, audience segmentation, customer journey analytics
- **Science and Research** — high-energy physics event selection, genomics pipelines, climate modelling output analysis
- **Federated and Privacy-Preserving Analytics** — applying [[Federated Learning]] and differential privacy to enable analytics across distributed, sensitive data without centralising raw records

### Standards and Context

- **Industry Frameworks**
  - CRISP-DM (Cross-Industry Standard Process for Data Mining) — the dominant lifecycle model for analytics projects, defining phases from business understanding through deployment
  - TDSP (Team Data Science Process) — Microsoft's agile analytics project methodology
  - DMBoK (Data Management Body of Knowledge) — DAMA International's reference framework covering [[Data Governance]], [[Data Quality Management]], and analytics
- **Open Standards and Specifications**
  - SQL:2016 and extensions — the foundational query language for [[Data Warehouse]] and analytical database systems
  - Apache Arrow — columnar in-memory format enabling zero-copy analytics across languages and systems
  - Apache Parquet and ORC — columnar storage formats optimised for analytical workloads on [[Data Lake]] platforms
  - Delta Lake / Apache Iceberg / Apache Hudi — open table formats providing ACID transactions on [[Data Lake]] stores
- **Regulatory Context**
  - GDPR (EU General Data Protection Regulation) — governs how personal data may be collected, processed, and analysed, requiring privacy-by-design in analytics pipelines
  - CCPA (California Consumer Privacy Act) — US state-level analogue imposing data rights constraints on analytics
  - AI Act (EU, 2024) — imposes conformity and transparency requirements on high-risk AI systems, which intersects with [[Predictive Analytics]] models used in consequential decisions
- **Key Organisations**
  - DAMA International — custodian of DMBoK, the professional body for data management and analytics practitioners
  - The Open Group — publishes standards relevant to enterprise data architecture
  - IEEE — standards activity in data provenance, [[Data Quality Management]], and analytics interoperability

### Semantic Classification

### Provenance

