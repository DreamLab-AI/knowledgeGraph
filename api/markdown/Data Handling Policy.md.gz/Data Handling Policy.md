
A data handling policy is a policy governing the processing, storage and transmission of data, declared in the Agent Ontology as the class `DataHandlingPolicy`.[^1] visionGraph places it under [[Data Protection]] and as a part of the [[Execution Context]].

The property `hasDataHandlingPolicy` has the [[Execution Context]] as its domain and the policy as its range, so a policy is attached to the context in which an agent acts rather than to the agent directly. The policy itself carries two datatype properties: `policyURI`, an `xsd:anyURI` pointing to the detailed policy document, and `encryptionRequired`, an `xsd:boolean`. The ontology therefore treats the policy as a short, machine-readable header that signals whether encryption is mandatory and points to the full text elsewhere.

The sibling class `AccessControlRule`, declared in the same module and attached to the execution context through `hasAccessControlRule`, covers permissions for an agent or role to act on a resource; the data handling policy covers how data is treated. For the wider field see [[Data Protection]] and [[Security Binding]].

[^1]: Semantic Agent Communication Community Group, “Security Binding Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/security-binding.ttl

