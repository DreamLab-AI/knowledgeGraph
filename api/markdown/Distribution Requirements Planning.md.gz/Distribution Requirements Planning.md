Distribution requirements planning (DRP) is a management system that plans and controls the distribution of finished goods, with forecasts able to serve as input.[^1][^2]

Oracle's JD Edwards documentation describes DRP as a system that plans and controls the distribution of finished goods based on demand, gives centralised control of distribution inventories and creates a coordinated replenishment plan.[^2] It places DRP beside master production scheduling and material requirements planning as one of the components of material planning operations.[^2]

SAP's documentation for service parts planning describes DRP as organising replenishment planning within bills of distribution. DRP determines the new demands of all locations in the bill of distribution, rounds them, and aggregates them along it to the entry location, and on that basis creates scheduling agreement releases and purchase requisitions.[^3] The same entry mentions a multilevel release process and checks of the planning results, and says further functions such as stability rules and anticipated demand coverage help products to be available at demand and so achieve a high level of service.[^3]

## Scope and distinctions

DRP concerns finished goods in a distribution network, whereas [[Material Requirements Planning]] concerns components for production, as the same JD Edwards overview sets out for MRP: it uses the master production schedule, open orders, the bill of materials and inventory records to calculate time-phased net requirements for every item.[^2] See [[Supply Planning]] and [[Supply Chain Planning]].

## What the sources do not establish

Only vendor documentation was available, from Oracle and SAP, and each describes a product feature rather than a general method. No university or standards source was opened for DRP, so this page is thinly evidenced and does not describe the time-phased calculation in detail.[^1][^3]

[^1]: Oracle, JD Edwards EnterpriseOne Applications Forecast Management documentation, “Distribution Requirements Planning”. https://docs.oracle.com/en/applications/jd-edwards/supply-chain-manufacturing/9.2/eoafm/distribution-requirements-planning.html
[^2]: Oracle, JD Edwards World Material Planning documentation, chapter 1, “1 Overview to Manufacturing and Distribution Planning”. https://docs.oracle.com/cd/E26228_01/doc.93/e21770/ch_over_manf_dist_pln.htm
[^3]: SAP, SAP Library documentation for Service Parts Planning (SCM 7.0 EHP2), “Distribution Requirements Planning (DRP)”. https://help.sap.com/doc/saphelp_scm700_ehp02/7.0.2/en-US/4d/9e3757c2e11162e10000000a42189b/content.htm?no_cache=true

