GDPR Compliance is the totality of organisational, technical, and procedural measures an entity must implement to satisfy obligations under the EU General Data Protection Regulation (Regulation 2016/679), including identifying a lawful basis for each processing activity, fulfilling data subject rights, performing Data Protection Impact Assessments for high-risk processing, notifying supervisory authorities of breaches within 72 hours, and appointing a Data Protection Officer where required. The regulation applies extraterritorially to any organisation processing personal data of EU data subjects regardless of where processing occurs. Compliance programmes encompass privacy-by-design architecture, data minimisation, consent lifecycle management, Records of Processing Activities, demonstrable accountability mechanisms, and contractual safeguards for cross-border data transfers.

### Overview

- GDPR came into force on 25 May 2018, replacing the 1995 Data Protection Directive (95/46/EC) and creating a harmonised framework across EU Member States. Its extraterritorial scope (Article 3) means any organisation worldwide that targets or monitors EU residents must comply, making it effectively a global standard for personal data handling.
- Why it matters:
  - Establishes enforceable rights for individuals over their personal data in the digital economy
  - Creates significant financial penalties — up to €20 million or 4% of global annual turnover (whichever is higher) for serious infringements
  - Acts as a reference model for subsequent privacy legislation including the UK GDPR, Brazil's LGPD, India's DPDP Act, and aspects of the [[AI Act Compliance]] regime
  - Shapes how AI systems are trained, deployed, and audited, particularly where personal data is used in model development
- How it works:
  - Organisations identify and document every processing activity in a [[Record of Processing Activities]] (RoPA)
  - A lawful basis from Article 6 must be identified for each activity: consent, contract, legal obligation, vital interests, public task, or [[Legitimate Interests]]
  - Special category data (health, biometrics, religion, etc.) requires an additional condition from Article 9
  - [[Supervisory Authority|Supervisory Authorities]] (e.g., the ICO in the UK, CNIL in France) investigate complaints and impose sanctions
  - [[Data Protection Officer]]s are mandatory for public authorities, processors handling large-scale systematic monitoring, and processors of special-category data at scale

### Key Components

- **Lawful Basis for Processing** — every processing activity must map to one of six lawful bases; organisations must document the chosen basis in the RoPA
- **[[Data Subject Rights]]** — eight core rights: access (Article 15), rectification (Article 16), erasure (Article 17, "right to be forgotten"), restriction of processing (Article 18), portability (Article 20), objection (Article 21), rights related to automated decision-making and profiling (Articles 21-22)
- **[[Consent Management]]** — where consent is the lawful basis, it must be freely given, specific, informed, and unambiguous; withdrawal must be as easy as giving consent; Consent Management Platforms (CMPs) implement cookie banners and preference centres
- **[[Privacy By Design]]** — Article 25 mandates data-protection-by-design and by-default: systems must minimise data collection and processing scope at the architecture level, not as an afterthought
- **[[Data Minimisation]]** — only personal data that is adequate, relevant, and limited to what is necessary for the stated purpose may be collected
- **[[Data Protection Impact Assessment]]** — mandatory for processing likely to result in high risk to individuals (e.g., large-scale profiling, systematic monitoring of public areas, processing of special-category data at scale)
- **[[Data Breach Notification]]** — breaches posing a risk to individuals must be reported to the [[Supervisory Authority]] within 72 hours of becoming aware; individuals must be notified without undue delay where the risk is high
- **[[Data Protection Officer]]** — independent role responsible for monitoring compliance, advising on DPIAs, and acting as contact point for supervisory authorities
- **[[Cross-Border Data Transfer]]** — transfers outside the EEA require an adequacy decision, Standard Contractual Clauses (SCCs), Binding Corporate Rules (BCRs), or another lawful transfer mechanism; the 2023 EU-US Data Privacy Framework replaced the invalidated Privacy Shield
- **[[Record of Processing Activities]]** — documented inventory of all processing activities, mandatory for organisations with 250+ employees or those processing high-risk or special-category data
- **[[Accountability Framework]]** — Article 5(2) requires controllers to be able to demonstrate compliance; this drives audit trails, governance policies, staff training, and vendor management

### Applications and Use Cases

- **Enterprise Data Governance** — multinational companies implement GDPR compliance programmes integrating [[Data Governance]] platforms, automated consent workflows, and cross-border transfer mechanisms across operating subsidiaries
- **AI and Machine Learning** — training datasets containing personal data must have a lawful basis; models performing automated profiling or decisions with legal or significant effects require human oversight provisions under Article 22; [[Federated Learning]] and [[Differential Privacy]] are used to derive analytical value while limiting personal data exposure
- **Healthcare and Clinical Research** — health data is special-category; clinical trial sponsors rely on Article 9(2)(j) (scientific research) combined with appropriate safeguards; pseudonymisation and anonymisation strategies reduce processing scope
- **E-Commerce and AdTech** — cookie consent, programmatic advertising, and behavioural tracking are primary GDPR battlegrounds; [[Consent Management]] Platforms implement the IAB Transparency and Consent Framework (TCF) to propagate consent signals across ad-tech stacks
- **SaaS Platforms and Cloud Services** — cloud providers act as data processors; Data Processing Agreements (DPAs) under Article 28 govern processor obligations; sub-processor chains require documented approval
- **HR and Employee Data** — employee monitoring, recruitment data, and payroll processing all engage GDPR; [[Legitimate Interests]] and contract are common lawful bases; works councils may have co-determination rights in some Member States
- **Public Sector** — government bodies and public authorities are controllers; DPOs are mandatory; public task (Article 6(1)(e)) is the primary lawful basis for most governmental processing
- **[[Spatial Computing]] and Wearables** — biometric data from AR/VR headsets and location tracking constitute special-category or highly sensitive data; GDPR compliance shapes sensor data architectures and retention policies

### Standards and Regulatory Context

- **Regulation (EU) 2016/679** — the primary legal instrument; directly applicable across all EU Member States without need for national transposition
- **UK GDPR** — retained in UK law post-Brexit via the European Union (Withdrawal) Act 2018; administered by the Information Commissioner's Office (ICO); divergence from EU GDPR is a growing compliance consideration
- **ePrivacy Directive (2002/58/EC, amended 2009)** — governs electronic communications and cookie consent; interacts with GDPR on consent requirements for cookies and similar tracking technologies; a proposed ePrivacy Regulation has not yet been finalised
- **EU-US Data Privacy Framework (2023)** — adequacy decision enabling transfers from the EU to US-certified organisations; replaces Privacy Shield (invalidated in Schrems II, 2020)
- **Standard Contractual Clauses (SCCs, 2021 revision)** — the most widely used mechanism for third-country data transfers; modular structure covers controller-to-controller, controller-to-processor, and processor-to-processor arrangements
- **EDPB Guidelines** — the European Data Protection Board issues binding decisions and non-binding guidelines on topics including consent, data transfers, profiling, and DPIA lists
- **ISO/IEC 27701:2019** — Privacy Information Management System standard; provides a framework extending ISO 27001 to support GDPR compliance demonstration
- **NIST Privacy Framework** — US reference framework increasingly adopted alongside GDPR programmes for multinational organisations managing cross-jurisdictional obligations
- **[[AI Act Compliance]]** — the EU AI Act (entered into force August 2024) layers additional obligations on top of GDPR for AI systems processing personal data, particularly regarding high-risk AI systems; GDPR DPIAs and AI Act Fundamental Rights Impact Assessments are converging compliance instruments

### Provenance

