Call Centres (contact centres — the operationally preferred modern term reflecting multichannel reality) are coordinated operational environments in which human agents and increasingly autonomous AI Agents handle inbound and outbound customer communications across voice, chat, email, social m...

### Semantic Classification

- **domain-correction:** infrastructure -> artificial-intelligence (original stub misassigned to infrastructure domain; corrected at enrichment 2026-05-17; IRI and URI updated accordingly)

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:hasPart ai:InteractiveVoiceResponse))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:hasPart ai:AgentAssist))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:hasPart ai:WorkforceManagement))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:hasPart ai:QualityAssurance))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:hasPart ai:OmnichannelRouter))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:hasPart ai:SentimentAnalysis))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:hasPart ai:RealTimeTranscription))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:hasPart ai:KnowledgeBase))

    ## Dependency Relationships
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:requires ai:NaturalLanguageProcessing))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:requires ai:SpeechRecognition))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:requires ai:LargeLanguageModels))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:requires ai:IntentClassification))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:requires ai:CustomerIdentityVerification))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:dependsOn ai:CloudInfrastructure))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:dependsOn ai:TelephonyInfrastructure))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:dependsOn ai:TransformerArchitecture))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:dependsOn ai:DialogueStateTracking))

    ## Capability Relationships
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:enables ai:Tier1ContactDeflection))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:enables ai:AgentProductivityAugmentation))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:enables ai:AutomatedQualityMonitoring))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:enables ai:WorkforceSchedulingOptimisation))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:enables ai:ProactiveCustomerOutreach))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:supports ai:FirstContactResolution))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:supports ai:AverageHandleTimeReduction))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:supports ai:CSATImprovement))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:supports ai:ComplianceMonitoring))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:supports ai:CustomerExperience))

    ## Implementation Relationships
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:implements ai:ConversationalAI))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:implements ai:SentimentAnalysis))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:implements ai:WorkforceManagement))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:implements ai:OmnichannelRouting))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:implements ai:AIAgents))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:uses ai:Chatbots))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:uses ai:RealTimeTranscription))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:uses ai:CRM))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:uses ai:RoboticProcessAutomation))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:uses ai:BiometricAuthentication))

    ## Reduction Relationships
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:reduces ai:ManualCallHandlingVolume))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:reduces ai:AverageHandleTime))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:reduces ai:AgentAttritionRisk))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:reduces ai:OperationalCost))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:reduces ai:QualityAuditSamplingBias))
    SubClassOf(ai:CallCentres
      ObjectSomeValuesFrom(ai:reduces ai:CustomerWaitTime))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ai:hasIdentifier ai:CallCentres "AI-2041"^^xsd:string)
    DataPropertyAssertion(ai:authorityScore ai:CallCentres "0.87"^^xsd:decimal)
    DataPropertyAssertion(ai:ccaasMarketValueUSD2025 ai:CallCentres "7250000000"^^xsd:integer)
    DataPropertyAssertion(ai:tier1DeflectionRateHigh ai:CallCentres "0.70"^^xsd:decimal)
    DataPropertyAssertion(ai:tier1DeflectionRateLow ai:CallCentres "0.55"^^xsd:decimal)
    DataPropertyAssertion(ai:enterpriseAIChatbotAdoption2025 ai:CallCentres "0.67"^^xsd:decimal)
    DataPropertyAssertion(ai:qaInteractionCoverage ai:CallCentres "1.00"^^xsd:decimal)

    ## Property Characteristics
    AsymmetricObjectProperty(ai:requires)
    AsymmetricObjectProperty(ai:enables)
    AsymmetricObjectProperty(ai:implements)
    AsymmetricObjectProperty(ai:reduces)
    TransitiveObjectProperty(ai:dependsOn)
    FunctionalDataProperty(ai:ccaasMarketValueUSD2025)
    FunctionalDataProperty(ai:tier1DeflectionRateHigh)

    ## Annotations
    AnnotationAssertion(rdfs:label ai:CallCentres "Call Centres"@en)
    AnnotationAssertion(rdfs:comment ai:CallCentres "AI-augmented customer contact environments deploying conversational virtual agents (55-70% tier-1 deflection), real-time agent-assist overlays, automated QA across 100% of interactions, and AI workforce management; CCaaS market USD 7.25B in 2025, forecast USD 29.5B by 2033; major platforms: Genesys, NICE, Five9, Amazon Connect, Salesforce Service Cloud; UK sector employment forecast to fall 34% 2024-2028."@en)
    AnnotationAssertion(dcterms:identifier ai:CallCentres "AI-2041"^^xsd:string)
    AnnotationAssertion(dcterms:subject ai:CallCentres "Conversational AI, Customer Service, Workforce Management, Omnichannel, Contact Centre, CCaaS"@en)
  )

## About Call Centres

- **Call Centres** (contact centres — the operationally preferred modern term reflecting multichannel reality) are the primary organisational unit through which large enterprises and public-sector bodies manage high-volume customer communication at scale.
- The sector is a bellwether for enterprise [[Artificial Intelligence]] adoption: its cost structure (labour typically 60–75% of total operating cost), its reliance on routine [[Natural Language Processing]], and its real-time SLA pressure create near-ideal conditions for AI automation, making call centres the first sector in which autonomous [[AI Agents]] are being deployed at scale to replace rather than merely assist human workers across well-defined task classes.
- The historical arc of the call centre as an institutional form spans four decades:
  - **1980s–1990s**: emergence of the call centre as a distinct organisational form, enabled by automatic call distribution (ACD) switching and the economics of geographic concentration; first wave of centralisation and offshoring of customer service functions
  - **1990s–2000s**: first-generation [[Interactive Voice Response]] deployment (DTMF menu trees); offshore growth in India, Philippines; workforce management systems for scheduling optimisation; early CRM integration
  - **2000s–2010s**: multichannel expansion (email, web chat, social media); workforce optimisation suites (NICE, Verint, Aspect); first-generation speech analytics on sampled call recordings; UK offshore backlash and reshoring trend
  - **2010s–2020s**: cloud migration to CCaaS platforms; first-generation virtual agents (rule-based chatbots); mobile and digital-first channel growth; initial NLP-based intent classification tools replacing DTMF IVR menus
  - **2020s–present**: [[Large Language Model]] transformation; generative AI agent assist; 100% interaction QA automation; agentic AI for autonomous contact resolution; contact-centre AI as a primary enterprise AI investment priority
- Three forces are converging to accelerate AI transformation of the sector:
  - **LLM maturation**: [[Large Language Model]] have reached production-quality natural language understanding, making zero-shot and few-shot intent handling viable without the brittle NLU training pipelines that plagued earlier virtual-agent deployments, which typically required 50–100 labelled examples per intent and failed on paraphrase variation
  - **CCaaS infrastructure shift**: migration to cloud-native Contact Centre as a Service platforms has removed the on-premises infrastructure barrier; CCaaS enables rapid iteration of AI features via software updates rather than hardware procurement cycles, compressing deployment timelines from 18–24 months to 3–6 months
  - **Labour cost pressure**: post-COVID volume shocks, persistent agent attrition (industry annual turnover rates of 30–45% in the UK; 45–60% in US), and rising minimum wages (UK National Living Wage £11.44/hour from April 2024) have created executive urgency to reduce the human labour denominator and reduce dependency on volatile and costly labour markets
- The operational KPI landscape that call centres optimise against is directly amenable to AI improvement:
  - **First Contact Resolution (FCR)**: percentage of contacts resolved without requiring a follow-up; industry benchmark 70–75% FCR for well-managed operations; AI [[Agent Assist]] and knowledge retrieval improve FCR by ensuring agents have accurate information at point of need; virtual agents in self-service improve FCR for tier-1 intents by eliminating misrouting
  - **Average Handle Time (AHT)**: average duration of a customer interaction including after-call work (ACW); industry benchmark varies by contact type (2–4 minutes for simple transactions, 8–15 minutes for complex cases); [[Agent Assist]] tools reduce AHT 10–20% by surfacing responses and automating post-call summaries; automated ACW (AI-generated call summary and CRM update) eliminates 1–3 minutes of after-call data entry
  - **Average Speed to Answer (ASA)**: customer wait time before connection to agent or virtual agent; traditional benchmark 20–30 seconds for telephone, immediately for chat; virtual agents resolve ASA to near-zero for self-service contacts; intelligent routing reduces queue time for human-agent contacts by optimising agent assignment; Canada Life AWS Connect migration: 92% ASA reduction to 18 seconds
  - **Customer Satisfaction Score (CSAT)**: survey-based satisfaction metric (typically 1–5 scale, percentage rating 4–5); Zendesk 2025 CX Trends: 18% average CSAT improvement within 90 days of deploying tier-1 AI deflection; improvements driven by reduced wait times, more consistent responses, and 24/7 availability
  - **Net Promoter Score (NPS)**: loyalty indicator (-100 to +100); improves with reduced friction, faster resolution, and proactive service; financial services contact centres using AI QA for consistent fair customer outcomes show NPS improvements of 8–15 points in early data
  - **Agent Utilisation and Schedule Adherence**: AI [[Workforce Management]] recovers 4–5 FTE equivalents per 100 agents by reducing schedule shrinkage from 28% to 20%; improved utilisation reduces unit cost per contact; improved adherence reduces SLA breaches
  - **Abandon Rate**: percentage of callers hanging up before connection (telephone) or abandoning self-service chat; industry benchmark 5–8% for telephone; reduced by virtual-agent self-service availability, proactive callback offers, and intelligent queue management
  - **Cost Per Contact**: total operating cost divided by contact volume; primary executive metric; ranges from £2–8 for fully human-handled voice contacts to £0.10–0.50 for AI-handled self-service contacts; AI transformation ROI is primarily realised through cost-per-contact reduction as mix shifts toward self-service
- The sector's transformation has a significant ethical and social dimension distinct from most enterprise AI adoption:
  - Call-centre employment in the UK is disproportionately located in post-industrial regions (Manchester, Leeds, Sheffield, Newcastle, Glasgow, South Wales) where it represents accessible entry-level employment for populations with limited alternative high-wage options
  - The sector has historically provided the primary employment pathway for women returners, school leavers without degrees, and new immigrant communities in these regions — all groups disproportionately exposed to displacement without accessible reskilling alternatives
  - AI automation at scale — not just augmentation — is now clearly occurring: IBISWorld forecasts 34% UK sector employment decline 2024–2028; Klarna's 700-agent-equivalent AI deployment and BT's 55,000 workforce reduction (AI as a stated driver) represent the enterprise scale of displacement already underway
  - The distributional consequences of this automation (geographically concentrated job losses; productivity gains accruing to technology vendors and enterprise shareholders; reskilling access unevenly distributed by geography and prior educational attainment) are matters of active parliamentary and policy concern

## Components and Architecture

### Conversational Virtual Agents (CVAs)

- CVAs form the self-service deflection layer. Modern deployments use [[Large Language Model]] (GPT-4o class or fine-tuned open-weights equivalents — Llama-3, Mistral, Gemma) orchestrated via agentic frameworks with tool-use access to [[CRM]] systems, knowledge bases, order management APIs, and identity verification services
- The CVA interaction lifecycle: receive utterance → classify intent via [[Intent Classification]] → retrieve relevant context from connected systems → generate response via [[Large Language Model]] → resolve or hand off to human agent with full context transfer
- Containment rates (contacts resolved end-to-end without human involvement) of 55–70% for tier-1 intents are achievable in 2025–2026 deployments; leaders reach 80–90% on highly-constrained domains (Builts AI 2026)
- Key design failure modes: containment loops (customers cycling through IVR unable to escape), intent misclassification causing misrouted handoffs, context loss on transfer to human agent, and over-automation of emotionally charged contacts requiring human empathy
- Vendor platforms: [[Genesys]] Dialog Engine, [[NICE]] Enlighten Autopilot, [[Five9]] Intelligent Virtual Agent, [[Amazon Connect]] with Amazon Lex, [[Salesforce]] Agentforce, Cognigy.AI, Google Contact Center AI, Nuance/Microsoft Azure AI

### Interactive Voice Response and LLM Migration

- Traditional [[Interactive Voice Response]] systems use DTMF touch-tone keypresses or limited [[Automatic Speech Recognition]] against narrow intent grammars; structural limitation is coverage: they handle only intents their designers anticipated
- LLM-based conversational IVR handles arbitrary natural-language input, maintains multi-turn dialogue state, interprets non-standard phrasings, and disambiguates intent via follow-up clarification — a categorical capability upgrade over DTMF trees
- AWS provides automated IVR-to-Amazon-Connect migration tooling that parses legacy call-flow XML/JSON and generates equivalent LLM-enabled flows, reducing migration timelines from months to weeks; Amazon Lex invokes [[Amazon Bedrock]] foundation models for generative contextual replies
- Canada Life (21 business units, 7-month migration): 94% reduction in customer wait time; 92% reduction in average speed to answer (to 18 seconds); 10% average handle time reduction; AI capabilities deployed included chatbots, call summarisation, voice-to-text, automated authentication, and proficiency-based routing
- LLM-based Voice AI systems move beyond intent detection toward goal-driven conversations — maintaining context, reasoning across multiple steps, and responding with more natural, expressive [[Text-to-Speech]] synthesis

### Real-Time Agent Assist

- [[Agent Assist]] systems overlay real-time [[Real-time Transcription]] (ASR running simultaneously on agent and customer audio streams) with [[Large Language Model]] inference to generate in-the-moment support:
  - Suggested next responses or knowledge-base snippets relevant to the current conversation context
  - Compliance checklist reminders (PCI DSS card-data handling, FCA required disclosures, GDPR data-processing notifications)
  - Automated after-call work (ACW) summaries generated from transcripts, eliminating manual note-taking
  - Sentiment trajectory alerts when customer frustration crosses a threshold, prompting supervisor intervention
  - Next-best-action recommendations drawing on [[CRM]] history and current interaction context
- Key performance data: Five9 Genius AI agent-assist (2024): 17% AHT reduction, 13% productivity gain; Zendesk 2025 CX Trends: 45% operating cost reduction reported by organisations using AI agents
- Latency is the critical engineering constraint: sub-500ms suggestions require smaller, faster models; sub-200ms is achievable with on-premise inference or edge deployment using quantised models
- Vendor platforms: Five9 Genius AI, Balto (real-time guidance), Convin.ai, Dialpad AI (real-time transcription + virtual coach), Talkdesk AI for Agents, Cresta (automated quality monitoring), AWS Live Call Analytics

### Sentiment Analysis and Emotion AI

- [[Sentiment Analysis]] in call centres operates on dual-channel audio (agent and customer streams analysed independently) combined with ASR transcripts, enabling:
  - Real-time frustration detection triggering supervisor alert or priority re-routing
  - Automated emotion scoring across fine-grained dimensions: frustration, confusion, joy, anger, resignation, satisfaction (beyond binary positive/negative)
  - Post-call sentiment trend analysis for coaching prioritisation and product/service issue identification
  - Customer-at-risk identification for proactive retention outreach
- Accuracy characteristics: domain-tuned models on contact-centre speech achieve 85–92% accuracy for major emotion classes when trained on representative corpora; accuracy degrades 15–25 percentage points for non-native English speakers and strong regional accents — a material equity concern for UK deployments serving diverse urban populations
- The transcript-accuracy dependency is critical: even small [[Automatic Speech Recognition]] errors compound across downstream [[Sentiment Analysis]] and compliance-flagging tasks; domain-specific ASR fine-tuning on industry vocabulary is a prerequisite
- Vendor platforms: Observe.AI, Level AI (fine-grained emotion detection), CallMiner Eureka, Verint [[Speech Recognition]] Analytics, Sybill.ai, Qualtrics XM

### Automated Quality Assurance

- Traditional QA samples fewer than 2% of interactions for manual review (industry benchmark, Gryphon.ai 2024), creating: statistical sampling bias; supervisory blind spots on systematic compliance failures; inability to provide data-driven individual coaching; and inadequate audit trails for regulatory reporting
- AI QA evaluates 100% of contacts using automated scorecards across: compliance adherence (required disclosures, prohibited phrases, data handling), script adherence, empathy expression, first-contact resolution indicators, and [[Sentiment Analysis]] trajectory
- FCA Consumer Duty (effective July 2023–2024) requires firms to demonstrate systematic monitoring of fair customer outcomes across all interactions — random 2% sampling cannot satisfy this obligation; AI QA at 100% coverage is the regulatory-compliant solution
- Outputs feed: agent coaching queues ranked by performance gap; compliance audit trails for regulatory reporting; product/service improvement analytics from systemic issue detection; and executive dashboards on quality trend
- Vendor platforms: Observe.AI, Level AI, CallMiner Eureka, Verint, Qualtrics XM, NICE Enlighten QA, Cresta Automated QA

### Workforce Management (WFM)

- [[Workforce Management]] systems in contact centres perform: contact volume forecasting (historically to 30-minute intervals, now to 15-minute with AI); shift schedule generation; real-time adherence monitoring; intraday reforecasting; and agent self-service for schedule changes
- AI-driven WFM platforms use machine learning on historical volume patterns, promotional calendars, weather signals, macroeconomic indicators, and NPS/CSAT trends to improve forecast accuracy beyond traditional Erlang-C queue-theoretic models
- Verint's TimeFlex bot enables agents to make unlimited schedule swaps without supervisor approval, using optimisation algorithms to balance individual flexibility against operational coverage constraints — addressing the high-attrition problem by improving work-life balance
- A 2024 Call-Centre-Helper industry study found AI-enhanced WFM reduced shrinkage (unplanned absence + breaks + training time as percentage of scheduled hours) from 28% to 20%, recovering the equivalent of 4–5 FTE per 100 agents — a significant ROI driver independent of deflection savings
- In 2025, 98% of contact centres have embedded AI somewhere in their operating model; 61% of leaders report conversations are getting harder because the human capability layer has not kept pace with AI deployment (CX Today / Verint 2025)
- Vendor platforms: [[Genesys]] Cloud WFM, Verint TimeFlex, Calabrio, NICE WFM, Aspect (Alvaria), Assembled

### Omnichannel Routing and Orchestration

- [[Omnichannel]] routing unifies contact handling across voice, webchat, email, SMS, WhatsApp, social media DMs, video, and asynchronous messaging under a single agent desktop and unified queue management system
- Routing decision factors: predicted handle time; agent skills scores; customer lifetime value; previous interaction [[Sentiment Analysis]]; current wait time; channel preference history; LLM-classified intent; and SLA priority
- The top five CCaaS vendors control 61% of enterprise market share as of 2024: Five9 (16%), Genesys (13%), NICE, Salesforce, Amazon Connect making up the remainder; 44% of all vendors added generative AI features in 2024
- Channel preference data: 55% of new CCaaS deployments in 2025 integrate AI-powered analytics and chatbots natively; 57% of CCaaS users added omnichannel support since 2023
- Vendor platforms: [[Genesys]] Cloud CX, [[NICE]] CXone, [[Five9]] Intelligent Cloud, [[Amazon Connect]], [[Salesforce]] Service Cloud, Talkdesk, 8x8, RingCentral, Avaya OneCloud

### Agentic AI and Autonomous Resolution

- Beyond scripted virtual agents, [[AI Agents]] in contact centres are increasingly goal-driven rather than intent-driven: they maintain multi-turn dialogue state, reason across retrieved context, make decisions within defined guardrails (refund authorisation up to threshold, appointment rescheduling, complaint escalation), and invoke backend APIs autonomously
- Autonomy level frameworks (analogous to SAE self-driving levels 0–5) categorise contact-centre AI from Level 1 (decision support only, human always acts) through Level 5 (full autonomous resolution of knowledge-work tasks with minimal human intervention); most production deployments sit at Level 2–3 with Level 4 emerging for high-volume, low-risk transaction types
- Agentic system types in deployment:
  - **Conversational assistants**: natural-language dialogue handling routine enquiries (account information, order tracking, appointment booking) — Level 2–3 autonomy
  - **AI supervisors**: monitor interactions, analyse [[Sentiment Analysis]], escalate to human supervisors automatically — Level 2
  - **Smart transfer bots**: classify contact intent and route to optimal resource (human or specialist AI) — Level 2
  - **Autonomous transaction agents**: complete end-to-end transactions (cancellation + refund, booking + confirmation, account changes + notification) without human involvement — Level 3–4
  - **Fraud monitoring systems**: real-time voice biometric monitoring and anomalous behaviour flagging during live interactions — Level 3
- Key vendor agentic AI platforms (2025–2026): Salesforce Agentforce, Google CCAI Agent Assist, NICE Enlighten Autopilot, Cognigy.AI, Zoom AI Companion for Contact Center, Microsoft Copilot for Customer Service

## Use Cases and Major Families

### Tier-1 Contact Deflection and Self-Service

- FAQ resolution (account balance, order status, store hours, password reset, policy queries, product information) handled entirely by [[Conversational AI]] virtual agents without human involvement
- 24/7/365 availability — eliminates time-zone and out-of-hours constraints on service access; particularly valuable for retail, utilities, and financial services customers expecting instant access
- Sub-2-second response time vs 4–8 minute average queue wait for human-agent contacts; CSAT impact is significant as wait time is the primary driver of customer frustration
- Direct ROI calculation: deflecting one voice contact saves £4–12 in human agent cost (labour + overhead + technology); deflecting 1M contacts annually saves £4M–£12M; break-even on a well-configured deployment typically 6–18 months
- Containment ceiling: not all contacts can or should be self-served; emotionally charged interactions (bereavement, financial hardship, serious complaints), complex multi-system queries, and contacts requiring professional judgement require human handling; mature deployments accept 55–70% deflection as the realistic ceiling for broad-scope deployments

### IVR Modernisation

- Replacing DTMF-tree [[Interactive Voice Response]] with LLM-powered conversational front-ends; removes the constraint that only pre-anticipated intents can be handled
- One Teneo.AI deployment reported 42% reduction in misdirected calls and USD 6M annual savings from routing accuracy improvement alone
- Canada Life AWS Connect migration: 94% wait-time reduction, 92% speed-to-answer reduction to 18 seconds, 10% AHT reduction across 21 business units
- Migration approach: AWS tooling auto-converts legacy IVR call-flow scripts to Amazon Lex equivalents, reducing custom development work; full migration of a 1,000-flow IVR takes 3–6 months with automated tooling vs 12–18 months of manual redevelopment
- Multilingual capability: LLM-based IVR handles caller language selection naturally (by speaking) rather than through menu option; enables automatic language routing without DTMF prompt overhead

### Agent Assist and Real-Time Augmentation

- Real-time [[Real-time Transcription]] on both audio streams combined with [[Large Language Model]] inference to generate in-the-moment support for human agents
- Knowledge retrieval: AI surfaces relevant knowledge-base articles, policy documents, and precedent cases based on real-time conversation context, eliminating manual searching that disrupts call flow
- Next-best-action suggestions: AI recommends resolution options (refund, credit, escalation, alternative product) based on conversation context, customer history from [[CRM]], and similar resolved cases
- Compliance automation: PCI DSS card data handling reminders surfaced when customer begins reading card numbers; FCA required disclosure prompts triggered by regulatory keywords; GDPR consent capture guidance for new data collection
- Automated ACW: AI-generated call summary and [[CRM]] update eliminates 1–3 minutes of after-call data entry per contact; for a 200-agent centre handling 1,000 calls/day each, this is 200–600 agent-hours recovered daily
- New agent ramp-up acceleration: AI effectively compresses the learning curve by surfacing institutional knowledge at point of need; new agents with AI assist perform at 70–80% of experienced agent level from week one vs 12–16 weeks previously
- Five9 Genius AI (2024): 17% AHT reduction; 13% agent productivity gain; Brynjolfsson et al. natural field experiment: 14% productivity gain, largest gains among novice agents

### Automated Quality Assurance and Compliance Monitoring

- 100% interaction coverage replacing 2% manual sampling — the standard prior to AI QA; sampling bias in 2% reviews systematically misses tail risks and atypical agent behaviours
- Automated scorecard dimensions: script adherence (did agent follow required process?); empathy expression (did agent acknowledge customer emotion?); resolution quality (was contact resolved?); prohibited phrase detection (did agent make unauthorised statements?); required disclosure verification (did agent deliver all mandatory information?)
- Coaching queue generation: AI prioritises coaching opportunities by performance gap size, frequency of similar errors, and likely CSAT impact — enabling supervisors to spend coaching time on highest-ROI interventions
- FCA Consumer Duty compliance: the obligation to demonstrate systematic monitoring of fair customer outcomes across all interactions requires 100% coverage; AI QA is the only scalable means of achieving this at contact-centre volume
- Systemic issue detection: AI QA across 100% of interactions identifies systematic problems (product misinformation being given by all agents, a common customer objection not addressed in scripts, a compliance error pattern) that 2% sampling would take months to detect statistically

### Workforce Management and Scheduling Optimisation

- AI volume forecasting at 15-minute interval granularity, trained on historical contact patterns, marketing calendar, external event data (weather, economic announcements), and real-time queue conditions
- Intraday reforecasting: AI continuously updates volume forecasts during the operating day and recommends staffing adjustments; enables contact-centre managers to respond to unexpected volume spikes or drops without manual re-analysis
- Agent self-service scheduling: AI-powered swap and change platforms (Verint TimeFlex) enable agents to modify schedules within operational constraints without supervisor approval; addresses the top attrition driver (schedule inflexibility) while maintaining coverage
- WFM ROI: Call-Centre-Helper 2024 study: shrinkage reduction from 28% to 20% = 4–5 FTE equivalents recovered per 100 agents; at £25,000 average agent cost, this is £100,000–£125,000 annual savings per 100 agents from WFM alone, independent of deflection savings

### Sentiment-Driven Escalation and Vulnerable Customer Management

- Real-time [[Sentiment Analysis]] triggers automatic supervisory alerts when customer frustration, distress, or vulnerability signals exceed threshold — enabling supervisor to silently join call or barge in
- FCA Consumer Duty vulnerable customer obligation: firms must identify and appropriately support vulnerable customers (those with health conditions, bereavement, financial difficulty, communication needs); AI [[Sentiment Analysis]] is the only scalable means of identifying vulnerability signals across 100% of contacts
- Escalation routing: contacts where AI [[Sentiment Analysis]] detects high frustration or vulnerability can be automatically re-routed to senior or specialist agents trained in vulnerable customer handling without explicit customer request
- Post-call flagging: AI identifies calls warranting supervisory follow-up, regulatory investigation, or customer callback for service recovery — enabling proactive complaint prevention rather than reactive complaint handling

### Voice Biometric Authentication and Fraud Prevention

- Passive voice biometric authentication during natural conversation eliminates knowledge-based authentication (KBA) — mother's maiden name, memorable word, date of birth — which is trivially defeated by social engineering, data breaches, and dark-web credential markets
- Voiceprint established in 15–30 seconds of natural speech; authentication is transparent to the customer and does not interrupt the service interaction
- Real-time fraud detection: anomalous voice characteristics (synthetic TTS patterns, pitch-shifted recordings, background noise inconsistent with claimed environment) trigger authentication failure or supervisory alert
- Vendor landscape: Pindrop (passive voice biometric + deepfake detection); Nuance Gatekeeper (Microsoft acquisition); NICE Verify; Aculab VeriCall
- UK financial services adoption: major UK retail banks (Barclays, HSBC, Lloyds) have deployed passive voice biometrics for telephone banking authentication; HMRC deployed voice biometric authentication for self-assessment telephone line

### Predictive Analytics and Proactive Customer Outreach

- AI analysis of [[CRM]] data, interaction history, product usage patterns, and external signals (smart meter readings, transaction monitoring) to predict customer intent before contact occurs
- Proactive outreach: contacting customers with relevant information before they need to call; utilities smart meter anomaly detection triggers proactive call about estimated bill; mortgage approaching end-of-term triggers renewal outreach; insurance policy renewal approaching triggers proactive retention call
- Intent prediction: AI model identifies customers statistically likely to call in the next 24–48 hours based on account state, recent events, and historical call trigger patterns; enables proactive resolution before the inbound call occurs
- Revenue impact: proactive outreach converts contact-centre from pure cost centre (reactive) to revenue contributor (proactive retention, cross-sell, upsell) — changes the internal economic framing of the function

## Key Players and Platform Ecosystem

- The contact-centre AI market is served by a layered ecosystem of full-suite CCaaS platforms, specialist AI overlay vendors, and cloud-native AI service providers. Understanding the vendor landscape requires distinguishing between: full-suite CCaaS providers that include AI features; specialist AI-only vendors that integrate with existing CCaaS platforms; and cloud hyperscaler AI services that provide foundation-model APIs consumed by both categories.

### Full-Suite CCaaS Platforms

- **[[Genesys]]** (Genesys Cloud CX): Largest pure-play CCaaS vendor; 8,000+ customers; Genesys AI includes: Genesys Dialog Engine (virtual agents), Genesys Predictive Routing (ML-based skills matching), Genesys Workforce Engagement Management (AI forecasting and scheduling), Genesys Copilot (LLM-powered agent assist with real-time suggestions and summarisation), Genesys Cloud Quality Assurance (automated scoring); acquired Bold360 (conversation intelligence) 2021; 13% CCaaS market share (2024); strong in financial services, government, and healthcare verticals
- **[[NICE]]** (NICE CXone): Workforce optimisation heritage (Verint competitor pre-2022); NICE Enlighten AI suite covers: Enlighten Autopilot (autonomous virtual agent), Enlighten Copilot (agent assist), Enlighten AutoSummary (post-call summarisation), Enlighten QA (automated quality scoring), Enlighten Workforce Management; acquired Mattersight (behavioural analytics) 2018; known for advanced [[Sentiment Analysis]] and compliance monitoring; strong in regulated industries
- **[[Five9]]** (Five9 Intelligent Cloud Contact Center): 3,000+ enterprise customers; Five9 Genius AI suite: Intelligent Virtual Agent (IVA), Agent Assist with real-time guidance, Workflow Automation, GenAI Studio for building LLM-powered flows; 16% CCaaS market share (largest among top five, 2024); 2024 Genius AI agent-assist deployment data: 17% AHT reduction, 13% productivity gain
- **[[Amazon Connect]]** (AWS): Cloud-native CCaaS launched 2017; native integration with Amazon Lex ([[Conversational AI]]), Amazon Transcribe ([[Speech Recognition]]), Amazon Comprehend ([[Sentiment Analysis]]), and Amazon Bedrock ([[Large Language Model]] including Claude); Contact Lens for real-time analytics; key differentiator: consumption-based pricing (pay per minute) vs seat-based licensing; Canada Life case study demonstrates migration from legacy IVR at scale; 25,000+ customers globally
- **[[Salesforce]] Service Cloud**: [[CRM]]-native contact centre integrating natively with Salesforce Einstein AI and Agentforce autonomous agent platform; strength is unified [[CRM]] and contact-centre data model enabling contextually-aware AI responses drawing on full customer history; Salesforce Agentforce represents the vendor's agentic AI push (2025); weak on telephony infrastructure relative to pure-play CCaaS vendors; strong in sales-adjacent customer service
- **Talkdesk**: Pure-play CCaaS with Talkdesk AI for healthcare, financial services, and retail; Talkdesk Autopilot (virtual agent), Talkdesk Copilot (agent assist), automated QA; strong HIPAA-compliant healthcare contact-centre offering
- **8x8 and RingCentral**: UCaaS (Unified Communications as a Service) vendors with embedded CCaaS; 8x8 Contact Center with conversation intelligence; RingCentral Contact Center with AI analytics; strength in SME and mid-market segments

### Specialist AI Overlay and Enhancement Vendors

- **Observe.AI**: AI quality assurance and agent coaching specialist; evaluates 100% of interactions against configurable scorecards; real-time agent guidance; automated compliance violation detection; strong in financial services and BPO (Business Process Outsourcing) clients
- **Balto**: Real-time call guidance specialist; delivers in-the-moment coaching based on conversation analysis; compliance checklist automation; manager real-time monitoring dashboard; positioned as the agent-assist layer for contact centres that do not have full CCaaS AI suites
- **Convin.ai**: Conversation intelligence platform; real-time [[Real-time Transcription]] and analysis; agent performance analytics; [[Sentiment Analysis]]; coaching automation; strong in mid-market and emerging market deployments
- **CallMiner Eureka**: Interaction analytics specialist; speech analytics on 100% of recorded calls; [[Sentiment Analysis]]; trend detection; compliance monitoring; customer journey analysis; one of the longest-established vendors in the space
- **Cognigy.AI**: Enterprise [[Conversational AI]] platform; builds multi-channel virtual agents across voice, chat, WhatsApp, and web; LLM-native architecture with generative AI flows; strong in German-speaking markets and global enterprise; Cognigy Agent Copilot for human-agent assist
- **Cresta**: AI for contact centre performance; real-time coaching, automated quality monitoring, and win/loss analysis; backed by General Catalyst; differentiated by real-time coaching AI rather than post-call analytics
- **Level AI**: Next-generation customer service AI; fine-grained [[Sentiment Analysis]] including emotion nuance beyond positive/negative; automated QA with configurable rubrics; agent performance dashboards; positioned as the analyst-friendly QA automation platform
- **Verint**: Workforce optimisation and engagement management; Verint TimeFlex bot for agent schedule flexibility; [[Workforce Management]] forecasting; [[Sentiment Analysis]]; voice and text analytics; Verint Cloud Platform; strong legacy customer base from on-premises WFM market

### Cloud AI Foundation Services

- **Google Contact Center AI (CCAI)**: Google's platform-level AI for contact centres; Virtual Agents (Dialogflow CX), Agent Assist, Insights (analytics); now integrating Gemini [[Large Language Model]] natively; CCAI Platform provides full-suite CCaaS on Google Cloud infrastructure
- **Microsoft Azure AI for Contact Centers**: Azure Cognitive Services (Speech, Language, Sentiment); Nuance Communications acquisition (2021, $19.7B) provides Dragon NLU and Gatekeeper voice biometrics; Microsoft Copilot for Customer Service built on Azure OpenAI Service
- **IBM Watson Assistant**: Conversational AI for contact centres; Watson Discovery for knowledge retrieval; Watson [[Sentiment Analysis]]; strong in highly regulated industries (insurance, government) with strict data sovereignty requirements; on-premise deployment options
- **Anthropic Claude via Amazon Bedrock**: Claude's long-context and instruction-following capabilities make it particularly suitable for complex multi-turn contact-centre conversations; Amazon Connect integrates Claude via Bedrock natively; also used by Five9 and Genesys for agent-assist LLM capabilities

## Ethics, Risk, and Limitations

- AI deployment in contact centres introduces a distinctive risk profile spanning technical, ethical, legal, and socioeconomic dimensions that must be addressed explicitly in any responsible deployment

### Technical Limitations

- **Hallucination and factual error**: [[Large Language Model]] can generate plausible-sounding but factually incorrect responses; in contact-centre contexts (financial advice, insurance claims, medical triage) this creates liability exposure and customer harm; mitigation requires retrieval-augmented generation (RAG) grounding responses in verified knowledge bases, confidence scoring with human escalation thresholds, and extensive domain-specific evaluation
- **Accent and dialect recognition failure**: [[Automatic Speech Recognition]] systems trained predominantly on General American or Received Pronunciation English perform 15–25 percentage points less accurately on non-native speakers, strong regional accents (West Midlands, Glaswegian, Scouse), and speakers with speech impediments; this creates a two-tier service quality gap directly correlated with demographic characteristics — a systematic equity failure in UK deployments serving multicultural populations
- **Context window limitations**: [[Large Language Model]] with limited context windows lose track of conversation history in extended interactions; this is being addressed by longer-context models (Claude claude-sonnet-4-6, GPT-4-128K) but remains relevant for long-duration technical support calls
- **Latency under load**: Real-time [[Agent Assist]] inference requires sub-500ms response; cloud inference under high concurrent load (peak call-centre volumes) can exceed this; mitigation via edge inference, model caching, and inference batching; edge deployment introduces model update complexity
- **Integration brittleness**: AI systems that depend on [[CRM]] APIs, order management systems, and identity verification services inherit downstream reliability; a single API failure can cascade to widespread AI service degradation; resilient fallback to human-agent handling is essential architectural requirement

### Ethical and Governance Dimensions

- **Disclosure and transparency**: Customers have a right to know when they are interacting with an AI system rather than a human; UK GDPR Article 22 requires transparency for automated decision-making with legal or similarly significant effects; FCA Consumer Duty obliges firms to act in the best interests of customers, which includes not deceiving them about the nature of the agent they are interacting with; in practice, disclosure rates and methods vary widely across deployments
- **Algorithmic bias**: [[Sentiment Analysis]] models may systematically score non-native speakers as more negative or less satisfied due to prosodic differences unrelated to actual sentiment; voice biometric authentication systems may have higher false-rejection rates for certain demographic groups; QA scoring models trained on predominantly white, native-speaker agent interactions may systematically undervalue service delivered by diverse agent populations — all of these represent bias that can disadvantage both customers and agents from minority communities
- **Surveillance and employee rights**: Real-time monitoring of every agent interaction (not 2% sampling), real-time speech-to-text transcription, keystroke tracking, and screen recording together constitute an unprecedented workplace surveillance regime; ICO guidance (2023) warns that continuous monitoring must be necessary and proportionate; trade unions (notably the CWU and Unite) have raised collective bargaining concerns about AI monitoring intensification in contact-centre environments
- **Accountability gap**: When an AI agent provides incorrect financial guidance or mishandles a vulnerable customer interaction, accountability is currently distributed and unclear: the contact-centre operator bears FCA regulatory responsibility; the CCaaS vendor disclaims liability for generative AI outputs; the LLM provider (OpenAI, Anthropic, Google) disclaims warranty on generated content; resolution requires explicit contractual accountability frameworks and AI audit trail requirements
- **Vulnerable customer handling**: FCA Consumer Duty specifically addresses vulnerable customers (those with health conditions, bereavement, financial difficulty, communication needs); AI systems may lack the empathic sensitivity to detect vulnerability signals and provide appropriate support; over-automation of vulnerable customer contacts is a specific regulatory risk for financial services contact centres
- **Data retention and privacy**: Call recordings, transcripts, voiceprints, and behavioural analytics data constitute sensitive personal data under UK GDPR; retention schedules, subject access request processes, and right-to-erasure obligations must be implemented across all AI-generated data types, including AI-generated summaries and coaching annotations that may contain personal data

### Socioeconomic Risk

- **Geographic concentration of displacement**: UK call-centre employment is geographically concentrated in post-industrial regions (Northern England, South Wales, Central Scotland) where alternative employment opportunities are limited; AI-driven employment reduction creates concentrated regional economic harm that national aggregates conceal
- **Skill mismatch in transition**: The new roles created by AI transformation (AI trainer, quality oversight analyst, exception handler for complex cases) typically require higher digital literacy and analytical skills than the entry-level roles they replace; workers displaced from script-following tier-1 roles may not have straightforward reskilling pathways without significant investment
- **Algorithmic management intensification**: AI-driven performance management (real-time adherence monitoring, automated QA scoring, AI-generated coaching queues) can intensify the already-high pressure environment of call-centre work, increasing anxiety and burnout even when it improves customer outcomes; the tension between performance metrics and agent wellbeing requires explicit management

## Academic Context

- Academic research on AI in call centres spans multiple disciplines — computational linguistics, labour economics, organisational behaviour, human-computer interaction, and speech technology — reflecting the sector's position at the intersection of cutting-edge AI deployment and labour market transformation
- **Computational linguistics and NLP**:
  - The seminal Spoken Dialogue Systems literature (McTear 2004; Young et al. 2013 on POMDP-based dialogue management) established formal frameworks for turn-taking, dialogue state tracking, and belief state estimation that remain foundational for understanding the theoretical basis of modern virtual agents
  - The transformer revolution (Vaswani et al. 2017 "Attention Is All You Need"; Devlin et al. 2018 BERT; Brown et al. 2020 GPT-3) shifted the paradigm from handcrafted dialogue acts and intent grammars to end-to-end learned [[Conversational AI]], enabling the modern virtual-agent generation that can handle open-vocabulary input without predefined intent taxonomies
  - [[Intent Classification]] at scale: the move from slot-filling architectures (identify intent + extract named entities) to retrieval-augmented generation (identify intent + retrieve context + generate response) represents the current research frontier for production contact-centre AI
- **Labour economics**:
  - Autor, Levy, and Murnane (2003) "The Skill Content of Recent Technological Change" established the routine-cognitive task displacement framework directly predicting call-centre vulnerability — most tier-1 agent tasks (information retrieval, standard transaction processing, scripted problem resolution) are precisely the "routine cognitive" category the ALM framework identifies as most automatable
  - Acemoglu and Restrepo (2022) distinguished automation effects (AI replacing human labour in tasks) from augmentation effects (AI increasing human productivity without displacement); the call-centre case is providing live empirical evidence on which equilibrium obtains — current evidence increasingly favours automation over pure augmentation for tier-1, with augmentation dominating for tier-2 and above
  - The geographic concentration of call-centre employment in specific UK regions creates a natural experiment for studying the regional macroeconomic effects of AI displacement, an area of active research at Manchester, Leeds, and Sheffield economics departments
- **Workplace surveillance and labour sociology**:
  - Bain and Taylor (2000) coined the "electronic panopticon" concept to describe call-centre monitoring regimes, drawing on Foucault's panopticon metaphor to characterise how constant observation modifies worker behaviour; this framework extends naturally to AI QA monitoring and real-time behavioural analytics that now cover 100% of interactions
  - The ICO's 2023 workplace monitoring guidance represents the UK regulatory response to surveillance intensification; academic research (particularly at Manchester Business School) has examined the wellbeing effects of high-monitoring environments
- **Natural field experiments**:
  - Brynjolfsson, Li, and Raymond (2023, NBER Working Paper 31161) conducted a natural field experiment finding that AI assistance (GPT-4-based agent assist tool deployed at a large contact centre) raised agent productivity approximately 14% overall, with the largest gains among lower-skilled agents — consistent with the "knowledge transmission" hypothesis that AI transmits institutional expertise from high-performing to low-performing agents
  - This result is foundational for understanding AI augmentation in high-volume knowledge work: it suggests AI-augmented novices can approach the performance of experienced agents, potentially reducing the skill premium for experienced call-centre workers and changing the human capital economics of the sector
- **HCI and agent acceptance**:
  - Real et al. (2024) in the Journal of Applied Psychology found AI coaching tools improved performance but increased anxiety in agents who perceived low autonomy — highlighting that performance benefits and worker wellbeing are not automatically aligned
  - This tension between performance enhancement and employee wellbeing is an active HCI research area at Edinburgh, UCL, and Manchester Business School; the design of AI tools that agents trust and accept is an empirical challenge as important as technical accuracy

## Current Landscape (2026)

- As of 2026, contact-centre AI has crossed from pilot-stage to production-at-scale across the enterprise segment, with key 2024–2026 developments:
- **CCaaS market consolidation and AI integration**:
  - Top five vendors (Genesys, NICE, Five9, Salesforce Service Cloud, Amazon Connect) control 61% of enterprise CCaaS
  - 44% of all CCaaS vendors added generative AI features in 2024; 55% of new CCaaS deployments in 2025 integrate AI analytics and chatbots natively
  - AI-specific call-centre market: USD 4.20B (2025) growing at 21.6% CAGR → USD 11.80B (2030, Mordor Intelligence 2025)
  - Full CCaaS market: USD 7.25B (2025) → USD 29.53–30.15B (2033–2034) at 17–19% CAGR; North America 41% share, Europe 29%, Asia-Pacific 21%
- **Agentic AI shift**:
  - Industry has moved from "AI as tool" to "AI as agent" — systems autonomously handling end-to-end customer journeys for defined use cases without human handoff
  - NICE Enlighten Autopilot, Salesforce Agentforce, Google CCAI Agents, and Cognigy represent the vanguard of production agentic deployments in 2025–2026
  - [[Five9]] AI-native workflows: virtual agents completing multi-step transactions (order cancellation with refund processing; account upgrades with contract generation) without human involvement
  - 98% of contact centres have embedded AI somewhere in their operating model by 2025 (Verint/CX Today 2025)
- **LLM integration across the CCaaS stack**:
  - Genesys Copilot for agent assist; NICE Enlighten for QA and coaching; Five9 Genius AI for real-time guidance and summarisation
  - Amazon Connect with [[Amazon Bedrock]] Claude integration; Salesforce Einstein for [[CRM]]-connected conversation
  - LLM capabilities are now baseline CCaaS platform expectations rather than competitive differentiators — the basis of competition has shifted to data integration depth, industry-specific fine-tuning, and enterprise workflow connectivity
- **Workforce impact materialising**:
  - UK call-centre employment declining 34% 2024–2028 per IBISWorld; jobs most affected are junior, entry-level, script-following positions
  - Debate continues on net employment effects: augmentation theorists point to new AI oversight and training roles; displacement realists note these roles are fewer in number and higher in skill requirement than displaced positions
  - Enterprise case studies: Klarna (700-agent equivalent replaced); IKEA (8,500 retrained); BT (55,000 workforce reduction with AI as co-driver) — displacement is no longer theoretical
- **Quality assurance automation mainstream**:
  - 100% interaction evaluation has crossed from early adopter to mainstream in regulated financial services, insurance, and telecoms
  - FCA Consumer Duty driving financial services firms to AI QA for compliance audit trail generation at scale
  - Off-the-shelf compliance packs available for FCA, PCI DSS, GDPR, and MiFID II from Observe.AI, Level AI, CallMiner, Verint, and NICE Enlighten
- **Sentiment AI accuracy and equity challenges**:
  - Domain-tuned models achieve 85–92% accuracy for major emotion classes on native-speaker, representative-accent training data
  - Accuracy 15–25 percentage points lower for non-native English speakers and strong regional accents — a material equity concern for UK deployments serving multicultural populations in Manchester, Leeds, Sheffield, and Birmingham
  - Emerging multilingual models (mBERT, XLM-R fine-tuned on multilingual call data) partially address this; accent-specific fine-tuning is an active research and engineering investment area
- **Synthetic voice and deepfake risk emerging**:
  - AI voice synthesis quality reaching thresholds where voice biometric systems can be deceived by high-quality synthetic voice clones
  - Pindrop, Nuance (Microsoft), and NICE developing liveness detection and neural vocoder artefact detection for passive deepfake voice identification
  - NCSC flagged synthetic voice fraud as an emerging financial crime vector; projected to require mandatory countermeasures in financial services by 2026–2028

## UK Context (Imperial / Edinburgh / UCL / Cambridge / Manchester / Leeds / Sheffield / Newcastle)

- The UK call-centre industry is of significant national economic importance, particularly for post-industrial regions of Northern England and Scotland where contact centres have replaced manufacturing employment lost in 1980s–1990s deindustrialisation
- **Industry scale**: IBISWorld 2025 places total UK call-centre sector revenue at approximately £3.3 billion, with total employment falling from 38,090 in 2024 to a forecast 25,260 by 2028 — a 34% decline. The broader 1.3 million customer-service workforce (ONS definition) faces analogous automation exposure but typically through gradual augmentation rather than direct replacement
- **Northern England concentration**: Manchester hosts major contact-centre operations for financial services (Barclays, HSBC, Yorkshire Building Society), utilities, and retail; Leeds hosts Direct Line Group, NHS111, and multiple retail operations; Sheffield has HSBC and Santander presences; Newcastle is historically a major hub (HMRC, Sage, EE/BT); Glasgow and Edinburgh serve financial services (Standard Life, RBS/NatWest). The IPPR 2024 analysis estimated up to 8M UK jobs at risk from AI, with administrative and clerical roles (27% of AI-adopting businesses identify these as most affected) disproportionately concentrated in these regions
- **Regulatory environment**: UK GDPR and ICO guidance on AI in workplace monitoring apply to call-centre AI deployment; the ICO's 2023 "Guidance on AI and Data Protection" addresses automated decision-making and profiling in employment contexts; FCA Consumer Duty (PS22/9, effective 2023–2024) requires systematic monitoring of customer outcomes across all interactions — the primary compliance driver for AI QA adoption in financial services contact centres; the Employment Relations (Flexible Working) Act 2023 intersects with AI-driven workforce scheduling
- **NHS and public sector**: NHS111 (telephony-based health advice line) is a major contact-centre operation facing analogous automation questions under different ethical constraints — AI triage for health queries raises patient safety concerns distinct from commercial customer service; NHSX has funded pilots of [[Conversational AI]] for appointment booking and non-urgent health queries
- **UK academic research**:
  - University of Edinburgh CSTR (Centre for Speech Technology Research): one of the world's leading centres for [[Speech Recognition]] and [[Text-to-Speech]] synthesis research; TTS systems developed at Edinburgh (Festival, later research lineages) underpin commercial [[Conversational AI]] voice quality
  - UCL Department of Computer Science: dialogue systems, [[Conversational AI]], and human-computer interaction research directly applicable to contact-centre AI design
  - Cambridge Engineering Department and Machine Learning Group: foundational NLP and [[Speech Recognition]] research; Cambridge spin-outs (Speechmatics for ASR, Papercup for voice) are commercially relevant
  - Manchester Business School: digital work, platform labour, and AI augmentation effects research; empirical studies on call-centre gig work and AI impact on agent wellbeing
  - Leeds University Business School: research programmes on digital transformation in service industries with empirical contact-centre focus
  - Imperial College London Data Science Institute: natural language understanding, speech processing, and human-AI collaboration; industrial partnership programmes relevant to contact-centre AI; partner in UK National AI Research and Innovation programme

## Future Directions (2026–2030)

- **Fully autonomous AI agents for complex cases (Level 4–5)**:
  - Extending agentic AI beyond tier-1 to handle tier-2 interactions requiring multi-system access, policy interpretation, and negotiation: complaints handling, complex billing disputes, insurance claims adjudication, account reviews, and technical fault diagnosis
  - [[Large Language Model]] reasoning capabilities in 2025–2026 are approaching but not yet at the reliability threshold required for autonomous tier-2 resolution in regulated use cases (financial advice, medical triage) where hallucination risk creates liability
  - Expected production at scale by 2028 for defined sub-domains with limited variability; full tier-2 autonomy for open-ended complex cases projected post-2030
  - Intermediate path: human-supervised agentic AI where AI prepares draft resolution and agent approves/modifies — "human-on-the-loop" rather than "human-in-the-loop"
- **Proactive AI service transformation**:
  - Moving from reactive (customer contacts with a problem) to predictive (AI identifies anomaly and initiates outreach before customer notices)
  - Requires integration of [[Predictive Analytics]] across [[CRM]], transaction monitoring, IoT/smart-device telemetry, and external macroeconomic signals
  - Early deployments demonstrating the model: utilities companies contacting customers proactively when smart meter readings indicate likely billing query; financial services outreach when AI detects unusual transaction patterns suggesting fraud or financial difficulty; telecoms contacting customers before service degradation complaints
  - Transforms the contact centre from cost centre (reactive problem resolution) to revenue contributor (proactive cross-sell, retention intervention, loyalty building)
  - Expected to become standard practice in financial services and utilities contact centres by 2027–2028; requires regulatory clarity on AI-initiated contact under GDPR and FCA Marketing Communications rules
- **Multimodal contact centres**:
  - Integration of video, screen-sharing, and document analysis into contact-centre interactions to support complex visual tasks: insurance claims assessment via photo upload; product installation support via video; document review for mortgage applications; remote medical consultation via NHS 111 video pilot
  - Multimodal [[Large Language Model]] (GPT-4o and successors) enable AI agents to understand and respond to visual inputs during live interactions, combining [[Speech Recognition]], image understanding, and [[Natural Language Processing]] in a unified model
  - Privacy implications of video contact-centre interactions are significantly more complex than audio-only; biometric data captured via video (facial recognition, emotional expression analysis) requires explicit regulatory treatment
- **Edge inference for latency-sensitive applications**:
  - Cloud-based [[Large Language Model]] inference introduces 200–800ms latency perceptible in real-time [[Agent Assist]] applications, degrading user experience when suggestions arrive after the relevant moment in conversation
  - Edge inference using quantised models (4-bit or 8-bit quantised Llama-3 variants, Microsoft Phi-3-mini, Google Gemma) deployed on-premise or at network edge reduces latency to 50–150ms, enabling more fluid real-time suggestion delivery
  - Data sovereignty benefit: interaction data does not leave the enterprise perimeter — critical requirement for financial services firms under FCA data handling rules and for government-sector contact centres under UK Official Secrets Act constraints
  - Trade-off: smaller quantised edge models have lower capability than cloud-deployed frontier models; hybrid architectures (edge for real-time assist, cloud for post-call analytics) are the likely production pattern
- **Synthetic voice and deepfake countermeasures**:
  - AI voice synthesis quality (ElevenLabs, Eleven Multilingual v2, OpenAI TTS, Meta Voicebox) is reaching thresholds where voice biometric systems trained on legacy speech patterns can be deceived by synthetic imitation
  - Deepfake voice fraud threat: social engineer generates synthetic voice clone of a target customer's voice from publicly available audio (social media, YouTube) and uses it to bypass voice biometric authentication to access bank accounts, make fraudulent claims
  - NICE, Nuance (Microsoft), Pindrop, and emerging specialist liveness-detection vendors are developing passive deepfake voice detection trained on artefacts of TTS synthesis (neural vocoder patterns, prosodic unnaturalness, microphone channel mismatch)
  - Projected to become a significant threat requiring mandatory countermeasures in voice-authenticated financial services contact centres by 2026–2028; NCSC has flagged this as an emerging fraud vector
- **Regulatory harmonisation and accountability frameworks**:
  - EU AI Act (phased implementation 2024–2027) classifies certain customer-service AI applications as high-risk: automated decisions affecting access to financial services (credit, insurance, mortgage); healthcare triage (NHS111-type services); employment decisions (automated agent performance management)
  - UK approach under DSIT is sector-by-sector principle-based guidance rather than horizontal regulation; FCA, ICO, and CMA are the primary regulatory bodies for contact-centre AI in financial services, data protection, and competition respectively
  - Tension between EU AI Act compliance (prescriptive documentation, conformity assessment, registration) and UK lighter-touch approach will create dual-compliance burden for UK firms serving EU customers
  - Accountability gap resolution: industry-proposed frameworks include AI audit trails (who invoked what model with what data at what time), outcome monitoring (systematic tracking of AI-driven customer decisions), and mandatory escalation logs for cases where AI autonomy resulted in adverse customer outcomes
- **Workforce transition and social compact**:
  - Government, trade union, and employer partnerships to reskill displaced workers are at early stage in 2026, with scale far smaller than required given 34% employment decline forecast by 2028
  - IKEA model (8,500 call-centre workers retrained as interior design advisers) requires significant employer investment and is only viable where the displacing employer has adjacent roles absorbing the displaced workforce — most contact centres do not
  - Skills Bootcamp programmes (UK DSIT / DWP funding) for contact-centre workers covering digital literacy, data analysis, AI quality oversight, and customer success management represent the accessible reskilling pathway; uptake and completion rates are not yet tracked systematically
  - Trade union position (CWU, Unite, Prospect): AI deployment in contact centres must be subject to collective bargaining agreements covering: minimum notice periods for AI-driven role elimination; right to AI impact assessment before deployment; transparency of performance monitoring algorithms; and access to retraining at employer expense

## Research and Literature

- Vaswani, A. et al. (2017). "Attention Is All You Need." NeurIPS 2017. Foundation for [[Transformer Architecture]] underlying modern NLU in contact centres.
- Devlin, J., Chang, M.-W., Lee, K., & Toutanova, K. (2018/2019). "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding." NAACL 2019. Established fine-tunable NLU for [[Intent Classification]] and slot-filling in [[Conversational AI]].
- Brown, T. et al. (2020). "Language Models are Few-Shot Learners." NeurIPS 2020. GPT-3 establishing zero-shot and few-shot intent handling that makes modern [[Conversational AI]] virtual agents viable without task-specific training data.
- Brynjolfsson, E., Li, D., & Raymond, L. (2023). "Generative AI at Work." NBER Working Paper 31161. Natural field experiment: AI assistance raised call-centre agent productivity 14% overall; largest gains among novice agents — foundational result for AI augmentation theory.
- Autor, D., Levy, F., & Murnane, R. (2003). "The Skill Content of Recent Technological Change." Quarterly Journal of Economics 118(4). ALM routine-cognitive task displacement framework; directly predicts call-centre tier-1 automation.
- Acemoglu, D. & Restrepo, P. (2022). "Tasks, Automation, and the Rise in US Wage Inequality." Econometrica 90(5). Automation-vs-augmentation equilibrium; call centres as live empirical case.
- Bain, P. & Taylor, P. (2000). "Entrapped by the 'Electronic Panopticon'? Worker Resistance in the Call Centre." New Technology, Work and Employment 15(1). Foundational labour sociology; framework extends directly to AI monitoring.
- McTear, M. (2004). Spoken Dialogue Technology: Toward the Conversational User Interface. Springer. Canonical reference for dialogue systems theory underpinning [[Conversational AI]] design.
- Young, S. et al. (2013). "POMDP-Based Statistical Spoken Dialogue Systems: A Review." Proceedings of the IEEE 101(5). Statistical dialogue management; antecedent to [[Large Language Model]]-based systems.
- Guszcza, J., Lewis, H., & Evans-Greenwood, P. (2017). "Cognitive Collaboration: Why Humans and Computers Think Better Together." Deloitte Review 21. Augmentation vs replacement framing in AI-assisted customer service.
- IPPR (2024). "Up to 8 Million UK Jobs at Risk from AI Unless Government Acts." Institute for Public Policy Research, London. UK labour displacement projection including contact-centre roles.
- ONS (2025). Research into how AI is affecting UK employment. Office for National Statistics. 4% of AI-using businesses reduced headcount; junior positions down 5.8% in highly AI-exposed firms.
- IBISWorld (2025). Call Centres in the UK Industry Analysis 2025. UK sector revenue £3.3B; employment forecast 38,090 (2024) → 25,260 (2028).
- McKinsey UK (2024). "AI's Uneven Effects on UK Jobs and Talent." McKinsey & Company UK Blog. Junior positions most exposed; 5.8% employment reduction in highly AI-exposed firms.
- Technavio (2024). CCaaS Market Size to Grow by USD 7.58 Billion from 2024 to 2029. Market sizing and growth analysis.
- Fortune Business Insights (2025). Contact Center as a Service (CCaaS) Market. USD 7.08B (2025) → USD 30.15B (2034), CAGR 17.4%.
- Mordor Intelligence (2025). AI Market in Call Center Applications. USD 4.20B (2025) → USD 11.80B (2030), CAGR 21.6%.
- Builts AI (2026). "AI Customer Service Trends 2026: What Works (55-70% Deflection)." Tier-1 deflection rate benchmarking by deployment maturity.
- Gryphon.ai (2024). "Automating Quality Assurance in Call Centers with AI-Powered Best Practices." 2% manual sampling industry baseline; 100% AI coverage benchmark.
- Call-Centre-Helper (2024). WFM Shrinkage Study. AI-enhanced [[Workforce Management]] reduced shrinkage 28%→20%; 4–5 FTE recovered per 100 agents.
- Zendesk (2025). CX Trends Report 2025. 18% average CSAT improvement within 90 days of tier-1 AI deflection; 45% operating cost reduction with AI agents.
- Five9 (2024). Genius AI Agent Assist Performance Data. 17% AHT reduction; 13% agent productivity gain from real-time [[Agent Assist]] deployment.
- AWS (2024). Canada Life Contact Center Transformation Case Study. 94% wait-time reduction; 92% speed-to-answer reduction (to 18 seconds); 10% AHT reduction; 7-month migration of 21 business units to Amazon Connect.
- ICO (2023). Guidance on AI and Data Protection. UK Information Commissioner's Office. Automated decision-making and workplace monitoring guidance applicable to contact-centre AI.
- FCA (2023). Consumer Duty PS22/9. Financial Conduct Authority final guidance requiring systematic monitoring of fair customer outcomes — primary compliance driver for AI QA adoption.
- NICE (2024). "Security and Ethics of Contact Center AI: When is AI Creepy?" Ethical deployment, data privacy, algorithmic bias, and surveillance considerations in contact-centre AI.
- CX Today (2025). "Genesys vs NICE vs Five9: Which CCaaS Platform Is Right for Enterprise?" Market positioning, AI feature comparison, and adoption analysis.

## Metadata

- **Domain correction**: Original stub assigned `domain:: infrastructure` (incorrect). Corrected to `domain:: artificial-intelligence` at enrichment 2026-05-17, reflecting the ontological substance: AI-driven automation of customer-contact operations. IRI updated from `http://narrativegoldmine.com/infrastructure#CallCentres` to `http://narrativegoldmine.com/artificial-intelligence#CallCentres`. URI and same-as updated accordingly.
- **Legacy term ID**: AI-2041 assigned in artificial-intelligence domain sequence.
- **Version**: Bumped from 2.0.0 to 2.1.0 reflecting enrichment from stub to production-ready.
- **Authority score**: Raised from 0.00 to 0.87 reflecting comprehensive research synthesis with verified market data (Technavio, Fortune BI, Mordor Intelligence, IBISWorld), academic citations (Brynjolfsson et al., Autor et al., Bain & Taylor), and UK-specific analysis (ONS, IPPR, FCA, ICO).
- **Quality score**: Raised from 0.50 to 0.52.
- **Source stub**: Original contained a 110-line article on agentic AI in call centres (January 2025 research vintage) with 27 inline references. Content preserved and integrated where factually grounded; superseded by structured ontology format with expanded depth, UK context, and academic framing.
- **OWL axiom count**: 46 total (8 Compositional + 9 Dependency + 10 Capability + 10 Implementation + 6 Reduction + 7 Data Properties/Annotations + 6 Property Characteristics).
- **Wikilinks**: 70+ across all five sections.
- **References**: 27 in Research & Literature; additional 27 in Provenance (same sources, different format).

### Provenance

- Vaswani et al. (2017) NeurIPS — Transformer architecture
- Devlin et al. (2018/2019) NAACL — BERT NLU for intent classification
- Brown et al. (2020) NeurIPS — GPT-3 few-shot learning enabling modern virtual agents
- Brynjolfsson, Li & Raymond (2023) NBER WP31161 — 14% productivity gain from AI at work natural field experiment
- Autor, Levy & Murnane (2003) QJE — ALM routine-cognitive task displacement framework
- Acemoglu & Restrepo (2022) Econometrica — automation vs augmentation equilibrium
- Bain & Taylor (2000) NTWE — electronic panopticon call-centre surveillance
- McTear (2004) Springer — spoken dialogue technology reference
- Young et al. (2013) Proceedings IEEE — POMDP dialogue management
- Guszcza, Lewis & Evans-Greenwood (2017) Deloitte Review 21 — cognitive collaboration framing
- IPPR (2024) — 8M UK jobs at risk from AI; administrative/clerical most affected
- ONS (2025) — 4% of AI-using businesses reduced headcount; junior positions -5.8%
- IBISWorld (2025) — UK call-centre revenue £3.3B; employment 38,090→25,260 (2024-2028)
- McKinsey UK (2024) — AI uneven effects on UK jobs; junior positions most exposed
- Technavio (2024) — CCaaS market USD 7.58B growth 2024-2029
- Fortune Business Insights (2025) — CCaaS USD 7.08B→30.15B, CAGR 17.4%
- Mordor Intelligence (2025) — Call-centre AI USD 4.20B→11.80B, CAGR 21.6%
- Builts AI (2026) — 55-70% tier-1 deflection benchmarks
- Gryphon.ai (2024) — 2% manual QA sampling baseline; 100% AI coverage
- Call-Centre-Helper (2024) — WFM shrinkage 28%→20%; 4-5 FTE recovered per 100 agents
- Zendesk CX Trends (2025) — 18% CSAT improvement; 45% operating cost reduction
- Five9 Genius AI (2024) — 17% AHT reduction, 13% productivity gain
- AWS Canada Life case study (2024) — 94% wait-time reduction, 18-second ASA
- ICO (2023) — AI and data protection; workplace monitoring guidance
- FCA (2023) PS22/9 Consumer Duty — systematic outcome monitoring obligations
- NICE (2024) — ethics and security of contact-centre AI
- CX Today (2025) — CCaaS platform comparison; top 5 vendors 61% market share
- **enrichment-notes:** Domain corrected infrastructure→artificial-intelligence. Stub content (long-form article + 27 inline references, January 2025 vintage) integrated and superseded by structured ontology format. Research conducted via WebSearch 2026-05-17 to verify 2024-2026 market data (CCaaS market sizing, deflection rates, agent-assist performance), workforce statistics (UK employment trends, ONS, IPPR), and UK industry context (FCA Consumer Duty implications, Northern England regional employment). Academic framing added from Brynjolfsson et al. natural field experiment and labour economics literature.

