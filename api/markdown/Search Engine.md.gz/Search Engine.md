A search engine is a software system that systematically crawls, indexes, and ranks digital content to retrieve relevant results in response to user queries. It combines web crawling, inverted-index construction, relevance ranking (including PageRank-style link analysis and learning-to-rank models), and query understanding (tokenisation, stemming, NLP) into an end-to-end pipeline. Modern search engines increasingly integrate semantic embeddings, dense retrieval, and large language model components to handle natural-language and multimodal queries. They constitute foundational information infrastructure for the open web, enterprise knowledge bases, e-commerce catalogues, and emerging spatial and metaverse content layers.

### Overview

- Search engines emerged in the early 1990s alongside the World Wide Web, with systems such as Archie (1990), AltaVista (1995), and then Google (1998) establishing the modern paradigm of link-based [[Relevance Ranking]].
- Their core value proposition is scale and speed: they pre-compute index structures that allow sub-second retrieval across billions of documents, a problem that naïve real-time scanning cannot solve.
- The domain is now mature. Google, Bing, and Baidu dominate the public web tier; [[Elasticsearch]] and Apache Solr lead enterprise and application search; specialised vertical search engines target domains such as legal, biomedical, and code.
- Recent developments centre on the fusion of classical [[Inverted Index]] retrieval with dense [[Vector Search]] (bi-encoders, ColBERT) and the integration of [[Large Language Model]] components for query rewriting, answer synthesis, and [[Retrieval-Augmented Generation]] (RAG).
- Search engines are critical infrastructure whose design choices — what content is surfaced, in what order, under what policies — carry significant societal implications for information access and [[Digital Governance]].

### Key Components

#### Web Crawler

- A [[Web Crawler]] (spider) autonomously fetches web pages by following hyperlinks from a seed set, respecting `robots.txt` exclusion rules and crawl politeness delays.
- Large-scale crawlers such as Googlebot distribute work across thousands of machines and must handle dynamic [[JavaScript Rendering]], canonical URL deduplication, and freshness scheduling.
- Related: [[Content Discovery]], [[URL Frontier]], [[Link Graph]].

#### Index Construction

- Raw crawled documents are parsed, normalised (encoding, HTML stripping), and tokenised into terms.
- An [[Inverted Index]] maps each term to a posting list of document identifiers and positional information, enabling fast Boolean and phrase retrieval.
- Modern indexes also store forward indexes for feature extraction and [[Document Embedding]] vectors for dense retrieval.
- [[Data Storage]] at search-engine scale requires distributed file systems (e.g. GFS / HDFS) and sharded index servers.

#### Query Processing

- [[Query Processing]] encompasses tokenisation, stemming/lemmatisation, stop-word removal, spelling correction, query expansion, and intent classification.
- [[Natural Language Processing]] components parse conversational and ambiguous queries; entity recognition links query terms to [[Knowledge Graph]] entities for disambiguation.
- Structured queries (Boolean, field-restricted, geo-spatial) are compiled into query plans evaluated against the index shards.

#### Relevance Ranking

- Classical [[Relevance Ranking]] models include TF-IDF, BM25 (Okapi), and [[PageRank]]-style authority propagation.
- Learning-to-rank (LTR) models (RankNet, LambdaMART, neural LTR) combine hundreds of features — textual similarity, freshness, click-through rates, page authority — into a final score.
- Dense retrieval augments sparse matching: query and document [[Embedding]] vectors are compared by approximate nearest-neighbour search ([[Vector Search]]), enabling semantic rather than purely lexical matching.
- Cross-encoder re-rankers (BERT-based) score top-k candidates for precision at the top of the results list.

#### Results Presentation

- The [[Search Results Page]] (SERP) formats ranked results as title, URL snippet, and rich-answer features (featured snippets, knowledge panels, image/video carousels).
- Answer generation using [[Large Language Model]] components is increasingly embedded directly in SERPs (e.g. AI Overviews in Google Search).
- Personalisation layers adjust ranking based on user history, location, and preferences, raising [[Privacy]] and [[Filter Bubble]] concerns.

### Mechanisms & Algorithms

- **BM25** — probabilistic term-frequency saturation model, the dominant sparse baseline since the 1990s.
- **PageRank / HITS** — graph-theoretic link-authority algorithms that treat hyperlinks as votes, forming the basis of web-scale quality signals.
- **Learning-to-Rank** — supervised models trained on human-labelled relevance judgements (NDCG-optimised); connect to [[Machine Learning]] pipelines for continuous model refreshes.
- **Dense Passage Retrieval (DPR)** — dual-encoder architecture mapping queries and passages to a shared vector space; enables [[Semantic Search]] without lexical overlap.
- **Approximate Nearest Neighbour (ANN)** — HNSW, IVF-PQ, and similar graph/quantisation indexes that make billion-scale [[Vector Search]] sub-millisecond.
- **BERT-based Re-ranking** — cross-attention models (e.g. monoT5, ColBERT) re-score top-k candidates for nuanced relevance.
- **[[Retrieval-Augmented Generation]] (RAG)** — retrieval step grounds [[Large Language Model]] generation in verified document chunks, reducing hallucination.

### Applications & Use Cases

- **Web Search** — universal-scope crawl-and-rank over the public web; dominated by Google, Bing, Baidu, and Yandex at national scale.
- **[[Enterprise Search]]** — internal search over corporate document repositories, wikis, e-mail, CRM, and structured databases using platforms such as [[Elasticsearch]], Coveo, and Glean.
- **E-commerce Search** — product catalogue retrieval optimised for conversion; combines keyword, faceted, and behavioural signals (used by Amazon, Shopify, Algolia).
- **Code Search** — repository-level retrieval over source code; GitHub Code Search, Sourcegraph, and ctags-based local search.
- **Biomedical & Legal Search** — domain-specific indexes over PubMed, case law, and patent databases with specialised ontology-aware ranking.
- **Conversational Search** — integration of search retrieval with dialogue management, enabling multi-turn [[Question Answering]] and task completion.
- **[[Spatial Search]] & [[Metaverse]] Discovery** — emerging application of search to 3D asset repositories, XR experiences, and geospatial content, connecting to [[Spatial Computing]] use cases.
- **[[Retrieval-Augmented Generation]] Backends** — search engines as retrieval substrates for LLM-based chatbots and agents, mediating the boundary between parametric model knowledge and live document corpora.

### Standards & Context

- **Schema.org** — structured data vocabulary used to annotate web pages, enabling search engines to extract rich entity information and generate knowledge panel entries; maintained by Google, Microsoft, Yahoo, and Yandex.
- **Sitemap Protocol (sitemaps.org)** — XML-based standard for webmasters to declare URL sets, update frequency, and priority hints to crawlers.
- **robots.txt (REP)** — Robots Exclusion Protocol governing which URL paths crawlers may access; formalised as RFC 9309 (2022).
- **OpenSearch** — XML description format allowing websites to advertise search endpoints to browsers and aggregators.
- **TREC (Text REtrieval Conference)** — long-running NIST evaluation series that has defined benchmarks (TREC-8, MS MARCO, BEIR) shaping ranking algorithm research for three decades.
- **MS MARCO / BEIR** — publicly available relevance datasets widely used to train and benchmark neural ranking models, including dense retrieval systems.
- **W3C Linked Data / SPARQL** — standards relevant to semantic search and entity-linked retrieval; connect to [[Knowledge Graph]] construction pipelines.
- [[Privacy]] regulation (GDPR, DSA in the EU) increasingly constrains personalisation, user-data retention, and de-indexing ("right to be forgotten") in search systems.

### Provenance

