Supply chain due diligence is a risk-based process through which a company identifies, prevents, mitigates and accounts for adverse impacts on people and the environment in its own operations and in its supply chain.[^1][^2]

## Human rights

The UN Guiding Principles on Business and Human Rights say that to identify, prevent, mitigate and account for how they address their adverse human rights impacts, business enterprises should carry out human rights due diligence.[^1] The process should include assessing actual and potential human rights impacts, integrating and acting upon the findings, tracking responses, and communicating how impacts are addressed.[^1] See [[Human Rights Due Diligence]].

## Human rights and environment

Directive (EU) 2024/1760 requires Member States to ensure that companies conduct risk-based human rights and environmental due diligence by integrating it into policies and risk management systems, identifying and assessing actual or potential adverse impacts, preventing and mitigating them, and providing remediation, among other actions.[^2] It extends the scope to a company's chain of activities, which covers the activities of upstream business partners related to production, including design, extraction, sourcing, manufacture, transport, storage and supply of raw materials, and certain downstream activities.[^2] It describes the OECD Due Diligence Guidance for Responsible Business Conduct and sectoral guidance as internationally recognised frameworks setting out practical due diligence steps.[^2] See [[OECD Due Diligence Guidance]].

## Sector regimes

Regulation (EU) 2017/821 defines supply chain due diligence for conflict minerals as the obligations of Union importers in relation to management systems, risk management, independent third-party audits and disclosure of information, with a view to identifying and addressing risks linked to conflict-affected and high-risk areas.[^3] That regime is described at [[Responsible Minerals Sourcing]].

## Scope and limits

Legal instruments that impose due diligence are collected at [[Supply Chain Due Diligence Instrument]]. The sources define due diligence by what it must include, not by outcome, and they differ on whether it is a standard of conduct or of result; the Guiding Principles say the process should be appropriate to size and circumstances. The OECD guidance was not opened.

[^1]: United Nations Office of the High Commissioner for Human Rights, HR/PUB/11/4, 2011, “Guiding Principles on Business and Human Rights: Implementing the United Nations “Protect, Respect and Remedy” Framework”. https://www.ohchr.org/sites/default/files/documents/publications/guidingprinciplesbusinesshr_en.pdf
[^2]: European Parliament and Council of the European Union, Directive (EU) 2024/1760 of 13 June 2024, “Directive (EU) 2024/1760 of the European Parliament and of the Council on corporate sustainability due diligence”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202401760
[^3]: European Parliament and Council of the European Union, Regulation (EU) 2017/821 of 17 May 2017, “Regulation (EU) 2017/821 of the European Parliament and of the Council laying down supply chain due diligence obligations for Union importers of tin, tantalum and tungsten, their ores, and gold originating from conflict-affected and high-risk areas”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32017R0821

