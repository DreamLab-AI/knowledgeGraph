WebGPU is a modern web standard and API that exposes the capabilities of contemporary graphics processing units to web applications for both rendering and general-purpose computation. It provides a low-overhead, explicit interface modelled on native APIs such as Vulkan, Metal and Direct3D 12, succeeding WebGL. WebGPU enables high-performance graphics, compute shaders, and GPU-accelerated machine learning directly in the browser.

- WebGPU is a modern web [[Graphics API]] that exposes contemporary [[GPU]] capabilities for both rendering and general-purpose [[Parallel Computing]] in the browser.
- It is the successor to WebGL, modelled on explicit native APIs such as [[Vulkan]], and shading is expressed in [[WGSL]].

### Overview

- WebGPU gives web applications low-overhead, explicit control over the GPU, mapping onto whichever native backend the platform provides — Vulkan, Metal or Direct3D 12.
- Beyond drawing, it exposes first-class [[Compute Shader]] support, allowing web code to run general-purpose [[GPU Computing]] workloads such as simulations and neural-network inference.
- Its design borrows the command-buffer, pipeline and binding-group model of modern native APIs, trading the convenience of older APIs for predictable, high performance.
- This makes WebGPU a bridge between the browser sandbox and the kind of [[GPU Acceleration]] previously confined to native applications.

### Key aspects

- Explicit pipelines: applications build [[Rendering Pipeline]] and compute pipeline objects up front for efficient repeated dispatch.
- Compute support: [[Compute Shader]] stages enable data-parallel work independent of graphics.
- WGSL shading: the WebGPU Shading Language ([[WGSL]]) defines portable shader programs.
- Portability: a single API targets multiple native backends, supporting cross-platform [[GPU Acceleration]].

### Mechanisms

- Command encoders record work that is submitted in batches to the [[GPU]] queue.
- Bind groups associate buffers and textures with shader resources in the [[Rendering Pipeline]].
- Compute dispatches map data-parallel workloads onto GPU threads for [[Parallel Computing]].
- The standard is developed in the open and standardised in cooperation with the [[Khronos Group]] ecosystem and web platform bodies.

### Applications

- High-fidelity [[Real-Time Rendering]] and 3D scenes in the browser.
- In-browser machine-learning inference using [[GPU Computing]].
- Scientific visualisation and simulation that need [[GPU Acceleration]] without native installs.
- Spatial-computing and WebXR experiences requiring efficient graphics.

### Provenance

