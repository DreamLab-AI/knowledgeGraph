An inference technique in constraint satisfaction that repeatedly applies local consistency rules to shrink the domains of variables, eliminating values that cannot participate in any solution before or during search. By propagating the logical consequences of each constraint through the constraint network, it prunes the search space dramatically, often exposes infeasibility early without any backtracking, and turns otherwise intractable combinatorial problems into practically solvable ones.

### Semantic Classification

### Content

## Definition

**Constraint propagation** is the workhorse inference mechanism of constraint programming. Given a constraint satisfaction problem — variables, finite domains, and constraints restricting which value combinations are permitted — propagation enforces a chosen level of *local consistency* by removing domain values that some constraint proves impossible. Each removal can trigger further removals in neighbouring variables, so the effect cascades through the constraint network until a fixed point is reached where no rule can delete anything more.

The technique sits between pure deduction and search. It is sound (it never removes a value that appears in a solution) but usually incomplete: reaching the fixed point rarely solves the problem outright, so solvers interleave propagation with [[Backtracking Search]], propagating again after every tentative assignment. This propagate-and-branch loop is what makes modern constraint solvers effective on scheduling, configuration, timetabling and design problems where naive enumeration would be hopeless.

Different consistency levels trade pruning power against cost. Node consistency checks unary constraints; [[Arc Consistency]] (the most widely used level) checks binary constraints between pairs of variables; path consistency and stronger k-consistency variants examine larger variable subsets. Global constraints such as `allDifferent` come with dedicated propagators — for example Régin's matching-based filtering — that achieve far more pruning than decomposing them into binary constraints ever could.

## Technical Details

- **Fixed-point computation**: propagators are applied until quiescence; the result is unique regardless of application order (confluence), which lets solvers schedule propagators by cost, running cheap ones first.
- **AC-3 and successors**: the classic AC-3 algorithm enforces arc consistency in O(ed³) time for e constraints and domain size d; AC-4, AC-6 and AC-2001 improve the bound to O(ed²) with support bookkeeping.
- **Propagation during search**: maintaining arc consistency (MAC) after each assignment is standard in solvers such as Gecode, Choco, OR-Tools CP-SAT and MiniZinc backends.
- **Beyond finite domains**: interval propagation applies the same idea to continuous variables in numerical and geometric constraint solving, which underpins parametric CAD and constraint-based design systems.
- **Failure detection**: when propagation wipes out a variable's domain the current branch is provably infeasible, giving solvers early, cheap backtrack triggers and powerful nogood learning signals.

  ## Current Landscape

- **CP-SAT dominance confirmed**: Google OR-Tools CP-SAT took gold in all four categories of the MiniZinc Challenge 2025 (Fixed, Free, Parallel, and — via its CP-SAT-LS variant — Local Search), with Choco-solver CP-SAT and PicatSAT taking silvers; it has placed first consistently since 2018.
- **Hybrid propagation-SAT architecture**: modern winners integrate constraint propagation with SAT-style clause learning through lazy clause generation — propagators explain their domain reductions as clauses, letting the solver reuse CP's specialised global-constraint filtering (linear, allDifferent, circuit, interval/disjunctive/cumulative scheduling) alongside conflict-driven learning.
- **Solver ecosystem**: the MiniZinc Challenge 2025 fielded entrants including Atlantis, Choco-solver (CP and CP-SAT), SICStus Prolog, Pumpkin, PicatSAT, iZplus, and Yuck, each run on 100 model instances — propagation-based finite-domain solving remains the benchmark's explicit focus.
- **Application growth**: propagation-backed CP is increasingly packaged for domain users, e.g. PyJobShop (2025, arXiv:2502.13483) exposing CP-SAT and IBM CP Optimizer for scheduling problems without requiring users to write propagator-level models.

  **Sources**:

- https://www.minizinc.org/challenge/2025/results/
- https://www.minizinc.org/challenge/
- https://developers.google.com/optimization/cp/cp_solver
- https://arxiv.org/pdf/2502.13483

