Texture compression is a set of techniques that store image textures in compact, GPU-decodable formats to reduce memory footprint and bandwidth during real-time rendering. Unlike general image compression, these formats support fast random access and fixed-rate block decoding directly in hardware, trading some image quality for large savings in storage and runtime cost. Common schemes include block-based formats such as BCn, ETC and ASTC.

### Overview

- Real-time graphics must fit large texture sets into limited GPU memory and bandwidth. Texture compression solves this with fixed-rate, block-based formats the GPU can decode on the fly during sampling, preserving random access for filtering and mipmapping. The chosen format balances quality, size and platform support across BCn, ETC and ASTC families.

### Mechanisms

- Fixed-rate, block-based encoding for random access.
- Hardware decoding during texture sampling.
- Format families: BCn/DXT, ETC and ASTC.
- Integration with mipmapping and level-of-detail.
- Quality-versus-size and platform trade-offs.

### Applications

- Game engines and real-time 3D rendering.
- AR/VR and spatial computing asset pipelines.
- Streaming large texture sets within GPU memory budgets.
- Mobile graphics with constrained bandwidth.

### Provenance

