A working group is a chartered subgroup of a standards organisation or collaborative body tasked with developing, reviewing and reaching consensus on a specific technical topic or deliverable. It brings together domain experts who draft specifications, resolve issues and progress documents through review and approval stages. Working groups are the principal unit of work through which formal standards and specifications are produced.

### Overview

- [[Working Group]] is situated within the standards domain and is defined as a subclass of [[Standards Body]].
- It connects to the wider knowledge graph through 16 typed relations spanning structural, functional and contrastive predicates.
- As a mature concept, it represents established knowledge with stable terminology and well-understood boundaries.

### Key aspects

- Relationship to [[Standards Body]] situates this concept within its operational and conceptual context.
- Relationship to [[Technical Committee]] situates this concept within its operational and conceptual context.
- Relationship to [[Consensus]] situates this concept within its operational and conceptual context.
- Relationship to [[Standards]] situates this concept within its operational and conceptual context.
- Relationship to [[Collaboration]] situates this concept within its operational and conceptual context.

### Mechanisms

- The concept is realised through its constituent parts and the standards, methods and dependencies enumerated in its relations.
- It both requires upstream capabilities and enables downstream capabilities, forming part of a directed chain of dependencies in the graph.

### Applications

- Practical use of [[Working Group]] appears wherever its enabled and supported concepts are deployed.
- It is referenced by existing classes in the graph, anchoring those edges to a defined, rooted node.

### Provenance

