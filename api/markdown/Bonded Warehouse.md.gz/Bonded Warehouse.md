A bonded warehouse, called a customs warehouse in United Kingdom and European Union usage, is a warehouse in which imported goods are stored under customs supervision with duty suspended until they are released or leave.[^1][^2][^3]

HM Revenue and Customs describes customs warehousing as a customs special procedure that allows importers to store goods while suspending duties and import VAT. The goods can then be declared to another procedure, re-exported or released to free circulation, when duties and VAT become due.[^1] The European Commission says non-EU goods stored in premises authorised by customs authorities are under supervision and not subject to import duties while they remain.[^2] US Customs and Border Protection defines a bonded warehouse as a building or other secured area in which imported dutiable merchandise may be stored, manipulated or undergo manufacturing operations without payment of duty for up to five years from the date of importation.[^3]

## Public and private warehouses

All three authorities distinguish public and private warehouses. In the UK a public customs warehouse is for businesses storing other people's goods, and a private one is for businesses storing their own, where the warehousekeeper and depositor are the same person.[^1] The European Commission says public customs warehouses can be used by any person, whereas private ones can be used by only one authorised person.[^2] The US statute, 19 U.S.C. 1555, says warehouses may be bonded for storing merchandise that belongs to the owners, known as private bonded warehouses, or for imported merchandise generally, known as public bonded warehouses.[^4]

## Differences between authorities

Time limits differ. The European Commission says storage may be for an unlimited period unless the goods could threaten health or the environment, while the US limit is five years.[^2][^3] In the UK a warehouse operator must be authorised by HMRC as a warehousekeeper.[^5] The US proprietor incurs liability under a warehouse bond on entry of goods.[^3] HMRC says only certain types of processing are allowed in a customs warehouse.[^5]

## Scope and distinctions

A bonded warehouse is a [[Warehouse Facility Type]] defined by legal status. Related customs ideas are covered at [[Customs Procedure]], [[Customs Duty]] and [[Free Trade Zone]].

## What the sources do not establish

Sources do not give the number of such warehouses or a UK time limit in the pages opened. The terms bonded, customs and public or private are used differently by each authority, and the page reports each in its own words.

[^1]: HM Revenue and Customs (GOV.UK), “Special procedure: customs warehousing - Introduction”. https://www.gov.uk/guidance/special-procedure-customs-warehousing/introduction
[^2]: European Commission, Directorate-General for Taxation and Customs Union, “Storage”. https://taxation-customs.ec.europa.eu/customs/customs-procedures-import-and-export/customs-operations/storage_en
[^3]: US Customs and Border Protection, “U.S. Customs and Border Protection Bonded Warehouse”. https://www.cbp.gov/sites/default/files/documents/bonded_20wh2_2.pdf
[^4]: Cornell Law School Legal Information Institute (text of 19 U.S.C. § 1555), “19 U.S. Code § 1555 - Bonded warehouses”. https://www.law.cornell.edu/uscode/text/19/1555
[^5]: HM Revenue and Customs (GOV.UK), “How to use a customs warehouse”. https://www.gov.uk/guidance/how-to-use-a-customs-warehouse

