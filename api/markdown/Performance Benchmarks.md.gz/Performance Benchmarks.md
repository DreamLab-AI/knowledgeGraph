Performance benchmarks are standardised, reproducible test suites and associated metric sets used to measure, compare, and rank the behavioural characteristics of software systems, hardware platforms, algorithms, or AI models under controlled or representative workload conditions. They quantify dimensions such as latency, throughput, resource utilisation, scalability, accuracy, and energy efficiency, enabling objective evaluation across vendors, versions, and deployment environments. Benchmark suites range from micro-benchmarks targeting isolated components to macro-benchmarks simulating realistic end-to-end workloads. Formal benchmark governance — through bodies such as SPEC, MLCommons, and TPC — establishes methodology rules, disclosure requirements, and result auditing to prevent benchmark gaming.

### Overview

- Performance benchmarks serve as the empirical backbone of system evaluation, providing a common language for comparing implementations that would otherwise be assessed subjectively.
- Unlike [[Unit Testing]] or [[Stress Testing]], benchmarks focus on quantitative, repeatable measurement under defined conditions — the same workload, the same hardware configuration, the same measurement window.
- Benchmarks are used across the entire computing stack: from CPU micro-architecture comparisons (SPECint, SPECfp) through database engine evaluations ([[TPC]]-C, TPC-H) to large language model throughput and quality assessments ([[MLPerf]]).
- The results of benchmarking directly feed into [[Capacity Planning]], [[Vendor Evaluation]], [[Service Level Objectives]], and procurement decisions in enterprise and cloud contexts.
- Benchmark validity depends critically on [[Reproducible Experiments]]: controlling for thermal throttling, background processes, JIT warm-up, and caching effects.

### Key Components

#### Workload Definition

- A benchmark's workload must represent the target use-case, whether that is database transaction throughput, image classification accuracy, or web request latency.
- [[Workload Profiling]] techniques extract representative operation mixes from production traces to ensure ecological validity.
- Synthetic workloads (e.g. Sysbench, TPC-C) offer full reproducibility; replay-based workloads offer realism.

#### Core Metrics

- **Latency** — time from request submission to response receipt; expressed as mean, p50, p95, p99, p999 percentiles.
- **Throughput** — operations, transactions, or tokens completed per unit time (requests/sec, tokens/sec).
- **[[Resource Utilisation]]** — CPU %, memory bytes, network I/O, storage I/O consumed per unit of work.
- **Scalability** — how throughput and latency degrade or improve as concurrency, data volume, or cluster size changes.
- **Accuracy / Quality** — for AI benchmarks, metric sets such as Top-1 accuracy, BLEU, ROUGE, BERTScore, or pass@k.
- **Energy efficiency** — performance per watt, increasingly important for [[Hardware Acceleration]] and green computing mandates.

#### Benchmark Anatomy

- **Harness** — orchestration code that provisions the system under test, injects load, and collects raw measurements.
- **Result reporter** — aggregates raw samples into summary statistics and formats them for disclosure.
- **Rules document** — defines legal vs. illegal optimisations, disclosure requirements, and auditing procedures.
- **Reference implementation** — a canonical, unoptimised implementation that sets a correctness baseline.

#### Benchmark Categories

- **Micro-benchmarks** — isolate a single subsystem (cache hit rate, memory bandwidth, floating-point throughput).
- **Component benchmarks** — evaluate one software layer (database engine, HTTP server, ML inference runtime).
- **System benchmarks** — end-to-end workloads across the full software stack.
- **AI/ML benchmarks** — [[MLPerf]] Training, [[MLPerf]] Inference, HELM (Holistic Evaluation of Language Models), BIG-bench, LMSYS Chatbot Arena.
- **Cloud benchmarks** — Cloud Harmony, PerfKit Benchmarker; account for multi-tenancy noise and variable network conditions.

### Applications and Use Cases

#### Hardware Procurement and Comparison

- Enterprise buyers use SPEC CPU, SPECjbb, and TPC benchmarks to compare server generations and vendors before purchasing.
- GPU vendors publish [[MLPerf]] results to demonstrate training and inference throughput for AI workloads.

#### Software Release Regression Detection

- [[Continuous Integration]] pipelines incorporate performance benchmarks as automated gates; a regression beyond a threshold blocks the release.
- Tools such as Criterion (Rust), JMH (Java), and Google Benchmark (C++) provide framework support for in-process microbenchmarking.

#### AI Model Evaluation

- [[AI Model Evaluation]] suites such as MMLU, HumanEval, GLUE, SuperGLUE, and [[MLPerf]] quantify capability and efficiency across model families and hardware targets.
- Inference benchmarks measure tokens-per-second, time-to-first-token (TTFT), and inter-token latency under batched and streaming conditions.

#### Cloud and Infrastructure Sizing

- [[Capacity Planning]] teams run synthetic benchmarks before migrating workloads to cloud environments to select instance types and auto-scaling parameters.
- [[Service Level Objectives]] are validated under benchmarked conditions before production rollout.

#### Compiler and Runtime Optimisation

- Language runtimes and JIT compilers use benchmark suites (Octane, Kraken, JetStream for JavaScript; Phoronix for Linux subsystems) as optimisation targets.

#### Regulatory and Procurement Compliance

- Government procurement frameworks in several jurisdictions require published benchmark results for IT acquisitions above threshold values.
- Energy efficiency benchmarks (SERT, SPECpower) feed directly into data-centre sustainability reporting.

### Standards and Governance

#### SPEC (Standard Performance Evaluation Corporation)

- Non-profit consortium founded in 1988 that produces and maintains CPU, workstation, server, cloud, and energy benchmarks.
- Key suites: SPEC CPU (integer/floating-point), SPECjbb (Java server), SPECvirt (virtualisation), SPEC Cloud IaaS, SPECworkstation.
- Results are peer-reviewed and must be published with full system configuration disclosure to be considered valid.

#### MLCommons / MLPerf

- Industry consortium (founded 2018) running [[MLPerf]] Training and Inference benchmark rounds for AI/ML hardware and software.
- Covers training convergence time and inference latency/throughput across datacenter and edge targets.
- Open-submission model with closed (optimised) and open (any technique) divisions.

#### TPC (Transaction Processing Performance Council)

- Defines database and data-warehouse benchmarks: TPC-C (OLTP), TPC-H (decision support), TPC-DS (complex analytics), TPC-E (brokerage workload).
- Published results must include price/performance and energy metrics alongside raw throughput figures.

#### LINPACK / TOP500

- HPL (High-Performance LINPACK) is the benchmark used to rank the TOP500 list of supercomputers, measuring dense-matrix floating-point throughput (FLOPS).
- Increasingly complemented by HPCG (High-Performance Conjugate Gradients) for memory-bound workload realism.

#### Emerging AI Evaluation Frameworks

- HELM (Stanford CRFM) provides holistic evaluation across accuracy, calibration, robustness, fairness, and efficiency dimensions for language models.
- LMSYS Chatbot Arena uses crowdsourced human preference ratings (Elo ranking) as an alternative to static benchmark saturation.
- BIG-bench (Beyond the Imitation Game benchmark) targets tasks believed to be beyond current model capabilities.

### Common Pitfalls and Anti-Patterns

- **Benchmark gaming** — optimising specifically for the benchmark workload rather than the general case; mitigated by result auditing and diverse workload coverage.
- **Benchmark saturation** — when model or system performance reaches ceiling on a benchmark, rendering it unable to differentiate further improvements (e.g. ImageNet Top-1 accuracy approaching human-level).
- **Thermal and power variance** — CPU/GPU throttling under sustained load invalidates reproducibility; controlled thermal environments or multiple run averages are required.
- **Micro-benchmark myopia** — optimising for isolated micro-benchmarks while ignoring end-to-end system behaviour.
- **Comparing incomparable configurations** — mixing results from different hardware generations, compiler flags, or batch sizes without normalisation.
- **Neglecting tail latency** — reporting only mean latency while ignoring p99/p999 percentiles, which dominate user-facing experience in distributed systems.

### Provenance

