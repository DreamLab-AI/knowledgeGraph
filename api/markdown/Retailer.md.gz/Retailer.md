A retailer is a business that sells goods to consumers. Eurostat's glossary describes retail trade as a form of trade in which goods are mainly purchased and resold to the consumer or end-user, generally in small quantities and in the state in which they were purchased by the retailer, or following minor transformations.[^1]

## Definitions in the sources

The United Nations ISIC defines retailing as the resale, without transformation, of new and used goods mainly to the general public for personal or household consumption or utilisation, by shops, department stores, stalls, mail-order houses, door-to-door sales persons, hawkers and peddlers, consumer cooperatives, auction houses and similar outlets.[^2] It adds that most retailers take title to the goods they sell, but some act as agents for a principal and sell on consignment or on a commission basis.[^2] The ISIC classifies retail trade first by type of sale outlet, in stores or not in stores.[^2]

The Industrial Ontologies Foundry defines a retailer as a person or business organisation who buys products from wholesalers and manufacturers and resells them to end users.[^3] It records several wordings in an explanatory note: a person or organisation that sells goods to the public in relatively small quantities for use or consumption rather than for resale, an organisation that buys from a manufacturer or distributor and resells to the ultimate consumer, and, in the GS1 wording, the party that sells directly to the ultimate consumer.[^3] The CSCMP wording in that note names global companies like Walmart and on-line stores like Amazon among retailers.[^3]

## Scope and distinctions

A retailer is a kind of [[Supply Chain Organisations]] role and sits downstream of the [[Wholesaler]]. Examples with their own pages are [[Walmart]] and [[Amazon]]. The online channel is covered under [[E-Commerce]] and [[Platform Economy]].

The IOF's own example of the role is slightly wider than the consumer definition: Home Depot has a retailer role when it sells construction materials to contractors.[^3] The ISIC separates wholesale from retail by the predominant type of customer, so a business that sells mostly to contractors could fall on either side of that line.[^2]

## What the sources do not establish

Sources do not define a boundary between small and large quantities, nor do they say where a producer that sells direct to consumers belongs. They give no market-size figures.

[^1]: Eurostat, Statistics Explained, “Glossary:Retail trade”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Retail_trade
[^2]: United Nations Statistics Division, “International Standard Industrial Classification of All Economic Activities (ISIC), Revision 4”. https://unstats.un.org/unsd/classifications/Econ/Download/In%20Text/ISIC_Rev_4_publication_English.pdf
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

