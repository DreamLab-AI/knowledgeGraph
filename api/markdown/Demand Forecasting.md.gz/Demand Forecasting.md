Demand forecasting is the prediction of future demand for a product by analysing historical and contemporary data.[^1][^2]

An open operations management textbook defines forecasting as the process of predicting future events or trends by analysing historical and contemporary data, most commonly through trend analysis. It says that practice includes formal statistical methods using time series, cross-sectional or longitudinal data, and less formal judgmental methods, and that the uncertainty attached to a forecast should be explicitly communicated.[^1] Goetschalckx describes short-term forecasting by logisticians as extrapolating historical observations, often with a seasonal pattern.[^2]

## Methods

The NIST handbook defines a time series as an ordered sequence of values of a variable at equally spaced time intervals and says time series models are used to understand the structure behind the data and to forecast. It names Box-Jenkins ARIMA models and Holt-Winters exponential smoothing (single, double, triple) among the methods, and sales forecasting and inventory studies among the applications.[^3] A vendor blog adds that traditional time-series techniques used by retailers and consumer goods companies model trend and seasonality.[^4]

## Role in planning

Chopra and Meindl write that demand forecasts form the basis of all supply chain planning, and give a six-step approach: understand the objective of forecasting, integrate demand planning and forecasting throughout the supply chain, understand customer segments, identify the major factors that influence the forecast, choose a technique, and establish performance and error measures.[^5] Jatta says that forecasts are prone to error because of demand variability and other uncertainties.[^6] See [[Demand Planning]], [[Demand Sensing]] and [[Supply Chain Planning]].

## What the sources do not establish

None of the sources opened here compares methods or reports accuracy for supply chain demand, and the earlier body of this page, which was unsourced, was replaced.[^1]

[^1]: Operations Management open textbook, eCampusOntario Pressbooks, section 3.2, “The Role of Forecasting in Marketing Strategy”. https://ecampusontario.pressbooks.pub/opsmgmt/chapter/3-2-the-role-of-forecasting-in-marketing-strategy/
[^2]: Marc Goetschalckx, Georgia Institute of Technology course text, “Chapter 2. Forecasting”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/forecasting/forecasting.pdf
[^3]: NIST/SEMATECH e-Handbook of Statistical Methods, “6.4.1. Definitions, Applications and Techniques”. https://www.itl.nist.gov/div898/handbook/pmc/section4/pmc41.htm
[^4]: Charlie Chase, SAS Voices blog (SAS Institute, a software vendor), 19 October 2020, “Is short-term demand sensing a key component of your digital supply chain transformation?”. https://blogs.sas.com/content/sascom/2020/10/19/is-short-term-demand-sensing-a-key-component-of-your-digital-supply-chain-transformation/
[^5]: Sunil Chopra and Peter Meindl, Supply Chain Management textbook chapter (copy hosted by Indiana University Kelley School of Business), “Chapter 7: Demand Forecasting in a Supply Chain”. https://host.kelley.iu.edu/mabert/e730/chopra-chap-7.pdf
[^6]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content

