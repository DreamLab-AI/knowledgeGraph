Freight consolidation is the combining of several small shipments into one larger shipment that is moved as a single load.[^1]

Maersk's glossary defines consolidation as combining less-than-full-load shipments (LTL or LCL) into one shipment at a centrally located point of origin, handled by a freight consolidator and carried as a single shipment to a destination. It adds that consolidation of cargo often results in reduced shipping rates.[^1] Georgia Tech's warehouse textbook gives the underlying economics: there is a fixed cost any time product is transported, so to amortise it the carrier has to be filled to capacity, and a distributor may therefore consolidate shipments from vendors into large shipments for downstream customers.[^2]

## In ocean freight

Flexport describes an LCL shipment consolidated with other LCL shipments into one container at a container freight station before it gates in at the container yard at origin, and deconsolidated at destination.[^3] Maersk describes a container freight station as a facility at a port or an inland location where goods are loaded into or unloaded from containers, with a focus on consolidation and deconsolidation of cargo.[^4] Maersk's glossary notes that consolidating several LCL loads from different places or shippers into a full container can save on costs, because ocean rates for LCL are commonly higher per unit than for a full container load.[^1] The unconsolidated counterpart is [[Full Container Load]].

## In road freight and terminals

For road freight, Bartholdi and Hackman say LTL means sending shipments that do not fill a trailer, and that an LTL freight company consolidates many such shipments and so achieves efficiencies.[^2] They give the reduction of transportation costs by consolidating multiple shipments into full truck loads as the biggest reason to have a crossdock.[^2] See [[Cross-Docking]]. Rodrigue and Slack note that freight must be consolidated at a distribution centre, a port or a rail yard before shipment, and Notteboom, Pallis and Rodrigue describe the port as a point of load break where cargo is stored, consolidated or deconsolidated.[^5][^6]

## Evidence limits

No opened source offers a standard or legal definition of the term. The ocean and glossary material is commercial, and the “centrally located point of origin” wording belongs to Maersk's glossary alone.[^1] Customs treatment of consolidated shipments is not covered by these sources.[^3][^4]

[^1]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms
[^2]: John J. Bartholdi III and Steven T. Hackman, Georgia Institute of Technology, “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^3]: Flexport, “LCL (Less than Container Load)”. https://www.flexport.com/glossary/less-than-container-load/
[^4]: Maersk, “Understanding CFS and CY Logistics in Freight Shipping”. https://www.maersk.com/logistics-explained/transportation-and-freight/2024/07/02/cfs-cy-logistics
[^5]: Jean-Paul Rodrigue and Brian Slack, The Geography of Transport Systems, “6.1 – The Function of Transport Terminals”. https://transportgeography.org/contents/chapter6/function-of-transport-terminals/
[^6]: Theo Notteboom, Athanasios Pallis and Jean-Paul Rodrigue, Port Economics, Management and Policy, “Chapter 0.1 – Defining Seaports”. https://porteconomicsmanagement.org/pemp/contents/introduction/defining-seaports/

