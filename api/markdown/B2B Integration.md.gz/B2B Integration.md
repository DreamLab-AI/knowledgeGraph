B2B integration is the electronic exchange of structured business messages between the systems of trading partners.[^1][^2][^3]

No source opened defines the term, so the page describes the layers its sources cover. At the level of messages, GS1 says its EDI standards provide global standards for electronic business messaging that allow automation of business transactions across the supply chain, covering master data alignment, order, delivery and financial settlement, and transport and warehouse management.[^1] GS1 has four complementary sets of standards: business terms, EANCOM, GS1 XML and GS1 UN/CEFACT XML.[^1]

## Transport

IETF RFC 4130, the AS2 specification, describes how to exchange structured business data securely using the HTTP transfer protocol instead of SMTP.[^2] The structured data may be XML, EDI in the ANSI X12 or UN/EDIFACT formats, or other structured formats.[^2] AS2 therefore defines secure delivery between partners and leaves the message content to other standards.[^2]

## Definitions of EDI

A NIST report from the mid-1990s says that the part of electronic commerce concerned with the actual interchange of business transactions is called electronic data interchange.[^3] See [[Electronic Data Interchange]] and [[Supply Chain Information Systems]].

## Scope and distinctions

Those three sources cover messages and their transport, and none describes how messages are connected to each firm's internal systems.[^1][^2][^3]

## What the sources do not establish

The NIST report is a 1990s document and the AS2 specification dates from 2005, so the page describes established standards and not recent API-based approaches. No source opened compares EDI with other integration methods or gives adoption figures.[^1][^2][^3]

[^1]: GS1, “GS1 Electronic Data Interchange (EDI) - Standards”. https://www.gs1.org/standards/edi
[^2]: D. Moberg and R. Drummond, IETF RFC 4130, July 2005, “MIME-Based Secure Peer-to-Peer Business Data Interchange Using HTTP, Applicability Statement 2 (AS2)”. https://www.rfc-editor.org/rfc/rfc4130.txt
[^3]: National Institute of Standards and Technology, NISTIR 5631, “Electronic Data Interchange (EDI) Standards”, analysis of ANSI ASC X12 and UN/EDIFACT. https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir5631.pdf

