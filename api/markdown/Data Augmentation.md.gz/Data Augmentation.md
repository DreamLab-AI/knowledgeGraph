Data augmentation is a machine learning technique that expands a training dataset by applying label-preserving transformations or synthesising new examples from existing data. Typical methods include geometric and photometric image transforms, noise injection, and generative model sampling such as GAN-produced samples, diffusion-model synthesis, and mixing-based strategies such as Mixup and CutMix. It improves model generalisation and robustness, mitigating overfitting when labelled data is scarce. Modern automated augmentation pipelines such as AutoAugment and RandAugment use reinforcement learning or random search to discover optimal policies, while 2024-2026 diffusion-based approaches such as DiffuseMix enable label-preserving generation of high-fidelity training examples that improve performance on imbalanced and low-resource benchmarks.

### Semantic Classification

### Content

## Compositional Relationships (Components)

```
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:hasPart ai:GeometricTransformation))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:hasPart ai:PhotometricTransformation))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:hasPart ai:NoiseInjection))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:hasPart ai:MixupAugmentation))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:hasPart ai:CutMix))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:hasPart ai:AutoAugment))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:hasPart ai:RandAugment))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:hasPart ai:FeatureSpaceAugmentation))
```

## Dependency Relationships

```
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:requires ai:TrainingDataset))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:requires ai:TrainingPipeline))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:requires ai:DataPreprocessing))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:dependsOn ai:LabelPreservationConstraint))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:dependsOn ai:DomainKnowledge))
```

## Capability Relationships

```
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:enables ai:ModelGeneralisation))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:enables ai:OverfittingPrevention))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:enables ai:ModelRobustness))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:enables ai:ClassImbalanceMitigation))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:enables ai:LowResourceLearning))
```

## Implementation Relationships

```
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:implements ai:RegularisationStrategy))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:implements ai:BiasVarianceTradeoff))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:uses ai:GenerativeAdversarialNetworks))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:uses ai:DiffusionModel))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:uses ai:VariationalAutoencoder))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:uses ai:ReinforcementLearning))
```

## Reduction Relationships

```
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:reducesTo ai:LabelPreservingTransformation))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:reducesTo ai:SyntheticDataGeneration))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:reducesTo ai:DistributionShiftMitigation))
```

## Support Relationships

```
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:SupervisedLearning))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:SemiSupervisedLearning))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:SelfSupervisedLearning))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:FewShotLearning))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:TransferLearning))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:ComputerVision))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:NaturalLanguageProcessing))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:SpeechRecognition))
SubClassOf(ai:DataAugmentation
  ObjectSomeValuesFrom(ai:supports ai:MedicalImaging))
```

## About

- Data augmentation emerged as a systematic practice in the early deep learning era, canonically associated with AlexNet (Krizhevsky et al., 2012), where random cropping and horizontal flipping of ImageNet images contributed substantially to its then state-of-the-art accuracy. The intuition is straightforward: a model trained on more diverse inputs must learn invariances rather than memorise superficial statistical regularities of a small corpus. When framed probabilistically, augmentation is equivalent to applying a prior over transformations believed to be semantically neutral for the task at hand, thereby regularising the hypothesis space implicitly without adding explicit penalty terms to the loss function.
- The 2018-2020 period brought a wave of policy-search approaches. AutoAugment (Cubuk et al., 2019) treated augmentation policy discovery as a discrete optimisation problem solved with a proximal policy gradient algorithm, finding non-obvious strategies such as applying shear-X followed by equalization that outperformed heuristic pipelines on CIFAR-10, CIFAR-100, and ImageNet. RandAugment (Cubuk et al., 2020) simplified this significantly, replacing the exponential search space with just two hyperparameters — the number of operations and the magnitude — and achieving comparable or superior performance. TrivialAugment (Müller and Hutter, 2021) went further, demonstrating that uniform random sampling across the augmentation magnitude range, with zero hyperparameters, matched or exceeded elaborate search schemes, challenging the assumption that sophisticated policy learning is necessary.
- The 2022-2026 period has been defined by generative model-based augmentation. Diffusion models in particular have demonstrated capacity to produce high-fidelity, diverse, and semantically controllable training examples. DiffuseMix (CVPR 2024) combines a diffusion generator with a mixing strategy, producing blended images with soft labels that preserve fine-grained class distinctions. A 2026 mathematical framework developed at UNIST formalised the conditions under which augmentation provably improves distributional robustness, grounding the empirical success in learning theory and opening avenues for principled policy design. Industry adoption in 2026 spans virtually all domains that rely on [[Deep Learning]]: autonomous vehicles (LiDAR and camera augmentation), clinical AI (augmenting rare pathology images), financial fraud detection (synthetic transaction records), and natural language tasks including machine translation, question answering, and instruction tuning of large language models.

## Components and Architecture

- **Geometric Transformations** — random cropping, resizing, horizontal and vertical flipping, rotation, shear, perspective warp, affine transformation. These exploit spatial invariance properties known to hold for most visual recognition tasks.
- **Photometric Distortions** — colour jitter (hue, saturation, brightness, contrast randomisation), random greyscale conversion, Gaussian blur, sharpening, solarisation, posterisation. They exploit the fact that semantic class identity is independent of illumination conditions.
- **Noise Injection** — additive Gaussian noise, salt-and-pepper noise, random erasing (simulating occlusion), Cutout (DeVries and Taylor, 2017), GridMask. These force the model to use distributed rather than spatially localised features.
- **Interpolation Strategies** — Mixup (Zhang et al., 2018) creates convex combinations of two training examples and their one-hot labels; CutMix (Yun et al., 2019) replaces a rectangular patch with one from another image and mixes labels proportionally to area; SaliencyMix and SnapMix use class activation maps to guide the mixing region, preserving discriminative regions.
- **Automated Policy Search** — AutoAugment (Cubuk et al., 2019), RandAugment (Cubuk et al., 2020), Fast AutoAugment, Population Based Augmentation (PBA), TrivialAugment. These meta-learning approaches discover effective transformation sequences from data rather than domain knowledge.
- **Generative Augmentation** — [[Generative Adversarial Networks]] (conditional GANs, StyleGAN) generate realistic synthetic examples with controllable class labels; [[Variational Autoencoder]] interpolations create in-class diversity; [[Diffusion Model]] pipelines (DiffuseMix, GenMix, CamDiff) synthesise photorealistic augmentations conditioned on existing images and text prompts.
- **Feature-Space Augmentation** — FeatMatch, ISDA (Implicit Semantic Data Augmentation), and manifold mixup perform interpolation in the latent space of a neural network rather than in pixel space, producing smoother decision surfaces.
- **Text Augmentation** — synonym replacement, random insertion/deletion/swap (Wei and Zou, EDA, 2019), back-translation (Sennrich et al., 2016), contextual word substitution via masked language models (BERT-based), sentence paraphrasing with GPT-class models.
- **Audio and Time-Series Augmentation** — SpecAugment (Park et al., 2019) masks frequency and time bands in spectrograms for [[Speech Recognition]]; jittering, window slicing, permutation, and warping are standard for time-series classification.

## Augmentation Families and Variants

- **Classical Hand-Crafted** — the baseline toolkit used since AlexNet; dataset-specific but requires human expert to define the invariance set. Fast to implement, no additional learnable parameters.
- **Policy-Search Automated** — AutoAugment, RandAugment, PBA, Fast AutoAugment, TrivialAugment. Reduce human bias but require significant GPU budget for search (AutoAugment) or accept a principled random approximation (TrivialAugment).
- **Mixing-Based** — Mixup, CutMix, SaliencyMix, SnapMix, DiffuseMix, Puzzlemix. Particularly effective for training [[Convolutional Neural Networks]] and vision [[Transformer Architecture]] models; improve calibration and adversarial robustness.
- **Generative Model-Based** — GAN-based, VAE-based, diffusion-based. Highest fidelity but require trained generators and careful quality filtering; risk distributional shift if the generator has captured training set biases.
- **Self-Supervised Augmentation** — SimCLR, MoCo, BYOL, DINO define augmentation pipelines as the core mechanism for learning visual representations; the augmentation policy directly determines which invariances are encoded in the representation.
- **Domain-Specific** — in [[Medical Imaging]], elastic deformations and stain normalisation; in satellite imagery, radiance variation and geometric distortion; in NLP, domain-specific paraphrase models; in LiDAR, point-cloud rotation and intensity dropout.

## Use Cases and Applications

- **Medical and Clinical AI** — [[Medical Imaging]] datasets (chest X-rays, histopathology slides, MRI volumes) are chronically small and class-imbalanced. Augmentation, especially elastic deformation and GAN-based synthesis, is the primary mechanism enabling clinically deployable classification performance without expensive additional annotation campaigns.
- **Autonomous Vehicles** — camera and LiDAR augmentation (weather synthesis, lighting variation, sensor noise simulation) improves robustness to rare but safety-critical distribution shifts such as fog, rain, night-time operation.
- **Natural Language Processing** — back-translation for low-resource machine translation; EDA for text classification; paraphrasing for instruction fine-tuning data diversity; adversarial sentence perturbation for robustness evaluation.
- **[[Speech Recognition]]** — SpecAugment reduces word error rates on large benchmarks and has become a default component of Conformer and Whisper-class models.
- **[[Few-Shot Learning]]** — augmentation is critical when only 1-5 labelled examples are available per class; few-shot benchmarks such as miniImageNet and tieredImageNet show consistent improvement from mixing-based augmentation.
- **Fraud and Anomaly Detection** — class-imbalanced tabular datasets in financial services use SMOTE, ADASYN, and conditional GAN synthesis to address the rarity of positive (fraudulent) examples.
- **Industrial Quality Inspection** — defect images are rare; GAN-based augmentation generates diverse defect morphologies, improving automated visual inspection recall.
- **[[Object Detection]]** — multi-scale crop, mosaic augmentation (YOLOv5/v8 approach combining four images), copy-paste augmentation all contribute to detection robustness.

## Academic Context

- Data augmentation as a systematic technique traces to convolutional network research of the early 2010s. The AlexNet paper (Krizhevsky, Sutskever, and Hinton, 2012) documented random cropping and horizontal flipping as explicit design choices that contributed to generalisation. The subsequent decade produced increasingly sophisticated augmentation taxonomies. The NLP analogue was catalysed by Sennrich et al. (2016), who demonstrated that back-translation — augmenting a low-resource translation corpus by translating target-side monolingual data back into the source language — dramatically improved neural machine translation quality. Zhang et al. (2018) introduced Mixup as a theoretically grounded vicinal risk minimisation approach. The AutoAugment line of work (Cubuk et al., Google Brain, 2019) demonstrated that policy search could discover non-obvious but highly effective augmentation sequences. The mixing literature expanded rapidly with CutMix (Yun et al., NAVER AI Lab, 2019), Puzzlemix (Kim et al., KAIST, 2020), and SaliencyMix (Uddin et al., 2021). The self-supervised learning literature — SimCLR (Chen et al., 2020), MoCo (He et al., 2020), BYOL (Grill et al., 2020), DINO (Caron et al., 2021) — elevated augmentation policy choice to a first-class architectural decision, demonstrating that the augmentation distribution defines what invariances are encoded in representations. The 2025 Springer review "Advances in diffusion models for image data augmentation" surveyed the emerging diffusion-based paradigm comprehensively, while a Virginia Tech comprehensive survey (2026) provided the most current taxonomy of the field.
- Key institutions include Google Brain (AutoAugment, RandAugment, CutOut, SimCLR), NAVER AI Lab (CutMix), KAIST (Puzzlemix), MIT (manifold mixup), UNIST (2026 robustness framework), and in the UK, the Machine Learning Group at the University of Cambridge (Ghahramani group), the UCL AI Centre, and medical imaging groups at Imperial College London's Department of Computing.

## Current Landscape (2026)

- By 2026, data augmentation is considered a non-negotiable component of virtually every production deep learning training pipeline. The tooling ecosystem has matured: major frameworks (PyTorch via Torchvision and Albumentations, TensorFlow/Keras, JAX via scenic) provide high-performance, GPU-accelerated augmentation primitives. The Albumentations library (Buslaev et al.) supports over 70 transform types and has become the de facto standard for [[Computer Vision]] augmentation. In the large language model domain, [[Self-Supervised Learning]] at scale has partially displaced the need for explicit text augmentation, but instruction fine-tuning and alignment training still rely heavily on augmented synthetic data pipelines.
- A January 2026 mathematical framework from UNIST published via TechXplore provides the first rigorous characterisation of when and how augmentation improves distributional robustness, distinguishing augmentation policies that provably reduce worst-case generalisation error from those that merely reduce average-case error. This theoretical grounding is enabling more systematic, principled policy design rather than purely empirical search. A comprehensive 2026 survey from Virginia Tech (Lu et al.) provides the most current taxonomy covering over 200 augmentation methods across modalities.
- In industry, the rise of [[Foundation Model]] and multimodal pre-training has introduced a new role for augmentation: curating and diversifying the pre-training corpus itself. Diffusion model-based synthetic data generation is being used by major AI labs to fill distributional gaps in pre-training datasets, with controlled experiments demonstrating improved downstream performance across [[Image Classification]], [[Object Detection]], and multi-modal retrieval benchmarks. AutoML platforms such as Google AutoML Vision, Azure Machine Learning, and H2O.ai now automatically search augmentation policies as part of their neural architecture and hyperparameter optimisation loops.

## UK Context

- The UK has significant research capacity in data augmentation and related machine learning methodology. The University of Edinburgh's School of Informatics hosts the Institute for Language, Cognition and Computation, which has contributed substantially to NLP augmentation via back-translation and low-resource neural machine translation. UCL's AI Centre (founded 2019) includes multiple research groups working on generative models applicable to augmentation pipelines. The Cambridge Machine Learning Group (Zoubin Ghahramani's lab) has long-standing contributions to Bayesian approaches to data efficiency that complement classical augmentation. Imperial College London's Department of Computing and the BioMedIA group have produced influential work on augmentation for [[Medical Imaging]], particularly elastic deformations for MRI segmentation and stain augmentation for histopathology. Lenovo and Imperial's 2026 London AI Technology Centre collaboration signals growing industry investment in UK AI infrastructure, with augmentation pipelines for vision tasks cited as a priority workload.
- In Northern England, the National Health Service's reliance on AI for diagnostic imaging in hospital trusts across Manchester, Leeds, Sheffield, and Newcastle has driven applied research in medical image augmentation. The Alan Turing Institute in London coordinates cross-university augmentation research in healthcare and climate modelling. UKRI Innovate UK has funded several programmes exploring synthetic data generation (a related technique) for sectors including manufacturing quality inspection and agricultural crop disease detection, where labelled dataset scarcity is acute. The Francis Crick Institute in London applies augmentation pipelines to cell imaging datasets, and the Wellcome Sanger Institute uses augmentation for genomic sequence classification tasks.

## Future Directions (2026-2030)

- **Foundation Model-Guided Augmentation** — large multimodal models will increasingly serve as semantic validators, accepting or rejecting synthesised augmentations based on whether they preserve task-relevant invariants, replacing human-curated invariance specifications.
- **Automated Augmentation via Meta-Learning** — the next generation beyond RandAugment will use gradient-based meta-learning to adapt augmentation policies to specific model architectures, dataset characteristics, and training stages in real time, converging on optimal policies without expensive separate search runs.
- **Diffusion-Based Counterfactual Augmentation** — conditioning diffusion models on causal intervention operators (do-calculus) to produce counterfactual training examples that fill specific causal gaps in the training distribution, particularly for fairness and robustness certification.
- **Augmentation for Alignment** — as LLM alignment and RLHF become standard, augmentation of preference data (generating diverse human-preference-compatible response pairs) will emerge as a critical bottleneck, with automated preference augmentation pipelines becoming a distinct subfield.
- **Theoretical Convergence** — following the 2026 UNIST framework, the field is expected to produce rigorous sample complexity results quantifying exactly how much augmentation reduces the labelled data requirement under specific distribution shift models, enabling principled decisions about augmentation budget.
- **Privacy-Preserving Augmentation** — as training data privacy requirements tighten under UK GDPR and the forthcoming Data Use and Access Bill, differentially private augmentation methods that inject calibrated noise into the generation process while preserving utility will become a compliance requirement rather than a research curiosity.
- **Cross-Modal Augmentation** — augmenting one modality (text) to improve another (vision, audio) through paired generative models, enabling cheap augmentation of expensive multi-modal datasets.

## Formal Analysis

- Data augmentation can be formalised within the vicinal risk minimisation (VRM) framework proposed by Chapelle et al. (2000). In standard empirical risk minimisation (ERM), a model is trained to minimise average loss over the empirical distribution defined by the labelled training set. VRM replaces each point mass in the training distribution with a probability density — a vicinal distribution — centred on each training example. The key insight is that any label-preserving data augmentation scheme corresponds to a choice of vicinal distribution: geometric transforms induce a spatial vicinity, colour jitter induces a photometric vicinity, and Gaussian noise injection induces a Gaussian vicinity around each training point. The training objective under VRM is:
  $$R_{\text{VRM}}(f) = \mathbb{E}_{(\tilde{x}, \tilde{y}) \sim \hat{p}_\nu} [\ell(f(\tilde{x}), \tilde{y})]$$
  where $\hat{p}_\nu$ is the vicinal distribution and $\ell$ is the task loss. Mixup (Zhang et al., 2018) generalises VRM by defining the vicinal distribution as a convex combination of all training example pairs: $\tilde{x} = \lambda x_i + (1-\lambda) x_j$, $\tilde{y} = \lambda y_i + (1-\lambda) y_j$, with $\lambda \sim \text{Beta}(\alpha, \alpha)$. This is equivalent to minimising expected loss under a distribution over all linear interpolations of the training data, which promotes linearity of the learned function between training examples and improves calibration.
- From a learning theory perspective, data augmentation serves two distinct functions. First, it increases the effective sample size $n$, tightening generalisation bounds that scale as $O(\sqrt{d/n})$ for a model family of VC dimension $d$ or Rademacher complexity $\mathcal{R}$. Second, it encodes task-specific invariances — rotational invariance for digit recognition, translation invariance for object detection — as hard constraints on the learned function, reducing the effective hypothesis space and consequently tightening the bound independently of sample count. The 2026 UNIST framework formalises this distinction, providing conditions on the augmentation distribution under which the augmented model provably achieves lower worst-case loss over a specified set of distribution shifts, versus conditions under which augmentation only reduces average-case but not worst-case error.
- Augmentation policies can be evaluated through the lens of information theory. An ideal augmentation strategy should maximise the diversity of augmented examples — measured by the entropy of the augmented distribution — while preserving the mutual information between augmented inputs and their labels (semantic content). Augmentations that reduce label-relevant information (e.g., heavy blurring that destroys fine-grained class-discriminative texture) fail the second criterion and empirically degrade performance. The self-supervised contrastive learning community (SimCLR, MoCo, DINO) formalises this as a requirement that augmented views of the same image share maximal task-relevant information while differing maximally in task-irrelevant nuisance dimensions, which can be operationalised as maximising $I(\tilde{x}_1; \tilde{x}_2) - I(\tilde{x}_1; y)$ where $\tilde{x}_1, \tilde{x}_2$ are two augmented views of the same image.
- Augmentation policy search can be cast as a bilevel optimisation problem: the inner loop trains a model $f_\theta$ under a fixed augmentation policy $\pi$, and the outer loop updates $\pi$ to minimise validation loss of the resulting model. AutoAugment solves this approximately using a policy gradient controller; Population Based Augmentation (PBA) uses a Bayesian optimisation approach; Fast AutoAugment uses density matching to bypass explicit inner loop training; and the 2026 generation is exploring gradient-based bilevel approaches using implicit differentiation (DARTS-style) to make policy search tractable at scale without requiring separate search compute budgets.

## Key Terminology

- **Data Augmentation** — expansion of a training dataset through label-preserving transformations or generative synthesis.
- **Label-Preserving Transformation** — any transformation that alters the input representation without changing the ground-truth label; the foundational constraint on any augmentation operation.
- **Vicinal Risk Minimisation (VRM)** — generalisation of ERM that defines a probability vicinity around each training example, within which loss is minimised; the theoretical framework that unifies all augmentation strategies.
- **Mixup** — augmentation strategy that creates training examples as convex combinations of two training inputs and their labels; promotes smooth interpolation in the input space.
- **CutMix** — augmentation strategy that replaces a rectangular region of one image with a patch from another, mixing labels proportionally to the area of the replaced patch.
- **AutoAugment** — reinforcement-learning-based augmentation policy search framework; finds optimal sequences of augmentation operations from a predefined search space.
- **RandAugment** — simplified policy search using only two hyperparameters (number of operations, magnitude); achieves near-AutoAugment performance with far lower search cost.
- **TrivialAugment** — zero-hyperparameter augmentation approach using uniform random sampling of operation magnitudes; baseline that is competitive with elaborate search-based methods.
- **SpecAugment** — augmentation for acoustic spectrogram representations; masks time and frequency bands to improve ASR model robustness.
- **EDA (Easy Data Augmentation)** — NLP augmentation suite: synonym replacement, random insertion, random swap, random deletion; improves text classification with minimal implementation cost.
- **DiffuseMix** — diffusion model-based label-preserving augmentation published at CVPR 2024; combines generative synthesis with mixing to produce high-fidelity diverse training examples.
- **Distribution Shift** — difference between training-time and test-time input distributions; the primary failure mode that augmentation is designed to mitigate.
- **Vicinal Distribution** — the probability density centred on each training example within VRM; the augmentation policy defines the shape of this distribution.
- **Albumentations** — the de facto standard [[Computer Vision]] augmentation library (Python/PyTorch); provides GPU-accelerated implementations of over 70 transform types.

## Research and Literature

- 1. Krizhevsky, A., Sutskever, I., Hinton, G.E. (2012). ImageNet Classification with Deep Convolutional Neural Networks. *NeurIPS 2012*.
- 2. Sennrich, R., Haddow, B., Birch, A. (2016). Improving Neural Machine Translation Models with Monolingual Data (Back-Translation). *ACL 2016*.
- 3. DeVries, T., Taylor, G.W. (2017). Improved Regularization of Convolutional Neural Networks with Cutout. *arXiv:1708.04552*.
- 4. Zhang, H., Cisse, M., Dauphin, Y.N., Lopez-Paz, D. (2018). Mixup: Beyond Empirical Risk Minimization. *ICLR 2018*.
- 5. Cubuk, E.D., Zoph, B., Mané, D., Vasudevan, V., Le, Q.V. (2019). AutoAugment: Learning Augmentation Strategies from Data. *CVPR 2019*.
- 6. Yun, S., Han, D., Oh, S.J., Chun, S., Choe, J., Yoo, Y. (2019). CutMix: Training Strategy that Makes Use of Sample Pairing. *ICCV 2019*.
- 7. Cubuk, E.D., Zoph, B., Shlens, J., Le, Q.V. (2020). RandAugment: Practical Automated Data Augmentation with a Reduced Search Space. *NeurIPS 2020*.
- 8. Chen, T., Kornblith, S., Norouzi, M., Hinton, G. (2020). A Simple Framework for Contrastive Learning of Visual Representations (SimCLR). *ICML 2020*.
- 9. Grill, J.B., et al. (2020). Bootstrap Your Own Latent: A New Approach to Self-Supervised Learning (BYOL). *NeurIPS 2020*.
- 10. Park, D.S., et al. (2019). SpecAugment: A Simple Data Augmentation Method for Automatic Speech Recognition. *Interspeech 2019*.
- 11. Kim, J., Choo, W., Song, H.O. (2020). Puzzlemix: Exploiting Saliency and Local Statistics for Optimal Mixup. *NeurIPS 2020*.
- 12. Müller, S.G., Hutter, F. (2021). TrivialAugment: Tuning-Free Yet State-of-the-Art Data Augmentation. *ICCV 2021*.
- 13. Caron, M., et al. (2021). Emerging Properties in Self-Supervised Vision Transformers (DINO). *ICCV 2021*.
- 14. Buslaev, A., Iglovikov, V.I., Khvedchenya, E., Parinov, A., Druzhinin, M., Kalinin, A.A. (2020). Albumentations: Fast and Flexible Image Augmentations. *Information 2020*.
- 15. Wei, J., Zou, K. (2019). EDA: Easy Data Augmentation Techniques for Boosting Performance on Text Classification Tasks. *EMNLP 2019*.
- 16. Li, Z., Liu, F., Yang, W., Peng, S., Zhou, J. (2022). A Survey of Convolutional Neural Networks: Analysis, Applications, and Prospects. *IEEE Transactions on Neural Networks and Learning Systems*.
- 17. Shorten, C., Khoshgoftaar, T.M. (2019). A Survey on Image Data Augmentation for Deep Neural Networks. *Journal of Big Data, 6(60)*.
- 18. Bergman, L., Hoshen, Y. (2020). Classification-Based Anomaly Detection for General Data. *ICLR 2020*.
- 19. Zhong, Z., Zheng, L., Kang, G., Li, S., Yang, Y. (2020). Random Erasing Data Augmentation. *AAAI 2020*.
- 20. Islam, Md.Z., Samsel, F., et al. (2024). Enhancing Image Classification with Augmentation Techniques. *arXiv:2502.18691*.
- 21. Singh, P., et al. (2024). DiffuseMix: Label-Preserving Data Augmentation with Diffusion Models. *CVPR 2024*. https://diffusemix.github.io/
- 22. Li, A., et al. (2025). Advances in diffusion models for image data augmentation: a review of methods, models, evaluation metrics and future research directions. *Artificial Intelligence Review, Springer Nature, 2025*. https://link.springer.com/article/10.1007/s10462-025-11116-x
- 23. Lu, C., et al. (2026). A Comprehensive Survey on Data Augmentation. Virginia Tech. https://people.cs.vt.edu/~clu/Publication/2026/Survey_on_Data_Augmentation-2026.pdf
- 24. TechXplore (2026). New framework pinpoints conditions that make data augmentation improve robustness. UNIST. https://techxplore.com/news/2026-01-framework-conditions-augmentation-robustness.html
- 25. Uddin, S., Mondal, T.K., Ali, S.A. (2021). SaliencyMix: A Saliency Guided Data Augmentation Strategy for Better Regularization. *ICLR 2021*.
- 26. Islam, A., et al. (2021). Shape or Texture: Understanding Discriminative Features in CNNs. *ICLR 2021*.
- 27. Feng, S.Y., et al. (2021). A Survey of Data Augmentation Approaches for NLP. *ACL-Findings 2021*.
- 28. Mumuni, A., Mumuni, F. (2022). Data augmentation: A comprehensive survey of modern approaches. *Array (Elsevier), 2022*. https://www.sciencedirect.com/science/article/pii/S2590005622000911

### Provenance

