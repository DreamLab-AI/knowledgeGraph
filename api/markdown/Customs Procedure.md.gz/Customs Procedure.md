A customs procedure is a regime under which goods are placed when they are dealt with by customs authorities, and it fixes which duties, measures and formalities apply to them.[^1][^2]

The Union Customs Code defines a customs procedure as any of three procedures under which goods may be placed: release for free circulation, special procedures and export.[^1] Special procedures fall into four categories: transit, storage (customs warehousing and free zones), specific use (temporary admission and end-use) and processing (inward and outward).[^1] All goods intended to be placed under a customs procedure, except for the free zone procedure, are to be covered by a customs declaration appropriate to the procedure.[^1] See [[Customs Declaration]].

## Examples

Release for free circulation entails, among other things, the collection of any import duty due and the application of commercial policy measures and prohibitions and restrictions where these do not have to be applied earlier.[^1] The European Commission describes free circulation as the status of goods released into EU customs territory that can move freely there in the same way as goods made in the EU.[^2] Inward processing is the procedure for non-EU goods imported to be used in processing operations such as manufacturing or repair.[^2]

HM Revenue and Customs describes customs warehousing as a customs special procedure that allows importers to store goods while suspending duties and import VAT.[^3] See [[Bonded Warehouse]].

## Terminology

No opened source uses the alias customs regime; they speak of procedures and, in the UK, of special procedures.[^1][^3] The Commission's overview page also lists customs transit as a customs procedure for moving goods between territories.[^4]

## Evidence limits

Definition above is the EU Code's. UK guidance read here covers one special procedure only, and national regimes outside the EU and UK were not opened.[^1][^3]

[^1]: European Parliament and Council, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code (recast)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^2]: European Commission, “Importation - Taxation and Customs Union - European Commission”. https://taxation-customs.ec.europa.eu/customs/customs-procedures-import-and-export/importation_en
[^3]: HM Revenue and Customs, “Special procedure: customs warehousing - Introduction - Guidance - GOV.UK”. https://www.gov.uk/guidance/special-procedure-customs-warehousing/introduction
[^4]: European Commission, “Customs Procedures for import and export - Taxation and Customs Union”. https://taxation-customs.ec.europa.eu/customs/customs-procedures-import-and-export_en

