xAPI (the Experience API, also known as Tin Can API) is an e-learning interoperability specification that captures learning experiences as actor-verb-object statements sent to a Learning Record Store. Unlike SCORM, it records learning that occurs outside a single course or platform, including informal, mobile and simulation-based activity. xAPI underpins rich learning analytics by providing a flexible, standardised data model.

### Overview

- xAPI (the Experience API, also known as Tin Can API) is an e-learning interoperability specification that captures learning experiences as actor-verb-object statements sent to a Learning Record Store.
- Unlike SCORM, it records learning that occurs outside a single course or platform, including informal, mobile and simulation-based activity.
- xAPI underpins rich learning analytics by providing a flexible, standardised data model.
- It is modelled as a subclass of [[Education Technology]] within the spatial-computing domain.

### Key aspects

- [[Metadata]] is a constituent or mechanism relevant to Xapi.
- [[Data Interoperability]] is a constituent or mechanism relevant to Xapi.
- [[Metadata]] is a constituent or mechanism relevant to Xapi.

### Mechanisms

- Xapi enables [[Learning Analytics]].
- Xapi is standardised in relation to [[Interoperability]].
- Xapi is standardised in relation to [[Standards]].

### Applications

- Applied in contexts involving [[Learning Analytics]].
- Applied in contexts involving [[Adaptive Learning]].

### Provenance

