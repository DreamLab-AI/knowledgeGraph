Geopolitical supply chain risk is the risk that conflict, sanctions, export controls or other trade policy interrupts or raises the cost of supply, and the sources opened here describe it through examples rather than a fixed definition.[^1]

The European Central Bank defines geoeconomic trade fragmentation as a policy-driven reversal of global trade integration, motivated by domestic economic policy objectives as well as geopolitical and strategic considerations.[^1] It states that as fragmentation gathers pace over the next few years, supply disruptions may increase due to the weaponisation of critical supply chains.[^1]

## Examples in the sources

The ECB points to export controls as one channel. Certain semiconductors and manufacturing equipment have long been regulated under multilateral agreements on dual-use items, but in 2022 the United States vastly expanded its unilateral control regime on them when destined for China.[^1]

The ASEAN+3 Macroeconomic Research Office (AMRO) makes a narrower point about shipping. It says that the war in Ukraine could make it difficult for shipping companies to move crew in and out of Ukraine, while Western sanctions on Russia could complicate payments to Russian seafarers.[^2] The Center for Climate and Energy Solutions lists geopolitics, with climate change and economic volatility, among the mounting risks faced by global supply chains.[^3]

## Responses and limits

The ECB reports that some EU manufacturers are shifting the sourcing of critical inputs from China to within the EU to mitigate the risk of disruptions, and cautions that broadbased protectionism aimed at foreign dependencies is self-defeating.[^1]

No source opened here defines geopolitical supply chain risk as a term, and the ECB paper is about trade policy and central banking rather than supply chain management as such. For the related concentration question see [[Supplier Concentration Risk]]; the parent category is [[Supply Chain Risk Type]].

[^1]: European Central Bank, Occasional Paper Series, “Navigating a fragmenting global trading system: insights for central banks (No 365)”. https://ecb.europa.eu/pub/pdf/scpops/ecb.op365~362d801aee.es.pdf
[^2]: ASEAN+3 Macroeconomic Research Office (AMRO), Analytical Note, 25 July 2022, “The Great Supply Chain Disruption: What Does the Shipping Crystal Ball Foretell?”. https://amro-asia.org/wp-content/uploads/2022/07/AMRO-Analytical-Note_The-Great-Supply-Chain-Disruption_What-Does-the-Shipping-Crystal-Ball-Foretell-_July-25-2022.pdf
[^3]: Center for Climate and Energy Solutions (C2ES), September 2025, “Assessing the Landscape of Climate Risk and Supply Chain Resilience: A Primer for Corporate Leaders and Climate Risk Professionals”. https://www.c2es.org/wp-content/uploads/2025/09/Climate-Risk-and-Supply-Chain-Report_FINAL_v3.pdf

