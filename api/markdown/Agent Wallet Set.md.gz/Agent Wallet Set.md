
An agent wallet set is the collection of wallets belonging to an AI agent, declared in the Agent Ontology as `WalletSet`.[^1] The ontology declares it without a definition; this one follows from its properties.

It is the range of the `economicInterfaces` property of the agent module, whose domain is the core agent (see [[Agent]]).[^2] Within the Economic module the only property with the wallet set as domain is `wallet`, ranging over a [[Wallet]], so the set holds one or more wallets. The module's own description says it defines "economic aspects of an AI Agent, such as wallets".

The class is a grouping device in the same way as the [[Agent Contract Set]]: it lets the agent expose its economic interface as one object rather than as a loose list. The module is at version 0.1.0 and says nothing about the kind of wallet, the chain or the custody arrangement. It is distinct from the [[Payment Intent]], which expresses an intended transfer rather than an account.

[^1]: Semantic Agent Communication Community Group, “Economic Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/economic.ttl
[^2]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

