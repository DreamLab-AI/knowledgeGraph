Segmentation and Identification is a foundational computer vision subdomain encompassing the computational processes of partitioning digital images and video frames into semantically meaningful regions and assigning categorical or instance-level identities to those regions.

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:SemanticSegmentation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:InstanceSegmentation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:PanopticSegmentation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:PromptableSegmentation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:OpenVocabularySegmentation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:MedicalSegmentation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:VideoObjectSegmentation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:MaskDecoder))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:hasPart cv:PixelClassificationHead))

    ## Dependency Relationships
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:requires cv:BackboneNetwork))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:requires cv:FeaturePyramidNetwork))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:requires cv:AnnotatedTrainingData))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:requires cv:GPUAcceleration))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:dependsOn cv:AttentionMechanism))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:dependsOn cv:ImageEmbeddings))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:dependsOn cv:ContrastiveLearning))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:dependsOn cv:VisualFoundationModels))

    ## Capability Relationships
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:enables cv:AutonomousDrivingPerception))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:enables cv:SurgicalRoboticsVision))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:enables cv:MedicalImageAnalysis))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:enables cv:ARContentRemoval))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:enables cv:SatelliteEarthObservation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:enables cv:IndustrialQualityControl))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:supports cv:VideoEditingAutomation))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:supports cv:ComputationalPathology))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:supports cv:RobotManipulation))

    ## Implementation Relationships
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:DeepLab))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:MaskRCNN))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:Mask2Former))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:SegFormer))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:PanopticFPN))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:SegmentAnythingModel))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:SAM2))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:nnUNet))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:MedSAM))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:implements cv:GroundedSAM))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:uses cv:CrossEntropyLoss))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:uses cv:DiceLoss))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:uses cv:HungarianMatching))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:uses cv:PanopticQualityMetric))

    ## Reduction Relationships
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:reduces cv:ManualAnnotationCost))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:reduces cv:ClinicalDiagnosisTime))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:reduces cv:SceneParsingComplexity))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:reduces cv:HumanInterventionRequirement))
    SubClassOf(cv:SegmentationAndIdentification
      ObjectSomeValuesFrom(cv:reduces cv:AnnotationEffort))

    ## Annotations
    AnnotationAssertion(rdfs:label cv:SegmentationAndIdentification "Segmentation and Identification"@en)
    AnnotationAssertion(rdfs:comment cv:SegmentationAndIdentification "Core computer vision subdomain partitioning images and video into semantically meaningful regions and assigning class/instance identities. Spans semantic (DeepLab, SegFormer, Mask2Former), instance (Mask R-CNN), panoptic (Panoptic FPN), promptable (SAM, SAM 2), open-vocabulary (Grounded-SAM, OWLv2, X-Decoder), and medical (nnUNet, MedSAM) paradigms. Benchmarked on Cityscapes, COCO, ADE20K, nuScenes, BDD100K. Deployed in autonomous driving, surgical robotics, computational pathology, and AR/XR pipelines."@en)
    AnnotationAssertion(dcterms:identifier cv:SegmentationAndIdentification "AI-2041"^^xsd:string)
    AnnotationAssertion(dcterms:subject cv:SegmentationAndIdentification "Computer Vision, Scene Segmentation, Image Understanding, Foundation Models"@en)
  )

## About Segmentation and Identification

- **Segmentation and Identification** constitutes one of the central problems in computer vision: given a raw 2-D (or 3-D volumetric) image, decompose it into spatially coherent regions and annotate each region with a meaningful label — whether a coarse semantic category ("road", "person"), an individual instance identity ("car #3"), or an arbitrary open-vocabulary concept specified at inference time. This problem sits at the intersection of perception, representation learning, and geometric reasoning, demanding that a model simultaneously understand global scene context (what kind of environment is this?) and fine-grained pixel-level detail (exactly which pixels belong to this tumour boundary?).
- The task is far harder than image classification (assign one label per image) or object detection (predict axis-aligned bounding boxes with class scores). Segmentation requires a dense, pixel-wise structured prediction where every output element interacts with its spatial neighbours and must respect object boundaries, occlusion relationships, and semantic class hierarchies. Early approaches relying on conditional random fields (CRFs) and hand-crafted features were superseded by fully convolutional networks (Long, Shelhamer & Darrell, 2015) and encoder-decoder architectures (U-Net, Ronneberger et al. 2015), which established the template of shared backbone feature extraction followed by upsampling to recover spatial resolution. Dilated convolutions (DeepLab series, Chen et al. 2017–2018) extended receptive fields without sacrificing resolution, while Feature Pyramid Networks (FPN, Lin et al. 2017) introduced multi-scale feature fusion that became the standard detection and segmentation neck. The advent of **Vision Transformers** (ViT, Dosovitskiy et al. 2021) and their segmentation adaptations (SegFormer, Xie et al. NeurIPS 2021; Mask2Former, Cheng et al. CVPR 2022) shifted architectural thinking toward global self-attention, masked-attention, and learnable query-based decoders that predict object masks in parallel rather than sliding a window.
- The latest wave of **foundation segmentation models** — Meta's Segment Anything Model (SAM, Kirillov et al. April 2023, trained on SA-1B with 1 billion masks across 11 million images) and its video extension SAM 2 (Ravi et al. August 2024) — introduces promptable interfaces where points, boxes, masks, or text trigger zero-shot segmentation of arbitrary objects without category-specific training. This paradigm shift decouples the perception of "what is a segmentable entity" from the classification of "what category does it belong to", enabling downstream specialisation through lightweight adaptation rather than full fine-tuning.

### Taxonomy of Segmentation Paradigms

- **Semantic Segmentation** assigns a single class label per pixel, treating all pixels of the same category identically regardless of how many objects are present. The output is a dense label map W × H with values in {0, …, C−1}. Primary architectures include the **DeepLab family** (DeepLab V1 2015 using VGG-16 with CRF post-processing; DeepLab V2 2017 with atrous spatial pyramid pooling ASPP on ResNet-101; DeepLab V3 2017 adding multi-scale image context via encoder ASPP; DeepLab V3+ 2018 adding Xception backbone and decoder with depthwise separable convolutions), **SegFormer** (hierarchical mix-transformer encoder MiT-B0 to B5 plus a lightweight all-MLP decoder, NeurIPS 2021, 72.0 mIoU on ADE20K with SegFormer-B5), and **Mask2Former** (masked-attention transformer decoder producing class-agnostic masks via Hungarian matching, CVPR 2022, 57.7 PQ on COCO panoptic, 80.3 mIoU on Cityscapes).
- **Instance Segmentation** identifies and separately masks each individual object occurrence. The dominant approach is the **Mask R-CNN** family (He et al. ICCV 2017): a two-stage detector (Faster R-CNN region proposal network + RoI align feature extraction) augmented with a lightweight FCN mask head predicting a 28 × 28 binary mask per proposed region. Mask R-CNN achieves 37.1 AP_mask on COCO val, scaling to 41.8 with ResNeXt-101-FPN backbone. **Cascade Mask R-CNN** (Cai & Vasconcelos 2019) stacks multiple detection and segmentation heads with progressively higher IoU thresholds, reaching 46.3 AP on COCO. **SOLOv2** (Wang et al. NeurIPS 2020) removes the region proposal stage via direct instance conditioning, achieving real-time instance segmentation at 31.1 FPS with 39.7 AP. **CondInst** and **BlendMask** further decoupled feature generation from mask generation through conditional convolutions and attention blending respectively.
- **Panoptic Segmentation** unifies semantic and instance predictions into a single coherent assignment: each pixel belongs to exactly one segment, described by a category label and — for countable "thing" classes — an instance ID. Stuffs (sky, road, vegetation) receive only semantic labels; things (car, person, bicycle) receive both class and instance IDs. The **Panoptic FPN** (Kirillov et al. CVPR 2019) proposed merging a Mask R-CNN instance branch with a semantic FPN head via a simple merge operation. **Panoptic-DeepLab** (Cheng et al. CVPR 2020) uses two bottom-up branches for stuff-class prediction and instance centroid regression. **MaskFormer** (Cheng et al. NeurIPS 2021) unified all three paradigms via binary mask classification rather than per-pixel multi-class prediction, the key architectural insight underpinning its successor **Mask2Former** which applies masked cross-attention to constrain each query to its predicted mask region, reducing memory 3× whilst improving performance.
- **Promptable / Interactive Segmentation** produces masks conditioned on sparse user cues at inference time. The **Segment Anything Model** (SAM, Kirillov et al. 2023) uses a heavyweight image encoder (ViT-H, 632M parameters) pretrained on SA-1B via a combination of manual, semi-automatic, and automatic annotation pipelines; a prompt encoder accepting points (+/−), boxes, masks, and text (via CLIP); and a lightweight mask decoder producing three candidate masks ranked by predicted IoU. SAM demonstrates zero-shot transfer to 23 downstream datasets without fine-tuning, achieving 58.0 mIoU on COCO when prompted with ground-truth boxes. **SAM 2** (Ravi et al. August 2024) extends the architecture to streaming video via a memory bank of past frame predictions and a memory attention mechanism, achieving state-of-the-art on DAVIS 2017 (J&F 92.5) and a 6× faster inference than SAM on static images due to a new Hiera image encoder. SAM 2 supports real-time video segmentation at 44 FPS on A100 GPU.
- **Open-Vocabulary Segmentation** generalises beyond closed-set training categories to arbitrary text-specified concepts at inference time. **X-Decoder** (Zou et al. CVPR 2023) introduces a generalised decoding architecture with task-specific query branches sharing a unified text-image feature space, achieving zero-shot panoptic segmentation (52.4 PQ on COCO) and referring segmentation. **OWLv2** (Minderer et al. ICCV 2023, Google Research) scales open-vocabulary detection to LVIS vocabulary with self-training on web-scale image-text pairs, reaching 44.6 AP on LVIS rare categories. **Grounded-SAM** combines Grounding DINO detection (Liu et al. 2023, DINO detector fused with GLIP language-image pre-training) with SAM masking to support text-prompted segmentation of arbitrary nouns without re-training; it achieves 48.4 COCO AP_mask with DINO-L backbone.
- **Medical Segmentation** applies dense prediction to volumetric medical imaging (CT, MRI, ultrasound, pathology whole-slide images). **nnUNet** (Isensee et al. Nature Methods 2021) is a self-configuring framework that automatically determines optimal preprocessing, architecture (2D, 3D, cascade 3D U-Net), training, and inference configurations from dataset fingerprints; it ranked first or second in 33 of 53 biomedical segmentation challenges. **MedSAM** (Ma et al. Nature Communications 2024) fine-tunes SAM on over 1.57 million image-mask pairs across 11 medical imaging modalities, achieving 83.9 mean Dice on the Medical Segmentation Decathlon (MSD) and outperforming nnUNet on 7 of 10 tasks whilst requiring only box prompts. **UniverSeg** (Butoi et al. 2023) introduces a cross-attention architecture enabling one-shot medical segmentation from a single support image-label pair without task-specific training.

### Architecture Deep Dive: Mask2Former

- Mask2Former (Cheng et al., CVPR 2022) represents the state-of-the-art unified segmentation transformer. Its architecture comprises: (1) a pixel encoder (any backbone — ResNet, Swin-T, ViT) producing multi-scale feature maps F at strides {1/8, 1/16, 1/32}; (2) a **pixel decoder** using deformable attention to upsample multi-scale features to 1/4 resolution producing per-pixel embeddings P ∈ R^{H/4 × W/4 × C}; (3) a **transformer decoder** with L=9 layers, each applying: (a) masked cross-attention — each of N=100 queries attends only within its predicted foreground mask region rather than the full feature map, reducing attention complexity from O(HW) to O(mask_area) and enabling the model to focus on fine-grained local regions; (b) self-attention among queries to model instance relationships; (c) FFN. Output N query features are linearly projected to class logits (C+1 classes including background) and dot-producted with P to produce N binary masks. Training uses bipartite matching (Hungarian algorithm) between predictions and ground-truth for thing segments; stuff classes use fixed query assignments. The unified loss is L = λ_cls × CE_cls + λ_mask × (BCE_mask + Dice_mask), matching the paradigm of MaskFormer but with masked attention that is the critical architectural improvement. On COCO panoptic, Mask2Former-Swin-L achieves 57.8 PQ, 63.1 mIoU semantic, 50.1 AP instance — a single model achieving state-of-the-art across all three tasks simultaneously.

### Architecture Deep Dive: SAM and SAM 2

- The Segment Anything Model architecture has three components: a **ViT-H image encoder** (632M params, patch size 16, 1024 input resolution) pretrained via masked autoencoding that produces a 64 × 64 image embedding; a **prompt encoder** that maps: (a) points as positional embeddings summed with a learned +/− token; (b) boxes as two positional embeddings summed with corner tokens; (c) masks as convolved downsampled features; (d) text via a frozen CLIP text encoder; and a lightweight **mask decoder** (2 transformer layers, ~4M params) that applies two-directional cross-attention between query tokens and image features before upsampling via two transposed convolutions to 256 × 256, predicting three mask candidates and their IoU scores. The three-mask output addresses ambiguity in prompts (a click on a person's arm could refer to arm, person, or the group of people). Training uses an iterative prompt sampling strategy: for each ground truth mask, simulate interactive annotation by sampling 1-11 sequential prompts (clicks + previous mask) and train with focal loss + dice loss.
- **SAM 2** introduces a **memory bank** storing per-frame features and sparse mask predictions in a FIFO queue of T=6 frames, an **object pointer** encoding per-frame high-level object semantics as a single token, and a **memory attention** mechanism allowing the current frame encoder to attend to past stored frames before decoding. The image encoder is replaced with **Hiera** (hierarchical vision transformer with multi-scale pyramid stages), which is 3× faster than ViT-H whilst maintaining comparable feature quality. For video, a streaming inference protocol propagates masks from prompted frames (which receive a full ViT-H pass) to subsequent frames (which reuse the memory bank), enabling 44 FPS processing. On SA-V (460K videos, 35M masks — the training set released alongside SAM 2), zero-shot performance on DAVIS 2017 reaches J&F 92.5 vs SAM+tracking at 87.6.

### DETR Family and Detection-Segmentation Unification

- The **Detection Transformer** (DETR, Carion et al. 2020) replaced the hand-crafted NMS post-processing of region proposal detectors with a set-prediction formulation: N=100 learned object queries attend to CNN + transformer encoder features, producing N (class, box) pairs matched to ground truth via Hungarian assignment during training. Whilst DETR achieved competitive accuracy (42.0 AP on COCO), its convergence was slow (500 epochs) due to slow attention learning of two-point cross-attention. **Deformable DETR** (Zhu et al. 2021) addressed this by replacing global cross-attention with deformable attention attending to a sparse set of reference points per query, reducing training to 50 epochs and improving small-object detection. **DN-DETR** (Li et al. CVPR 2022) added denoising training with noisy ground-truth boxes as additional training queries. **DINO-DETR** (Zhang et al. 2022) combined deformable attention, denoising, contrastive denoising, and a mixed query selection strategy, achieving 63.3 AP on COCO val with Swin-L backbone, establishing DETR as the dominant detection paradigm. **Grounding DINO** (Liu et al. 2023) fuses DINO-DETR with GLIP (Grounded Language-Image Pre-training) to produce an open-set detector that accepts text queries specifying arbitrary noun phrases, forming the detection backbone of Grounded-SAM.

### Benchmark Landscape

- **Cityscapes** (Cordts et al. 2016): 5,000 finely annotated and 20,000 coarsely annotated urban driving images at 2048 × 1024 resolution, 19 semantic classes. Primary metric: mean IoU over 19 classes. SOTA (2026): Mask2Former-Swin-L 84.3 mIoU. Cityscapes has shaped all urban driving perception stacks; its class distribution (vehicle-biased) influences model behaviour at deployment.
- **COCO Panoptic** (Kirillov et al. 2019): 118K training images, 80 thing classes + 53 stuff classes, evaluated by Panoptic Quality (PQ = SQ × RQ, product of segmentation quality and recognition quality). SOTA (2026): Mask2Former-Swin-L 57.8 PQ.
- **ADE20K** (Zhou et al. 2017): 20K training / 2K validation scene parsing images, 150 semantic categories spanning indoor/outdoor. Primary metric: mIoU. SOTA: InternImage-H 62.9 mIoU.
- **BDD100K** (Yu et al. 2020): 100,000 driving videos with multi-task annotation (detection, instance segmentation, drivable area, lane marking, semantic segmentation). Represents diverse conditions (night, rain, adverse weather).
- **nuScenes** (Caesar et al. 2020): 1,000 driving scenes with 360-degree LiDAR, camera, radar annotation. 23 semantic classes in 3D. Supports LiDAR segmentation and multi-modal fusion.
- **Medical Segmentation Decathlon** (MSD, Antonelli et al. 2022): 10 medical image segmentation tasks spanning CT (liver, pancreas, colon, hepatic vessels, lung, spleen), MRI (brain, cardiac, prostate, hippocampus). Standardised benchmark enabling direct model comparisons across modalities and organ systems.
- **SA-1B** (Kirillov et al. 2023): 1.1 billion mask annotations across 11 million diverse images — the largest segmentation dataset ever released, used to train SAM and SAM 2.

## Components / Architecture Families

### Semantic Segmentation Architectures

- The **encoder-decoder** template dominates semantic segmentation. The encoder (backbone: ResNet, ConvNeXt, Swin Transformer, ViT variants) extracts hierarchical features at multiple scales; the decoder upsamples features to the original resolution and produces per-pixel class predictions. Key decoder designs: **U-Net skip connections** directly fusing encoder feature maps at matching resolution to recover spatial detail lost during downsampling; **ASPP** (Atrous Spatial Pyramid Pooling, DeepLab V3) applying parallel atrous convolutions at rates {6, 12, 18, 24} to capture multi-scale context without additional parameters; **MLP decoder** (SegFormer) showing that a simple linear projection of multi-scale transformer features to a common channel dimension followed by bilinear upsampling matches or exceeds complex decoders when the backbone is sufficiently expressive.
- **SegFormer** (Xie et al. NeurIPS 2021, NVIDIA Research) is the leading transformer-based semantic segmentation model. Its Mix Transformer (MiT) encoder uses an overlapping patch embedding (3×3 convolution with stride 2) for richer spatial information than ViT's non-overlapping patches, and efficient self-attention via sequence reduction (ratio R reduces key/value spatial dimensions before attention, making complexity O(N²/R)). Six model scales B0–B5 span 3.7M to 82M parameters. The all-MLP decoder has only 0.4M parameters yet achieves 50.3 mIoU (MiT-B0, 640 × 640) to 84.0 mIoU (MiT-B5) on Cityscapes. MiT-B2 at 25M parameters achieves 81.0 mIoU whilst running at real-time on modern GPUs, making SegFormer the pragmatic choice for deployment.
- **DeepLab V3+** (Chen et al. 2018, Google Brain) combines ASPP encoder with an Xception backbone (separable convolutions reducing FLOPs 4–8×) and a decoder that refines boundaries by concatenating low-level features (1×1 conv, 32 channels) with upsampled ASPP output before a final 3×3 convolution. Achieves 89.0% mIoU on PASCAL VOC 2012 and 82.1% mIoU on Cityscapes. The Xception variant reduces inference latency 20–30% vs ResNet-101 with matched accuracy, making it the standard production semantic segmentation baseline.

### Instance Segmentation Architectures

- **Mask R-CNN** (He et al. ICCV 2017, Facebook AI Research) extends Faster R-CNN (Ren et al. 2015) with a mask branch: after RoI Align (replacing the quantisation-lossy RoI Pooling with bilinear-interpolated feature extraction at exact sub-pixel positions), a small FCN (4 × Conv 256 + ReLU → deconv → 1×1 conv) predicts a K-binary mask for each of the top-K classes independently (decoupling classification from segmentation). Trained with L = L_cls + L_box + L_mask, where L_mask is pixel-wise sigmoid binary cross-entropy applied only on the predicted class mask. With ResNet-101-FPN backbone, achieves 37.1 AP_mask on COCO 2017 val. The Detectron2 implementation (FAIR, 2019) became the standard framework for reproducing and extending Mask R-CNN family models.
- **Cascade Mask R-CNN** (Cai & Vasconcelos, CVPR 2019) trains three sequential detection/segmentation heads at IoU thresholds 0.5, 0.6, 0.7: each head's detections serve as proposals for the next. The progressively refined box predictions improve mask quality by reducing regression noise. With Swin-L backbone and HTC++ (Hybrid Task Cascade, which adds inter-stage feature fusion and a semantic segmentation branch as auxiliary supervision), achieves 58.7 AP_mask on COCO test-dev as of 2022.
- **SOLOv2** (Wang et al. NeurIPS 2020) eliminates region proposals entirely. It divides the image into an S × S grid; each cell predicts a mask kernel vector k ∈ R^D and class scores. A global mask feature map F ∈ R^{H×W×D} is produced by a feature pyramid and grouped by matrix multiplication with kernels, producing instance masks directly. Dynamic convolution (CondConv) further improves efficiency. Achieves 39.7 AP at 31.1 FPS on COCO with ResNet-101-FPN.

### Medical Segmentation Architectures

- **nnUNet** (Isensee et al. Nature Methods 2021, DKFZ Heidelberg) operates as a self-configuring framework: given a new dataset, it automatically determines optimal image preprocessing (normalisation statistics, resampling to median voxel spacing), network topology (2D U-Net, 3D full-resolution U-Net, 3D cascade U-Net or ensembles), patch sizes, batch sizes, augmentation pipeline, and inference post-processing from dataset fingerprint features (spacing, image sizes, class distributions). No architecture search — the framework rigorously applies U-Net with encoder depths {2, 3, 4, 5}, feature maps {32, 64, 128, 256, 320}, residual blocks optional. Trained with Dice + cross-entropy loss and deep supervision at each decoder level. Results: ranked first in 26 and second in 7 of 53 challenge tasks at time of publication, including Brain Tumour Segmentation (BraTS), Kidney Tumour Segmentation (KiTS19), Liver Segmentation Decathlon. The nnUNet v2 (2023) extends to 2.5D and supports natural images.
- **MedSAM** (Ma et al. Nature Communications 2024, University of Toronto / McMaster) fine-tunes SAM on the largest curated medical segmentation dataset: 1.57M image-mask pairs across 11 modalities (CT, MRI, X-ray, ultrasound, endoscopy, dermoscopy, fundus photography, microscopy, mammography, PET, optical coherence tomography), 31 organs and tissues, 10 cancer types, 3 continents' patient populations. Fine-tuning uses AdamW with cosine schedule, updating the image encoder and mask decoder whilst freezing the prompt encoder (box prompts only). Results: 83.9 mean Dice on MSD, superior to nnUNet on liver tumour (0.872 vs 0.843 Dice) and spleen (0.970 vs 0.963), comparable elsewhere. Key finding: generalisation from prompt-conditioned fine-tuning outperforms fully trained task-specific models for small-data regimes (<100 training images).
- **UniverSeg** (Butoi et al. 2023, MIT) introduces a **CrossBlock** operating on triplets (query image, support image, support label) with cross-attention between query and support pixel features, enabling one-shot segmentation of unseen anatomical structures with a single support example and no test-time fine-tuning. Achieves 78.4 mean Dice on 21 cardiac MRI structures with 1 support example, approaching 82.1 for 16 support examples.

## Use Cases / Major Families

### Autonomous Driving and Robotics

- Autonomous driving systems require real-time, accurate semantic and panoptic segmentation of road scenes: drivable surface extraction (road, lane markings), obstacle detection (vehicles, pedestrians, cyclists), and free-space prediction for trajectory planning. Cityscapes, BDD100K, and nuScenes provide the training and evaluation infrastructure. State-of-practice deployment pipelines (Waymo, Tesla, Mobileye, UK autonomous vehicle testbeds including Oxford Robotics Institute and Edinburgh ANC) combine multi-camera semantic segmentation (SegFormer or EfficientNet-based custom models) with LiDAR-camera fusion for 3D panoptic segmentation. Key metrics: Cityscapes mIoU >82% for deployment qualification; nuScenes detection mAP >0.6; inference latency <30ms on embedded GPU (NVIDIA Drive AGX Orin). The Edinburgh Autonomous Navigation Centre (ANC) has contributed heavily to outdoor robustness benchmarks, particularly long-term place recognition combined with dense semantic mapping using SegFormer-derived representations for memory-efficient SLAM.
- Robot manipulation uses instance segmentation to identify and localise graspable objects: a robot must segment individual objects from a cluttered table, estimate their 6-DoF pose, and plan collision-free paths. Mask R-CNN remains the standard baseline; newer approaches use FoundPose (SAM + pose estimation) or GraspNet-1Billion. The Imperial Hamlyn Centre for Robotic Surgery (London) deploys instance and semantic segmentation in robotic endoscopy pipelines (CholecSeg8k dataset), where tissue class segmentation enables autonomous tool guidance and collision avoidance in laparoscopic procedures.

### Medical Imaging: Radiology, Pathology, Surgery

- Medical image segmentation spans: **radiology** (CT/MRI organ delineation for radiotherapy planning, tumour volumetry, surgical planning); **pathology** (nucleus detection and semantic segmentation in whole-slide images for cancer grading); **ophthalmology** (retinal vessel and optic disc segmentation in fundus images); **cardiology** (cardiac chamber segmentation in echocardiography and cardiac MRI for ejection fraction measurement); and **surgical video** (instrument and anatomy segmentation for surgical phase recognition and autonomous guidance). nnUNet remains the primary production framework for radiology, achieving FDA-cleared workflows in commercial products (Siemens Syngo, GE Healthcare AIR, Philips IntelliSpace). MedSAM adoption is accelerating for interactive annotation platforms (OHIF, 3D Slicer MedSAM plugin, Monai Label) where box-prompted segmentation reduces expert annotation time 70–85% versus manual tracing. UK NHS deployment of AI-assisted radiotherapy target delineation (primarily GTV/CTV segmentation) is expanding under the NHS AI Lab roadmap, with Imperial College Healthcare and University College London Hospitals piloting commercial platforms including Liminal AI and Therapixel.

### Creative and AR/XR Applications

- Background removal, object isolation, and scene composition in video production pipelines rely on segmentation: Adobe Firefly, DaVinci Resolve Neural Engine, and RunwayML Gen-2 all use SAM-derivative or custom segmentation models for real-time background replacement and selective editing. SAM WebGPU (Xenova, Hugging Face Spaces) demonstrates browser-local interactive segmentation without server round-trips. BiRefNet (Zheng et al. 2024, arXiv) proposes bilateral reference feature extraction for high-resolution dichotomous image segmentation (cutting out objects with extremely fine boundaries — hair, fur, transparent materials), achieving 89.0 F-measure on DIS-TE. XR applications including AR headset pass-through (Magic Leap 2, Meta Quest 3 scene understanding, Apple Vision Pro spatial computing) use real-time semantic segmentation for occlusion handling, furniture AR placement, and mixed-reality content anchoring.

### Satellite and Geospatial Earth Observation

- Semantic segmentation of multispectral satellite imagery enables land use/land cover (LULC) mapping, deforestation monitoring, flood extent estimation, and crop type classification. EuroSAT, DeepGlobe, iSAID, and SpaceNet provide training benchmarks. Architectures adapted for multi-spectral inputs (replacing 3-channel RGB conv stems with N-band equivalents, typically N=4–13 for Sentinel-2 or Landsat-8) include SegFormer variants and SatMAE (Spectral-Spatial MAE pre-training on multi-temporal satellite data). UK applications include DEFRA land parcel analysis, Environment Agency flood modelling, and the UK Space Agency's EO Catalyst programme funding startups (Sparkgeo UK, Tesselo) deploying transformer segmentation pipelines on ESA Copernicus data.

## Academic Context

- Segmentation and Identification draws on a rich lineage of foundational computer vision research. Long, Shelhamer and Darrell's **Fully Convolutional Networks** (FCN, CVPR 2015) established dense prediction as a viable deep learning paradigm by replacing fully connected classification heads with 1×1 convolution and transposed convolution upsampling, demonstrating that arbitrary resolution inputs could produce spatial output maps. Ronneberger et al.'s **U-Net** (MICCAI 2015) introduced skip connections from encoder to decoder to preserve fine spatial detail lost during max-pooling downsampling, becoming the dominant architecture in medical segmentation and influencing essentially all subsequent encoder-decoder designs. The **DeepLab series** (Chen et al., 2015–2018) solved the fundamental tension between spatial resolution and receptive field size through atrous convolutions and ASPP, while also introducing CRF-as-RNN (Zheng et al. 2015, Oxford VGG) for boundary refinement. Mask R-CNN (He et al. ICCV 2017) established the two-stage instance segmentation paradigm and RoI Align, founding a research lineage still dominant in Cascade Mask R-CNN and HTC++. The FPN (Lin et al. CVPR 2017) created the multi-scale feature extraction pattern now universal in detection and segmentation necks. DETR (Carion et al. 2020) introduced set-prediction with transformer decoders for object detection, catalysing MaskFormer and Mask2Former's application of the same paradigm to segmentation. SAM (Kirillov et al. 2023) represents the most significant architectural contribution of the 2023 cycle — the first foundation model specifically designed for segmentation with a data engine capable of scaling annotation to 1B+ masks.
- Oxford's **Visual Geometry Group** (VGG) has contributed CRF-as-RNN (Zheng et al. ICCV 2015), DenseCRF integrations, and the VGGNet backbone that underpinned early DeepLab variants. Oxford's recent work includes **Predicting Human Attention Using Neural Networks** and weakly supervised segmentation. The **Edinburgh ANC** contributes semantic SLAM and long-term autonomy using segmentation for place recognition and map maintenance. Imperial College London's **Hamlyn Centre for Robotic Surgery** is a world leader in surgical scene segmentation and tool tracking, producing the CholecSeg8k (cholecystectomy anatomy segmentation) and AutoLaparo (laparoscopic workflow recognition) datasets, and pioneering real-time transformer-based segmentation on surgical video.

## Current Landscape (2026)

- As of mid-2026, the field is characterised by three concurrent developments. First, **foundation model proliferation**: following SAM and SAM 2, multiple groups have released medical (MedSAM), remote sensing (RSPrompter, SAM-EO), and video variants, creating a landscape of specialised SAM fine-tunes. The Grounded-SAM ecosystem has become the de-facto zero-shot segmentation pipeline combining open-vocabulary detection with promptable masking. Second, **architecture consolidation around masked-attention transformers**: Mask2Former's masked cross-attention has been adopted as the standard decoder design (OneFormer, Mask2Former++, FreeSeg, CAT-Seg), with the primary differentiation being the choice of backbone (ViT-based ViTDet vs Swin vs ConvNeXt vs InternImage) and the scale of pre-training. Third, **real-time deployment pressure**: on-device inference requirements for robotics, autonomous driving, and AR/XR are driving efficient model development — TinySAM (2024) distills SAM to 10M parameters with 6× speedup; MobileSAM achieves 100 FPS on CPU via knowledge distillation; EfficientViT-SAM reaches 48.9 AP at 1200 FPS on A100. UK regulatory context: the NHS AI Lab requires clinical segmentation systems to hold UKCA/CE-IVD marks where segmentation informs clinical decisions, with MDR 2017/745 requiring prospective clinical evaluation — a compliance hurdle constraining adoption speed of MedSAM in direct-care workflows.
- Benchmark saturation is prompting domain expansion: COCO panoptic (57.8 PQ) is approaching human performance (~64 PQ estimated by MSeg study), pushing research toward harder benchmarks (LVIS long-tail, OpenImagesV7 inter-active segmentation, challenging weather on BDD100K) and more nuanced metrics (Boundary IoU, instance ranking AP). The open-vocabulary paradigm — OWLv2, Grounded-SAM, X-Decoder — is becoming the default for robotic grasping and document AI pipelines where fixed taxonomies are impractical.

## UK Context

- **Imperial College London / Hamlyn Centre for Robotic Surgery**: Professor Guang-Zhong Yang's group pioneered robotic vision for surgical applications; current researchers (Dr Stamatia Giannarou, Dr Daniel Elson) deploy real-time instrument tracking and tissue segmentation in clinical trials of robotic-assisted cholecystectomy and partial nephrectomy. CholecSeg8k (17 semantic tissue classes, 80K frames) and EndoVis 2017/2019 challenge datasets originated from Hamlyn's clinical collaboration with St Mary's Hospital, London. Hamlyn contributes to NHS AI Lab's surgical AI programme and EPSRC-funded ORCA Hub for offshore robotic systems requiring autonomous segmentation.
- **University of Oxford / Visual Geometry Group**: Oxford VGG (Prof. Andrew Zisserman, Dr Andrea Vedaldi) produced seminal contributions including VGGNet, CRF-as-RNN, and weakly supervised segmentation methods used in industrial defect inspection. Oxford Robotics Institute (ORI) runs the RobotCar dataset (long-term outdoor autonomy) and SemanticKITTI LiDAR semantic segmentation with PointNet++ and RandLA-Net variants for outdoor scene understanding.
- **University of Edinburgh / Autonomous Navigation Centre**: Edinburgh ANC (Prof. David Lane, Dr Chris Xiaoxuan Lu) focuses on long-term semantic SLAM in outdoor environments, combining SegFormer-derived representations with topological mapping for agricultural robotics (APRIL project) and underground mine inspection. Edinburgh contributes to the UK Robotics and Autonomous Systems (UK-RAS) network, a key coordinating body for autonomous systems policy including segmentation technology standards.
- **University of Cambridge / Machine Intelligence Lab**: Cambridge MIL (Prof. Roberto Cipolla) contributed early work on real-time semantic segmentation for autonomous vehicles (SegNet, Badrinarayanan et al. TPAMI 2017) and continues work on uncertainty quantification in dense prediction for safety-critical applications. SegNet's encoder-decoder architecture with max-pooling index reuse remains a lightweight baseline.
- **Northern England Industrial**: Sheffield Forgemasters and BAE Systems Samlesbury (Lancashire) use semantic segmentation for automated weld inspection and fuselage assembly monitoring. AMRC (Advanced Manufacturing Research Centre, Sheffield, affiliated with University of Sheffield) deploys Mask R-CNN-based defect detection pipelines on aerospace composite materials. Siemens Energy (Lincoln factory) uses instance segmentation for turbine blade inspection. These applications drive demand for domain-specific training data collection and annotation pipelines using SAM-assisted annotation tools.

## Future Directions (2026-2030)

- **Unified perception-generation models**: The boundary between segmentation models and generative diffusion models is dissolving — architectures such as Stable Diffusion with ControlNet inpainting, DALL-E 3's internal segmentation masks, and Sora's implicit scene graph construction suggest that future foundation models will jointly handle segmentation, depth estimation, and generation from the same latent representations. Explicit segmentation APIs will be embedded in multimodal LLMs (GPT-5 Vision, Gemini Ultra 2) enabling natural language-directed pixel manipulation.
- **3D Gaussian Splatting segmentation**: Real-time scene decomposition using 3D Gaussian Splatting (Kerbl et al. 2023) combined with DEVA/ODISE tracking enables persistent instance segmentation in novel-view synthesis and spatial computing applications (Apple Vision Pro, Meta Quest 3). UK startup Varjo and research groups at Edinburgh and Imperial are exploring Gaussian-based segmentation for surgical scene reconstruction.
- **Video-language grounding at 30 FPS**: SAM 2 demonstrated real-time video segmentation; the next step is real-time text-grounded video segmentation (given "find and track the dog in frames 0-N" in a long video). GLEE (General-purpose Language-guided End-to-End), UNINEXT, and VideoGLUE are early steps; full deployment readiness is expected 2027-2028.
- **Federated and privacy-preserving medical segmentation**: NHS data governance (UK GDPR, NHS Data Security and Protection Toolkit) constrains centralised training of clinical segmentation models. Federated learning frameworks (FLARE, OpenFL, PySyft) combined with nnUNet and MedSAM are being evaluated by NHS Digital for a federated NHS AI segmentation model — a priority in the NICE AI guidance framework (2025).
- **Neuromorphic and event camera segmentation**: Event cameras (Dynamic Vision Sensors) produce asynchronous per-pixel brightness change events rather than frames, enabling 10,000 FPS equivalent temporal resolution with <1 mW power. Semantic segmentation on event streams (ESS, E2VID + SegFormer, RecEvSeg) is an active research direction relevant to high-speed robotics and drone navigation — the Oxford Active Vision Lab and University of Zurich Robotics and Perception Group are key contributors.
- **Interpretable and uncertainty-aware segmentation**: Clinical deployment requirements are driving adoption of calibrated uncertainty maps alongside segmentation predictions. Bayesian deep learning methods (Monte Carlo Dropout, Deep Ensembles applied to nnUNet) and evidential deep learning (EDL) for medical segmentation are growing, with NHS England's AI approval process now requiring uncertainty quantification for segmentation tools used in radiotherapy planning (NICE dAV6 2025 guidance).

## Research & Literature

- Long, J., Shelhamer, E., Darrell, T. (2015). **Fully Convolutional Networks for Semantic Segmentation**. CVPR 2015. Foundational FCN architecture enabling dense prediction with arbitrary input resolution.
- Ronneberger, O., Fischer, P., Brox, T. (2015). **U-Net: Convolutional Networks for Biomedical Image Segmentation**. MICCAI 2015. Skip-connection encoder-decoder for medical segmentation; 100K+ citations.
- Chen, L.-C., Papandreou, G., Schroff, F., Adam, H. (2018). **Encoder-Decoder with Atrous Separable Convolution for Semantic Image Segmentation (DeepLab V3+)**. ECCV 2018. Combines ASPP encoder with Xception backbone and boundary-aware decoder.
- He, K., Gkioxari, G., Dollár, P., Girshick, R. (2017). **Mask R-CNN**. ICCV 2017. Instance segmentation via RoI Align + FCN mask head; 37.1 AP on COCO.
- Kirillov, A., He, K., Girshick, R., Rother, C., Dollár, P. (2019). **Panoptic Segmentation**. CVPR 2019. Formal definition of panoptic segmentation and Panoptic FPN baseline.
- Xie, E., Wang, W., Yu, Z., Anandkumar, A., Alvarez, J.M., Luo, P. (2021). **SegFormer: Simple and Efficient Design for Semantic Segmentation with Transformers**. NeurIPS 2021. MiT encoder + all-MLP decoder; 84.0 mIoU Cityscapes.
- Cheng, B., Misra, I., Schwing, A.G., Kirillov, A., Girdhar, R. (2022). **Masked-attention Mask Transformer for Universal Image Segmentation (Mask2Former)**. CVPR 2022. Unified semantic/instance/panoptic; 57.8 PQ on COCO panoptic.
- Kirillov, A., Mintun, E., Ravi, N., et al. (2023). **Segment Anything**. arXiv:2304.02643. SAM foundation model; SA-1B 1B+ masks; zero-shot transfer across 23 benchmarks.
- Ravi, N., Gabeur, V., Hu, Y.-T., et al. (2024). **SAM 2: Segment Anything in Images and Videos**. arXiv:2408.00714. Memory-bank video extension; J&F 92.5 on DAVIS 2017; 44 FPS A100.
- Isensee, F., Jaeger, P.F., Kohl, S.A.A., Petersen, J., Maier-Hein, K.H. (2021). **nnU-Net: a self-configuring method for deep learning-based biomedical image segmentation**. Nature Methods 18, 203–211. Self-configuring framework; top-ranked in 33 of 53 biomedical challenges.
- Ma, J., He, Y., Li, F., et al. (2024). **Segment Anything in Medical Images**. Nature Communications 15, 654. MedSAM: SAM fine-tuned on 1.57M medical image-mask pairs, 11 modalities.
- Minderer, M., Gritsenko, A., Zhai, X., et al. (2023). **Scaling Open-Vocabulary Object Detection (OWLv2)**. ICCV 2023. Self-training on image-text pairs for open-vocabulary detection; 44.6 AP LVIS rare.
- Zou, X., Dou, Z.-Y., Yang, J., et al. (2023). **Generalized Decoding for Pixel, Image, and Language (X-Decoder)**. CVPR 2023. Unified segmentation + retrieval + captioning decoder.
- Liu, S., Zeng, Z., Ren, T., et al. (2023). **Grounding DINO: Marrying DINO with Grounded Pre-Training for Open-Set Object Detection**. arXiv:2303.05499. DINO-DETR + GLIP for open-vocabulary detection backbone of Grounded-SAM.
- Carion, N., Massa, F., Synnaeve, G., Usunier, N., Kirillov, A., Zagoruyko, S. (2020). **End-to-End Object Detection with Transformers (DETR)**. ECCV 2020. Set-prediction formulation with Hungarian matching; 42.0 AP COCO.
- Zhu, X., Su, W., Lu, L., Li, B., Wang, X., Dai, J. (2021). **Deformable DETR: Deformable Transformers for End-to-End Object Detection**. ICLR 2021. Sparse deformable attention reducing DETR training from 500 to 50 epochs.
- Wang, X., Kong, T., Shen, C., Jiang, Y., Li, L. (2020). **SOLO: Segmenting Objects by Locations**. ECCV 2020. Proposal-free instance segmentation via instance conditioning.
- Zhang, H., Li, F., Liu, S., et al. (2022). **DINO: DETR with Improved DeNoising Anchor Boxes**. arXiv:2203.03605. 63.3 AP COCO; state-of-the-art detection transformer.
- Badrinarayanan, V., Kendall, A., Cipolla, R. (2017). **SegNet: A Deep Convolutional Encoder-Decoder Architecture for Image Segmentation**. TPAMI. Lightweight architecture with max-pooling index reuse; Cambridge MIL contribution.
- Zheng, S., Jayasumana, S., Romera-Paredes, B., et al. (2015). **Conditional Random Fields as Recurrent Neural Networks**. ICCV 2015. CRF-as-RNN boundary refinement; Oxford VGG.
- Cai, Z., Vasconcelos, N. (2019). **Cascade R-CNN: High Quality Object Detection and Instance Segmentation**. CVPR / TPAMI. Multi-threshold cascading; 58.7 AP_mask with HTC++ variants.
- Cordts, M., et al. (2016). **The Cityscapes Dataset for Semantic Urban Scene Understanding**. CVPR 2016. Benchmark for urban driving semantic/instance segmentation.
- Zheng, P., et al. (2024). **BiRefNet: Bilateral Reference for High-Resolution Dichotomous Image Segmentation**. arXiv:2401.03407. Fine boundary extraction for production matting pipelines.
- Butoi, V.I., et al. (2023). **UniverSeg: Universal Medical Image Segmentation**. ICCV 2023. Cross-attention for one-shot medical structure segmentation; MIT contribution.
- Zhang, X., et al. (2024). **TinySAM: Pushing the Envelope for Efficient Segment Anything Model**. arXiv:2312.13789. 10M parameter SAM distillate; 6× speedup.
- Caesar, H., et al. (2020). **nuScenes: A Multimodal Dataset for Autonomous Driving**. CVPR 2020. 3D panoptic and semantic annotation for autonomous driving.

## Metadata

- **Term ID**: AI-2041
- **Domain**: computer-vision (corrected from stub implicit `artificial-intelligence` — computer-vision is the precise subdomain classification; the concept is hosted under the broader AI namespace but ontologically belongs to CV)
- **Ontology prefix**: `cv:` (Computer Vision subdomain of `ai:`)
- **Authority score basis**: Established benchmark SOTA citations (Mask2Former CVPR 2022, SAM Nature 2023, MedSAM Nature Comms 2024, nnUNet Nature Methods 2021), breadth of sub-paradigm coverage (semantic, instance, panoptic, promptable, open-vocabulary, medical), and UK institutional coverage (Imperial Hamlyn Centre, Oxford VGG, Edinburgh ANC, Cambridge MIL)
- **Version**: 2.1.0 (stub 2.0.0 → enriched 2.1.0, Phase 6 bulk run 2026-05-17)

### Provenance

- **domain-correction:** stub had implicit `artificial-intelligence` domain; corrected to `computer-vision` as the precise ontological subdomain; IRI, URI, owl-class prefix updated accordingly

