Procurement is the acquisition of goods, construction or services by an organisation from outside suppliers; UNCITRAL's definition for public procurement reads the acquisition of goods, construction or services by a procuring entity.[^1]

An earlier, unsourced body of this page has been replaced. UNCITRAL's Model Law lists the methods a procuring entity may use, among them request for quotations, request for proposals, two-stage tendering, electronic reverse auction and single-source procurement.[^1] UNCITRAL allows a request for quotations for readily available goods or services that are not specially produced to the buyer's description and have an established market, if the estimated value is below a threshold set in the procurement regulations.[^1] The UK Cabinet Office Sourcing Playbook sets out the stages of a government procurement: define the business need, assess the market and develop a sourcing strategy, then draft the specification, use a standard selection questionnaire to select suitable suppliers, evaluate tenders, advertise the contract opportunity, award and sign the contract, and receive goods or services and issue payments.[^2]

## Private-sector view

Kraljic wrote in 1983 that the stable way of business life many corporate purchasing departments enjoyed was imperilled by resource depletion, raw materials scarcity, political turbulence, intensified competition and accelerating technological change.[^3] HM Revenue and Customs describes the business-to-business purchasing cycle from requisition and purchase order through receipt, purchase invoice and supplier payment.[^4]

See [[Sourcing and Procurement]], [[Procure-to-Pay]], [[Strategic Sourcing]] and [[Supplier Management]].

## What the sources do not establish

UNCITRAL's definition covers public procurement only, and the Playbook describes UK government practice, so the private-sector scope rests on the two shorter sources.[^1][^2][^3][^4] The earlier claims about compliance, auditability, smart contracts and electronic signatures were not found in any opened source and were removed.

[^1]: United Nations Commission on International Trade Law (UNCITRAL), “UNCITRAL Model Law on Public Procurement (2011)”. https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/2011-model-law-on-public-procurement-e.pdf
[^2]: UK Cabinet Office, Crown copyright (Open Government Licence v3.0), June 2023, “The Sourcing Playbook: Government guidance on service delivery, including outsourcing, insourcing, mixed economy sourcing and contracting”. https://assets.publishing.service.gov.uk/media/64901fcc5f7bb700127fac5e/Sourcing_Playbook_Final.pdf
[^3]: Peter Kraljic, Harvard Business Review, September 1983 (publisher page with opening text), “Purchasing Must Become Supply Management”. https://hbr.org/1983/09/purchasing-must-become-supply-management
[^4]: HM Revenue and Customs, VAT compliance controls guidelines (Crown copyright), “Procure to pay (part 4)”. https://www.gov.uk/government/publications/help-with-vat-compliance-controls-guidelines-for-compliance-gfc8/procure-to-pay-part-4

