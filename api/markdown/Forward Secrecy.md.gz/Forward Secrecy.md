Forward secrecy, also called perfect forward secrecy, is a property of key-agreement protocols ensuring that the compromise of long-term private keys does not allow an attacker to decrypt previously recorded session traffic. It is achieved by deriving ephemeral session keys for each connection through a fresh key exchange and discarding them afterwards, so that no single persistent secret can retroactively unlock past communications. The property is a cornerstone of modern transport-layer security.

### Overview

- Forward secrecy decouples the security of past sessions from the security of long-term identity keys.
- Ephemeral Diffie-Hellman exchanges generate a unique shared secret per session that is never written to disk and is destroyed after use.
- Even if a server's certificate private key is later stolen, recorded ciphertext from earlier sessions remains undecryptable because the ephemeral keys no longer exist.

### Mechanisms

- Ephemeral key exchange generates fresh per-session secrets via [[Key Exchange]] rather than reusing static keys.
- Long-term keys authenticate the exchange but are not used to encrypt session data directly.
- Session keys are short-lived and erased once the connection closes.
- Combined with authenticated encryption to provide both confidentiality and integrity.
- Standardised within [[Transport Layer Security]] cipher suites that mandate ephemeral exchange.

### Applications

- HTTPS connections negotiating ephemeral cipher suites for web traffic.
- Secure messaging protocols that rotate keys per message or per session.
- VPN tunnels protecting against retrospective decryption of captured traffic.
- Any [[Secure Communication]] channel where long-term key compromise is part of the threat model.

### Provenance

