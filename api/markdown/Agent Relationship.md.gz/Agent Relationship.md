
An agent relationship is a relationship between two or more agents.[^1] It is declared as `AgentRelationship` in the delegation module, and visionGraph places it under the AI Research Area hub and as part of [[Multi-Agent System]]. The schema.org mapping aligns it with `schema:Role`.[^2]

It is the parent for the kinds of connection that a multi-agent system is built from. [[Agent Delegation]] is the relationship the ontology specifies, a transfer of authority from one agent to another, and [[Delegation Chain]] sits beneath it as an ordered sequence of such transfers. Other kinds, such as peer collaboration or supervision, belong here as further subclasses.

The class has no properties of its own. A relationship is described by its subclass, which carries the roles, scope and identifiers that make it concrete.

[^1]: Semantic Agent Communication Community Group, “Delegation Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/delegation.ttl
[^2]: Semantic Agent Communication Community Group, “Agent Ontology to Schema.org Mapping” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/schema-org-mapping.ttl

