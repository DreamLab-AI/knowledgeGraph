A warehouse facility type is a class of storage or distribution facility, distinguished by the customers it serves or by its place and role in the supply chain.[^1][^2]

Georgia Tech's open textbook says warehouses may be categorised by type, which is primarily defined by the customers they serve. It names a retail distribution center that supplies retail stores, a service parts distribution center, a catalog fulfillment or e-commerce distribution center, a 3PL warehouse to which a company outsources its warehousing, and the crossdock, a kind of high-speed warehouse in which product flows with such velocity that there is no point in putting it on a shelf.[^1]

## Classification by role in the chain

An eCampusOntario logistics text classifies warehouses by where they sit. In transit it lists consolidation warehouses, which store products from different suppliers bound for a similar destination, cross-docking warehouses, break-bulk warehouses, in which large bulk-packed quantities are split into smaller quantities, hub-and-spoke warehouses, which are large and tend to be located where transportation systems converge, and distribution centers.[^2] See [[Distribution Centre]], [[Fulfilment Centre]] and [[Bonded Warehouse]]; the customs type is defined by legal status rather than by customer or location.

## Scope and distinctions

These two texts use different schemes: one by customer served, one by position in the chain. They overlap, since a distribution center appears in both, and neither claims to be complete.[^1][^2] A US statistical committee notes that cross-docking facility and warehouse are other terms for units that collect and distribute goods to affiliated retail locations, which shows the names are not fixed.[^3]

Facility types sit under [[Warehousing and Distribution]]. The operations carried out inside them are covered at [[Warehouse Operation]].

## What the sources do not establish

No source gives a standard list of warehouse types or counts them by type. The terms are used by their authors for teaching, and operators may use their own labels.

[^1]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^2]: eCampusOntario Pressbooks (Introduction to Logistics), “Chapter 5 – Warehousing”. https://ecampusontario.pressbooks.pub/logistics001oerfc/chapter/chapter-5-warehousing/
[^3]: US Census Bureau, Economic Classification Policy Committee, “Recommendation for Classification of Distribution Centers in North American Industry Classification System (NAICS) Revisions for 2012”. https://www2.census.gov/library/reference/naics/federal-register/supporting/distribution_centers.pdf

