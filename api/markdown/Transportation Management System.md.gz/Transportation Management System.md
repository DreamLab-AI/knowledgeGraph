A transportation management system (TMS) is software used to plan and carry out freight transportation, though Georgia Tech presentation slides say there is no one true definition of TMS today.[^1]

Those slides list functions of systems that call themselves a TMS: fleet routing, parcel rating, carrier selection, rate quoting, carrier tendering and global trade management.[^1] The range shows that the label covers products with different boundaries.

## A worked example

The US General Services Administration describes its TMSS 2.0 as a transportation management solution that provides services and management tools to promote efficiency during shipment creation, planning, tendering, execution and reporting in a single solution.[^2] It says the system supports motor, rail, ocean, air and international freight shipments, offers automated shipment planning and tendering, and automatically generates the bill of lading.[^2]

## Place among systems

Zaidi, Amanton and Sanlaville list transportation management systems with warehouse management systems and manufacturing execution systems as the supply chain execution class.[^3] See [[Supply Chain Execution System]], [[Warehouse Management System]] and [[Global Trade Management System]].

## Scope and distinctions

The GSA example puts planning and tendering inside the same system as execution, so the planning and execution classes in the preprint overlap in practice.[^2][^3] The Georgia Tech list includes global trade management among TMS functions, while this domain treats it as a separate system.[^1]

## What the sources do not establish

The GSA page describes one government programme and is not a general definition. The slides are undated and are a presentation, not a standard. No opened source gives market structure, vendor lists or adoption figures for freight transport software.[^1][^2][^3]

[^1]: Georgia Tech Supply Chain and Logistics Institute, “Principles of Transportation Management” (overview presentation). https://www.scl.gatech.edu/sites/default/files/presentations/GTSCL-PrinciplesTransportationManagementOverview.pdf
[^2]: US General Services Administration, “TMSS 2.0”. https://www.gsa.gov/buy-through-us/products-and-services/transportation-and-logistics-services/transportation-programs/tmss-20
[^3]: Fares Zaidi, Laurent Amanton and Eric Sanlaville, “Towards a Novel Cooperative Logistics Information System Framework”, arXiv:1905.00687. https://arxiv.org/pdf/1905.00687

