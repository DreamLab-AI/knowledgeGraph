Digital Twin Technology is the discipline of constructing and operating persistent, synchronised virtual replicas of physical objects, systems, or environments that continuously ingest real-time sensor and telemetry data to mirror the state, behaviour, and lifecycle of their physical counterparts. Rooted in model-based engineering, it combines IoT connectivity, physics-based simulation, data analytics, and 3D visualisation to enable predictive maintenance, design optimisation, remote monitoring, and what-if scenario analysis without physical intervention. The technology spans the full asset lifecycle—from design and commissioning through operation and decommissioning—and underpins industrial metaverse platforms, smart-city infrastructure, and autonomous system validation. Standardisation efforts led by ISO/IEC JTC 1 and the Industrial Internet Consortium (IIC) are consolidating reference architectures and interoperability frameworks across vendor ecosystems.

### Overview

- Digital twin technology originated in aerospace and defence—NASA used physics-based mirroring to manage the Apollo programme spacecraft—before expanding into manufacturing, energy, infrastructure, and urban planning. The defining characteristic that distinguishes a digital twin from a conventional [[Simulation Modelling]] is bidirectional, real-time data coupling: the virtual model receives continuous telemetry from the physical asset and can send control signals back, creating a closed feedback loop.
- Three abstraction levels are commonly distinguished:
  - **Component twin** — a replica of a single part or machine element (e.g. a turbine blade)
  - **Asset twin** — a replica of a complete asset (e.g. a wind turbine or MRI scanner)
  - **System / process twin** — a replica of an interconnected set of assets (e.g. a production line or power grid segment)
- A fourth level, the **enterprise twin**, aggregates multiple system twins to represent an entire organisation or city, as seen in smart-city initiatives such as Singapore's Virtual Singapore project.
- Why digital twins matter:
  - Shift maintenance from reactive or scheduled approaches to truly predictive, condition-based intervention driven by [[Machine Learning]] anomaly detection
  - Enable design validation in the virtual domain before physical build, compressing product development cycles
  - Reduce the need for on-site physical presence in hazardous or remote environments (offshore platforms, nuclear facilities, space assets)
  - Provide the persistent, semantically rich virtual layer that anchors [[Industrial Metaverse]] and [[Extended Reality]] collaboration experiences

### Key Components

- **Physical asset and sensing layer**
  - Embedded sensors, actuators, [[Internet of Things]] gateways collecting temperature, pressure, vibration, position, and process variables
  - [[Sensor Fusion]] pipelines that integrate heterogeneous sensor streams into coherent state vectors
  - Edge processing nodes that filter, timestamp, and pre-process raw telemetry before cloud transmission
- **Connectivity and data transport**
  - [[Real-Time Data Streaming]] middleware (MQTT, AMQP, OPC-UA, Kafka) ensuring low-latency telemetry delivery
  - [[Cloud Computing]] infrastructure (Azure Digital Twins, AWS IoT TwinMaker, NVIDIA Omniverse) hosting the twin runtime
  - [[Digital Twin Framework]] — the software stack defining twin schema, state management, versioning, and API surface
- **Digital model layer**
  - Geometric and semantic models (CAD, BIM, point clouds) forming the spatial skeleton of the twin
  - [[Physics-Based Simulation]] engines (finite-element, CFD, multi-body dynamics) that replicate physical behaviour
  - [[Building Information Modelling]] feeds in construction and facilities management contexts
  - Knowledge graphs and ontologies providing semantic context and interoperability between twin components
- **Analytics and intelligence layer**
  - [[Machine Learning]] models for anomaly detection, remaining useful life prediction, and fault classification
  - [[Data Analytics]] pipelines running continuous model calibration against live telemetry
  - [[Computer Vision]] for camera-based state estimation where traditional sensors are impractical
  - Causal inference and what-if simulation for operational decision support
- **Visualisation and interaction layer**
  - [[3D Rendering]] engines providing photorealistic or engineering-grade visual fidelity
  - [[Extended Reality]] interfaces (AR overlays, VR walkthroughs) for immersive inspection and collaboration
  - Dashboards and alerts surfaced through operator workstations and mobile devices
- **Lifecycle management**
  - [[Asset Lifecycle Management]] systems tracking twin versions across design, build, operate, and retire phases
  - [[Model-Based Engineering]] practices that keep the twin synchronised with engineering change orders

### Applications and Use Cases

- **Manufacturing and Industry 4.0**
  - Production line twins detect tooling wear, optimise throughput, and validate process changes in simulation before deployment on real equipment
  - NVIDIA Omniverse-based factory twins enable geographically distributed engineering teams to inspect and modify layouts in shared virtual space
  - Quality assurance twins correlate sensor data with product defect rates to tighten tolerances automatically
- **Energy and utilities**
  - Wind farm twins combine aero-elastic simulation with live SCADA data to schedule maintenance windows that minimise generation losses
  - Power grid digital twins model fault propagation and train operators in emergency response scenarios without risking real grid stability
  - Oil and gas offshore platform twins reduce the frequency of costly and hazardous personnel visits
- **Urban planning and smart cities**
  - City-scale [[Smart City]] twins integrate traffic, utilities, weather, and population models to inform infrastructure investment decisions
  - Emergency response twins simulate evacuation routes and resource deployment under various incident scenarios
  - Singapore's Virtual Singapore and the UK National Digital Twin programme exemplify national-scale ambition
- **Healthcare**
  - Patient-specific organ twins (heart, lung) built from medical imaging data and personalised physiological models support surgical planning and drug dosing optimisation
  - Hospital facility twins manage equipment utilisation, patient flow, and infection control zone integrity
- **Aerospace and defence**
  - Aircraft airframe twins integrate structural health monitoring to predict fatigue crack propagation and schedule inspections with precision
  - Spacecraft twins support in-orbit anomaly diagnosis when round-trip communication latency prohibits real-time teleoperation
- **Autonomous systems validation**
  - [[Autonomous Systems]] development uses environment twins as high-fidelity simulation grounds for training and validating perception and control stacks before physical testing
  - Vehicle-in-the-loop and hardware-in-the-loop testing against urban scenario twins dramatically reduces real-world test mileage requirements

### Standards and Context

- **ISO/IEC 30173:2023** — International standard defining digital twin terminology, conceptual model, and reference architecture, providing a vendor-neutral vocabulary for interoperability
- **ISO/IEC JTC 1/WG 11** — Working group responsible for digital twin standards within the broader ISO/IEC family, covering IoT, smart city, and industrial contexts
- **Industrial Internet Consortium (IIC) Digital Twin Interoperability Task Group** — publishes reference architecture whitepapers and testbed programmes aligning OPC-UA, W3C WoT, and DTDL (Digital Twins Definition Language) schemas
- **W3C Web of Things (WoT)** — Thing Description standard provides semantic descriptions of IoT device capabilities that feed into twin ontologies
- **DTDL (Digital Twins Definition Language)** — Microsoft's open modelling language for defining twin schemas, relationships, and telemetry properties; underpins Azure Digital Twins
- **AS4 / STEP AP242** — Aerospace and automotive product lifecycle interoperability standards that feed geometric models into digital twins
- **UK National Digital Twin programme** — government-backed initiative coordinated by the Centre for Digital Built Britain establishing a shared information management framework for infrastructure twins across the UK
- **Gartner Hype Cycle** positions digital twins as entering the Slope of Enlightenment, reflecting rapid enterprise adoption in manufacturing, energy, and defence sectors following a period of inflated expectations

### Provenance

