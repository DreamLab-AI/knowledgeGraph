Partial synchrony is a timing model for distributed systems that sits between the fully synchronous model, where message delays are bounded and known, and the fully asynchronous model, where delays are unbounded. In the partially synchronous model there exists an unknown bound on message delay that eventually holds after some unknown global stabilisation time (GST), or alternatively a known bound that holds only after GST. This model is the theoretical foundation for practical Byzantine fault-tolerant consensus protocols, allowing them to circumvent the FLP impossibility result by guaranteeing safety always and liveness once the network behaves synchronously.

### Overview

- Partial synchrony was introduced by Dwork, Lynch and Stockmeyer to model real networks, which are usually timely but can experience arbitrary bursts of delay during congestion, partitions, or attacks. Because no algorithm can guarantee both safety and liveness in a fully asynchronous network with even a single crash failure (the FLP result), partial synchrony provides a principled escape hatch: protocols are designed to never violate safety, and to make progress only when timing assumptions hold.

### Mechanisms

- Global stabilisation time (GST) after which message-delay bounds hold
- Timeout-based view changes that retry leadership when progress stalls
- Eventual synchrony assumption decoupling safety from liveness
- Quorum intersection guaranteeing agreement across overlapping votes
- Exponential backoff on timeouts to adapt to unknown delay bounds

### Applications

- BFT consensus engines such as Tendermint and HotStuff
- Classical state-machine replication via Paxos and Raft
- Permissioned and permissionless blockchain finality
- Atomic broadcast and total-order delivery layers

### Provenance

- This class was materialised to resolve inbound references from existing classes in the knowledge graph.

