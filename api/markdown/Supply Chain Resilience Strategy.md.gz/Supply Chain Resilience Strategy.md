A supply chain resilience strategy is a set of actions that a firm or government takes to reduce exposure to disruption and to speed recovery, and the sources opened here propose different sets rather than one standard list.[^1][^2]

Christopher and Peck draw general principles from their research programme: an understanding of the network, a re-examination of the trade-off between efficiency and redundancy, collaboration across the network, agility, and a risk management culture.[^1] They define supply chain agility as the ability to respond rapidly to unpredictable changes in demand or supply.[^1] They also say the strategic and selective use of slack may be fundamental to resilience, without advocating buffering every stage.[^1]

## Other proposals

The UK Climate Change Committee says businesses can adapt their supply chains to climate change through business continuity planning and diversification, can create inventory buffers and can monitor where and when risks may materialise.[^3] For climate risks it highlights understanding and diversifying the geographic location of suppliers, which lowers the effect of any single region's risks.[^3]

The White House 100-day review says that tools including ally and friend-shoring and stockpiling, along with investments in sustainable domestic production and processing, will all be necessary to strengthen resilience.[^2]

## Where the sources disagree

The World Trade Organization takes a different view of some of those tools. It concludes that the answer to national economic resilience lies in expanding and diversifying trade, not restricting or reshoring it, and warns that reshoring or friend-shoring could make supply chains more fragile by cutting off global options.[^4] The White House report and the WTO are making policy arguments, and neither tests its claims in the text opened here.

## Component pages

Elements named above have their own pages: [[Supply Chain Redundancy]], [[Strategic Stockpile]], [[Supplier Diversification]] and [[Supply Chain Regionalisation]]. The outcome sought is [[Supply Chain Resilience]], and the process that selects the actions is [[Supply Chain Risk Management]].

[^1]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^2]: The White House, report under Executive Order 14017, June 2021, “Building Resilient Supply Chains, Revitalizing American Manufacturing, and Fostering Broad-Based Growth: 100-Day Reviews under Executive Order 14017”. https://bidenwhitehouse.archives.gov/wp-content/uploads/2021/06/100-day-supply-chain-review-report.pdf
[^3]: UK Climate Change Committee, “Resilient Supply Chains (briefing, 2022)”. https://www.theccc.org.uk/wp-content/uploads/2022/10/Resilient-Supply-Chains-.pdf
[^4]: World Trade Organization, “World Trade Report 2023: Re-globalization for a secure, inclusive and sustainable future”. https://www.wto.org/english/res_e/booksp_e/wtr23_e/wtr23_e.pdf

