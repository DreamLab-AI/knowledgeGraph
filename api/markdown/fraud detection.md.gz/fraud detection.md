Fraud detection is the automated or semi-automated identification of deceptive, unauthorised, or anomalous activities—such as payment fraud, account takeover, synthetic identity creation, and insurance claim manipulation—using statistical models, machine learning classifiers, graph analytics, and rule-based engines applied to transactional, behavioural, and network data. The field operates under severe class-imbalance constraints where fraudulent events are rare relative to legitimate activity, demanding specialised sampling strategies such as SMOTE and evaluation metrics including precision-recall curves and F1 scores. Modern production systems combine ensemble methods such as gradient-boosted trees for rapid inference with deep learning approaches including graph neural networks and LSTM sequence models to capture both point-in-time anomalies and temporal patterns indicative of coordinated fraud schemes. Explainability of model decisions is increasingly mandated by financial regulators to support human review of adverse determinations and compliance with consumer protection law.

### Overview

- Fraud detection spans a broad set of financial and digital risk disciplines concerned with detecting, preventing, and investigating deceptive activities before or after they cause harm.
- It is foundational to the operation of payment networks, online banking platforms, insurance systems, e-commerce marketplaces, and telecommunications providers, each presenting distinct feature engineering challenges.
- The detection problem is characterised by:
  - Severe class imbalance — legitimate transactions vastly outnumber fraudulent ones
  - Concept drift — fraud patterns evolve rapidly as adversaries adapt to countermeasures
  - Low-latency requirements — decisions on card transactions may need to complete within 100–300 milliseconds
  - Adversarial dynamics — fraudsters actively probe detection systems to find blind spots
- Economic significance is high: payment card fraud, account takeover, and synthetic identity fraud represent large categories of financial loss for banks, insurers, merchants, and consumers globally.
- The field has matured from simple rule-based systems in the 1990s through statistical score-card models to modern ensemble and deep learning pipelines, and is now integrating [[Federated Learning]] and [[Blockchain Analytics]] for cross-institution cooperation.

### Key Components

#### Data Sources and Feature Engineering

- Transaction-level features: amount, merchant category code, time of day, geographic location, transaction velocity
- Device and network signals: device fingerprints, IP geolocation, browser user-agent, session duration
- Behavioural signals: keystroke dynamics, mouse movement, navigation patterns — see [[Behavioural Biometrics]]
- Graph-structured data: networks of accounts, devices, IP addresses, and merchants enabling ring-fraud detection
- Historical aggregates: rolling-window statistics over hours, days, and months per customer
- [[Feature Engineering]] is a critical bottleneck; domain expertise determines which signals separate fraud from legitimate activity

#### Detection Approaches

- **Rule-based systems**: velocity rules, spend-limit thresholds, country-block lists; fast and interpretable but brittle to novel patterns
- **Statistical scoring**: logistic regression, scorecard models; foundation of legacy banking fraud systems
- **Gradient-boosted trees**: XGBoost, LightGBM — dominant in production for tabular transactional data due to speed, accuracy, and relative interpretability
- **[[Anomaly Detection]]**: autoencoders, isolation forests, one-class SVM — used when labelled fraud examples are scarce or entirely absent
- **[[Supervised Learning]]** classifiers: trained on labelled fraud/non-fraud pairs; require high-quality [[Data Labelling]]
- **Sequence models**: LSTM and Transformer architectures over ordered transaction histories, capturing temporal dependencies indicative of progressive account compromise
- **[[Graph Neural Network]]**: model multi-relational networks of accounts, beneficiaries, and devices to detect synthetic identity clusters and money-mule networks invisible to row-level models

#### Class Imbalance Handling

- Oversampling of minority class: SMOTE (Synthetic Minority Over-sampling Technique) and variants
- Undersampling of majority class: random undersampling, Tomek links
- Cost-sensitive learning: asymmetric loss functions penalising false negatives more heavily
- Evaluation: precision-recall area under curve (PR-AUC) preferred over ROC-AUC in high-imbalance settings

#### Real-Time Inference

- Low-latency scoring engines consuming events from [[Data Stream Processing]] platforms such as Apache Kafka and Apache Flink
- Feature stores providing pre-computed aggregates for sub-millisecond feature retrieval
- Model serving via REST or gRPC endpoints with strict SLA requirements
- [[Real-Time Data Pipelines]] integrate event streams, feature stores, model servers, and decisioning engines

### Applications and Use Cases

#### Payment Fraud

- Card-present and card-not-present fraud detection at point of sale and e-commerce checkout
- 3-D Secure authentication risk scoring — issuer-side decision on step-up authentication requirement
- Chargeback prediction and dispute management
- Cross-border transaction risk assessment

#### Account Takeover and Identity Fraud

- Login anomaly detection: new device, new location, impossible travel heuristics
- Credential stuffing detection via login velocity and bot-signal analysis
- Synthetic identity detection: fictitious identities assembled from real and fabricated data components — addressed through [[Know Your Customer]] enrichment and graph linkage analysis
- [[Digital Identity]] verification integration to confirm claimed identities at onboarding

#### Anti-Money Laundering

- [[Anti-Money Laundering]] transaction monitoring: structuring detection, layering pattern recognition over multi-hop payment networks
- Customer risk scoring and enhanced due diligence triggers
- Sanctions screening and politically exposed persons (PEP) list matching using [[Natural Language Processing]]
- Suspicious Activity Report (SAR) narrative generation assistance

#### Insurance and Healthcare

- Insurance claim anomaly detection: duplicate claims, provider billing fraud, staged accidents
- Healthcare billing fraud: CPT code pattern analysis, outlier provider detection

#### E-commerce and Digital Platforms

- Seller fraud and counterfeit goods detection on marketplace platforms
- Promo abuse and coupon fraud detection
- Ad fraud detection: invalid traffic, click fraud, impression fraud

#### Cryptocurrency and [[Blockchain Analytics]]

- On-chain transaction graph analysis for address clustering and entity attribution
- Exchange-level deposit/withdrawal anomaly detection
- Ransomware wallet tracking and sanctions compliance

### Standards and Regulatory Context

#### Financial Regulation

- **PSD2 (EU Payment Services Directive 2)**: mandates Strong Customer Authentication (SCA) and provides regulatory technical standards for transaction risk analysis exemptions, directly governing payment fraud detection in the EU
- **Bank Secrecy Act (BSA) / Anti-Money Laundering Act 2020 (US)**: requires transaction monitoring programmes generating SAR filings; regulators expect firms to use advanced analytics
- **FCA Consumer Duty (UK)**: requires firms to prevent foreseeable harm, including fraud-related harm, influencing how fraud models must be operated and explained
- **GDPR and UK GDPR**: restrict use of personal data in automated decision-making; adversely affected individuals have the right to human review, driving [[Explainable AI]] adoption

#### Industry Standards

- **PCI DSS (Payment Card Industry Data Security Standard)**: governs security of cardholder data environments; compliance is a prerequisite for operating card fraud detection infrastructure
- **ISO 20022**: next-generation financial messaging standard enriching payment data available for fraud analytics
- **FATF Recommendations**: international AML/CFT standards influencing national transaction monitoring requirements globally

#### Explainability Requirements

- Regulators including the US OCC and EU EBA have issued guidance expecting financial institutions to be able to explain automated model decisions affecting customers
- SHAP (SHapley Additive exPlanations) and LIME (Local Interpretable Model-agnostic Explanations) are the de facto standard tools for post-hoc explanation of fraud model outputs
- Model risk management frameworks (SR 11-7 in the US) require validation of all models used in fraud detection

### Challenges and Emerging Directions

- **Concept drift**: fraud patterns evolve continuously as adversaries adapt; models require frequent retraining and monitoring pipelines
- **Federated learning**: [[Federated Learning]] enables cross-institution fraud pattern sharing without exposing raw transaction data, addressing data-sharing constraints between competing financial institutions
- **Adversarial robustness**: fraudsters use adversarial machine learning techniques to probe and evade deployed models
- **Synthetic data**: generative models are used to augment training data for rare fraud types, raising model validation challenges
- **Multi-modal fusion**: integrating text (messages, documents), images (identity documents, receipts), and structured transaction data within unified detection pipelines
- **Graph foundation models**: pre-trained graph models for financial networks, enabling transfer learning across institutions with limited labelled fraud data
- **Privacy-preserving computation**: homomorphic encryption and secure multi-party computation enabling collaborative fraud analytics across institution boundaries without data exposure

### Provenance

