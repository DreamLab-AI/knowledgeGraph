A cybersecurity framework is a structured set of standards, guidelines and practices that organisations use to identify, protect against, detect, respond to and recover from cyber threats. Frameworks such as the NIST Cybersecurity Framework provide a common taxonomy and maturity model for managing security risk in a repeatable, auditable way. They align technical controls with governance, risk management and regulatory obligations.

### Overview

- A cybersecurity framework organises security activity into functions, typically identify, protect, detect, respond and recover, each decomposed into categories and controls mapped to informative references. Organisations assess their current posture against target profiles, prioritise gaps by risk, and track maturity over time. The framework provides a shared language between technical teams, executives and regulators, and underpins audit and certification.

### Key aspects

- Core functions of identify, protect, detect, respond, recover
- Control catalogues mapped to risk and regulatory references
- Maturity profiles and gap assessment
- Integration with enterprise risk management
- Audit, certification and continuous improvement

### Applications

- Enterprise security programme governance
- Regulatory and contractual compliance demonstration
- Third-party and supply-chain risk assessment
- Board-level reporting on cyber risk posture

### Provenance

