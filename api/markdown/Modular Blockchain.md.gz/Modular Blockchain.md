A modular blockchain is a blockchain architecture that separates the core functions of execution, settlement, consensus, and data availability into distinct, specialised layers rather than handling them all in a single monolithic chain. Each layer can be optimised and scaled independently, and components can be mixed and matched across networks. This decomposition aims to overcome the scalability constraints of monolithic designs while preserving security and decentralisation.

### Overview

- Modular blockchains reframe scaling as an architectural problem. Where a monolithic chain forces every node to execute every transaction, store all data, and reach consensus together, a modular stack lets dedicated layers handle each responsibility, so specialised data-availability and consensus layers can serve many execution layers above them.

### Mechanisms

- The execution layer processes transactions and updates state, typically as a rollup.
- The settlement layer verifies proofs, resolves disputes, and anchors execution layers.
- The consensus layer orders transactions and provides finality across participants.
- The data-availability layer guarantees that transaction data is published and retrievable, often via data-availability sampling.

### Applications

- Scalable rollup ecosystems that share a common data-availability layer.
- Application-specific chains that reuse external consensus and settlement.
- Interoperable multi-chain networks built from specialised, composable layers.

### Provenance

