The basic rights and freedoms guaranteed to individuals by constitutional orders and supranational charters — dignity, privacy, freedom of expression, equality, non-discrimination, and effective remedy among them — which bind public authorities and increasingly shape technology governance, serving as the normative benchmark for instruments such as the EU Charter of Fundamental Rights, the GDPR, and the EU AI Act.

### Semantic Classification

### Content

## Definition

**Fundamental rights** are the basic entitlements a legal order guarantees to individuals against the state and, in defined circumstances, against private actors: human dignity, life and integrity, liberty, privacy and data protection, freedom of expression and assembly, equality and non-discrimination, fair trial, and effective remedy. The term is closely related to "human rights" but carries a jurisdictional inflection: human rights denote universal moral-legal claims articulated in international instruments (the Universal Declaration, the ICCPR, the European Convention on Human Rights), while fundamental rights are those claims as entrenched and enforceable within a specific constitutional order — the EU Charter of Fundamental Rights, the German Grundrechte, or rights given domestic effect in the UK through the Human Rights Act 1998. [[Human Rights Law]] is the body of doctrine and adjudication through which both are implemented.

Their operation depends on the [[Rule of Law]]: rights are only meaningful where public power is exercised under law, subject to independent courts and proportionality review. Most fundamental rights are qualified rather than absolute — interference is lawful only if prescribed by law, in pursuit of a legitimate aim, and necessary and proportionate — a structure that supplies the analytical machinery for nearly all technology-policy disputes, from surveillance to content moderation.

In digital governance, fundamental rights have become the explicit design benchmark. The GDPR is formally an implementation of the Charter's Articles 7 (private life) and 8 (data protection); the EU AI Act classifies systems as high-risk according to their potential impact on fundamental rights and mandates fundamental-rights impact assessments for certain deployers; and the [[EU HLEG AI]] Ethics Guidelines for Trustworthy AI ground their entire framework in fundamental rights as the source of ethical principles for AI development.

## Current Landscape

- **Instruments**: EU Charter of Fundamental Rights (binding since 2009), European Convention on Human Rights enforced by the Strasbourg court, national constitutional catalogues, and the UN framework including the Guiding Principles on Business and Human Rights
- **Technology jurisprudence**: CJEU rulings on data retention (Digital Rights Ireland), transfers (Schrems I/II), and the right to erasure (Google Spain) show fundamental rights invalidating or reshaping digital legislation and practice
- **AI governance**: the EU AI Act (Regulation (EU) 2024/1689) entered into force on 1 August 2024; its Article 27 requires deployers that are public bodies, private providers of public services, and certain other Annex III deployers to perform a Fundamental Rights Impact Assessment (FRIA) before first use, with the AI Office to supply a template questionnaire
- **Council of Europe**: the Framework Convention on Artificial Intelligence, Human Rights, Democracy and the Rule of Law — the first binding international AI treaty — was opened for signature on 5 September 2024 and signed by the EU, extending rights-based, lifecycle risk-assessment obligations (Article 16) beyond the Union
- **Institutions**: the EU Agency for Fundamental Rights (FRA) published *Assessing High-risk Artificial Intelligence: Fundamental Rights Risks* in November 2025, offering a step-by-step FRIA method keyed to the Charter; national equality bodies and data-protection authorities act as day-to-day enforcers
- **Open tensions**: horizontal effect between private parties, extraterritorial reach of rights-based regulation, and reconciling innovation policy with precautionary rights protection

  **Sources**:

- https://artificialintelligenceact.eu/article/27/
- https://fra.europa.eu/en/publication/2025/assessing-high-risk-ai
- https://www.tandfonline.com/doi/full/10.1080/20508840.2025.2492524

