Virscapes are AI-generated virtual landscape images produced by training generative adversarial networks (StyleGAN) on a curated dataset of digital game landscapes collected over seven years, exploring latent space to create emotionally resonant synthetic environments. The practice investigates questions of landscape identity, simulacra, and the distinction between human aesthetic curation and algorithmic generation in digital art.

### Semantic Classification

### Content

# Virscapes paper

- Light lit survey of praxis artists and movements
  - The term Landvættir is an old Nordic phrase used to describe the souls/spirits that inhabit and protect the natural landscapes; the soul of a landscape so to speak. Whilst our physical landscapes and presence will eventually diminish, our interpretations and experiences of these ‘places’ albeit virtual will endure. Landvættir  is an attempt to manifest the Greek aphorism; *Ars longa, vita brevis*
  - Many still feel virtual worlds, are just that, a cheap imitation of reality, a replica of the ‘real’ thing, nothing more than a *simulacra*, a fake copy that as Plato argued was a distortion and a deviation of truth. The word *Simulacra  *has long been a focal point for philosophers, with its roots stemming from classical Greek philosophy, in particular Plato’s dialogues to the modern day as Jean Baudrillard, the postmodern social theorist, who unlike Plato argued the simulacra was not a copy but in fact a truth, in its own right:* “The simulacrum is never that which conceals the truth--it is the truth which conceals that there is none…..The simulacrum is true*.” (Poster & Mourrain, 2002, pp.166-184)
  - We have witnessed  the birth not only a new epoch of artistic practice but perhaps something far more deeper a new intelligence, not artificial but evolutionary intelligence; one that threatens as much as it promises. The embryonic precursor digital landscapes we ‘play’ and create today are far more fragile that we could ever comprehend; undermined by the notion that there are simple digital entities can be replicated and saved with ease…..however how we experienced them, as individuals and the grater collective, the impact on our every evolving and transient *collective unconscious*, all the spaces inbetween cannot.
  - Landvættir explores notions of latent space  (the space in between the generated data) as it in ways reflects the experience and perceptions of digital landscape art; beyond the digital/binary representation there is a another layer; fleeting
  - **If the generations of A.I to follow dream of the first virtual places, will they dream of Turner, Constable and Monet? Or would they dream of the precursor virtual landscapes where the seeds of their intelligence took hold and began to grow?**
  - Landvættir explores an alternative approach to generative  A.I art. Contemporary approaches to generative adversarial network art heavily utilize image scrapping to form the foundation of the dataset’s used to train generative models; however Landvættir ‘virscapes’ are perhaps the world first that use a curated dataset of digital landscapes (created as part of a 7 year doctoral study project) thousands of virtual game landscapes were collected and used to generate the digital Landvættir ‘virscapes’. The virscapes are not simply generated from a ‘mass farming’ of images; but one that has been curated, not driven by metadata alone but from the individual and collective  emotional responses of players and virtual landscape inhabitants driving the selection of virtual landscapes to include across three decades.
- Grounding
  - Identity
  - Beeple, Banksy, anonymity, NFTs, digital, community
    - The overpowering nature of external perceptions of identity
  - The empowering potential of anonymity for experimentation
    - How does AI view these things?
- Early experimentation
  - GANs
  - Embed emotion
  - Very high resolution
- Methodology
  - Data preperation
  - Curation of landscapes
    - Intentionally minimising human curation and preference / influence
  - Data manipulation
    - Aspect ratios, resizing
    - Managing distortions through automation
    - RunwayML (studio?
  - sunsetted)
  - Building on Ann Spelters working
  - Steps and Epochs
  - Referencing style gans
    - Dreaming up imaginary landscapes with Runway ML & StyleGAN
    - A no-code and step-by-step account of training a Generative Adversarial Network (GAN) to generate places that don’t exist
  - Generating process
  - dig out the details
    - Need to disambiguate the terminology
    - Volumes (runs) of generation
  - Latent space exploration
    - videos and animations
      - co-proximate n dimension embeddings in latent space have sufficient similarity to tween / animate
  - Outputs
    - Image sets
      - Anchor in place and meaning
        - Human guided process
  - imprinting of the artist's preference
    - Image examples section in the paper
      - Olympus Mons
      - Alderly Edge
      - Personal History
      - Mountains in Pakistan
      - Scarfell Pike
      - French Tuscon in late summer
    - Reflection on the moment
      - Surfacing of emergent and meaningful work through the process
    - Video
      - Landschap
        - Landschap is a Dutch term that translates to "landscape" in English. It refers to the physical features and characteristics of a particular area of land, including its natural elements such as mountains, hills, rivers, and vegetation, as well as any human-made elements such as buildings, roads, and infrastructure.
        - A landschap can be diverse and varied, ranging from vast stretches of open fields and farmland to rugged mountain ranges or coastal regions with sandy beaches and cliffs. Each landschap has its own unique qualities and ecosystem, shaped by natural processes like erosion, deposition, and climate, as well as human activities like agriculture, urbanization, and land management.
        - The concept of landschap goes beyond just the physical aspects and also encompasses the cultural, historical, and social dimensions of a place. It reflects the interactions and relationship between people and their environment, including the ways in which they have shaped and been influenced by the natural world around them.
        - Landschap is not only a visual representation of a particular area but also holds significant value for various purposes. It can serve as a source of inspiration for artists, writers, and poets, who often find beauty and meaning in the unique characteristics of different landscapes. Additionally, various field of studies like geography, ecology, and landscape architecture are devoted to understanding and analyzing landschaps to better manage and preserve natural resources, protect biodiversity, and create sustainable environments.
        - In summary, landschap refers to the physical and cultural characteristics of a particular area of land, highlighting the interactions between people and their environment. It encompasses both natural and human-made elements and holds significance for various purposes, including aesthetics, recreation, and scientific research.
    - Acoustic exploration
      - Generative audio
  - Sharing and surfacing under a pseudonym for critical reponse
    - Popularity
  - Resolution and upscaling
    - Develop and evolve
    - Topaz Gigapixel
      - This is a further AI emergent exploration.
      - Where does it break down
      - What are the emergent and interesting features
      - Iterate to 32k with internal consistency through recursion
        - White Forest
  - HalfLife callback? Cohesion was maintained.
    - Challenges in viewing the images.
      - Print format
      - Installations for Hospitals and charities idea
      - Zoomify and Silverlight (mothballed)
      - Gigamacro.com (to check)

      ```<iframe src="https://viewer.gigamacro.com/" style="width: 100%; height: 600px"></iframe>```
      ```

    - Planned to finish
      - Curate to book
      - Curate to website
      - Embed in wider narrative

# Transcript summary

- **Introduction to the Project:**
  - Originating in the early excitement around NFTs in 2021, the project aimed to bridge digital artists and new media artists into the burgeoning NFT market. This period saw a proliferation of NFT exchanges, with a wide spectrum from the open, non-curated platforms reminiscent of eBay, to the more selective and artistically rigorous ones like Super Rare.
  - The project's inception was marked by a fascination with the ways in which digital and virtual spaces could be curated, owned, and traded, sparking a deep exploration into the possibilities of NFT technology as a medium for artistic expression.
- **Technological Exploration and Artistic Intent:**
  - The transition from traditional digital platforms to NFT-based exchanges offered a unique lens through which the project explored the digital art landscape. Special attention was given to how these platforms enabled or constrained artistic expression.
  - Influential works and artists, such as "Dark Castles" by Anne Speelter, served as touchstones for the project, inspiring a deeper investigation into how virtual landscapes could be rendered, experienced, and owned through the lens of NFTs and AI-generated art.
  - A significant portion of the discussion was dedicated to generative AI technologies, particularly StyleGAN, which was utilized to produce complex, emotionally resonant landscapes. This exploration was not just technical but deeply intertwined with artistic intent, aiming to push the boundaries of what AI can create.
- **Methodological Approach:**
  - A deliberate decision was made to strip away pre-existing structures and conventions in digital art to allow for an uninhibited exploration of new landscapes. This approach was both a philosophical stance and a practical method to encourage innovation.
  - The curation of a dataset for AI training was approached with meticulous care, aiming to balance artistic vision with the capabilities and tendencies of AI technologies. The goal was to foster a synergy between human creativity and algorithmic generation, leading to artworks that were both unique and reflective of the artist's intentions.
- **Artistic and Emotional Dimensions:**
  - Central to the project was the ambition to infuse AI-generated landscapes with emotional depth and narrative richness. This ambition reflects a broader artistic endeavor to see landscapes not just as physical or virtual spaces but as canvases for emotional expression and storytelling.
  - The conversation explored the intrinsic connection between landscapes and emotional states, positing that both real and virtual landscapes have the power to evoke a wide range of feelings and thoughts. This connection was a key driver in the project's exploration of digital landscapes, guiding the artistic process and the selection of themes and motifs.
- **Reflections on Public Perception and Artistic Identity:**
  - An insightful discussion on how digital and AI-generated art is received by the public and the art community highlighted the challenges and opportunities in this domain. There was a keen awareness of the need to navigate public perceptions while staying true to one's artistic identity.
  - The role of naming and framing AI-generated art was emphasized as crucial for embedding the artworks in a context that resonates with audiences. This process was seen as essential for adding layers of meaning and connecting the virtual landscapes to real or imagined geographies and narratives.
- **Technological Challenges and Innovations:**
  - Technical aspects of the project were addressed, including the challenges of adapting image aspect ratios for AI processing. This technical hurdle was illustrative of the broader challenges in merging artistic vision with AI capabilities.
  - The use of tools like Runway ML was highlighted for their ability to generate landscapes by navigating the latent space of images. These technological explorations were not just about overcoming limitations but also about uncovering new possibilities for artistic expression.
- **Future Directions and Reflections:**
  - Speculation on the future role of AI in art, particularly in how AI might come to interpret and create landscapes, was a theme of keen interest. This forward-looking perspective underscored the project's commitment to being at the forefront of technological and artistic innovation.
  - Reflecting on the integration of technology and art, the conversation touched upon the desire to create works that are not only technologically advanced but also deeply meaningful. The project was framed as a journey into uncharted territories where art and technology meet, offering new ways to understand and appreciate landscapes, both real and imagined.
- **Data Curation and AI Training**: A meticulous approach to curating datasets for AI training was employed, focusing on collecting images that aligned with the project's artistic vision. This dataset served as the foundation for training StyleGAN models, ensuring that the generated landscapes were not only high quality but also resonant with the intended emotional and aesthetic themes.
- **Generative AI Technologies**: The project leveraged generative AI technologies, primarily StyleGAN, to produce complex and emotionally resonant landscapes. This involved experimenting with different parameters and training techniques to guide the AI in generating artworks that reflected the project's artistic objectives.
- **AI and Human Collaboration**: A key methodological aspect was the collaborative process between the AI and the artists. This included iterative cycles of generation and curation, where artists would fine-tune AI outputs to better reflect their visions, highlighting the project's emphasis on a symbiotic relationship between technology and creativity.
- **Adapting to Technical Challenges**: The project also involved innovative solutions to technical challenges, such as adapting image aspect ratios for optimal AI processing. Tools like Runway ML were utilized to explore the latent space of images, enabling the creation of landscapes that pushed the boundaries of traditional digital art forms.
  Looking ahead, the project anticipates several future directions and opportunities for growth:
- **Deepening AI Integration**: Future work aims to deepen the integration of AI in the creative process, exploring more advanced AI models and training techniques to generate increasingly sophisticated and nuanced landscapes. This includes leveraging advancements in AI to better interpret artistic intent and emotional subtleties.
- **Expanding the NFT Ecosystem**: The project seeks to explore new ways to engage with and expand the NFT ecosystem, looking at innovative models for artist remuneration, ownership, and interaction within digital spaces. This could involve creating more interactive and immersive NFT experiences that go beyond static images.
- **Cross-disciplinary Collaborations**: There's an interest in fostering cross-disciplinary collaborations that merge art, technology, and other fields such as environmental science or urban planning. These collaborations could lead to projects that not only push artistic boundaries but also engage with pressing global issues.
- **Public Engagement and Education**: Another future direction involves greater public engagement and educational efforts. This could include workshops, exhibitions, and discussions that demystify AI and NFT technologies, fostering a broader understanding and appreciation of digital art.
- **Exploring New Themes and Narratives**: The project is also keen on exploring new themes and narratives within digital landscapes, pushing into uncharted territories that challenge conventional perceptions of space, identity, and reality in the digital age.

### Future Scope:

### Provenance

