The WCO SAFE Framework of Standards to Secure and Facilitate Global Trade is an instrument that WCO Members adopted at the World Customs Organization (WCO) Council Sessions in Brussels in June 2005, setting standards for supply chain security and facilitation.[^1]

The WCO says the Framework ushered in modern supply chain security standards and a new approach to end-to-end management of goods moving across borders, with closer partnership between customs and business.[^1] It has been regularly updated. Additions include provisions on Authorized Economic Operators, Coordinated Border Management and Trade Continuity and Resumption, a third pillar on customs and other government agencies, and pre-loading advance cargo information for air cargo. The latest version opened was updated in 2021.[^1]

## Core elements and pillars

The Framework has five core elements.[^1] First, it harmonises advance electronic cargo information requirements on inbound, outbound and transit shipments. Second, each country that joins commits to a consistent risk management approach to security threats. Third, at the reasonable request of the receiving nation and based on a comparable risk targeting methodology, the sending nation's customs administration will perform an outbound inspection of high-risk cargo or conveyances. Fourth, it suggests benefits customs will provide to businesses that meet minimal supply chain security standards and best practices. Fifth, it promotes close cooperation with other governmental agencies in order to keep societies safe and secure while facilitating the movement of goods.[^1]

These rest on three pillars: customs-to-customs network arrangements, customs-to-business partnerships and customs-to-other government agencies co-operation.[^1] The WCO introduced its Authorized Economic Operators programme in 2007 as the flagship customs-business partnership programme; see [[Authorised Economic Operator]].[^2]

## Scope and distinctions

The Framework is a WCO instrument, adopted by customs administrations, rather than a treaty of the [[World Trade Organization]]. For the WTO instrument see [[WTO Trade Facilitation Agreement]]. The Framework pairs security with [[Trade Facilitation]].[^1] Its objectives include strengthening cooperation between customs administrations and other government agencies, for example through a [[Single Window]].[^1] The WCO is covered at [[World Customs Organization]]; see also [[Customs Trade Facilitation]].

## Correction to the earlier text

Earlier text on this page described four core elements. Both WCO sources opened say five, so the page now follows them.[^1][^2]

## What the sources do not establish

No opened source gives the number of WCO Members that have implemented the Framework or its legal status in national law. Only the 2021 text and the WCO AEO programme page were opened, not earlier editions.

[^1]: World Customs Organization, “SAFE Framework of Standards 2021”. https://www.wcoomd.org/-/media/wco/public/global/pdf/topics/facilitation/instruments-and-tools/tools/safe-package/safe-framework-of-standards.pdf
[^2]: World Customs Organization, AEO programme About page. https://aeo.wcoomd.org/about

