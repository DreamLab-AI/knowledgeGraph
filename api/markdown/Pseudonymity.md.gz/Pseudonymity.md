Pseudonymity is the property of operating under a persistent, stable identifier that is not directly linked to a participant's real-world legal identity, enabling consistent reputation and accountability without exposing personal information. Unlike full anonymity — where individual actions cannot be attributed to any consistent actor — pseudonymity preserves linkability across interactions under the chosen identifier while severing the mapping to biological or legal selfhood. The pseudonymous identifier may be a username, cryptographic public key, or blockchain address; its strength depends on the isolation of contextual signals that could enable de-anonymisation. Pseudonymity is foundational to privacy-preserving communication, decentralised identity systems, and selective-disclosure credential architectures.

### Overview

- Pseudonymity is a foundational concept across security, cryptography, communications, and decentralised systems. The word derives from the Greek *pseudōnymos* (false name) and has been practised since antiquity — authors writing under pen names, activists using aliases — but has taken on new technical precision in the digital era.
- A pseudonymous actor uses a chosen identifier (username, cryptographic [[Public Key Cryptography]] address, or [[Decentralised Identifier]]) that may accumulate reputation, history, and trust, yet no automatic mechanism links that identifier to the holder's legal name or physical location.
- The security-relevant distinction is the *linkability spectrum*:
  - **Full anonymity**: individual actions cannot be linked to any consistent actor.
  - **Pseudonymity**: actions are linkable to a persistent identifier but not to a real-world person.
  - **Identified**: actions are directly linked to legal identity (e.g. passport-verified).
- Pseudonymity is not an absolute guarantee; [[Deanonymisation]] attacks — via traffic analysis, metadata correlation, or on-chain analytics — can re-link pseudonymous identifiers to real identities if the actor leaks contextual signals. Robust pseudonymity therefore depends on deliberate operational security and, increasingly, on cryptographic reinforcement.
- The value proposition of pseudonymity is its balance: it permits participation in digital systems with measurable, long-term reputation building (a property absent from pure [[Anonymity]]) while protecting the holder from targeting based on real-world identity. This balance makes pseudonymity the dominant identity model in open decentralised networks, peer-to-peer file sharing, whistleblowing infrastructure, and [[Self-Sovereign Identity]] frameworks.
- Pseudonymity has both social and technical dimensions. The technical dimension concerns the cryptographic and protocol mechanisms that make an identifier unlinkable to a legal identity. The social dimension concerns norms, platform policies, and legal frameworks that determine when and whether pseudonymous actors can be compelled to disclose their real identity — a central tension in platform [[Governance]] and digital rights discourse.

### Key Mechanisms

- **Persistent pseudonym creation**
  - The actor generates or adopts a stable identifier independent of legal identity: a username on a forum, an asymmetric [[Key Pair]], or a W3C [[Decentralised Identifier]].
  - The identifier must be self-generated or issued by a party that does not record real-world identity linkage.
- **Cryptographic pseudonymity**
  - [[Public Key Cryptography]] enables pseudonymity via key pairs: the public key serves as the pseudonym; ownership is proved by signing with the corresponding private key, with no third-party identity authority needed.
  - [[Zero-Knowledge Proof]] schemes allow a holder to prove properties of their identity (membership in a group, possession of a credential) without revealing the underlying pseudonym or its linkage to other contexts.
  - [[Ring Signature]] constructions hide which member of a defined group signed a message, strengthening pseudonymity toward anonymity for that specific assertion.
  - [[Hash Function]]s create one-way commitment schemes that can bind credentials to a pseudonymous identifier without revealing the underlying data.
- **Selective disclosure**
  - [[Selective Disclosure]] allows a pseudonymous actor to reveal specific attributes (e.g. "over 18", "citizen of jurisdiction X") from a [[Verifiable Credential]] without exposing other attributes or the credential's full contents. This is central to privacy-respecting identity architectures such as the W3C [[W3C DID Core]] specification.
- **Contextual separation**
  - Strong pseudonymity requires that an actor maintain distinct pseudonyms in distinct contexts (forum, financial system, social network) so that cross-context correlation is not possible. Failure to separate contexts is a common deanonymisation vector.
- **Operational security (OPSEC)**
  - Technical pseudonymity is undermined by metadata leakage: writing style, IP address, timing patterns, associated accounts. Tools such as [[Tor Network]] route traffic through onion layers to prevent IP-based deanonymisation, but are not sufficient alone.

### Applications and Use Cases

- **Blockchain and cryptocurrency**
  - Blockchain addresses (e.g. Bitcoin's UTXO addresses, Ethereum account addresses) are the canonical example of practical pseudonymity at scale. Addresses are not inherently linked to legal identity, yet the transparent ledger links all transactions from a given address, creating a pseudonymous audit trail. [[Blockchain]] analytics firms specialise in chain-tracing and cluster analysis to deanonymise wallets.
  - Privacy-focused ledgers (Zcash, Monero) apply [[Zero-Knowledge Proof]] and [[Ring Signature]] techniques to strengthen pseudonymity toward unlinkability.
- **Decentralised identity**
  - W3C [[Decentralised Identifier]]s (DIDs) and [[Verifiable Credential]]s form an architecture where users control pseudonymous identifiers across contexts and selectively disclose attestations. [[Self-Sovereign Identity]] (SSI) systems build on this to give users portable, privacy-preserving digital identity without centralised registries.
- **Online communication and journalism**
  - Activists, journalists, and [[Whistleblowing]] sources operate pseudonymously to communicate sensitive information without personal risk. Platforms such as SecureDrop combine pseudonymous accounts with [[Tor Network]] routing.
- **Open-source development**
  - Many significant open-source contributors operate pseudonymously (e.g. Satoshi Nakamoto). Pseudonymity enables contribution without professional or personal risk in politically sensitive or commercially competitive areas.
- **Reputation and trust systems**
  - [[Reputation System]]s in decentralised marketplaces or federated social networks rely on pseudonymous identifiers accumulating verifiable history. A pseudonym can be trusted not because we know the human behind it but because its track record is visible and tamper-evident.
- **Regulatory and compliance contexts**
  - [[GDPR]] and similar data-protection regimes treat pseudonymisation as a data-protection technique: replacing directly identifying fields with pseudonyms reduces, but does not eliminate, risk under the regulation (because re-identification via auxiliary data remains possible, distinguishing pseudonymisation from anonymisation).
- **Gaming and virtual worlds**
  - User accounts in online games and [[Metaverse]] platforms are inherently pseudonymous; the avatar or username is the social actor. [[Identity Management]] in these contexts involves reputation, asset ownership, and access rights attached to the pseudonym.

### Standards and Governance Context

- **W3C DID Core (Decentralized Identifiers v1.0)** — defines a URI scheme for pseudonymous, controller-owned identifiers resolvable without a central registry. DIDs are the primary standardised expression of cryptographic pseudonymity.
- **W3C Verifiable Credentials Data Model** — defines how [[Verifiable Credential]]s are issued and presented, enabling selective disclosure of attributes tied to pseudonymous DIDs.
- **ISO/IEC 29101 (Privacy Architecture Framework)** — provides a framework that explicitly recognises pseudonymity as one of the privacy-enhancing identity states alongside anonymity and identifiability.
- **GDPR (EU 2016/679), Recital 26 & Article 4(5)** — defines pseudonymisation as processing personal data in such a way that it can no longer be attributed to a specific data subject without the use of additional information; encourages pseudonymisation as a risk-reduction measure but does not treat it as equivalent to anonymisation.
- **NIST SP 800-188** — addresses de-identification and pseudonymisation of federal datasets, including risk frameworks for re-identification.
- **ISO/IEC 24760 (Identity Management)** — provides foundational definitions for identifiers, attributes, and identity lifecycles that underpin pseudonymity concepts.
- **eIDAS 2.0 (European Digital Identity Wallet)** — introduces EU-mandated digital identity wallets that incorporate pseudonymous presentation modes, allowing citizens to prove specific attributes without disclosing their full identity to relying parties.
- **IETF RFC 7800 (Proof-of-Possession Key Semantics for JWTs)** — enables binding of cryptographic keys to [[Verifiable Credential]]-like tokens, supporting pseudonymous but verifiable token-holder assertions.
- **W3C Privacy Principles** — the W3C TAG's Privacy Principles document identifies pseudonymity as a design goal for web specifications, influencing how browser APIs and identity protocols are designed to reduce linkability.

### Threats and Limitations

- **[[Deanonymisation]]**: correlation of pseudonymous identifiers with external datasets (social graph, writing style, timing, IP address) can re-link pseudonyms to legal identity. Even strong cryptographic pseudonymity cannot protect against all contextual leakage.
- **Sybil attacks**: pseudonymity enables one actor to create many pseudonymous identifiers, undermining voting and [[Reputation System]]s and proof-of-work or proof-of-stake mechanisms are deployed as countermeasures.
- **Accountability gap**: pseudonymity can shield malicious actors from legal accountability, creating tension with [[Governance]] and law-enforcement requirements.
- **Linkability across contexts**: using the same pseudonym across multiple contexts (login, forum, financial transaction) aggregates a profile that may be equivalent to identified. Context separation is operationally difficult to maintain.
- **Key compromise**: loss or theft of the private key that controls a pseudonymous identifier can irreversibly expose or transfer the actor's accumulated pseudonymous reputation and history.
- **Metadata persistence**: even when content is pseudonymous, metadata (timestamps, file sizes, access patterns) retained by infrastructure providers may allow re-linkage independently of the identifier itself.

### Design Principles for Robust Pseudonymity

- **Identifier isolation**: each distinct context (professional, social, financial) should use a separately generated pseudonymous [[Identifier]] with no cryptographic or metadata link to other contexts.
- **Minimal disclosure by default**: reveal only the attributes strictly required for a given transaction or interaction; use [[Selective Disclosure]] and [[Zero-Knowledge Proof]] techniques to avoid unnecessary attribute leakage.
- **Key hygiene**: rotate cryptographic keys periodically; use hierarchical deterministic ([[Key Pair]]) schemes to derive context-specific keys from a master seed so that per-context keys are unlinkable without the master.
- **Metadata scrubbing**: strip EXIF data from images, normalise document metadata, and use tools that prevent style fingerprinting before publishing under a pseudonym.
- **Network-layer anonymisation**: pair pseudonymous identifiers with [[Tor Network]] or similar mix-network routing to prevent IP-level correlation with the pseudonym.
- **Credential binding without identity**: when an external attestation is required (age verification, professional qualification), use a [[Verifiable Credential]] with a [[Zero-Knowledge Proof]] presentation rather than sharing the raw credential linked to a legal identity.
- **Auditability vs. privacy trade-off**: system designers must choose the degree to which pseudonymous transactions are auditable. Fully opaque systems risk enabling fraud; fully transparent pseudonymous ledgers risk deanonymisation. Techniques such as confidential transactions and selective audit paths represent intermediate solutions.

### Pseudonymity in Decentralised and Web3 Contexts

- [[Self-Sovereign Identity]] architectures use [[Decentralised Identifier]]s as the pseudonymous anchor for portable digital identity; the holder controls the DID document and chooses which verifiers can see which credentials.
- In [[Blockchain]] ecosystems, pseudonymity is the baseline: wallet addresses serve as pseudonyms, but their public transaction history creates a permanent, globally auditable trail. Layer-2 privacy extensions and off-chain channels (e.g. Lightning Network payment channels) reduce on-chain footprint.
- [[Censorship Resistance]] in decentralised systems depends partly on pseudonymity: if participants cannot be identified, targeted suppression of their keys or addresses requires broad network-level interference rather than identity-specific action.
- Non-fungible token (NFT) ownership, decentralised autonomous organisation (DAO) voting rights, and on-chain governance all rest on pseudonymous key ownership, making [[Identity Management]] for these contexts a distinct challenge compared with traditional enterprise identity.

### Historical and Conceptual Context

- The practice of pseudonymity predates digital computing by centuries: pen names (George Eliot, Mark Twain, Voltaire) served social and political functions analogous to digital pseudonymity.
- Cypherpunk discourse of the 1980s–1990s (Eric Hughes' "A Cypherpunk's Manifesto", Timothy May's "Crypto Anarchist Manifesto") framed pseudonymity as a necessary precondition for freedom of expression and commerce in the digital age, directly motivating the design of Bitcoin's pseudonymous address scheme.
- The academic field of Privacy-Enhancing Technologies ([[Privacy]]) has produced formal models distinguishing anonymity, pseudonymity, and unlinkability — most notably the taxonomy by Pfitzmann and Hansen (2010) which defines these properties rigorously within an attacker model.
- David Chaum's early work on blind signatures (1982) laid the cryptographic foundation for pseudonymous digital cash, later extended by systems such as DigiCash and ultimately the modern generation of privacy-preserving cryptocurrencies.
- The modern revival of interest in pseudonymity coincides with the growth of surveillance capitalism, where platform business models depend on linking pseudonymous accounts to real-world purchase behaviour; this has renewed academic and policy interest in [[Unlinkability]] and data minimisation as design requirements rather than optional add-ons.

### Provenance

