Babylon.js is an open-source, JavaScript and TypeScript real-time 3D rendering engine for the web that drives interactive graphics, games, and immersive experiences through WebGL and WebGPU backends. It provides a scene graph, physically based rendering, a node-based material system, glTF asset loading, an animation system, physics integration, and first-class WebXR support for virtual and augmented reality. As a spatial-computing framework it is a common foundation for browser-delivered metaverse and 3D applications, abstracting low-level GPU programming behind a high-level scene and entity API.

### Overview

- Babylon.js targets the full browser-3D stack: it renders, manages scenes, loads assets, handles input and cameras, and orchestrates the per-frame [[Rendering Pipeline]].
- It supports both WebGL2 and [[WebGPU]] backends, letting the same scene exploit modern compute and rendering features where available and fall back gracefully otherwise.
- The engine emphasises a complete, batteries-included framework with editor tooling, a node material editor, and an inspector, contrasting with leaner libraries like [[Three.js]] that favour minimal core plus ecosystem.
- Its native [[WebXR]] integration makes it a frequent choice for immersive web and browser-based metaverse experiences.

### Key aspects

#### Scene graph and entities

- Hierarchical [[Scene Graph]] of meshes, transform nodes, lights, and cameras with parent-child transforms.
- Component systems for behaviours, animations, and physics colliders.

#### Materials and shading

- [[Physically Based Rendering]] materials, a visual node material editor that compiles to [[Shader]] code, and post-processing pipelines.
- Custom shaders and effects layered over the standard pipeline.

#### Asset pipeline

- First-class [[glTF]] and GLB import, texture and animation loading, and scene serialisation.

#### Rendering backends

- Abstraction over WebGL and [[WebGPU]], enabling compute-driven effects and modern GPU features through one [[Rendering Pipeline]].

#### Immersive and interaction

- Built-in [[WebXR]] sessions, controllers, hand tracking, and AR/VR camera rigs.

### Applications

#### Immersive web and metaverse

- Browser-delivered 3D worlds, social spaces, and product configurators using [[WebXR]].

#### Games and interactive media

- Web-native games and rich interactive visualisations built on a [[Game Engine]]-like feature set.

#### Visualisation and digital twins

- Engineering, scientific, and architectural visualisation rendered with [[Real-Time Rendering]] in the browser.

### Provenance

