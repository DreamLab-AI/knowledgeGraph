Manufacturing resource planning (MRP II) is an extension of material requirements planning that adds procedures for capacity, feedback and other functions so that planning covers manufacturing resources as well as materials.[^1][^2][^3]

Gallego writes that MRP II embeds additional procedures to address the shortcomings of MRP and tries to be an integrated manufacturing system by bringing together other functional areas such as marketing and finance. Its additional functions include forecasting, demand management, rough-cut capacity planning, capacity requirements planning, scheduling and dispatching rules, and input and output control, within a hierarchy of long-range planning, medium-range planning and short-term control.[^1]

The Cambridge Institute for Manufacturing describes MRP II as keeping all the elements of MRP, namely the bill of materials, the master production schedule as starting point and the steps of explosion, netting and offsetting, while adding four developments. These are feedback from the shop floor to all levels of the schedule, which is why it is sometimes called closed loop MRP; resource scheduling, which takes capacity into account but only after the MRP schedule has been prepared; batching rules; and software extension programmes, of which rough-cut capacity planning is the most important.[^2] It adds that full implementation makes the system an integrated database for the company and demands great emphasis on data accuracy, with suppliers encouraging users to aim for accuracy of between 95% and 98%.[^2]

Beasley's OR-Notes say MRP II is essentially MRP with more added, typically cost information, management reports and what-if analysis and possibly capacity requirements planning. They say the name signals planning of manufacturing resources such as people, machines and storage rather than only materials.[^3]

## Scope and distinctions

Gallego describes enterprise resource planning systems as extensions of MRP systems that run on a single database and support marketing and finance as well as production.[^1] See [[Material Requirements Planning]], [[Rough-Cut Capacity Planning]], [[Capacity Requirements Planning]] and [[Enterprise Resource Planning]].

## What the sources do not establish

These three sources describe MRP II in somewhat different terms, and none is a standard, so the list of what MRP II includes varies by author.[^1][^2][^3]

[^1]: Guillermo Gallego, Columbia University IEOR 4000 Production Management lecture notes, “Material Requirements Planning (MRP)”. http://www.columbia.edu/~gmg2/4000/pdf/lect_06.pdf
[^2]: University of Cambridge Institute for Manufacturing, Decision Support Tools, “Manufacturing Resource Planning (MRP II)”. https://www.ifm.eng.cam.ac.uk/research/dstools/mrp-ii/
[^3]: J. E. Beasley, OR-Notes, Brunel University London, “Materials requirements planning (MRP)”. https://people.brunel.ac.uk/~mastjjb/jeb/or/mrp.html

