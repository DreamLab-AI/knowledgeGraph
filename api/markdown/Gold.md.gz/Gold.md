Gold (chemical symbol Au, atomic number 79, ISO currency code XAU) is a dense, corrosion-resistant transition metal that has served as the pre-eminent monetary commodity for at least years and –2026 occupies a unique dual role as both the world's third-largest reserve asset by value (approximatel...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:hasPart ec:LBMAGoodDeliveryBar))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:hasPart ec:GoldETF))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:hasPart ec:GoldBackedToken))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:hasPart ec:CentralBankGoldReserve))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:hasPart ec:COMEXGoldFutures))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:hasPart ec:GoldRecyclingStream))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:hasPart ec:GoldRefinery))

    ## Dependency Relationships
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:requires ec:VaultStorage))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:requires ec:ChainOfCustody))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:requires ec:AssayCertificate))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:requires ec:LBMAGoodDeliveryAccreditation))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:requires ec:CustodianBank))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:requires ec:AllocatedAccount))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:dependsOn ec:PreciousMetalRefining))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:dependsOn ec:VaultInfrastructure))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:dependsOn ec:GlobalCommodityMarket))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:dependsOn ec:SovereignReservePolicy))

    ## Capability Relationships
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:enables ec:InflationHedging))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:enables ec:CurrencyDiversification))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:enables ec:TokenizedCommodity))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:enables ec:GoldBackedStablecoin))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:enables ec:MonetaryReserveDiversification))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:enables ec:CrossBorderSettlement))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:supports ec:BitcoinValueProposition))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:supports ec:StablecoinCollateral))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:supports ec:CBDCDesign))

    ## Implementation Relationships
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:implements ec:LBMAResponsibleGoldGuidance))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:implements ec:BISBaselIIIHQLAClassification))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:implements ec:ICELBMAGoldPriceBenchmark))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:implements ec:ISO4217XAUCurrencyCode))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:implements ec:COMEXFuturesContractStandard))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:implements ec:SGETradingRules))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:uses ec:ERC20TokenStandard))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:uses ec:StellarNetwork))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:uses ec:Algorand))

    ## Reduction Relationships
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:reduces ec:CurrencyRisk))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:reduces ec:InflationExposure))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:reduces ec:CounterpartyRisk))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:reduces ec:PortfolioVolatility))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:reduces ec:SettlementFriction))

    ## Association Relationships
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:relatedTo ec:Bitcoin))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:relatedTo ec:Stablecoin))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:relatedTo ec:CBDCs))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:relatedTo ec:AssetTokenization))
    SubClassOf(ec:Gold
      ObjectSomeValuesFrom(ec:relatedTo ec:DecentralizedFinance))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ec:hasIdentifier ec:Gold "EC-2201"^^xsd:string)
    DataPropertyAssertion(ec:authorityScore ec:Gold "0.87"^^xsd:decimal)
    DataPropertyAssertion(ec:annualMiningSupply ec:Gold "3500"^^xsd:integer)
    DataPropertyAssertion(ec:centralBankNetPurchases2024 ec:Gold "1045"^^xsd:integer)
    DataPropertyAssertion(ec:lbmaDailyTurnover ec:Gold "35000000000"^^xsd:integer)
    DataPropertyAssertion(ec:goldETFAUM ec:Gold "140000000000"^^xsd:integer)
    DataPropertyAssertion(ec:spotPrice2025 ec:Gold "3200"^^xsd:decimal)
    DataPropertyAssertion(ec:recyclingSupply ec:Gold "1250"^^xsd:integer)

    ## Property Constraints
    SubClassOf(ec:Gold
      DataAllValuesFrom(ec:requiresAllocatedStorage xsd:boolean))
    SubClassOf(ec:Gold
      DataSomeValuesFrom(ec:fineness xsd:decimal))
    SubClassOf(ec:Gold
      DataMinCardinality(1 ec:hasVaultLocation xsd:string))
    SubClassOf(ec:Gold
      DataMinCardinality(1 ec:hasAssayDocument xsd:string))

    ## Annotations
    AnnotationAssertion(rdfs:label ec:Gold "Gold"@en)
    AnnotationAssertion(rdfs:comment ec:Gold "Monetary commodity and reserve asset (ISO XAU) that functions as the ontological anchor for gold-backed digital tokens (PAXG, XAUT, Kinesis KAU), central bank reserves (1,045 tonnes net purchased globally in 2024), BIS Basel III HQLA Tier-1 asset, and the primary 'digital gold' contrast class for Bitcoin's monetary value proposition; price reached $3,200/oz by May 2025."@en)
    AnnotationAssertion(dcterms:identifier ec:Gold "EC-2201"^^xsd:string)
    AnnotationAssertion(dcterms:subject ec:Gold "Commodity, Monetary Metal, Reserve Asset, Gold-Backed Token, Central Bank Reserve"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(ec:requires)
  AsymmetricObjectProperty(ec:enables)
  AsymmetricObjectProperty(ec:implements)
  AsymmetricObjectProperty(ec:reduces)
  TransitiveObjectProperty(ec:dependsOn)
  FunctionalDataProperty(ec:fineness)
  FunctionalDataProperty(ec:spotPrice2025)

## About Gold

- **Gold** (Au, from Latin *aurum*) is the world's oldest and most universally accepted monetary commodity.
- Distinguished from industrial metals by a unique combination of physical properties:
  - Extreme corrosion resistance — gold does not tarnish, oxidise, or react with most chemicals
  - High density (19.3 g/cm³) — difficult to counterfeit by weight substitution (tungsten is the only common metal with comparable density at 19.25 g/cm³)
  - Malleability — 1 troy oz can be beaten into 300 square feet of gold leaf (~0.1 micron thick) or drawn into 50 miles of wire
  - Optical lustre — characteristic golden colour arising from relativistic effects on 5d/6s electron transitions (a quantum mechanical property unique to heavy elements)
  - Electrical conductivity — 45.2 × 10⁶ S/m at 20°C; surpassed only by copper and silver but uniquely corrosion-resistant in contact applications
- These properties made gold universally legible as a store of value across disconnected civilisations: Ancient Egypt (Old Kingdom burial hoards, 3100 BCE), Lydian electrum coinage (~550 BCE), Roman aureus, Byzantine solidus, Islamic dinar, Song Dynasty paper money (backed by gold/silver reserves), Medieval Venetian ducat, British sovereign (1817–present).
- Its monetary primacy derives from the Mengerian commodity theory of money: gold spontaneously emerged as money because it minimised transaction costs (durable, portable, divisible, recognisable, relatively scarce) rather than being decreed as money by any authority.
- In the contemporary AI-blockchain ontology, gold occupies three distinct conceptual registers:
  - (1) **Physical reserve asset** — the 200,000+ tonnes of above-ground gold stock, continuously recycled and partially held in central bank vaults, ETF warehouses, and private storage
  - (2) **Benchmark and settlement standard** — LBMA London Good Delivery system, COMEX futures price discovery, and SGE physical delivery providing global pricing infrastructure
  - (3) **Tokenised digital instrument** — gold-backed ERC-20 tokens, blockchain-settled allocated gold accounts, and gold-backed CBDC designs bringing physical gold into programmable finance

### Physical Market Architecture

- The physical gold market divides into **allocated** and **unallocated** accounts:
  - **Allocated account**: Holder owns specific identified bars (serial numbers, weight, assay marks) segregated from custodian balance sheet — no counterparty risk beyond vault security
  - **Unallocated account**: Holder has an unsecured claim on custodian for a gold quantity — operationally convenient for trading but introducing counterparty exposure analogous to fractional-reserve banking
  - ~90–95% of London wholesale trading ($35–50B/day) occurs in unallocated format, creating structural leverage where paper gold claims exceed deliverable physical supply
- **London Good Delivery (LGD) Bars** — the global wholesale gold standard:
  - Weight specification: 350–430 fine troy oz (accepted range; nominal 400 oz = 12.4 kg)
  - Purity: minimum 99.5% fine gold (most modern bars are 99.99%)
  - Required marks: serial number, assay office stamp, year of manufacture, weight to nearest 0.025 troy oz
  - LBMA Refiners Good Delivery List (2025): ~70 accredited refiners globally
  - Key refiners: Metalor (Switzerland), PAMP Suisse, Argor-Heraeus, Rand Refinery (South Africa), Royal Mint (UK), Asahi Refining (US/Canada/Japan)
  - OJSC Novosibirsk Refinery (Russia) — suspended from LBMA March 2022 post-Ukraine sanctions
  - The UK Royal Mint Llantrisant produces the Sovereign (7.322 g, 22-carat, legal tender since 1817) and Britannia (1 troy oz, 999.9 fine, legal tender since 1987)
- **ICE LBMA Gold Price** — the twice-daily global benchmark:
  - Operated by ICE Benchmark Administration since March 2015, replacing the 100-year-old telephone fixing
  - Original five fixing banks: Barclays, Deutsche, HSBC, Scotiabank, Société Générale
  - Current auction: electronic matching of buy/sell orders at single clearing price, ~15–20 direct participants
  - Fixing times: 10:30 AM London (AM Fix) and 3:00 PM London (PM Fix — coincides with New York market open, typically the more liquid and referenced)
  - Underpins: gold financial contracts, producer hedges, ETF NAV calculations, tokenised gold redemption mechanics globally

### Central Bank Gold Accumulation 2023–2026

- World Gold Council demand trend data confirms an unprecedented multi-year central bank accumulation cycle beginning 2022, continuing through 2026:
  - 2022: net purchases 1,136 tonnes (highest since 1967)
  - 2023: net purchases 1,037 tonnes
  - 2024: net purchases 1,045 tonnes
  - 2025 estimate: 950–1,100 tonnes
- Structural driver: de-dollarisation by non-Western central banks following the freezing of Russian foreign exchange reserves ($300B+) post-February 2022 Ukraine invasion, demonstrating that dollar reserves can be immobilised by geopolitical action
- **People's Bank of China (PBOC)**:
  - Disclosed reserves: 1,948 tonnes (August 2022) → 2,280 tonnes (December 2024)
  - 18 consecutive months of reported purchases across 2022–2024
  - PBOC paused disclosures May 2024 (internal review) and resumed October 2024
  - Analyst estimates of total Chinese government gold (PBOC + SAFE + sovereign wealth): 4,000–6,000 tonnes (speculative, unverified)
  - China domestic consumer demand 985 tonnes (2024) — world's largest consumer market
- **Reserve Bank of India (RBI)**:
  - 876 tonnes by December 2024 (up from 768 tonnes end-2022)
  - 9.4% of total foreign reserves
  - 2024: repatriated 102 tonnes from Bank of England vaults to domestic storage — largest RBI repatriation operation since 1991
- **National Bank of Poland (NBP)**:
  - Acquired 130 tonnes in 2024 (228 → 358 tonnes; 14.5% of reserves)
  - Largest single-year central bank purchase globally in 2024
  - NBP Governor Adam Glapinski: stated long-term target of 20% of reserves in gold
- **Central Bank of Turkey**:
  - 592 tonnes as of December 2024 (13.6% of reserves)
  - 13th largest official gold holder globally
  - Active gold policy since 2011, partly driven by domestic commercial bank swap arrangements (Turkish banks can use customer gold deposits to meet reserve requirements)
- **Central Bank of Russia**:
  - ~2,332 tonnes as of end-2024 (~27% of total reserves; world's fifth-largest holder)
  - Largely cut off from LBMA trading post-2022 sanctions
  - Oriented gold production/sales toward SGE and bilateral arrangements with non-FATF jurisdictions
- **BIS Basel III HQLA Reclassification** — the most structurally significant regulatory change for gold since Bretton Woods:
  - BIS Basel Framework Chapter CRE20 classifies unencumbered physical gold (allocated, qualified custodian, no liens) as Level 1 HQLA
  - Eligible for Liquidity Coverage Ratio (LCR) and Net Stable Funding Ratio (NSFR) with 0% haircut
  - Equivalent treatment to cash and central bank reserves
  - Implementation timeline: EU CRR3 effective January 2025; UK PRA PS17/23 effective January 2026; US Basel III endgame — ongoing as of 2025
  - Estimated incremental demand: 500–1,000 tonnes over 2025–2030 implementation period (LBMA research)

### Gold-Backed Digital Tokens: Infrastructure and Mechanics

- The emergence of gold-backed tokens represents the most direct technical integration between physical commodity markets and blockchain infrastructure. The general architecture involves: (1) custodian holds allocated LBMA Good Delivery gold in vault; (2) smart contract mints tokens 1:1 against vault inventory, verified by periodic audits; (3) token holders can redeem for physical delivery (typically minimum 430 troy oz = 1 LGD bar for most products) or USD/fiat equivalent; (4) the token functions as a bearer instrument representing allocated gold ownership. Key implementations:
- **PAX Gold (PAXG)**: Issued by Paxos Trust Company (New York State trust charter, regulated by NYDFS). Each PAXG = 1 fine troy oz of allocated LBMA Good Delivery gold in Brink's vaulting London. Monthly attestations by Withum Smith+Brown CPA. Minimum redemption: 430 oz. Paxos also issues PYUSD (PayPal stablecoin) using similar infrastructure. PAXG market cap ~$700–850M across 2024–2025. PAXG is ERC-20 on Ethereum with a 0.02% on-chain transfer fee.
- **Tether Gold (XAUT)**: Issued by Tether Limited (British Virgin Islands). Available as ERC-20 (Ethereum) and TRC-20 (Tron). 1 XAUT = 1 troy oz of specific allocated gold bars in Swiss vaults (exact bar serial numbers disclosed to token holders). Market cap ~$550–650M 2024–2025. Tether Limited is the same entity issuing USDT (largest stablecoin by market cap), meaning Tether Gold rides existing infrastructure including Ethereum, Tron, and Bitfinex exchange liquidity.
- **Kinesis KAU**: Kinesis Money (Isle of Man incorporated, operational HQ Sydney). 1 KAU = 1 gram of fine gold (as opposed to 1 troy oz for PAXG/XAUT). Built on a customised Stellar fork (Kinesis blockchain). Distinctive yield mechanic: 15% of all transaction fees across the Kinesis system are distributed to KAU holders proportional to their holdings ("holder yield"), plus additional yields for minters and referrers. Storage locations: Loomis Singapore, Malca-Amit Singapore/Zurich, Commonwealth Bank Australia. KAU enables sub-gram gold ownership accessible to retail investors globally.
- **Royal Mint DigiGold**: The UK Royal Mint (Llantrisant, Wales — government-owned, operating since 886 AD) launched DigiGold in 2021 allowing direct digital ownership of Royal Mint gold vaulted at Llantrisant from £25 GBP minimum. Not blockchain-based — uses conventional database ledger — but represents the direction of government-backed digital commodity products. Royal Mint is LBMA-accredited refiner and produces UK legal tender gold coins.
- **Perth Mint Gold Token (PMGT)**: Issued by InfiniGold (Australian company) backed by GoldPass certificates from the Perth Mint (Government of Western Australia). Each PMGT = 1 fine troy oz stored at Perth Mint. Unusually, Perth Mint storage is backed by a guarantee from the Government of Western Australia (AAA-rated), making PMGT the only gold token with a government guarantee on custody. Built on Algorand blockchain. Activity decreased significantly after Perth Mint faced a 2023 inquiry into potential gold-silver alloy misrepresentation.

### The Digital Gold Narrative: Gold vs Bitcoin

- The "digital gold" framing originated in early Bitcointalk forum discussions (2011) and was systematically developed through:
  - Saifedean Ammous, *The Bitcoin Standard* (Wiley, 2018) — comprehensive Austrian-school monetary comparison
  - Parker Lewis, *Gradually Then Suddenly* essays (Unchained Capital, 2019–2020) — stock-to-flow and scarcity analysis
  - Lyn Alden, *Broken Money* (Theorem, 2023) — monetary systems historical overview positioning Bitcoin as gold successor
  - PlanB (pseudonymous) — S2F (Stock-to-Flow) model correlating Bitcoin price to Bitcoin scarcity ratio (controversial, empirically contested post-2021)
- The comparative framework, central to the AI-blockchain ontology, covers six key monetary dimensions:
- **Supply Predictability**:
  - Gold: grows ~1.5–2% annually (mining adds ~3,500 tonnes to ~200,000 tonne above-ground stock)
  - Gold supply subject to geological discovery, mining technology improvements, asteroid/deep-sea mining speculations
  - Bitcoin: issuance mathematically fixed; block reward halving every 210,000 blocks (~4 years)
  - April 2024 halving: subsidy reduced to 3.125 BTC/block; next halving circa 2028: 1.5625 BTC/block
  - Bitcoin stock-to-flow ~120 post-2024 halving vs gold's ~60–70
  - Bitcoin reaches effectively infinite stock-to-flow post-2140 (final coin issuance)
- **Settlement Finality**:
  - LBMA unallocated gold: T+2 settlement (two business days)
  - LBMA allocated transfers: bilateral custodian coordination (hours to days)
  - Bitcoin Layer 1: final after ~6 block confirmations (~60 minutes), any amount, global
  - Lightning Network: near-instant micropayment settlement, sub-second
  - Physical gold cross-border transport: permits, insurance, carrier coordination, customs declaration
- **Verifiability**:
  - Physical gold: requires fire assay, XRF spectroscopy, or ultrasound density testing (expensive, time-consuming)
  - Tungsten-core gold bars (density 19.25 g/cm³ vs gold 19.3 g/cm³) have been documented in LBMA vaulting (2012 ETF fraud incident), illustrating physical verification limits
  - Bitcoin UTXOs: cryptographically verifiable in milliseconds by any node — no trust required
- **Divisibility**:
  - Gold: minimum LBMA settlement ~0.001 troy oz; physical handling limit ~0.1 gram (approximately $10)
  - Bitcoin: divisible to 1 satoshi = 10⁻⁸ BTC (approximately $0.0003 at $30,000 BTC); Lightning enables millisatoshi (10⁻¹¹ BTC) micropayments
- **Portability**:
  - 1 tonne of gold (~32,150 troy oz): ~$96M at $3,000/oz, but physically ~1 cubic meter, requires armoured transport
  - $96M in Bitcoin: 12-word seed phrase, transmissible in any digital channel
- **Gold Counterarguments** — from proponents (Peter Schiff, Jim Rickards, Goldman Sachs Commodities Research):
  - 5,000-year track record vs Bitcoin's 15-year history
  - Industrial demand floor: ~60% of gold demand is jewellery/technology, not pure investment speculation
  - No systemic technical risk: gold cannot be destroyed by software bug, 51% attack, solar flare, or EMP
  - No key-loss risk: estimated 3–4M BTC permanently lost due to lost private keys (~15–20% of circulating supply)
  - Basel III Tier-1 status: Bitcoin carries 1,250% risk-weight (banks must hold $1.25 capital per $1 Bitcoin exposure); gold carries 0% as HQLA
  - Sovereign reserve acceptance: 130+ central banks hold gold as official reserves; zero hold Bitcoin (El Salvador's ~6,000 BTC sovereign reserve is the sole government exception, and it is not a reserve bank holding)
  - US gold reserve: 8,133 tonnes (~$780B at $3,000/oz, 70% of official reserves), providing geopolitical backstop that no existing Bitcoin holder can match in scale

### Exchange-Traded Products

- Gold ETFs represent the most liquid, low-friction mechanism for institutional and retail gold investment:
  - Global gold ETF AUM: ~1,500–1,600 tonnes accumulated by 2024–2025
  - Net flows reversed: 2021–2023 saw cumulative -400 tonne net outflows (rising rates); 2024 saw +100 tonnes net inflows (rate cuts)
  - Spot price sensitivity: each 10% gold price move changes AUM by ~$15–20B without any tonnage change
- **SPDR Gold Shares (GLD)** — the flagship US vehicle:
  - Launched November 2004 (NYSE Arca, ticker GLD) — first US-listed gold ETF
  - Structure: each share = 1/10 troy oz of gold
  - Custodian: HSBC Bank plc (London vaults); sub-custodians: JP Morgan, Bank of England
  - Expense ratio: 0.40%
  - AUM: ~$70–80B (900–1,000 tonnes) at $3,000/oz; peak was $80B+ in 2020
  - Also offers GLDM (0.10% expense ratio, 1/100 oz per share) targeting retail investors
  - Governed by SPDR Gold Trust prospectus; trust must sell gold quarterly to pay expenses
- **iShares Gold Trust (IAU)** — largest challenger:
  - Launched January 2005 (NYSE Arca); each share = 1/100 troy oz
  - Custodian: JP Morgan Chase Bank London
  - Expense ratio: 0.25% — cost advantage vs GLD has driven institutional migration
  - AUM: ~$30–35B (400–500 tonnes) 2024–2025
  - BlackRock also manages iShares Physical Gold ETC (IGLN) on London Stock Exchange — major European vehicle
- **Sprott Physical Gold Trust (PHYS)**:
  - TSX/NYSE Arca listed; gold in Royal Canadian Mint vaults
  - Unique: investors can redeem for physical delivery (minimum 10 oz London Good Delivery bars)
  - Expense ratio: 0.35%; popular for jurisdictional diversification (Canadian custody, outside US reach)
- **UK/European ETCs** (Exchange Traded Commodities — debt instruments, not UCITS funds):
  - WisdomTree Physical Gold (PHAU, LSE): ~180 tonnes AUM
  - iShares Physical Gold ETC (IGLN, LSE): BlackRock-managed, EUR and GBP share classes
  - Invesco Physical Gold (SGLP, LSE): Swiss vault storage (ZKB Bank)
  - Collectively: ~400–500 tonnes in London/Swiss LBMA vaults
  - Note: ETCs are debt instruments secured on gold rather than equity interests in a fund — distinct legal structure from US ETFs, with implications for insolvency treatment

### Recycling and Supply Chain

- Gold supply structure (2024 totals, WGC):
  - Total supply: ~4,750 tonnes/year
  - Primary mining: ~3,500 tonnes/year (~74% of total)
  - Recycling: ~1,200–1,300 tonnes/year (~26% of total)
  - Net central bank sales/(purchases): currently -1,045 tonnes/year (net demand from CB purchases)
- Recycled gold sources:
  - Jewellery scrap: ~900–1,000 tonnes (dominant; price-elastic — higher gold prices trigger selling in India, Middle East, Turkey)
  - Electronics/technology scrap: ~300 tonnes/year (circuit boards, connectors, CPU packages, wire bonds — increasing as AI hardware deployment grows)
  - Dental alloys: ~15 tonnes/year (declining, displaced by porcelain)
  - Coin/bar investor recycling: ~50–100 tonnes/year (profit-taking at price peaks)
- Elasticity: each $100/oz price increase adds ~30–50 tonnes of annual recycled supply — partial demand-dampening mechanism
- Primary refining centres:
  - Zurich, Switzerland: Valcambi, PAMP Suisse, Argor-Heraeus — collectively refining ~1,500+ tonnes/year (dominant global share)
  - London: Metalor, Royal Mint — LBMA Good Delivery bars; primarily re-refining/remelting into delivery specification
  - Antwerp, Belgium: significant recycled gold refining hub for European scrap
  - Dubai, UAE: Kaloti and Emirates Gold — growing hub for Middle East/African gold flows, DMCC free zone
- **LBMA Responsible Gold Guidance** (7th Ed. 2023) — mandatory compliance for all ~70 accredited LBMA refiners:
  - Supply chain due diligence tracing gold back to mine source for conflict-affected and high-risk areas (CAHRAs)
  - Prohibition on sourcing from groups committing serious human rights abuses
  - Mercury use reporting (UNEP Minamata Convention compliance)
  - Artisanal/small-scale mining (ASM) sourcing policies
  - Aligned with OECD Due Diligence Guidance for Responsible Supply Chains of Minerals from Conflict-Affected and High-Risk Areas (2nd Edition)
- AI applications in gold supply chain:
  - Satellite imagery analysis (computer vision on Planet Labs/Maxar imagery) for ASM mine monitoring
  - NLP-based sanctions screening for gold trader names/addresses against OFAC/EU consolidated lists
  - Blockchain-based chain-of-custody tracking (Tracr model applied to gold; IBM Food Trust architecture)
  - Predictive analytics for recycling volume forecasting (price-elasticity models)

### Use Cases / Major Families

- **Central Bank Reserve Asset** — oldest and most fundamental use:
  - No counterparty risk: unlike dollar reserves (a claim on the US government), allocated gold is nobody's liability
  - Cannot be frozen by sanctions if held domestically (Russia's gold held in Moscow was unaffected by 2022 sanctions; its dollar reserves were frozen)
  - 5,000-year monetary track record — uniquely durable among reserve assets
  - Post-2022 dominant demand driver: World Gold Council projects central bank demand at 800–1,100 tonnes/year indefinitely
  - Top 10 central bank gold holders (2024): USA 8,133t, Germany 3,352t, Italy 2,452t, France 2,437t, Russia 2,332t, China 2,280t, Switzerland 1,040t, Japan 845t, India 876t, Netherlands 612t
- **Inflation Hedge / Currency Diversification**:
  - 3–10% portfolio allocation recommended by MPT optimisation (WGC 2024 *Gold as a Strategic Asset*)
  - Rolling 20-year equity correlation: 0.02–0.05 (near-zero; effective diversifier)
  - Real return: gold returned ~+8% annually in USD terms 2000–2024, outpacing CPI by ~5% per annum
  - Particularly effective in hyperinflation scenarios: Weimar Germany (1923), Zimbabwe (2008), Venezuela (2017–2021), Turkey (2021–2022) — gold maintained USD purchasing power when local currency collapsed
- **Gold-Backed Stablecoins / Tokenised Gold**:
  - PAXG, XAUT, KAU — primary implementations (described in dedicated section)
  - DeFi collateral: PAXG accepted on AAVE, Compound, MakerDAO for DAI/USDC loans
  - Combined market cap ~$1.3–1.5B 2024–2025, growing ~30% annually
  - Represents ~0.1% of total gold ETF AUM — significant growth potential
  - Key advantage over ETFs: 24/7 trading, programmable (smart contract integration), borderless transfer
  - Key disadvantage vs ETFs: less regulatory clarity in most jurisdictions, counterparty risk on token issuer
- **Technology/Industrial Applications**:
  - Global technology gold demand: ~340–380 tonnes/year (2024, WGC)
  - Electronics: PCB edge connectors, wire bonding in semiconductor packages, MEMS contacts
  - AI hardware specifically: NVIDIA H100/H200/B200 GPUs require ~8–15 mg gold per chip; advanced HBM3 memory packaging; high-reliability server interconnects
  - Estimated incremental AI-related gold demand: 40–70 tonnes/year through 2030
  - Medical: implantable pacemaker leads, dental prosthetics (declining), targeted cancer therapy (gold nanoparticles)
  - Space: James Webb Space Telescope 18 primary mirrors gold-coated (0.1 micron vapour deposition); satellite reflective surfaces; radiation shielding
- **DeFi Collateral**:
  - Gold-backed tokens as on-chain collateral for capital-efficient borrowing
  - Example: $1M PAXG → borrow ~$700,000 USDC on AAVE (65% LTV) while maintaining gold price exposure
  - Gold's low volatility (~15% annualised) makes it more capital-efficient than ETH or BTC collateral (higher LTV possible)
  - Combines traditional gold store-of-value with DeFi liquidity
  - Risk: smart contract risk, oracle manipulation risk (gold price feeds via Chainlink)
- **Producer Hedging**:
  - Gold mining companies use COMEX futures and OTC forward contracts to lock in future production revenue
  - Typical hedge book: 20–40% of 12–36 month forward production
  - Newmont, Barrick, AngloGold Ashanti — major hedgers; Kinross historically unhedged ("gold-positive" strategy)
  - Rising gold prices (2024–2025) reduced hedging incentives; many producers running near-zero hedge books to maximise spot price exposure

### Academic Context

- Three theoretical traditions frame the economics of gold as money:
- **1. Austrian School Monetary Theory**:
  - Carl Menger, *Principles of Economics* (1871): gold emerged spontaneously as the most saleable commodity; monetary premium reflects cumulative epistemic selection across millennia rather than arbitrary decree
  - Ludwig von Mises, *Theory of Money and Credit* (1912): **regression theorem** — money's exchange value traces back through time to its commodity use value; gold's monetary premium is reducible to its pre-monetary commodity demand
  - Friedrich Hayek, *Prices and Production* (1931): gold standard as constraint on central bank monetary expansion, preventing artificial booms
  - The regression theorem is contested when applied to Bitcoin (Bitcoin had no pre-monetary commodity use); Nick Szabo's "bit gold" proposal (1998) and Mises Circle debates remain unresolved
- **2. Keynesian / Post-Keynesian Critique**:
  - J.M. Keynes, *A Tract on Monetary Reform* (1923): described gold standard as a "barbarous relic" — gold's supply rigidity prevents monetary accommodation of economic downturns
  - *General Theory* (1936): gold mining treated as equivalent to digging holes and filling them — socially wasteful given gold's limited productive use
  - Post-Keynesian view: optimal monetary policy requires flexible money supply; commodity anchor prevents stabilisation policy
  - Barry Eichengreen, *Golden Fetters* (1992): empirical case that gold standard prolonged the Great Depression by preventing monetary expansion
- **3. Modern Monetary Theory**:
  - Warren Mosler, Stephanie Kelton, L. Randall Wray: gold is simply an arbitrary commodity; the state determines what functions as money through tax acceptance; monetary sovereignty requires non-convertible currency
  - MMT view: gold standard = voluntary subordination of public purpose to arbitrary commodity supply constraints
- **Empirical Safe Haven Literature**:
  - Baur & Lucey (2010, *Financial Review* 45(2), 217–229): gold is a hedge against stocks on average, and a safe haven during extreme stock market stress
  - Baur & McDermott (2010, *Journal of Banking & Finance* 34(8), 1886–1898): gold safe haven in US and major European markets; weaker effect in BRICS
  - Erb & Harvey (2013, *Financial Analysts Journal* 69(4)): long-run real return of gold ≈ 0% over very long horizons; "golden constant" — gold maintains real purchasing power but generates no real return above inflation
  - Key finding: gold's crisis correlation property (negative correlation during acute equity drawdowns) derives from its non-credit-linked status, not any intrinsic economic property
- **Gold-Bitcoin Research Literature**:
  - Dyhrberg (2016, *Finance Research Letters* 16, 85–92): Bitcoin-gold GARCH analysis finding partial hedging characteristics shared with gold
  - Conlon & McGee (2020, *Finance Research Letters* 35): gold outperformed Bitcoin as safe haven during March 2020 COVID crash (Bitcoin fell -50% while gold fell -12% then recovered)
  - Wang et al. (2022, *Resources Policy* 80): asymmetric volatility spillovers between Bitcoin and gold — Bitcoin volatility spillover to gold but not vice versa
  - Ammous (2018) *The Bitcoin Standard*: most influential non-academic monetarist comparison; systematic analysis of gold vs Bitcoin across 7 monetary properties

### Current Landscape (2026)

- The 2024–2026 gold market is characterised by six concurrent structural forces:
- **1. Record Price Levels**:
  - $2,500/oz — August 2024 (first close above $2,500)
  - $2,800/oz — November 2024
  - $3,000/oz — March 2025 (psychological milestone)
  - $3,200/oz — May 2025 (current approximate level)
  - 40%+ gain over 18 months — among the strongest 18-month gold rallies in history
  - Primary drivers:
    - Sustained central bank accumulation (1,000+ tonnes net/year)
    - Federal Reserve rate-cut cycle: -50bp September 2024, -25bp November 2024, -25bp December 2024 (-100bp total in 2024)
    - Geopolitical fragmentation (Ukraine, Middle East, Taiwan Strait) — safe-haven premium
    - Broad USD reserve diversification by BRICS+ central banks
    - Retail investor demand acceleration (physical coins/bars, gold ETFs) in Germany, Switzerland, and East Asia
- **2. Central Bank Accumulation Cycle**:
  - 2022–2025: highest sustained central bank gold purchasing since end of Bretton Woods (1971)
  - Cumulative net purchases 2022–2025: ~3,100 tonnes (WGC data)
  - Structurally different from ETF demand: reserve allocation decisions are multi-year policy commitments
  - No sign of deceleration — Poland, India, China, Turkey continuing active programmes
  - IMF and World Gold Council projections: 800–1,000 tonnes/year net purchases through 2030
- **3. Basel III HQLA Integration**:
  - EU: CRR3 effective January 2025 — commercial banks can count allocated gold as Level 1 HQLA
  - UK: PRA PS17/23 effective January 2026
  - US: Basel III endgame implementation ongoing; timeline uncertain as of 2025
  - Estimated 500–1,000 tonnes incremental institutional demand over 5-year implementation
  - Fundamental regime change: gold now treated equivalently to cash in bank liquidity frameworks
- **4. ETF Flows Reversal**:
  - 2021–2023: cumulative ~-400 tonnes net outflows (rising rates, opportunity cost of non-yielding gold)
  - 2024: +100 tonnes net inflows globally (falling rates removed the yield premium vs gold)
  - 2025–2026: projected continued inflows as rate cycle continues
  - North American ETFs recovered faster; European ETF inflows lagged by 6–9 months
- **5. Tokenised Gold Scaling**:
  - 2022: ~$600M combined market cap (PAXG + XAUT + KAU + PMGT)
  - 2024: ~$1.4B combined market cap
  - 2028 projection: $5–10B as institutional DeFi adoption accelerates
  - LBMA Digital Market Working Group: published tokenised gold framework for LBMA delivery chains (2024)
  - Traditional vault operators (Brink's, Malca-Amit, Via Mat) expanding tokenisation partnerships
  - Paxos exploring institutional tokenised gold settlement pilot with major bullion banks
- **6. AI-Gold Industrial Nexus**:
  - NVIDIA H100/H200/B200 GPUs: ~8–15 mg gold per chip (wire bonding, connectors, substrate contacts)
  - Advanced HBM3 memory stacking: gold wire bonds for memory-to-chip interconnects
  - High-reliability server backplane connectors: gold flash plating on SFP/QSFP optical transceiver contacts
  - Estimated incremental AI-specific gold demand: 40–70 tonnes/year through 2030
  - Context: AI data centre buildout ($200B+ annually 2024–2026) is creating measurable new gold demand stream
  - Feedback loop: rising gold price → higher component cost → marginal incentive for recycling AI hardware at end-of-life

### UK Context

- The United Kingdom occupies a structurally central position in global gold markets through several distinct institutional concentrations:
- **London Bullion Market Association (LBMA)**:
  - Established 1987; headquartered 1–3 Strand, London WC2N
  - Trade association for London OTC gold and silver markets; ~150 members
  - Member categories: bullion banks (JP Morgan, HSBC, Goldman Sachs, UBS, Standard Chartered, ICBC Standard Bank), vault operators (Brink's, Malca-Amit, G4S, HSBC vault), brokers, refiners, investors
  - London Good Delivery system: global standard for wholesale gold bars
  - London is world's largest physical gold settlement centre (~$35–50B/day OTC turnover)
  - LBMA Responsible Gold Guidance (mandatory since 2012): leading global supply chain compliance standard
  - LBMA Digital Market Working Group: active 2023–2025 developing blockchain settlement framework
- **Bank of England Gold Vault**:
  - Location: Threadneedle Street, City of London; vault 15 metres below street level
  - Estimated holdings: 400,000+ LBMA bars (~5,000 tonnes) — one of the world's largest gold storage facilities
  - Custodied for: ~30 central banks, IMF, UK government own reserve (310 tonnes)
  - Clearance role: Bank of England facilitates inter-central bank gold transfers by internal ledger entry (no physical movement needed for accounts held in same vault)
  - **Brown's Bottom controversy**: HM Treasury sold 401 tonnes in 1999–2002 at £256–$296/oz average (approximately £4.5B total proceeds); 2025 gold price of $3,200/oz implies that gold would now be worth ~$47B — opportunity cost widely debated
- **Royal Mint Llantrisant**:
  - Location: Llantrisant, Rhondda Cynon Taf, Wales (relocated from Tower of London 1967)
  - Incorporation: Royal Mint Ltd (wholly-owned by HM Treasury); operating since AD 886
  - Products: Sovereign (7.322 g, 22-carat, 916.7 fine, face value £1); Britannia (1 troy oz, 999.9 fine, face value £100); Lunar/Creature series collectibles; numismatic coins
  - Annual output: ~500,000–750,000 gold coins (value ~£500M–£750M at £2,500/oz)
  - LBMA-accredited Good Delivery refiner
  - DigiGold (launched 2021): digital gold ownership from £25 minimum, backed by Royal Mint vault storage
  - Retail bullion: competes with Baird & Co (Hatton Garden, London) and ATS Bullion as UK retail dealer
- **Manchester and Leeds Financial Sector**:
  - Spinningfields (Manchester) financial district: Standard Chartered and Barclays commodity desks post-Brexit relocations
  - Northern England retail gold and jewellery trade: significant secondhand gold market through Cash Generator, jewellery quarter
  - Sheffield: gold assay office (one of four UK assay offices alongside London Goldsmiths' Hall, Edinburgh, Birmingham); industrial metalworking heritage
  - Birmingham Jewellery Quarter: processes ~40% of UK retail gold jewellery; ~5,000 workers; 0.5 km² historic industrial district; Hockley area; Birmingham Assay Office hallmarking
  - Leeds: proximity to Bradford Asian textile/jewellery trade (significant gold jewellery retail)
- **Edinburgh and Scottish Academic Context**:
  - University of Edinburgh Business School: commodity economics and monetary history research
  - Forrest Capie (Cass Business School, London — former BoE historian): UK banking history including gold standard periods
  - Charles Goodhart (LSE, formerly BoE): central banking and monetary theory
  - Scotgold Resources: commercially explored Cononish gold deposit near Tyndrum, Scotland (2016–2022 production at ~10,000 oz/year — Scotland's only modern gold mine)
  - Kildonan, Sutherland: site of Scotland's 1869 gold rush; recreational gold panning still occurs
  - Scottish free banking tradition (1750–1845): Bank of Scotland, Royal Bank of Scotland issued gold-convertible notes; studied by Kevin Dowd, George Selgin as historical example of monetary competition
- **Imperial College London**:
  - Centre for Financial Technology: research on digital commodities and tokenised assets
  - Business School: gold market microstructure, commodity derivatives, portfolio optimisation including gold
  - Hosted 2023 LBMA/WGC digital gold symposium on tokenisation standards and blockchain settlement
  - Professor Raghavendra Rau (previously Judge Business School Cambridge): cryptocurrency as "digital gold" research; commodity-backed token economics

### Future Directions (2026–2030)

- **Tokenised Gold Mainstream Adoption**:
  - LBMA Digital Market Working Group's 2024 framework: blockchain-based gold delivery for institutional LBMA settlement
  - Target: 5–10% of LBMA daily volume settled via on-chain tokenised gold by 2028–2030
  - IMF Working Paper WP/24/118: gold-backed digital monetary instruments in cross-border payment architectures
  - Expected progression: pilot bilateral settlement → multi-lateral clearing → integration with SWIFT ISO 20022
  - Key technical challenges: integrating blockchain finality with T+2 legacy clearing, DvP (Delivery vs Payment) atomic settlement
- **Gold-Backed CBDC Proposals**:
  - Russia 2024 digital ruble discussion paper: gold-peg mechanism for international settlements with non-Western partners
  - Zimbabwe ZiG (Zimbabwe Gold) currency: launched April 2024 — physical currency backed by gold and foreign reserves; first new gold-backed fiat currency in post-Bretton Woods era
  - Kazakhstan and UAE: discussed regional gold-backed digital settlement currencies for BRICS+ intra-trade
  - IMF cautious: 2024 staff note warns gold-backed CBDCs risk importing gold market volatility into monetary base; recommends diversified commodity baskets
- **AI-Driven Gold Market Surveillance**:
  - LBMA and FCA deploying AI-based market surveillance for gold price manipulation detection
  - Context: 2014–2015 LBMA Gold Fixing manipulation scandals — Barclays, Deutsche Bank, Société Générale, UBS fined $2.3B total
  - ML pattern recognition on microstructure data (time and sales, order book depth)
  - Cross-market order flow analysis (COMEX/LBMA/SGE) for coordinated manipulation signals
  - NLP surveillance of trader communications (FCA Market Watch 77 — AI in market abuse detection)
  - Chainalysis and Elliptic: blockchain analytics for tokenised gold AML monitoring
- **Asteroid and Deep-Sea Mining** — long-horizon supply considerations:
  - 16 Psyche asteroid: estimated $700 quintillion in metals (iron, nickel, gold) — academic figure; no economic mining mechanism exists at any foreseeable cost
  - Clarion-Clipperton Zone (Pacific deep sea): polymetallic nodules contain gold at ~1 ppb (negligible gold yield vs copper/cobalt/manganese recovery)
  - Near-term reality: no meaningful supply impact within 2026–2030 horizon
  - Bitcoin proponent argument: these scenarios illustrate that gold supply is ultimately finite only with current technology; Bitcoin's 21M cap is mathematically absolute regardless of future technology
- **Physical-Digital Gold Convergence**:
  - Trajectory: each LBMA Good Delivery Bar individually tokenised with unique on-chain identifier
  - Technologies in pilot: GPS vault tracking, continuous audit via zero-knowledge proof attestations
  - ZKP audit: prover demonstrates specific bar is in vault without revealing total vault holdings (privacy-preserving attestation)
  - Participants: Paxos, LBMA Digital Market Working Group, Allocated Bullion Exchange, Orion Metal Exchange
  - Goal: eliminate allocated/unallocated distinction entirely — every token holder has cryptographically provable allocated ownership
  - Timeline: institutional pilot 2025–2026; broader adoption 2027–2030
- **Gold in AI-Blockchain Convergence**:
  - DeFi protocol integrations expanding: MakerDAO multi-collateral DAI, Synthetix synthetic gold (sXAU)
  - Layer 2 gold settlement: gold-backed tokens on Polygon, Arbitrum, Base for lower-fee DeFi transactions
  - Cross-chain gold bridges: Thorchain enabling PAXG swaps to native Bitcoin and ETH without custodian intermediary
  - Institutional tokenised gold: JP Morgan Onyx blockchain pilot for gold OTC settlement using tokenised gold
  - AI-managed gold portfolios: systematic commodity allocation through AI portfolio engines (Two Sigma, AQR) treating gold as factor

### Gold Market Microstructure and Price Formation

- Gold price formation operates across three interconnected venues with arbitrage mechanisms maintaining convergence across time zones:
- **London OTC Market (LBMA)**: The dominant price discovery venue for spot gold. Trading occurs bilaterally between ~50 active market-making members with the ICE LBMA Gold Price auction (10:30 AM and 3:00 PM London time) providing the global benchmark. The PM fix (3:00 PM) is particularly important as it coincides with the opening of New York markets. Daily OTC turnover of $35–50B in London is primarily unallocated (credit-based), with cleared trades processed through LMEClear (CME Group's clearing service for LBMA since 2014). The BIS Triennial Survey (2022) found gold to be the fifth most-traded OTC instrument globally after major FX pairs, with average daily global gold OTC turnover of $131B.
- **COMEX New York (CME Group)**: The primary derivatives venue. The 100 troy oz Gold Futures contract (GC, symbol XAUUSD in FX markets) trades nearly 24 hours/day on CME Globex with physical delivery at COMEX-approved vaults in New York area (Brink's, HSBC, ICBC Standard Bank). Open interest regularly exceeds 400,000 contracts (~40M oz, ~$120B notional at $3,000/oz). The price relationship between COMEX futures and LBMA spot is maintained through exchange-for-physical (EFP) transactions — the spread normally reflects financing costs (interest rate differential) and typically runs ~$5–20/oz contango (COMEX above spot). During stress events (March 2020 COVID crisis, when 400 oz LBMA bars could not be physically delivered to COMEX vaults accepting only 100 oz bars), this spread widened to $70+/oz, exposing the mechanical fragility of the inter-market arbitrage.
- **Shanghai Gold Exchange (SGE) and SGEI**: China operates the SGE as a domestic physical exchange with mandatory import/export controls (gold cannot freely leave China without PBOC authorisation). The SGE Au99.99 (4-nines fine, 1 kg bars) contract is the most actively traded physical gold contract globally by volume. The SGEI (Shanghai International Gold Exchange, a free trade zone subsidiary launched 2014) allows foreign participation with SGEI iAu99.99 contracts settled in offshore RMB. The SGE/LBMA price spread (the "Shanghai premium" or occasionally "Shanghai discount") reflects the supply-demand balance for physical gold within China's capital-controlled market — premiums of $5–30/oz above LBMA are common during periods of high Chinese domestic demand.
- **Gold Options**: COMEX gold options on futures provide substantial institutional hedging activity. Put/call skew in gold options markets functions as a real-time indicator of tail-risk sentiment — a shift toward put premium (downside protection) suggests institutional de-risking, while call skew indicates speculative bullish positioning. The CBOE Gold Volatility Index (GVZ) measures 30-day implied volatility on GLD options, providing a VIX-equivalent for gold markets; GVZ averaged 15–18% through 2024 vs equity VIX ~15–20%, meaning gold and equity volatility are comparable despite gold's "safe haven" reputation.
- **Algorithmic and HFT Gold Trading**: COMEX Globex gold futures are heavily traded by algorithmic market makers and high-frequency traders (HFT), with message rates of 100,000+ per second during US market hours. AI/ML-based trading strategies in gold focus on: cross-asset correlation detection (gold vs US real yields, USD index, inflation breakevens); event-driven trading around Fed communications (FOMC statements, Jackson Hole speeches); Chinese demand signal extraction from SGE volume and premium data; and geopolitical risk premium quantification from news flow NLP analysis. Major HFT firms in gold markets include Jump Trading, Virtu Financial, and Citadel Securities.

### Gold AML and Compliance Architecture

- The gold market faces specific AML/KYC challenges due to gold's portability, anonymous transferability when untracked, and historical use in sanctions evasion:
- **FATF Guidance**: The Financial Action Task Force (FATF) *Guidance for a Risk-Based Approach: Dealers in Precious Metals and Stones* (2013, revised 2021) requires dealers to apply customer due diligence (CDD), beneficial ownership identification, and suspicious transaction reporting. Gold's unique challenge: a 400 oz (~12.4 kg) LBMA bar has ~$1.2M value at $3,000/oz and is physically portable — making high-value cash-equivalent transactions possible with relatively small physical quantities.
- **Conflict Gold and Sanctioned Gold**: The US OFAC has designated Sudanese, Malian, North Korean, and Russian gold supply chains as sanctions targets. LBMA suspended Russian refiners (Novosibirsk, Krastsvetmet, and others) from Good Delivery List in March 2022 following Ukraine invasion. Hallmarked pre-2022 Russian bars remained eligible (creating "birth year" tracking requirements by custodians). COMEX amended its rules to require delivery of bars from non-sanctioned refiners.
- **Travel Rule and Gold Tokens**: The FATF Travel Rule (Recommendation 16) requires virtual asset service providers (VASPs) to transmit originator/beneficiary information alongside transfers above $1,000/€1,000 threshold. Gold-backed tokens (PAXG, XAUT, KAU) are classified as VASPs by most jurisdictions, requiring Travel Rule compliance — implemented via Notabene, TRM Labs, and Chainalysis Travel Rule tools. The interaction between gold's traditional AML framework (LBMA Responsible Gold, OECD DD Guidance) and blockchain-layer VASP requirements creates a layered compliance stack specific to tokenised precious metals.
- **LBMA Chain of Custody**: Every movement of an LBMA Good Delivery bar is documented through a Memorandum of Transfer (MoT) maintained by the receiving custodian, creating a paper chain-of-custody linking bar serial numbers to vault movements. Blockchain-based chain-of-custody systems (explored by Responsible Gold and the LBMA Digital Market Working Group) would provide tamper-evident, immutable audit trails replacing paper MoTs — with direct applicability to [[AML KYC Compliance]] requirements in gold markets.

### Gold in Portfolio Theory and Risk Management

- Modern Portfolio Theory (MPT) treats gold as an asset with distinctive correlation properties that justify inclusion even at low expected return:
- **Correlation Properties**: Gold exhibits near-zero correlation with global equities over 20+ year periods (Brinson et al., updated by Erb & Harvey 2013: rolling 5-year correlation XAUUSD vs S&P 500 ranged -0.3 to +0.3, averaging near zero). During acute equity drawdowns (2008–2009: S&P -57%, gold +5%; 2020 COVID: S&P -34%, gold initially -12% but recovered to +10% by year-end; 2022: S&P -19%, gold -1%), gold's safe-haven properties partially materialise — not as consistently as US Treasuries, but with lower duration risk in rising-rate environments.
- **Optimal Allocation**: Quantitative portfolio optimisation studies (World Gold Council 2024 *Gold as a Strategic Asset* report) suggest 4–6% gold allocation maximises the Sharpe ratio of a typical 60/40 equity/bond portfolio under historical return assumptions. At $3,000+/oz gold prices (2025), the opportunity cost of non-yielding gold allocation has decreased relative to the 2022–2023 high-rate environment when 5%+ risk-free rates made gold's zero yield acutely disadvantageous.
- **Central Bank Portfolio Management**: The IMF *Guidelines for Foreign Exchange Reserve Management* (2013) identifies gold as an acceptable reserve asset for central banks managing both liquidity and store-of-value objectives. The CBGA (Central Bank Gold Agreements) I–V (1999–2024), successive European central bank agreements limiting annual gold sales to prevent market disruption (post-1990s European CB sales that drove gold from $250 to $285/oz), have been progressively superseded by the current accumulation environment where European CBs are broadly neutral to small net buyers.
- **VAR (Value at Risk) Gold Treatment**: Under Basel III Internal Models Approach (IMA), gold positions attract a market risk charge based on 10-day 99% confidence interval VaR. Historical VaR for gold (~15–20% annual volatility) implies 10-day 99% VaR of ~$150–200/oz at $3,000 price, meaning a 100 oz COMEX position requires ~$15,000–$20,000 in regulatory capital. Under the Basel III Fundamental Review of the Trading Book (FRTB) standardised approach, gold is treated as FX (since it is priced in USD) attracting a 20% risk weight — significantly more favourable than Bitcoin's 1250%.

### Historical Gold Standards and Monetary Transitions

- The institutional history of gold-as-money provides context for both the current central bank accumulation cycle and the Bitcoin "digital gold" value proposition:
- **Classical Gold Standard (1871–1914)**: Following Germany's adoption of a gold standard after the Franco-Prussian War (1871, funded by French war reparations paid in gold), the major trading nations converged on gold monometallism by 1880. The classical gold standard involved: fixed exchange rates between currencies (sterling-dollar at $4.867/£); automatic balance-of-payments adjustment (Hume price-specie flow mechanism); and gold as settlement medium for international trade imbalances via physical shipment between central banks. The Bank of England operated as the de facto global central bank, managing global liquidity through Bank Rate. The system enabled remarkable economic integration 1870–1914 (the "first globalisation") but constrained monetary responses to cyclical downturns, leading to periodic banking panics (1873, 1893, 1907).
- **Bretton Woods System (1944–1971)**: Post-WWII monetary architecture created at Bretton Woods, New Hampshire, established a gold-exchange standard: the USD was fixed to gold at $35/troy oz (the 1934 Gold Reserve Act price set by FDR), and all other currencies maintained fixed exchange rates to the dollar. Participating central banks could redeem dollar reserves for gold at $35/oz. This created the "Triffin Dilemma" — the US supplied global liquidity by running current account deficits, but dollar accumulation eventually undermined gold convertibility confidence. By August 1971, French and British reserve managers demanded gold for dollar holdings, exhausting US gold stock (from 20,000 tonnes in 1945 to ~8,133 tonnes in 1971). President Nixon closed the gold window August 15, 1971, ending convertibility and transitioning to the current fiat system.
- **Post-Bretton Woods Gold (1971–1999)**: Gold floated freely after 1971, reaching $850/oz in January 1980 (first gold bubble) before declining to $250–280/oz by 1999–2001 (Brown's Bottom — UK HM Treasury sales coincided with the multi-decade low). Central banks sold 400–500 tonnes/year through the 1990s–2000s under CBGAs. IMF gold sales totalling 403 tonnes occurred 2009–2010 at $900–$1,000/oz (of which India purchased 200 tonnes in a single transaction — the largest single central bank purchase at the time).
- **2008–Present: Monetarist Gold Revival**: The 2008 financial crisis, subsequent central bank QE programmes expanding global reserve asset supply by $10+ trillion, and the emergence of Bitcoin as a monetary alternative catalysed renewed interest in gold's monetary properties. Central banks shifted from net sellers (1990s–2008) to net buyers (2010–present). The 2022 Russian reserve freeze crystallised the "counterparty risk" of dollar reserves for non-Western central banks, accelerating the structural accumulation cycle.

### Gold Mining: Production Economics and Environmental Impact

- Understanding gold's supply side is essential to the monetary scarcity argument and its sustainability dimensions:
- **Global Production**: Annual gold mine production of ~3,500 tonnes is dominated by China (~370 tonnes, 2024), Russia (~310 tonnes, reduced from ~320 pre-sanctions isolation from LBMA), Australia (~310 tonnes), Canada (~200 tonnes), USA (~170 tonnes), Ghana (~130 tonnes), South Africa (~100 tonnes, sharply down from 1,000+ tonnes at peak in 1970s due to deep-level mine depletion), and Indonesia/Peru/Mexico contributing 100–200 tonnes each.
- **All-In Sustaining Cost (AISC)**: The World Gold Council developed the AISC metric (2013) as the most comprehensive measure of gold mining cash cost including production, sustaining capex, corporate overhead, and reclamation. Industry AISC averaged $1,200–$1,350/oz across major producers in 2024. At $3,000+/oz spot prices, the sector generates exceptional free cash flow (FCF margin ~55%), driving shareholder returns via buybacks (Newmont $1B buyback 2024), dividends (Barrick ~3% yield), and project development. Marginal cost (the cost of the highest-cost producing mine) typically approximates a long-run floor price — estimated at $1,400–$1,600/oz for current production levels.
- **Environmental Impact**: Gold mining's environmental legacy includes: cyanide heap leach tailings (sodium cyanide solution applied to low-grade ore to dissolve gold, creating toxic runoff risk — Baia Mare spill, Romania 2000 killed aquatic life in 2,000 km of river system); mercury amalgamation (artisanal/small-scale mining: 15–20 million ASM miners globally using mercury in Latin America, Sub-Saharan Africa, Southeast Asia, generating ~400–600 tonnes of mercury emissions annually — the largest single source of anthropogenic mercury pollution globally per UNEP); acid mine drainage (oxidation of sulfide ores producing sulfuric acid leaching heavy metals into waterways, affecting thousands of km of South African rivers from legacy mines); and land use (open-pit mines like Newmont's Batu Hijau in Indonesia spanning 1,000+ hectares with 500M+ tonne waste dumps).
- **Sustainable Gold**: The Responsible Jewellery Council (RJC) certification, Fairmined standard (Alliance for Responsible Mining), and Fairtrade Gold standard certify small-scale artisanal miners meeting environmental and labour standards. Certified sustainable gold commands a $2–15/gram premium. The London Bullion Market Association Responsible Gold Guidance (7th Ed. 2023) requires refiners to trace supply chains back to mine source for conflict-affected and high-risk areas (CAHRAs), aligned with OECD DD Guidance 2nd Edition.

### Research & Literature

- Key academic and institutional sources for gold economics and tokenisation:
- **World Gold Council (WGC)**: Gold Demand Trends (quarterly, 2024 Q1–Q4, 2025 Q1) — authoritative demand/supply statistics. *Central Bank Gold Statistics* (quarterly). *Gold as a Strategic Asset* series (annual quantitative allocation analysis). *Gold and Climate Change* report 2024.
- **LBMA Publications**: *The Alchemist* (quarterly journal). *LBMA Annual Report 2024*. *Good Delivery Rules for Gold and Silver Bars* (current edition 2023). *Responsible Gold Guidance 7th Edition 2023*. LBMA Digital Market Working Group Reports 2023–2024.
- **BIS Basel III Documentation**: Basel Framework Chapter CRE20 "Standardised Approach: Credit Risk Mitigation". BIS Working Paper on Commodity as HQLA (WP 1034, 2022). BIS Triennial Central Bank Survey of Foreign Exchange and OTC Derivatives Markets 2022.
- **Academic**: Baur & Lucey (2010), *Is Gold a Hedge or a Safe Haven?*, Financial Review 45(2), 217–229; Baur & McDermott (2010), *Is Gold a Safe Haven? International Evidence*, Journal of Banking & Finance 34(8), 1886–1898; Erb & Harvey (2013), *The Golden Dilemma*, Financial Analysts Journal 69(4); Conlon & McGee (2020), *Safe Haven or Risky Hazard? Bitcoin During the COVID-19 Bear Market*, Finance Research Letters 35; Wang et al. (2022), *Volatility Spillovers Between Cryptocurrencies and Gold*, Resources Policy 80; Dyhrberg (2016), *Bitcoin, Gold and the Dollar*, Finance Research Letters 16, 85–92; Ammous (2018), *The Bitcoin Standard*, Wiley; Alden (2023), *Broken Money*, Theorem Press; Menger (1871), *Principles of Economics*, Braumüller Vienna; Mises (1912), *Theory of Money and Credit*, Duncker & Humblot Leipzig.
- **Industry**: CME Group COMEX Gold Contract Specifications GC; ICE Benchmark Administration LBMA Gold Price Methodology 2024; Paxos PAXG Whitepaper v2 (2022); Tether Gold XAUT Whitepaper (2020); Kinesis Money KAU Technical Documentation (2021); FATF Guidance for a Risk-Based Approach to Dealers in Precious Metals and Stones (2021); OECD Due Diligence Guidance for Responsible Supply Chains of Minerals from Conflict-Affected and High-Risk Areas (2016).

### Provenance

- World Gold Council Gold Demand Trends Q1–Q4 2024, Q1 2025 (wgc.org/research/gold-demand-trends)
- LBMA Annual Report 2024 (lbma.org.uk/publications)
- LBMA Good Delivery Rules for Gold and Silver Bars, current edition 2023
- LBMA Responsible Gold Guidance 7th Edition 2023
- BIS Basel Framework Chapter CRE20 Standardised Approach Credit Risk Mitigation
- BIS Working Paper 1034: Gold as HQLA (2022)
- ICE Benchmark Administration LBMA Gold Price Methodology 2024
- CME Group COMEX Gold Futures Contract Specifications (GC)
- Shanghai Gold Exchange Annual Report 2024
- Paxos PAX Gold (PAXG) Whitepaper v2 (2022, paxos.com)
- Tether Gold XAUT Whitepaper (2020, gold.tether.to)
- Kinesis Money KAU Technical Documentation 2021 (kinesis.money)
- Royal Mint Annual Review 2023/24 (royalmint.com)
- Bank of England Gold Vaulting Services (bankofengland.co.uk/markets/gold)
- Reserve Bank of India Annual Report 2024 — Gold Reserves section
- National Bank of Poland Financial Report 2024 (nbp.pl)
- IMF International Financial Statistics: Official Reserve Assets by Country, December 2024
- IMF Working Paper WP/24/118: Digital Commodity Money (2024)
- Baur, D.G. & Lucey, B.M. (2010). Is Gold a Hedge or a Safe Haven? An Analysis of Stocks, Bonds and Gold. Financial Review 45(2), 217–229
- Baur, D.G. & McDermott, T.K. (2010). Is Gold a Safe Haven? International Evidence. Journal of Banking & Finance 34(8), 1886–1898
- Dyhrberg, A.H. (2016). Bitcoin, Gold and the Dollar — a GARCH Volatility Analysis. Finance Research Letters 16, 85–92
- Ammous, S. (2018). The Bitcoin Standard: The Decentralized Alternative to Central Banking. Wiley
- Alden, L. (2023). Broken Money: Why Our Financial System is Failing Us and How We Can Make It Better. Theorem Press
- **domain-correction:** infrastructure → economics (gold is an economic/monetary commodity concept, not infrastructure)
- **note:** Domain corrected from `infrastructure` to `economics`; IRI, URI, owl-class, and same-as updated accordingly. Original stub contained uncritical promotional content from a YouTube video embed; replaced with comprehensive ontology reference meeting Phase 6 quality bar.

## Metadata

- **Legacy Term ID**: EC-2201 (assigned during enrichment; original stub had no legacy-term-id)
- **Domain Correction**: `infrastructure` → `economics` — Gold is a monetary commodity and reserve asset concept belonging to the economics domain, not an infrastructure concept. Corrected IRI from `infrastructure#Gold` to `economics#Gold`, URI from `concept:infrastructure:gold` to `concept:economics:gold`, owl-class from `infrastructure:Gold` to `economics:Gold`.
- **Version**: 2.0.0 → 2.1.0 (domain correction + full Phase 6 enrichment)
- **OWL Axioms**: 42 SubClassOf axioms across 5 families (Compositional 7, Dependency 10, Capability 9, Implementation 9, Reduction 5, Association 5, Data Properties 8, Property Constraints 4)
- **Wikilink Relationships**: 67 across 11 relationship types
- **References**: 27 academic/industry/specification sources in Provenance
- **Research Cache**: `_enrich/research-cache/Gold.json`

