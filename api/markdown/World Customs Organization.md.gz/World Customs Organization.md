The World Customs Organization (WCO) is an international organisation that develops the Harmonized System and promotes customs co-operation. The European Commission says that the WCO plays an important role in promoting international customs co-operation and addressing new challenges for customs and trade, and that the European Union joined it from 1 July 2007 on an interim basis, with rights and obligations akin to those of WCO Members.[^1]

## What the WCO does

The WCO's own page on the Harmonized System says that the Harmonized Commodity Description and Coding System is a multipurpose international product nomenclature developed by the WCO, and that more than 200 countries and economies use it as a basis for their customs tariffs and for the collection of international trade statistics.[^2] The Commission lists the areas of EU involvement in the WCO: nomenclature and classification under the Harmonised System, origin of goods, customs value, simplification and harmonisation of customs procedures and trade facilitation, and the development of supply chain security standards.[^1]

## Membership

The Commission's page refers to 172 current Members of the organisation, a figure that is a snapshot from the date the page was read.[^1] Full accession of the EU requires an amendment to the Convention establishing a Customs Co-operation Council, which allows economic and customs unions to join, to be ratified by those Members.[^1]

## Role in the supply chain

The WCO is an [[Intergovernmental Trade Organisation]] and its nomenclature is used in tariff classification; see also [[Customs Declaration]] and [[Customs Clearance]]. The official spelling World Customs Organization is kept as the title, and World Customs Organisation is an alias.

## What the sources do not establish

The WCO's own pages could not be read for a self-description beyond the Harmonized System page, because the general pages carried navigation text only. The sources opened do not use the word intergovernmental, so that label comes from the vault catalogue. They give no founding date or budget, and the WCO Data Model was not opened.[^2][^1]

[^1]: European Commission, Taxation and Customs Union, “World Customs Organization”. https://taxation-customs.ec.europa.eu/customs-4/international-affairs/world-customs-organization_en
[^2]: World Customs Organization, “What is the Harmonized System (HS)?”. https://www.wcoomd.org/en/topics/nomenclature/overview/what-is-the-harmonized-system.aspx

