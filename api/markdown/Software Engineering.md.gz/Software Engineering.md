Software Engineering is the disciplined application of systematic, quantifiable, and theoretically grounded approaches to the specification, design, development, testing, deployment, and maintenance of software systems. It draws on computer science, project management, and systems thinking to produce reliable, maintainable, scalable, and secure software at scale. The field encompasses a lifecycle spanning requirements elicitation, architectural design, implementation, verification and validation, and operational observability. Modern practice integrates agile and lean methodologies, continuous delivery pipelines, domain-driven design, and platform engineering to sustain high-velocity, high-quality development across distributed teams.

### Overview

- Software Engineering emerged as a named discipline at the 1968 NATO Software Engineering Conference in Garmisch, Germany, in direct response to the "software crisis" — the observation that software projects routinely ran over budget, over schedule, and delivered unreliable systems.
- The core insight is that software development at scale requires the same rigour as civil or mechanical engineering: repeatable processes, measurable quality attributes, formal specifications, and systematic testing.
- Modern software engineering is characterised by:
  - Iterative and incremental delivery replacing waterfall big-bang releases
  - [[Continuous Integration]] and [[Continuous Delivery]] pipelines automating build, test, and deployment
  - Cross-functional teams combining development, operations ([[DevOps]]), security ([[DevSecOps]]), and product management
  - Quantitative quality measures: code coverage, cyclomatic complexity, mean time to recovery (MTTR), deployment frequency
- The discipline is considered **mature**: its foundational practices are well-understood, extensively published, standardised by ISO/IEC and IEEE, and taught in every major university computing programme worldwide.

### Key Components

#### Requirements Engineering

- The process of eliciting, analysing, specifying, and validating the needs of stakeholders before design begins.
- Techniques: user stories, use cases, formal specifications (Z notation, Alloy), domain modelling.
- Poor requirements are the leading cause of project failure; [[Requirements Engineering]] directly determines system fitness.

#### Software Architecture

- High-level structural decisions about system decomposition, component responsibilities, and inter-component contracts.
- Key styles: [[Microservices Architecture]], [[Event-Driven Architecture]], layered architectures, hexagonal/ports-and-adapters.
- [[Software Architecture]] decisions are expensive to reverse and carry long-term quality consequences ([[Technical Debt]]).

#### Software Design Patterns

- Reusable solutions to recurring design problems, catalogued in the Gang of Four (GoF) patterns (Singleton, Factory, Observer, Strategy, etc.) and enterprise patterns (Repository, CQRS, Saga).
- [[Software Design Patterns]] encode collective wisdom and improve communicability between engineers.
- [[Domain-Driven Design]] (DDD) extends pattern thinking to align software structure with business domains through bounded contexts, aggregates, and ubiquitous language.

#### Implementation and Code Quality

- Writing production code to the designed specification using appropriate programming languages and frameworks.
- Quality dimensions: correctness, readability, testability, performance, security.
- Practices: [[Test-Driven Development]] (TDD), pair programming, [[Refactoring]], static and dynamic analysis.
- [[Static Analysis]] tools (linters, type checkers, SAST scanners) catch defects at compile time without running code.

#### Software Testing

- Systematic verification that software behaves as specified and validation that it satisfies user needs.
- Testing pyramid: unit tests (fast, isolated) → integration tests → end-to-end tests (slow, expensive).
- [[Software Testing]] disciplines include property-based testing, mutation testing, fuzz testing, and chaos engineering.
- [[Test-Driven Development]] inverts the conventional order: write failing tests before writing implementation code.

#### Version Control

- Tracking changes to source code over time, enabling collaboration, branching, merging, and rollback.
- Git is the dominant tool; [[Version Control]] strategies (trunk-based development, Gitflow) govern branching policies for teams.
- Pull requests and [[Code Review]] are primary quality gates enforced through version control workflows.

#### DevOps and Continuous Delivery

- [[DevOps]] integrates software development and IT operations to shorten delivery cycles and improve reliability.
- [[Continuous Integration]] ensures code changes are merged and tested frequently (multiple times per day).
- Continuous Delivery (CD) ensures every green build is deployable to production; Continuous Deployment removes the human release gate entirely.
- [[Infrastructure as Code]] (Terraform, Pulumi, CloudFormation) provisions and manages environments reproducibly, eliminating "works on my machine" failures.
- [[Containerisation]] (Docker, OCI images) packages applications with their dependencies; [[Kubernetes]] orchestrates containers at scale.

#### Observability

- The ability to infer the internal state of a running system from its external outputs: logs, metrics, and distributed traces.
- [[Observability]] is a prerequisite for reliable operations: without it, incidents cannot be diagnosed or learned from.
- Modern stacks use OpenTelemetry for instrumentation, feeding into platforms such as Grafana, Datadog, or Honeycomb.

### Applications / Use Cases

#### Enterprise Application Development

- Building ERP systems, CRM platforms, and business intelligence tools that process millions of transactions reliably.
- Requires strong [[Requirements Engineering]], formal change management, and long maintenance horizons (10–20 years).

#### Cloud-Native and Distributed Systems

- Designing applications that leverage cloud elasticity via [[Microservices Architecture]], service meshes, and managed databases.
- [[Distributed Systems]] engineering addresses consensus, partitioning, eventual consistency, and fault tolerance.

#### Embedded and Safety-Critical Systems

- Aerospace (DO-178C), automotive (ISO 26262 ASIL), and medical device (IEC 62304) software requires formal verification and exhaustive testing well beyond standard practice.
- [[Systems Engineering]] and software engineering overlap heavily in these domains.

#### Machine Learning System Engineering

- Applying software engineering rigour to ML workflows: reproducible experiments, model versioning, data pipeline testing, and model deployment pipelines (MLOps).
- [[Machine Learning Engineering]] is the fastest-growing sub-discipline, bridging software engineering and data science.

#### Platform and Developer Experience Engineering

- Building internal developer platforms (IDPs) that provide self-service infrastructure, golden paths, and abstractions over cloud complexity.
- [[Platform Engineering]] applies product thinking to tooling, treating developers as internal customers.

#### Open-Source Software Ecosystems

- Global distributed collaboration on shared codebases, governed by licences, contribution guidelines, and governance models.
- Version control, [[Code Review]], and CI/CD pipelines are foundational to open-source software engineering at scale.

#### Security Engineering and Secure SDLC

- Integrating [[Security Engineering]] throughout the lifecycle: threat modelling in design, SAST/DAST in CI pipelines, penetration testing pre-release.
- [[DevSecOps]] embeds security as a shared responsibility rather than a late-stage gate.

### Standards & Context

- **ISO/IEC 12207** — International standard for software lifecycle processes; defines process categories from acquisition through retirement.
- **IEEE Std 730** — IEEE Standard for Software Quality Assurance Processes; governs planning and execution of SQA activities.
- **[[SWEBOK]] v4** (IEEE, 2024) — Software Engineering Body of Knowledge; defines 18 knowledge areas including requirements, design, construction, testing, maintenance, and professional practice.
- **ISO/IEC 25010** — Systems and software quality model (SQuaRE); defines quality characteristics (functional suitability, reliability, usability, security, maintainability, portability, compatibility, performance efficiency).
- **CMMI (Capability Maturity Model Integration)** — Process improvement framework rating organisational software engineering maturity from Level 1 (Initial) to Level 5 (Optimising); used in defence and large-scale enterprise contexts.
- **Agile Manifesto (2001)** — Values and twelve principles reshaping the field away from plan-driven processes toward iterative, people-centric delivery; underpins Scrum, Kanban, XP, and SAFe frameworks.
- **The Twelve-Factor App** — Methodology for building software-as-a-service applications emphasising declarative configuration, statelessness, and disposability; canonical reference for cloud-native [[DevOps]].
- **OpenTelemetry (CNCF)** — Vendor-neutral [[Observability]] instrumentation standard providing unified APIs for traces, metrics, and logs.
- **Semantic Versioning (SemVer)** — Versioning convention (MAJOR.MINOR.PATCH) widely adopted to communicate compatibility guarantees in software releases, directly tied to [[Version Control]] workflows.

### Provenance

