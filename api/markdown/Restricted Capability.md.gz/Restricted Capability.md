
A restricted capability is an [[Agent Capability]] whose exercise is limited, and it is the sibling of [[Critical Capability]]. The two classes are disjoint: no capability is both critical and restricted. The Agent Ontology declares the class without a definition; this one follows from its parent and the axiom that involves it.[^1]

`RestrictedCapability` is a subclass of the core `Capability`. The disjointness is asserted between it and `CriticalCapability`, under the principle that an agent cannot claim contradictory capabilities.[^2]

The class is structural. Together with its sibling it gives a reasoner a pair of classes that must not overlap, so a capability claim that places one capability in both is detected as a contradiction. Which capabilities fall into which class is a matter for the policy that classifies them, not for the class itself.

[^1]: Semantic Agent Communication Community Group, “Security Binding Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/security-binding.ttl
[^2]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl

