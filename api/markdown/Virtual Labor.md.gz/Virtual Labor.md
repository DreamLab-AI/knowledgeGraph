Work performed in virtual environments that generates economic value, spanning content creation, service provision, virtual construction, platform governance, and social labour. Virtual labour is often platform-dependent, contract-based, and remunerated via virtual currency or revenue-sharing models, raising significant questions around labour rights, taxation of cross-border virtual income, and platform exploitation.

### Semantic Classification

### Content

#### Key Characteristics

- **Compensated Activities**: Direct monetary payment for virtual services
- **Value Creation**: Production of digital goods, experiences, or services
- **Platform Dependency**: Labor tied to specific virtual world infrastructures
- **Skill Requirements**: Technical, creative, and social competencies
- **Precarity Issues**: Often informal, contract-based, or platform-mediated

  ## Economic Models

- **Commission-Based**: Payment per completed virtual item or service
- **Subscription Services**: Recurring fees for ongoing virtual labor
- **Revenue Sharing**: Percentage of sales from user-generated content
- **Platform Wages**: Direct employment by metaverse operators
- **Tip/Donation Systems**: Voluntary compensation from beneficiaries

  ## Definition

  Work performed in virtual environments that generates economic value, spanning content creation, service provision, virtual construction, platform governance, and social labor.

  #### Related Concepts

- [[Virtual Economy]]
- [[Land Economics]]
- [[Digital Asset]]
- [[Virtual Currency]]
- [[User-Generated Content]]

  ## Applications

- Virtual architecture and construction
- Digital fashion design
- Virtual event hosting and entertainment
- In-world moderation and community management
- Avatar customization services
- Virtual tutoring and education

  ## Challenges

- Labor rights and protections in virtual spaces
- Taxation of cross-border virtual income
- Platform monopolies and exploitation
- Work-life boundary dissolution
- Skill transferability to physical economy

  #### References

- Fairfield, J. (2021). *Owned: Property, Privacy, and the New Digital Serfdom*
- Lehdonvirta, V. (2018). "Flexibility in the Gig Economy"
- Taylor, T. L. (2006). *Play Between Worlds: Exploring Online Game Culture*

  ### Relationships

### Provenance

