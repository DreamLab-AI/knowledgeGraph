Deferred rendering is a real-time shading technique that separates geometry processing from lighting by first rasterising scene attributes into a set of screen-space buffers, then computing lighting in a second pass over those buffers. By storing per-pixel position, normal, albedo, and material data in a geometry buffer, lighting cost becomes independent of scene complexity and scales with the number of lights instead. This decoupling makes it efficient to render scenes with many dynamic light sources.

### Overview

- Deferred rendering was developed to overcome the quadratic cost of forward shading when many lights illuminate a scene, where each object must be shaded against every light. By deferring lighting to a screen-space pass, the technique evaluates each pixel exactly once per contributing light. The trade-offs include higher memory bandwidth for the geometry buffer and difficulty handling transparency and hardware anti-aliasing.

### Mechanisms

- Geometry pass writes surface attributes into a multi-target geometry buffer
- Lighting pass reads the buffer and accumulates contributions per light in screen space
- Lighting cost scales with light count rather than geometric complexity
- Transparency typically requires a separate forward-rendered pass
- Bandwidth pressure from the fat geometry buffer is the main performance constraint

### Applications

- Real-time games and engines rendering many dynamic point and spot lights
- Screen-space effects such as ambient occlusion and reflections
- Approximations of global illumination in interactive frame budgets
- High-fidelity spatial computing and virtual production scenes

### Provenance

