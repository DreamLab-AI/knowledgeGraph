
An agent artefact is a produced output or result generated through agent execution. The Agent Ontology declares it as `Artifact`, using American spelling for the identifier.[^1] visionGraph places it under the AI Research Area hub.

An [[Agent Action]] yields an artefact through `producesArtifact`. The only property of the class itself is `description`, a human-readable string. Format, storage and integrity are not fixed, so a file, a message and a decision record all qualify.

The artefact is the outcome end of the chain from [[Agent Intent]] to action: an intent leads to an action, and the action leads to an artefact. The action itself may be recorded separately as an [[Agent Trace Event]], which describes that the action happened, while the artefact is what it left behind.

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl

