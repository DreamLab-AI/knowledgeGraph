Regulation is the systematic use of authoritative rules, standards, and enforcement mechanisms by governments, inter-governmental bodies, or designated agencies to direct, constrain, or oversee the conduct of individuals, organisations, and systems within a defined domain. It encompasses the full lifecycle from rule-making and publication through monitoring, inspection, and sanctioning of non-compliance. Regulation is distinct from voluntary standards in that it carries legal force and can result in penalties, licence revocation, or other coercive consequences for non-conformance. In technical domains such as AI, data systems, and critical infrastructure, regulation increasingly intersects with algorithmic accountability, risk classification, and mandatory transparency obligations.

### Overview

- Regulation represents one of the fundamental tools through which societies manage collective risk, protect vulnerable parties, and coordinate economic activity. Unlike [[Self-Regulation]] or voluntary codes of conduct, statutory regulation binds all actors within its scope and provides sanctioning powers to [[Supervisory Authority]] bodies. The rationale for regulation typically rests on identified market failures — information asymmetries, externalities, natural monopoly conditions, or systemic risk — where uncoordinated private action produces socially suboptimal outcomes.
- The regulatory process typically follows a recognisable pattern: a statutory mandate confers power on an agency; the agency develops secondary rules through [[Rule-Making]] procedures that commonly include consultation and impact analysis; rules are published and given effect; ongoing [[Audit]] and inspection verify adherence; and non-compliance attracts graduated sanctions ranging from warnings through fines to criminal prosecution or [[Licensing]] revocation.
- Regulation differs from [[Policy]] in that policy expresses intent or direction, while regulation gives that intent legal force. It differs from [[Legislation]] in that legislation is enacted by a legislature, whereas most detailed regulatory rules are made by delegated authority under enabling statutes.

### Key Mechanisms

- **Rule-Making and Publication**
  - Draft rules are subject to [[Impact Assessment]] to weigh costs and benefits before finalisation. [[Transparency]] requirements mandate public consultation periods and plain-language summaries for affected parties.
- **Licensing and Authorisation**
  - Many regulated sectors require prior [[Licensing]] or registration. Conditions attached to licences operationalise ongoing obligations, and revocation is a powerful enforcement lever.
- **Supervisory Oversight**
  - [[Supervisory Authority]] bodies conduct routine and event-triggered inspections, analyse reported data, and may issue guidance, directions, or binding decisions.
- **Enforcement and Sanctions**
  - [[Enforcement]] ranges from informal supervisory engagement through civil penalties, criminal prosecution, and remedial orders. Proportionality principles generally require sanctions to reflect the severity and culpability of the breach.
- **Regulatory Impact Assessment**
  - [[Risk Assessment]] and [[Impact Assessment]] are used upstream to identify proportionate regulatory responses and downstream to evaluate whether rules achieve their objectives.
- **Co-Regulation and Hybrid Approaches**
  - Many modern frameworks combine statutory backstops with industry-led codes, creating a spectrum between pure [[Self-Regulation]] and full command-and-control models. This mirrors structures found in [[AI Governance]] frameworks such as the EU AI Act.
- **International Coordination**
  - Global markets require cross-border regulatory dialogue. Bodies such as the Basel Committee, IOSCO, and IAEA coordinate regulatory standards across jurisdictions to prevent regulatory arbitrage.

### Applications and Use Cases

- **Financial Services**
  - Prudential regulation governs capital adequacy, liquidity, and systemic risk in banks and insurers. Conduct regulation addresses [[Market Integrity]], consumer disclosure, and anti-money-laundering obligations. Frameworks include Basel III, MiFID II, and Dodd-Frank.
- **Data and Privacy**
  - [[Data Protection]] regulation (GDPR in the EU, UK GDPR, CCPA in California) constrains how personal data may be collected, processed, and transferred, underpinning [[Data Sovereignty]] objectives. [[Transparency]] and accountability principles are central.
- **Artificial Intelligence**
  - The EU AI Act creates a risk-tiered regulatory framework for AI systems, imposing conformity assessment, [[Algorithmic Accountability]], and prohibited-use categories. This connects Regulation directly to [[AI Governance]] and [[Machine Learning]] deployment pipelines.
- **Critical Infrastructure**
  - Energy, telecommunications, transport, and water sectors are regulated to ensure service continuity, [[Safety]], and fair access. Network industries typically feature economic regulation (price controls, access obligations) alongside technical safety regulation.
- **Healthcare and Pharmaceuticals**
  - Medicines and medical devices require pre-market authorisation (EMA, FDA). Post-market surveillance feeds back into regulatory assessment cycles. [[Certification]] and Good Manufacturing Practice underpin quality assurance.
- **Environmental and Climate**
  - Emissions trading systems, pollution limits, and environmental impact requirements regulate externalities. Climate disclosure regulation extends to financial sectors, requiring firms to report climate-related risks.
- **Digital Markets and Platforms**
  - Emerging frameworks (EU Digital Markets Act, UK Digital Markets, Competition and Consumers Act) apply asymmetric obligations to gatekeepers, addressing interoperability, data access, and self-preferencing.
- **Spatial Computing and Immersive Environments**
  - Spectrum allocation, content moderation, and consumer protection obligations are being extended to immersive and extended-reality platforms, bridging governance into [[Spatial Computing]] contexts.

### Regulatory Doctrines and Design Principles

- **Proportionality** — regulatory obligations should be commensurate with the risk or harm addressed; excessive burden relative to benefit undermines compliance and economic welfare.
- **Consistency** — rules should be applied evenly across comparable actors to prevent [[Market Integrity]] distortions.
- **Transparency** — rule-making processes, enforcement decisions, and supervisory rationale should be accessible to affected parties and the public.
- **Accountability** — regulators are themselves subject to oversight (parliamentary, judicial, or ombudsman scrutiny) to prevent capture or abuse of delegated power.
- **Adaptability** — regulatory frameworks require periodic review to remain fit-for-purpose as technology, markets, and societal values evolve.
- **Subsidiarity** — in multi-level governance systems, regulation is assigned to the most appropriate level (local, national, supranational) based on the scope of the activity and externalities.

### Regulatory Styles and Traditions

- **Common Law Tradition** — regulation is often principles-based, with significant judicial interpretation. UK, Australia, New Zealand, Hong Kong, and US federal regulation exhibit this style.
- **Civil Law Tradition** — detailed codified rules dominate. French, German, and EU regulatory frameworks tend to be more prescriptive.
- **Risk-Based Regulation** — resources and scrutiny are allocated in proportion to assessed risk, characteristic of the UK Financial Conduct Authority and comparable bodies.
- **Responsive Regulation (Braithwaite)** — enforcement strategy escalates along a pyramid from persuasion to punitive sanctions, calibrated to actor behaviour and responsiveness.
- **Better Regulation Agenda** — associated with OECD recommendations, promoting [[Impact Assessment]], sunset clauses, regulatory simplification, and stakeholder engagement as quality discipline on rule-making.

### Standards and International Context

- **OECD Regulatory Policy** — the OECD's Regulatory Policy Committee produces the OECD Recommendation on Regulatory Policy and Governance (2012, updated guidance ongoing), promoting [[Standards]] for quality regulation across member states.
- **WTO Technical Barriers to Trade Agreement** — constrains the use of regulation as covert trade barriers, requiring that measures be no more trade-restrictive than necessary.
- **ISO/IEC Standards** — [[Certification]] to international standards (ISO 9001, ISO 27001, IEC 62443) is frequently used as a compliance pathway within regulatory regimes.
- **Financial Stability Board** — coordinates macro-prudential regulatory standards globally, including standards for systemically important financial institutions.
- **EU Regulatory Acquis** — the EU's body of regulation constitutes the most extensive supranational regulatory system, covering competition, financial services, data, product safety, environment, and increasingly AI.
- **Basel Committee on Banking Supervision** — sets global minimum standards for bank capital (Basel III/IV), liquidity, and governance, subsequently transposed into national law by member jurisdictions.

### Tensions and Critiques

- **Regulatory Capture** — the risk that regulated entities exert undue influence over their regulators, skewing rules in their favour. Structural safeguards include independence, rotation, and transparency of lobbying.
- **Regulatory Arbitrage** — firms relocate activities or incorporate in lenient jurisdictions to escape stricter rules, undermining regulatory objectives. International coordination via bodies such as FATF and IOSCO counters this.
- **Innovation Inhibition** — overly prescriptive regulation can foreclose beneficial technologies or business models. Regulatory sandboxes and innovation hubs attempt to balance [[Safety]] against dynamism.
- **Compliance Burden** — disproportionate compliance costs fall more heavily on smaller actors, potentially concentrating markets. Better [[Impact Assessment]] and proportionality exemptions partially address this.
- **Democratic Legitimacy** — delegation of rule-making to unelected agencies raises accountability questions; procedural safeguards (consultation, judicial review, parliamentary oversight) are the principal response.

### Provenance

