California AI bill is the collective designation for a sequence of California state legislative instruments enacted or proposed between 2023 and 2026 to regulate the development, deployment, and disclosure obligations of large-scale Frontier Models — most prominently Senate Bill 1047 (SB 1047...

### Semantic Classification

- SB 1047 (vetoed 2024) — pre-training safety mandate
- SB 53 (signed 2025, effective 2026) — frontier AI transparency
- AB 2013 (signed 2024, effective 2026) — training data disclosure
- AB 1008 (signed 2024, effective 2025) — CCPA extension to AI outputs
- SB 942 / AB 853 (signed 2025, effective August 2026) — AI content transparency
- AB 489 (signed 2025, effective 2026) — healthcare AI guardrail
- **regulatory-paradigm:** transparency-first (SB 53/AB 2013) superseding pre-certification (SB 1047)
- **threshold-type:** dual (compute 10^26 FLOPs AND revenue >$500M for SB 53); single compute (10^26 FLOPs AND cost >$100M for SB 1047)
- **preemption-status:** contested (Trump EO December 2025); legal consensus predicts preemption challenge unlikely to succeed absent federal AI statute
- **california-effect-domains:** UK DSIT consultations, Canada AIDA, Australia AI safety standards, EU GPAI Code of Practice
  - 2024-02-07 SB 1047 introduced
  - 2024-08-30 SB 1047 passes both chambers
  - 2024-09-28 AB 2013 signed; AB 1008 signed
  - 2024-09-29 SB 1047 vetoed by Newsom
  - 2025-09-29 SB 53 signed by Newsom
  - 2025-12-11 Trump EO National AI Policy Framework
  - 2026-01-01 SB 53 and AB 2013 take effect
  - 2026-03-30 Newsom EO N-5-26 AI procurement
  - 2026-08 SB 942/AB 853 AI Transparency Act takes effect

### Content

## Compositional Relationships (Components)
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:hasPart ai:SB1047FrontierModelAct))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:hasPart ai:SB53TransparencyAct))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:hasPart ai:AB2013TrainingTransparencyAct))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:hasPart ai:FrontierAIFramework))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:hasPart ai:CriticalSafetyIncidentReporting))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:hasPart ai:WhistleblowerProtectionMechanism))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:hasPart ai:KillSwitchMandate))

    ## Dependency Relationships
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:requires ai:FrontierModelDefinition))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:requires ai:ComputeThreshold))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:requires ai:RevenueThreshold))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:requires ai:SafetyEvaluationProtocol))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:requires ai:AttorneyGeneralEnforcement))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:dependsOn ai:CaliforniaLegislature))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:dependsOn ai:NISTAIRiskManagementFramework))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:dependsOn ai:ISOIEC42001))

    ## Capability Relationships
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:enables ai:AITransparency))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:enables ai:AlgorithmicAccountability))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:enables ai:WhistleblowerProtection))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:enables ai:TrainingDataDisclosure))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:enables ai:CriticalHarmPrevention))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:supports ai:FrontierModelSafety))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:supports ai:ConsumerPrivacyInAI))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:supports ai:OpenSourceAISafety))

    ## Implementation Relationships
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:implements ai:RiskBasedGovernance))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:implements ai:TransparencyMandate))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:implements ai:PreDeploymentSafetyChecks))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:implements ai:CivilLiabilityFramework))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:implements ai:IncidentReportingObligation))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:uses ai:FLOPThreshold))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:uses ai:CatastrophicRiskAssessment))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:uses ai:ThirdPartySafetyAudit))

    ## Reduction Relationships
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:reduces ai:CatastrophicAIRisk))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:reduces ai:RegulatoryInformationAsymmetry))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:reduces ai:AIOpacity))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:contrasts ai:VoluntaryAICommitments))
    SubClassOf(ai:CaliforniaAIBill
      ObjectSomeValuesFrom(ai:contrasts ai:FederalPreemptionRegime))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(ai:hasIdentifier ai:CaliforniaAIBill "AI-2047"^^xsd:string)
    DataPropertyAssertion(ai:authorityScore ai:CaliforniaAIBill "0.87"^^xsd:decimal)
    DataPropertyAssertion(ai:computeThresholdFLOPs ai:CaliforniaAIBill "1e26"^^xsd:double)
    DataPropertyAssertion(ai:trainingCostThreshold ai:CaliforniaAIBill "100000000"^^xsd:integer)
    DataPropertyAssertion(ai:maxCivilPenalty ai:CaliforniaAIBill "1000000"^^xsd:integer)
    DataPropertyAssertion(ai:revenueThreshold ai:CaliforniaAIBill "500000000"^^xsd:integer)
    DataPropertyAssertion(ai:incidentReportingDays ai:CaliforniaAIBill "15"^^xsd:integer)
    DataPropertyAssertion(ai:emergencyReportingHours ai:CaliforniaAIBill "24"^^xsd:integer)
    DataPropertyAssertion(ai:legislativeYear ai:CaliforniaAIBill "2024"^^xsd:integer)

### About

- California AI bill designates the legislative sequence through which California has attempted — with varying success — to impose enforceable safety, transparency, and accountability obligations on the developers of the most powerful [[Frontier Models]].
- The arc runs from ambitious pre-training mandates (SB 1047, vetoed 2024) through narrower disclosure-and-reporting requirements (SB 53, signed 2025, effective 2026), accompanied by complementary training-data and privacy-related bills that collectively form the most comprehensive sub-national AI governance corpus in the United States.
- The legislative sequence reflects a learning process: SB 1047's veto identified three structural problems (context-agnostic scope, kill-switch infeasibility for open models, small-model gap) and SB 53's design directly addressed all three by narrowing scope to disclosures, removing the kill-switch requirement, and applying a dual revenue+compute threshold.
- The regulatory strategy reflects a fundamental tension in [[AI Regulation]] between innovation facilitation and catastrophic harm prevention — encoded in the divergent positions of industry incumbents (opposed, citing compliance burden and preemption concerns), safety researchers (supportive, citing existential risk and lack of federal action), and elected officials navigating both constituencies.
- California's unique position as both the jurisdiction where frontier AI is primarily developed (San Francisco Bay Area containing OpenAI, Anthropic, Google DeepMind, Meta AI, xAI, Mistral AI US operations) and the world's fifth-largest economy (GDP ~$4 trillion) makes it the most consequential sub-national AI regulator globally.
- The California bills have served as a proxy battleground for the federal preemption debate: whether the US federal government can or should supersede state AI laws to prevent a 50-state compliance patchwork.
- President Trump's December 2025 executive order establishing a national AI policy framework and directing the DOJ to challenge inconsistent state laws raised constitutional stakes. Legal experts assess preemption challenges to SB 53's transparency requirements as unlikely to succeed, since the law regulates commercial disclosures rather than product design in interstate commerce.
- Governor Newsom's March 2026 executive order on AI procurement further entrenched California's position while exploiting the federal executive order's explicit carve-out for state procurement activities, demonstrating that regulatory strategy can be designed to minimise preemption exposure.
- The California effect — by which California's regulatory standards diffuse nationally and internationally because multi-state companies prefer a single compliance standard — is operating in AI as in prior technology cycles (vehicle emissions, consumer privacy, chemicals disclosure).
- The SB 1047 / SB 53 arc has been extensively documented in both legal practice and academic literature as the most consequential sub-national AI regulatory episode in history — influencing regulatory design in the UK, Canada, Australia, and EU GPAI Code of Practice implementation.
- Compliance with SB 53 for large frontier developers:
  - Estimated initial implementation cost: $500K–$2M for large organisations (primarily legal and governance costs, per Nelson Mullins and WilmerHale assessments).
  - Ongoing annual update costs: $200K–$500K per year.
  - Modest relative to covered companies' frontier development budgets: OpenAI's 2025 operating expenses exceeded $5 billion; Google DeepMind's annual AI research budget exceeds $2 billion.
  - Compliance cost structure: legal counsel to draft Frontier AI Framework (50–200 attorney hours); internal AI safety team documentation of risk assessment methodology; cybersecurity team documentation of model weight protection practices; annual review governance process.
- The debate over California AI bills has produced what may be the most detailed public record of frontier AI risk assessment in existence.
- The legislative hearings, industry submissions, academic analyses, and advocacy materials from SB 1047's legislative cycle constitute an invaluable repository of technical and policy thinking about AI safety governance that will inform future regulatory efforts globally.
- **Key legislative milestones:**
  - February 2024: SB 1047 introduced by Senator Wiener.
  - March–August 2024: SB 1047 amended 12 times in response to industry and academic engagement.
  - August 2024: SB 1047 passes Assembly and Senate; 100+ AI employee letter endorsing bill published.
  - September 28, 2024: Governor Newsom signs AB 2013, AB 1008, and 17 other AI bills.
  - September 29, 2024: Newsom vetoes SB 1047.
  - October 2024: Post-veto analysis published; Newsom commissions frontier AI advisory council.
  - 2025 legislative session: SB 53 drafted and introduced as SB 1047 successor.
  - September 29, 2025: Newsom signs SB 53.
  - December 11, 2025: Trump executive order on national AI policy framework and state preemption.
  - January 1, 2026: SB 53 and AB 2013 take effect.
  - March 30, 2026: Newsom executive order N-5-26 on AI procurement.
  - August 2026: SB 942/AB 853 AI Transparency Act takes effect.
- **SB 1047 vs SB 53 — structural comparison:**
  - Scope trigger: SB 1047 — $100M training cost AND 10^26 FLOPs; SB 53 — 10^26 FLOPs AND $500M annual revenue.
  - Obligation type: SB 1047 — pre-training safety protocol, kill-switch, third-party evaluation; SB 53 — annual transparency disclosure, incident reporting, whistleblower channel.
  - Enforcement: SB 1047 — AG plus private right of action (negligence); SB 53 — AG civil actions only, no private right.
  - Open-source compatibility: SB 1047 — incompatible (kill-switch requirement); SB 53 — compatible (no technical control required).
  - Cloud provider obligations: SB 1047 — yes (verify customer compliance); SB 53 — no.
  - Institutional design: SB 1047 — new Frontier Model Division (regulatory capture risk); SB 53 — AG enforcement (existing institutional capacity).
  - Legislative outcome: SB 1047 — vetoed 29 September 2024; SB 53 — signed 29 September 2025.
  - Compliance cost: SB 1047 estimated $10M–$50M+ per developer (evaluation, protocol, compliance infrastructure); SB 53 estimated $500K–$2M (documentation and governance).
  - International analogue: SB 1047 — pharmaceutical pre-market approval paradigm; SB 53 — securities disclosure + EU GPAI Code of Practice paradigm.

### Components / Architecture

- **SB 1047 (Vetoed 2024) — Scope and Structure**
  - Covered models: training cost >$100M, training compute >10^26 FLOPs, plus fine-tuned derivatives ($10M+, >3×10^25 FLOPs).
  - Fine-tuned model coverage: a fine-tune of a covered model costing >$10M and using >3×10^25 FLOPs is itself a covered model, extending obligations to downstream derivative systems.
  - Pre-training obligations: documented safety protocol, kill-switch installation, third-party safety evaluation, CBRN and cyberattack risk assessment.
  - The safety and security protocol required: written articulation of foreseeable catastrophic harm scenarios; planned mitigation measures for each scenario; internal audit procedures; incident response playbook; and a process for post-incident review and public disclosure.
  - The kill-switch mandate: developers must implement technical capability to promptly enact a full shutdown of the covered model and all derivative models — a requirement that proved structurally incompatible with open-weight release.
  - Third-party safety evaluation: required independent evaluation for CBRN uplift risk (can the model meaningfully assist in synthesising chemical, biological, radiological, or nuclear weapons beyond publicly available knowledge?), autonomous cyberattack potential, and mass-casualty event facilitation.
  - Pre-deployment obligations: Statement of Compliance submitted to California Attorney General before any public release.
  - The Statement of Compliance required affirmation that: the developer had implemented a safety and security protocol; conducted third-party evaluation; taken reasonable care to prevent unreasonable risk of critical harms; and maintained kill-switch capability.
  - Cloud provider obligations: hyperscalers providing training compute required to verify customer compliance documentation — effectively pulling Google Cloud, AWS, Azure, and Oracle Cloud into the regulatory chain as co-regulators.
  - Post-deployment liability: "reasonable care" negligence standard for critical harms — CBRN weapons, $500M+ cyberattacks, mass-casualty autonomous crimes.
  - Critical harm categories defined: (1) creation/facilitation of a CBRN weapon capable of mass casualties; (2) cyberattack on critical infrastructure causing >$500M damage or mass casualties; (3) autonomous crime causing >$500M damage or mass casualties; (4) other events causing mass casualties.
  - Institutional design: Frontier Model Division within California Department of Technology, funded through fines — structurally vulnerable to [[Regulatory Capture]] as it creates financial dependence on the industry regulated.
  - Frontier Model Division authority: could modify key parameters including the FLOP threshold for covered models and specific safety standards — creating flexibility vulnerable to incumbent lobbying.
  - Legislative timeline: introduced 7 February 2024, passed both chambers August 2024, vetoed 29 September 2024.
  - Sponsor: State Senator Scott Wiener, SD-11, San Francisco.
- **SB 53 (Signed 2025) — Scope and Structure**
  - Official title: Transparency in Frontier Artificial Intelligence Act (TFAIA).
  - Scope: large frontier developers — annual gross revenues >$500M developing 10^26+ FLOP models.
  - Revenue threshold rationale: $500M revenue identifies established commercial-scale organisations with resources to implement compliance obligations; startups and open-source developers below this threshold are exempt.
  - Applies to: OpenAI, Anthropic, Google DeepMind, Meta AI, and any qualifying entity regardless of corporate domicile — extraterritorial reach mirrors CCPA and GDPR principles.
  - Does not apply to: model deployers, downstream users, open-source re-trainers below the revenue threshold, model-as-a-service customers, or fine-tuners who did not train the original foundation model.
  - Core instrument: Frontier AI Framework — public disclosure of risk assessment methodology, catastrophic risk mitigation, cybersecurity practices, internal AI governance controls, alignment with NIST AI RMF and ISO/IEC 42001.
  - Incident reporting to CalOES: within 15 days of developer awareness; within 24 hours if there is imminent risk of death or serious physical injury.
  - Covered incident categories: AI-enabled cyberattacks on critical infrastructure; AI-enabled mass-casualty crimes; deceptive AI behaviour undermining its own safety controls; AI-autonomous actions outside intended parameters causing substantial harm.
  - Incident reporting scope explicitly exceeds EU AI Act: SB 53 covers AI-autonomous crime and deceptive AI self-undermining — categories the EU AI Act does not address.
  - Whistleblower mechanism: anonymous internal channel at the developer, mandatory response process, monthly status updates for reporting employees covering investigation progress and actions taken.
  - Public incident reporting pathway: members of the public (not only employees) may also submit potential critical safety incident reports to CalOES.
  - Enforcement: California Attorney General civil actions only; no private right of action; penalties do not flow to a division funded by fines (avoiding SB 1047 regulatory-capture structure).
  - Civil penalty: up to $1 million per violation, each failure constituting a separate violation.
  - Effective: 1 January 2026.
  - Sponsor: Senator Scott Wiener; signed 29 September 2025.
- **AB 2013 (Signed 2024) — Training Data Transparency**
  - Official title: Generative Artificial Intelligence Training Data Transparency Act.
  - Signed: 28 September 2024. Effective: 1 January 2026.
  - Scope: any entity — individuals, corporations, or government agencies — designing, coding, producing, or substantially modifying a generative AI system for public use by Californians, from January 2022 onward.
  - Retroactive coverage: applies to systems made available to Californians since January 2022, not only new systems deployed after the effective date.
  - Required disclosures: training data sources and owners; licensing or purchase status of each dataset; description of how datasets serve the AI's intended purpose; data collection time window; cleaning, processing, or modification methods applied.
  - Intellectual property disclosures: whether training data includes copyrighted, trademarked, or patented material (with licensing details); whether data is in the public domain; whether the system incorporates Creative Commons-licensed content.
  - Privacy disclosure: whether training data includes personal information as defined under CCPA.
  - Synthetic data disclosure: whether the system used or continuously uses synthetic data generation during development.
  - Format: publicly posted website documentation before making systems available to Californians, updated before each substantial modification released on or after January 2022.
  - Exemptions: security-only AI systems (detecting security incidents); aircraft navigation systems in national airspace; national security, military, or defence systems available exclusively to federal entities.
  - Enforcement: Attorney General civil actions; each separate omission constitutes a separate violation.
  - Practical challenge: many large-scale AI systems trained on internet-scraped corpora cannot enumerate individual data sources with the specificity the statute implies — creating compliance uncertainty analogous to early GDPR implementation gaps.
- **AB 1008 (Signed 2024) — CCPA Extension to AI Outputs**
  - Revises CCPA definition of "personal information" to include abstract digital formats — model weights, tokens, embeddings, other outputs derived from consumer data capable of outputting individually linked information.
  - Conditioned on simultaneous enactment of SB 1223 (a companion data-collection clarification bill).
  - Effective: 1 January 2025.
  - Practical impact: generative AI systems trained on Californians' personal data must honour CCPA access, deletion, and opt-out rights even where the personal information exists only in parameterised form.
- **Frontier AI Framework (SB 53 core instrument)**
  - Required content elements: identification of national standards incorporated (NIST AI RMF, NIST SP 800-series cybersecurity); identification of international standards incorporated (ISO/IEC 42001 AI Management Systems, ISO/IEC 23894 AI Risk Management); description of industry consensus practices incorporated; methodology for identifying catastrophic risks; risk mitigation measures deployed; cybersecurity practices protecting model weights and training infrastructure; internal AI governance structure (board oversight, safety review processes, escalation procedures).
  - The framework must explain — not merely assert — how standards are incorporated: a general reference to "NIST AI RMF" without describing how the RMF's four functions (GOVERN, MAP, MEASURE, MANAGE) are applied to specific catastrophic risk categories is unlikely to satisfy SB 53's "describing how" requirement.
  - Must be reviewed and updated at least annually, with material changes published promptly.
  - Annual review obligations: developers must affirmatively assess whether their risk identification methodology remains current given: (a) new model capabilities identified through red-teaming or evaluation; (b) new threat models identified in the safety research literature; (c) new standards or industry practices incorporated into NIST, ISO, or industry consensus bodies.
  - Conceptually parallel to EU AI Act system cards for GPAI models (Article 53(1)(a) EU AI Act), NIST AI RMF organisational profiles, and voluntary AI safety commitments made to the Biden White House in 2023 (Responsible AI Commitment) and the Bletchley Declaration's Frontier AI Safety Commitments.
  - Compliance responses from large frontier developers as of May 2026 have largely cross-referenced pre-existing voluntary frameworks (Anthropic Responsible Scaling Policy, OpenAI Preparedness Framework, Google DeepMind Frontier Safety Framework, Meta AI Safety Policy) rather than generating materially novel disclosures — raising the question of whether SB 53 adds meaningful new information or merely codifies existing voluntary disclosure as a legal obligation.
  - The AG's forthcoming guidance on what constitutes an adequate Frontier AI Framework will determine whether the compliance standard is substantive (requiring genuine risk analysis beyond policy documents) or formal (accepting any reasonably detailed reference to existing frameworks).
- **Critical Safety Incident Reporting (SB 53 instrument)**
  - Covered incident categories: AI-enabled cyberattack on critical infrastructure; AI-enabled crime causing mass casualties or substantial damage; deceptive AI behaviour designed to undermine its own safety controls; AI-autonomous actions outside intended operational parameters causing substantial harm.
  - Reporting timeline: 15 days from developer awareness; 24 hours if imminent risk of death or serious physical injury.
  - Reports submitted to: California Governor's Office of Emergency Services (CalOES).
  - Public reporting pathway also established, enabling third-party incident submission to CalOES.
  - Exceeds EU AI Act's incident-reporting scope: SB 53 explicitly covers AI-autonomous crime and deceptive AI self-undermining, categories the EU AI Act does not address.
- **Whistleblower Protection Mechanism (SB 53 instrument)**
  - Standing: covered employees at large frontier developers who believe in good faith that the developer's activities present a specific and substantial danger to public health or safety through catastrophic risk or TFAIA violation.
  - Process: developer must provide a reasonable anonymous internal channel for filing reports. Cannot require employees to use real name.
  - Response obligation: developer must investigate and provide monthly status updates to the reporting employee on investigation progress and actions taken.
  - Retaliation prohibition: Attorney General may bring civil actions for retaliatory dismissal, demotion, or suppression.
  - Design analogous to Dodd-Frank Section 21F financial whistleblower regime and EPA/OSHA environmental whistleblower protections.

### Use Cases / Major Families

- **Pre-Deployment Safety Assurance (SB 1047 paradigm)**
  - The SB 1047 model placed compliance obligations at training inception and again at deployment decision, analogous to pharmaceutical pre-market approval or nuclear plant licensing.
  - Covered developers would have been required to certify that a model posed no "unreasonable risk" of critical harm before release — a standard borrowed from products liability but novel in software regulation.
  - The pharmaceutical analogy: the FDA requires preclinical safety data, Phase I–III clinical trials, and a pre-market approval submission before any drug reaches patients. SB 1047 would have established an analogous preclearance regime for frontier AI, with the key difference that FDA has decades of scientific precedent while AI safety evaluation methodology is still nascent.
  - The nuclear licensing analogy: nuclear power plants require NRC licensing before operation, with ongoing safety requirements, shutdown authority, and liability frameworks. SB 1047's kill-switch and liability provisions echo nuclear licensing philosophy applied to software systems.
  - The paradigm resonated with AI safety researchers who draw analogies between frontier model release and pharmaceutical deployment: both involve complex systems with unknown emergent risks, both require safety testing before public access, and both generate externalities not fully internalised by developers or initial users.
  - The kill-switch requirement was particularly significant conceptually: it obligated developers to retain technical capability to halt a model and all its derivatives, a provision critics argued was technically infeasible for open-weight models (Meta Llama, Mistral, Falcon, Phi) once publicly released to download.
  - Kill-switch technical feasibility for closed models: for API-gated proprietary models (GPT-4, Claude, Gemini), a kill-switch is operationally trivial — the developer controls all access points. The controversy was specifically about open-weight models where access is not mediated through the developer's infrastructure.
  - The CBRN focus was directly informed by AI safety research on dual-use uplift — the risk that frontier AI systems could provide meaningful assistance in synthesising biological or chemical weapons to actors who would otherwise lack the necessary knowledge.
  - The RAND Corporation, Johns Hopkins Center for Health Security, and the Gryphon Scientific organisation published research in 2023–2024 documenting real, if bounded, uplift of frontier models in bioweapon synthesis scenario studies — research that directly informed SB 1047's critical harm definitions.
  - The "reasonable care" negligence standard was deliberately chosen over strict liability to avoid creating a standard so burdensome as to make frontier AI development legally untenable, while still providing a basis for liability where developers clearly failed to take available precautions.
- **Transparency and Disclosure (SB 53 / AB 2013 paradigm)**
  - The post-veto legislative strategy pivoted to transparency mandates: requiring developers to publish standardised information rather than pre-certify safety. This avoids the kill-switch problem and creates a lighter compliance burden compatible with open-source development models.
  - The Frontier AI Framework draws on established securities-disclosure analogy: listed companies must disclose material risks to investors under Regulation S-K; frontier AI developers must disclose risk assessment and mitigation approaches to the public and regulators. The securities analogy has precedent in environmental regulation (SEC climate disclosure rules) and pharmaceutical post-marketing (FDA REMS disclosure requirements).
  - AB 2013's training-data disclosure requirements parallel food-labelling obligations — a disclosure-based intervention that does not restrict content but enables informed evaluation by users, researchers, regulators, and copyright owners.
  - Disclosure-based regulation accepts that it cannot prevent harm directly; it relies on market discipline (reputational pressure on developers publishing inadequate frameworks), shareholder and investor scrutiny, regulatory follow-on (future legislation using disclosed information to identify gaps), and litigation discovery (disclosed frameworks may be used as evidence in civil actions).
  - Critics of disclosure-based approaches argue the analogy is imperfect: securities disclosure works because investors have financial incentives to scrutinise disclosures and act on them; the public-safety equivalent of that scrutiny (who evaluates whether a Frontier AI Framework is adequate?) depends on NGOs, academics, and regulators that may lack capacity and technical expertise.
  - The SB 53 disclosure regime is better characterised as setting up infrastructure for future regulation: the Frontier AI Frameworks, once published and subjected to expert scrutiny over several years, may reveal systematic gaps that inform more targeted legislative requirements.
  - AB 2013 faces significant implementation challenges for models trained on large internet-scraped corpora (Common Crawl, The Pile, LAION-5B): these datasets contain billions of web pages without clear individual source attribution, making comprehensive data-source documentation practically impossible at the granularity implied by the statute. Guidance from the California Attorney General on acceptable summary-level disclosure is expected during 2026.
- **Consumer Privacy Extension (AB 1008 paradigm)**
  - Applying CCPA to AI model weights and embeddings addresses a gap in existing privacy law: personal data extracted and distilled into model parameters during training may not be covered by consumer access and deletion rights under a literal reading of earlier privacy statutes.
  - AB 1008 resolves this by treating the model itself as a personal information repository when trained on consumer data and retaining capacity to output individually linked information.
  - Aligns California with emerging interpretations of the EU [[GDPR]] applied to generative AI training pipelines — where EU data protection authorities (including the Italian Garante, French CNIL, and UK ICO) have required AI developers to document legal bases for training data use and provide data subject access mechanisms.
  - Creates compliance complexity for models trained on large, heterogeneous web-scraped corpora where individual data subjects are indeterminate.
- **Healthcare AI Guardrail (AB 489 paradigm)**
  - Prohibiting AI from impersonating licensed clinicians reflects sector-specific harm risk: patients relying on AI-generated clinical advice without knowing they lack human oversight may make health decisions with life-affecting consequences.
  - Mirrors FTC's existing rules on endorsement deception and extends them to AI-specific impersonation — consistent with FTC's 2023 AI and Dark Patterns enforcement guidance.
  - Creates a concrete, context-specific prohibition without requiring general safety certification of the underlying model, avoiding the breadth problems of SB 1047.
- **Open Source Tension**
  - SB 1047's liability-for-derivatives regime created acute structural tension with the open-source AI community.
  - Developers of openly released weights (Mistral 7B/8×7B, Meta Llama 2/3 series, EleutherAI's Pythia, TII Falcon 180B, Microsoft Phi-2/Phi-3) argued that once a model is publicly released, the original developer cannot control downstream fine-tunes, quantisations, or deployments, yet SB 1047 would have maintained developer liability for harms caused by modifications it could not technically prevent.
  - The AI Alliance (IBM, Meta, and 50+ organisations) formally opposed SB 1047 on these grounds, as did the Open Source Initiative. Their argument: requiring a kill-switch for an open-source model is technically equivalent to requiring the author of a book to recall all copies ever printed.
  - SB 53's transparency-only approach avoids this structural conflict entirely: disclosure obligations do not require technical control over derivative copies, and the revenue threshold (>$500M) exempts virtually all small open-source developers from compliance.
  - The revenue threshold creates an implicit open-source safe harbour: organisations like EleutherAI (non-profit), Mistral AI (at its 2024 revenue scale), and individual researchers releasing model weights are excluded regardless of model compute, because they do not meet the $500M annual revenue criterion.
  - The boundary between "open source" and "proprietary" in AI is contested: Meta's Llama models are released under a community licence with restrictions — not OSI-certified open source. This ambiguous category was not cleanly resolved by either SB 1047 or SB 53.
- **Compute Governance and Threshold Design**
  - Both SB 1047 and SB 53 use the 10^26 FLOP threshold, derived from the October 2023 Biden White House Executive Order on Safe, Secure, and Trustworthy AI. This threshold was calibrated to identify "frontier" as of 2023–2024 (GPT-4 estimated at ~10^24–10^25 FLOPs; Gemini Ultra and Claude 3 Opus estimated to approach or exceed 10^26).
  - The SB 53 threshold explicitly mirrors the Biden EO threshold, creating potential for automatic regulatory updating if the federal executive order threshold changes — though the Trump administration's December 2025 EO did not revise the compute threshold benchmark.
  - Academic critics (Narayanan and Kapoor, Princeton "AI Snake Oil" project) argued that FLOPs are a poor proxy for capability or dangerousness because: (a) efficiency improvements allow more capable models to be trained at lower compute; (b) the threshold conflates training scale with deployment risk; (c) a small specialised model trained for malicious purposes could cause greater harm than a large general-purpose model at 10^27 FLOPs.
  - Defenders of the threshold (including AI safety researchers at the Center for AI Safety, Anthropic, and Google DeepMind) argued that some bright-line trigger is necessary for a workable regulatory definition even if it is imperfect, and that 10^26 correctly identifies the highest-risk development tier in 2024.
  - Scaling laws as empirical basis: Kaplan et al. (OpenAI, 2020) demonstrated that model capability (measured by perplexity and downstream task performance) follows predictable power-law scaling with training compute. Hoffmann et al. (DeepMind, 2022 Chinchilla) refined this to show optimal compute allocation between model size and training tokens. These empirical relationships support the use of compute as a capability proxy, though they apply to pre-training of transformer language models and may not generalise to other architectures or training objectives.
  - The dual SB 53 criterion (10^26 FLOPs AND >$500M revenue) partially addresses the "small dangerous model" criticism: even if a malicious actor trained a dangerous specialised model at 10^26 FLOPs, they would need $500M+ annual revenue to be caught by SB 53 — effectively excluding state-level threat actors and most non-state adversaries from the regulatory scope, though this is arguably appropriate since such actors are beyond California's jurisdictional reach regardless.
  - International compute governance: the 10^26 FLOP threshold has been adopted not only by California and the 2023 Biden EO but also referenced in the UK AISI's frontier model evaluation criteria, the G7 Hiroshima AI Process, and the Bletchley Declaration on frontier AI safety. Its widespread adoption suggests that, whatever its technical imperfections, it has become the de facto international coordination point for frontier AI regulatory scope.
  - The threshold is expected to require revision by 2027–2028 as algorithmic efficiency improvements lower the cost per FLOP and more developers approach the frontier compute scale — though the SB 53 revenue threshold may prove a more durable regulatory scope criterion than the FLOP threshold since revenue scales with commercial deployment scale rather than purely technical efficiency.

### Academic Context

- **Legal scholarship:**
  - The California AI legislative arc has generated substantial scholarly engagement across constitutional law, torts, administrative law, and comparative regulatory studies.
  - Stanford CodeX, Berkeley Law, and UCLA School of Law have debated whether the California model constitutes a legitimate exercise of state police power or an unconstitutional regulation of interstate commerce.
  - Kevin Werbach (Wharton, "SB 53: What California's New AI Safety Law Means for Developers," 2025) argues that disclosure-based AI regulation occupies safer constitutional ground than pre-market approval mandates — because the latter directly affect product design in interstate commerce while the former impose affirmative disclosure obligations with only indirect effect on product characteristics.
  - Ryan Calo (University of Washington Law) has developed the "AI as information" framework: AI disclosures (training data, risk frameworks) are analogous to commercial speech and mandatory labelling, which the First Amendment doctrine permits states to require as long as they are factual and non-misleading.
  - The preemption debate is structurally analogous to California vehicle emissions standards under Clean Air Act Section 209: California has historically sought EPA waivers from federal preemption for stricter state vehicle emissions standards, and courts have upheld these waivers repeatedly — suggesting a template for state AI regulation to coexist with federal frameworks.
  - Administrative law scholars have noted that the proposed SB 1047 Frontier Model Division would have been among the first AI-specific agencies in US history, raising questions about non-delegation doctrine (can the legislature grant a division authority to modify computational thresholds?) and procedural due process (do covered entities have adequate notice and opportunity to comment on threshold changes?).
- **AI safety research divide:**
  - The legislative debate crystallised an existing academic disagreement between researchers assessing frontier model catastrophic risks as near-term and tractable versus those assessing current models as too weak to warrant SB 1047-class regulation.
  - Bill supporters: Dan Hendrycks (Center for AI Safety, MATS — Machine Learning for Alignment Theory Scholars); Stuart Russell (Berkeley, author of "Human Compatible: Artificial Intelligence and the Problem of Control," 2019); Geoffrey Hinton (formerly Google Brain, 2024 Nobel Prize in Physics for neural network foundational work); Yoshua Bengio (Mila, 2024 Nobel Prize in Physics, co-recipient with Hinton).
  - Hinton public statement: "It's critical that we have legislation with real teeth to address the risks. California is a natural place for that to start, as it is the place this technology has taken off."
  - Bengio's position: the potential benefits of SB 1047 in signalling regulatory seriousness and stimulating safety culture development outweighed the costs of compliance burden, particularly given the gap between voluntary commitments and demonstrated safety assurance methodology.
  - Bill opponents: Yann LeCun (Meta chief AI scientist) argued that current LLMs are "not even close" to general intelligence or catastrophic capability and that SB 1047 would hamper research into safer AI architectures; Timnit Gebru (DAIR Institute) argued that existential risk framing distracts from immediate harms of AI bias, exploitation, and surveillance affecting marginalised communities today.
  - Y Combinator and most venture-backed AI startup founders opposed the bill on commercial grounds: compliance costs and liability exposure would create barriers to entry favouring large incumbents, effectively cartellising the frontier AI market.
- **Compute threshold critique:**
  - Arvind Narayanan and Sayash Kapoor (Princeton, AI Snake Oil, 2024) argued that 10^26 FLOPs is an arbitrary line disconnected from demonstrated capability, conflating training compute scale with deployment dangerousness.
  - Their critique: (a) GPT-3's 10^23-FLOP training produced a model capable of generating persuasive disinformation and assisting in phishing attacks — harms that occur far below the 10^26 threshold; (b) FLOP thresholds create bright-line incentives that developers can game by using alternative architectures (mixture-of-experts, neural architecture search) that achieve similar capability at lower raw FLOP counts; (c) the relevant risk metric is deployed capability and alignment, not training compute.
  - Defenders of threshold (Anthropic's Responsible Scaling Policy, DeepMind's Frontier Safety Framework): some bright-line trigger is necessary for a workable regulatory definition even if imperfect. Compute correlates more directly with emergent capability in empirical scaling-law research (Kaplan et al. 2020, Hoffmann et al. 2022 Chinchilla) than any available alternative proxy. The alternative — case-by-case capability assessment — would require regulatory agencies to conduct ongoing AI safety evaluations they do not currently have the capacity or methodology to perform.
- **Torts and liability design:**
  - Woodrow Hartzog (Boston University Law) noted that SB 1047's "reasonable care" negligence standard for catastrophic harm would have created the first US statutory basis for AI developer liability in product design.
  - The analogous doctrine is drug manufacturer duty-of-care under the Restatement (Third) of Torts: Products Liability — where manufacturers face liability if they fail to take reasonable precautions against foreseeable risks of their products.
  - The "reasonable care" standard was considered less restrictive than strict liability (which would apply regardless of fault) but would have resolved existing doctrinal ambiguity in AI injury litigation, where courts have struggled to fit AI harms into existing product liability, negligence, or warranty frameworks.
  - Gary Marcus (NYU) endorsed liability provisions as a mechanism to internalise development externalities that voluntary commitments demonstrably fail to internalise — citing the 2023 AI company safety commitments to the Biden White House as demonstrating the limits of self-certification absent binding obligations.
  - The Restatement (Third) of Torts § 2 (2) design defect standard — whether the foreseeable risks of harm from the product could have been reduced by a reasonable alternative design — is already being tested in early AI liability cases (Netchoice, Doe v. GitHub, Ouellette v. Stability AI) though without a statutory basis, creating incentive for a legislative clarification such as SB 1047 proposed.
- **Political economy and industry split:**
  - SB 1047 exposed an unusual intra-industry split not previously observed at this scale in tech policy.
  - Industry opponents: OpenAI, Google, Meta, the Consumer Technology Association, Chamber of Progress, Computer & Communications Industry Association, and the Y Combinator startup portfolio.
  - Venture capital lobbying: Marc Andreessen (a16z) wrote a widely circulated manifesto opposing SB 1047; Y Combinator president Garry Tan organised Silicon Valley opposition and retained advisors with close ties to Governor Newsom for lobbying purposes.
  - Employee opposition to employers: more than 100 current and former employees of AI companies opposing the bill — including 36 from OpenAI, DeepMind, and Meta specifically — signed a public letter endorsing SB 1047 and urging Newsom to sign it.
  - The letter-signing employees represented AI safety and alignment researchers, engineers working on red-teaming and evaluation, and policy staff — the technical safety function within companies that publicly opposed the bill.
  - Anthropic's intermediate position: CEO Dario Amodei publicly stated: "The new SB 1047 is substantially improved, to the point where we believe its benefits likely outweigh its costs. However, we are not certain of this, and there are still some aspects of the bill which seem concerning or ambiguous to us." This represented the only major frontier AI lab to express qualified support rather than outright opposition.
  - AI pioneer support: both Geoffrey Hinton and Yoshua Bengio — the two most-cited AI researchers globally and 2024 Nobel laureates in Physics for their foundational work on neural networks — publicly endorsed SB 1047, giving the bill academic credibility that industry opponents struggled to rebut.
  - Elon Musk supported the bill, creating an atypical political coalition between AI safety researchers (who align with progressive tech regulation) and tech-sceptic conservatives (who distrust large AI companies), united only by their view that frontier AI poses genuine risks requiring regulatory response.

### Current Landscape (2026)

- **Legislation in force as of May 2026:**
  - SB 53 / TFAIA: in force since 1 January 2026. Large frontier developers have published initial Frontier AI Frameworks. Compliance quality varies: early frameworks largely cross-reference pre-existing voluntary commitments (Anthropic Responsible Scaling Policy, OpenAI Preparedness Framework, Google DeepMind Frontier Safety Framework, Meta AI Safety Policy) rather than producing materially new disclosures, reflecting that the frameworks pre-existed the SB 53 obligation.
  - SB 53 enforcement: as of May 2026, the California Attorney General has not brought any civil enforcement actions under SB 53. The Attorney General's office is reported to be developing internal guidance on what constitutes an adequate Frontier AI Framework — a determination that will shape compliance expectations.
  - AB 2013: in force since 1 January 2026. Training data documentation obligations apply to generative AI developers with California-facing products as far back as January 2022. First compliance wave covers existing deployed systems; early industry response has been summary-level documentation rather than granular dataset enumeration.
  - AB 1008: in force since 1 January 2025. CCPA rights extended to AI model outputs derived from consumer data. Impact felt most directly in CCPA data subject access requests that now reach AI model parameters, though technical implementation of "deletion from model weights" remains legally and technically unresolved.
  - Machine unlearning as AB 1008 compliance mechanism: research on machine unlearning (SISA training, gradient-based unlearning, selective forgetting techniques) is advancing but no production-ready method achieves deletion of individual data points from large language models without retraining — meaning full AB 1008 compliance may currently be unachievable in a strict technical sense. The AG is expected to adopt a "reasonable effort" standard analogous to the GDPR right to erasure's "technical infeasibility" exception.
  - SB 942 / AB 853: AI Transparency Act for large platforms effective August 2026. Watermarking and AI-content detection requirements are generating industry compliance investments through the first half of 2026.
  - AB 489: Healthcare AI Act effective 2026. FTC alignment means federal and state prohibitions on AI clinical impersonation are now concurrent.
- **Federal-state tension (2025–2026):**
  - President Trump's Executive Order on National AI Policy Framework (11 December 2025) directs the DOJ AI Litigation Task Force to challenge state AI laws inconsistent with the order's goal of "sustaining US AI dominance through a minimally burdensome national policy framework."
  - Executive order constitutional limits: the order itself cannot supersede state law; it can only direct DOJ to file suit. Courts then decide whether state AI laws are preempted by federal statutes (none currently enacted) or the Constitution (dormant Commerce Clause). Legal experts across the political spectrum assess these challenges as unlikely to succeed.
  - Dormant Commerce Clause argument: an untested but potentially viable federal argument is that California's AI laws unconstitutionally discriminate against interstate commerce or impose extraterritorial effects on AI development occurring predominantly outside California. This argument requires demonstrating that compliance obligations burden out-of-state commerce more than local — a showing complicated by the fact that all major frontier AI developers operate primarily in California.
  - California, Colorado, and New York governors issued joint statements in December 2025 confirming state enforcement will continue regardless of the executive order; state AGs in those states filed amicus briefs in related federal cases through early 2026.
  - California strategic response: Governor Newsom's March 2026 Executive Order N-5-26 requires AI vendors to California state agencies to meet new certification standards — exploiting the federal executive order's explicit carve-out for "state government procurement and use of AI," insulating California's procurement requirements from any preemption challenge.
  - White House National Policy Framework for AI (released March 2026): proposes preserving "state government procurement and use of AI" as a carve-out, effectively endorsing California's procurement strategy as compliant with the administration's approach even while challenging California's broadly applicable regulatory mandates.
- **State AI legislation landscape (2025–2026):**
  - Over 700 state AI bills introduced across the US in 2025 alone — the largest single-year volume of state AI legislation in US history.
  - Substantive AI legislation enacted or advancing: California (SB 53, AB 2013, AB 1008); Colorado (SB 205, AI systems disclosure, first to define AI system broadly); Texas (HB 4664, requiring AI incident reports and safety audits for high-risk AI); Illinois (GAIA Act, requiring algorithmic impact assessments); New York (proposed AI accountability laws covering both frontier and deployed AI).
  - Industry's compliance burden argument: a company offering AI services across the US faces obligations from 15+ states with divergent definitions of "high-risk AI," divergent disclosure timelines, and divergent enforcement mechanisms — characterised as "50 different AI frameworks" requiring per-state compliance tracking.
  - As of May 2026, no comprehensive federal AI bill has cleared committee in either chamber of Congress. The CREATE AI Act, the most bipartisan proposal, had 12 Senate co-sponsors but had not received a committee vote.
- **California Effect on global norms:**
  - SB 53's Frontier AI Framework requirement has directly influenced transparency discussions in: the UK (DSIT frontier AI framework consultations drawing on SB 53 language for risk-framework disclosure requirements); Canada (AIDA federal AI framework, which adopted analogous transparency disclosure obligations for high-impact AI systems); Australia (AI safety standards consultations by DISR incorporating incident-reporting timeline benchmarks); and the EU's GPAI Code of Practice implementation.
  - The "American Brussels Effect" — California setting de facto global compliance standards as multinational companies implement a single framework to serve its large market — is historically observed in: vehicle emissions standards (California LEV standards adopted by 17 states and influenced federal CAFE standards); consumer privacy (CCPA influenced 12 state privacy laws enacted 2021–2024 and elevated political pressure for a federal privacy framework); chemicals regulation (California Prop 65 disclosures adopted by manufacturers globally to avoid California-specific labelling).
  - AI is tracking the same pattern: OpenAI, Anthropic, and Google DeepMind have each published Frontier AI Frameworks that exceed SB 53's geographic scope, applying globally rather than only to California-facing operations, because maintaining California-only versions is operationally impractical.
  - The California effect implies that SB 53's 10^26 FLOP / $500M revenue threshold structure may become the de facto global definition of "frontier AI" for regulatory purposes — just as California's LEV emissions standards became the de facto US national standard.

### UK Context (Imperial / Edinburgh / UCL / Cambridge / Manchester academic; Northern English industrial)

- **Academic engagement:**
  - The Alan Turing Institute has published comparative analysis of SB 1047 and SB 53 relative to the EU AI Act's GPAI model provisions, noting that California's revenue+compute dual threshold creates a different covered entity population than the EU's FLOP-only threshold (10^25 FLOPs for systemic risk designation under the EU AI Act Article 51 versus SB 53's 10^26 FLOPs plus $500M revenue requirement).
  - The ATI analysis highlighted that the EU AI Act designates fewer than 10 models as "systemic risk" GPAI systems as of 2025, while SB 53's higher FLOP threshold but additional revenue criterion creates a similar coverage population — approximately the same 5–8 largest frontier AI developers globally.
  - The Centre for the Study of Existential Risk (CSER), Cambridge, contributed to international discussions on kill-switch feasibility and catastrophic harm definitions. Researchers including Seán Ó hÉigeartaigh and Haydn Belfield provided analysis to California legislative staff during the SB 1047 debate on the conceptual distinction between "shutdown" (stop current inference) and "containment" (prevent future harmful use) — two capabilities SB 1047 conflated in the kill-switch requirement.
  - CSER's contribution to the SB 1047 debate: arguing that the kill-switch requirement was technically achievable for closed-API models (trivially: revoke API access) but structurally impossible for open-weight models (technically: cannot enforce stopping inference on already-downloaded weights). This analysis directly informed Newsom's veto reasoning on open-source incompatibility.
  - Edinburgh's Bayes Centre and School of Informatics, through researchers including Charles Sutton and Amos Storkey, engaged with the liability frameworks through formal verification and probabilistic safety assurance of AI systems — an approach that provides theoretical grounding for the "reasonable care" negligence standard SB 1047 attempted to codify.
  - UCL's Centre for Artificial Intelligence, through work on EU AI Act implementation and the ICO's AI guidance development, contributed to comparative analysis of California's AB 2013 training-data transparency requirements relative to EU AI Act Article 53 GPAI transparency obligations — finding that AB 2013's retroactive application to January 2022 systems is more demanding than EU AI Act obligations that apply prospectively.
  - Imperial College London's AI faculty have published on compute governance through the lens of international governance frameworks, with researchers examining whether FLOP thresholds derived from scaling law research (Kaplan et al. 2020, Hoffmann et al. 2022 Chinchilla) remain valid as architectural innovations (mixture-of-experts, state-space models) decouple capability from total training compute.
  - Manchester's School of Computer Science and Alliance Manchester Business School have engaged with the economic regulation dimensions of California AI bills — including the market-concentration effects of imposing compliance costs that large incumbents can absorb but startups cannot, and whether the bills implicitly facilitate cartelisation of the frontier AI market.
- **UK regulatory divergence:**
  - The UK's choice not to pass a horizontal AI Act (opting instead for a pro-innovation, sector-regulator model under the AI Opportunities Action Plan 2025 and the DSIT AI Regulation guidance to existing regulators) creates regulatory divergence relative to California.
  - The UK's sector-regulator model distributes AI oversight across the FCA (financial services AI), ICO (data protection and AI), Ofcom (online platforms and AI-generated content), MHRA (medical AI), and CMA (AI competition concerns) — contrasting with California's concentration of frontier AI enforcement in the Attorney General's office.
  - UK AI developers seeking California market access must comply with SB 53's transparency obligations while operating under a domestic regime with no equivalent requirements — a compliance asymmetry the UK AI Safety Institute (rebranded AI Security Institute in 2024) has acknowledged may require bridging guidance.
  - UK-headquartered AI companies with US operations (Wayve, Graphcore, Stability AI, Waymo-affiliated entities, DeepMind's London arm as part of Google DeepMind) are subject to California obligations if their revenue exceeds $500M and they develop 10^26-FLOP+ models.
  - The UK AI Security Institute's State of the Science reports on frontier model evaluations — published in 2023 and 2024 — informed the scientific framing of "critical safety incidents" that SB 53 codifies, providing intellectual common ground despite regulatory divergence. The AISI evaluations of GPT-4, Claude, and Gemini using pre-deployment access agreements established a model that SB 53's incident-reporting requirements implicitly build upon.
  - Post-Brexit regulatory divergence: the UK's exclusion from the EU AI Act's directly applicable provisions means UK developers face potential triple compliance (UK sector-regulator guidance, EU AI Act for EU market access, California SB 53 for US market access) by 2026 — a compliance cost asymmetry that larger UK AI labs can absorb but that creates significant burden for mid-tier UK AI companies.
- **Northern England industrial exposure:**
  - Sheffield's manufacturing AI cluster (Sheffield Robotics, Advanced Manufacturing Research Centre, industrial machine vision deployments) and Manchester's data-economy ecosystem (Manchester Metropolitan's AI Research Group, Manchester Science Partnerships, AutoAI) interact with California legislation primarily through the supply chains of cloud AI providers.
  - Google Cloud, AWS, Azure, and Oracle Cloud are subject to SB 53's large frontier developer requirements in their own model development activities (PaLM/Gemini, Titan/Bedrock, Azure OpenAI, Oracle AI); their Sheffield and Manchester data centre operations are not directly regulated by SB 53 as customers of these providers.
  - UK-based AI startups with California-incorporated parent structures or selling into California markets face AB 2013's training data disclosure requirements as soon as they make generative AI systems available to California users — regardless of UK company size or revenue.
  - The Financial Conduct Authority's AI strategy (published November 2024) and the Prudential Regulation Authority's AI model risk guidance draw on the same catastrophic-risk framing that informed SB 1047, and UK financial regulators have noted California's 15-day / 24-hour incident-reporting timeline as a potential benchmark for UK AI incident notification standards under development through 2026.
  - Leeds Digital Festival and Manchester's thriving digital sector have hosted panels on California AI bill compliance — signalling that UK industry practitioners are engaging with the regulatory implications even absent equivalent UK legislation.
  - Newcastle's Sage Group and other Northern English enterprise software providers deploying AI features face AB 2013 training data disclosure obligations for generative AI features accessible to California-resident customers, requiring documentation of training datasets that may include licensed customer data.
  - Leeds's financial technology sector (Asda Money, Sky Betting and Gaming, Infinity Works) and Manchester's fintech hub (OakNorth, Starling Bank Manchester office) deploy AI systems for credit decisioning, fraud detection, and customer service — deployer-tier applications not directly subject to SB 53's frontier developer threshold but potentially subject to AB 2013 if they deploy generative AI features trained on proprietary datasets.
  - Scottish AI companies (Skyscanner, Fanduel, Administrate, Edinburgh's AI startups in financial compliance and drug discovery) engage with California legislation primarily through data governance requirements under AB 1008 when serving California-resident users, and through AB 2013 when using generative AI trained on user data.
  - The UK's AI Safety Institute (now AI Security Institute) international engagement programme includes bilateral information-sharing with the California Governor's Office on frontier AI evaluation methodologies, creating regulatory coordination channels that may facilitate future mutual recognition of Frontier AI Framework assessments between UK and California regulatory regimes.

### Future Directions (2026–2030)

- **Federal preemption resolution** — The central uncertainty for California AI legislation through 2030 is whether Congress enacts a federal AI statute that expressly preempts state law. Multiple federal bills have been introduced (CREATE AI Act, AI Advancement and Reliability Act, Responsible Artificial Intelligence Act) but none has passed. Any federal law enacted under the Trump administration's deregulatory AI posture would likely preempt California's requirements. A law passed under a future Democratic administration might instead establish a federal floor allowing more stringent state standards to persist — the pattern of Clean Air Act Section 209 (California vehicle emissions waiver).
- **Federal preemption resolution (2026–2030)**
  - The central uncertainty is whether Congress enacts a federal AI statute that expressly preempts state law. Multiple federal bills have been introduced (CREATE AI Act, AI Advancement and Reliability Act, Responsible Artificial Intelligence Act) but none has passed as of May 2026.
  - Federal preemption requires congressional action; a presidential executive order alone cannot supersede enacted state law. The DOJ AI Litigation Task Force established by the December 2025 executive order can challenge state laws in court but faces substantial constitutional obstacles.
  - Three preemption doctrines apply: (1) express preemption — requires explicit congressional language (absent from any enacted federal AI statute); (2) field preemption — federal regulation is so pervasive as to occupy the field (impossible absent any federal frontier AI statute); (3) conflict preemption — state law makes it impossible to comply with federal law (SB 53's transparency requirements impose affirmative disclosure obligations that do not conflict with any federal obligation).
  - Any federal law enacted under the Trump administration's deregulatory AI posture would likely preempt California's requirements and set a lower national standard. A law passed under a future Democratic administration might establish a federal floor allowing more stringent state standards to persist — replicating the Clean Air Act Section 209 waiver architecture.
  - Probability assessment: most constitutional law scholars assess preemption of SB 53 as unlikely before 2028 absent specific congressional action; the greater risk to California's regime is a comprehensive federal framework that harmonises but does not fully displace state law.
- **Compute threshold obsolescence and revision (2027–2030)**
  - The 10^26 FLOP threshold, calibrated to 2024 frontier models, will capture a progressively larger fraction of AI development as efficiency improvements lower cost-per-FLOP.
  - Trajectory: GPT-4 was estimated at 10^24–10^25 FLOPs; GPT-4-class capabilities achieved at 10^24 FLOPs by 2025–2026 efficiency improvements. At this rate, the 10^26 threshold will encompass mid-tier commercial models by 2028.
  - Algorithmic efficiency advances — mixture-of-experts architectures (reducing active parameter compute by 60–90%), state-space models (linear attention approximation), test-time compute scaling (inference-time reasoning), and speculative decoding — mean that 10^26 FLOPs of training compute may produce significantly more capable models in 2028 than in 2024.
  - The SB 53 threshold could be revised by: (a) the California Legislature updating the statute; (b) the California Attorney General issuing regulatory guidance that interprets "frontier model" in light of updated technical understanding; or (c) federal executive action updating the Biden EO threshold that SB 53 references.
  - Failure to update thresholds risks regulatory drift: a regime calibrated to 2024's most powerful models may inadvertently regulate mid-tier commercial AI while failing to capture qualitatively more dangerous specialised systems trained at lower but more efficiently-used compute.
- **SB 1047 successor legislation (2026–2028)**
  - Senator Wiener has signalled intent to pursue more substantive pre-deployment safety requirements once SB 53's transparency framework establishes baseline compliance infrastructure over 2026–2027.
  - A putative SB 1047-generation successor, potentially introduced in the 2026–2027 legislative session, might incorporate the following lessons from the 2024 veto:
    - Context-sensitive requirements: applying different standards to high-risk use categories (CBRN uplift, autonomous offensive cyber, critical infrastructure control) versus general-purpose deployments.
    - Open-source safe harbour: explicit liability safe harbours for developers who release model weights after completing a documented safety evaluation and disclosure process, provided they take reasonable mitigation measures.
    - Independent oversight body: a multi-stakeholder AI safety board with public funding and representation from civil society, academia, and government, avoiding the regulatory capture risk of the SB 1047 Frontier Model Division.
    - Evaluation standardisation: mandatory pre-deployment evaluations using standardised protocols developed by NIST, AISI, or the GPAI Code of Practice.
    - Graduated timelines: pre-deployment evaluation requirements applied to new frontier-scale models from a date certain, allowing existing deployed models a grace period.
- **EU AI Act GPAI Code of Practice convergence (2025–2028)**
  - The EU's General Purpose AI Code of Practice, developed for GPAI provisions effective August 2025, addresses frontier model transparency and safety evaluation in terms structurally similar to SB 53.
  - Key structural parallels: both require frontier model developers to publish safety frameworks; both mandate incident reporting mechanisms; both address systemic risk assessment through threshold-based definitions.
  - Key structural differences: EU GPAI Code applies to models with 10^25 FLOPs (lower threshold than SB 53's 10^26); EU regime covers EU-market entities by virtue of market access (not revenue); EU Code is developed through multi-stakeholder drafting process while SB 53 is a unilateral state statute.
  - As both regimes mature, compliance convergence is expected: multinational AI developers will create unified compliance documentation covering both SB 53's Frontier AI Framework and the EU GPAI Code's equivalent disclosure requirements.
  - The GPAI Code provides California legislators and the California Attorney General with internationally recognised benchmark standards that could be incorporated by reference into future California regulations, reducing divergence and lowering aggregate compliance cost.
- **Whistleblower ecosystem development (2026–2030)**
  - SB 53's anonymous CalOES reporting mechanism is the first AI-specific whistleblower regime with binding legal backing in the United States.
  - Effectiveness depends on: (a) employee uptake — awareness of the mechanism and confidence in its protections; (b) CalOES institutional capacity — ability to evaluate frontier AI incident reports without specialised AI expertise; (c) follow-through — the Attorney General's enforcement of retaliation protections.
  - Comparison with financial services: Dodd-Frank Section 21F (2010) paid out $1.2 billion to 334 SEC whistleblowers in its first decade; the programme required years of SEC institutional development before generating substantive submissions.
  - AI safety researchers have identified SB 53's whistleblower provision as potentially the most consequential element in the long run: if even a small number of substantive incident disclosures are filed with CalOES, they could expose AI risk patterns invisible to external regulators and inform precisely targeted future legislation.
- **Procurement-based regulation expansion (2026–2030)**
  - Governor Newsom's March 2026 Executive Order N-5-26 establishes a California AI vendor certification programme, requiring AI vendors to state agencies to meet new safety and transparency certification standards.
  - The California Department of General Services is charged with developing the certification framework by end of 2026, drawing on SB 53's Frontier AI Framework requirements and AB 2013's training data disclosure obligations.
  - This procurement-based approach exploits the federal executive order's explicit carve-out for "state government procurement and use of AI" — insulating California's requirements from preemption challenge.
  - Potential expansion: if the procurement certification regime becomes established, California may extend it to state-funded healthcare providers, public universities, local governments, and entities receiving state grants — a model analogous to FAR/DFARS cybersecurity requirements that eventually encompassed the entire federal contractor ecosystem.
  - California government AI procurement exceeds $1 billion annually: this creates meaningful market leverage for certification requirements, comparable to the federal government's use of CMMC (Cybersecurity Maturity Model Certification) to drive cybersecurity standards adoption across the defence industrial base.

### Research & Literature

- The primary and secondary research corpus spans legal practice alerts, legislative text, academic policy analysis, AI safety research, journalism, and comparative regulatory studies. SB 1047 / SB 53 generated more policy-research coverage than any other sub-national AI regulation in history.
- Zvi Mowshowitz, "Guide to SB 1047" (Substack, 2024) — the most comprehensive pre-veto public clause-by-clause analysis, covering definitional scope, compliance mechanics, kill-switch feasibility, and liability structure. Widely cited by legal practitioners and policymakers evaluating the bill.
- Dan Hendrycks (Center for AI Safety, 2024) — technical analysis of CBRN uplift risk and autonomous cyberattack capability as the empirical basis for SB 1047's critical harm definitions. Hendrycks also edited "An Overview of Catastrophic AI Risks" (2023) providing the risk taxonomy that informed SB 1047's harm categories.
- Stuart Russell (Berkeley, 2024) — public testimony and letters to Governor Newsom supporting SB 1047, drawing on his work in "Human Compatible" (2019) on the control problem for advanced AI systems.
- Brookings Institution (Mark MacCarthy, Cameron Kerry, 2024–2025) — assessed both the misrepresentations of SB 1047 in public debate and the structure of California's enacted SB 53. Brookings produced multiple analyses distinguishing SB 1047's actual text from characterisations by both proponents and opponents.
- Carnegie Endowment for International Peace (Marietje Schaake, 2024–2025) — comparative analyses of SB 1047 lessons and SB 53's significance as the first US frontier AI law. Schaake previously served as a Member of the European Parliament and has led international AI governance discussions.
- Gibson Dunn (legal memorandum, 2024) — eight key takeaways from the SB 1047 veto on developer liability, kill-switch mechanics, and cloud-provider obligations. Key analysis of the cloud-provider upstream liability mechanism absent from most other commentaries.
- IAPP (2025) — comparison of SB 53 and EU AI Act as parallel governance frameworks with significant structural differences, noting that SB 53 regulates developers while EU AI Act regulates both developers (providers) and deployers.
- Freshfields (2025) — compliance overlap analysis between SB 53 and EU AI Act GPAI provisions. Identified 7 areas of material overlap and 4 areas of divergence for multinational AI developers subject to both regimes.
- CSET Georgetown (2024–2025) — California AI governance approach relative to federal options and international regulatory models. CSET produces the most systematic comparative analysis of state-level AI legislation against federal and international alternatives.
- Wharton AI & Analytics Initiative, Kevin Werbach (2025) — SB 53 governance effectiveness assessment from a regulatory-design perspective. Werbach's analysis situates SB 53 in a broader framework of disclosure-based vs. conduct-based AI regulation.
- Sciences Po Chaire Numerique (2024) — comparative analysis of SB 1047 versus EU AI Act regulatory philosophy. Found that SB 1047 applied a "precautionary principle at scale" approach closer to pharmaceutical regulation while the EU AI Act applies a "risk-proportionate deployment" approach.
- ECIPE (2025) — "Empires of Exceptionalism: Lessons from the EU AI Act and Attempts at AI Legislation in California." Comparative analysis of how jurisdictional exceptionalism shapes AI regulatory design.
- Nelson Mullins (2025) — expanded SB 53 compliance guide for large frontier developers including obligations timeline, compliance cost estimates, and sample Frontier AI Framework structural elements.
- Paul Hastings (2024–2025) — California AI legislation package and Trump executive order preemption strategy. One of the most detailed analyses of the constitutional preemption arguments available to DOJ.
- King & Spalding (January 2026) — interaction between new California laws effective January 2026 and the December 2025 Trump executive order. Specific analysis of which California AI obligations are vulnerable to preemption challenge and which are protected by the procurement carve-out.
- WilmerHale (October 2025) — SB 53 standardised AI safety disclosure requirements analysis, including detailed compliance calendar and documentation recommendations.
- Crowell & Moring (2024–2025) — Newsom veto, SB 53 signing, and AB 2013 disclosure requirements. Multiple client alerts covering the full legislative arc from SB 1047 veto through SB 53 signing.
- Morgan Lewis (2024–2026) — SB 1047 veto, SB 53 enactment, and April 2026 California procurement executive order. Most comprehensive single-firm coverage of the California AI legislation arc.
- Gibson Dunn (December 2025) — Trump executive order AI preemption strategy and its constitutional limits. Assessed as the most thorough constitutional analysis of the federal preemption prospects.
- Morrison Foerster (October 2025) — SB 53 incident-reporting and whistleblower requirements. Detailed analysis of the CalOES reporting mechanism and the anonymous whistleblower process obligations.
- CalMatters (September 2024, December 2025) — primary California-focused journalism on the SB 1047 veto and 2025 legislative session. CalMatters Digital Democracy tool provides the most accessible legislative tracking of California AI bills.
- American Enterprise Institute (2024) — argued the SB 1047 veto created conditions for more durable and targeted AI safety regulation, providing a conservative-leaning case for why the veto was beneficial for AI safety governance long-term.
- AI Safety Newsletter (Center for Human-Compatible AI, Berkeley, 2024) — technical analysis of SB 1047 from an AI safety research perspective, including assessment of whether the critical harm definitions captured the right risk categories.
- Senator Scott Wiener, official communications and legislative record (2024) — sponsor's formal responses to industry opposition, including correspondence with OpenAI, Anthropic, and other stakeholders. Archived by California Senate District 11 office.
- SafeSecureAI.org (2024) — official SB 1047 advocacy site archiving bill text, amendments through 12 amendment cycles, and endorsements, including the 100+ AI employee letter from current and former OpenAI, DeepMind, and Meta staff.
- AI Alliance Statement in Opposition to SB 1047 (2024) — formal opposition from IBM, Meta, and 50+ organisations citing open-source compatibility, startup harm, and jurisdictional overreach.
- Narayanan, A. and Kapoor, S. (2024). "AI Snake Oil: What Artificial Intelligence Can Do, What It Can't, and How to Tell the Difference." Princeton University Press. AI governance chapters include specific critique of FLOP-based capability proxies applied to SB 1047's threshold design.
- Future of Privacy Forum (2025). "California's SB 53: The First Frontier AI Law, Explained." Comprehensive compliance guidance covering each SB 53 obligation with practical implementation notes.
- MultiState (2025). "California Passes First-of-Its-Kind AI Safety Law." Survey of SB 53 as national first and its implications for state AI regulation across the US.
- Kaplan, J. et al. (2020). "Scaling Laws for Neural Language Models." OpenAI. The empirical foundation for using training compute as a capability proxy — directly underpins the regulatory rationale for FLOP-based thresholds in SB 1047 and SB 53.
- Hoffmann, J. et al. (2022). "Training Compute-Optimal Large Language Models." DeepMind (Chinchilla paper). Updated scaling law findings informing understanding of what 10^26 FLOPs achieves in model capability terms.

### Metadata

- **domain-correction:** none (domain was correctly set to `artificial-intelligence`)
- **geographic-scope:** California (primary), United States (federal preemption debate), global (California effect)
- **temporal-scope:** 2024–2026 (primary legislative arc); 2026–2030 (future directions)
- **regulatory-status-2026:** SB 53 in force (January 2026); AB 2013 in force (January 2026); AB 1008 in force (January 2025); SB 942/AB 853 effective August 2026; federal preemption challenge ongoing; no federal AI statute enacted

### Provenance

- [1] Newsom, G. (2024). Veto Message: SB 1047. California Governor's Office. https://www.gov.ca.gov/wp-content/uploads/2024/09/SB-1047-Veto-Message.pdf
- [2] Cadelago, C. and Mason, M. (2024). "Newsom vetoes major California artificial intelligence bill." CalMatters. https://calmatters.org/economy/2024/09/california-artificial-intelligence-bill-veto/
- [3] Kumar, A. (2024). "Gov. Newsom vetoes California's AI safety bill that divided Silicon Valley." NPR. https://www.npr.org/2024/09/20/nx-s1-5119792/newsom-ai-bill-california-sb1047-tech
- [4] Coldewey, D. (2024). "Gov. Newsom vetoes California's controversial AI bill, SB 1047." TechCrunch. https://techcrunch.com/2024/09/29/gov-newsom-vetoes-californias-controversial-ai-bill-sb-1047/
- [5] Gibson Dunn (2024). "Regulating the Future: Eight Key Takeaways from California's SB 1047, Vetoed by Governor Newsom." https://www.gibsondunn.com/regulating-the-future-eight-key-takeaways-from-californias-sb-1047-vetoed-by-governor-newsom/
- [6] MacCarthy, M. (2024). "Misrepresentations of California's AI safety bill." Brookings Institution. https://www.brookings.edu/articles/misrepresentations-of-californias-ai-safety-bill/
- [7] Carnegie Endowment for International Peace (2024). "A Heated California Debate Offers Lessons for AI Safety Governance." https://carnegieendowment.org/posts/2024/10/california-sb1047-ai-safety-bill-veto-lessons
- [8] Morgan Lewis (2024). "California Governor Vetoes AI Safety Bill SB 1047, Signs AB 2013 Requiring Generative AI Transparency." https://www.morganlewis.com/pubs/2024/10/california-governor-vetoes-ai-safety-bill-sb-1047-signs-ab-2013-requiring-generative-ai-transparency
- [9] Mowshowitz, Z. (2024). "Guide to SB 1047." The Zvi / Substack. https://thezvi.substack.com/p/guide-to-sb-1047
- [10] Wikipedia (2024). "Safe and Secure Innovation for Frontier Artificial Intelligence Models Act." https://en.wikipedia.org/wiki/Safe_and_Secure_Innovation_for_Frontier_Artificial_Intelligence_Models_Act
- [11] Schaake, M. (2024). "All Eyes on Sacramento: SB 1047 and the AI Safety Debate." Carnegie Endowment for International Peace. https://carnegieendowment.org/posts/2024/09/california-sb1047-ai-safety-regulation
- [12] Governor of California (2025). "Governor Newsom signs SB 53, advancing California's world-leading artificial intelligence industry." 29 September 2025. https://www.gov.ca.gov/2025/09/29/governor-newsom-signs-sb-53-advancing-californias-world-leading-artificial-intelligence-industry/
- [13] TechCrunch (2025). "California Governor Newsom signs landmark AI safety bill SB 53." https://techcrunch.com/2025/09/29/california-governor-newsom-signs-landmark-ai-safety-bill-sb-53/
- [14] Future of Privacy Forum (2025). "California's SB 53: The First Frontier AI Law, Explained." https://fpf.org/blog/californias-sb-53-the-first-frontier-ai-law-explained/
- [15] WilmerHale (2025). "Transparency in Frontier Artificial Intelligence Act (SB-53)." https://www.wilmerhale.com/en/insights/blogs/wilmerhale-privacy-and-cybersecurity-law/20251001-transparency-in-frontier-artificial-intelligence-act-sb-53-california-requires-new-standardized-ai-safety-disclosures
- [16] Morrison Foerster (2025). "At the Frontier — California Enacts AI Safety and Transparency Regulation TFAIA (SB 53)." https://www.mofo.com/resources/insights/251001-california-enacts-ai-safety-transparency-regulation-tfaia-sb-53
- [17] Werbach, K. (2025). "SB 53: What California's New AI Safety Law Means for Developers." Wharton AI & Analytics Initiative. https://ai-analytics.wharton.upenn.edu/wharton-accountable-ai-lab/sb-53-what-californias-new-ai-safety-law-means-for-developers/
- [18] MacCarthy, M. (2025). "What is California's AI safety law?" Brookings Institution. https://www.brookings.edu/articles/what-is-californias-ai-safety-law/
- [19] MultiState (2025). "California Passes First-of-Its-Kind AI Safety Law." https://www.multistate.us/insider/2025/10/9/california-passes-first-of-its-kind-ai-safety-law
- [20] IAPP (2025). "CA's SB 53, EU AI Act are both governance frameworks, but the similarities end there." https://iapp.org/news/a/ca-s-sb-53-eu-ai-act-are-both-governance-frameworks-but-the-similarities-end-there
- [21] Freshfields (2025). "Compliance in a Global AI Market: Examining the Overlaps Between California's SB 53 and the EU AI Act." https://blog.freshfields.us/post/102lo9t/compliance-in-a-global-ai-market-examining-the-overlaps-between-californias-sb
- [22] Nelson Mullins (2025). "California SB 53 — Expanded Compliance Guide for Frontier AI Developers." https://www.nelsonmullins.com/insights/blogs/ai-task-force/ai/california-sb-53-expanded-compliance-guide-for-frontier-ai-developers
- [23] CalMatters (2025). "California got new AI regulations, but just barely, in 2025." December 2025. https://calmatters.org/economy/technology/2025/12/california-ai-regulation-2025/
- [24] Paul Hastings (2025). "President Trump Signs Executive Order Challenging State AI Laws." https://www.paulhastings.com/insights/client-alerts/president-trump-signs-executive-order-challenging-state-ai-laws
- [25] King & Spalding (2026). "New State AI Laws are Effective on January 1, 2026, But a New Executive Order Signals Disruption." https://www.kslaw.com/news-and-insights/new-state-ai-laws-are-effective-on-january-1-2026-but-a-new-executive-order-signals-disruption
- [26] Gibson Dunn (2025). "President Trump's Latest Executive Order on AI Seeks to Preempt State Laws." https://www.gibsondunn.com/president-trump-latest-executive-order-on-ai-seeks-to-preempt-state-laws/
- [27] Morgan Lewis (2026). "California Executive Order Expands AI Oversight Through State Procurement." April 2026. https://www.morganlewis.com/pubs/2026/04/california-executive-order-expands-ai-oversight-through-state-procurement
- [28] Sciences Po (2024). "California's SB1047 vs EU AI Act: A Comparative Analysis of AI Regulation." https://www.sciencespo.fr/public/chaire-numerique/en/2024/10/28/californias-sb1047-vs-eu-ai-act-a-comparative-analysis-of-ai-regulation/
- SB 1047 bill text: https://leginfo.legislature.ca.gov/faces/billTextClient.xhtml?bill_id=202320240SB1047
- SB 53 bill text: https://leginfo.legislature.ca.gov/faces/billTextClient.xhtml?bill_id=202520260SB53
- AB 2013 bill text: https://leginfo.legislature.ca.gov/faces/billTextClient.xhtml?bill_id=202320240AB2013
- SB 1047 veto message: https://www.gov.ca.gov/wp-content/uploads/2024/09/SB-1047-Veto-Message.pdf
- Newsom EO N-5-26 (March 2026): https://www.gov.ca.gov/2026/03/30/as-trump-rolls-back-protections-governor-newsom-signs-first-of-its-kind-executive-order
- SafeSecureAI.org advocacy archive: https://safesecureai.org/learn
- AI Alliance opposition statement: https://thealliance.ai/core-projects/sb1047
- **domain-correction:** none (domain correctly set to artificial-intelligence)

