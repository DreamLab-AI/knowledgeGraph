Taiwan Semiconductor Manufacturing Company (TSMC) is a semiconductor foundry that manufactures chips designed by its customers. TSMC's own site says it was established in 1987 by Dr. Morris Chang and that it pioneered the pure-play foundry business model with an exclusive focus on manufacturing its customers' products.[^1]

## Independent description

The Congressional Research Service defines a pure-play foundry as one that only manufactures designs for others and produces no products of its own design, and contrasts it with fabless companies that only design chips and outsource manufacturing.[^2] The same report states that in 2022 TSMC owned about half of the global logic chip foundry capacity, a figure that is dated to 2022.[^2]

The European Commission describes ESMC, a planned semiconductor manufacturing facility in Dresden, as a joint venture between TSMC, Bosch, Infineon and NXP, and the Commission's State aid announcement concerns a microchip manufacturing plant in Dresden.[^3]

## Role in the supply chain

TSMC is a [[Contract Manufacturer]] in the semiconductor chain, and its place in that chain is described under [[Semiconductor Supply Chain]] and [[Semiconductor Manufacturing]]. See also [[GPU Supply Chain]]. In this vault TSMC is a class under the contract manufacturer role, not an individual.

## What the sources do not establish

Sources do not say which products TSMC makes for which customers, and they give no capacity or revenue figures beyond the dated Congressional Research Service share. The company's own page was read for the founding date and the business model only. The Commission page describes ESMC as a joint venture and does not describe TSMC's activities in general.[^1][^3]

[^1]: Taiwan Semiconductor Manufacturing Company, “Company Info”. https://www.tsmc.com/english/aboutTSMC/company_profile
[^2]: Congressional Research Service, “Semiconductors and the Semiconductor Industry”, R47508, April 2023. https://www.congress.gov/crs_external_products/R/PDF/R47508/R47508.2.pdf
[^3]: European Commission, “Commission approves €5 billion German State aid measure to support ESMC in setting up a new semiconductor manufacturing facility”. https://digital-strategy.ec.europa.eu/en/news/commission-approves-eu5-billion-german-state-aid-measure-support-esmc-setting-new-semiconductor

