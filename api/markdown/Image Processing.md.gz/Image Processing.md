Image Processing is the computational manipulation of digital images using mathematical operations—including spatial filtering, morphological transforms, frequency-domain analysis, and learned convolutional operations—to enhance visual quality, extract structured information, or transform image representations for downstream tasks. It encompasses both classical signal processing techniques (Fourier and wavelet transforms, histogram equalisation, edge detection via Sobel or Canny operators, morphological erosion and dilation) and modern deep-learning approaches implemented through convolutional neural networks, vision transformers, and diffusion models. Image processing forms the foundational preprocessing and analysis layer for computer vision pipelines, medical imaging workflows, remote sensing, autonomous navigation, and industrial quality inspection, operating on discrete pixel grids to produce processed images or structured semantic outputs. The field bridges raw sensor data acquisition and higher-level scene understanding, with applications spanning from embedded real-time systems to large-scale cloud inference infrastructure.

### Overview

- Image processing as a formal discipline emerged from the US space programme of the 1960s, when NASA required algorithms to reconstruct and enhance telemetry images from lunar probes degraded by radio-channel noise. The development of the Fast [[Fourier Transform]] in 1965 enabled practical frequency-domain filtering at scale, and algorithms developed at JPL became foundational to the field. Medical imaging—enhancement of X-ray radiographs, CT reconstruction from projections via filtered back-projection, and [[MRI]] signal denoising—drove rapid development of both spatial and frequency-domain methods throughout the 1970s and 1980s. Industrial machine vision systems, deployed from the 1980s onward, applied image processing primitives to quality inspection on semiconductor and automotive manufacturing lines.
- The deep-learning era, inaugurated by the AlexNet breakthrough in 2012, transformed image processing: convolutional filters trained end-to-end on large labelled corpora demonstrated that learned representations substantially outperformed hand-engineered features across nearly all benchmark tasks. Modern industrial image processing pipelines are typically hybrid—classical preprocessing steps (demosaicing, lens distortion correction, white balance, colour space conversion from camera RAW) prepare sensor data before learned models perform semantic analysis. Generative frameworks, particularly [[Diffusion Model]] architectures, have further expanded the field by enabling high-fidelity image synthesis, super-resolution, inpainting, and restoration as routine capabilities.
- Why it matters: image processing is the enabling layer for billions of deployed systems—from smartphone camera stacks processing every photo taken globally, to radiology AI tools supporting clinical decisions, to satellite imagery pipelines monitoring environmental change, to the real-time perception stacks aboard autonomous vehicles. Its continued advancement is therefore both an engineering imperative and an active research frontier.

### Key Components

#### Spatial Domain Operations

- **Convolution and Filtering** — application of filter kernels (Gaussian, Sobel, Laplacian, Gabor) through discrete convolution to implement blurring, edge detection, sharpening, and texture enhancement. Linear filters admit frequency-domain analysis via the convolution theorem. Related: [[Digital Signal Processing]], [[Feature Extraction]].
- **Morphological Operations** — structuring-element-based binary and greyscale operations including erosion, dilation, opening, closing, and the hit-or-miss transform. Used to remove noise, separate touching objects, compute shape skeletons, and extract geometric descriptors from binary masks. Related: [[Image Segmentation]].
- **Histogram Equalisation** — redistribution of pixel intensity histograms to maximise contrast; adaptive variants (CLAHE) apply equalisation within local tiles to avoid over-amplification in bright regions. Standard preprocessing step in [[Medical Imaging]] and satellite imagery.
- **Geometric Transformations** — rotation, scaling, affine and perspective warping, image registration, and coordinate remapping. Essential for multi-sensor fusion, panoramic stitching, and data augmentation in [[Machine Learning Pipeline]] training regimes.
- **Colour Space Processing** — conversion between RGB, HSV, YCbCr, LAB, and camera-native RAW colour models. [[Colour Science]] underpins white balance, gamut mapping, and tone-curve operations in imaging pipelines.

#### Frequency Domain Operations

- **Fourier Transform** — the 2-D Discrete Fourier Transform decomposes images into sinusoidal basis functions; manipulation of spectrum coefficients achieves noise reduction, periodic-pattern removal, and texture synthesis. The [[Fourier Transform]] is the mathematical backbone of classical image processing.
- **Wavelet Transform** — multiresolution analysis using wavelet basis functions; wavelets provide spatially localised frequency decomposition superior to the DFT for non-stationary signals, underpinning [[Image Compression]] standards (JPEG 2000) and denoising algorithms.
- **Compressed Sensing** — reconstruction of images from sub-Nyquist measurements via sparsity-promoting optimisation; enables MRI acceleration and single-pixel camera architectures.

#### Deep Learning-Based Operations

- **Convolutional Neural Networks** — hierarchical feature extractors whose layers implicitly learn spatial filters; foundational architecture for [[Image Classification]], [[Object Detection]], [[Image Segmentation]], and low-level restoration tasks. See [[Convolutional Neural Network]].
- **Vision Transformers** — self-attention-based architectures (ViT, Swin Transformer) that treat image patches as sequence tokens; competitive with or superior to CNNs on large-scale benchmarks and strong backbones for dense prediction tasks. See [[Vision Transformer]].
- **Diffusion Models** — iterative denoising generative models achieving state-of-the-art image synthesis, super-resolution, and inpainting; replace GAN-based approaches in high-fidelity generation tasks. See [[Diffusion Model]].
- **Foundation Models for Vision** — large-scale models (SAM — Segment Anything Model, CLIP, DINOv2) trained on vast corpora and prompted at inference time; enable universal segmentation and retrieval without task-specific retraining.

#### Preprocessing and Pipeline Infrastructure

- **Demosaicing** — reconstruction of full-colour images from single-sensor Bayer-pattern RAW data via interpolation; first stage in camera image signal processors (ISPs).
- **Noise Modelling and Removal** — characterisation of sensor noise (shot, read, fixed-pattern) and application of spatially adaptive denoising (BM3D, NLM, learned denoisers).
- **Image Registration** — spatial alignment of images acquired from different times, sensors, or viewpoints using feature matching or intensity-based optimisation; prerequisite for change detection, panoramic stitching, and medical image fusion.
- **Image Compression** — reduction of image file size via lossy (JPEG, HEIC, WebP) or lossless (PNG, JPEG 2000 lossless) coding; compression artefact removal is itself an active image processing task. See [[Image Compression]].

### Applications / Use Cases

- **Medical Imaging** — enhancement and segmentation of CT, MRI, PET, ultrasound, and histopathology images for diagnostic support; tumour detection, organ segmentation, and imaging biomarker extraction. AI-powered medical image processing tools have received regulatory clearance in multiple jurisdictions for specific radiology applications. See [[Medical Imaging]].
- **Remote Sensing and Satellite Imagery** — multispectral and hyperspectral image analysis for land cover classification, crop monitoring, disaster damage assessment, and climate change monitoring. Related: [[Remote Sensing]].
- **Autonomous Vehicles** — real-time camera image processing for lane detection, traffic sign recognition, pedestrian detection, depth estimation from stereo or monocular cameras; tightly coupled with [[Object Detection]] and sensor fusion pipelines. See [[Autonomous Vehicles]].
- **Augmented Reality** — camera tracking, marker detection, plane estimation, and occlusion handling via live image processing on mobile processors; core enabler of [[Augmented Reality]] headsets and mobile AR applications.
- **Industrial Quality Inspection** — defect detection, dimensional measurement, and surface inspection on manufacturing lines using structured-light imaging and convolutional defect classifiers; deployed in semiconductor wafer inspection, PCB assembly verification, and food safety grading.
- **Computational Photography** — night mode HDR stacking, portrait mode depth-of-field simulation, optical zoom enhancement via super-resolution, and style transfer in smartphone imaging stacks; executed on dedicated neural processing units embedded in mobile SoCs.
- **Scientific Imaging** — astronomy image denoising and deconvolution (event horizon telescope reconstruction via CLEAN algorithm), electron microscopy super-resolution, fluorescence microscopy deconvolution, and materials characterisation.
- **Document Processing** — OCR preprocessing (binarisation, skew correction, border removal), layout analysis, and signature verification in document management systems.
- **Security and Surveillance** — face detection and recognition, crowd density estimation, anomaly detection in CCTV footage; interfaces with [[Robotics]] for autonomous patrol systems.
- **Spatial Computing** — depth image processing for LiDAR and structured-light sensors in [[Spatial Computing]] platforms; point cloud generation and 3-D reconstruction from RGBD images.

### Standards & Context

- **ISO/IEC JTC1 SC29** governs image and audio coding standards including JPEG (ISO/IEC 10918), JPEG 2000 (ISO/IEC 15444), JPEG XL, HEIF, and MPEG video coding families—all of which rely on image processing algorithms as their encoding core.
- **IEEE Signal Processing Society** publishes the IEEE Transactions on Image Processing, the primary journal of record for the field, and organises ICIP (International Conference on Image Processing).
- **MICCAI** (Medical Image Computing and Computer-Assisted Intervention) society coordinates standards and benchmarks for medical image processing, including the Medical Segmentation Decathlon challenge datasets.
- **ISO 9283 / ISO 10360** cover machine vision metrology relevant to industrial image processing applications.
- **Camera and Colour Standards** — ICC colour profiles (ISO 15076), DNG RAW format (Adobe/ISO), sRGB (IEC 61966-2-1), and Display P3 colour spaces define the interoperability layer for colour image processing across devices.
- The field operates with open benchmark datasets: ImageNet (large-scale classification), COCO (detection and segmentation), Cityscapes (autonomous driving semantic segmentation), BSDS500 (edge detection), and BSD68 (image denoising).

### Provenance

