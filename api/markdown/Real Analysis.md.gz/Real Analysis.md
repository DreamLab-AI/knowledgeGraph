Real Analysis is the branch of mathematics that rigorously studies the real numbers, sequences, series, limits, continuity, differentiation and integration. It provides the formal foundations underlying calculus, establishing theorems on convergence and the structure of the real line. Real analysis underpins measure theory, functional analysis and the probabilistic and optimisation theory used in machine learning.

### Overview

- Real Analysis is the branch of mathematics that rigorously studies the real numbers, sequences, series, limits, continuity, differentiation and integration.
- It provides the formal foundations underlying calculus, establishing theorems on convergence and the structure of the real line.
- Real analysis underpins measure theory, functional analysis and the probabilistic and optimisation theory used in machine learning.
- It is modelled as a subclass of [[Calculus]] within the machine-learning domain.

### Key aspects

- [[Convergence]] is a constituent or mechanism relevant to Real Analysis.

### Mechanisms

- Real Analysis enables [[Probability Theory]].
- Real Analysis supports [[Sigma Algebra]].

### Applications

- Applied in contexts involving [[Probability Theory]].
- Applied in contexts involving [[Sigma Algebra]].
- Applied in contexts involving [[Machine Learning]].
- Applied in contexts involving [[Functional Analysis]].
- Applied in contexts involving [[Measure Theory]].

### Provenance

