A chokepoint disruption is the blockage or closure of a narrow, heavily used passage on a transport route, such as a canal or strait, which interrupts the flows that depend on it.[^1]

The US Energy Information Administration describes maritime transit chokepoints as narrow channels along widely used global sea routes.[^1] Its 2011 note is about petroleum, and it says that the blockage of a chokepoint, even temporarily, can lead to a substantial disruption in energy markets.[^1]

## Consequences and alternatives

The EIA says that closure of some chokepoints would require longer alternate routes and so raise transportation costs, while other chokepoints have limited alternate routes.[^1] For the Suez Canal and SUMED Pipeline it estimates that closure would add about 6,000 miles of travel around the continent of Africa.[^1] It also says transit through the Strait of Bab el-Mandeb has been vulnerable to piracy, and that the Panama Canal plays a smaller role in oil transit mainly because of tanker size restrictions.[^1]

## An actual blockage

AMRO records that the accidental blockage of the Suez Canal in March 2021 and various weather-related disturbances in North America and Asia compounded the squeeze in shipping capacity.[^2] The note treats the blockage as one factor among several in a wider disruption of shipping, and it does not isolate the effect of the blockage alone.[^2]

## Scope and limits

Chokepoint disruption is a type of [[Supply Chain Disruption]] and bears on [[Ocean Freight]]. The EIA material is more than a decade old and covers oil, so it supports the definition and the mechanism but not current volumes or the more recent diversions of container traffic. No other source opened here describes the Red Sea or Panama Canal disruptions after 2021.

[^1]: U.S. Energy Information Administration, “Maritime chokepoints critical to petroleum markets (Today in Energy, 2 March 2011)”. https://www.eia.gov/todayinenergy/detail.php?id=330
[^2]: ASEAN+3 Macroeconomic Research Office (AMRO), Analytical Note, 25 July 2022, “The Great Supply Chain Disruption: What Does the Shipping Crystal Ball Foretell?”. https://amro-asia.org/wp-content/uploads/2022/07/AMRO-Analytical-Note_The-Great-Supply-Chain-Disruption_What-Does-the-Shipping-Crystal-Ball-Foretell-_July-25-2022.pdf

