A bill of lading is a carrier's document that serves as a receipt for goods, as written evidence of the contract of carriage, and, in its negotiable form, as a document of title.[^1][^2]

Maersk's glossary describes it as a legal document signed by or for the master, agents, owners of a vessel or the carrier, which is a receipt for the goods and an undertaking to carry and deliver them, where provisions stipulate delivery against surrender of the document to a named person, to order or to bearer, and which evidences the terms of the contract of carriage.[^1] HM Revenue and Customs' guidance calls bills of lading documents of title providing evidence of the contract between exporter and carrier, and calls air and sea waybills similar but not title documents.[^2] The carrier glossary says the same of waybills.[^1]

## Legal treatment

The UK Carriage of Goods by Sea Act 1992 applies to any bill of lading, sea waybill and ship's delivery order, and excludes from bills of lading a document incapable of transfer by indorsement or, as a bearer bill, by delivery.[^3] A person who becomes the lawful holder of a bill of lading has transferred to him all rights of suit under the contract of carriage as if he had been a party to it.[^4] Title 49 of the United States Code defines a holder as a person having possession of, and a property right in, a bill of lading, and names the consignee and consignor by reference to the bill.[^5]

## In practice

UNCITRAL's explanatory note says the request for delivery of goods typically requires the surrender of a bill of lading.[^6] The Digital Container Shipping Association calls it the most important trade document in container shipping.[^7] See [[Electronic Bill of Lading]], [[Trade Document]] and [[Ocean Carrier]].

## Evidence limits

Legal effect of the document differs by jurisdiction. Sources cover UK statute, a United States definitions section and carrier and agency descriptions; international conventions on carriage were not opened. The DCSA statement is an industry body's own view.[^3][^5][^7]

[^1]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms
[^2]: HM Revenue and Customs, “Archiving your trade documents - GOV.UK”. https://www.gov.uk/guidance/archiving-your-trade-documents
[^3]: UK Parliament, “Carriage of Goods by Sea Act 1992”, section 1. https://www.legislation.gov.uk/ukpga/1992/50/section/1
[^4]: UK Parliament, “Carriage of Goods by Sea Act 1992”, section 2. https://www.legislation.gov.uk/ukpga/1992/50/section/2
[^5]: Cornell Law School Legal Information Institute, “49 U.S. Code § 80101 - Definitions”. https://www.law.cornell.edu/uscode/text/49/80101
[^6]: United Nations Commission on International Trade Law, Model Law on Electronic Transferable Records, explanatory note (PDF). https://uncitral.un.org/sites/uncitral.un.org/files/media-documents/uncitral/en/mletr_ebook_e.pdf
[^7]: Digital Container Shipping Association, Bill of Lading standard (web page). https://dcsa.org/standards/bill-of-lading

