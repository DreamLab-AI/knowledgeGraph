
An agent purpose and role declares the operational purpose and ownership of an agent, declared as `PurposeRole` in the agent module of the Agent Ontology.[^1] visionGraph places it under [[Specification]] and as part of [[Agent]].

An [[Agent]] reaches it through `purposeAndRole`. Two string properties describe it: `objective`, the purpose the agent serves, and `owner`, the party responsible for it. Together they answer what an agent is for and who answers for it, which is the starting point for judging whether a given action is in scope.

The class is one of several descriptor facets of an agent in the same module. Another is the [[Agent Operational Profile]], which covers triggers and input and output. The purpose and role states what the agent is for and who owns it, whereas the profile states how it runs.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

