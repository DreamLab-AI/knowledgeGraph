The Bank of England (BoE) is the United Kingdom's central bank, founded in 1694 by Royal Charter to finance the Crown, and nationalised in 1946. It is responsible for monetary policy via the Monetary Policy Committee (MPC), which sets Bank Rate to maintain a 2% CPI inflation target; macroprudential financial stability policy via the Financial Policy Committee (FPC); and microprudential supervision of deposit-taking institutions, insurers, and systemically important financial market infrastructures via the Prudential Regulation Authority (PRA). The Bank also operates the UK's Real-Time Gross Settlement (RTGS) payment infrastructure and issues sterling banknotes, acting as the operational backbone of the UK financial system.

### Overview

- The Bank of England occupies a unique constitutional position: it is operationally independent from HM Treasury (since the Bank of England Act 1998), yet accountable to Parliament through regular testimony and published minutes. This independence-within-accountability model is widely studied as a template for [[Central Bank]] governance globally.
- Its mandate spans three interlocking domains:
  - **Monetary policy**: the MPC sets Bank Rate eight times per year, using [[Interest Rate Policy]] and, where needed, [[Quantitative Easing]] (asset purchases) to anchor inflation expectations.
  - **Financial stability**: the FPC identifies, monitors, and acts against systemic vulnerabilities using tools such as the countercyclical capital buffer and stress-testing exercises.
  - **Prudential supervision**: the PRA applies [[Basel III]] capital and liquidity requirements adapted for UK law (UK CRR) and sets rules on operational resilience, model risk management, and recovery and resolution planning.
- The Bank also acts as [[Lender of Last Resort]], providing emergency liquidity assistance to solvent but illiquid institutions during financial stress, as demonstrated during the 2007–2009 financial crisis and the 2022 liability-driven investment (LDI) market intervention.

### Key Mechanisms

- **Bank Rate (base rate)**: the primary [[Interest Rate Policy]] lever, influencing borrowing costs, exchange rates, and aggregate demand across the economy.
- **Monetary Policy Committee (MPC)**: nine-member committee (four external members appointed by HM Treasury) meeting eight times per year; decisions are published with minutes and a quarterly Monetary Policy Report.
- **Financial Policy Committee (FPC)**: macroprudential body with powers to direct the PRA and FCA; sets the countercyclical capital buffer, loan-to-value limits, and debt-to-income guidance for mortgage lenders.
- **Prudential Regulation Authority (PRA)**: approx. 1,500 regulated firms; supervises via a forward-looking, judgement-based approach; issues Supervisory Statements and Policy Statements that implement UK-specific rules derived from Basel and Solvency II frameworks.
- **RTGS / CHAPS**: the [[Real-Time Gross Settlement]] system processes high-value sterling payments. The Bank's RTGS renewal programme (completed 2024) introduced ISO 20022 messaging, enhanced resilience, and extensibility for future [[Financial Market Infrastructure]] innovation.
- **Balance sheet and asset purchases**: [[Quantitative Easing]] programmes expanded the BoE balance sheet substantially from 2009 onwards; quantitative tightening (gilt sales) has been underway since 2022.
- **Stress testing**: annual concurrent stress tests for major UK banks assess capital adequacy against severe but plausible macro scenarios, informing [[Risk Management Framework]] benchmarks.

### Applications and Use Cases

- **Monetary stability**: setting Bank Rate to control consumer price inflation and anchor expectations, directly affecting mortgage rates, savings rates, and business investment.
- **Systemic risk mitigation**: using FPC powers to require higher capital buffers during credit booms, preventing [[Systemic Risk]] build-up in the banking sector.
- **Payment system oversight**: operating CHAPS for same-day high-value settlements and overseeing retail payment systems under the [[Payment System]] oversight remit shared with the Payment Systems Regulator.
- **Digital currency exploration**: the Bank has jointly consulted with HM Treasury on a retail "digital pound" — a form of [[Central Bank Digital Currency]] — and participated in wholesale CBDC experiments including Project Rosalind (with the BIS Innovation Hub) and the Digital Securities Sandbox.
- **Distributed ledger technology pilots**: the Bank's Financial Market Infrastructure (FMI) sandbox (established under the Financial Services and Markets Act 2023) allows firms to test [[Distributed Ledger Technology]]-based settlement for securities without immediately requiring full compliance with existing rules.
- **AI governance in finance**: the PRA has issued Supervisory Statement SS1/23 on model risk management, providing the primary UK regulatory reference for [[AI Governance]] of machine-learning models used in credit, pricing, and market risk at regulated firms.
- **Climate and sustainability**: the Bank embeds climate scenario analysis into its stress-testing framework, aligning with the [[Financial Stability Board]]'s TCFD recommendations to assess transition and physical risk exposures.

### Standards and Regulatory Context

- **Bank of England Act 1998**: granted operational independence for monetary policy; established the MPC and accountability to Parliament.
- **Financial Services and Markets Act 2000 (FSMA 2000)**: legislative basis for financial regulation, creating the twin-peaks model shared between the PRA and FCA.
- **Financial Services Act 2012**: restructured post-crisis; created the FPC with macroprudential powers; transferred banking supervision from the FSA to the PRA.
- **Financial Services and Markets Act 2023**: introduced the FMI sandbox for [[Distributed Ledger Technology]] experimentation; enacted post-Brexit regulatory reforms (Edinburgh Reforms) allowing UK-specific divergence from EU rules (e.g., CRD IV / Solvency II).
- **[[Basel III]] / UK CRR**: capital and liquidity requirements transposed into UK law post-Brexit; the PRA is completing the UK implementation of the Basel 3.1 (Basel IV) package.
- **Solvency II / Solvency UK**: insurance capital framework under review to improve proportionality and competitiveness of UK insurers regulated by the PRA.
- **TCFD alignment**: the Bank integrates Task Force on Climate-related Financial Disclosures recommendations into its supervisory and financial stability frameworks.
- **ISO 20022**: adopted in RTGS renewal for richer data in sterling payment messages, facilitating fraud detection and compliance automation.
- **PRA Supervisory Statement SS1/23**: model risk management guidance covering AI and ML models used in regulated firms — the principal UK regulatory document on [[AI Governance]] in financial services.

### Historical Milestones

- **1694**: founded by Act of Parliament as a private bank to lend £1.2 million to William III for war with France.
- **1844**: Bank Charter Act established the Bank's monopoly on banknote issuance in England and Wales.
- **1946**: nationalised by the Bank of England Act 1946 under the Attlee government.
- **1997–1998**: granted independence to set interest rates; MPC established; banking supervision transferred to the newly formed FSA.
- **2008–2009**: major lender of last resort operations during the global financial crisis; launch of quantitative easing.
- **2013**: PRA and FCA replace the FSA; twin-peaks model fully operational.
- **2021–2023**: digital pound consultation launched; Project Rosalind wholesale CBDC experiments; SS1/23 model risk guidance published.
- **2024**: RTGS renewal completed; Basel 3.1 implementation timetable confirmed; quantitative tightening ongoing.

### Provenance

