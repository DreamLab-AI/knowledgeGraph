A warehouse storage system is the physical equipment in which goods are held and from which they are retrieved, such as racks, shelving and automated systems.[^1]

Georgia Tech's open textbook says storage and retrieval equipment can reduce labour costs, for example by allowing many stock keeping units on the pick face, which increases pick density and reduces travel per pick, and by easing handling. It says storage equipment can increase space utilisation by partitioning space into subregions and by making it possible to store product high.[^1] It names common storage modes as pallet rack for bulk storage, carton flow rack for high-volume picking, and static shelving for slower, lower-volume picking.[^1]

## Automated and picker-oriented systems

A review of operations and supply chain management says the traditional automated storage and retrieval system is a crane-operated rack filled with pallets or bins, and lists carousels, vertical lift modules, puzzle-based storage systems, deep-lane systems and shuttle-based systems as other automated storage types.[^2] A literature review of order picking describes low-level picking from storage racks or bins while the picker travels along aisles, and notes that other systems employ high storage racks.[^3] See [[Automated Storage and Retrieval System]].

## Scope and distinctions

Storage systems sit under [[Warehousing and Distribution]]. The way goods flow in and out of storage is covered at [[Warehouse Operation]], and the picking method at [[Order Picking]]. Storage equipment is a [[Warehouse Automation]] topic when it is automated.

## What the sources do not establish

Sources do not rank storage modes and give no comparative costs. The Georgia Tech text describes the modes in general terms and the review lists the automated types without defining each.

[^1]: Georgia Institute of Technology (John J. Bartholdi III and Steven T. Hackman), “Warehouse & Distribution Science, Release 0.98”. https://www2.isye.gatech.edu/~jjb/wh/book/editions/wh-sci-0.98.pdf
[^2]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^3]: René de Koster, Tho Le-Duc and Kees Jan Roodbergen, European Journal of Operational Research 182(2), 2007, “Design and control of warehouse order picking: A literature review”. https://pure.eur.nl/ws/portalfiles/portal/46713708/DesignandControl_2007.pdf

