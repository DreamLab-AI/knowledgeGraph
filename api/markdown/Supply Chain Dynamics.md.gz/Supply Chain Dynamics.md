Supply chain dynamics is the study of how the stocks, flows, delays and ordering rules of a supply chain interact to produce its behaviour over time, including oscillation and the amplification of disturbances.[^1]

John Sterman's abstract says that many supply chains exhibit chronic instability, including oscillations, amplification as disturbances move upstream from final sales, and phase lag.[^1] It describes every supply chain as a network of stocks and flows of material, time delays and the decision rules that couple them.[^1] It adds that simulations, field studies and experiments show that instability arises from decision-makers failing to account for time delays in the system and for the supply line of orders not yet received, and from failing to understand basic principles of accumulation.[^1] Only the abstract was opened, so the model itself is not reported.

## Related findings

Lee, Padmanabhan and Whang report that order information tends to be distorted, that the variance of orders may exceed that of sales, and that the distortion tends to increase as one moves upstream; they call this the bullwhip effect.[^2] It has its own page at [[Bullwhip Effect]]. Christopher and Peck describe modern commercial supply chains as dynamic networks of interconnected firms and industries.[^3]

## Beer Game

Kaminsky and Simchi-Levi describe the Beer Game, a classroom exercise in which each week the retail manager observes external demand, fills as much as possible, records backorders and places an order with the wholesaler.[^4] They note that because customer demand does not vary much, there must be another cause for wildly fluctuating inventory and backorder levels.[^4] The game is a teaching device and is not evidence about real supply chains by itself.

## Scope

Dynamics sits under [[Supply Chain Risk and Resilience]] in this corpus. The propagation of an outside shock through tiers is described at [[Ripple Effect]].

## What the sources do not establish

No source opened defines supply chain dynamics as a fixed term. Forrester's early industrial dynamics work was not opened, and the page makes no claim about its history.

[^1]: John Sterman, chapter in The Handbook of Behavioral Operations Management, Oxford University Press, 2015 (MIT DSpace record, abstract only), “Booms, Busts, and Beer: Understanding the Dynamics of Supply Chains”. https://dspace.mit.edu/handle/1721.1/121087
[^2]: Hau L. Lee, V. Padmanabhan and Seungjin Whang, Management Science, 1997 (copy on a Bilkent University course site, abstract used), “Information Distortion in a Supply Chain: The Bullwhip Effect”. https://courses.ie.bilkent.edu.tr/ie102/wp-content/uploads/sites/12/2019/02/Lee-Padmanabhan-Whang-1997-MS.pdf
[^3]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^4]: Philip Kaminsky and David Simchi-Levi, Northwestern University, 1998, “A New Computerized Beer Game: A Tool for Teaching the Value of Integrated Supply Chain Management”. https://kaminsky.ieor.berkeley.edu/Reprints/PK_DSL_98b.pdf

