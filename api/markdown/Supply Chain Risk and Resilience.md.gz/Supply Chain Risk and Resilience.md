Supply chain risk and resilience is the area of study and practice concerned with disturbances to the flows of product, information and cash through a supply network, and with the capacity of the network to recover from them.[^1]

Christopher and Peck argue that as supply chains become more complex through global sourcing and the continued trend to “leaning-down”, supply chain risk increases.[^1] They define resilience as “the ability of a system to return to its original state or move to a new, more desirable state after being disturbed”.[^1] The same paper lists natural disasters, industrial disputes, terrorism and war among events that have caused serious disruptions to supply chain activities.[^1]

## Sources of risk now discussed

Later agency and central bank material names two sources in particular. The UK Climate Change Committee says that climate change can stress supply chains and cause price rises, disruptions, delays and even failures in the supply of goods and services.[^2] The European Central Bank reports that, although European firms are reorganising supply chains, critical foreign dependencies persist.[^3] The Center for Climate and Energy Solutions lists climate change, geopolitics and economic volatility together as mounting risks to global supply chains.[^4]

[[Supply Chain Risk Type]] organises the risk side of the branch, [[Supply Chain Disruption]] describes events and [[Supply Chain Dynamics]] describes system behaviour. [[Supply Chain Risk Management]] covers the governance process and [[Supply Chain Resilience]] the capacity to recover.

## Scope and limits

The C2ES primer observes that corporate resilience planning has grown since COVID-19 but that climate risk is still treated separately from supply chain management.[^4] That is a statement about corporate practice, not a definition of the field.

No source opened here defines supply chain risk and resilience as a single subject. The page therefore describes the field through the sources above rather than through a standard.

[^1]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^2]: UK Climate Change Committee, “Resilient Supply Chains (briefing, 2022)”. https://www.theccc.org.uk/wp-content/uploads/2022/10/Resilient-Supply-Chains-.pdf
[^3]: European Central Bank, Occasional Paper Series, “Navigating a fragmenting global trading system: insights for central banks (No 365)”. https://ecb.europa.eu/pub/pdf/scpops/ecb.op365~362d801aee.es.pdf
[^4]: Center for Climate and Energy Solutions (C2ES), September 2025, “Assessing the Landscape of Climate Risk and Supply Chain Resilience: A Primer for Corporate Leaders and Climate Risk Professionals”. https://www.c2es.org/wp-content/uploads/2025/09/Climate-Risk-and-Supply-Chain-Report_FINAL_v3.pdf

