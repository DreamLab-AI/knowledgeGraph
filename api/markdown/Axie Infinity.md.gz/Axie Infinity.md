Axie Infinity is a blockchain-based game in which players collect, breed, and battle digital creatures called Axies that are represented as non-fungible tokens.

### Semantic Classification

### Content

- Axie Infinity, developed by Sky Mavis, lets players own Axies as NFTs and earn in-game tokens through play. It popularised the play-to-earn model and at its peak attracted large numbers of players, particularly in Southeast Asia.
- The game runs on Ronin, an Ethereum sidechain built by Sky Mavis to reduce transaction costs. In 2022 the Ronin bridge suffered a large security breach in which attacker-controlled validators authorised fraudulent withdrawals.

### Provenance

