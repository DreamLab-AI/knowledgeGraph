A seaport is a node in global supply chains where goods move between ships and inland transport, together with the activities clustered around that interface.[^1]

Notteboom, Pallis and Rodrigue define a seaport as a logistic and industrial node in global supply chains with a strong maritime character and a functional and spatial clustering of activities linked to transportation, transformation and distribution, acting as an interface between maritime and inland systems of circulation.[^1] They note that a port is conventionally a transit area or gateway through which goods and people move from and to the sea, and that because maritime and inland modes have different capacities the port is a point of load break where cargo is stored, consolidated or deconsolidated.[^1]

## Legal and physical definitions

Definitions differ in emphasis. Regulation (EU) 2017/352 defines a maritime port as an area of land and water made up of the infrastructure and equipment needed to permit, principally, the reception of waterborne vessels, their loading and unloading, the storage of goods, the receipt and delivery of those goods and the embarkation and disembarkation of passengers, crew and other persons, and any other infrastructure necessary for transport operators within the port area.[^2] Rodrigue and Notteboom describe ports more briefly as harbour areas in which marine terminal facilities transfer cargo and passengers between ships and land transportation.[^3] The first definition is functional and supply-chain based; the second is a statutory description of a site; the third is descriptive.[^1][^2][^3]

## Relation to other nodes

A seaport is one kind of [[Freight Node]]. Rodrigue and Slack call large transport terminals, particularly ports and airports, gateways or hubs, since they become obligatory points of transit between segments of the global transport system.[^4] Inland terminals linked to a seaport are treated at [[Dry Port]].

## Evidence limits

Two of the sources share an author, and the third is a regulation that applies in the EU.[^1][^3][^2] No opened source gives port counts or traffic figures, and none is used for them here.

[^1]: Theo Notteboom, Athanasios Pallis and Jean-Paul Rodrigue, Port Economics, Management and Policy, “Chapter 0.1 – Defining Seaports”. https://porteconomicsmanagement.org/pemp/contents/introduction/defining-seaports/
[^2]: European Parliament and Council, “Regulation (EU) 2017/352 of the European Parliament and of the Council of 15 February 2017 establishing a framework for the provision of port services and common rules on the financial transparency of ports”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32017R0352
[^3]: Jean-Paul Rodrigue and Theo Notteboom, The Geography of Transport Systems, “6.3 – Port Terminals”. https://transportgeography.org/contents/chapter6/port-terminals/
[^4]: Jean-Paul Rodrigue and Brian Slack, The Geography of Transport Systems, “6.1 – The Function of Transport Terminals”. https://transportgeography.org/contents/chapter6/function-of-transport-terminals/

