A supply chain planning system is software that supports supply chain planning, which Yin and colleagues describe as the process of anticipating future demand and coordinating operational activities across the logistics network.[^1]

No source opened defines the system itself. Zaidi, Amanton and Sanlaville place supply chain planning among three classes of logistics information systems, alongside enterprise resource planning and execution, and describe the planning class as product lifecycle management, scheduling and production planning.[^2]

## Planning tiers

In the open handbook on operations and supply chain management, hierarchical planning segments the planning task into subtasks in three tiers: long-term, mid-term and short-term.[^3] Long-term planning focuses on a multi-year horizon and influences decisions on supplier selection, production capacity and distribution structure.[^3] Mid-term planning comprises demand planning and master planning, and short-term planning, which includes scheduling and distribution planning, is conducted on a weekly or daily basis.[^3] These tiers are the work that planning software supports.

## Link to other systems

That handbook says advanced planning systems act as decision support: they extract data from enterprise resource planning systems, generate high-quality solutions and relay decisions back to the ERP for execution.[^3] See [[Advanced Planning and Scheduling]], [[Supply Chain Execution System]] and [[Supply Chain Information Systems]].

## What the sources do not establish

All three sources are academic preprints, and Yin and colleagues write with an e-commerce setting in mind.[^1][^2][^3] None defines a planning system as a product category or lists the modules a planning product must have. The sources give no vendor list for planning software beyond the handbook's mention of vendors of advanced planning systems, and no adoption data.

[^1]: Jiaheng Yin, Yongzhi Qi, Jianshen Zhang, Dongyang Geng, Zhengyu Chen, Hao Hu, Wei Qi and Zuo-Jun Max Shen, “Rethinking Supply Chain Planning: A Generative Paradigm”, arXiv:2509.03811. https://arxiv.org/pdf/2509.03811
[^2]: Fares Zaidi, Laurent Amanton and Eric Sanlaville, “Towards a Novel Cooperative Logistics Information System Framework”, arXiv:1905.00687. https://arxiv.org/pdf/1905.00687
[^3]: Fotios Petropoulos et al., “Operations & Supply Chain Management: Principles and Practice”, arXiv:2503.05749, section on planning problems by Christoph H. Glock and Ting Zheng. https://arxiv.org/pdf/2503.05749

