CMA CGM is a container shipping and logistics group whose parent company is governed by French law. The European Commission described CMA CGM in a 2016 decision as the parent company of an international group of companies involved in the sectors of containerised liner shipping and port terminal management, offering a range of services including shipping, reefer transport, handling facilities in port as well as freight transport and logistics on land.[^1]

## What CMA CGM says it does

CMA CGM’s own site describes it as a global player in sea, land, air and logistics solutions, committed to working hand in hand with customers.[^2] The page was read in a browser because the company's earlier address returned an error to automated requests.

## Change over time in independent descriptions

A later Commission decision, in the CEVA case, describes the group as the parent company, governed by the laws of France, of an international group of companies involved in container liner shipping, port terminal services and, to a much smaller extent, freight forwarding services through its subsidiary CMA CGM Logistics.[^3] Comparing the two decisions, the later one names freight forwarding explicitly, which the earlier description covers only as freight transport and logistics on land.[^1][^3]

The Alphaliner operator list consolidates CMA CGM, APL, ANL, CNC, CoMaNav, Containerships, Feeder Associate System, MacAndrews, Mercosul Line and SoFrana under the CMA CGM Group name for its ranking by fleet capacity.[^4] That shows that fleet figures for the group span several brands.

## Role in the supply chain

CMA CGM is an [[Ocean Carrier]] in this vault, because container liner shipping is the first activity in both Commission descriptions.[^1][^3] It also takes part in forwarding and terminals, so the group holds more than one role. See [[Container Shipping]].

## What the sources do not establish

Sources opened give no founding date, no headquarters statement other than the French law of the parent company, and no fleet or revenue figures. The independent UNCTAD tables could not be opened. The Commission descriptions are dated and describe the group at the time of each decision.[^1][^3]

[^1]: European Commission, Case M.7908 CMA CGM / NOL, decision of 29 April 2016. https://ec.europa.eu/competition/mergers/cases/decisions/m7908_1366_3.pdf
[^2]: CMA CGM Group, group and vision page. https://www.cmacgm-group.com/en/group-and-vision
[^3]: European Commission, Case M.9221 CMA CGM / CEVA, decision under Article 6(1)(b). https://ec.europa.eu/competition/mergers/cases1/202115/m9221_139_3.pdf
[^4]: Alphaliner (AXS Marine), PublicTop100 page, consolidated operator notes. https://alphaliner.axsmarine.com/PublicTop100/

