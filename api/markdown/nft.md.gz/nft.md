A Non-Fungible Token (NFT) is a cryptographic token deployed on a blockchain that encodes a unique, verifiable ownership claim over a specific digital or physical asset, distinguishing it from fungible tokens where every unit is interchangeable. The on-chain token record contains a unique identifier and owner address, while rich metadata and media assets are typically stored off-chain via IPFS, Arweave, or centralised hosting, with a content-addressed URI anchored in the token. Dominant standards include ERC-721 for individual unique tokens and ERC-1155 for semi-fungible batch collections on Ethereum-compatible chains, with equivalents on Solana (Metaplex), Tezos (FA2), and other ecosystems. NFTs enable programmable royalties, provenance tracking, and cross-platform digital ownership in domains spanning digital art, gaming, music, event ticketing, and real-world asset tokenisation.

### Overview

- NFTs emerged from early experiments with coloured coins on Bitcoin and Counterparty (2012–2014), crystallised into the ERC-721 standard on [[Ethereum]] (EIP-721, finalised January 2018), and gained mainstream attention through CryptoKitties (2017), digital art auctions (2021), and metaverse land sales.
- The fundamental value proposition is trustless provenance: any party can verify, on the public ledger, who owns a given token and the complete ownership history without relying on a centralised registry.
- NFTs separate the concept of ownership (on-chain) from the asset itself (typically off-chain), creating a novel ownership layer that can be programmed with royalty splits, transfer restrictions, and unlockable content.
- Criticisms include environmental cost on proof-of-work chains (largely mitigated by Ethereum's move to proof-of-stake in 2022), off-chain metadata fragility, and speculative market dynamics.

### Key Mechanisms

- **Minting**: A [[Smart Contract]] transaction assigns a unique token ID to a wallet address; the event is recorded immutably on the [[Blockchain]].
- **Token Standards**
  - [[ERC-721]]: the dominant single-token standard defining `ownerOf`, `transferFrom`, and `tokenURI` interfaces on [[Ethereum]]-compatible chains.
  - [[ERC-1155]]: multi-token standard supporting fungible, semi-fungible, and non-fungible tokens in one contract; reduces [[Gas Fees]] for large collections.
  - Metaplex (Solana), FA2 (Tezos), and RMRK (Polkadot) provide equivalent standards on alternative chains.
- **Metadata URI pattern**: `tokenURI()` returns a JSON document with name, description, image URL, and trait attributes. The URI is the primary architectural weakness — if the hosting service disappears, the NFT loses its associated content.
- **Content-addressed storage**: [[IPFS]] and [[Arweave]] mitigate URI rot by identifying content by its cryptographic hash, so the on-chain CID is sufficient to retrieve the asset from any node holding a copy.
- **Programmable royalties**: EIP-2981 defines a standard royalty interface allowing creators to receive a percentage of every secondary-market sale, enforced at the marketplace contract level.
- **[[Public Key Cryptography]]**: ownership is controlled via [[Wallet]] private keys; transferring an NFT requires a valid cryptographic signature from the current owner's key.

### Applications and Use Cases

- **Digital art and collectibles**: Artists mint limited editions; buyers gain verifiable scarcity. Platforms include OpenSea, Blur, and Foundation.
- **Gaming and virtual worlds**: In-game items, characters, and virtual land parcels represented as NFTs enable player-owned economies and cross-platform portability. Key examples: Axie Infinity, Decentraland, The Sandbox — all bridging NFTs to [[Metaverse]] environments.
- **Music and media**: Musicians tokenise albums, stems, and concert recordings to distribute royalties directly via [[Programmable Royalties]] and bypass intermediaries.
- **Event ticketing**: NFT tickets carry verifiable provenance, programmable resale caps, and post-event utility (e.g., backstage access unlockables), reducing fraud versus traditional barcodes.
- **Real-world asset tokenisation**: [[Real-World Asset Tokenisation]] maps physical assets (property deeds, luxury goods, fine wine) to on-chain NFTs, enabling fractional ownership and liquidity via [[Decentralised Finance]] protocols.
- **Identity and credentials**: Soulbound tokens (SBTs, non-transferable NFTs) proposed by Vitalik Buterin represent qualifications, reputation, and attestations — a bridge to [[Decentralised Identifier]]s and verifiable credentials.
- **Supply chain provenance**: NFTs attached to physical goods carry [[Provenance Tracking]] data through the supply chain, intersecting with [[Supply Chain]] management and IoT oracle feeds.
- **[[Digital Twin]]**: NFTs can serve as the ownership record for a [[Digital Twin]] of a physical product, linking real-world sensor data to a blockchain-anchored identity.
- **Spatial computing**: [[Spatial Computing]] platforms use NFTs to represent persistent 3D objects, wearables, and environments accessible in AR/VR layers.

### Standards and Context

- **EIP-721** (January 2018): the foundational Ethereum Improvement Proposal defining the non-fungible token interface; authored by William Entriken, Dieter Shirley, Jacob Evans, and Nastassia Sachs.
- **EIP-1155** (June 2019): multi-token standard by Witek Radomski (Enjin), enabling mixed fungible/non-fungible collections in a single contract.
- **EIP-2981**: NFT royalty standard providing a consistent royalty information retrieval interface for marketplaces.
- **EIP-4907**: rental standard (ERC-4907) separating owner and user roles with expiry, enabling time-limited NFT lending.
- **Metaplex**: the dominant NFT standard on Solana, supporting compressed NFTs (cNFTs) for drastically reduced minting costs.
- **IETF / W3C**: no formal cross-chain NFT standard exists at IETF level; W3C DID and VC specs intersect with soulbound token proposals.
- **Regulatory context**: NFTs have attracted securities law scrutiny in the US (SEC enforcement actions, 2023), AML/KYC requirements in the EU under MiCA (Markets in Crypto-Assets Regulation), and IP law debates around whether owning an NFT conveys copyright in the underlying work.
- The [[Ethereum Improvement Proposal]] process (governed by the Ethereum Foundation's EIP editors) is the primary standards governance mechanism for NFT token interfaces.

### Technical Architecture

- **On-chain component**: token ID, owner address, approval mappings, and total supply stored in contract storage slots on the [[Blockchain]].
- **Off-chain component**: JSON metadata file (name, description, image URI, attributes array) and the associated media file (image, audio, video, 3D model).
- **Metadata hosting options**:
  - Centralised (HTTP): lowest cost, highest fragility — single point of failure.
  - [[IPFS]]: content-addressed, peer-to-peer; requires pinning services (Pinata, nft.storage) for persistence.
  - [[Arweave]]: pay-once permanent storage with cryptoeconomic guarantees; preferred for high-value assets.
  - On-chain SVG/base64: fully on-chain metadata and image, maximally durable but expensive; used by Autoglyphs, Nouns DAO.
- **Gas optimisation patterns**: lazy minting (defer on-chain record until first sale), batch minting via ERC-1155, and compressed NFTs (Solana cNFTs using Merkle trees).
- **Marketplace interaction**: NFT marketplaces (OpenSea, Blur, Magic Eden) interact with token contracts via approval (`setApprovalForAll`) and listing mechanisms; royalty enforcement is market-level, not universally enforced at the protocol level.

### Criticisms and Limitations

- **Off-chain metadata fragility**: the most common failure mode — if the `tokenURI` host disappears, the NFT is an on-chain pointer to nothing.
- **Environmental cost**: proof-of-work minting (pre-Merge Ethereum) was energy-intensive; proof-of-stake chains have dramatically reduced per-transaction energy consumption.
- **Copyright misalignment**: purchasing an NFT typically conveys no copyright in the underlying work unless explicitly granted by the creator's terms; this is frequently misunderstood.
- **Wash trading and market manipulation**: thin secondary markets and low barriers to self-trading have inflated reported trading volumes on some platforms.
- **Smart contract risk**: bugs in minting or marketplace contracts have resulted in exploits and loss of funds (e.g., re-entrancy attacks).
- **Royalty enforcement**: without protocol-level enforcement, marketplaces can bypass creator royalties, undermining the creator-economy value proposition.

### Current Landscape (2026)

- The market has completed a "K-shaped" consolidation: 2025 annual trade volume fell to roughly $5.5-5.6 billion (down 37% year-on-year and ~95% below the 2021 peak), average sale prices slid to about $96, and monthly Ethereum volume stabilised near $720 million in early 2026 after bottoming around $480 million in 2024 — a small tier of blue-chip and utility collections retains liquidity while the long tail is effectively dead.
- The token-standard family has diversified well beyond static ERC-721/ERC-1155: ERC-6551 token-bound accounts (2023) give each NFT a smart-contract wallet that can own other assets, ERC-4337 account abstraction removes UX friction, ERC-4907 enables rentable NFTs, and experimental hybrids like ERC-404 (2024) and dynamic/AI standards such as ERC-7857 (iNFTs) and ERC-8004 (on-chain AI-agent identities) are emerging.
- Utility, not speculation, now drives activity: gaming NFTs command roughly 38% of on-chain transaction volume in 2026 (Immutable/Mythos titles like Guild of Guardians and DMarket), while real-world-asset tokenisation has become the institutional use case, with on-chain RWA value growing roughly fourfold to over $24-26 billion and real estate NFTs (e.g. DAMAC tokenising $1bn+ in property, Courtyard on Polygon) as the largest category.
- Marketplaces have consolidated and bifurcated: Blur overtook OpenSea to capture around 38% of Ethereum NFT volume via incentive-driven trading, low-friction AMM pools serve floor collections while order-book venues handle unique assets, and most new projects now launch on Layer 2s (Base, Zora, Immutable X, Arbitrum, Polygon) rather than Ethereum L1.
- Regulation shifted from "enforcement-first" to purpose-built frameworks: the EU's MiCA became fully applicable on 30 December 2024 (excluding genuinely unique NFTs but re-qualifying fractionalised or large-series tokens), DAC8 tax reporting took effect 1 January 2026, and the SEC closed its OpenSea investigation without charges on 21 February 2025 — though classification remains fragmented across the SEC, ESMA, FCA, MAS and Japan's FSA.
- Open challenges as of 2026: jurisdiction-specific securities/AML classification inflates compliance costs (reportedly up sixfold since 2023), royalty enforcement remains marketplace-dependent despite EIP-2981, centralised infrastructure fragility was exposed by 2025 data breaches, and scaling RWA tokenisation into durable, liquid market structure — rather than pilots — is the central frontier.

### References

- 1. Zipmex (2026). Are NFTs Dead in 2026? The Honest Market Breakdown. https://zipmex.com/blog/are-nfts-dead/
- 2. CleanSky (2026). The NFT Market in 2026: Post-Mortem of a Bubble, Birth of Digital Ownership. https://cleansky.io/blog/nft-market-2026/
- 3. Calmops (2026). NFT Standards and Marketplace Architecture 2026. https://calmops.com/web3/nft-standards-marketplace-architecture/
- 4. CoinLaw (2026). NFT Regulatory Framework 2026: Global Compliance Map. https://coinlaw.io/nft-regulatory-framework/
- 5. CoinMarketCap (2026). NFT Supply Hits 1.3B as Sales Drop 37% in 2025. https://coinmarketcap.com/academy/article/nft-supply-hits-13b-sales-drop-37-percent-2025
- 6. Bitcoin.com News (2026). NFT Market Matures in 2025: Utility, Gaming, and RWA Drive Growth. https://news.bitcoin.com/nft-market-matures-in-2025-utility-gaming-and-rwa-drive-growth/

### Provenance

