An IoT sensor is a networked device that measures physical or environmental conditions — such as temperature, humidity, location, vibration or light — and transmits the resulting data over a communications network to back-end systems for monitoring and analysis. By embedding sensing and connectivity into assets and environments, IoT sensors provide continuous, real-time visibility that supports automation and data-driven decisions. In supply chains they are central to cold-chain monitoring, asset tracking and condition-based maintenance.

### Overview

- IoT sensors combine a sensing element, embedded processing, power management and a network interface into a compact, often battery-powered device. They sample physical quantities on a schedule or by event, may pre-process readings at the edge to reduce bandwidth, and stream data to gateways or cloud platforms over wireless protocols. In supply chains, fleets of such sensors yield granular, time-stamped records of where goods are and the conditions they experience, feeding traceability systems and, via oracles, even blockchain-based provenance ledgers.

### Key aspects

- Sensing modalities: temperature, humidity, GPS, vibration
- Edge pre-processing and data reduction
- Wireless connectivity and gateways
- Power and battery-life constraints
- Calibration, drift and data quality
- Integration with oracles and ledgers

### Applications

- Cold-chain monitoring for food and pharmaceuticals
- Real-time asset and shipment tracking
- Condition-based maintenance of equipment
- Feeding traceability and provenance systems
- Supplying verified data to blockchain oracles

### Provenance

