Python is a high-level, dynamically typed, interpreted programming language designed by Guido van Rossum with an explicit emphasis on code readability, expressive syntax, and developer productivity. Its reference implementation, CPython, executes code via a bytecode interpreter protected by the Global Interpreter Lock (GIL), whilst third-party runtimes such as PyPy provide JIT compilation for CPU-bound workloads. Python's extensive standard library and the PyPI ecosystem—encompassing NumPy, Pandas, PyTorch, TensorFlow, Scikit-learn, and the Hugging Face stack—have established it as the dominant language for machine learning research, data science, scientific computing, and AI infrastructure automation. Its clean syntax, interactive tooling via Jupyter notebooks, and first-class cloud-platform support have made it the lingua franca of artificial intelligence development globally.

### Overview

- Python prioritises developer productivity and code clarity over raw execution speed, operating on the principle that code is read more often than it is written.
- The reference implementation, CPython, compiles source to bytecode and executes it through a stack-based virtual machine protected by the Global Interpreter Lock (GIL), which simplifies memory management but constrains true multi-threaded CPU parallelism.
- For compute-intensive workloads, this constraint is immaterial: libraries such as [[NumPy]], [[PyTorch]], and [[TensorFlow]] delegate numerical operations to C, C++, or CUDA extensions that release the GIL, achieving GPU-accelerated throughput.
- Python 3, introduced in 2008 with breaking changes from Python 2, is the sole maintained branch; Python 2 reached end-of-life in January 2020.
- The language is governed by the Python Software Foundation (PSF) and evolves through the PEP (Python Enhancement Proposal) process, with a yearly release cadence (e.g. Python 3.12, 3.13).
- Python's interactive REPL and [[Jupyter Notebook]] integration support rapid experimentation, a critical property for iterative [[Machine Learning]] research.

### Key Components

- **CPython runtime**: The reference interpreter; compiles `.py` source to `.pyc` bytecode; implements the GIL; releases are the canonical Python versions.
- **Python Standard Library**: 200+ built-in modules covering I/O, networking, concurrency (`asyncio`, `concurrent.futures`), cryptography, JSON/XML parsing, and more.
- **PyPI (Python Package Index)**: The canonical repository for third-party packages, hosting over 500,000 distributions; accessed via `pip`.
- **Virtual environments**: `venv`, `virtualenv`, and `conda` provide isolated dependency namespaces; `poetry` and `uv` offer modern dependency resolution and lock-file management.
- **Type annotation system**: PEP 484 introduced type hints; PEP 526 added variable annotations; `mypy`, `Pyright`, and `Ruff` provide static analysis and linting for large codebases.
- **Alternative runtimes**:
  - [[PyPy]]: JIT-compiled Python, 2–10× faster for CPU-bound pure-Python code.
  - MicroPython: Minimal Python 3 implementation for microcontrollers and embedded systems.
  - Cython: Python superset that compiles to C for performance-critical extensions.
  - Numba: LLVM-based JIT compiler targeting NumPy array operations and CUDA kernels.
- **Asynchronous I/O**: `asyncio` event loop (PEP 3156) and `async/await` syntax enable high-concurrency network services without OS-thread overhead; underpins frameworks such as FastAPI and aiohttp.
- **C extension API**: The CPython C-API and `ctypes`/`cffi` allow Python to bind to native libraries; `pybind11` and `nanobind` simplify C++ binding authorship.

### Scientific & AI Ecosystem

- **[[NumPy]]**: N-dimensional array library providing BLAS/LAPACK-backed linear algebra; the foundational dtype and memory model for the entire scientific stack.
- **[[SciPy]]**: Algorithms for integration, optimisation, signal processing, sparse matrices, and statistics built on NumPy arrays.
- **[[Pandas]]**: Labelled, columnar data manipulation (DataFrame/Series); the standard for tabular data wrangling in [[Data Science]] pipelines.
- **[[Matplotlib]] / Seaborn / Plotly**: Visualisation libraries ranging from publication-quality static figures to interactive web charts.
- **[[PyTorch]]**: Dynamic computation graph framework developed at Meta; dominant in [[Deep Learning]] research; supports eager and compiled (torch.compile / XLA) execution modes.
- **[[TensorFlow]] / Keras**: Google's ML framework; wide production deployment; `tf.keras` high-level API; TFLite and TFX for on-device and pipeline tooling.
- **[[Scikit-learn]]**: Classical [[Machine Learning]] algorithms (SVMs, random forests, gradient boosting, dimensionality reduction); consistent `fit`/`predict` API; integrates with NumPy and Pandas.
- **Hugging Face Transformers**: Pre-trained [[Transformer]] model hub and training toolkit; abstracts PyTorch, TensorFlow, and JAX backends; central to modern [[Natural Language Processing]] and [[Computer Vision]] workflows.
- **JAX**: NumPy-compatible array library from Google with automatic differentiation and XLA JIT compilation; used in Flax and Equinox neural network libraries.
- **[[Jupyter Notebook]] / JupyterLab**: Browser-based interactive computing environments; de facto standard for exploratory [[Data Science]] and ML experimentation.

### Applications / Use Cases

- **[[Machine Learning]] research and development**: prototyping models, hyperparameter tuning, experiment tracking (MLflow, Weights & Biases).
- **[[Data Science]] and analytics**: data ingestion, cleaning, feature engineering, statistical modelling, and reporting pipelines.
- **[[Natural Language Processing]]**: tokenisation, embedding, fine-tuning and inference of language models via Hugging Face, spaCy, NLTK.
- **[[Computer Vision]]**: image preprocessing (Pillow, OpenCV), model training (torchvision, Albumentations), and deployment (ONNX runtime, TensorRT bindings).
- **[[Robotics]] and autonomous systems**: ROS 2 node authorship via `rclpy`; physics simulation via PyBullet, MuJoCo-py, and Isaac Gym.
- **[[Infrastructure as Code]] and DevOps**: Ansible playbooks, AWS CDK (Python bindings), Terraform providers, and Kubernetes operators via the Python Kubernetes client.
- **[[Web Framework]] services**: Flask, Django, FastAPI for REST and GraphQL APIs; Celery for distributed task queues.
- **[[Knowledge Graph]] tooling**: rdflib (RDF/SPARQL), owlready2 (OWL reasoning), SPARQLWrapper; Python scripts power RDF serialisation pipelines in ontology engineering projects.
- **[[Scientific Computing]] and simulation**: astronomical computation (Astropy), bioinformatics (Biopython), quantum computing (Qiskit), computational chemistry (RDKit).
- **Finance and quantitative analysis**: QuantLib, zipline, backtrader; Python dominates quantitative finance prototyping before hand-off to low-latency C++ systems.
- **[[Smart Contract]] and blockchain tooling**: Web3.py for Ethereum interaction; Brownie and Ape frameworks for Solidity contract testing and deployment.

### Standards & Context

- **PSF (Python Software Foundation)**: Governs the CPython reference implementation, PSF Licence, and trademark policy; non-profit incorporated in Delaware, USA.
- **PEP process**: Python Enhancement Proposals are the change-management mechanism; notable PEPs include PEP 8 (style guide), PEP 20 (Zen of Python), PEP 484 (type hints), PEP 572 (walrus operator), PEP 634 (structural pattern matching).
- **PEP 668 / pyproject.toml (PEP 517/518/660)**: Standardised build-system declarations and source distribution metadata; replaced setup.py as the canonical project descriptor.
- **PEP 703**: Proposed removal of the GIL (free-threaded CPython), implemented as an experimental option in CPython 3.13 under the `--disable-gil` build flag; enables true multi-threaded CPU parallelism.
- **WSGI / ASGI**: PEP 3333 (WSGI) and the ASGI specification (Encode.io) define the Python server-gateway interfaces underpinning all major Python web frameworks.
- **ONNX and ML interoperability**: Python is the primary language for exporting and importing models via the Open Neural Network Exchange (ONNX) format, enabling cross-framework deployment.
- **IEEE / ISO**: Python is referenced in various IEEE software-engineering and AI-ethics standards as an example of high-level interpreted language use in safety-critical and AI systems.

### Provenance

