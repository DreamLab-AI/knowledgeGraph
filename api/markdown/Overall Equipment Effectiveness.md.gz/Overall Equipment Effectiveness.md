Overall equipment effectiveness (OEE) is a total productive maintenance measure of how effectively equipment is being used.[^1]

The Lean Enterprise Institute says OEE is calculated from three elements and that they are multiplied. The availability rate measures downtime losses from equipment failures and adjustments as a percentage of scheduled time. The performance rate measures operating speed losses, running at speeds lower than design speed and stoppages lasting a few seconds. The quality rate expresses losses due to scrap and rework as a percentage of total parts run.[^1]

## Calculation

The Tennessee Manufacturing Extension Partnership guide states OEE as the product of three percentages, each calculated independently and then multiplied together.[^2] It gives availability as run time divided by planned production time, performance as ideal cycle time multiplied by total pieces, divided by run time, and quality as good pieces divided by total pieces.[^2] The Lean Enterprise Institute adds that OEE typically focuses on six major losses: failures, adjustments, minor stoppages, reduced operating speeds, scrap and rework, though some companies add other measures.[^1]

## Use and limits

The Tennessee guide describes OEE as a tool for finding losses, not a scorecard to game.[^2] Related practice is described at [[Total Quality Management]], [[Predictive Maintenance]] and [[Condition Monitoring]].

ISO 22400-2:2014 specifies a selected number of key performance indicators for manufacturing operations management, each presented by its formula and elements, time behaviour and unit.[^3] The catalogue abstract opened does not list the indicators, so this page cannot say whether or how the standard defines OEE. The same record says the standard is expected to be replaced by a draft revision.[^3]

## What the sources do not establish

OEE is an equipment measure from the shop floor. None of the sources opened places it within supply chain performance measurement, so its listing under [[Supply Chain Performance Measure]] follows the domain catalogue and not a source. The sources give no benchmarks that this page endorses.[^1][^2][^3]

[^1]: Lean Enterprise Institute, “Overall Equipment Effectiveness”, Lean Lexicon. https://www.lean.org/lexicon-terms/overall-equipment-effectiveness/
[^2]: Tennessee Manufacturing Extension Partnership, “OEE Implementation Guide for Manufacturers | How to Calculate OEE”. https://tmep.cis.tennessee.edu/oee-implementation-guide
[^3]: ISO, “ISO 22400-2:2014 - Automation systems and integration — Key performance indicators (KPIs) for manufacturing operations management — Part 2: Definitions and descriptions” (catalogue record). https://www.iso.org/standard/54497.html

