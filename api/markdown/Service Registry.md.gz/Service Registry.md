A Service Registry is a database of available service instances and their network locations that underpins dynamic service discovery in distributed and microservice architectures. Instances register on startup and deregister on shutdown, while clients or load balancers query the registry to resolve a logical service name to a healthy endpoint. Health checks expire stale entries, keeping the registry an accurate view of live topology in elastic, frequently changing deployments.

### Overview

- **Service Registry** sits within the [[Service Discovery]] area of the distributed systems domain.
- It is referenced by existing classes in the knowledge graph and is materialised here as a defined, rooted node so those edges resolve.

### Key aspects

- Establishes a precise, shared meaning for service registry usable across coordinating components.
- Integrates with neighbouring concepts through the relations enumerated below.
- Maturity assessed as established based on established practice and literature.

### Mechanisms

- Operates through the dependencies and components captured in its `requires`, `uses`, and `hasPart` relations.
- Produces the capabilities captured in its `enables` and `supports` relations.

### Applications

- Applied wherever distributed systems systems need the function described above.
- Connects to broader workflows via the bridging relations listed below.

### Provenance

