Lean production is a business system for organising and managing product development, operations, suppliers and customer relations that, compared with mass production, requires less human effort, space, capital, material and time to make products with fewer defects to precise customer desires.[^1]

The Lean Enterprise Institute adds that Toyota pioneered lean production after World War II and that John Krafcik, a research assistant at MIT, coined the term in the late 1980s.[^1] The Institute also describes lean as a way of thinking about creating needed value with fewer resources and less waste, and as a practice of continuous experimentation, with thinking and practice occurring together.[^2]

## Aims and origins

An open operations management text defines waste in the lean world as any activity or condition that consumes resources but creates no value for customers, and says the ultimate objective of lean is the avoidance of muda, or wasteful activity, in all business operations.[^3] It says most lean tools and techniques were developed by Toyota in Japan beginning in the 1950s, and that the term came into widespread use with the 1990 book The Machine That Changed the World.[^3] It adds that lean was initially focused on improving manufacturing operations but is now used for product development, order processing and other nonmanufacturing processes.[^3] Toyota describes its own production system as a way of making things whose objective is to thoroughly eliminate waste and shorten lead times, pursued by all employees through daily incremental kaizen.[^4]

## Scope and distinctions

Lean production is filed here as a production management philosophy; see [[Production Management Philosophy]]. The Lean Enterprise Institute defines it by contrast with the previous system of mass production, so it is distinct from [[Mass Production]].[^1] The Toyota Production System, as Toyota presents it, rests on two pillars, and the second is just-in-time; see [[Just-in-Time Production]].[^4] The tools usually attached to lean are covered at [[Kaizen]], [[Kanban]] and [[Takt Time]]. Applied across the organisations of a chain, see [[Lean Supply Chain]].

That text calls lean a system of nonfinancial controls used to improve product and service quality and decrease waste.[^3]

## What the sources do not establish

Lean production, lean manufacturing and the Toyota Production System are used close to interchangeably in these sources, and none states exact boundaries between them. The Lean Enterprise Institute is the main origin for the definition, so its wording is not independently checked; the textbook and Toyota corroborate the Toyota origin and the focus on waste only.

[^1]: Lean Enterprise Institute, “Lean Production (Lean Lexicon)”. https://www.lean.org/lexicon-terms/lean-production/
[^2]: Lean Enterprise Institute, “What is Lean?”. https://www.lean.org/explore-lean/what-is-lean/
[^3]: Business LibreTexts (Introduction to Operations Management, NWTC), “10.1: Lean Manufacturing and Control”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/10:_Just_in_Time_Lean_Systems/10.01:_Lean_Manufacturing_and_Control
[^4]: Toyota Motor Corporation, “Toyota Production System”. https://global.toyota/en/company/vision-and-philosophy/production-system/

