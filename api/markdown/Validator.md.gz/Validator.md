A validator is a network participant in a proof-of-stake blockchain that is responsible for proposing new blocks, attesting to the validity of blocks proposed by others, and participating in the finality mechanism of the network. Validators commit a quantity of cryptocurrency as collateral (stake), which is subject to slashing — partial or total confiscation — if the validator behaves dishonestly or fails liveness requirements. Through their collective attestations and proposals, validators form the active set that drives consensus and maintains the canonical chain history.

### Overview

- Validators are the operational heartbeat of any [[Proof of Stake]] network. Rather than competing to solve hash puzzles as [[Miner]]s do in [[Proof of Work]] systems, validators are pseudorandomly selected — weighted by their staked balance — to perform two core duties: proposing new [[Block]]s and attesting to valid blocks proposed by others.
- The selection and scheduling of validators is managed by the [[Consensus Protocol]]. In Ethereum's Beacon Chain, for example, validators are organised into committees and assigned duties each epoch. A randomly chosen proposer broadcasts a block; the rest of the committee issues attestations that collect into an aggregate signature.
- The validator's stake serves as a bond. Honest participation earns incremental [[Staking]] rewards (new token issuance plus transaction fees). Provable violations — double-voting, surround voting, prolonged offline periods — trigger [[Slashing]], burning a portion of the bond and forcibly exiting the validator. This mechanism aligns economic incentives with protocol correctness and is foundational to [[Byzantine Fault Tolerance]].
- Validators participate in the [[Peer-to-Peer Network]], gossiping blocks and attestation data via libp2p or equivalent transport layers. Their combined attestations drive [[Block Finality]], making chain reversion computationally and economically prohibitive once enough stake has attested.

### Key Mechanisms

- **Block Proposal**
  - Each slot, one validator from the active set is selected as the block proposer via a RANDAO-based randomness beacon.
  - The proposer bundles transactions from the mempool into a [[Block]], adds execution payload data, signs it, and broadcasts it.
  - See also: [[Block Proposal]], [[Transaction]], [[Mempool]]
- **Attestation**
  - After a proposal, committee members each sign an [[Attestation]] message declaring the head of the chain they perceive as canonical.
  - Attestations are aggregated using BLS signature schemes, compressing hundreds of individual signatures into a single constant-size proof.
  - Aggregated attestations are included in subsequent blocks, creating a running record of committee agreement.
  - See also: [[BLS Signature]], [[Validator Committee]]
- **Finality**
  - Under Casper FFG (Ethereum) or Tendermint-style protocols, validators vote on checkpoint blocks. When a supermajority (typically two-thirds of staked weight) attests to a checkpoint, the chain segment up to that point is finalised.
  - [[Block Finality]] means the chain cannot be reorganised without burning at least one-third of total stake — making attacks economically catastrophic.
- **Slashing**
  - [[Slashing]] conditions are protocol-enforced penalties for equivocation (double-proposing or double-voting) and surround voting.
  - Slashing proofs can be submitted by any network participant, incentivising a vigilant watchtower ecosystem.
  - Penalties scale with the proportion of validators simultaneously misbehaving (correlation penalty), making coordinated attacks especially costly.
- **Inactivity Leak**
  - If the chain cannot finalise due to widespread validator absence, an inactivity leak gradually reduces the stake of offline validators until the remaining active set constitutes a supermajority.
  - This mechanism preserves [[Byzantine Fault Tolerance]] even under extreme partition events.
- **Validator Lifecycle**
  - Deposit → Pending → Active → Exiting → Withdrawn
  - Entry and exit queues are rate-limited to prevent sudden stake mass-movements from destabilising the active set.

### Validator Committees and Set Management

- The active validator set is typically capped or rotated to balance decentralisation with communication overhead. Ethereum's Beacon Chain supports hundreds of thousands of active validators; many other chains cap the set at dozens to hundreds to maintain fast [[Consensus Mechanism]] rounds.
- **Committees**: validators are shuffled pseudorandomly into committees each epoch. Committee size balances statistical security (each committee must be large enough that an adversary is unlikely to control a supermajority) against latency.
- **Shuffling algorithms**: Fisher-Yates shuffle seeded by RANDAO ensures unpredictability while remaining verifiable on-chain.
- **Delegation and Liquid Staking**: users below the minimum stake threshold can delegate tokens to a validator via [[Liquid Staking]] protocols (e.g. Lido, Rocket Pool), receiving a liquid derivative token representing their staked position.

### Applications and Use Cases

- **Layer 1 Proof-of-Stake Chains**: Ethereum (post-Merge), Cosmos SDK chains, Polkadot, Cardano, Solana, Avalanche — all rely on validators as the primary security mechanism.
- **Layer 2 Sequencer Decentralisation**: [[Rollup]] networks are moving toward decentralised sequencer sets using validator-like mechanisms, where sequencers stake tokens to earn the right to order transactions.
- **Cross-Chain Bridges**: bridge protocols use a validator set (often a multisig or BLS committee) to attest to events on one chain and trigger actions on another. See [[Cross-Chain Bridge]].
- **Oracle Networks**: [[Decentralised Oracle]] networks such as Chainlink use staked node operators — functionally validators — to attest to off-chain data delivered on-chain.
- **Restaking**: through protocols like EigenLayer, Ethereum validators can opt in to validate additional services (AVSs), extending their economic security to [[Decentralised Finance]] primitives, data availability layers, and more.
- **Governance Participation**: in many networks, active validators also have weighted [[Governance]] voting rights proportional to their stake or delegation, directly influencing protocol upgrades.

### Comparison with Miners

| Property | Validator (PoS) | Miner (PoW) |

| --- | --- | --- |

| Resource commitment | Staked tokens | Energy + hardware |

| Selection mechanism | Pseudo-random (stake-weighted) | Hash-race competition |

| Penalty for misbehaviour | Slashing of stake | Wasted electricity |

| Environmental footprint | Negligible | High |

| Barrier to entry | Minimum stake threshold | Capital expenditure on ASICs |

| Finality | Economic finality in seconds–minutes | Probabilistic, grows with confirmations |

### Standards & Context

- **Ethereum Beacon Chain (EIP-3675)**: formal specification of the Ethereum validator lifecycle, duties, and slashing conditions under the Proof-of-Stake transition.
- **Cosmos Tendermint BFT**: defines a bounded active-validator set with deterministic round-robin proposer selection and instant finality.
- **Polkadot NPoS (Nominated Proof of Stake)**: nominators back validators with their stake; the election mechanism (Phragmén algorithm) optimises stake distribution to avoid centralisation.
- **Casper FFG / LMD-GHOST**: Ethereum's hybrid finality gadget layered atop a fork-choice rule; the interplay between the two mechanisms defines when validators' attestations become canonical.
- **IEEE P2418 / ISO TC307**: emerging blockchain standardisation efforts that address roles and responsibilities of network participants including validator-equivalent roles.
- **BLS12-381 curve**: the elliptic curve underlying BLS signature aggregation used in Ethereum validator attestations, balancing security and efficiency.

### Provenance

