
A payment intent is an [[Agent Intent]] to transfer value from one agent to another. The Agent Ontology declares it as `PaymentIntent`, a subclass of `Intent`.[^1]

Six properties describe it. `payer` and `payee` both range over an [[Agent Entity]], so either party may be an agent, a person or an organisation. `amount` is an `xsd:decimal`, `unit` a string naming what the amount is measured in, and `reason` a string giving the purpose. `hasSettlementInterface` ranges over a [[Settlement Interface]], which says how the transfer would be completed.

An intent in this sense states a desire to pay; it is not the settlement itself. The unit is unconstrained, so currencies, tokens and other measures all fit. A payer draws on a [[Wallet]] from its [[Agent Wallet Set]] to fund the transfer, and the wider field is covered by [[AI Agent Payments]].

visionGraph treats the payment intent, the settlement interface and the wallet as three separate concerns: what is wanted, how it is completed, and where the value is held.

[^1]: Semantic Agent Communication Community Group, “Payment Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/payment.ttl

