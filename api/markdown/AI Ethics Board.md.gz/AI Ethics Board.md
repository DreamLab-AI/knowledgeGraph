An AI Ethics Board is a formally constituted, multidisciplinary oversight committee responsible for reviewing AI systems and deployments against ethical principles, organisational values, and applicable regulatory requirements. Comprising technical experts, ethicists, legal and compliance professionals, domain specialists, and stakeholder representatives, the board conducts structured ethical impact assessments, provides binding or advisory guidance on AI deployment decisions, and monitors deployed systems for ongoing compliance. It serves as a key institutional mechanism for operationalising responsible AI principles and maintaining human oversight of consequential automated decision-making.

### Semantic Classification

### Content

AI Ethics Boards emerged as a governance mechanism in response to growing recognition that consequential AI deployments — in hiring, lending, criminal justice, healthcare, and public services — require structured human oversight beyond technical quality assurance. The structural precedent is the Institutional Review Board (IRB) model from biomedical research ethics, adapted for AI's distinct challenges: rapid iteration cycles, opacity of model internals, emergent behaviours, and cross-domain deployment.

Effective boards operate through a defined review lifecycle. Proposal intake involves AI project teams submitting structured descriptions of the system's purpose, data sources, affected populations, and planned mitigations. Expert deliberation engages board members from relevant disciplines — a clinical ethicist for a medical AI, a criminologist for a predictive policing system, a civil rights attorney for a credit-scoring model. Stakeholder consultation may include community members from affected groups, whose lived experience of algorithmic harms provides evidence not captured in technical audits. The board issues a decision — approval, conditional approval, deferral, or rejection — with documented rationale, creating an accountability trail.

Board authority varies significantly between organisations. Advisory boards provide guidance but lack binding power; approval boards exercise veto rights over deployments; monitoring boards conduct post-deployment audits with authority to mandate changes or decommissioning. The EU AI Act (2024) mandates conformity assessments for high-risk AI systems that parallel the functions of an ethics board, elevating this from voluntary best practice to regulatory requirement for EU-market AI.

Common structural weaknesses include insufficient independence (board members are internal employees subject to business pressure), lack of technical capacity among non-technical members, inadequate ongoing monitoring relative to initial review emphasis, and absence of external accountability for board decisions. Models such as Microsoft's Aether committee, Google's (now disbanded) external AI ethics council, and Mastercard's AI Ethics Principles demonstrate the range of implementation approaches. The IEEE P7000 series and ISO/IEC 42001:2023 provide standardised process guidance for AI ethics governance programmes that AI Ethics Boards can reference and implement.

### Provenance

