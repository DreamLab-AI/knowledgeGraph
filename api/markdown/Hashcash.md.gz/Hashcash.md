Hashcash is a proof-of-work system invented by Adam Back in 1997 that requires a sender to compute a partial SHA-1 (later SHA-256) hash collision by finding a nonce such that the resulting digest has a specified number of leading zero bits. The asymmetry between expensive computation and cheap verification makes it suitable as an anti-abuse token: the sender bears a measurable cost while the recipient verifies in microseconds. Originally designed to combat email spam and denial-of-service attacks, the mechanism was directly adopted by Bitcoin as the basis of its mining consensus algorithm, making Hashcash one of the foundational primitives of the blockchain era.

### Overview

- Hashcash addresses a fundamental asymmetry problem in open communication channels: senders bear near-zero cost to flood recipients, while recipients bear the full cost of filtering. By requiring each message or transaction to carry a proof that real computation was expended, Hashcash shifts cost back to the initiator.
- The protocol is built on [[Preimage Resistance]], a core property of [[Cryptographic Hash Function]]s: there is no faster route to finding a valid nonce than exhaustive search. This makes the puzzle non-parallelisable in any fundamentally clever way — brute force is the only strategy.
- Because verification only requires hashing the presented token once and checking the leading bits, the verifier's workload is O(1) while the prover's is O(2^d) where d is the required number of leading zero bits (the difficulty).
- Adam Back published the original Hashcash paper in 1997 and implemented it for email anti-spam. The system saw moderate adoption in anti-spam tools before [[Satoshi Nakamoto]] incorporated the same mechanism into [[Bitcoin Protocol]] in 2008, citing Back's work directly in the Bitcoin whitepaper.

### Key Mechanisms

- **Partial Hash Collision**
  - A valid Hashcash token is a string (or structured header) whose [[SHA-256]] (originally [[SHA-1]]) digest has at least d leading zero bits.
  - Finding such a token requires iterating the [[Nonce]] field until the condition is satisfied. Expected iterations: 2^d.
  - The verifier checks validity in one hash operation — no iterative work required.
- **Token Format**
  - The original email format: `X-Hashcash: version:bits:date:resource:rand:counter`
  - Fields include the target resource (email address), a date to prevent reuse, random salt, and the counter (nonce).
  - [[Bitcoin Protocol]] generalises this to a block header containing a [[Merkle Tree]] root, timestamp, difficulty target, and nonce.
- **Difficulty Adjustment**
  - The number of required leading zeros (d) controls how hard the puzzle is. More zeros → exponentially more work.
  - [[Bitcoin Protocol]] uses a [[Difficulty Adjustment]] algorithm that recalibrates every 2016 blocks to maintain a ~10-minute block interval as total [[Mining]] hash rate changes.
- **Double-Spend Prevention**
  - In [[Bitcoin Mining]], valid proof-of-work seals a block. Reversing a transaction would require recomputing that block's proof and all subsequent blocks faster than honest miners build new ones — the [[51 Percent Attack]] problem.
- **Nonce Exhaustion**
  - The 32-bit nonce field in a Bitcoin block header can be exhausted without finding a valid hash. Miners extend the search space using the [[Extra Nonce]] field in the coinbase transaction, effectively widening the search space arbitrarily.

### Applications and Use Cases

- **Email Spam Prevention**
  - The original motivation: attach a Hashcash stamp to each outgoing email. Legitimate senders tolerate a fraction of a second per email; bulk spammers cannot scale to millions of stamps. Deployed in spam filters including Apache SpamAssassin.
- **Bitcoin and Cryptocurrency Mining**
  - [[Bitcoin Mining]] directly inherits Hashcash's algorithm using [[SHA-256]] double-hash. Miners compete to produce valid block headers, earning block rewards and transaction fees. This is the primary large-scale deployment of Hashcash in the world today.
- **Denial of Service Protection**
  - Web servers and APIs can require clients to compute a Hashcash-style puzzle before servicing a request, raising the cost of flooding attacks. See [[Denial of Service Protection]] and [[Rate Limiting]].
- **Cryptocurrency Alternatives**
  - [[Litecoin]] and other [[Altcoin]]s adapted Hashcash-style PoW with alternative hash functions (e.g. Scrypt) to change the hardware trade-off profile.
- **Computational Fairness Tokens**
  - Research into [[Verifiable Delay Function]]s and [[Memory-Hard Function]]s builds on Hashcash's insight that computational cost can be a proxy for honest participation in [[Distributed Consensus]] systems.
- **Anti-Bot Challenges**
  - Hashcash-style client puzzles have been proposed as alternatives to [[CAPTCHA]], shifting challenge cost to computation rather than human cognitive labour.

### Technical Deep-Dive

- **Hash Function Selection**
  - The original Hashcash used [[SHA-1]]. Bitcoin adopted [[SHA-256]] double-hash (SHA-256(SHA-256(header))) for stronger collision resistance. The double-hash guards against length-extension attacks inherent in the Merkle–Damgård construction.
- **ASIC Specialisation**
  - Bitcoin's SHA-256 PoW is highly amenable to custom silicon. Application-Specific Integrated Circuits ([[ASIC]]) now dominate Bitcoin [[Mining]], producing hash rates many orders of magnitude beyond CPUs and GPUs. This centralisation pressure is a recognised trade-off of Hashcash-style PoW.
- **Memory-Hard Alternatives**
  - To resist ASIC dominance, successor schemes such as Scrypt (used by [[Litecoin]]) and Ethash (used by [[Ethereum]] prior to its merge) introduced [[Memory-Hard Function]] requirements, forcing miners to hold large datasets in RAM rather than pure compute throughput.
- **Selfish Mining and Game Theory**
  - Hashcash-based PoW creates game-theoretic incentives studied in [[Mechanism Design]] and [[Cryptoeconomics]]. Selfish mining attacks show that miners with more than ~33% of hash power can gain disproportionate rewards by withholding valid blocks strategically.
- **Energy Consumption**
  - The intentional wastefulness of Hashcash-style computation is both its security guarantee and its principal criticism. [[Proof of Stake]] consensus mechanisms were developed partly to eliminate this energy expenditure while retaining [[Sybil Resistance]].

### Standards and Context

- Adam Back's original specification: "Hashcash — A Denial of Service Counter-Measure" (1997, revised 2002).
- Bitcoin whitepaper (Nakamoto, 2008) cites Hashcash as the PoW primitive directly.
- [[IETF]] has no formal RFC for Hashcash as a standalone standard; the email header format (`X-Hashcash`) was informally adopted.
- SHA-256 standardised by [[NIST]] in FIPS 180-4, which underpins Bitcoin's adaptation of Hashcash.
- The [[Cypherpunk]] movement's prior work on digital postage (Wei Dai's b-money, Nick Szabo's Bit Gold) drew on related computational cost concepts before Back formalised Hashcash.

### Provenance

