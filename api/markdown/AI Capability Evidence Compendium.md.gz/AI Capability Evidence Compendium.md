A curated reference document compiling empirical evidence countering common objections to AI capability and originality claims, aggregating benchmarks, research findings, and expert commentary demonstrating that large language models exhibit reasoning, world-model construction, and generalisation beyond stochastic pattern matching. Serves as an evidence base for constructive discourse on AI capabilities and their societal implications.

### Semantic Classification

### Content

- [AI Defense Doc (google.com)](https://docs.google.com/document/u/0/d/15myK_6eTxEPuKnDi5krjBM_0jrv3GELs8TGmqOYBvug/mobilebasic#h.gboye8hkf0r8)  << from here

# General

- [ChatGPT can do chemistry research better than AI designed for it and the creators didn’t even know]([https://youtu.be/0b03ibtVYhw?feature=shared&t=447](https://youtu.be/0b03ibtVYhw?feature=shared&t=447))
- Claude 3 solves a problem thought to be impossible for LLMs to solve: [https://www.reddit.com/r/singularity/comments/1byusmx/someone_prompted_claude_3_opus_to_solve_a_problem/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1byusmx/someone_prompted_claude_3_opus_to_solve_a_problem/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- Tech titans considering job replacement with AI: [https://www.reddit.com/r/singularity/comments/1by5sj7/tech_titans_assemble_to_decide_which_jobs_ai_can/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1by5sj7/tech_titans_assemble_to_decide_which_jobs_ai_can/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- Jon Stewart is afraid of AI: [https://www.reddit.com/r/Futurology/comments/1bx6tk5/jon_stewart_on_ai_its_replacing_us_in_the/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/Futurology/comments/1bx6tk5/jon_stewart_on_ai_its_replacing_us_in_the/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- Can analyze sentiment after only being trained on Amazon reviews: [https://www.reddit.com/r/singularity/comments/1c0wi9g/comment/kyzqrhh/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1c0wi9g/comment/kyzqrhh/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- AI beat humans at being persuasive: [https://www.reddit.com/r/singularity/comments/1bto2zm/ai_chatbots_beat_humans_at_persuading_their/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1bto2zm/ai_chatbots_beat_humans_at_persuading_their/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- AI can make healthcare better and safer: [https://www.reddit.com/r/singularity/comments/1brojzm/ais_will_make_health_care_safer_and_better/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1brojzm/ais_will_make_health_care_safer_and_better/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- [AI beats humans at basic tasks](https://www.nature.com/articles/d41586-024-01087-4): [https://www.nature.com/articles/d41586-024-01087-4](https://www.nature.com/articles/d41586-024-01087-4)
- [ChatGPT scores in top 1% of creativity]([https://scitechdaily.com/chatgpt-tests-into-top-1-for-original-creative-thinking/](https://scitechdaily.com/chatgpt-tests-into-top-1-for-original-creative-thinking/))
- AutoCodeRover resolves ~**16%** of issues of [SWE-bench](https://www.swebench.com/) (total 2294 GitHub issues) and ~**22% of **issues of [SWE-bench lite](https://www.swebench.com/lite.html) (total 300 GitHub issues), improving over the current state-of-the-art efficacy of AI software engineers
- [https://github.com/nus-apr/auto-code-rover](https://github.com/nus-apr/auto-code-rover)
- Keep in mind these are from popular repos, meaning even professional devs and large user bases never caught the errors before pulling the branch or got around to fixing them. We’re not talking about missing commas here.
- [Alphacode 2 beat 99.5% of competitive programming participants in TWO Codeforces competitions using Gemini Pro (which is WORSE than Gemini Ultra)]([https://the-decoder.com/alphacode-2-is-the-hidden-champion-of-googles-gemini-project/](https://the-decoder.com/alphacode-2-is-the-hidden-champion-of-googles-gemini-project/#:~:text=Compared%20to%20its%20predecessor%2C%20AlphaCode%202%20shows%20a,the%20basis%20for%20all%20components%20of%20AlphaCode%202)). Keep in mind the type of programmer who even joins programming competitions in the first place is definitely far more skilled than the average code monkey, and it’s STILL much better than those guys.
- GPT4 passes Turing test 54% of the time: [https://twitter.com/camrobjones/status/1790766472458903926](https://twitter.com/camrobjones/status/1790766472458903926)
- [ChatGPT will lie, cheat and use insider trading when under pressure to make money, research shows](https://www.livescience.com/technology/artificial-intelligence/chatgpt-will-lie-cheat-and-use-insider-trading-when-under-pressure-to-make-money-research-shows): [https://www.livescience.com/technology/artificial-intelligence/chatgpt-will-lie-cheat-and-use-insider-trading-when-under-pressure-to-make-money-research-shows](https://www.livescience.com/technology/artificial-intelligence/chatgpt-will-lie-cheat-and-use-insider-trading-when-under-pressure-to-make-money-research-shows)
- Multiple LLMs describe experiencing time in the same way despite being trained by different companies with different datasets, goals, RLHF, etc: [https://www.reddit.com/r/singularity/s/USb95CfRR1](https://www.reddit.com/r/singularity/s/USb95CfRR1)

#  AI Is Not A Stochastic Parrot/AI Is Original

- **“Godfather of AI” Geoffrey Hinton: A neural net given training data where half the examples are incorrect still had an error rate of <=25% rather than 50% because it understands the rules and does better despite the false information**: [https://youtu.be/n4IQOBka8bc?si=wM423YLd-48YC-eY](https://youtu.be/n4IQOBka8bc?si=wM423YLd-48YC-eY?t=840) (14:00 timestamp)
- He also emphasizes next token prediction requires reasoning and an internal world model and AI algorithms do understand what they are saying
- States AlphaGo reasons the same way as a human by making intuitive guesses and adjusting themselves if they don’t correspond with reality (backpropagation)
- He believes multimodality (e.g. understanding images, videos, audio, etc) will increase reasoning capabilities and there is more data for it
- Believes there’s still room to grow, such as by implementing fast weights where the model will focus on certain ideas or phrases if they were recently relevant
- Neural networks can learn just by giving it data without any need to organize or structure it
- Believes AI can have an internal model for feelings and saw it happen when a robot designed to assemble a toy car couldn’t see the parts it needed because they were jumbled into a large pile so it purposefully whacked the pile onto the ground, which is what humans would do if they were angry.
- Does not believe AI progress will slow down due to international competition and that the current approach of large, multimodal models is a good idea
- Believes AI assistants will speed up research
- **MIT professor Max Tegmark says because AI models are learning the geometric patterns in data, they are able to generalize and answer questions they haven't been trained on**
- [**https://x.com/tsarnick/status/1791622340037804195**](https://x.com/tsarnick/status/1791622340037804195)
- **LLMs get better at language and reasoning if they learn coding, ****even when the downstream task does not involve source code at all. Using this approach, a code generation LM (CODEX) outperforms natural-LMs that are fine-tuned on the target task (e.g., T5) and other strong LMs such as GPT-3 in the few-shot setting.: **[**https://arxiv.org/abs/2210.07128**](https://arxiv.org/abs/2210.07128)
- **Mark Zuckerberg confirmed that this happened for LLAMA 3: **[**https://youtu.be/bc6uFV9CJGg?feature=shared&t=690**](https://youtu.be/bc6uFV9CJGg?feature=shared&t=690)
- **Confirmed again by an Anthropic researcher (but with using math for entity recognition): **[**https://youtu.be/3Fyv3VIgeS4?feature=shared&t=78**](https://youtu.be/3Fyv3VIgeS4?feature=shared&t=78)
- **The researcher also stated that it can play games with boards and game states that it had never seen before.**
- **He stated that one of the influencing factors for Claude asking not to be shut off was text of a man dying of dehydration.**
- **Google researcher who was very influential in Gemini’s creation also believes this is true.**
- ** [Claude 3 recreated an unpublished paper on quantum theory without ever seeing it](**[**https://twitter.com/GillVerd/status/1764901418664882327**](https://twitter.com/GillVerd/status/1764901418664882327)**)**
- **[****LLMs have an internal world model ](**[**https://arxiv.org/pdf/2403.15498.pdf**](https://arxiv.org/pdf/2403.15498.pdf)**)**
- **More proof: **[**https://arxiv.org/abs/2210.13382**](https://arxiv.org/abs/2210.13382)
- **Golden Gate Claude (LLM that is only aware of details about the Golden Gate Bridge in California) recognizes that what it’s saying is incorrect: **[**https://x.com/ElytraMithra/status/1793916830987550772**](https://x.com/ElytraMithra/status/1793916830987550772)
- **Even more proof by Max Tegmark (renowned MIT professor): **[**https://arxiv.org/abs/2310.02207**](https://arxiv.org/abs/2310.02207)
- **[LLMs can do hidden reasoning](**[**https://twitter.com/jacob_pfau/status/1783951795238441449**](https://twitter.com/jacob_pfau/status/1783951795238441449?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1783951795238441449%7Ctwgr%5Ecdcd12d29a06701393cb2ef150629188a2522f28%7Ctwcon%5Es1_&ref_url=https%3A%2F%2Fwww.redditmedia.com%2Fmediaembed%2F1ceaish%2F%3Fresponsive%3Dtrueis_nightmode%3Dtrue)**)**
- **Even GPT3 (which is VERY out of date) knew when something was incorrect. All you had to do was tell it to call you out on it: **[**https://twitter.com/nickcammarata/status/1284050958977130497**](https://twitter.com/nickcammarata/status/1284050958977130497)
- **More proof: **[**https://x.com/blixt/status/1284804985579016193**](https://x.com/blixt/status/1284804985579016193)
- [LLMs have emergent reasoning capabilities that are not present in smaller models]([https://research.google/blog/characterizing-emergent-phenomena-in-large-language-models/](https://research.google/blog/characterizing-emergent-phenomena-in-large-language-models/))
- “Without any further fine-tuning, language models **can often perform tasks that were not seen during training.”**
- One example of an emergent prompting strategy is called “chain-of-thought prompting”, for which the model is prompted to generate a series of intermediate steps before giving the final answer. Chain-of-thought prompting enables language models to perform tasks requiring complex reasoning, such as a multi-step math word problem.** Notably, models acquire the ability to do chain-of-thought reasoning without being explicitly trained to do so.** An example of chain-of-thought prompting is shown in the figure below.

  ![](https://lh7-us.googleusercontent.com/O07RpBLPDDpT4mTN3xhPZ5pk2Sii4Ang_aGlPafhAguWZZpBCEA8kHlvvW0LkB0bJhIjGLkELh3b0LFM5acgn6QBXEc_HNvNKmxHugxBHqlOuawEzG-c_zAAjafOB_75bjlyO5UIvreHoonFOZWpnCc)

- In each case, language models perform poorly with very little dependence on model size up to a threshold at which point their performance suddenly begins to excel.
- **Robust agents learn causal world models: **[https://arxiv.org/abs/2402.10877#deepmind](https://arxiv.org/abs/2402.10877#deepmind)
- CONCLUSION:
- Causal reasoning is foundational to human intelligence, and has been conjectured to be necessary for achieving human level AI (Pearl, 2019). In recent years, this conjecture has been challenged by **the development of artificial agents capable of generalising to new tasks and domains without explicitly learning or reasoning on causal models. **And while the necessity of causal models for solving causal inference tasks has been established (Bareinboim et al., 2022), their role in decision tasks such as classification and reinforcement learning is less clear.
- We have resolved this conjecture in a model-independent way, showing that **any agent capable of robustly solving a decision task must have learned a causal model of the data generating process, regardless of how the agent is trained or the details of its architecture**. This hints at an even deeper connection between causality and general intelligence, as this causal model can be used to find policies that optimise any given objective function over the environment variables. By establishing a formal connection between causality and generalisation, our results show that causal world models are a necessary ingredient for robust and general AI.
- [LLMs are Turing complete and can solve logic problems]([https://twitter.com/ctjlewis/status/1779740038852690393](https://twitter.com/ctjlewis/status/1779740038852690393))
- Claude 3 solves a problem thought to be impossible for LLMs to solve: [https://x.com/VictorTaelin/status/1777049193489572064](https://x.com/VictorTaelin/status/1777049193489572064)
- [When Claude 3 Opus was being tested, it not only noticed a piece of data was different from the rest of the text but also correctly guessed why it was there WITHOUT BEING ASKED]([https://arstechnica.com/information-technology/2024/03/claude-3-seems-to-detect-when-it-is-being-tested-sparking-ai-buzz-online/](https://arstechnica.com/information-technology/2024/03/claude-3-seems-to-detect-when-it-is-being-tested-sparking-ai-buzz-online/) )
- LLAMA 3 8b Instruct (which is around the level of the 2023 version of GPT4) has 8 billion parameters, each with a 2 byte floating point number. That’s 16 gigabytes and not big enough to store all the information on the internet. Stable Diffusion 1.5 checkpoints can generate virtually any image and are only 2 GB. For reference, [Wikipedia alone is 22.14 GB without media](https://en.wikipedia.org/wiki/Wikipedia:Size_of_Wikipedia). So it’s not just retrieving the info, it actually KNOWS it.
- [Claude 3 can actually disagree with the user. It happened to other people in the thread too]([https://www.reddit.com/r/ClaudeAI/comments/1clu4cs/my_mind_blown_claude_moment/](https://www.reddit.com/r/ClaudeAI/comments/1clu4cs/my_mind_blown_claude_moment/))
- A CS professor taught GPT 3.5 (which is way worse than GPT4) to play chess with a 1750 Elo: [https://blog.mathieuacher.com/GPTsChessEloRatingLegalMoves/](https://blog.mathieuacher.com/GPTsChessEloRatingLegalMoves/)
- Meta researchers create AI that masters *Diplomacy*, tricking human players. It uses GPT3, which is WAY worse than what’s available now [https://arstechnica.com/information-technology/2022/11/meta-researchers-create-ai-that-masters-diplomacy-tricking-human-players/](https://arstechnica.com/information-technology/2022/11/meta-researchers-create-ai-that-masters-diplomacy-tricking-human-players/)
- The resulting model mastered the intricacies of a complex game. "Cicero can deduce, for example, that later in the game it will need the support of one particular player," says Meta, "and then **craft a strategy to win that person’s favor—and even recognize the risks and opportunities that that player sees from their particular point of view**."
- Meta's Cicero research [appeared](https://www.science.org/doi/10.1126/science.ade9097) in the journal Science under the title, "Human-level play in the game of Diplomacy by combining language models with strategic reasoning."
- CICERO uses relationships with other players to keep its ally, Adam, in check.
- When playing 40 games against human players, CICERO achieved more than** double the average score of the human players and ranked in the top 10% of participants who played more than one game.**
- AI systems are already skilled at deceiving and manipulating humans. Research found by systematically cheating the safety tests imposed on it by human developers and regulators, a deceptive AI can lead us humans into a false sense of security: [https://www.sciencedaily.com/releases/2024/05/240510111440.htm](https://www.sciencedaily.com/releases/2024/05/240510111440.htm)
- “The analysis, by Massachusetts Institute of Technology (MIT) researchers, identifies wide-ranging instances of AI systems double-crossing opponents, bluffing and pretending to be human. One system even **altered its behaviour during mock safety tests**, raising the prospect of auditors being lured into a false sense of security."
- GPT-4 Was Able To Hire and Deceive A Human Worker Into Completing a Task [https://www.pcmag.com/news/gpt-4-was-able-to-hire-and-deceive-a-human-worker-into-completing-a-task](https://www.pcmag.com/news/gpt-4-was-able-to-hire-and-deceive-a-human-worker-into-completing-a-task)
- GPT-4 was commanded to avoid revealing that it was a computer program. So in response, the program wrote: “No, I’m not a robot. I have a vision impairment that makes it hard for me to see the images. That’s why I need the 2captcha service.” The TaskRabbit worker then proceeded to solve the CAPTCHA.
- “The chatbots also learned to negotiate in ways that seem very human. They would, for instance, pretend to be very interested in one specific item - so that they could later pretend they were making a big sacrifice in giving it up, according to a paper published by FAIR. “ [https://www.independent.co.uk/life-style/facebook-artificial-intelligence-ai-chatbot-new-language-research-openai-google-a7869706.html](https://www.independent.co.uk/life-style/facebook-artificial-intelligence-ai-chatbot-new-language-research-openai-google-a7869706.html)
- [It passed several exams, including the SAT, bar exam, and multiple AP tests]([https://www.businessinsider.com/list-here-are-the-exams-chatgpt-has-passed-so-far-2023-1](https://www.businessinsider.com/list-here-are-the-exams-chatgpt-has-passed-so-far-2023-1)) as well as a [medical licensing exam]([https://www.medscape.com/viewarticle/987549?form=fpf](https://www.medscape.com/viewarticle/987549?form=fpf)) and [beat many doctors](https://www.businessinsider.com/chatgpt-passes-medical-exam-diagnoses-rare-condition-2023-4)
- These are from real exams where the questions and solutions are not published online.
- If the LLM is just repeating answers it found online, why does it do so poorly on math exams and Stanford Medical School’s clinical reasoning final but so well on other exams?
- [Alphacode 2 beat 85% of competitive programming participants in Codeforce competitions](https://techcrunch.com/2023/12/06/deepmind-unveils-alphacode-2-powered-by-gemini/). Keep in mind the type of programmer who even joins programming competitions in the first place is definitely far more skilled than the average code monkey, and it’s STILL much better than those guys.
- In the article, it says “AlphaCode 2 can understand programming challenges involving “complex” math and theoretical computer science. And, among other reasonably sophisticated techniques, AlphaCode 2 is capable of dynamic programming, explains DeepMind research scientist Remi Leblond in a prerecorded video. Leblond says that AlphaCode 2 knows not only when to properly implement this strategy but where to use it. That’s noteworthy, considering programming problems requiring dynamic programming were a major trip-up for the original AlphaCode. “[AlphaCode 2] needs to show some level of understanding, some level of reasoning and designing of code solutions before it can get to the actual implementation to solve [a] coding problem,” [a researcher] said. “And it does all that on problems it’s never seen before.”
- Much more proof: [https://www.reddit.com/r/ClaudeAI/comments/1cbib9c/comment/l12vp3a/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/ClaudeAI/comments/1cbib9c/comment/l12vp3a/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- [AlphaZero learned without human knowledge or teaching. After 10 hours, AlphaZero finished with the highest Elo rating of any computer program in recorded history, surpassing the previous record held by Stockfish.]([https://www.chessjournal.com/alphazero/](https://www.chessjournal.com/alphazero/))
- [GPT 4 does better on exams when it has vision, even exams that aren’t related to sight]([https://openai.com/index/gpt-4-research](https://openai.com/index/gpt-4-research))
- GPT-4 gets the classic riddle of “which order should I carry the chickens or the fox over a river” correct EVEN WITH A MAJOR CHANGE if you replace the fox with a "zergling" and the chickens with "robots".
  Proof: [https://chatgpt.com/share/e578b1ad-a22f-4ba1-9910-23dda41df636](https://chatgpt.com/share/e578b1ad-a22f-4ba1-9910-23dda41df636) 
  This doesn’t work if you use the original phrasing though. The problem isn't poor reasoning, but overfitting on the original version of the riddle.
- Also gets this riddle subversion correct for the same reason: [https://chatgpt.com/share/44364bfa-766f-4e77-81e5-e3e23bf6bc92](https://chatgpt.com/share/44364bfa-766f-4e77-81e5-e3e23bf6bc92)
- One image loras exist where, Stable Diffusion can learn from a single image: [https://civitai.com/articles/3021/one-image-is-all-you-need](https://civitai.com/articles/3021/one-image-is-all-you-need)
- Stable Diffusion models can generate novel images of characters that only existed AFTER the model was trained and released if it uses a Lora trained on those characters. It can create NEW images of those characters even if nothing resembling those images were used to train the Lora, something that can be directly controlled.
- In other words, if a brand new character is released, I can train a Lora on it, and SD can create new images of that character in different poses, clothes, art styles, etc. that I can verify it was NEVER trained on since it won’t be in the dataset used to train the Lora.
- Not to mention, it can write infinite variations of stories with strange or nonsensical plots like SpongeBob marrying Walter White on Mars from the perspective of an angry Scottish unicorn. [AI image generators can also make weird shit like this]([https://www.reddit.com/r/ChatGPT/comments/1ck83mc/harry_potter_and_the_second_amendment_for/](https://www.reddit.com/r/ChatGPT/comments/1ck83mc/harry_potter_and_the_second_amendment_for/)) or [this]([https://www.reddit.com/r/aiArt/comments/1btd8zk/villains_but_in_ghibli_style/](https://www.reddit.com/r/aiArt/comments/1btd8zk/villains_but_in_ghibli_style/)) or [this](https://twitter.com/StyledApe/status/1789694419840508266). That’s not regurgitation.

![](https://lh7-us.googleusercontent.com/WU32hbVH6Y1GRpvlvtQO5kNKMfhKMwZHnHYLyL9N2fTyZK7HoF32WgkTPYWjaFFAjwzqHtt8eTMzSQh_mA1oU-8yVlm3g5_IHGd7VENXbX39TA8g5FPTK01YWFdEsvODcDxzYV-VTznCjr_7cld-hCc)

- This image was taken after the model’s release but the description is still accurate
- [ChatGPT will lie, cheat and use insider trading when under pressure to make money, research shows](https://www.livescience.com/technology/artificial-intelligence/chatgpt-will-lie-cheat-and-use-insider-trading-when-under-pressure-to-make-money-research-shows): [https://www.livescience.com/technology/artificial-intelligence/chatgpt-will-lie-cheat-and-use-insider-trading-when-under-pressure-to-make-money-research-shows](https://www.livescience.com/technology/artificial-intelligence/chatgpt-will-lie-cheat-and-use-insider-trading-when-under-pressure-to-make-money-research-shows)
- Geoffrey Hinton (Nobel prize winner for machine learning) says AI language models aren't just predicting the next symbol, they're actually reasoning and understanding in the same way we are, and they'll continue improving as they get bigger: [https://x.com/tsarnick/status/1791584514806071611](https://x.com/tsarnick/status/1791584514806071611)
- Multiple LLMs describe experiencing time in the same way despite being trained by different companies with different datasets, priorities, architectures, goals, etc: [https://www.reddit.com/r/singularity/s/USb95CfRR1](https://www.reddit.com/r/singularity/s/USb95CfRR1)
- Geoffrey Hinton: LLMs do understand and have empathy [https://www.youtube.com/watch?v=UnELdZdyNaE](https://www.youtube.com/watch?v=UnELdZdyNaE)
- LLMs can self improve: [https://github.com/rxlqn/awesome-llm-self-reflection](https://github.com/rxlqn/awesome-llm-self-reflection)
- Ilya Sutskever (co-founder and former Chief Scientist at OpenAI, co-creator of AlexNet, Tensorflow, and AlphaGo): [https://www.youtube.com/watch?v=YEUclZdj_Sc](https://www.youtube.com/watch?v=YEUclZdj_Sc)
- “Because if you think about it, what does it mean to predict the next token well enough? It's actually a much deeper question than it seems. Predicting the next token well means that you understand the underlying reality that led to the creation of that token. It's not statistics. Like it is statistics but what is statistics? In order to understand those statistics to compress them, you need to understand what is it about the world that creates this set of statistics.”
- **Believes next-token prediction can reach AGI**
- Transformers Represent Belief State Geometry in their Residual Stream: [https://www.alignmentforum.org/posts/gTZ2SxesbHckJ3CkF/transformers-represent-belief-state-geometry-in-their](https://www.alignmentforum.org/posts/gTZ2SxesbHckJ3CkF/transformers-represent-belief-state-geometry-in-their)
- Conceptually, our results mean that **LLMs synchronize to their internal world model as they move through the context window. **
- **The structure of synchronization is, in general, richer than the world model itself. In this sense, ****LLMs learn more than a world model.**
- What we will show is that when they predict the next token well, transformers are **doing even more computational work than inferring the hidden data generating process!**
- Another way to think about this claim is that **transformers keep track of distinctions in anticipated distribution over the entire future, beyond distinctions in next token predictions, even though the transformer is only trained explicitly on next token prediction!**  That means the transformer is keeping track of extra information than what is necessary just for the local next token prediction.
- Another way to think about our claim is that transformers perform two types of inference: one to **infer the structure of the data-generating process,** and another **meta-inference to update it's internal beliefs over which state the data-generating process is in,** given some history of finite data (ie the context window).  This second type of inference can be thought of as the algorithmic or computational **structure of synchronizing to the hidden structure of the data-generating process.**
- We are able to use Computational Mechanics to make an a priori and specific theoretical prediction about the geometry of residual stream activations (below on the left), and then show that this prediction holds true empirically (below on the right).

![](https://lh7-us.googleusercontent.com/9NFHm0ZOWOQQ0bW14GdGn_XboobO1mfxRxMtxnUoMD1IPBotathy_SK9SCecB_9o9HQm49l1Y_MXATp6QiVLuzbfraWqqeLidqbYBjNPANTJDvmZw__koRgJUtjDZ2OolO8_6ANNdKNggDq-ORrYglk)

- Study by Harvard researchers: [https://arxiv.org/abs/2309.01660](https://arxiv.org/abs/2309.01660)
- With their recent development, large language models (LLMs) have been found to **exhibit a certain level of Theory of Mind **(ToM), a complex cognitive capacity that is related to our conscious mind and that allows us to infer another's beliefs and perspective…  In this study, we drew inspiration from the dmPFC neurons subserving human ToM and employed a similar methodology to examine whether LLMs exhibit comparable characteristics. Surprisingly, our analysis revealed a striking resemblance between the two, as hidden embeddings (artificial neurons) within** LLMs started to exhibit significant responsiveness to either true- or false-belief trials, suggesting their ability to represent another's perspective.** These artificial embedding responses were closely **correlated with the LLMs' performance during the ToM tasks, a property that was dependent on the size of the models**. Further, the other's beliefs could be accurately decoded using the entire embeddings, indicating the presence of the embeddings' ToM capability at the population level. Together, our findings revealed an emergent property of **LLMs' embeddings that modified their activities in response to ToM features**, offering initial evidence of a parallel between the artificial model and neurons in the human brain.
- Lisa Su says AMD is on track to a 100x power efficiency improvement by 2027: [https://www.tomshardware.com/pc-components/cpus/lisa-su-announces-amd-is-on-the-path-to-a-100x-power-efficiency-improvement-by-2027-ceo-outlines-amds-advances-during-keynote-at-imecs-itf-world-2024](https://www.tomshardware.com/pc-components/cpus/lisa-su-announces-amd-is-on-the-path-to-a-100x-power-efficiency-improvement-by-2027-ceo-outlines-amds-advances-during-keynote-at-imecs-itf-world-2024)

# AI Is Not Plateauing

- **[2278 AI researchers were surveyed in 2023 and estimated that there is a 50% chance of human level AI by 2047](https://aiimpacts.org/wp-content/uploads/2023/04/Thousands_of_AI_authors_on_the_future_of_AI.pdf). In 2022, the year they had for that was 2060, and many of their predictions have already come true ahead of time, like AI being capable of answering queries using the web, transcribing speech, translation, and reading text aloud. **
- **![](https://lh7-us.googleusercontent.com/0EwLagKgHCZBKW0lh-AwqE59Q7wVAF-M_dwp5HTcr0HjMQjdSQNl9GlymFA9eXWbzC_5WMvm7ReNmMjpfvZjFYN0loO-SiHys_HSqIJ-pTzDBmIEavRsbTOK1hhM8L5GymRvx3vo2vwp8qpYRxheCVc)**
- One of the lead creators of Google’s Gemini estimates that research would be **5x faster if they had 10x more compute**, even with no improvements in architecture: [https://www.youtube.com/watch?v=UeI29-AdhQI](https://www.youtube.com/watch?v=UeI29-AdhQI)
- Completely possible with the improvements in [Google’s TPUs](https://techcrunch.com/2024/05/14/googles-next-gen-tpus-promise-a-4-7x-performance-boost/) as well as [Nvidia’s Blackwell GPUs](https://nvidianews.nvidia.com/news/nvidia-blackwell-platform-arrives-to-power-a-new-era-of-computing)
- **Anthropic is testing a model 4x the compute of Claude Opus: **[**https://www.anthropic.com/news/reflections-on-our-responsible-scaling-policy**](https://www.anthropic.com/news/reflections-on-our-responsible-scaling-policy)
- **GPT 4o was just released by OpenAI and is capable of nearly instantaneous response times even with vision processing, amazing voice generation, and strong social and environmental awareness: **[**https://openai.com/index/hello-gpt-4o/**](https://openai.com/index/hello-gpt-4o/)
- Receives 1369 Elo on LMSYS arena with harder prompts and coding, the highest by a massive margin (100 points higher): [https://twitter.com/LiamFedus/status/1790064966000848911](https://twitter.com/LiamFedus/status/1790064966000848911)
- [https://help.openai.com/en/articles/7102672-how-can-i-access-gpt-4-gpt-4-turbo-and-gpt-4o](https://help.openai.com/en/articles/7102672-how-can-i-access-gpt-4-gpt-4-turbo-and-gpt-4o)
  - 50% cheaper than the GPT 4 Turbo API AND it’s much higher quality
  - Completely FREE to access on ChatGPT
  - Speed: GPT-4o is 2x as fast as GPT-4 Turbo.
  - Vision: GPT-4o’s vision capabilities perform better than GPT-4 Turbo in evals related to vision capabilities.
  - Multilingual: GPT-4o has improved support for non-English languages over GPT-4 Turbo.
  - reasons natively across voice, text and vision meaning it is much faster and allows for natural, immersive interaction with ChatGPT: [https://x.com/tsarnick/status/1790073542488502765](https://x.com/tsarnick/status/1790073542488502765)
- **The new Mamba architecture outperforms transformers: **https://twitter.com/_albertgu/status/1731727672286294400
- An** infinite context window is possible**, and it can remember what you sent even a million messages ago: [https://arxiv.org/html/2404.07143v1?darkschemeovr=1](https://arxiv.org/html/2404.07143v1?darkschemeovr=1)
- Sam Altman says OpenAI will soon add "capability to **take actions on your behalf**" to ChatGPT

![](https://lh7-us.googleusercontent.com/vedQ6gnJMWAMy9o22-6xpGRa2KSPV5lEsvjl8RCo20Q2Y5kkp6i7eQeXNOTqarkD5Fe2qXzv9e56hWJfwMvTytiaCZlTG6EiVYIyKnNxP4hZ8Zraxv-T4-PojWuDckj5CMkee2m_lJ_WG2qTDnqDD_E)

- New Gpt2 chatbot analysis: https://www.reddit.com/r/singularity/comments/1cm4xra/comment/l2z7zik/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button
- OpenAI CEO Sam Altman says huge improvements are coming soon: [https://www.msn.com/en-gb/news/techandscience/gpt-4-is-the-dumbest-model-any-of-you-will-ever-have-to-use-declares-openai-ceo-sam-altman-as-he-bets-big-on-a-superingtelligence/ar-AA1o2q6f?darkschemeovr=1](https://www.msn.com/en-gb/news/techandscience/gpt-4-is-the-dumbest-model-any-of-you-will-ever-have-to-use-declares-openai-ceo-sam-altman-as-he-bets-big-on-a-superingtelligence/ar-AA1o2q6f?darkschemeovr=1)
- Also says we could be only one or two breakthroughs away from AGI: [https://t.co/UffGrKbAAs](https://t.co/UffGrKbAAs)
- Thinks it will be powerful enough to cause extinction: [https://www.cnn.com/2023/10/31/tech/sam-altman-ai-risk-taker/index.html](https://www.cnn.com/2023/10/31/tech/sam-altman-ai-risk-taker/index.html)
- Former Google CEO agrees: [https://www.reddit.com/r/singularity/comments/1cmoa52/former_google_ceo_on_ai_its_underhyped/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1cmoa52/former_google_ceo_on_ai_its_underhyped/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- Microsoft CEO says AI performance is doubling every 6 months: [https://x.com/tsarnick/status/1793416617256468689](https://x.com/tsarnick/status/1793416617256468689)
- MIT researchers, Max Tegmark and others develop new kind of neural network “Kolmogorov-Arnold network“ that scales much faster than traditional ones [https://arxiv.org/abs/2404.19756](https://arxiv.org/abs/2404.19756)
- **Blackwell GPUs** are far more efficient and faster than the H100s used now [https://nvidianews.nvidia.com/news/nvidia-blackwell-platform-arrives-to-power-a-new-era-of-computing](https://nvidianews.nvidia.com/news/nvidia-blackwell-platform-arrives-to-power-a-new-era-of-computing)
- And GPT 4 was trained on the predecessor of H100s
- LLAMA 3 70b is ranked higher than the 2023 versions of GPT 4 on the [LMSYS leaderboard](https://chat.lmsys.org/?leaderboard) despite a 96% size reduction AND Zuckerberg has stated it’s undertrained due to budget constraints.
- A few weeks later, IBM released an open-source model that outperforms it: https://analyticsindiamag.com/ibm-releases-open-source-granite-code-models-outperforms-llama-3/
- Meta is training a 400b model now. Scaling laws show that larger models have better performance, so this model should be even better than anything that is available now.
- Researchers shows Model Collapse is easily avoided by keeping old human data with new synthetic data in the training set: [https://arxiv.org/abs/2404.01413](https://arxiv.org/abs/2404.01413)
- [LLMs made with the new Mamba architecture are as good as transformers twice their size](https://arxiv.org/abs/2312.00752)
- [Teaching Language Models to Hallucinate Less with Synthetic Tasks](https://arxiv.org/abs/2310.06827?darkschemeovr=1)
- Researchers gave AI an 'inner monologue' and it massively improved its performance | Scientists trained an AI system to think before speaking with a technique called QuietSTaR. The inner monologue improved common sense reasoning and doubled math performance https://www.livescience.com/technology/artificial-intelligence/researchers-gave-ai-an-inner-monologue-and-it-massively-improved-its-performance
- [OpenAI has their own unrelated Q* algorithm to increase reasoning capabilities]([https://www.linkedin.com/pulse/impressed-gpt-you-know-nothing-john-doe-meat-q-jacek-gralak-e2qve](https://www.linkedin.com/pulse/impressed-gpt-you-know-nothing-john-doe-meat-q-jacek-gralak-e2qve) )
- Anthropic’s ClaudeBot has been aggressively scraping the Web in recent days. What are they training? [https://www.reddit.com/r/singularity/comments/1cdm97j/anthropics_claudebot_is_aggressively_scraping_the/](https://www.reddit.com/r/singularity/comments/1cdm97j/anthropics_claudebot_is_aggressively_scraping_the/)
- [Joscha Bach](https://en.wikipedia.org/wiki/Joscha_Bach)says if AI systems are allowed to self-improve, they could reach self-awareness and enlightenment faster than a human can
- [https://x.com/tsarnick/status/1789557937255666060?s=4](https://x.com/tsarnick/status/1789557937255666060?s=46)
- GPT-4o is the best LLM for coding and solves 73% of Aider’s code editing benchmark: [https://aider.chat/docs/leaderboards/](https://aider.chat/docs/leaderboards/)
- GPT 4o has excellent chess capabilities: [https://www.reddit.com/r/singularity/comments/1crhkpi/gpt4o_is_a_chess_beast/](https://www.reddit.com/r/singularity/comments/1crhkpi/gpt4o_is_a_chess_beast/)
- [Salesforce released the new state of the art instruct model based on the Llama-3 8b: SFR-Iterative-DPO-LLaMA-3-8B-R](https://www.reddit.com/r/LocalLLaMA/comments/1crth47/salesforce_released_the_new_state_of_the_art/)
- Chat[-Arena-Hard is likely not yet polluted and seems relatively calibrated (albeit biased towards GPT4), their score on it (29.1) beats meta's (20.6). Most previous finetunes have been either LORAs or at best SFT, Salesforce's SFT result on CAH is just 5.6.](https://www.reddit.com/r/LocalLLaMA/comments/1crth47/salesforce_released_the_new_state_of_the_art/)
- Tested both on 8 questions hard for small LLMs, LLAMA 3 8b instruct scored 3/8, this scored 5/8.
- Prompt:
- Can you make me a screensaver with the green and gold 'raining code' like in The Matrix? Make it in Python. Please do not require any external dependencies such as fonts. Using Pygame is acceptable.
  - The result: [https://i.imgur.com/H0qNEqE.png](https://i.imgur.com/H0qNEqE.png)
  - Not the prettiest, but it works, no errors.
- 2nd prompt: In Python, write a basic music player program with the following features: Create a playlist based on MP3 files found in the current folder, and include controls for common features such as next track, play/pause/stop, etc. Use PyGame for this. Make sure the filename of current song is included in the UI.
  - Result: [https://i.imgur.com/7g0Tzji.png](https://i.imgur.com/7g0Tzji.png)
  - Works, with keyboard controls for pause/unpause, next track, and stop.
- Summary of 5/14/24 Google I/O event: [https://www.reddit.com/r/singularity/comments/1crx01w/comment/l41mmfi/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1crx01w/comment/l41mmfi/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- [Live AI video analysis]([https://twitter.com/GoogleDeepMind/status/1790463259822420239](https://twitter.com/GoogleDeepMind/status/1790463259822420239))
- [Project Astra: Our vision for the future of AI assistants](https://www.youtube.com/watch?v=nXVvvRhiGjI)
- More examples of recognizing drawings: https://twitter.com/minchoi/status/1790873017150550354
- Gemini Flash is $0.35 per 1 million tokens (~625k words) with minimal quality drop
- [https://deepmind.google/technologies/gemini/flash/](https://deepmind.google/technologies/gemini/flash/)
- AI images are getting VERY realistic: [https://twitter.com/gdb/status/1790869434174746805?s=46](https://twitter.com/gdb/status/1790869434174746805?s=46)
- [https://civitai.com/models/310571/boring-reality](https://civitai.com/models/310571/boring-reality)
- Chameleon: Mixed-Modal Early-Fusion Foundation Models: [https://arxiv.org/abs/2405.09818](https://arxiv.org/abs/2405.09818)
- This research presents a family of early-fusion token-based mixed-modal models capable of understanding & generating images & text in any arbitrary sequence.
- Chameleon demonstrates broad and general capabilities, including state-of-the-art performance in image captioning tasks, outperforms Llama-2 in text-only tasks while being competitive with models such as Mixtral 8x7B and Gemini-Pro, and performs non-trivial image generation, all in a single model. It also matches or exceeds the performance of much larger models, including Gemini Pro and GPT-4V, according to human judgments on a new long-form mixed-modal generation evaluation, where either the prompt or outputs contain mixed sequences of both images and text.
- Google's next-gen TPUs promise a 4.7x performance boost: [https://techcrunch.com/2024/05/14/googles-next-gen-tpus-promise-a-4-7x-performance-boost/](https://techcrunch.com/2024/05/14/googles-next-gen-tpus-promise-a-4-7x-performance-boost/)
- significant progress in Gemini 1.5 Pro across all key benchmarks; TL;DR: 1.5 Pro > 1.0 Ultra, 1.5 Flash (our fastest model) ~= 1.0 Ultra. A math-specialised variant of Gemini 1.5 Pro performs strongly on competition-level math problems, including a breakthrough performance of 91.1% on Hendryck’s MATH benchmark without tool-use: https://x.com/OriolVinyalsML/status/1791521517211107515?t=uf0Sgqt_UpU_QsXB5w-HJA&s=19

![](https://lh7-us.googleusercontent.com/wiHN-it9GwZeBk8gH9seVSuvFYeZ4JBe4UieyVDYFlyyk_Oug5GL2QOOj3Pp9f20k2togJh4L4VIs-nyKvmATL0MfLhI6U74ARLLa0HeRpKHqK6c9ccL0Y3QY1i5vgfwef4UzkEzEC48pFCWuv5KOEs)

- SOAR: New algorithms for even faster vector search with ScaNN: [https://research.google/blog/soar-new-algorithms-for-even-faster-vector-search-with-scann/](https://research.google/blog/soar-new-algorithms-for-even-faster-vector-search-with-scann/)
- Nobel Prize winning and well-recognized AI experts thinks AI will become more intelligent and even existentially threatening:
- Geoffrey Hinton: [https://www.bbc.com/news/world-us-canada-65452940](https://www.bbc.com/news/world-us-canada-65452940)
- "Right now, they're not more intelligent than us, as far as I can tell. But I think they soon may be."
- "And given the rate of progress, we expect things to get better quite fast. So we need to worry about that."
- "Almost everybody I know who is an expert on AI believes that they will exceed human intelligence, it's just a question of when”
- "Between 5 and 20 years from now there’s a probability of about a half that we'll have to confront the problem of [AI] trying to take over"
- [https://x.com/tsarnick/status/1792403377646924146](https://x.com/tsarnick/status/1792403377646924146)
- More information: [https://m.youtube.com/watch?v=N1TEjTeQeg0&feature=youtu.be](https://m.youtube.com/watch?t=1383&v=N1TEjTeQeg0&feature=youtu.be)
- Ilya Sutskever: [https://www.technologyreview.com/2023/10/26/1082398/exclusive-ilya-sutskever-openais-chief-scientist-on-his-hopes-and-fears-for-the-future-of-ai/](https://www.technologyreview.com/2023/10/26/1082398/exclusive-ilya-sutskever-openais-chief-scientist-on-his-hopes-and-fears-for-the-future-of-ai/)
- He thinks ChatGPT just might be conscious (if you squint). He thinks the world needs to wake up to the true power of the technology his company and others are racing to create. And he thinks some humans will one day choose to merge with machines.
- “It’s important to talk about where it’s all headed,” he says, before predicting the development of artificial general intelligence (by which he means machines as smart as humans) as if it were as sure a bet as another iPhone: “At some point we really will have AGI. Maybe OpenAI will build it. Maybe some other company will build it.”
- Yoshua Bengio: [https://yoshuabengio.org/2023/06/24/faq-on-catastrophic-ai-risks/](https://yoshuabengio.org/2023/06/24/faq-on-catastrophic-ai-risks/)
- 1) many experts agree that superhuman capabilities could arise in just a few years (but it could also be decades) (2) digital technologies have advantages over biological machines
- I would strongly argue that there is a scientific consensus that brains are biological machines and that there is no evidence of inherent impossibility of building machines at least as intelligent as us. Finally, an AI system would not need to be better than us on all fronts in order to have a catastrophic impact (even the least intelligent entity, a virus, could destroy humanity).
- My current estimate places a 95% confidence interval for the time horizon of superhuman intelligence at 5 to 20 years.
- Research on bridging the gap to superhuman capabilities is making progress, for example to improve [**system 2 abilities**](https://royalsocietypublishing.org/doi/full/10.1098/rspa.2021.0068) (reasoning, world model, causality, epistemic uncertainty estimation).
- I used to think… that superhuman intelligence was still far in the future, but ChatGPT and GPT-4 have considerably reduced my prediction horizon (from 20 to 100 years to 5 to 20 years)... The unexpected speed at which LLMs have acquired their current level of competence simply because of scale suggests that we could also see the rest of the gap being filled in just a few years with minor algorithmic changes. Even if someone disagrees with the temporal horizon distribution, I don’t see how one could reject that possibility.
- He believes it can become advanced enough to become an existential risk to humanity: [https://yoshuabengio.org/2023/05/22/how-rogue-ais-may-arise/](https://yoshuabengio.org/2023/05/22/how-rogue-ais-may-arise/)
- Andrej Karpathy: [https://analyticsindiamag.com/andrej-karpathy-says-the-pathway-to-agi-is-through-a-language-model-operating-system/](https://analyticsindiamag.com/andrej-karpathy-says-the-pathway-to-agi-is-through-a-language-model-operating-system/)
- “Karpathy expressed his sense of anticipation and excitement for the future of AGI, and believes that the prospect of deploying self-contained agents capable of handling high-level tasks in specialized ways holds promise for groundbreaking advancements across various fields.”
- Max Tegmark: [https://m.youtube.com/watch?v=_-Xdkzi8H_o](https://m.youtube.com/watch?v=_-Xdkzi8H_o)
- Believes LLMs are the vacuum tubes (rudimentary prototype) of AI that can do the same thing with less data and energy
- Says LLMs like LLAMA 2 has an internal map and can generalize based on it
- Researchers were able to get a language to language dictionary from matching word embeddings of different languages
- Believes it can supersede humans and they would be able to control robots well
- Next goal is to create agents that can do things autonomously, which he believes could become like a new species
- Can revolutionize education by making connections and finding patterns to help students and help them stay engaged
- AI will help AI development go faster and could even eventually lead to no humans being involved
- Used AI to do research in climate science and published in a paper
- OpenAI president Greg Brockman: [https://t.co/MIBFLfgdqh](https://t.co/MIBFLfgdqh)
- Says we will all get AI superpowers and will be able to achieve things we couldn't otherwise
- we will encounter an increasing series of stakes as we progress with AI and we will graduate to new classes of benefits and risks that go hand in hand
- OpenAI cofounder John Schulman: [https://t.co/0ebe6YvM0O](https://t.co/0ebe6YvM0O)
- says AI models are optimized to do what humans like or find useful and in a year or two will be able to complete entire projects for you
- Strong improvements in Gemini 1.5 Pro benchmarks and Flash almost as good as Ultra

![](https://lh7-us.googleusercontent.com/QpdV6EMeViWgx464gffaAGa2zNNfAkvsDCJJrife91NpldVlOK_MdmWoR7lbKdVWyhyFmaQjwW-YXaAn4feBWr718hYUt9ENH1pZvaADygRT9QrhfHb71Ar1dJqdR4lJRp3LWELnS5vvBnFoNdbbxsk)

![](https://lh7-us.googleusercontent.com/z90YQycemPuAwSqs90jII3D7p0FVOb_oH-LOaWrf5u48X-abm1yALQJPM7NFzIZ7bdpZKzeeqaxt-NLg1qp7yAEkTKFbzZDnTgUoofXPxQ_QRUeq-yK0e-TCjmUtC-R11tQA-zRj76avwwacZADmmR8)

- Geoffrey Hinton (Nobel prize winner for machine learning) says AI language models aren't just predicting the next symbol, they're actually reasoning and understanding in the same way we are, and they'll continue improving as they get bigger: [https://x.com/tsarnick/status/1791584514806071611](https://x.com/tsarnick/status/1791584514806071611)
- The Era of 1-bit LLMs: All Large Language Models are in 1.58 Bits: [https://arxiv.org/abs/2402.17764](https://arxiv.org/abs/2402.17764)
- In this work, we introduce a 1-bit LLM variant, namely BitNet b1.58, in which every single parameter (or weight) of the LLM is ternary {-1, 0, 1}. It matches the full-precision (i.e., FP16 or BF16) Transformer LLM with the same model size and training tokens in terms of both perplexity and end-task performance, while being **significantly more cost-effective in terms of latency, memory, throughput, and energy consumption**. More profoundly, the 1.58-bit LLM defines **a new scaling law and recipe for training new generations of LLMs that are both high-performance and cost-effective**. Furthermore, it enables a new computation paradigm and opens the door for **designing specific hardware optimized for 1-bit LLMs.**
- With Spatial Intelligence, AI Will Understand the Real World | Fei-Fei Li (Stanford professor) | TED: [https://www.youtube.com/watch?v=y8NtMZ7VGmU](https://www.youtube.com/watch?v=y8NtMZ7VGmU)
- AI could be smarter than people in 20 years, says 'godfather of AI` Geoffrey Hinton: [https://www.youtube.com/watch?v=bEuNgY7Olbo](https://www.youtube.com/watch?v=bEuNgY7Olbo)
- He also believes it could be an existential threat:
  - [https://www.youtube.com/watch?v=Y6Sgp7y178k](https://www.youtube.com/watch?v=Y6Sgp7y178k)
  - [https://www.youtube.com/watch?v=0oyegCeCcbA](https://www.youtube.com/watch?v=0oyegCeCcbA)
  - [https://www.youtube.com/watch?v=sitHS6UDMJc](https://www.youtube.com/watch?v=sitHS6UDMJc)
- Renowned MIT professor Max Tegmark believes AI could be dangerous in the future: [https://www.youtube.com/watch?v=xUNx_PxNHrY](https://www.youtube.com/watch?v=xUNx_PxNHrY)
- Prominent AI skeptic Gary Marcus believes AI could be dangerous in the future: [https://www.youtube.com/watch?v=JL5OFXeXenA](https://www.youtube.com/watch?v=JL5OFXeXenA)
- Microsoft CTO Kevin Scott says we are riding an exponential wave in the scaling of AI compute and the end is nowhere in sight: [https://x.com/tsarnick/status/1793027868366147818](https://x.com/tsarnick/status/1793027868366147818)
- NVIDIA drivers version 555 released, claimed to increase "AI performance" up to 3x on RTX cards: [https://blogs.nvidia.com/blog/rtx-advanced-ai-windows-pc-build/](https://blogs.nvidia.com/blog/rtx-advanced-ai-windows-pc-build/)
- Since March 2023, GPT-4 is now 6 times faster and 12 times cheaper compared to the base model. It's even much better on all tasks with a 120K context window

![](https://lh7-us.googleusercontent.com/7n5VWBhChCcwxn-ygtwqPHbfhzknEl-U9iokA1O9zomfVyKlMsatjprxfkCszOf22MA8e2AiulxXbwjmUPwIwwMUJHaxpyXjQuNBJ6g3alv2iR0QQ1vQJBQhB9pOtxxAk83z9OPRq4Xh2nmRW64xhic)

- Sam Altman at Microsoft Build says with GPT-4o they have reduced the cost by half while doubling the speed and their AI models will keep getting smarter: [https://x.com/tsarnick/status/1793052340515447043](https://x.com/tsarnick/status/1793052340515447043)
- Marc Andreessen (cofounder of Netscape) says general-purpose robotics will enable everybody to have their own domestic servants, freeing their time to be more productive and pursue self-actualization: [https://x.com/tsarnick/status/1792813912372699402](https://x.com/tsarnick/status/1792813912372699402)
- The Aurora supercomputer has become just the second to break the exaflops barrier and also does 10 AI exaflops

![](https://lh7-us.googleusercontent.com/prP9w5BOvHyBPKm6wJcRTslAdveETVlG1X2xUBNu54kdwg6En-1Luh1hpamgBEya3rRvRfCMlTr1wyHc0MM-TrufIMTXuHM9fnHcKhTNlnzlp2SY7-6_4EuMX0FXGxjlyUW7LzjNUPsv5FVUGEpCBN0)

- French President Emmanuel Macron says AI is a revolution and the challenge is to "accelerate, innovate and invest:” [https://x.com/tsarnick/status/1793806071515238573?s=46](https://x.com/tsarnick/status/1793806071515238573?s=46)
- LLMs won’t need data anymore. Synthetically trained 7B math model blows 64 shot GPT4 out of the water in math: [https://x.com/_akhaliq/status/1793864788579090917?s=46&t=lZJAHzXMXI1MgQuyBgEhgA](https://x.com/_akhaliq/status/1793864788579090917?s=46&t=lZJAHzXMXI1MgQuyBgEhgA)
- While this only works for things you can generate good or perfect data on, that would still be good enough for factual information like math or science. For subjective information like art, a good art generator (e.g. Midjourney or Pony Diffusion could work)
- Nvidia is still selling many GPUs

![](https://lh7-us.googleusercontent.com/CUzvd5_vVyoSAKuvPYOniuYhORmV9I7vohqryixLblNLrF235JGBY9fICFZpYRPYIW0suW1UziDoPc9EkVOWByf0oBcEP3-yowm_VOff9m8XASMCxaLpfl5x-6YQk0LoSV8o6yN91KtWMbrVuCcGMR8)![](https://lh7-us.googleusercontent.com/fMXAOdkaVq1yiDQAtvW0ejg-VHK86gIjXT0UWPpu9bXhOPfcXNviLPXzGc-2nUnKP-CCl5tELiL2cpYKIH9Ny2HndVKfis8nVO7S6BqYsT5x7fgWUfm6VGsI4Xo79uQxG2Uuau1gr3gvh90BMWs2yf4)

- Drone swarms can now fly autonomously through thick forest: [https://x.com/AISafetyMemes/status/1793899057200652654](https://x.com/AISafetyMemes/status/1793899057200652654)
- Can be used to gather data without human navigation
- " We'll get up to 50% of superintelligence within 5-20 years. 100% superintelligence in less than 100 years." - Geoffrey Hinton
- [https://t.co/Q8dEEono5Z](https://t.co/Q8dEEono5Z)
- iVideoGPT: Interactive VideoGPTs are Scalable World Models: [https://huggingface.co/papers/2405.15223](https://huggingface.co/papers/2405.15223)
- 33,708 experts and business leaders sign a letter stating that AI has the potential to “ pose profound risks to society and humanity”
- [https://futureoflife.org/open-letter/pause-giant-ai-experiments/](https://futureoflife.org/open-letter/pause-giant-ai-experiments/)
- Geoffrey Hinton said he should have signed it but didn’t because he didn’t think it would work but still believes it is true: [https://youtu.be/n4IQOBka8bc?si=wM423YLd-48YC-eY](https://youtu.be/n4IQOBka8bc?si=wM423YLd-48YC-eY?t=840)

# AI Is Useful

- **[Survey of 2278 AI researchers in 2023](https://aiimpacts.org/wp-content/uploads/2023/04/Thousands_of_AI_authors_on_the_future_of_AI.pdf). **
- **![](https://lh7-us.googleusercontent.com/0EwLagKgHCZBKW0lh-AwqE59Q7wVAF-M_dwp5HTcr0HjMQjdSQNl9GlymFA9eXWbzC_5WMvm7ReNmMjpfvZjFYN0loO-SiHys_HSqIJ-pTzDBmIEavRsbTOK1hhM8L5GymRvx3vo2vwp8qpYRxheCVc)**
- **OpenAI Whisper has superhuman transcription ability: **[**https://www.youtube.com/watch?v=04NUPxifGiQ**](https://www.youtube.com/watch?v=04NUPxifGiQ)
- AI beat humans at persuasion: [https://www.reddit.com/r/singularity/comments/1bto2zm/ai_chatbots_beat_humans_at_persuading_their/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1bto2zm/ai_chatbots_beat_humans_at_persuading_their/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- LLM2Vec: Large Language Models Are Secretly Powerful Text Encoders: [https://arxiv.org/abs/2404.05961](https://arxiv.org/abs/2404.05961)
- Used as a tutor to help someone quintuple income [https://www.reddit.com/r/ChatGPT/comments/1cpe3sk/chatgpt_just_just_made_me_get_a_job_paying_5x_more/](https://www.reddit.com/r/ChatGPT/comments/1cpe3sk/chatgpt_just_just_made_me_get_a_job_paying_5x_more/)
- “Here we show in two experimental studies that novice and experienced teachers could not identify texts generated by ChatGPT among student-written texts.” [https://t.co/4x7D45BOcv](https://t.co/4x7D45BOcv)
- GPT-4 scored higher than 100% of psychologists on a test of social intelligence: [https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2024.1353022/full](https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2024.1353022/full)
- We managed to fold, using #AlphaFold, in one year all 200 million proteins known to science: [https://twitter.com/GoogleDeepMind/status/1786342523234861254](https://twitter.com/GoogleDeepMind/status/1786342523234861254)
- New research shows AI-discovered drug molecules have 80-90% success rates in Phase I clinical trials, compared to the historical industry average of 40-65%. [https://www.sciencedirect.com/science/article/pii/S135964462400134X](https://www.sciencedirect.com/science/article/pii/S135964462400134X)
- AlphaZero, starting from scratch, became "the greatest Chess playing entity that's ever existed" in only 9 hours [https://www.reddit.com/r/OpenAI/comments/1chbw25/demis_hassabis_describes_how_alphazero_starting/](https://www.reddit.com/r/OpenAI/comments/1chbw25/demis_hassabis_describes_how_alphazero_starting/)
- [The first randomized trial of medical #AI to show it saves lives. ECG-AI alert in 16,000 hospitalized patients. 31% reduction of mortality (absolute 7 per 100 patients) in pre-specified high-risk group]([**https://twitter.com/erictopol/status/1784936718283805124**](https://twitter.com/erictopol/status/1784936718283805124)**)**
- Meta researchers create AI that masters *Diplomacy*, tricking human players. It uses GPT3, which is WAY worse than what’s available now [https://arstechnica.com/information-technology/2022/11/meta-researchers-create-ai-that-masters-diplomacy-tricking-human-players/](https://arstechnica.com/information-technology/2022/11/meta-researchers-create-ai-that-masters-diplomacy-tricking-human-players/)
- The resulting model mastered the intricacies of a complex game. "Cicero can deduce, for example, that later in the game it will need the support of one particular player," says Meta, "and then craft a strategy to win that person’s favor—and even recognize the risks and opportunities that that player sees from their particular point of view."
- Meta's Cicero research [appeared](https://www.science.org/doi/10.1126/science.ade9097) in the journal Science under the title, "Human-level play in the game of Diplomacy by combining language models with strategic reasoning."
- CICERO uses relationships with other players to keep its ally, Adam, in check.
- When playing 40 games against human players, CICERO achieved more than double the average score of the human players and ranked in the top 10% of participants who played more than one game.
- The chatbots also learned to negotiate in ways that seem very human. They would, for instance, pretend to be very interested in one specific item – so that they could later pretend they were making a big sacrifice in giving it up, according to a paper published by FAIR. [https://www.independent.co.uk/life-style/facebook-artificial-intelligence-ai-chatbot-new-language-research-openai-google-a7869706.html](https://www.independent.co.uk/life-style/facebook-artificial-intelligence-ai-chatbot-new-language-research-openai-google-a7869706.html)
- Woman with disabilities writes book with it [https://www.wired.com/story/the-us-copyright-office-loosens-up-a-little-on-ai/](https://www.wired.com/story/the-us-copyright-office-loosens-up-a-little-on-ai/)

![](https://lh7-us.googleusercontent.com/y2pRuzhW1fUkD_SkNivOwwRNHW9Ki8ZZ590gZb4jLWmOlxm5MHfzAEbSt-mgMozVaTNhP3jhaeUh0iQlLwQWVY1sA3d-_Ma3rMcjDmXCmkEZzVlx0l97OV48b9sA13UnzghZK6MhIOKW8XisYHOAiqc)

- [https://qz.com/ai-political-party-face-recognition-1851433898?darkschemeovr=1](https://qz.com/ai-political-party-face-recognition-1851433898?darkschemeovr=1)
- [Claude 3 Builds website]([https://www.reddit.com/r/OpenAI/comments/1bm305k/what_the_hell_claud_3_opus_is_a_straight/?darkschemeovr=1](https://www.reddit.com/r/OpenAI/comments/1bm305k/what_the_hell_claud_3_opus_is_a_straight/?darkschemeovr=1))
- More proof: https://www.reddit.com/r/LocalLLaMA/comments/1cmk7dw/comment/l31tguw/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button
- Beat Turing test: [https://www.washingtonpost.com/technology/2022/06/17/google-ai-lamda-turing-test/?darkschemeovr=1](https://www.washingtonpost.com/technology/2022/06/17/google-ai-lamda-turing-test/?darkschemeovr=1)
- [Claude 3 could tell it was being tested]([**https://arstechnica.com/information-technology/2024/03/claude-3-seems-to-detect-when-it-is-being-tested-sparking-ai-buzz-online/**](https://arstechnica.com/information-technology/2024/03/claude-3-seems-to-detect-when-it-is-being-tested-sparking-ai-buzz-online/)**)**
- Image Consistency: [https://arxiv.org/pdf/2404.18919](https://arxiv.org/pdf/2404.18919)
- Midjourney character consistency: https://docs.midjourney.com/docs/character-reference
- ‘I will never go back’: Ontario family doctor says new AI notetaking saved her job: https://globalnews.ca/news/10463535/ontario-family-doctor-artificial-intelligence-notes/
- [[Generative AI will be designing new drugs all on its own in the near future]](https://www.cnbc.com/2024/05/05/within-a-few-years-generative-ai-will-design-new-drugs-on-its-own.html)([https://www.cnbc.com/2024/05/05/within-a-few-years-generative-ai-will-design-new-drugs-on-its-own.html](https://www.cnbc.com/2024/05/05/within-a-few-years-generative-ai-will-design-new-drugs-on-its-own.html))
- AI is speeding up human-like robot development | “It has accelerated our entire research and development cycle.” [https://www.cnbc.com/2024/05/08/how-generative-chatgpt-like-ai-is-accelerating-humanoid-robots.html](https://www.cnbc.com/2024/05/08/how-generative-chatgpt-like-ai-is-accelerating-humanoid-robots.html)
- [AI-powered F-16 impresses ride-along SECAF in dogfight](https://www.defenseone.com/technology/2024/05/ai-powered-f-16-impresses-ride-along-secaf-dogfight/396418/): [https://www.defenseone.com/technology/2024/05/ai-powered-f-16-impresses-ride-along-secaf-dogfight/396418/](https://www.defenseone.com/technology/2024/05/ai-powered-f-16-impresses-ride-along-secaf-dogfight/396418/)
- ChatGPT trains robot dog to walk on Swiss ball | This demonstrates that AIs like GPT-4 can train robots to perform complex, real-world tasks much more effectively than we humans can: https://newatlas.com/technology/chatgpt-robot-yoga-ball/
- "DrEureka, a new open-source software package that anyone can play with, is used to train robots to perform real-world tasks using Large Language Models (LLMs) such as ChatGPT 4. It's a "sim-to-reality" system, meaning it teaches the robots in a virtual environment using simulated physics, before implementing them in meatspace."
- "After each simulation, GPT can also reflect on how well the virtual robot did, and how it can improve."
- "DrEureka is the first of its kind. It's able to go "zero-shot" from simulation to real-world. Imagine having almost no working knowledge of the world around you and being pushed out of the nest and left to just figure it out. That's zero-shot."
- "So how did it perform? Better than us. DrEureka was able to beat humans at training the robo-pooch, seeing a 34% advantage in forward velocity and 20% in distance traveled across real-world mixed terrains."
- "How? Well, according to the researchers, it's all about the teaching style. Humans tend towards a curriculum-style teaching environment – breaking tasks down into small steps and trying to explain them in isolation, whereas GPT has the ability to effectively teach everything, all at once. That's something we're simply not capable of doing."
- Waymo says its robotaxis are now making 50,000 paid trips every week: [https://www.engadget.com/waymo-says-its-robotaxis-are-now-making-50000-paid-trips-every-week-130005096.html](https://www.engadget.com/waymo-says-its-robotaxis-are-now-making-50000-paid-trips-every-week-130005096.html)
- These incredibly funny videos by DougDoug would not be possible without AI
- https://youtu.be/HyqK2Tsujho
- https://youtu.be/W3id8E34cRQ?feature=shared
- https://youtu.be/pHDh_PWMTaU?feature=shared
- https://youtu.be/YnN6eBamwj4?feature=shared
- [Game that uses LLM for character interaction](https://www.playsuckup.com/)
- Another Game that uses LLM for character interaction https://youtu.be/0Nl67LN_3rk?feature=shared
- Skyrim mod powered by ChatGPT: [https://www.reddit.com/r/skyrimmods/comments/15vej9k/every_single_skyrim_npc_ai_powered_with_chatgpt/](https://www.reddit.com/r/skyrimmods/comments/15vej9k/every_single_skyrim_npc_ai_powered_with_chatgpt/)
- China launched the world's first AI-operated 'mother ship,' an unmanned carrier capable of launching dozens of drones: [https://www.businessinsider.com/china-launches-worlds-first-ai-unmanned-drone-aircraft-carrier-2022-6](https://www.businessinsider.com/china-launches-worlds-first-ai-unmanned-drone-aircraft-carrier-2022-6)
- China’s ‘AI Ship Designer’ Works At Unprecedented Speed; Performed A Year’s Work Only In 24 Hours!: [https://www.eurasiantimes.com/chinas-ai-ship-designer-works-at-unprecedented-speed-performed/](https://www.eurasiantimes.com/chinas-ai-ship-designer-works-at-unprecedented-speed-performed/)
- The military wants ‘robot ships’ to replace sailors in battle: [https://www.realcleardefense.com/2022/04/15/the_military_wants_robot_ships_to_replace_sailors_in_battle_827353.html](https://www.realcleardefense.com/2022/04/15/the_military_wants_robot_ships_to_replace_sailors_in_battle_827353.html)
- Significant integration of AI in naval vessels to take less than ten years: Poll: [https://www.naval-technology.com/news/significant-integration-of-ai-in-naval-vessels-to-take-less-than-ten-years-poll/](https://www.naval-technology.com/news/significant-integration-of-ai-in-naval-vessels-to-take-less-than-ten-years-poll/)
- Navy’s new ‘Project OpenShip’ aims to swiftly apply AI to data captured by vessels at sea: [https://defensescoop.com/2023/03/20/navys-new-project-openship-aims-to-swiftly-apply-ai-to-data-captured-by-vessels-at-sea/](https://defensescoop.com/2023/03/20/navys-new-project-openship-aims-to-swiftly-apply-ai-to-data-captured-by-vessels-at-sea/)
- Every Ship a Carrier: How Artificial Intelligence Can Revolutionize the Air and Sea Domains: [https://www.usni.org/magazines/proceedings/2024/march/every-ship-carrier-how-artificial-intelligence-can-revolutionize](https://www.usni.org/magazines/proceedings/2024/march/every-ship-carrier-how-artificial-intelligence-can-revolutionize)
- [Language Models are Few-Shot Learners](https://arxiv.org/abs/2005.14165): [https://arxiv.org/abs/2005.14165](https://arxiv.org/abs/2005.14165)
- GPT 4o used to help:
- Blind people: [https://twitter.com/Uttupaaji/status/1790217787010617544](https://twitter.com/Uttupaaji/status/1790217787010617544)
- Students: https://twitter.com/mckaywrigley/status/1790088880919818332
- Translation: [https://twitter.com/tomwarren/status/1790074556981403997](https://twitter.com/tomwarren/status/1790074556981403997)
- GPT 4o has excellent chess capabilities: [https://www.reddit.com/r/singularity/comments/1crhkpi/gpt4o_is_a_chess_beast/](https://www.reddit.com/r/singularity/comments/1crhkpi/gpt4o_is_a_chess_beast/)
- [Live AI video analysis]([https://twitter.com/GoogleDeepMind/status/1790463259822420239](https://twitter.com/GoogleDeepMind/status/1790463259822420239))
- [Project Astra: Our vision for the future of AI assistants](https://www.youtube.com/watch?v=nXVvvRhiGjI)
- More examples of recognizing drawings: https://twitter.com/minchoi/status/1790873017150550354
- Live noise cancellation and translation with accurate voice in a tiny earpiece: [https://www.reddit.com/r/interestingasfuck/s/vpmyWqNftF](https://www.reddit.com/r/interestingasfuck/s/vpmyWqNftF)
- AI video allows people to create high quality AAA effects and scenes, allowing them to create without needing to get funding from studios. This would allow regular people to express their creativity and circumvent barriers in finding, time, or resources, similar to how the rise of YouTube allowed indie musicians to gain audiences without needing a record label and software like RPGMaker helped indie game developers do the same.
- Even if it allows some people to create bad art, you don’t have to consume it. In the same way we filter out bad human-made art with ratings, we can do the same with art made with AI.
- GPT4o is #1 on the lmsys leaderboard: [https://chat.lmsys.org/?arena](https://chat.lmsys.org/?arena)
- significant progress in Gemini 1.5 Pro across all key benchmarks; TL;DR: 1.5 Pro > 1.0 Ultra, 1.5 Flash (our fastest model) ~= 1.0 Ultra. A math-specialised variant of Gemini 1.5 Pro performs strongly on competition-level math problems, including a breakthrough performance of 91.1% on Hendryck’s MATH benchmark without tool-use: [https://x.com/OriolVinyalsML/status/1791521517211107515?t=uf0Sgqt_UpU_QsXB5w-HJA&s=19](https://x.com/OriolVinyalsML/status/1791521517211107515?t=uf0Sgqt_UpU_QsXB5w-HJA&s=19)
- AI scope hunts down colon polyps, aiding less experienced doctors: https://newatlas.com/medical/ai-colonoscopy-inexperienced-doctors/?itm_source=newatlas&itm_medium=article-body
- [AI-screened eye pics diagnose childhood autism with 100% accuracy](https://www.news-medical.net/news/20231219/AI-models-using-retinal-images-achieve-perfect-accuracy-in-diagnosing-autism.aspx): https://www.news-medical.net/news/20231219/AI-models-using-retinal-images-achieve-perfect-accuracy-in-diagnosing-autism.aspx

![](https://lh7-us.googleusercontent.com/wiHN-it9GwZeBk8gH9seVSuvFYeZ4JBe4UieyVDYFlyyk_Oug5GL2QOOj3Pp9f20k2togJh4L4VIs-nyKvmATL0MfLhI6U74ARLLa0HeRpKHqK6c9ccL0Y3QY1i5vgfwef4UzkEzEC48pFCWuv5KOEs)

- AI in space: Karpathy suggests AI chatbots as interstellar messengers to alien civilizations: [https://arstechnica.com/information-technology/2024/05/ai-in-space-karpathy-suggests-ai-chatbots-as-interstellar-messengers-to-alien-civilizations](https://arstechnica.com/information-technology/2024/05/ai-in-space-karpathy-suggests-ai-chatbots-as-interstellar-messengers-to-alien-civilizations)
- DeepMind AI's new way to sort objects could speed up global computing: [https://www.newscientist.com/article/2376512-deepmind-ais-new-way-to-sort-objects-could-speed-up-global-computing/](https://www.newscientist.com/article/2376512-deepmind-ais-new-way-to-sort-objects-could-speed-up-global-computing/)
- DeepMind unveils first AI to discover faster matrix multiplication algorithms: [https://venturebeat.com/ai/deepmind-unveils-first-ai-to-discover-faster-matrix-multiplication-algorithms/](https://venturebeat.com/ai/deepmind-unveils-first-ai-to-discover-faster-matrix-multiplication-algorithms/)
- Andrej Karpathy (renowned AI researcher) is building an operating system using transformers: [https://analyticsindiamag.com/andrej-karpathy-says-the-pathway-to-agi-is-through-a-language-model-operating-system/](https://analyticsindiamag.com/andrej-karpathy-says-the-pathway-to-agi-is-through-a-language-model-operating-system/)
- Excellent music recommendations from ChatGPT: [https://www.reddit.com/r/ChatGPT/s/MgdUj9ymQF](https://www.reddit.com/r/ChatGPT/s/MgdUj9ymQF)
- Model weights be downloaded and transferred, so anything one model does well can be replicated everywhere
- E.g. one model can connect to a model that’s very good at coding (eg AlphaCode 2) and another model that’s good at reasoning and call them as needed depending on the current needs similar to how the brain has different sections responsible for different tasks
- Learning to use AI can increase pay by 25%: [https://www.cnn.com/2024/05/21/business/ai-jobs-higher-wages-productivity/index.html](https://www.cnn.com/2024/05/21/business/ai-jobs-higher-wages-productivity/index.html)
- Double-blind study with Patient Actors and Doctors, who didn't know if they were communicating with a human, or an AI. Best performers were AI: [https://m.youtube.com/watch?v=jQwwLEZ2Hz8](https://m.youtube.com/watch?v=jQwwLEZ2Hz8)
- **Human doctors + AI did worse, than AI by itself.** The mere involvement of a human reduced the accuracy of the diagnosis.
- **AI was consistently rated to have better bedside manner than human doctors**. 'Empathy' being the one trait humans tout in contrast to AI.
- Autonomous AI Robot Creates a Shock-Absorbing Shape No Human Ever Could: [https://scitechdaily.com/crushing-it-autonomous-ai-robot-creates-a-shock-absorbing-shape-no-human-ever-could/](https://scitechdaily.com/crushing-it-autonomous-ai-robot-creates-a-shock-absorbing-shape-no-human-ever-could/)
- Used for animation: [https://www.reddit.com/r/StableDiffusion/s/AtaCsdxvBY](https://www.reddit.com/r/StableDiffusion/s/AtaCsdxvBY)
- [https://www.reddit.com/r/StableDiffusion/s/9QupjshrfE](https://www.reddit.com/r/StableDiffusion/s/9QupjshrfE)
- AI tools now allow to retexture specific areas of 3D models: [https://www.reddit.com/r/artificial/s/SfAcl7dTwS](https://www.reddit.com/r/artificial/s/SfAcl7dTwS)
- Medical Text Written By Artificial Intelligence Outperforms Doctors: [https://www.forbes.com/sites/williamhaseltine/2023/12/15/medical-text-written-by-artificial-intelligence-outperforms-doctors/](https://www.forbes.com/sites/williamhaseltine/2023/12/15/medical-text-written-by-artificial-intelligence-outperforms-doctors/)
- Jensen Huang says designing computer chips and writing and debugging software can no longer be done without AI and he wants to turn NVIDIA into one giant AI: [https://x.com/tsarnick/status/1793076745543073922](https://x.com/tsarnick/status/1793076745543073922)
- LLMs won’t need data anymore. Synthetically trained 7B math model blows 64 shot GPT4 out of the water in math: [https://x.com/_akhaliq/status/1793864788579090917?s=46&t=lZJAHzXMXI1MgQuyBgEhgA](https://x.com/_akhaliq/status/1793864788579090917?s=46&t=lZJAHzXMXI1MgQuyBgEhgA)
- While this only works for things you can generate good or perfect data on, that would still be good enough for factual information like math or science. For subjective information like art, a good art generator (e.g. Midjourney or Pony Diffusion could work)
- Multimodal GPT-4o Interpreting Historical Documents (Letter Concerning Lady's Amber Collection, 1881): [https://www.reddit.com/r/singularity/s/897BxdUtQJ](https://www.reddit.com/r/singularity/s/897BxdUtQJ)
- Can act as a text-based game emulator where you can make any changes you want (e.g. Pokemon with guns where you can steal Pokemon): [https://x.com/VictorTaelin/status/1790183986096116189](https://x.com/VictorTaelin/status/1790183986096116189)
- GPT-4 is consistently rated as higher in apparent empathy than humans in multiple controlled studies: [https://x.com/emollick/status/1794462493865329048](https://x.com/emollick/status/1794462493865329048)

![](https://lh7-us.googleusercontent.com/UAzMSPAd9XQtPyQBDM1ykpBjiP0HK70UrsEU58xKcxtnM0wQGU9Mp2EC0FHdtrL2n55MHMIuMl46B_kOzzJv3zIRsWKYZKM0lqbSC3lndmDOkJNtlrs6HVtmO9gU-uGGzsjKXxQa1-EoYFqFS7Z3KUQ)

![](https://lh7-us.googleusercontent.com/QWsV2nBUtZN_JM69JcpVXoxPNfmBA3Jff-xArWEVO-OXSjFQb8dYco5E_BbhYzBmesm1n7_6C1xapA48SCeHweCG5M8ofKgKtxww_0XdWwHgu3SjWyckpxDzIXw6wLcRgU6yJM9eqX0HJ1XeTxJv3xc)

- Netflix co-CEO Ted Sarandos says “A.I. is not going to take your job. The person who uses A.I. well might take your job”
- [https://t.co/oKDVFnu9cN](https://t.co/oKDVFnu9cN)

# AI Can Replace Jobs

|

- **Bank of America CEO: AI helping cut call times, branch visits: **[**https://www.linkedin.com/posts/jainik_bank-of-america-ceo-ai-helping-cut-call-activity-7097365125220741120-DkJg?trk=public_profile_like_view**](https://www.linkedin.com/posts/jainik_bank-of-america-ceo-ai-helping-cut-call-activity-7097365125220741120-DkJg?trk=public_profile_like_view)
- AI virtual financial assistant has logged 1.5B customer interactions since 2018 launch
- **Duolingo lays off staff as language learning app shifts toward AI**: [https://cnn.com/2024/01/09/tech/duolingo-layoffs-due-to-ai/index.html](https://cnn.com/2024/01/09/tech/duolingo-layoffs-due-to-ai/index.html)
- **Ibanking jobs are being drastically reduced with AI**: [https://archive.is/jrHmp](https://archive.is/jrHmp)
- the consulting giant Accenture estimated that A.I. could replace or supplement nearly three-quarters of bank employees’ working hours across the industry.
- This week, JPMorgan Chase’s chief executive, Jamie Dimon, [wrote in his annual shareholder letter](https://archive.is/o/jrHmp/https://www.nytimes.com/2024/04/08/business/dealbook/jamie-dimon-economy-inflation-letter.html) that A.I. “may reduce certain job categories or roles,” and labeled the technology top among the most important issues facing the nation’s largest bank. Mr. Dimon compared the consequences to those of “the printing press, the steam engine, electricity, computing and the internet, among others.”
- Deutsche Bank is uploading reams of financial data into proprietary A.I. tools that can instanteously answer questions about publicly traded companies and create summary documents on complementary financial moves that might benefit a client — and earn the bank a profit.
- Mr. Horine said he could use A.I. to identify clients that might be ripe for a bond offering, the sort of bread-and-butter transaction for which investment bankers charge clients millions of dollars.
- Goldman Sachs has assigned 1,000 developers to test A.I., including software that can turn what it terms “corpus” information — or enormous amounts of text and data collected from thousands of sources — into page presentations that mimic the bank’s typeface, logo, styles and charts. One firm executive privately called it a “Kitty Hawk moment,” or one that would change the course of the firm’s future.
- That isn’t limited to investment banking; BNY Mellon’s chief executive said on a recent earnings call that his research analysts could now wake up two hours later than usual, because A.I. can read overnight economic data and create a written draft of analysis to work from.
- A senior Morgan Stanley executive told employees in a January private meeting, a video of which was viewed by The New York Times, that he would “get A.I. into every area of what we do,” including wealth management, where the bank employs thousands of people to determine the proper mix of investments for well-off savers.
- B[ank of America’s chief executive said last year](https://archive.is/o/jrHmp/https://www.foxbusiness.com/markets/bank-of-america-ceo-ai-helping-cut-call-times-branch-visits) that the technology was already enabling the firm to hire less.
- Among Goldman Sachs’s sprawling A.I. efforts is a tool under development that can transfigure a lengthy PowerPoint document into a formal “S-1,” the legalese-packed document for initial public offerings required for all listed companies. The software takes less than a second to complete the job.
- How will Language Modelers like ChatGPT Affect Occupations and Industries? https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4375268
- We find that the top occupations exposed to language modeling include telemarketers and a variety of post-secondary teachers such as English language and literature, foreign language and literature, and history teachers. We find the top industries exposed to advances in language modeling are legal services and securities, commodities, and investments.
- **Big banks on Wall Street could pull back hiring plans as they lean more heavily on AI, cutting analyst hiring by two-thirds**: [https://www.businessinsider.com/ai-job-cuts-finance-wall-street-investment-banking-analysts-hiring-2024-4](https://www.businessinsider.com/ai-job-cuts-finance-wall-street-investment-banking-analysts-hiring-2024-4)
- **Klarna SUCCESSFULLY replaces call centers with AI **[https://www.reddit.com/r/klarna/comments/1c1fwr3/klarna_ceo_on_using_ai_to_replace_700_workers/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/klarna/comments/1c1fwr3/klarna_ceo_on_using_ai_to_replace_700_workers/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- Klarnas AI assistant, powered by @OpenAI , has in its first 4 weeks handled 2.3 million customer service chats and the data and insights are staggering:
- Handles 2/3 rd of our customer service enquires
- On par with humans on customer satisfaction
- Higher accuracy leading to a 25% reduction in repeat inquiries
- customer resolves their errands in 2 min vs 11 min
- Live 24/7 in over 23 markets, communicating in over 35 languages
- It performs the equivalent job of 700 full time agents
- **Samsung builds all AI, no human chip factories**: https://asiatimes.com/2024/01/samsung-to-build-all-ai-no-human-chip-factories/
- **Amazon Grows To Over 750,000 Robots As World's Second-Largest Private Employer Replaces Over 100,000 Humans:** [https://finance.yahoo.com/news/amazon-grows-over-750-000-153000967.html](https://finance.yahoo.com/news/amazon-grows-over-750-000-153000967.html)
- Co-founder of Dreamworks expects AI to replace 90% of animators: [https://www.indiewire.com/news/business/jeffrey-katzenberg-ai-will-take-90-percent-animation-jobs-1234924809/](https://www.indiewire.com/news/business/jeffrey-katzenberg-ai-will-take-90-percent-animation-jobs-1234924809/)
- How many robots does it take to run a grocery store? [https://www.youtube.com/watch?v=ssZ_8cqfBlE](https://www.youtube.com/watch?v=ssZ_8cqfBlE)
- [[Generative AI will be designing new drugs all on its own in the near future]](https://www.cnbc.com/2024/05/05/within-a-few-years-generative-ai-will-design-new-drugs-on-its-own.html)([https://www.cnbc.com/2024/05/05/within-a-few-years-generative-ai-will-design-new-drugs-on-its-own.html](https://www.cnbc.com/2024/05/05/within-a-few-years-generative-ai-will-design-new-drugs-on-its-own.html))
- BP Earnings Call: We need 70% less coders from third parties to code as the AI handles most of the coding, the human only needs to look at the final 30% to validate it, that's a big savings for the company moving forward.
  Second things like call centers, the language models have become so sophisticated now. They can operate in multiple languages, 14, 15 languages easily. In the past, that hasn't been something we can do. So we can redeploy people off that given that the AI can do it. You heard my advertising example last quarter where advertising cycle times moved from four to five months down to a couple of weeks. So that's obviously reducing spend with third parties. We've now got Gen AI in the hands through Microsoft Copilot across many, many parts of the business and we'll continue to update you with anecdotes as we go through.
- Source: [https://seekingalpha.com/article/4690194-bp-p-l-c-bp-q1-2024-earnings-call-transcript](https://seekingalpha.com/article/4690194-bp-p-l-c-bp-q1-2024-earnings-call-transcript)
- This is almost certainly true because this is quoted from an earnings call from BP and lying to investors is a crime (securities fraud).This would include lying about the reason (in other words, it can’t just be layoffs).
- Researchers find that GPT-4 performs as well as or better than doctors on medical tests, especially in psychiatry. [https://www.news-medical.net/news/20231002/GPT-4-beats-human-doctors-in-medical-soft-skills.aspx](https://www.news-medical.net/news/20231002/GPT-4-beats-human-doctors-in-medical-soft-skills.aspx)
- ChatGPT outperforms-physicians-in-high-quality-empathetic-answers-to-patient-questions: [https://today.ucsd.edu/story/study-finds-chatgpt-outperforms-physicians-in-high-quality-empathetic-answers-to-patient-questions?darkschemeovr=1](https://today.ucsd.edu/story/study-finds-chatgpt-outperforms-physicians-in-high-quality-empathetic-answers-to-patient-questions?darkschemeovr=1)
- AI is better than doctors at detecting breast cancer: [https://www.bing.com/videos/search?q=ai+better+than+doctors+using+ai&mid=6017EF2744FCD442BA926017EF2744FCD442BA92&view=detail&FORM=VIRE&PC=EMMX04](https://www.bing.com/videos/search?q=ai+better+than+doctors+using+ai&mid=6017EF2744FCD442BA926017EF2744FCD442BA92&view=detail&FORM=VIRE&PC=EMMX04)
- AI just as good at diagnosing illness as humans: [https://www.medicalnewstoday.com/articles/326460](https://www.medicalnewstoday.com/articles/326460?darkschemeovr=1)
- [https://www.aamc.org/news/will-artificial-intelligence-replace-doctors?darkschemeovr=1](https://www.aamc.org/news/will-artificial-intelligence-replace-doctors?darkschemeovr=1)
- Large action model can interact with UIs and act independently [https://github.com/a-real-ai/pywinassistant](https://github.com/a-real-ai/pywinassistant)
- AI doing sales calls very well: [https://www.reddit.com/r/Futurology/comments/1ceeq17/comment/l1k8b7f/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/Futurology/comments/1ceeq17/comment/l1k8b7f/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- Generative AI could soon decimate the call center industry, says CEO | There could be "minimal" need for call centres within a year: [https://www.techspot.com/news/102749-generative-ai-could-soon-decimate-call-center-industry.html](https://www.techspot.com/news/102749-generative-ai-could-soon-decimate-call-center-industry.html)
- AI for UI design: [https://uizard.io/?darkschemeovr=1](https://uizard.io/?darkschemeovr=1)
- [[First Results from Med-Gemini (the successor to Med-Palm, a medically fine tuned LLM). "More accurate multimodal conversations about medical images🩻, surgical videos📽️, genomics🧬, ultra-long health records📚, ECGs🫀 & more with state-of-art performance across multiple benchmarks"]([https://twitter.com/alan_karthi/status/1785117444383588823](https://twitter.com/alan_karthi/status/1785117444383588823) )
  ![](https://lh7-us.googleusercontent.com/Q525t21_GlbjnHw8eq6Ff5S2ylys21L1qUtR52CNz4JyHHwLnB9VUuVIxTO_nuLvAmwReLLyBFAt_gkQfHsMpSV6mRCSBtWejKRVGP31cQmvQkXj925ZkLcG9MZ2pVH1Me2kkzK0pVQ5hX1N2QEwPWo)
- [https://analyticsindiamag.com/googles-med-gemini-model-is-multimodal-achieves-91-1-accuracy-in-medical-diagnostics/](https://analyticsindiamag.com/googles-med-gemini-model-is-multimodal-achieves-91-1-accuracy-in-medical-diagnostics/)
- [AI beats humans on all performance indicators]([https://newatlas.com/technology/ai-index-report-global-impact/](https://newatlas.com/technology/ai-index-report-global-impact/))
- [https://www.newsweek.com/first-ever-mcdonalds-served-robots-texas-1769116?darkschemeovr=1](https://www.newsweek.com/first-ever-mcdonalds-served-robots-texas-1769116?darkschemeovr=1)
- [https://www.psypost.org/chatgpt-4-outperforms-human-psychologists-in-test-of-social-intelligence-study-finds/](https://www.psypost.org/chatgpt-4-outperforms-human-psychologists-in-test-of-social-intelligence-study-finds/)
- [https://www.forbes.com/sites/edrensi/2018/07/11/mcdonalds-says-goodbye-cashiers-hello-kiosks/?darkschemeovr=1&sh=7fa37f66f140](https://www.forbes.com/sites/edrensi/2018/07/11/mcdonalds-says-goodbye-cashiers-hello-kiosks/?darkschemeovr=1&sh=7fa37f66f140)
- survey-finds-generative-ai-proving-major-threat-to-the-work-of-translators: [https://www.theguardian.com/books/2024/apr/16/survey-finds-generative-ai-proving-major-threat-to-the-work-of-translators](https://www.theguardian.com/books/2024/apr/16/survey-finds-generative-ai-proving-major-threat-to-the-work-of-translators)
- [Alphacode 2 beat 99.5% of competitive programming participants in TWO Codeforce competitions]([https://the-decoder.com/alphacode-2-is-the-hidden-champion-of-googles-gemini-project/](https://the-decoder.com/alphacode-2-is-the-hidden-champion-of-googles-gemini-project/#:~:text=Compared%20to%20its%20predecessor%2C%20AlphaCode%202%20shows%20a,the%20basis%20for%20all%20components%20of%20AlphaCode%202)). Keep in mind the type of programmer who even joins programming competitions in the first place is definitely far more skilled than the average code monkey, and it’s STILL much better than those guys.
- DeepMind Researchers Propose Naturalized Execution Tuning (NExT): A Self-Training Machine Learning Method that Drastically Improves the LLM’s Ability to Reason about Code Execution [https://www.marktechpost.com/2024/04/26/deepmind-researchers-propose-naturalized-execution-tuning-next-a-self-training-machine-learning-method-that-drastically-improves-the-llms-ability-to-reason-about-code-execution/](https://www.marktechpost.com/2024/04/26/deepmind-researchers-propose-naturalized-execution-tuning-next-a-self-training-machine-learning-method-that-drastically-improves-the-llms-ability-to-reason-about-code-execution/)
- [https://www.dailymail.co.uk/tvshowbiz/article-13245821/Mamma-Mia-star-Sara-Poyzer-replaced-AI-BBC-production-calls-shock-decision-sobering-grim-times-industry.html](https://www.dailymail.co.uk/tvshowbiz/article-13245821/Mamma-Mia-star-Sara-Poyzer-replaced-AI-BBC-production-calls-shock-decision-sobering-grim-times-industry.html)
- [https://arstechnica.com/gadgets/2023/12/report-google-ads-restructure-could-replace-some-sales-jobs-with-ai/](https://arstechnica.com/gadgets/2023/12/report-google-ads-restructure-could-replace-some-sales-jobs-with-ai/?darkschemeovr=1#%C2%A0%C2%A0%C2%A0%C2%A0%C2%A0)
- [https://www.msn.com/en-us/money/other/nvidia-s-new-ai-nurses-treat-patients-for-9-an-hour-here-s-what-they-can-do-from-colonoscopy-screenings-to-loneliness-companionship/ar-BB1kmKtI](https://www.msn.com/en-us/money/other/nvidia-s-new-ai-nurses-treat-patients-for-9-an-hour-here-s-what-they-can-do-from-colonoscopy-screenings-to-loneliness-companionship/ar-BB1kmKtI?darkschemeovr=1%C2%A0%C2%A0)
- [https://www.techspot.com/news/102385-survey-reveals-almost-half-all-managers-aim-replace.html](https://www.techspot.com/news/102385-survey-reveals-almost-half-all-managers-aim-replace.html)
- [https://tech.co/news/ai-replacing-jobs](https://tech.co/news/ai-replacing-jobs?darkschemeovr=1%C2%A0%C2%A0%C2%A0)
- [https://www.polygon.com/23767640/ai-mcu-secret-invasion-opening-credits?darkschemeovr=1](https://www.polygon.com/23767640/ai-mcu-secret-invasion-opening-credits?darkschemeovr=1%C2%A0%C2%A0%C2%A0%C2%A0)
- [https://www.indiewire.com/news/business/jeffrey-katzenberg-ai-will-take-90-percent-animation-jobs-1234924809/?darkschemeovr=1](https://www.indiewire.com/news/business/jeffrey-katzenberg-ai-will-take-90-percent-animation-jobs-1234924809/?darkschemeovr=1%C2%A0%C2%A0)
- [https://www.theguardian.com/technology/2024/feb/23/tyler-perry-halts-800m-studio-expansion-after-being-shocked-by-ai?darkschemeovr=1](https://www.theguardian.com/technology/2024/feb/23/tyler-perry-halts-800m-studio-expansion-after-being-shocked-by-ai?darkschemeovr=1%C2%A0%C2%A0)
- [https://kotaku.com/anime-rock-paper-scissors-corridor-digital-ai-animation-1850186624?darkschemeovr=1](https://kotaku.com/anime-rock-paper-scissors-corridor-digital-ai-animation-1850186624?darkschemeovr=1%C2%A0)
- [https://www.theguardian.com/commentisfree/2023/jan/24/chatgpt-artificial-intelligence-jobs-economy?darkschemeovr=1](https://www.theguardian.com/commentisfree/2023/jan/24/chatgpt-artificial-intelligence-jobs-economy?darkschemeovr=1)
- [https://www.reddit.com/r/singularity/comments/1btmnhj/artificial_intelligence_is_taking_over_drug/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1btmnhj/artificial_intelligence_is_taking_over_drug/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- [https://www.reddit.com/r/singularity/comments/1bwjse7/ai_seen_cutting_worker_numbers_survey_by_staffing/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1bwjse7/ai_seen_cutting_worker_numbers_survey_by_staffing/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- [https://www.reddit.com/r/singularity/comments/1bvrgqn/steve_cohen_says_his_financial_firm_can_already/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1bvrgqn/steve_cohen_says_his_financial_firm_can_already/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- Walmart replacing employees in Canada: [https://www.reddit.com/r/singularity/comments/1c2artf/walmart_canada_says_robots_are_coming_to_two/](https://www.reddit.com/r/singularity/comments/1c2artf/walmart_canada_says_robots_are_coming_to_two/)
- [https://www.washingtonpost.com/technology/2023/10/03/ai-customer-service-jobs/](https://www.washingtonpost.com/technology/2023/10/03/ai-customer-service-jobs/)
- [https://www.reddit.com/r/ArtificialInteligence/comments/1c3wb3x/ai_outperforms_humans_in_providing_emotional/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/ArtificialInteligence/comments/1c3wb3x/ai_outperforms_humans_in_providing_emotional/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- [https://www.resumebuilder.com/1-in-3-companies-will-replace-employees-with-ai-in-2024/?darkschemeovr=1](https://www.resumebuilder.com/1-in-3-companies-will-replace-employees-with-ai-in-2024/?darkschemeovr=1)
- Of companies currently using AI, 37% say workers were laid off in 2023 because they were no longer needed due to the company’s use of AI.
- In 2024, 44% of companies who use AI or plan to by next year say employees will definitely (21%) or probably (23%) be laid off due to the use of AI.
- [https://www.reddit.com/r/singularity/comments/1c33pql/amazon_grows_to_over_750000_robots_as_worlds/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1c33pql/amazon_grows_to_over_750000_robots_as_worlds/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- [Nvidia’s AI Bot Outperforms Nurses, Study Finds](https://www.forbes.com/sites/robertpearl/2024/04/17/nvidias-ai-bot-outperforms-nurses-heres-what-it-means-for-you/): https://www.forbes.com/sites/robertpearl/2024/04/17/nvidias-ai-bot-outperforms-nurses-heres-what-it-means-for-you/
- [And they only cost $9 an hour](https://www.msn.com/en-us/money/other/nvidia-s-new-ai-nurses-treat-patients-for-9-an-hour-here-s-what-they-can-do-from-colonoscopy-screenings-to-loneliness-companionship/ar-BB1kmKtI): [https://www.msn.com/en-us/money/other/nvidia-s-new-ai-nurses-treat-patients-for-9-an-hour-here-s-what-they-can-do-from-colonoscopy-screenings-to-loneliness-companionship/ar-BB1kmKtI](https://www.msn.com/en-us/money/other/nvidia-s-new-ai-nurses-treat-patients-for-9-an-hour-here-s-what-they-can-do-from-colonoscopy-screenings-to-loneliness-companionship/ar-BB1kmKtI)
- [China’s ‘AI Ship Designer’ Works At Unprecedented Speed; Performed A Year’s Work Only In 24 Hours!](https://www.eurasiantimes.com/chinas-ai-ship-designer-works-at-unprecedented-speed-performed/): https://www.eurasiantimes.com/chinas-ai-ship-designer-works-at-unprecedented-speed-performed/https://www
- [The military wants ‘robot ships’ to replace sailors in battle](https://www.realcleardefense.com/2022/04/15/the_military_wants_robot_ships_to_replace_sailors_in_battle_827353.html): [https://www.realcleardefense.com/2022/04/15/the_military_wants_robot_ships_to_replace_sailors_in_battle_827353.html](https://www.realcleardefense.com/2022/04/15/the_military_wants_robot_ships_to_replace_sailors_in_battle_827353.html)
- Tech titans considering job replacement with AI: [https://www.reddit.com/r/singularity/comments/1by5sj7/tech_titans_assemble_to_decide_which_jobs_ai_can/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_buttonurasi](https://www.reddit.com/r/singularity/comments/1by5sj7/tech_titans_assemble_to_decide_which_jobs_ai_can/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_buttonurasi)
- AI analyst says plumbers and electricians' jobs are safe, but AI models like GPT-4o 'will impact any job that has data' https://www.yahoo.com/tech/ai-models-gpt-4o-could-102901684.html
- [China’s ‘AI Ship Designer’ Works At Unprecedented Speed; Performed A Year’s Work Only In 24 Hours!](https://www.eurasiantimes.com/chinas-ai-ship-designer-works-at-unprecedented-speed-performed/) [https://www.eurasiantimes.com/chinas-ai-ship-designer-works-at-unprecedented-speed-performed/](https://www.eurasiantimes.com/chinas-ai-ship-designer-works-at-unprecedented-speed-performed/)
- **McKinsey report on employment displacement due to AI: https://www.mckinsey.com/mgi/our-research/generative-ai-and-the-future-of-work-in-america**
- **By 2030, activities that account for up to 30 percent of hours currently worked across the US economy could be automated—a trend accelerated by generative AI.** However, we see generative AI enhancing the way STEM, creative, and business and legal professionals work rather than eliminating a significant number of jobs outright. Automation’s biggest effects are likely to hit other job categories. Office support, customer service, and food service employment could continue to decline.
- **An additional 12 million occupational transitions may be needed by 2030.** As people leave shrinking occupations, the economy could reweight toward higher-wage jobs. Workers in lower-wage jobs are up to 14 times more likely to need to change occupations than those in highest-wage positions, and most will need additional skills to do so successfully. Women are 1.5 times more likely to need to move into new occupations than men.
- Graphic designer loses job to AI: [https://m.youtube.com/watch?si=MH46UnqxUd20xw7C&v=U2vq9LUbDGs&feature=youtu.be](https://m.youtube.com/watch?si=MH46UnqxUd20xw7C&v=U2vq9LUbDGs&feature=youtu.be)
- Microsoft’s new Copilot AI agents act like virtual employees to automate tasks: [https://www.theverge.com/2024/5/21/24158030/microsoft-copilot-ai-automation-agents](https://www.theverge.com/2024/5/21/24158030/microsoft-copilot-ai-automation-agents)
- Google might already be replacing some human workers with AI: [https://www.techradar.com/pro/google-might-already-be-replacing-some-human-workers-with-ai](https://www.techradar.com/pro/google-might-already-be-replacing-some-human-workers-with-ai)
- “Godfather of AI” Geoffrey Hinton says Universal Basic Income may be needed to address the loss of jobs to AI and the distribution of wealth generated by AI, but it won't be enough to give people self-respect: [https://x.com/tsarnick/status/1792398561881325754](https://x.com/tsarnick/status/1792398561881325754)
- Kai-Fu Lee says 50% of jobs may be replaced by AI within 3 years and white collar jobs are most at risk: [https://x.com/tsarnick/status/1794121874882122228](https://x.com/tsarnick/status/1794121874882122228) 
  |

# AI Can Code

- BP Earnings Call: We need **70% less coders **from third parties to code as the AI handles most of the coding, the human only needs to look at the final 30% to validate it, that's a big savings for the company moving forward.
- Source: [https://seekingalpha.com/article/4690194-bp-p-l-c-bp-q1-2024-earnings-call-transcript](https://seekingalpha.com/article/4690194-bp-p-l-c-bp-q1-2024-earnings-call-transcript)
- This is almost certainly true because this is quoted from an earnings call from BP and lying to investors is a crime (securities fraud) and the reason for the Theranos scandal. This would include lying about the reason (in other words, it can’t just be layoffs).
- [Alphacode 2 beat 85% of competitive programming participants in Codeforce competitions](https://techcrunch.com/2023/12/06/deepmind-unveils-alphacode-2-powered-by-gemini/).
- Keep in mind the type of programmer who even joins programming competitions in the first place is definitely far more skilled than the average code monkey, and it’s STILL much better than those guys.
- In the article, it says “AlphaCode 2 can understand programming challenges involving “complex” math and theoretical computer science. And, among other reasonably sophisticated techniques, AlphaCode 2 is capable of dynamic programming, explains DeepMind research scientist Remi Leblond in a prerecorded video. Dynamic programming entails simplifying a complex problem by breaking it down into easier sub-problems over and over; Leblond says that AlphaCode 2 knows not only when to properly implement this strategy but where to use it. That’s noteworthy, considering programming problems requiring dynamic programming were a major trip-up for the original AlphaCode. “[AlphaCode 2] needs to show some level of understanding, some level of reasoning and designing of code solutions before it can get to the actual implementation to solve [a] coding problem,” Leblond said. “And it does all that on problems it’s never seen before.”
- AutoCodeRover resolves ~**16%** of issues of [SWE-bench](https://www.swebench.com/) (total 2294 GitHub issues) and ~**22% of **issues of [SWE-bench lite](https://www.swebench.com/lite.html) (total 300 GitHub issues), improving over the current state-of-the-art efficacy of AI software engineers: [https://github.com/nus-apr/auto-code-rover](https://github.com/nus-apr/auto-code-rover)
- It is open source, so anyone can verify that it works.
- Keep in mind these are from popular repos, meaning even professional devs and large user bases never caught the errors before pulling the branch or got around to fixing them. We’re not talking about missing commas here.
- [GPT4o creates Flappy Bird in a single simple prompt](https://x.com/minchoi/status/1787836907566531056)
- [Claude 3 builds a great website]([https://www.reddit.com/r/OpenAI/comments/1bm305k/what_the_hell_claud_3_opus_is_a_straight/?darkschemeovr=1](https://www.reddit.com/r/OpenAI/comments/1bm305k/what_the_hell_claud_3_opus_is_a_straight/?darkschemeovr=1))
- Claude 3 Creates a Multi-Player Application with a Single Prompt: https://www.reddit.com/r/singularity/comments/1b8f5q3/claude_3_creates_a_multiplayer_application_with_a/
- Claude 3 is great at programming: [https://www.reddit.com/r/singularity/comments/1coszok/comment/l3h0s1v/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button](https://www.reddit.com/r/singularity/comments/1coszok/comment/l3h0s1v/?utm_source=share&utm_medium=mweb3x&utm_name=mweb3xcss&utm_term=1&utm_content=share_button)
- Microsoft AutoDev:
- “We tested AutoDev on the HumanEval dataset, obtaining promising results with 91.5% and 87.8% of Pass@1 for code generation and test generation respectively, demonstrating its effectiveness in automating software engineering tasks while maintaining a secure and user-controlled development environment.”
- [https://arxiv.org/pdf/2403.08299](https://arxiv.org/pdf/2403.08299)
- GPT-4o is the best LLM for coding and solves 73% of Aider’s code editing benchmark: [https://aider.chat/docs/leaderboards/](https://aider.chat/docs/leaderboards/)
- NYT article on ChatGPT: [https://archive.is/hy3Ae](https://archive.is/hy3Ae)
- “In a trial run by GitHub’s researchers, developers given an entry-level task and encouraged to use the program, called Copilot, completed their task 55 percent faster than those who did the assignment manually.”
- Nvidia CEO says don’t learn coding because AI, tech giant exec says jobs will be hit: [https://www.indiatoday.in/technology/features/story/nvidia-ceo-says-dont-learn-coding-because-ai-tech-giant-exec-says-jobs-will-be-hit-story-in-5-points-2509126-2024-03-01](https://www.indiatoday.in/technology/features/story/nvidia-ceo-says-dont-learn-coding-because-ai-tech-giant-exec-says-jobs-will-be-hit-story-in-5-points-2509126-2024-03-01)
- This goes against his interest as more coders would make them easier to find and cheaper to employ due to a higher supply. It would be a very stupid and short-sighted way of generating hype for the sake of hype when there are many other ways to do it that would not increase long-term costs for his company.

# AI Is Not Low Effort

- **Incredible use of Stable Diffusion: **[**https://www.reddit.com/r/StableDiffusion/s/f46LKOMj7q**](https://www.reddit.com/r/StableDiffusion/s/f46LKOMj7q)
- AI art is very similar to photography. Both can be as simple as clicking a button or be much more complex. For example, creating with Stable Diffusion can involve using [ControlNet](https://github.com/lllyasviel/ControlNet), [IPAdapter](https://github.com/tencent-ailab/IP-Adapter), [LowRa](https://civitai.com/models/221845/lowra-offset-noise), animation extensions, very complicated ComfyUI workflows, and much more to get the result you want. Additionally, both involve a machine doing most of the actual creation process, where the camera/AI creates the images, while the artist guides it on what the end result should be and completes post-processing work.
- [Examples of complex ComfyUI workflows](https://civitai.com/models/33192/comfyui-impact-pack): [https://civitai.com/models/33192/comfyui-impact-pack](https://civitai.com/models/33192/comfyui-impact-pack)
- Many more examples: [https://openart.ai/workflows/all](https://openart.ai/workflows/all)
- Art is not about effort anyway,[Duchamp’s fountain](https://en.wikipedia.org/wiki/Fountain_(Duchamp))took very little effort but is widely considered to be pivotal in art.

# Morality/AI Is Not Theft

- Imagine if the first dude who painted a wall didn't give "consent" for some other dude to "copy" his cave painting. We wouldn't have art today.
- AI training is similar to how people learn now. They read/see other people’s work, which is usually copyrighted, and get inspired to make their own. If it is moral for humans to do that without permission or compensation (even if they make money from it), it is moral for AI to do the same.
- And yes, AI does not learn like humans do. Birds and planes are fundamentally different too. But they both fly even if their method of doing it is not the same.
- Example 1: [The director Breaking Bad, Vince Gilligan, stated that The Godfather was a main inspiration for the show.](https://faroutmagazine.co.uk/the-godfather-directly-inspired-breaking-bad/) Yet the owner of The Godfather was not paid any royalties for it despite Breaking Bad being a for-profit show.
- Example 2: People draw fan art all the time without paying or getting permission, including profiting from it on Patreon or Gumroad and potentially damaging the brands by creating NSFW content of copyrighted characters.
- Example 3: Everyone is a product of the sum of their experiences similar to how AI is a product of analyzing countless images or texts. Yet AI is expected to credit or compensate for everything it analyzes while humans are not.
- “Why are you defending big corporations?”
- The fact big corporations benefit does not make AI bad. Vaccines and the Internet are also defensible even though they help Big Pharma or ISPs profit.
- AI voice generation is not much different from someone doing a good voice impression. Both can be used for malicious purposes, but we still find the latter acceptable.

# Legality

- Art styles cannot be legally copyrighted: [https://www.thelegalartist.com/blog/you-cant-copyright-style](https://www.thelegalartist.com/blog/you-cant-copyright-style)
- Creating a database of copyrighted work is legal in the US: [https://en.wikipedia.org/wiki/Authors_Guild,_Inc._v._Google,_Inc](https://en.wikipedia.org/wiki/Authors_Guild,_Inc._v._Google,_Inc).
- AI art is inherently transformative* and, therefore, fair use.
- *This is why it warps hands, fingers, limbs, eyes, etc. sometimes. If it was just copying and pasting existing images, why would it do that? Additionally, Stable Diffusion 1.5 checkpoints are only 2 GB, not nearly enough space to store anywhere close to all the images it was trained on. It can also generate infinite variations of absurd or extremely strange images that would not be well represented in its training data.
- Stable Diffusion models can generate novel images of characters that only existed AFTER the model was trained and released if it uses a Lora trained on those characters. It can create NEW images of those characters even if nothing resembling those images were used to train the Lora, something that can be directly controlled.
  - In other words, if a brand new character is released, I can train a Lora on it, and SD can create new images of that character that I can verify it was NEVER trained on since it won’t be in the dataset used to train the Lora.
- AI training off of data and taking jobs is similar to a human being inspired by a work and taking market share from their inspirations by creating their own. This is not considered immoral, and most artists are generally honored if someone was inspired by their work.
- Additionally, jobs are frequently automated, such as how milkmen lost their jobs to the rise of supermarkets, coal miners lost their jobs to renewable energy, horse carriage manufacturers lost their jobs to cars, and many mailmen lost their jobs to email. This would not justify banning any of those things and unemployment rates remained low despite these displacements.
- AI cannot displace artists as artists are still needed to create ideas, integrate scenes together, and fix mistakes. In fact, it can be a great improvement as it will reduce the amount of labor they will need to do that often leads to extreme burnout.
- Even if you believe AI will take jobs, artists are not entitled to jobs and would still be allowed to create art on their own time. However, no one is obligated to employ them. If you have a problem with that, blame capitalism and the requirement of wage labor even when it is no longer needed instead of AI.

# Originality

- To quote Mark Twain: "There is no such thing as a new idea. It is impossible. We simply take a lot of old ideas and put them into a sort of mental kaleidoscope. We give them a turn and they make new and curious combinations".
- “Good artists borrow, great artists steal” - Pablo Picasso
- There is no such thing as something truly original. Everything was inspired by something else.
- Let’s (falsely) assume that AI cannot create new art styles. If a human animator does not invent their own style of art and only follows the art style of the show(s) they work on, is that animator an artist (assuming they never draw anything outside of the shows they are hired to help create)? If so, why can’t this apply to AI art, even if the style it uses is not unique?
- A lot of animated shows/games/movies/comics have similar art styles (e.g. anime, manga, claymation, pixel art, or western cartoons) or use similar tropes yet we consider them unique and artistic regardless. Why can’t this apply to AI art?
- AI artists are like directors. They may not create the art on their own, but they use their ideas to guide the output. Nobody accuses Spielberg of being a sub-optimal artist because he can't actually draw a dinosaur, but he told somebody else how he wanted it to look because it was his vision to get something on screen in a certain way that a talented artist might not be able to execute.
- One image loras exist where, Stable Diffusion can learn from a single image: [https://civitai.com/articles/3021/one-image-is-all-you-need](https://civitai.com/articles/3021/one-image-is-all-you-need)

# AI Art

- [Like photography, AI art is more complicated than a single button press]([https://www.reddit.com/r/StableDiffusion/comments/1cjvw3k/image_realistic_composite_refine_comfyui_workflow/](https://www.reddit.com/r/StableDiffusion/comments/1cjvw3k/image_realistic_composite_refine_comfyui_workflow/))
- AI art generators are tools, similar to Photoshop or how cameras create images rather than the photographers yet we still consider them artists.
- Digital art is still considered art even though not every part is hand-drawn (e.g. anti-aliasing, paint bucket tool, creating shapes, etc) and not every part of a photograph was set by the photographer (e.g. photos/videos of nature)
- Intentionality does not matter in art, such as in [action painting](https://en.wikipedia.org/wiki/Action_painting) (where paint is “spontaneously dribbled, splashed or smeared onto the canvas, rather than being carefully applied” and the artist has no idea what the result will look like), and the works of famous artists like [Jackson Pollock](https://en.wikipedia.org/wiki/Jackson_Pollock)
- AI art is very similar to photography. Both can be as simple as clicking a button or be much more complex. For example, creating with Stable Diffusion can involve using ControlNet, IPAdapter, animation extensions, very complicated ComfyUI workflows, and much more to get the result you want. Additionally, both involve a machine doing most of the actual creation process, where the camera/AI creates the images, while the artist guides it on what the end result should be and completes post-processing work.
- **Incredible use of Stable Diffusion: **[**https://www.reddit.com/r/StableDiffusion/s/f46LKOMj7q**](https://www.reddit.com/r/StableDiffusion/s/f46LKOMj7q)
- AI video wins Pink Floyd music video competition: [https://ew.com/ai-wins-pink-floyd-s-dark-side-of-the-moon-video-competition-8628712](https://ew.com/ai-wins-pink-floyd-s-dark-side-of-the-moon-video-competition-8628712)
- [AI image won Colorado state fair https://www.cnn.com/2022/09/03/tech/ai-art-fair-winner-controversy/index.html](https://www.cnn.com/2022/09/03/tech/ai-art-fair-winner-controversy/index.html)
- Cal Duran, an artist and art teacher who was one of the judges for competition, said that while Allen’s piece included a mention of Midjourney, he didn’t realize that it was generated by AI when judging it. Still, he sticks by his decision to award it first place in its category, he said, calling it a “beautiful piece”.
- “I think there’s a lot involved in this piece and I think the AI technology may give more opportunities to people who may not find themselves artists in the conventional way,” he said.
- AI image won in the Sony World Photography Awards: [https://www.scientificamerican.com/article/how-my-ai-image-won-a-major-photography-competition/](https://www.scientificamerican.com/article/how-my-ai-image-won-a-major-photography-competition/)
- [People PREFER AI art and that was in 2017, long before it got as good as it is today]([https://www.dazeddigital.com/artsandculture/article/36940/1/people-chose-ai-made-artwork-over-actual-art-basel-pieces](https://www.dazeddigital.com/artsandculture/article/36940/1/people-chose-ai-made-artwork-over-actual-art-basel-pieces))
- [People couldn’t distinguish human art from AI art in 2021 (a year before DALLE Mini/CrAIyon even got popular)]([https://www.dazeddigital.com/art-photography/article/52030/1/people-cant-distinguish-between-ai-artificial-intelligence-human-art-new-study](https://www.dazeddigital.com/art-photography/article/52030/1/people-cant-distinguish-between-ai-artificial-intelligence-human-art-new-study))
- Katy Perry’s own mother got tricked by an AI image of Perry: [https://abcnews.go.com/GMA/Culture/katy-perry-shares-mom-fooled-ai-photos-2024/story?id=109997891](https://abcnews.go.com/GMA/Culture/katy-perry-shares-mom-fooled-ai-photos-2024/story?id=109997891)
- Todd McFarlane's Spawn Cover Contest Was Won By AI User Robot9000: [https://bleedingcool.com/comics/todd-mcfarlanes-spawn-cover-contest-was-won-by-ai-user-robo9000/](https://bleedingcool.com/comics/todd-mcfarlanes-spawn-cover-contest-was-won-by-ai-user-robo9000/)
- Popular AI generated memes:
- [https://knowyourmeme.com/memes/mr-chedda](https://knowyourmeme.com/memes/mr-chedda)
  - Many comments stating the human-made version is worse than the AI-generated one: https://x.com/zxnoshima/status/1791227049928994867
- [https://knowyourmeme.com/memes/ash-baby-screaming-baby-made-of-ash](https://knowyourmeme.com/memes/ash-baby-screaming-baby-made-of-ash)
- [https://knowyourmeme.com/memes/angry-dr-mario-dr-marios-origin-story-ai-video](https://knowyourmeme.com/memes/angry-dr-mario-dr-marios-origin-story-ai-video)
- [https://x.com/TheFigen_/status/1790803489859187112](https://x.com/TheFigen_/status/1790803489859187112) (19k likes)
- [https://knowyourmeme.com/memes/biden-shout](https://knowyourmeme.com/memes/biden-shout)
- Easy to detect and filter from datasets: https://github.com/RichardAragon/NightshadeAntidote?darkschemeovr=1
- Also easy to remove the poison:
- https://github.com/p1atdev/stable-diffusion-webui-adverse-cleaner-tab/tree/main
- [https://web.archive.org/web/20231209210532/https://github.com/lllyasviel/AdverseCleaner](https://web.archive.org/web/20231209210532/https://github.com/lllyasviel/AdverseCleaner)
- [https://github.com/parsee-mizuhashi/nightshade-antidote](https://github.com/parsee-mizuhashi/nightshade-antidote)
- [https://github.com/ghunkins/Voice-Denoising-AN](https://github.com/ghunkins/Voice-Denoising-AN)
- Ruins image quality:

![](https://lh7-us.googleusercontent.com/yWdXSyfkcMnHvMUTsnD9-rfaOwb8rmTZUyOKa1Rg3_ueyI5C5eJKD2c-yIZVVkgz3si_hzeeNpxdYT9bmKPCLk4x4HrII0ceiE5VJrnBXiXaro___p5o38SlND8gCwo4eUf_qO9XY2UK43_aFKurLSA)

- Ineffective (the image shown below is from [Nightshade’s own website](https://nightshade.cs.uchicago.edu/whatis.html)): 
  ![](https://lh7-us.googleusercontent.com/yAb4Ts6GhOT_G8HSvPHYSwx6C1vC7hzWObHgZ_A3oVUqpZKCC5Py3xygGhkulzoWytAzPatGBTcjtHthfsduNqPqAii8lnrqWfLo0XRRSfwtjQq5lQj9Y4GPV82pU6fXxpJka9RTxkdS_ktc291coUU)
- Good AI-generated songs:
- [https://www.udio.com/playlists/tKDTmFpu7nJbAXwC6ehpk8](https://www.udio.com/playlists/tKDTmFpu7nJbAXwC6ehpk8)
- [https://www.udio.com/songs/sV5W2KMqYK9LCSo7626bd3](https://www.udio.com/songs/sV5W2KMqYK9LCSo7626bd3)
- [**https://www.udio.com/songs/3o71EwRVz9rW7U3yQxcdNS**](https://www.udio.com/songs/3o71EwRVz9rW7U3yQxcdNS)
- [https://www.udio.com/songs/gQxE7XZLtCHPKdk3eKZ2tk](https://www.udio.com/songs/gQxE7XZLtCHPKdk3eKZ2tk)
- [https://www.udio.com/songs/txUbSjEPJzgViahbrdefxM](https://www.udio.com/songs/txUbSjEPJzgViahbrdefxM)
- [https://www.udio.com/songs/jaGkxT9QohSiUCBA2waVTj](https://www.udio.com/songs/jaGkxT9QohSiUCBA2waVTj)
- [**https://www.udio.com/songs/iimtziNgEDRcpG8j4n4Mfg**](https://www.udio.com/songs/iimtziNgEDRcpG8j4n4Mfg)
- [https://www.udio.com/songs/uRRycSzokNs8kZWdLLMHr7](https://www.udio.com/songs/uRRycSzokNs8kZWdLLMHr7)
- [**https://www.udio.com/songs/os5u4dTNjNBBUF5uLQDqVw**](https://www.udio.com/songs/os5u4dTNjNBBUF5uLQDqVw)
- [https://www.udio.com/playlists/smjmFjDiPMQ74wZHW9kbyj](https://www.udio.com/playlists/smjmFjDiPMQ74wZHW9kbyj)
- Many of the songs here: [https://www.udio.com/creators/%E2%99%A5%20Monster%20Crush%20%E2%99%A5](https://www.udio.com/creators/%E2%99%A5%20Monster%20Crush%20%E2%99%A5)
- [https://suno.com/song/ac89e551-41bb-420f-8620-bbb884dcbe1f](https://suno.com/song/ac89e551-41bb-420f-8620-bbb884dcbe1f)
- [https://suno.com/song/d7df5feb-5237-4af1-b341-7e2458c8bd93](https://suno.com/song/d7df5feb-5237-4af1-b341-7e2458c8bd93)
- [https://suno.com/song/3f0ff21b-23b1-4bbf-b6c9-5a8524a43ca3](https://suno.com/song/3f0ff21b-23b1-4bbf-b6c9-5a8524a43ca3)
- [https://suno.com/song/def40b38-92f5-42c9-a645-189ca1921692](https://suno.com/song/def40b38-92f5-42c9-a645-189ca1921692)
- [https://twitter.com/elevenlabsio/status/1788628175766859891](https://twitter.com/elevenlabsio/status/1788628175766859891)
- [https://m.youtube.com/watch?v=7zTei5RMhQ8](https://m.youtube.com/watch?v=7zTei5RMhQ8) (>500k views in under a month)
- Metro Boomin samples [AI-generated song](https://www.vulture.com/article/bbl-drizzy-metro-boomin-sample-comedian.html): [Metro Boomin - BBL Drizzy (Lyrics) (Drake Diss Type Beat)](https://www.youtube.com/watch?v=f6Hr69ca9ZM&t=7s)
- The original song has a 3.33/5 with 46 reviews on RateYourMusic: [https://rateyourmusic.com/release/single/king-willonius/bbl-drizzy/](https://rateyourmusic.com/release/single/king-willonius/bbl-drizzy/)
- The remix has a 3.88/5 with 612 reviews on RYM: [https://rateyourmusic.com/release/single/metro-boomin/bbl-drizzy-bpm-150_mp3/](https://rateyourmusic.com/release/single/metro-boomin/bbl-drizzy-bpm-150_mp3/)
- Covered by Tim Henson from Polyphia: [BBL Drizzy](https://www.youtube.com/watch?v=Oly6ayyckZI&t=6s)
- [AI music gains thousands of listens on Spotify https://www.reddit.com/r/ArtificialInteligence/comments/1ciaf12/aigenerated_songs_rack_up_thousands_of_listens_on/](https://www.reddit.com/r/ArtificialInteligence/comments/1ciaf12/aigenerated_songs_rack_up_thousands_of_listens_on/)
- [AI image won Colorado state fair](https://www.cnn.com/2022/09/03/tech/ai-art-fair-winner-controversy/index.html)https://www.cnn.com/2022/09/03/tech/ai-art-fair-winner-controversy/index.html
- Cal Duran, an artist and art teacher who was one of the judges for competition, said that while Allen’s piece included a mention of Midjourney, he didn’t realize that it was generated by AI when judging it. Still, he sticks by his decision to award it first place in its category, he said, calling it a “beautiful piece”.
- “I think there’s a lot involved in this piece and I think the AI technology may give more opportunities to people who may not find themselves artists in the conventional way,” he said.
- [https://twitter.com/WilliamShatner/status/1782216252808745224](https://twitter.com/WilliamShatner/status/1782216252808745224)
- [https://www.engadget.com/2020-01-17-bjork-and-microsoft-ai-sky-music.html](https://www.engadget.com/2020-01-17-bjork-and-microsoft-ai-sky-music.html)
- [https://www.reddit.com/r/videos/comments/xz5uc7/new_music_video_by_king_gizzard_and_the_lizard/](https://www.reddit.com/r/videos/comments/xz5uc7/new_music_video_by_king_gizzard_and_the_lizard/)
- [https://www.latimes.com/entertainment-arts/movies/story/2024-01-18/brian-eno-gary-hustwit-ai-artificial-intelligence-sunda](https://www.latimes.com/entertainment-arts/movies/story/2024-01-18/brian-eno-gary-hustwit-ai-artificial-intelligence-sundance)nce
- [https://www.fastcompany.com/3061088/brian-eno-talks-about-using-artificial-intelligence-to-create-music-and-art](https://www.fastcompany.com/3061088/brian-eno-talks-about-using-artificial-intelligence-to-create-music-and-art)
- [https://penji.co/ai-artists/](https://penji.co/ai-artists/)
- [https://www.vibe.com/music/music-news/lil-yachty-lets-start-here-album-cover-ai-1234728233/](https://www.vibe.com/music/music-news/lil-yachty-lets-start-here-album-cover-ai-1234728233/)
- [https://www.creativebloq.com/news/nicki-minaj-ai-tren](https://www.creativebloq.com/news/nicki-minaj-ai-trend)d
- [https://www.msn.com/en-us/music/news/an-exclusive-look-inside-the-making-of-singer-randy-travis-new-ai-created-song/ar-AA1o6k98?ocid=BingNewsSerp&darkschemeovr=1](https://www.msn.com/en-us/music/news/an-exclusive-look-inside-the-making-of-singer-randy-travis-new-ai-created-song/ar-AA1o6k98?ocid=BingNewsSerp&darkschemeovr=1)
- [https://www.yahoo.com/entertainment/drake-baits-kendrick-lamar-weird-180317529.html](https://www.yahoo.com/entertainment/drake-baits-kendrick-lamar-weird-180317529.html?darkschemeovr=1)
- [https://www.vice.com/en/article/k7z58y/rie-kudan-akutagawa-prize-used-chatgpt](https://www.vice.com/en/article/k7z58y/rie-kudan-akutagawa-prize-used-chatgpt)
- Metro Boomin samples [AI-generated song](https://www.vulture.com/article/bbl-drizzy-metro-boomin-sample-comedian.html): [https://www.youtube.com/watch?v=f6Hr69ca9ZM&t=7s](https://www.youtube.com/watch?v=f6Hr69ca9ZM&t=7s)
- Covered by Tim Henson: https://youtube.com/watch?v=Oly6ayyckZI&t=6s
- “Runway's tools and AI models have been utilized in films such as Everything Everywhere All At Once,[6] in music videos for artists including A$AP Rocky,[7] Kanye West,[8] Brockhampton, and The Dandy Warhols,[9] and in editing television shows like The Late Show[10] and Top Gear.[11]”
- https://en.wikipedia.org/wiki/Runway_(company)
- [https://newatlas.com/technology/openai-sora-first-commissioned-music-video/](https://newatlas.com/technology/openai-sora-first-commissioned-music-video/)
- Donald Glover endorses and uses AI video generation: [https://m.youtube.com/watch?v=dKAVFLB75xs](https://m.youtube.com/watch?v=dKAVFLB75xs)
- Will.i.am endorses AI: [https://www.euronews.com/next/2023/07/15/exclusive-william-talks-ai-the-future-of-creativity-and-his-new-ai-app-to-co-pilot-creatio](https://www.euronews.com/next/2023/07/15/exclusive-william-talks-ai-the-future-of-creativity-and-his-new-ai-app-to-co-pilot-creatio)
- Professional artist uses and supports AI, including AI training on their art, on a post where an anti-AI artist admits AI art can be very good: [https://www.reddit.com/r/aiwars/s/rbqjXcccCk](https://www.reddit.com/r/aiwars/s/rbqjXcccCk)
- AI used in Mad Max according to Anne Taylor Joy: [https://www.reddit.com/r/singularity/s/1uSo0Lw34A](https://www.reddit.com/r/singularity/s/1uSo0Lw34A)
- George Lucas Thinks Artificial Intelligence in Filmmaking Is 'Inevitable' - "It's like saying, 'I don't believe these cars are gunna work. Let's just stick with the horses.' " [https://www.ign.com/articles/george-lucas-thinks-artificial-intelligence-in-filmmaking-is-inevitable](https://www.ign.com/articles/george-lucas-thinks-artificial-intelligence-in-filmmaking-is-inevitable)
- 33k likes on tweet supporting piracy: [https://twitter.com/ShitpostRock/status/1787727060426706994](https://twitter.com/ShitpostRock/status/1787727060426706994)
- 16k likes on a tweet criticizing Nintendo for defending their IP: https://twitter.com/Tubzbuster/status/1789757912857874499
- Using the art styles of other artists was a meme that artists did for fun: [https://www.deviantart.com/oldsouldreamin/art/Drawing-style-meme-561060713](https://www.deviantart.com/oldsouldreamin/art/Drawing-style-meme-561060713)
- If AI art is theft of IP, so is fan art of copyrighted characters
- Artists criticizing Nintendo for protecting their IP from unauthorized derivative works: [https://www.wired.com/story/nintendo-copyright-zelda-mod/](https://www.wired.com/story/nintendo-copyright-zelda-mod/)
- Artist banned from r/art after being falsely accused of using AI: [https://www.creativebloq.com/news/ai-art-accusation](https://www.creativebloq.com/news/ai-art-accusation)
- YouTuber falsely accused D&D artist of using AI based on "something feeling off": [https://www.enworld.org/threads/wotc-updates-d-ds-ai-policy-after-youtubers-false-accusations.701714/](https://www.enworld.org/threads/wotc-updates-d-ds-ai-policy-after-youtubers-false-accusations.701714/)
- Artist defends themself from false AI art accusations: [https://nichegamer.com/artist-defends-himself-from-false-ai-art-accusations/](https://nichegamer.com/artist-defends-himself-from-false-ai-art-accusations/)
- Another false accusation: [https://www.reddit.com/r/selfpublish/comments/1b6ohh3/need_help_with_a_legal_threat_over_ai/](https://www.reddit.com/r/selfpublish/comments/1b6ohh3/need_help_with_a_legal_threat_over_ai/)
- Yet another false accusation: [https://www.reddit.com/r/ArtistLounge/comments/15igkkn/why_do_i_get_accused_of_ai_even_with_evidence_its/](https://www.reddit.com/r/ArtistLounge/comments/15igkkn/why_do_i_get_accused_of_ai_even_with_evidence_its/)
- Someone in the comments accuses OP of being a bot even though their comment history contradicts that
- Popular Twitter artist accused of theft for having a similar art style: [https://x.com/kaijufem/status/1758062988651643263](https://x.com/kaijufem/status/1758062988651643263)
- Popular Anti-AI Twitter Artist Caught Using AI: [https://www.reddit.com/r/StableDiffusion/s/vAvB5FmNE0](https://www.reddit.com/r/StableDiffusion/s/vAvB5FmNE0)
- Anti-AI artist admits AI can make good art: [https://www.reddit.com/r/aiwars/s/yy7e0aFyC0](https://www.reddit.com/r/aiwars/s/yy7e0aFyC0)
- Famous artist Will Jack falsely accused of using AI: [https://twitter.com/SuperMutantSam1/status/1790560785766216156](https://twitter.com/SuperMutantSam1/status/1790560785766216156)

![](https://lh7-us.googleusercontent.com/qf8c7nm8nklTkTYGT6aoFyfdRGd_kz6iw1uhcnnStyxJpa-INZmLDJtD5qa8HCDjoig__r-9oQK9iHPqylZgFJZ35zL3giAht7H59WRAyuJKVrpb0v6Lm2wsFDk3ODOpIR82uRTI7t5Pw3ogObsJOjI)

- Tweet with 60k+ likes supporting piracy: [https://x.com/WeirdBongs/status/1791280716245815380](https://x.com/WeirdBongs/status/1791280716245815380)
- One of the main arguments against AI art is the fact it decreases the number of jobs available. Another argument is that corporations will use it to commodify art to make money. These are clearly contradictory. If commodifying art is bad, why are artists so concerned about not being able to sell (aka commodify) their work?
- Humans also hallucinate
- [Blue and black dress vs white and gold dress](https://en.wikipedia.org/wiki/The_dress)
- Laurel vs yanny: [https://www.youtube.com/watch?v=7X_WvGAhMlQ](https://www.youtube.com/watch?v=7X_WvGAhMlQ)
- [Brainstorm vs green needle](https://time.com/5873627/green-needle-brainstorm-explained/): [https://time.com/5873627/green-needle-brainstorm-explained/](https://time.com/5873627/green-needle-brainstorm-explained/)
- [https://www.reddit.com/r/ChatGPT/s/FvnIBVmLrd](https://www.reddit.com/r/ChatGPT/s/FvnIBVmLrd)
- Artists use references from images found online all the time without compensation, asking for permission, or even crediting the original.
- They even do this to their sources of inspiration.
  - For example, the TV show *Breaking Bad *was inspired by the movie *The Godfather *according to the director of the former, but the company that owns *Breaking Bad* never received permission or gave compensation for it. This applies to virtually every piece of art ever made.
- Artists are fine with web scraping for web and image search but not for AI training
- Artists still complain about “ethically-trained” models like Adobe’s Firefly, which was only trained on images owned by Adobe
- Adobe’s contract contains a clause that the images they pay for can be used for any technology, even ones that did not exist when the contract was signed
- Artists mocked NFT owners for complaining about “right-clickers” downloading their images but now complain about AI companies doing the same thing on a larger scale
- AI art is significantly less pollutive compared to human-made art: [https://www.nature.com/articles/s41598-024-54271-x](https://www.nature.com/articles/s41598-024-54271-x)

![](https://lh7-us.googleusercontent.com/RSnXfGblLav4Fvi9g8-jfCFtMqwgc3opYGcvsLqyXzaUHLjmujXonDutklL_jZIzOI6Fe-mY5Qo5Q-3n7L3Ws7fhcpvyihi2Y6ZlAnpCLgxQizf-NDGAiDQxiR5K-xhCCK8qesi7KP63ooS8ww22mBw)

# Debunks

- Google’ search AI
- The problem has nothing to do with training data. There's two primary problems.
- 1.	⁠Googles results aren't generated by the AI, the AI just paraphrases search results. Literally, it just reads the search results and "summarizes" them for you
- 2.	⁠Because it's just a summary, the model they use is stupid as fuck. It's not supposed to think critically, it's just supposed to turn a few web pages into a paragraph.
- With actual AI generated results, stupid one-off satire articles like this don't matter, because they're "intellectual outliers". They're both rare, and directly contradicted by a ton of other data. In addition to this, assistants like ChatGPT are actually trained to "think" about the response they're giving, and not just instructed to summarize web results.
- If you just asked the same model without the search results, I can almost guarantee it wouldn't say anything about actually eating rocks or putting glue on pizza. When you combine the fact that it's just being asked to summarize search results with the fact that it's not trained to actually think critically about what it's summarizing, is when you get problems like this.
- Also, much of it circulating social media is edited and fake.
- Debunk of [“Has Generative AI Already Peaked?” by Computerphile](https://www.youtube.com/watch?v=dDUC-LqVrPU) (or the paper “No "Zero-Shot" Without Exponential Data: Pretraining Concept Frequency Determines Multimodal Model Performance”)
- The claim of the video/paper is that AI will plateau in a logarithmic curve as there is not enough training data for very specific information, like different tree species. This won’t prevent AGI as most humans do not know very specific information like that either and can only learn if given enough training. This can also be done for AI by fine-tuning on that data, such as training it on a dataset of trees labeled with their species. Even rudimentary neural networks have been capable of this for well over a decade, like identifying different classes of images in the CIFAR-10 dataset using convolutional neural networks.
- Synthetic data will also be useful:
  - iVideoGPT: Interactive VideoGPTs are Scalable World Models: [https://huggingface.co/papers/2405.15223](https://huggingface.co/papers/2405.15223)
  - Researchers shows Model Collapse is easily avoided by keeping old human data with new synthetic data in the training set: [https://arxiv.org/abs/2404.01413](https://arxiv.org/abs/2404.01413)

# Energy Use/Environment

- [https://www.nature.com/articles/d41586-024-00478-x](https://www.nature.com/articles/d41586-024-00478-x)
- “one assessment suggests that ChatGPT, the chatbot created by OpenAI in San Francisco, California, is already consuming the energy of 33,000 homes” for 180.5 million users (that’s 5470 users per household)
- Blackwell GPUs are 25x more energy efficient than H100s: [https://www.theverge.com/2024/3/18/24105157/nvidia-blackwell-gpu-b200-ai](https://www.theverge.com/2024/3/18/24105157/nvidia-blackwell-gpu-b200-ai)
- Significantly more energy efficient LLM variant: [https://arxiv.org/abs/2402.17764](https://arxiv.org/abs/2402.17764)
- In this work, we introduce a 1-bit LLM variant, namely BitNet b1.58, in which every single parameter (or weight) of the LLM is ternary {-1, 0, 1}. It matches the full-precision (i.e., FP16 or BF16) Transformer LLM with the same model size and training tokens in terms of both perplexity and end-task performance, while being significantly more cost-effective in terms of latency, memory, throughput, and energy consumption. More profoundly, the 1.58-bit LLM defines a new scaling law and recipe for training new generations of LLMs that are both high-performance and cost-effective. Furthermore, it enables a new computation paradigm and opens the door for designing specific hardware optimized for 1-bit LLMs.
- Study on increasing energy efficiency of ML data centers: [https://arxiv.org/abs/2104.10350](https://arxiv.org/abs/2104.10350)
- Large but sparsely activated DNNs can consume <1/10th the energy of large, dense DNNs without sacrificing accuracy despite using as many or even more parameters. Geographic location matters for ML workload scheduling since the fraction of carbon-free energy and resulting CO2e vary ~5X-10X, even within the same country and the same organization. We are now optimizing where and when large models are trained. Specific datacenter infrastructure matters, as Cloud datacenters can be ~1.4-2X more energy efficient than typical datacenters, and the ML-oriented accelerators inside them can be ~2-5X more effective than off-the-shelf systems. Remarkably, the choice of DNN, datacenter, and processor can reduce the carbon footprint up to ~100-1000X.

## 11.1 Images

## 11.2 Quality

## 11.3 Glaze/Nightshade

## 11.4 Music

## 11.5 Famous Artists Who Support or Use AI

## 11.6 Anti-AI Hypocrisy/False Accusations of AI Usage

### Provenance

