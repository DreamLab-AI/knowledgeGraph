Batch production is a production system type in which groups of identical products are made on a regular basis, each group passing through a set of steps from start to end.[^1]

An open operations management text says an organisation may have multiple batches at different stages of the process, that the processing is intermittent, and that there is less variety than in a job shop. The equipment is relatively general purpose and suited to the industry. Its examples are baked goods, aircraft parts, clothing and vaccines, and it says an important decision for these firms is how big the batch should be.[^1]

## Sources describe the boundary differently

Georgia Tech class notes describe a job shop layout and, separately, a cellular layout, which they tie to batch production. In a cellular layout, machines are clustered into cells that perform a group of operations on a group of similar products called a product family. The notes say this operation is associated with batch production, where a limited number of similar products based on group technology is manufactured intermittently in limited quantities.[^2] The textbook defines the batch by the grouping of identical products and does not mention cells.[^1] The two descriptions overlap but are not the same, and this page keeps both.

## Scope and distinctions

Batch production sits between [[Job Shop Production]] and [[Mass Production]] in volume and variety; see [[Production System Type]].[^1][^2] In the class notes, the lot size is itself one of the two characteristics used to divide layouts, so choosing a batch size is part of choosing the system.[^2]

A Newcastle University page notes that suppliers of engineered capital goods make components using a range of jobbing, batch, flow and assembly processes, which shows that batch production can occur alongside other process types within a single business.[^3]

## What the sources do not establish

Neither source gives a formula for batch size, so the page does not. No source here compares batch production with continuous flow on cost.

[^1]: Business LibreTexts (Introduction to Operations Management, NWTC), “6.3: Process Types”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/06:_Process_Design/6.03:_Process_Types
[^2]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design Class Notes, Chapter 12. Manufacturing Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/Logistics%20Systems%20Design/Full%20Text%20PDF/Manufacturing%20Systems.pdf
[^3]: Newcastle University, Department of Mechanical, Materials and Manufacturing Engineering (Dr Christian Hicks), “Make to Order / Engineer to Order Companies”. https://www.staff.ncl.ac.uk/chris.hicks/make_to_order.htm

