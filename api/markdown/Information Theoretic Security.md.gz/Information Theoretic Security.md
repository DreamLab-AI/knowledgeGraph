Information theoretic security is a class of cryptographic guarantee in which a scheme is secure against an adversary with unlimited computational power, because the ciphertext or protocol transcript carries no statistical information about the secret. Unlike computational security, which rests on the assumed hardness of mathematical problems, these guarantees follow from the structure of information itself and remain valid even against future advances such as quantum computers. Canonical examples include the one-time pad and threshold secret sharing.

### Overview

- Information theoretic security represents the strongest achievable confidentiality guarantee: an adversary observing the protocol output learns nothing beyond what they knew a priori, regardless of how much computation they apply. This unconditional property is purchased at a cost, typically requiring keys as long as the message, trusted shares, or physical assumptions such as quantum channels, which limits where it can be deployed.
- It is modelled as a subclass of [[Cryptography]] within the security domain.
- The practical price of unconditional security is what limits its reach. The one-time pad requires a truly random key as long as the message that is never reused, which makes key distribution the hard problem rather than encryption itself. This is why most deployed systems accept computational security in exchange for short, reusable keys.
- Information theoretic guarantees nonetheless anchor several high-assurance primitives. Threshold secret sharing protects keys so that compromise of a minority of custodians leaks nothing, and quantum key distribution offers key agreement whose security rests on physical law rather than on unproven computational hardness, making both attractive in a post-quantum threat model.

### Mechanisms

- Perfect secrecy: the posterior distribution of the message given the ciphertext equals its prior, as proven by Shannon for the one-time pad.
- Key length constraint: unconditional secrecy generally demands keying material at least as long as the protected data.
- Threshold schemes: secret sharing splits a secret so that fewer than a threshold of shares reveal nothing about it.
- Physical assumptions: quantum key distribution derives unconditional key agreement from the laws of physics rather than computation.

### Applications

- One-time pad encryption for the highest-assurance communications.
- Threshold secret sharing for key custody and distributed trust.
- Quantum key distribution and post-quantum-resilient confidentiality.

### Considerations

- Key management dominates: the security collapses entirely if pad material is reused or imperfectly random.
- Authentication is separate; unconditional confidentiality does not by itself prevent tampering and must be paired with information-theoretic message authentication codes.
- Physical assumptions in quantum schemes shift trust to hardware and channel integrity rather than removing it.

### Provenance

