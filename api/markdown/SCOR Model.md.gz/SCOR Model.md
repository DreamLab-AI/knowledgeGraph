The Supply Chain Operations Reference (SCOR) model is a reference model published by ASCM that describes the business activities associated with satisfying customer demand.[^1][^2]

ASCM says the SCOR model was established in 1996 and has been updated regularly, and that the current standard is the product of ASCM, formerly APICS, following the merger of the Supply Chain Council and APICS in 2014.[^1] SCOR is a registered trademark of ASCM.[^1]

## Structure

Version 14.0 is organised around seven primary management processes: Orchestrate, Plan, Order, Source, Transform, Fulfill and Return.[^1] Version 12.0 was organised around six: Plan, Source, Make, Deliver, Return and Enable.[^2] Version 12.0 focuses on three process levels and does not attempt to prescribe how a particular organization should conduct its business or tailor its systems or information flow.[^2]

## Performance

SCOR 14.0 says its approach to evaluating and diagnosing performance has three elements: performance attributes, metrics, and process or practice maturity.[^1] It recognises three performance categories and eight performance attributes.[^1] Version 12.0 recognised five attributes: reliability, responsiveness, agility, cost and asset management efficiency.[^2] Level-1 metrics are diagnostics for the overall health of the supply chain and are also known as key performance indicators.[^2] See [[Supply Chain Performance Measure]], [[Supply Chain Maturity Model]] and [[Supply Chain Performance Framework]].

## What the sources do not establish

Both sources are ASCM or APICS documents, so the page rests on one publisher. SCOR is cite-only: the 14.0 document says no portion may be reproduced, so this page paraphrases it and quotes short spans only. The ASCM site refused automated access, both documents were read through the Internet Archive, and the full 14.0 standard, which is for members, was not opened.[^1][^2] No independent evaluation of SCOR was available, so the page makes no claim about its adoption or effect.

[^1]: ASCM, “SCOR Digital Standard”, introduction and front matter, SCOR Version 14.0, 2025 (Internet Archive copy). https://web.archive.org/web/2025/https://www.ascm.org/globalassets/ascm_website_assets/docs/scor/intro-and-front-matter-scor-digital-standard-2025.pdf
[^2]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf

