A peg mechanism is the set of economic and technical arrangements by which a token maintains a stable exchange rate against a reference asset such as a fiat currency or another token. It typically combines collateral backing, minting and redemption rules, and arbitrage incentives so that market deviations from the target price are pushed back towards parity. The design of the peg mechanism determines how robustly a stablecoin or wrapped asset holds its value under stress.

- A Peg Mechanism is the arrangement that keeps a [[Stablecoin]] or [[Wrapped Token]] aligned to its target [[Peg]], using [[Collateral]], [[Token Minting]], and [[Arbitrage]] to restore parity.
- Its design governs how reliably the asset holds [[Price Stability]] under market pressure.

### Overview

- A peg mechanism is what makes a stable-value token actually stable. It defines the rules and incentives that draw the market price back to a reference value whenever trading pushes it above or below the target.
- Most pegs rest on three pillars. Collateral backing gives holders confidence that each token can be redeemed for value. Minting and redemption rules let participants create or destroy tokens at the reference rate. Arbitrage incentives reward traders for buying when the token trades below peg and selling when it trades above, closing the gap as a side effect of profit-seeking.
- Different designs balance these pillars differently: fiat-backed coins lean on off-chain reserves and redemption, crypto-collateralised coins over-collateralise on-chain, and algorithmic designs lean on incentives alone, which has historically proven fragile.

### Mechanisms

- Collateral reserves back outstanding tokens and underwrite redemption at the peg.
- Minting and redemption let authorised parties expand or contract supply at the reference rate.
- Arbitrage incentives convert price deviations into profitable trades that restore parity.
- Over-collateralisation buffers crypto-backed pegs against collateral price swings.
- Stability fees, liquidations, and reserve management adjust supply and risk to defend the peg.

### Applications

- Fiat-pegged stablecoins maintaining a one-to-one rate with a currency.
- Crypto-collateralised stablecoins such as DAI defending their peg on-chain.
- Wrapped tokens that mirror the value of an underlying asset across chains.
- DeFi protocols that rely on dependable peg behaviour for lending and trading.

### Provenance

