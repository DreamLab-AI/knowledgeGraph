A sourcing strategy is the plan for how an organisation will obtain what it needs from the market, covering the make-or-buy choice, the supplier arrangements and the tactics used.[^1][^2][^3]

No opened source defines the phrase. The UK Cabinet Office Sourcing Playbook lists developing a sourcing strategy among the typical commercial activities of the preparation and planning phase, alongside assessing the market and consulting it before procurement, and says pilot planning should be built into the sourcing strategy, the delivery model assessment, the bid documents and the evaluation processes.[^2] Medina-Serrano and colleagues frame the make-or-buy decision as a fundamental firm process and describe the options as in-house production, buying from external providers or combining both.[^1]

Hesping and Schiele quote Kraljic's 1983 article as offering “pragmatic advice on how top management can recognize the extent of its own supply weakness and treat it with a comprehensive strategy to manage supply”.[^3] They describe purchasing portfolio models, above all the Kraljic matrix, as adopted to recommend generic strategies and tactics for different categories of purchases, and report that practising buyers use a mix of tactical sourcing levers rather than the few recommended for each quadrant.[^3]

## Scope and distinctions

See [[Kraljic Portfolio Matrix]], [[Strategic Sourcing]], [[Single Sourcing]], [[Dual Sourcing]] and [[Supply Chain Configuration Decision]].

## What the sources do not establish

No source gives a standard content for a sourcing strategy document, and the three sources come from public-sector guidance, a make-or-buy review and a survey of purchasing agents, so the page is an editorial grouping.[^2][^1][^3]

[^1]: Ruben Medina-Serrano and colleagues, Journal of Industrial Engineering and Management, 2020, “Strategic Sourcing: Developing a Progressive Framework for Make-Or-Buy Decisions”. https://jiem.org/index.php/jiem/article/download/2858/922
[^2]: UK Cabinet Office, Crown copyright (Open Government Licence v3.0), June 2023, “The Sourcing Playbook: Government guidance on service delivery, including outsourcing, insourcing, mixed economy sourcing and contracting”. https://assets.publishing.service.gov.uk/media/64901fcc5f7bb700127fac5e/Sourcing_Playbook_Final.pdf
[^3]: Frank Henrik Hesping and Holger Schiele, International Journal of Production Economics 177, 2016 (University of Twente repository), “Matching tactical sourcing levers with the Kraljic matrix: Empirical evidence on purchasing portfolios”. https://ris.utwente.nl/ws/portalfiles/portal/6966746/Hesping_Matching%20tacticalsourcingleverswiththeKraljicmatrix.pdf

