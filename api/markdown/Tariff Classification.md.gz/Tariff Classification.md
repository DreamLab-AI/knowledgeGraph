Tariff classification is the assignment of a traded good to a code in a tariff nomenclature, which then determines the duty rate and other requirements that apply to it.[^1][^2]

GOV.UK describes commodity codes as internationally recognised reference numbers, each describing a specific product, used on any import declaration and found in the Trade Tariff tool.[^1] It lists what the code works out as the rate of Customs Duty and import VAT, and the same tool helps check whether the goods are covered by measures such as agricultural policy, anti-dumping duties, UK safeguarding measures or tariff quotas.[^1] The import guidance adds that the commodity code determines the rate of duty and whether an import licence is needed.[^2]

## International basis

Behind national codes sits the Harmonised System. The World Customs Organization says it comprises more than 5,000 commodity groups, each identified by a six digit code and supported by well-defined rules to achieve uniform classification.[^3] Maersk's glossary adds that contracting parties are obliged to base their tariff schedules on the HS nomenclature, although parties set their own rates of duty.[^4] See [[Harmonised System]].

## Place in the customs system

The European Commission names tariff classification, with origin and customs value, as one of the factors that determine the customs tariff treatment applied and any trade policy measure.[^5] See [[Rules of Origin]] and [[Customs Duty]].

## Evidence limits

GOV.UK itself says finding the right commodity code can be complicated.[^1] The opened sources do not set out the interpretive rules, and they do not say how many digits national codes extend beyond the six of the HS.[^3][^1]

[^1]: HM Revenue and Customs, “Finding commodity codes for imports into or exports out of the UK - GOV.UK”. https://www.gov.uk/guidance/finding-commodity-codes-for-imports-or-exports
[^2]: HM Revenue and Customs, “Import goods into the UK: step by step - GOV.UK”. https://www.gov.uk/import-goods-into-uk
[^3]: World Customs Organization, “What is the Harmonized System (HS)?” (web page). https://www.wcoomd.org/en/topics/nomenclature/overview/what-is-the-harmonized-system.aspx
[^4]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms
[^5]: European Commission, “Rules of origin for goods - Taxation and Customs Union”. https://taxation-customs.ec.europa.eu/customs/rules-origin-goods_en

