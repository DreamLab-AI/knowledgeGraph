The practice of making clinical decisions by conscientiously integrating the best available research evidence with clinical expertise and patient values. Formalised in the early 1990s, it ranks evidence by methodological rigour — systematic reviews and randomised controlled trials at the top, expert opinion at the bottom — and operationalises care through critical appraisal, clinical guidelines, and decision support, replacing tradition- and authority-based practice with explicit, auditable use of research findings.

### Semantic Classification

### Content

## Definition

**Evidence-based medicine (EBM)** is the explicit, systematic use of current best research evidence in decisions about the care of individual patients, integrated with clinical judgement and patient preferences. The term was coined by Gordon Guyatt's group at McMaster University in 1991, building on Archie Cochrane's earlier critique that medicine lacked systematic summaries of which interventions actually work. David Sackett's canonical 1996 definition stresses the three-way integration: evidence alone does not make a decision, but no decision should be made in ignorance of it.

EBM's methodological core is the *hierarchy of evidence*. Systematic reviews and meta-analyses of well-conducted trials sit at the apex, followed by individual [[Randomised Controlled Trial]] results, then cohort and case-control studies, case series, and finally mechanistic reasoning and expert opinion. Randomisation earns its position by eliminating confounding by indication — the systematic differences between patients who do and do not receive a treatment that bias observational comparisons. Modern refinements such as GRADE assess evidence *quality* across outcomes (risk of bias, imprecision, inconsistency, indirectness, publication bias) rather than relying on study design labels alone.

The practice operates through an infrastructure: the Cochrane Collaboration's systematic reviews, critical-appraisal training, pre-registration of trials, reporting standards (CONSORT, PRISMA), and guideline bodies such as NICE in the UK that translate evidence into recommendations, explicitly weighing benefit, harm, and cost-effectiveness. Computerised [[Clinical Decision Support]] systems embed these guidelines at the point of care, and EBM supplies the validation standard against which such systems — including modern clinical AI — must themselves be judged.

## Current Landscape

EBM's population-average logic is in productive tension with [[Precision Medicine]], which stratifies patients by genomic and biomarker profiles: an RCT estimates the average treatment effect in a trial population, whilst precision approaches ask what will work for *this* patient. The synthesis is emerging in stratified and adaptive trial designs (basket, umbrella, and platform trials such as RECOVERY), estimation of heterogeneous treatment effects, and the regulated use of real-world evidence from electronic health records to complement trials where randomisation is infeasible.

Contemporary challenges include research waste and publication bias, the slow pace of guideline updating against exponential publication volume (motivating "living" systematic reviews), applicability of trial evidence to multimorbid patients excluded from trials, and the appraisal of AI-based interventions, for which trial standards (CONSORT-AI, SPIRIT-AI) have been developed. Automation of evidence synthesis — screening, extraction, and increasingly LLM-assisted appraisal — is an active research front, with the same EBM standards applied reflexively to the automation tools themselves.

Recent dated developments:

- **CONSORT 2025 statement** (published 14 April 2025, simultaneously in the BMJ, Nature Medicine, PLoS Medicine and other journals) supersedes CONSORT 2010, which the authors state should no longer be used. The update comprises a 30-item checklist with seven new items, three revised, one deleted, and a new "open science" section covering trial registration, protocol and statistical-analysis-plan access, data sharing, and conflicts of interest.
- CONSORT 2025 integrates items from the Harms, Outcomes and Non-Pharmacological Treatment extensions plus TIDieR, and is explicitly framed as a **living guideline** to be periodically updated — the reporting infrastructure adopting the same "living" model as living systematic reviews.
- Its companion **explanation and elaboration** document (BMJ 2025;389:e081124) adds required reporting on patient and public involvement, harms assessment, and missing-data handling.
- The paired SPIRIT 2025 protocol guideline and CONSORT 2025 now share a joint home (consort-spirit.org), registered with the EQUATOR Network.

  **Sources**:

- https://www.bmj.com/content/389/bmj-2024-081123
- https://www.nature.com/articles/s41591-025-03635-5
- https://pmc.ncbi.nlm.nih.gov/articles/PMC11995452/
- https://www.equator-network.org/reporting-guidelines/consort/

### Provenance

