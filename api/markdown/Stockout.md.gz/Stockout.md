A stockout is the event in which demand arrives and the stock on hand is not enough to meet it.[^1][^2]

A Penn State teaching note describes an out-of-stock event as occurring if net stock, on hand stock minus backorders, becomes negative before an order is received.[^1] The Bazargan open textbook says that in a continuous review system shortage occurs when the demand during the lead time exceeds the reorder point.[^2] The Bazargan text also treats a lost sale or a shortage as the outcome in cycles with a stockout.[^2]

## Consequences and costs

The Penn State note says shortage cost represents either backorder cost or lost sales cost, and possibly lost goodwill.[^1] MIT lecture slides list shortage costs as expedited shipping, reimbursement to customers and loss of customer goodwill.[^3] Georgia Tech class notes say that, instead of a cost of unsatisfied demand, a minimum service level may be used as a constraint on the inventory policy.[^4] A review of operations and supply chain management says later research moved to lost-sales models, which better reflect customer behaviour during stockouts.[^6]

## Prevention

An APICS magazine article describes safety stock as inventory carried to prevent stockouts; see [[Safety Stock]].[^5] In a continuous review system the reorder point sets how often lead-time demand exceeds stock; see [[Reorder Point Policy]] and [[Base Stock Policy]].

## Scope and distinctions

A stockout is distinct from a backorder, in which the demand is held and met later, and from a lost sale, in which it is not. The sources name both as outcomes of a stockout.[^1][^2] Stockouts are an inventory event within [[Inventory Management]].

## What the sources do not establish

Sources use stockout, out-of-stock, shortage and stock-out for the same event and do not give a standard definition. None reports typical stockout rates. Service level measures such as fill rate are not defined in the sources opened for this batch.

[^1]: J. E. Tyworth, Penn State Smeal College of Business SCM 810 technical note, February 2014, “Basic Multi-period Inventory Systems”. https://courses.smeal.psu.edu/SCM810/scm_810_module_3/Multi%20Period%20Inventory%20Systems%20Teaching%20Note.pdf
[^2]: Hamid Bazargan, BCcampus Open Education, November 2021, “Classical Topics in Inventory Control”. https://opentextbc.ca/oerdiscipline/wp-content/uploads/sites/213/2018/09/Classical-Topics-in-Inventory-Control.pdf
[^3]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf
[^4]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf
[^5]: Peter L. King, APICS magazine, July/August 2011 (copy hosted by MIT 2.810), “Understanding safety stock and mastering its equations”. https://web.mit.edu/2.810/www/files/readings/King_SafetyStock.pdf
[^6]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

