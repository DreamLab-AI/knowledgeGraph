Theory of constraints is a management approach that concentrates on improving profits by managing constraints, the factors that prevent a company from achieving its goals.[^1]

The Lean Enterprise Institute describes it as a management philosophy and a set of tools for organisational change developed by the physicist Eliyahu Goldratt and popularised in the 1984 book The Goal by Goldratt and Jeff Cox.[^1] A 1997 study from DePaul University defines it as a management approach which focuses on improving bottleneck processes to continuously improve the performance of manufacturing operations, and says it attempts to answer three questions: what to change, what to change to, and how to cause the change.[^2] A 1999 teaching article calls it a method of improving productivity and profitability by reducing bottlenecks in operating systems.[^3]

## Five steps

That teaching article lists five steps: identify the system constraints, decide how to exploit them, subordinate everything else to that decision, “Elevate the system constraints”, and, if a constraint has changed, go back to the first step.[^3] It explains the first step as identifying the system's constraints, which may be something like availability of raw materials, time or money.[^3]

## Scope and distinctions

The Institute says the primary focus of the theory of constraints is removing or managing constraints to improve throughput, while lean focuses on identifying and removing waste to improve the flow of value, and that both emphasise improving the whole system rather than individual parts.[^1] See [[Lean Production]]. The topic is filed as a production management philosophy; see [[Production Management Philosophy]].

The DePaul study compared management science, the theory of constraints and local optimisation in a laboratory experiment with a production planning game. It reported that its own comparison of the theory of constraints with linear and integer programming for a product-mix problem found the mathematical methods outperformed it.[^2] The study treats the theory as a set of concepts that include a thinking process, a five step approach, nine optimised production technology rules and drum-buffer-rope scheduling, but this page does not describe those other elements in detail.[^2]

## What the sources do not establish

The 1999 article says the theory of constraints was less widely taught than just-in-time and total quality management at that date.[^3] The sources do not report how widely it is used now, and the claims about its effect on profit come from the Institute's summary, not from data.

[^1]: Lean Enterprise Institute, “Theory of Constraints (Lean Lexicon)”. https://www.lean.org/lexicon-terms/theory-of-constraints/
[^2]: Cornell University eCommons (Rohit Verma, DePaul University), 1997 article copy, “Management Science, Theory of Constraints/Optimized Production Technology and Local Optimization”. https://ecommons.cornell.edu/server/api/core/bitstreams/81611c91-9449-4c30-8670-404c7a5853a3/content
[^3]: Arup Mukherjee and Walter J. Wheatley, Developments in Business Simulation and Experiential Learning 26, 1999, “The ABC’s of Teaching the Theory of Constraints to Undergraduate Business Students”. https://absel-ojs-ttu.tdl.org/absel/article/view/976/945

