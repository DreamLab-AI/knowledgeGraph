Freight transportation is the carriage of goods by one or more modes of transport: rail, road, inland waterways, sea, air and, for goods only, pipelines.[^1][^2]

Eurostat says a transport mode refers to the way in which passengers and goods can be transported, and lists rail, maritime, road, inland waterways and air as modes for both, with pipelines carrying goods only.[^1] The Glossary for transport statistics, co-published by Eurostat, the United Nations and the International Transport Forum, gives the classification of methods of transport for statistical reporting as rail, road, inland waterways, maritime, pipeline, air and an unknown mode.[^2]

## Combining modes

That glossary defines multimodal freight transport as the transport of goods by at least two different modes and says that intermodal transport is a particular type of multimodal transport.[^2] Intermodal movement is covered at [[Intermodal Transport]], with the loading unit at [[Shipping Container]] and the practice at [[Freight Containerisation]].

## Measurement

The UK Department for Transport measures goods moved as the weight of goods carried, multiplied by the distance hauled, measured in tonne kilometres.[^3] Eurostat bases the modal split of freight on tonne-kilometres in the same way.[^1] The shares of each mode are given at [[Freight Transport Mode]].

## Policy

The Department for Transport describes its Future of freight plan as the first-ever cross-modal and cross-government plan for the UK freight transport sector, developed in partnership with industry.[^4]

## Scope and distinctions

Freight Transportation sits under [[Supply Chains and Logistics]]. Mode pages are [[Road Freight]], [[Rail Freight]], [[Ocean Freight]] and [[Air Freight]], and commercial offerings are covered at [[Freight Service]]. Related pages are [[Fleet Management]], [[Satellite Communication]] and [[Warehousing and Distribution]].

## What the sources do not establish

Sources opened here give statistical definitions of modes and no single agreed definition of freight transportation as a field. Their measures are in tonne-kilometres or tonnes lifted, and the page does not compare costs or emissions between modes.

[^1]: Eurostat, Statistics Explained, “Glossary:Transport mode”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Transport_mode
[^2]: Eurostat, United Nations and International Transport Forum (OECD), “Glossary for transport statistics”, 5th edition, 2019 (copy hosted by SIPoTra). https://www.sipotra.it/wp-content/uploads/2019/09/Glossary-for-transport-statistics-2019.pdf
[^3]: UK Department for Transport (GOV.UK), “Transport Statistics Great Britain: 2024 Freight”. https://www.gov.uk/government/statistics/transport-statistics-great-britain-2025/transport-statistics-great-britain-2024-freight
[^4]: UK Department for Transport (GOV.UK), “Future of freight plan”. https://www.gov.uk/government/publications/future-of-freight-plan

