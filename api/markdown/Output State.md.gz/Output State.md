
An output state is the record of what an action returned, held inside an [[Execution Context]]. It is the output-side counterpart of [[Input State]], which records what the action received, and the Agent Ontology declares it as `OutputState`.[^1]

An Execution Context reaches it through the property `outputState`. A single datatype property, `outputValue`, has the class as its domain and a string as its range, so the content of an output is carried as serialised text and its structure is left to the schema of whichever action produced it.

Together with its input counterpart, the class lets one context describe both sides of a single action: what went in and what came out. A result that is a produced object, such as a file or a report, is better described by an [[Agent Artefact]], with the output state recording only the value returned to the caller.

visionGraph places Output State under [[Schema]], because it describes the shape in which a result is expressed, and treats it as part of [[Execution Context]].

[^1]: Semantic Agent Communication Community Group, “Execution Context Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/execution-context.ttl

