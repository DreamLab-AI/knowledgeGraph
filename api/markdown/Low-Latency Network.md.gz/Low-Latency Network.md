A low-latency network is a communications network engineered to minimise the round-trip delay experienced by data packets travelling between endpoints. It combines short physical paths, fast switching, prioritised traffic handling, and edge placement of compute so that interactive and real-time applications respond within tight, predictable time bounds. Such networks are foundational to immersive and time-critical experiences where perceptible delay degrades usability.

### Overview

- Latency, not bandwidth, is the binding constraint for interactive systems: a high-[[Bandwidth]] link can still feel sluggish if packets take too long to arrive.
- Total latency is the sum of propagation delay (distance / speed of light in the medium), serialisation delay, queueing delay, and processing delay at each hop.
- Low-latency design attacks each contributor: shorter paths, faster links, fewer hops, prioritised queues, and predictable scheduling.
- The discipline matters across [[Spatial Computing]], finance, industrial control, and multiplayer interaction, anywhere the cost of waiting is high.

### Key aspects

- **Propagation reduction** — placing servers and caches geographically near users, often through [[Edge Computing]] and a [[Content Delivery Network]], shortens the physical distance signals must travel.
- **Traffic prioritisation** — [[Quality of Service]] mechanisms tag and expedite time-sensitive flows ahead of bulk transfers.
- **Deterministic scheduling** — bounded queueing and jitter control make latency predictable, which interactive applications value as much as low average delay.
- **Topology engineering** — flatter, well-provisioned [[Network Topology]] removes congestion points and redundant hops.
- **Protocol selection** — lightweight, connectionless or multiplexed [[Network Protocol]] choices avoid head-of-line blocking and handshake overhead.

### Mechanisms

- Edge nodes terminate sessions near the user so that most interactions never traverse the wide-area core.
- Traffic engineering and shortest-path routing keep packet journeys minimal and stable.
- Pre-fetching and predictive caching hide latency by having data ready before it is requested.
- Hardware acceleration in switches and NICs cuts per-hop processing delay.

### Applications

- [[Cloud Gaming]] and [[Real-Time Rendering]] streamed from remote GPUs, where input-to-photon delay must stay below perception thresholds.
- [[Telepresence]] and [[Real-Time Communication]] for natural, overlap-free conversation.
- [[Immersive Experience]] in extended-reality systems, where motion-to-photon latency drives comfort and presence.
- Industrial automation and remote operation requiring tight control loops.

### Provenance

