
An agent action is a concrete execution event initiated by an agent, producing observable or verifiable consequences.[^1] visionGraph places it under [[Event]]: it depends on an [[Execution Context]] and produces an [[Agent Artefact]].

An agent performs its actions through `executesAction`. The core module connects an action to the artefact it produces (`producesArtifact`), to the [[Agent Trace Event]] that records it (`recordedIn`), and to the execution context that applies to it (`contextOf`). The intent module adds `hasActionType` to an [[Action Type]], `executedIn` to an execution context, and `loggedAs` to a [[Runtime Ledger Event]]. An [[Agent Intent]] reaches an action through `producesAction`.[^2]

The schema.org mapping aligns the class with `schema:Action`.[^3] An action is an event that has been initiated, so a plan or a requested step is an [[Agent Task]] or an [[Agent Intent]] rather than an action.

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Intent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/intent.ttl
[^3]: Semantic Agent Communication Community Group, “Agent Ontology to Schema.org Mapping” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/schema-org-mapping.ttl

