A measurable function that assigns a numerical value to each outcome in the sample space of a random experiment, providing the formal bridge between abstract probability spaces and quantitative analysis. Random variables may be discrete or continuous, are fully characterised by their probability distributions, and underpin expectation, variance, covariance, and the entropy measures central to information theory and statistical machine learning.

### Semantic Classification

### Content

## Definition

A **random variable** is the workhorse abstraction of [[Probability Theory]]: formally, a measurable function X : Ω → ℝ from a probability space (Ω, ℱ, P) to the real numbers, so that statements such as "X ≤ x" correspond to measurable events with well-defined probabilities. This construction lets analysts move from qualitative outcomes (a coin lands heads, a packet arrives late) to numbers that can be summed, averaged, and compared, without abandoning mathematical rigour.

Random variables come in two principal flavours. **Discrete** random variables take countably many values and are described by a probability mass function — the number of dropped frames in a telepresence session, for instance. **Continuous** random variables take values on a continuum and are described by a probability density function — sensor noise, rendering latency, or the position error of a tracked headset. In every case the variable's behaviour is captured by its [[Probability Distribution]], from which moments such as the expectation E[X] and variance Var(X) are derived.

In this knowledge graph, random variables sit beneath much of the analytical machinery: the [[Covariance Matrix]] generalises variance to vectors of random variables, [[Entropy]] in information theory measures the uncertainty of a random variable, and Bayesian inference treats model parameters themselves as random variables to be updated with evidence. Multivariate collections of random variables indexed by time form the [[Stochastic Process]] models used in simulation and forecasting.

## Technical Details

- **Formal definition**: X : Ω → ℝ is a random variable if {ω : X(ω) ≤ x} ∈ ℱ for every x ∈ ℝ (Borel measurability).
- **Distribution function**: F(x) = P(X ≤ x) is non-decreasing, right-continuous, with limits 0 and 1; it fully determines the variable's law.
- **Moments**: E[X] = ∫ x dF(x); Var(X) = E[(X − E[X])²]; higher moments capture skewness and kurtosis.
- **Joint behaviour**: for random vectors (X₁, …, Xₙ), pairwise covariances Cov(Xᵢ, Xⱼ) populate the covariance matrix; independence factorises the joint distribution.
- **Transformations**: functions of random variables (sums, maxima, smooth maps) are themselves random variables — the change-of-variables formula and the central limit theorem govern their limiting behaviour.
- **Common families**: Bernoulli, binomial, and Poisson (discrete); uniform, Gaussian, and exponential (continuous). The Gaussian case dominates machine-learning practice because it is closed under linear maps and maximises entropy for a fixed variance.

  ## Current Landscape

  The concept is settled mathematics; the notes below reconcile the graph's definition with standard references.

- **Codomain generality**: the fully general definition takes a random variable to be a measurable function X : Ω → E into *any* measurable space (E, ℰ) — real-valued (E = ℝ) is the common special case, but random vectors, random matrices, and random graphs are all random variables in this sense. The page's ℝ-valued statement is the widely-taught special case, not the most general form.
- **Measurability condition**: X is measurable iff the preimage X⁻¹(B) ∈ ℱ for every B in the codomain σ-algebra; for real-valued X this reduces to {ω : X(ω) ≤ x} ∈ ℱ for all x, exactly the Borel condition stated in the page's technical details.
- **Distribution as pushforward**: the "law" of X is the pushforward measure P∘X⁻¹ on the codomain — the modern framing that underlies why identically-distributed variables can still differ (e.g. be dependent), a distinction central to probabilistic ML.
- **Contemporary relevance**: this measure-theoretic footing is what makes probabilistic programming, Bayesian deep learning, and diffusion-model noise schedules rigorous, since each manipulates transformations and conditionals of random variables.

  **Sources**:

- https://en.wikipedia.org/wiki/Random_variable
- https://e.math.cornell.edu/people/belk/measuretheory/Probability.pdf
- https://sas.uwaterloo.ca/~dlmcleis/s901/chapt3.pdf

