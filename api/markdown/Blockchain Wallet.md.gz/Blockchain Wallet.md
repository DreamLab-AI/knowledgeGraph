A blockchain wallet is software or hardware that manages the cryptographic keys used to control assets and identities on a blockchain. Rather than storing assets directly, a wallet stores private keys, derives public addresses, and signs transactions that authorise the movement of on-chain assets. Wallets range from custodial services that hold keys on a user's behalf to self-custody solutions where the user retains exclusive control.

### Overview

- A blockchain wallet provides the user-facing entry point to a blockchain network, abstracting key management and transaction construction behind an interface. The defining security trade-off is custody: self-custody wallets give users sole control of their keys and therefore full responsibility for their security, while custodial wallets delegate that responsibility to a third party. Hardware wallets isolate private keys on a dedicated device to reduce exposure to compromised hosts.

### Key aspects

- Wallets generate and store private keys, often deriving many addresses from a single seed phrase.
- Transactions are constructed locally and authorised with cryptographic signatures.
- Custody models range from fully self-custodial to fully custodial, with differing security and recovery properties.
- Hardware wallets keep keys offline, signing transactions without exposing the key to a connected computer.

### Applications

- Holding and transferring cryptocurrencies and tokens.
- Interacting with decentralised finance protocols and smart contracts.
- Managing decentralised identity and on-chain credentials.
- Securing high-value assets through cold storage and hardware isolation.

### Provenance

