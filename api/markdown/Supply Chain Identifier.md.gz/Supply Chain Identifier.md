A supply chain identifier is a code assigned to a product, location, shipping unit or production batch so that trading partners can recognise it and connect records about it.[^1][^2]

GS1 expresses the idea in its own scheme: a GS1 identifier is a data element that expresses an identification key in order to identify an entity and connect to information about that entity.[^1] GS1 says its identification keys let organisations assign standard identifiers to entities such as products, documents, locations and more, and that because the keys are globally unique they can be shared between organisations.[^2]

Identifiers pick out different things. A GS1 identification key may identify a class of entities, such as a trade item, or an instance of an entity, such as a logistic unit.[^1] A batch or lot number groups products made together, while a serial number is assigned to an entity for its lifetime and, combined with a GTIN, identifies an individual item.[^1]

## Identifiers set by regulation

Some identifiers are required by law. Delegated Regulation (EU) 2016/161 requires a unique identifier that is unique to a given pack of a medicinal product, and the serial number inside it must be generated according to randomisation rules.[^3] In the United States, 21 CFR 210.3 defines a lot number as any distinctive combination of letters, numbers or symbols from which the complete history of the manufacture, processing, packing, holding and distribution of a batch or lot of drug product can be determined.[^4]

## Types covered in this domain

GS1 lists the Global Trade Item Number for products and services, the Global Location Number for parties and locations, and the Serial Shipping Container Code for logistics units.[^2] Those are covered at [[Global Trade Item Number]], [[Global Location Number]] and [[Serial Shipping Container Code]]. Two further identifiers apply to groups and single items: [[Batch Number]] and [[Product Serialisation]]. The family of GS1 keys is described at [[GS1 Identification Key]].

## What the sources do not establish

No source opened here defines the term supply chain identifier. The page is bounded by how GS1, the European Union and the United States describe identifiers in their own schemes. The GS1 texts describe one scheme and do not compare it with others, and the legal texts are sector specific, covering medicines and drugs.[^1][^2][^3][^4]

[^1]: GS1, “GS1 General Specifications Standard”, release 26.0. https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf
[^2]: GS1, “GS1 identification keys”. https://www.gs1.org/standards/id-keys
[^3]: European Commission, “Commission Delegated Regulation (EU) 2016/161 of 2 October 2015 supplementing Directive 2001/83/EC of the European Parliament and of the Council by laying down detailed rules for the safety features appearing on the packaging of medicinal products for human use”, legislation.gov.uk copy. https://www.legislation.gov.uk/eur/2016/161/adopted/data.htm
[^4]: US Food and Drug Administration, 21 CFR 210.3, “Definitions” (electronic Code of Federal Regulations). https://www.ecfr.gov/api/renderer/v1/content/enhanced/current/title-21?part=210&section=210.3

