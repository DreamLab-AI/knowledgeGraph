Sustainable procurement is procurement that integrates environmental and social considerations alongside price and quality in decisions about what to buy and from whom.[^1]

ISO 20400:2017 provides guidance to organisations, independent of their activity or size, on integrating sustainability within procurement, as described in ISO 26000.[^1] The catalogue page says the standard is intended for stakeholders involved in, or impacted by, procurement decisions and processes.[^1] Only the catalogue abstract was opened; the standard is cite-only.

## Public procurement

The European Commission's Green Forum page quotes the 2008 Communication on public procurement for a better environment, which defines green public procurement as a process whereby public authorities seek to procure goods, services and works with a reduced environmental impact throughout their life cycle when compared to goods, services and works with the same primary function that would otherwise be procured.[^2] This is the environmental half of the topic; the sources opened do not give an equivalent definition for social procurement.

## Business case

The UN Global Compact and BSR guide says sustainable supply chain management can be a strong driver of value and success, for business as much as for society.[^3] The same guide offers advice on designing a supplier code of conduct, covered at [[Supplier Code of Conduct]].[^3]

## Scope and distinctions

Sustainable procurement is a practice within [[Sustainable Supply Chains]]. The guidance standard is [[ISO 20400]], and the control of suppliers' behaviour once chosen is discussed at [[Supply Chain Governance]]. Due diligence, which is a legal duty in several jurisdictions, is at [[Supply Chain Due Diligence]].

These sources do not give a single definition covering private and public buyers, and they do not report how much procurement is carried out under such criteria.

[^1]: International Organization for Standardization, catalogue page (abstract only; ISO standards are cite-only), ISO 20400:2017 Sustainable procurement — Guidance. https://www.iso.org/standard/63026.html
[^2]: European Commission, Green Forum, Green Public Procurement. https://green-forum.ec.europa.eu/green-public-procurement_en
[^3]: United Nations Global Compact and Business for Social Responsibility, 2010, “Supply Chain Sustainability: A Practical Guide for Continuous Improvement”. https://www.bsr.org/reports/BSR_UNGC_SupplyChainReport.pdf

