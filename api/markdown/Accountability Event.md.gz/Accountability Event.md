
An accountability event is an evaluative record that assesses one executed action for correctness, authorisation and compliance.[^1] It is distinct from the runtime event it evaluates, which is a [[Ledger Event]]; the property `linkedLedgerEvent` joins the two. visionGraph places it under [[Event]].

The class is the hub of the accountability module. It carries an `eventId` and `timestamp`, the `actor` (an agent) and the `action` performed (see [[Agent Action]]), and a free-text `intent`. Three properties point to the evaluation records: `delegationChain` to a [[Delegation Basis]], `responsibility` to a [[Responsibility Attribution]], and `compliance` to a [[Conformity Assessment]].

Together these answer three questions about a single action: whether it was authorised, who is responsible for it, and whether it meets regulatory expectations. The ledger module declares the opposite direction with `accountabilityRecord`, which connects a ledger event to its accountability evaluation. See also [[Accountability]].

[^1]: Semantic Agent Communication Community Group, “Accountability Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/accountability.ttl

