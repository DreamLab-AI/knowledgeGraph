A Human Pose SLAM Capture System is an integrated sensing and computation pipeline that simultaneously localises a device within an unknown environment (SLAM) while continuously tracking the full-body skeletal pose of one or more human occupants in real time. It fuses data from depth cameras, inertial measurement units, and RGB imagery through probabilistic state estimation — typically particle filters or factor-graph optimisers — to produce a joint world model of both the static scene geometry and dynamic human kinematics. The output drives applications including markerless motion capture, avatar animation in extended reality, safety-aware robot navigation around people, and persistent spatial AI anchoring. The discipline sits at the intersection of computer vision, human-computer interaction, and spatial computing, with maturing industrial deployments in XR headsets, telepresence rigs, and autonomous vehicle pedestrian tracking.

### Overview

- **What it is**: a closed-loop perception system that tracks where it is in the world (mapping + localisation) and where each person's body parts are in that world (pose), updating both estimates concurrently at frame rate.
- **Why it matters**: decoupled systems suffer drift between the coordinate frame of the map and the frame of the body tracker, causing avatar foot-sliding, robot collision misses, and broken AR occlusion. A tightly coupled Human Pose SLAM system eliminates this drift by sharing state between the two inference pipelines.
- **How it works**:
  - A front-end processes each incoming frame: extracting [[Visual Feature Extraction]] keypoints for SLAM and human joint heatmaps for pose.
  - A back-end graph optimiser (e.g. [[Factor Graph Optimisation]]) maintains a joint factor graph with pose-graph nodes for camera trajectory and kinematic chain nodes for body joints.
  - [[Loop Closure Detection]] corrects accumulated drift when the camera revisits a known scene region.
  - The combined output is a metrically consistent 3-D skeleton embedded in a persistent [[Scene Reconstruction]] mesh or point cloud.
- **Scope**: applicable to single-person ego-centric capture (inside-out tracking, as in [[XR Headset]] devices) and multi-person outside-in setups (studio arrays, robot observers).

### Key Components

- **Depth Sensing layer**
  - Structured-light or time-of-flight [[Depth Camera]] provides per-pixel range, anchoring skeleton joints in 3-D space.
  - [[LiDAR SLAM]] variants replace depth cameras in outdoor or automotive contexts, trading resolution for range.
- **Inertial backbone**
  - [[Inertial Measurement Unit]] (IMU) at high frequency (200–1000 Hz) bridges camera frame gaps and suppresses motion blur artefacts, critical for fast limb movement.
  - Visual-inertial odometry (VIO) pre-integrates IMU deltas between keyframes, maintaining low-latency pose updates.
- **Pose estimation front-end**
  - 2-D heatmap regression (e.g. HRNet, ViTPose) detects joint locations in the image plane.
  - Lifting networks or direct volumetric regression convert 2-D detections to 3-D joint positions.
  - [[Neural Network Inference]] on-device requires quantised models to meet real-time budgets on mobile SoCs.
- **Joint SLAM back-end**
  - [[Factor Graph Optimisation]] (iSAM2, GTSAM, g2o) maintains sparse landmark map and body trajectory as one unified graph.
  - Marginalisation keeps graph size bounded for real-time operation.
  - Optionally integrates semantic object nodes, linking [[Scene Understanding]] with body pose context.
- **Scene representation**
  - Dense mesh or [[Occupancy Grid]] for navigation and occlusion reasoning.
  - Sparse feature map (ORB, SIFT) sufficient for lightweight localisation without full reconstruction.
  - Neural implicit representations (NeRF variants) emerging as richer but more compute-hungry alternatives.
- **Output layer**
  - Skeletal stream in standard rig formats (BVH, FBX, USD Skel) for downstream [[Avatar Animation]] and [[Digital Twin]] applications.
  - Spatial anchor poses for persistent [[Augmented Reality]] overlays via [[Spatial Anchoring]].

### Applications / Use Cases

- **Extended Reality headsets**
  - Inside-out head tracking (6DoF) combined with hand and body pose enables controller-free full-body avatars in social VR platforms.
  - Devices such as Meta Quest and Apple Vision Pro implement partial variants; full-body SLAM is an active research and productisation frontier.
- **Markerless motion capture**
  - Film and game studios replace optical marker suits with camera-array SLAM rigs, reducing setup time from hours to minutes.
  - Tools like [[OpenPose]] and commercial successors (Move.ai, Kinetix) approximate this pipeline without dedicated SLAM backends.
- **Human-robot collaboration**
  - [[Human Robot Interaction]] safety requires a robot to know exactly where human limbs are relative to its own trajectory plan.
  - Shared SLAM maps allow a robot arm to update a joint occupancy model in real time, enabling predictive collision avoidance.
- **Telepresence and volumetric communication**
  - Capturing a speaker's full body in a metrically accurate room model lets remote participants perceive realistic spatial audio and gaze direction.
  - Drives [[Metaverse Presence]] fidelity and remote collaboration quality.
- **Rehabilitation and sports science**
  - Clinicians use markerless body SLAM to quantify gait asymmetry, joint range of motion, and movement quality without attaching sensors to patients.
  - Removes lab dependency, enabling capture in the field or at home.
- **Autonomous vehicle pedestrian modelling**
  - Vehicles with [[LiDAR SLAM]] maps augment pedestrian detections with full-body pose priors to predict crossing intent and gesture signals.
  - Bridges to [[Autonomous Navigation]] decision systems.
- **Emotion and biometric inference**
  - Body pose dynamics encode proxemic behaviour and micro-gestures correlated with emotional state, supporting affective computing research.
  - Raises significant [[Privacy in XR]] considerations (see Ethics section).

### Technical Challenges

- **Occlusion handling**: self-occlusion (one limb behind another) and environment occlusion break joint visibility, requiring temporal priors and kinematic constraints to infer hidden state.
- **Scale ambiguity**: monocular RGB systems cannot recover metric scale without depth sensors or known objects; depth and IMU are necessary for metrically correct skeletons.
- **Dynamic environment problem**: classical SLAM assumes a static world; humans moving in the scene violate this assumption, requiring people to be explicitly tracked and removed from the static map.
- **Compute budget**: joint factor graph optimisation on resource-constrained XR hardware demands aggressive approximation — fixed-lag smoothers, incremental solvers, and neural acceleration.
- **Multi-person scalability**: tracking N bodies multiplies the state space; data-association across occlusions (who is who after they cross paths) is an active research problem related to [[Multi-Object Tracking]].
- **Privacy and data minimisation**: body pose streams are highly re-identifiable; on-device inference and differential privacy mechanisms are needed before cloud transmission.

### Ethics and Safety

- Motion tracking data in XR has been shown in research to enable re-identification and behavioural profiling even when no explicit identity signal is present (see arXiv:2306.06459 and related work).
- Gait signatures and limb proportions are near-biometric; storing or transmitting raw skeletal streams without consent carries significant GDPR and CCPA implications.
- Affect inference from body language (emotion tracking, arousal/valence annotation) is ethically contentious; standards bodies including the [[IEEE]] and the EU AI Act classify such systems as high-risk where they influence consequential decisions.
- Safety-critical deployments (surgical robotics, autonomous vehicles) require validated uncertainty estimates on pose outputs, not just point estimates.
- [[Privacy in XR]] literature recommends anonymising skeletal data at capture time, retaining only task-relevant joint subsets.

### Standards and Context

- No single dedicated standard governs Human Pose SLAM as an integrated system; relevant specifications span multiple bodies:
  - **OpenXR** (Khronos Group) defines body tracking API extensions for XR runtimes, providing a standard interface for consuming skeletal output.
  - **USD Skel** (Pixar/ASWF) standardises skeletal rig interchange for downstream rendering and animation pipelines.
  - **IEEE 1873-2015** (robot map data representation) provides vocabulary for the SLAM map component.
  - **BVH / C3D** are legacy interchange formats for motion capture data, widely supported but lacking semantic metadata.
  - **W3C Immersive Web** working group addresses web-based XR device APIs that surface pose data in browser contexts.
- Related academic benchmarks: TUM RGB-D (SLAM evaluation), Human3.6M and MPI-INF-3DHP (3-D pose estimation), PROX (joint scene + body dataset).

### Provenance

