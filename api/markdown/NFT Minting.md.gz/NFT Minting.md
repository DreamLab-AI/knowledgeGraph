NFT Minting is the on-chain or deferred off-chain process by which a unique, indivisible, and cryptographically authenticated digital token—a non-fungible token—is created and permanently recorded on a distributed ledger, establishing irrevocable provenance, ownership, and transferability for a l...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ERC721Standard))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ERC1155Standard))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:TokenMetadata))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:IPFSStorage))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ArweaveStorage))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:CreatorRoyalty))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:MintFunction))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:TransferEvent))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:TokenURI))

    ## Dependency Relationships
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:requires blockchain:SmartContract))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:requires blockchain:BlockchainNetwork))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:requires blockchain:GasFee))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:requires blockchain:WalletAddress))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:requires blockchain:TokenStandard))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:Ethereum))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:SmartContracts))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:IPFS))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:GasMechanism))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:CryptographicHashFunction))

    ## Capability Relationships
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:enables blockchain:DigitalOwnership))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:enables blockchain:ProvenanceTracking))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:enables blockchain:CreatorEconomy))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:enables blockchain:RealWorldAssetTokenisation))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:enables blockchain:SoulboundToken))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:enables blockchain:OnChainIdentity))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:supports blockchain:DigitalArtMarket))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:supports blockchain:GamingNFTs))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:supports blockchain:MusicNFTs))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:supports blockchain:BrandLoyaltyNFTs))

    ## Implementation Relationships
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:implements blockchain:ERC721Standard))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:implements blockchain:ERC1155Standard))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:implements blockchain:EIP2981RoyaltyStandard))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:implements blockchain:EIP5192LockingStandard))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:implements blockchain:EIP712TypedSigning))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:implements blockchain:LazyMinting))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:implements blockchain:BatchMinting))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:uses blockchain:Solidity))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:uses blockchain:OpenZeppelinContracts))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:uses blockchain:MerkleTree))

    ## Reduction Relationships
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:reduces blockchain:GasCostViaL2))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:reduces blockchain:MintingBarrierViaLazyMinting))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:reduces blockchain:ProvenanceFrictionViaOnChainRecord))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:reduces blockchain:MetadataVolatilityViaIPFS))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:reduces blockchain:CounterfeitRiskViaTokenUniqueness))

    ## Association Relationships
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:NFTMarketplace))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:BlockchainInteroperability))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:DecentralisedFinance))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:BitcoinOrdinals))
    SubClassOf(blockchain:NftMinting
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:Metaverse))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(blockchain:hasIdentifier blockchain:NftMinting "BC-1000"^^xsd:string)
    DataPropertyAssertion(blockchain:authorityScore blockchain:NftMinting "0.87"^^xsd:decimal)
    DataPropertyAssertion(blockchain:peakMarketVolume blockchain:NftMinting "25000000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:erc721GasCost blockchain:NftMinting "80000"^^xsd:integer)
    DataPropertyAssertion(blockchain:l2GasCostReduction blockchain:NftMinting "0.99"^^xsd:decimal)

    ## Property Constraints
    SubClassOf(blockchain:NftMinting
      DataAllValuesFrom(blockchain:requiresUniqueTokenId xsd:boolean))
    SubClassOf(blockchain:NftMinting
      DataSomeValuesFrom(blockchain:tokenStandardType xsd:string))
    SubClassOf(blockchain:NftMinting
      DataMinCardinality(1 blockchain:hasMetadataURI xsd:anyURI))

    ## Annotations
    AnnotationAssertion(rdfs:label blockchain:NftMinting "NFT Minting"@en)
    AnnotationAssertion(rdfs:comment blockchain:NftMinting "The on-chain or lazily-deferred process of creating a unique, indivisible cryptographic token on a distributed ledger via smart contract invocation, establishing irrevocable provenance and programmable ownership for digital and physical assets, standardised through ERC-721 and ERC-1155, with metadata persistence via IPFS/Arweave and creator royalties via EIP-2981."@en)
    AnnotationAssertion(dcterms:identifier blockchain:NftMinting "BC-1000"^^xsd:string)
    AnnotationAssertion(dcterms:subject blockchain:NftMinting "Blockchain, Digital Assets, Smart Contracts, Creator Economy, Tokenisation"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(blockchain:requires)
  AsymmetricObjectProperty(blockchain:enables)
  AsymmetricObjectProperty(blockchain:implements)
  AsymmetricObjectProperty(blockchain:reduces)
  TransitiveObjectProperty(blockchain:dependsOn)
  FunctionalDataProperty(blockchain:authorityScore)
  FunctionalDataProperty(blockchain:peakMarketVolume)

## About NFT Minting

- **NFT Minting** denotes the on-chain act of instantiating a non-fungible token within a blockchain's global state by calling a [[Smart Contract]] method that assigns a cryptographically unique identifier, records the originating owner address, and anchors a content-addressed metadata document to the token record. The term "minting" borrows from monetary coinage—the act of bringing new currency into existence—but in the blockchain context it specifically means the state transition from token non-existence (owned by `address(0)`, the null address) to token existence (owned by a designated wallet), a transition permanently and immutably recorded in the chain's history.
- The fundamental value proposition rests on the property of **provable digital scarcity**: unlike a JPG image which can be copied infinitely, a minted NFT exists in exactly one location on a specific blockchain, has one canonical owner at any point in time (per the contract's `ownerOf` mapping), and carries a verifiable history of all prior ownership transfers encoded in the chain's transaction log. This combination—scarcity, ownership, transferability, composability—distinguishes NFTs from earlier approaches to digital collectibles (e.g., MP3 metadata, proprietary game item databases) and enables genuinely permissionless secondary markets where buyer and seller transact without platform intermediation.

### Minting Transaction Lifecycle

The **minting transaction lifecycle** proceeds through five distinct phases, each with distinct technical requirements and failure modes:

**Phase 1 — Pre-mint preparation**: The creator deploys a [[Smart Contract]] (or uses a platform's shared contract via Manifold, Zora, or OpenSea's shared storefront), uploads media to [[IPFS]] or [[Arweave]], constructs the metadata JSON per the OpenSea schema, records the CID, and configures `baseTokenURI` or individual token URIs.

**Phase 2 — Transaction submission**: The minter's wallet broadcasts a `mint()` call signed with the wallet's private key, including sufficient ETH to cover gas. EIP-1559 fee estimation determines `maxFeePerGas` (base fee cap) and `maxPriorityFeePerGas` (validator tip); if `maxFeePerGas` falls below the network's base fee, the transaction remains pending in the mempool until network conditions change.

**Phase 3 — EVM execution**: Validators include the transaction in a block; the [[Ethereum]] Virtual Machine executes the mint function, writes storage slots (`_owners[tokenId]` and `_balances[to]`), and emits the Transfer event `(address(0), to, tokenId)`. The gas consumed is debited from the sender's balance; the base fee is burned per EIP-1559; the priority fee goes to the validator.

**Phase 4 — Finality**: After sufficient block confirmations (12+ blocks / ~144 seconds for Ethereum mainnet probabilistic finality, 1–2 blocks / ~2 seconds for [[Polygon]] PoS, near-instant for Base/Arbitrum via optimistic rollup with 7-day challenge window for finality), the token is considered safely minted and ownership is established.

**Phase 5 — Marketplace indexing**: Off-chain indexers (OpenSea, Blur, Reservoir API) detect the Transfer event via JSON-RPC `eth_getLogs` or WebSocket subscription, fetch metadata from the tokenURI, decode the JSON, and display the token in the creator's and buyer's wallets with media and attributes populated.

### Token Standards in Detail

**ERC-721 interface specification**: Six mandatory functions (`balanceOf(address)`, `ownerOf(uint256)`, `safeTransferFrom(address,address,uint256,bytes)`, `safeTransferFrom(address,address,uint256)`, `transferFrom(address,address,uint256)`, `approve(address,uint256)`, `setApprovalForAll(address,bool)`, `getApproved(uint256)`, `isApprovedForAll(address,address)`); three events (`Transfer`, `Approval`, `ApprovalForAll`); Metadata extension (`name()`, `symbol()`, `tokenURI(uint256)`) and Enumerable extension (`totalSupply()`, `tokenByIndex(uint256)`, `tokenOfOwnerByIndex(address,uint256)`).

**ERC-1155 design rationale**: A single contract manages multiple token types (IDs 0–2^256), each with its own supply, via `balanceOf(address,uint256)` and `balanceOfBatch(address[],uint256[])`. The single-contract model saves ~50% deployment gas vs deploying separate ERC-721 contracts per item type, critical for gaming economies managing thousands of item types. The `uri(uint256)` function returns a URI template with `{id}` substituted server-side.

**ERC-721A** (Azuki team, Chiru Labs 2021): By initialising ownership data lazily (storing only the first owner of a consecutive batch rather than each token's owner individually), ERC721A reduces batch-minting gas from ~O(n × 25,000) to ~O(1 × 25,000 + n × 3,000), saving ~70% gas on 10,000-token drops (from ~800M gas to ~270M gas at 80K gas/token, a ~$60,000–$200,000 saving on 2021 L1 gas prices).

**ERC-721C** (LimitBreak, August 2023): Programmable transfer hooks via `ICreatorTokenTransferValidator` interface allow contract owners to enforce royalty payment at the protocol level; compatible marketplaces (Magic Eden, Blur season 3, Foundation) check the validator and reject transfers that do not route royalties to the specified receiver, addressing the 2022–2023 marketplace royalty crisis.

**Standard comparison matrix**:

- ERC-721: Single-token-type, 1 token per ID, mandatory uniqueness; best for 1-of-1 art, PFP collections, domain names
- ERC-1155: Multi-token-type, N tokens per ID, mixed fungibility; best for gaming items, edition prints, event tickets at scale
- ERC-721A: Gas-optimised ERC-721 for batch mints of 1,000–100,000 tokens; best for large PFP drops
- ERC-721C: ERC-721 with enforcement hooks; best for creator-royalty-critical collections (gaming, premium art)
- ERC-4907 Rental Standard: Adds `user` role distinct from `owner`, enabling time-limited rental of NFTs (gaming item rental, ticket delegation) without ownership transfer
- ERC-6551 Token Bound Accounts: Each ERC-721 token can own assets and execute transactions via a deterministic smart contract wallet derived from the token address and ID; enables "backpack" NFTs carrying sub-assets

### Royalty Enforcement Technical Analysis

**EIP-2981 mechanics**: The `royaltyInfo(uint256 tokenId, uint256 salePrice)` function returns `(address receiver, uint256 royaltyAmount)`; typically `royaltyAmount = salePrice × royaltyFee / 10000` where `royaltyFee` is a basis-point integer (e.g., 500 = 5%). Marketplaces query this function before finalising each sale and route the `royaltyAmount` to `receiver` in the same transaction.

**Enforcement failure modes**:

- Platform opt-out: Blur, X2Y2, LooksRare initially offered optional-royalty modes, creating a race-to-the-bottom dynamic where NFT holders preferred zero-royalty platforms for secondary liquidity
- Aggregator bypass: Seaport-based aggregators could route trades through non-royalty-checking intermediaries
- Wash trading: Sellers buying their own NFTs back at inflated prices could farm royalties on non-enforcing platforms

  **ERC-721C enforcement mechanism**:

- Contract specifies a `TransferValidator` address implementing `ICreatorTokenTransferValidator`
- The validator's `validateTransfer(caller, from, to, tokenId)` reverts if royalties are not correctly routed
- Marketplaces must integrate the validator to list ERC-721C tokens; non-compliant marketplaces simply cannot transfer these tokens
- Adopted by: all Immutable IMX games, Magic Eden's Bitcoin Ordinals marketplace, Foundation, SuperRare (2024 contract upgrades)

  **Royalty crisis economic timeline**:

- October 2022: Blur launches with optional royalties; captures 15% of volume in first month
- November 2022: OpenSea enables optional royalties for new collections without Operator Filter; many creators disable royalties
- January 2023: Blur Season 1 airdrop incentivises volume; captures 50%+ share; artist income collapses
- April 2023: OpenSea deprecates Operator Filter Registry entirely, citing adoption failure
- August 2023: LimitBreak releases ERC-721C as open-source alternative enforcement mechanism
- 2024–2026: Royalty enforcement bifurcates: gaming NFTs (Immutable, Flow) maintain ~5–10% royalties via protocol enforcement; art/PFP collections on open markets effectively operate at 0% optional royalties

## Components / Architecture

### Smart Contract Implementation Patterns

**OpenZeppelin contract library** (v4.x and v5.x, Solidity 0.8.x) provides the dominant implementation foundation:

- `ERC721.sol`: Base implementation with internal `_mint(to, tokenId)` and `_safeMint(to, tokenId)` functions
- `ERC721URIStorage.sol`: Per-token URI mapping via `_setTokenURI(tokenId, uri)`, higher storage gas cost (~$5–$20 per token on L1 vs ~$1–$3 for `baseURI` pattern)
- `ERC721Enumerable.sol`: On-chain enumerable token lists, highest gas cost (3 extra storage writes per mint), used where on-chain querying is required
- `ERC721Consecutive.sol`: EIP-2309 batch minting via single `ConsecutiveTransfer` event for ranges, O(1) gas per token in batch vs O(n) in standard ERC-721
- `ERC721Royalty.sol`: Integrates EIP-2981 `royaltyInfo()` with configurable fee numerator

  **Merkle allowlist pattern**: A 32-byte Merkle tree root is stored on-chain; individual whitelisted addresses are verified at mint time by submitting a Merkle proof (array of sibling hashes) to the contract's `mint(bytes32[] calldata proof)` function, which calls `MerkleProof.verify(proof, root, leaf)`. This pattern enables gas-efficient allowlist enforcement for 50,000+ addresses with only one `bytes32` stored in contract state vs ~$100K gas to store 50,000 addresses individually.

  **Batch minting gas benchmarks** (Ethereum mainnet 2024, 30 Gwei base fee, $2,500 ETH):

- Standard ERC-721 `mint()` per token: ~80,000 gas = $6.00
- ERC721A batch of 10 tokens: ~85,000 gas total = $6.38 (vs $60 for 10 × ERC-721)
- ERC-1155 `mintBatch(10 types × 1)`: ~90,000 gas total = $6.75
- On-chain SVG storage (`tokenURI` returning base64 JSON): ~300,000–2,000,000 gas per token depending on data size

  **Access control security patterns**:

- `Ownable.sol`: Single owner, `onlyOwner` modifier, suitable for simple collections
- `AccessControl.sol`: Role-based, `MINTER_ROLE` / `PAUSER_ROLE` / `ADMIN_ROLE`, suitable for platform contracts with multiple operator types
- Multisig treasury: Gnosis Safe 3-of-5 multisig for contract ownership of high-value collections (BAYC, CryptoPunks, Art Blocks)
- `ReentrancyGuard.sol`: Protects `safeMint` against reentrancy attacks from malicious ERC721Receiver implementations

### Metadata Architecture in Depth

**OpenSea metadata schema** (de facto standard, widely adopted by Blur, Rarible, Foundation):

- `name` (string): Token display name, e.g., "Bored Ape #7090"
- `description` (string): Markdown-formatted description up to ~1,000 characters
- `image` (URI): Primary media (PNG/JPG/SVG/GIF); max 40MB recommended, IPFS CID preferred
- `animation_url` (URI): Interactive/animated content (HTML, MP4, MP3, GLB 3D models)
- `external_url` (URI): Project website or token-specific detail page
- `attributes` (array): `[{"trait_type": "Background", "value": "Aquamarine"}, ...]`; basis for rarity ranking and marketplace filtering
- `background_color` (hex string): 6-character hex for OpenSea background display

  **On-chain storage economics**:

- Ethereum storage costs 20,000 gas per 32-byte slot written (~$1.50 per slot at $2,500 ETH / 30 Gwei)
- A 10KB SVG image requires ~313 storage slots = ~$470 per token on L1 mainnet
- Art Blocks generative scripts (p5.js + custom algorithm, typically 5–50KB) stored once per "project" not per token, amortising cost across 600–1,000 editions
- Fully on-chain projects (Autoglyphs, Nouns DAO, Loot) accept the premium for maximum durability

  **IPFS content addressing**:

- CID v0 (SHA2-256, base58 multihash): e.g., `QmXoypizjW3WknFiJnKLwHCnL72vedxjQkDDP1mXWo6uco`
- CID v1 (SHA2-256, base32 multibase): e.g., `bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi`
- Pinning services: Pinata (2M+ files pinned, 100GB free tier), Infura IPFS, nft.storage (now web3.storage, Internet Archive-backed), Filebase (S3-compatible IPFS)
- Risk: If all pinning nodes remove a file, the CID remains valid but the content is unretrievable; Jonty Wareing's 2021 analysis "Most NFTs are already broken" quantified 40%+ of NFT images hosted on centralised servers with no IPFS pinning

  **Arweave permanent storage model**:

- One-time upload fee per file, endowment model funding 200-year storage via SPoRA (Succinct Proofs of Random Access) mining
- Storage cost ~$0.005–$0.01 per KB (2024 AR token prices); a 1MB image costs ~$5–$10 to store permanently
- Bundlr Network (now Irys) provides subsidised batched Arweave uploads accepting ETH/MATIC/SOL payment with immediate availability confirmation
- Used by: Metaplex (Solana NFT standard), Magic Eden uploads, major art platforms

### Gas Optimisation and Layer 2 Deployment in Detail

**EIP-1559 gas mechanics** (August 2021 London fork):

- Base fee: algorithmically determined per block, targeting 50% full blocks; burned (not paid to validators)
- Priority fee (tip): paid to validators/miners as incentive for inclusion; 1–3 Gwei typical outside congestion
- Max fee: user-specified ceiling, unused portion refunded; transaction reverts if base fee exceeds max fee
- Impact on NFT minting: predictable cost estimation (Etherscan Gas Tracker, MetaMask fee estimator) vs pre-1559 first-price auction; peak congestion during major drops (Otherdeeds, Goblintown) still drove base fees to 500–3,000 Gwei

  **Layer 2 cost comparison** (2024–2025 benchmarks for ERC-721 mint):

- Ethereum mainnet: $2–$15 (30–50 Gwei base fee, $2,000–$3,000 ETH)
- Polygon PoS: $0.001–$0.005 (MATIC denominated, ~$0.00001 MATIC/gas)
- Arbitrum One: $0.05–$0.20 (L2 execution + L1 calldata compression)
- Optimism: $0.05–$0.20 (similar to Arbitrum, EVM-equivalent)
- Base: $0.01–$0.05 (Optimism Superchain, heavily subsidised via Coinbase)
- Immutable X: $0 (gas-free for users, gasless minting via StarkEx validium)
- Solana: $0.0001–$0.001 (per-transaction fee, Metaplex NFT standard)

  **Zora Protocol architecture** (zora.co, Base-native):

- Permissionless free minting: any address can deploy a Zora collection contract for $0 (Base gas only ~$0.01)
- Protocol mint fee: 0.000777 ETH per collect (split: creator 0.0007 + referrer 0.000049 + Zora 0.000028)
- "Zora Collect" model: 100,000+ collectors minting a single creator's work at fixed price generates streaming royalty income vs traditional one-time primary sale
- Reached 10M+ total mints on Base by mid-2024, 500,000+ unique collectors

## Use Cases / Major Families

### Digital Art and Collectibles

**CryptoPunks** (Larva Labs 2017, acquired by Yuga Labs 2022): 10,000 algorithmically generated 24×24 pixel characters with 87 attributes (hat, glasses, skin, accessory types) distributed across varying rarity tiers; minted for free in 2017, floor prices reached 80+ ETH ($300,000+) in early 2022, total sales volume exceeding $2B; retroactively compliant with ERC-721 via an official wrapper contract; recognised as the origin of the "PFP" (Profile Picture Project) NFT genre.

**Bored Ape Yacht Club** (BAYC, Yuga Labs April 2021): 10,000 ERC-721 apes on Ethereum with trait rarity, a members-only Discord, commercial licensing rights granted to holders (enabling $1M+ merchandise brands built on single tokens), major celebrity adoption, and the "Otherside" metaverse expansion (Otherdeeds land parcels minted April 2022, causing Ethereum gas prices to reach 8,000+ Gwei during the mint event).

**Art Blocks** (generative on-chain art, launched November 2020): The ArtBlocks Engine contract stores algorithmic art scripts on-chain; at mint time, the transaction hash serves as the deterministic random seed; the `tokenURI` function executes the script to generate a unique SVG/p5.js artwork—genuine on-chain provenance eliminating metadata availability risk. Notable collections: Chromie Squiggle (Snowfro/Erick Calderon, 9,000 editions, secondary market $3M+ floor), Ringers by Dmitri Cherniak (1,000 editions, single token sold for $6.9M).

**SuperRare / Foundation / KnownOrigin**: Curated single-edition or limited-edition platforms for fine digital art. SuperRare: 1-of-1 ERC-721 tokens, 15% primary commission, 10% secondary royalty (EIP-2981). Foundation: open application, 15% primary, 5% secondary. KnownOrigin: UK-based (Leeds/Manchester), 15% primary, 3-10% secondary, strong European artist community.

### Gaming Assets

**Axie Infinity** (Sky Mavis, Vietnam, Ronin sidechain): Pioneered "play-to-earn" P2E with Axie NFT creatures requiring purchase for game entry (average $300–$1,500 during 2021 peak); generated $4B+ in 2021 NFT sales across Axies, land, and items; the March 2022 Ronin bridge hack ($625M stolen via compromised validator private keys) demonstrated the catastrophic single-sidechain security risk; the subsequent Axie economy collapse (AXS token -98%, SLP scholarship economics destroyed) exposed the unsustainability of hyperinflationary P2E token design.

**Gods Unchained** (Immutable X, Immutable Pty Ltd, Sydney): Free-to-play trading card game with ERC-721 cards minted on Immutable X (StarkEx validium ZK rollup, 9,000 TPS, gas-free); cards are true player-owned assets tradeable on IMX marketplace; the game demonstrated that gas-free minting on a dedicated gaming rollup could support genuine NFT utility without speculative P2E mechanics.

**Immutable Passport** (2024): Unified cross-game NFT identity enabling assets, progress, and rewards to be recognised across multiple Immutable games without re-minting, a limited but genuine implementation of the theoretical cross-game NFT portability value proposition.

**Limitations of the "true ownership" narrative**: Cross-game asset portability requires active studio integration (art style conflicts, balance considerations, legal IP agreements) and is rarely implemented; "owning" an in-game NFT in a game that shuts down leaves the holder with a token pointing to a dead server's metadata—as demonstrated by several 2022–2023 P2E game shutdowns (Crabada, Pegaxy) where NFTs became worthless despite continuing on-chain existence.

### Music NFTs

**Royal.io** (3LAU / Justin Blau): Fans purchase fractional streaming royalty ownership as NFTs (ERC-721 tiers with different royalty split percentages); holders receive quarterly USDC distributions proportional to Spotify/Apple Music streaming revenue; demonstrated with Blau's own catalog ($11.6M raised in 2021 drop) and external artists (Nas, The Chainsmokers). Represents a structural shift from streaming platform dependency ($0.003–$0.005/stream) to direct fan ownership of revenue streams.

**Sound.xyz**: Edition-limited single-track and album NFTs (typically 25–100 editions, $5–$50 mint price); the NFT receipt enables on-chain "plays" (social listening signal), first-comment privileges, and community access gating; artists include Daniel Allan (raised $140K via "Overstimulated" EP crowdfund), Reo Cragun, and Snoop Dogg (Shady Records x Sound.xyz partnership).

**Catalog**: 1-of-1 single-edition music NFTs where the holder owns the unique "record" of a song—not the copyright, but the canonical provenance record; prices range from 0.1–50 ETH; notable sales include RAC's album "BOY" (1-of-1 original master NFT sold for $1.03M in 2021).

### Ticketing and Event NFTs

**GET Protocol** (Netherlands, open-source): 3M+ NFT tickets minted 2019–2024 for concerts, festivals (Lowlands NL, Sziget HU), and sports events; enables transparent secondary market trading at market-determined prices (capturing scalper premium for venues/artists rather than arbitrageurs), and instant counterfeit verification via `ownerOf` query at venue gate without centralised database dependency.

**YellowHeart** (US): NFT tickets with encoded perks (front-row seats, backstage passes, digital collectible) as attributes accessible post-event; partnership with Kings of Leon ("When You See Yourself" album: 3-in-1 NFT with album access + concert ticket + perks), Maroon 5, and various festival brands.

**Tokenproof** (US): Mobile wallet-to-gate infrastructure enabling ERC-721/1155 token verification without requiring the holder to sign a transaction or reveal a private key; the verifier device generates a challenge, the holder signs with their wallet app, Tokenproof verifies the signature against the on-chain `ownerOf` record—solving the practical "wallet-gating at physical events" UX problem.

### Real World Asset (RWA) Tokenisation

**RealT** (US residential real estate, 400+ properties, $100 minimum investment): Each property is owned by an LLC; the LLC interests are fractionalized into ERC-20 tokens (fungible fractional ownership) or ERC-721 tokens (single-owner, whole-property); rental income distributions are automated via smart contract token distribution functions executing weekly; secondary market liquidity via Uniswap/Balancer pools. Legal structure: Delaware LLC holding title, operating agreement binds tokenholders to LLC terms.

**BlackRock BUIDL Fund** (BlackRock USD Institutional Digital Liquidity Fund, launched March 2024 on Ethereum): Tokenised money market fund investing in US Treasury bills, overnight repos, and cash; ERC-20 tokens accruing daily yield; reached $500M AUM within weeks of launch; signalled institutional legitimisation of on-chain RWA tokenisation at the world's largest asset manager ($10T AUM).

**Centrifuge**: Tokenises private credit instruments (invoices, trade receivables, real estate mortgages, microfinance portfolios) as ERC-1155 tokens (senior/junior tranche structure); enables DeFi protocols (Aave, MakerDAO/Maker/Sky) to accept real-world collateral for stablecoin issuance; total financed volume exceeded $500M by 2024, representing the largest real-economy DeFi credit protocol.

**Legal architecture challenges**: The NFT represents a legal interest (LLC membership, contractual revenue right, security entitlement), not the interest itself; enforcing on-chain token ownership against off-chain legal systems requires jurisdiction-specific SPV structures, title transfer documentation, KYC/AML compliance, and in many jurisdictions securities law registration (SEC Regulation D exemptions, UK FCA regulatory perimeter).

### Soulbound Tokens and Decentralised Identity

**SBT conceptual framework** (Buterin/Weyl/Ohlhaver 2022): "Souls" are wallets accumulating non-transferable "Soulbound Tokens" representing credentials, attestations, affiliations, and social reputation; SBTs from multiple "Souls" (employer, university, community) jointly attest to a person's real-world identity and social graph; proposed applications include Sybil-resistant democratic governance, undercollateralised lending based on on-chain reputation, and community recovery of lost Soul keys.

**EIP-5192 Minimal Soulbound NFT standard** (finalised 2023): Adds `locked(uint256 tokenId) returns (bool)` function to ERC-721; if `locked()` returns `true`, the token is permanently non-transferable; the `Locked(tokenId)` event signals the lock state to indexers.

**Ethereum Name Service (ENS)**: `.eth` domains minted as ERC-721 NFTs with annual renewal fees (0.003 ETH/year for 5+ character names); function as human-readable wallet addresses, decentralised website pointers, and social identity handles; 3M+ registered names by 2024; `.eth` resolution via ENS Resolver contract's `addr(bytes32 node)` function.

**Gitcoin Passport** (Ceramic Network + EAS attestations): Aggregates identity "stamps" (Twitter, GitHub, ENS, BrightID, Worldcoin, Coinbase KYC) as Verifiable Credentials stored on Ceramic Streams; on-chain score via EAS (Ethereum Attestation Service) attestations; 900,000+ unique passport holders by 2024; used for Sybil-resistant quadratic funding distributing $50M+ in public goods grants.

### IP, Copyright, and Legal Status of NFTs

**The copyright ownership gap** (Guadamuz 2021, Fairfield 2021): Purchasing an NFT does not transfer copyright in the underlying work absent an explicit IP assignment agreement. The NFT is a property record—a unique entry in a contract's `ownerOf` mapping—not a licence or assignment of intellectual property. This means:

- The NFT holder owns the token (on-chain record) but not the image, video, or audio it represents
- The creator retains copyright and can sell additional prints, create derivative works, or licence the IP
- The NFT holder cannot prevent others from copying the image (right of reproduction is the copyright owner's)
- Exception: BAYC's IP licence grants holders "a worldwide license to use, copy, and display the purchased Art" for commercial purposes—this is a contractual licence, not a copyright assignment, but it provides meaningful commercial utility

  **Disputes and enforcement cases**:

- Roc-A-Fella Records v. Damon Dash (2021): Court issued TRO preventing Dash from selling NFT of Jay-Z's "Reasonable Doubt" album artwork; court confirmed that copyright owner (label) not NFT owner controls tokenisation rights
- Miramax v. Quentin Tarantino (2021): Tarantino's planned Pulp Fiction NFT auction challenged by Miramax on grounds that the studio's IP licence covers "tokenisation rights"; settled out of court
- Hermès v. Mason Rothschild (MetaBirkin NFTs, 2023): Jury found Rothschild's MetaBirkin NFTs constituted trademark infringement of Hermès's BIRKIN mark; $133,000 damages awarded; significant precedent for "digital fashion" NFT trademark liability
- Getty Images v. Stability AI UK (2025): While primarily an AI training data case, judgment's analysis of unauthorised reproduction in AI-generated outputs has direct bearing on AI-minted NFT collections using unlicensed training data

  **UK-specific considerations**:

- HMRC (HMRC CRYPTO22000): NFTs are taxable cryptoassets; disposal (sale, transfer, gifting) triggers Capital Gains Tax at 10% (basic rate) or 20% (higher rate); mining/creating NFTs for profit constitutes trading income subject to Income Tax
- CDPA 1988 s.9(3): Computer-generated works are protected with the "author" being the human who undertook the arrangements for creation; potentially applicable to AI-generated NFT art where a human configured the generation pipeline
- FCA financial promotions: UK-targeted NFT marketing requires FCA authorisation or an exemption as of October 2023 (PS23/6)

### Platform and Tooling Ecosystem

**Deployment tooling** for NFT smart contracts in 2024–2026:

- Hardhat (JavaScript/TypeScript, HardhatHQ): Local EVM node, contract compilation (solc), testing (Ethers.js/Waffle/Chai), deployment scripts; industry standard for Ethereum NFT development
- Foundry (Rust-based, Paradigm): Faster compilation (10–100× vs Hardhat), Forge testing framework, Cast CLI for on-chain interactions; growing adoption for security-conscious NFT teams
- Remix IDE (web-based, Ethereum Foundation): Browser-based Solidity editor and deployer; ideal for prototyping and educational use
- Manifold Studio (no-code/low-code): Deploys audited OpenZeppelin ERC-721/1155 contracts with Manifold's extension framework; used by 100,000+ creator contracts deployed by 2025

  **Minting infrastructure services**:

- Alchemy and Infura: JSON-RPC node providers ($0–$500/month tiers) with NFT API endpoints (`getNFTsForOwner`, `getNFTMetadata`, `getOwnersForCollection`) and webhook-based Transfer event monitoring
- Moralis: Web3 data platform with cross-chain NFT streaming, wallet history APIs, real-time event streams; widely used in NFT project backends
- OpenSea API / Reservoir API: Indexing and aggregation APIs for NFT listings, offers, and sales events; Reservoir is open-source and supports cross-marketplace aggregation
- Pinata / web3.storage: IPFS pinning services with bulk upload APIs, CID management dashboards, and NFT metadata pinning workflows

  **On-chain analytics tooling**:

- Nansen.ai: Wallet labelling ("smart money", "NFT influencer", "wash trader" labels), NFT holder distribution analytics, mint participation tracking; subscription $150–$1,500/month
- Dune Analytics: SQL-based on-chain data queries across Ethereum/Polygon/Arbitrum/Base; community-created NFT dashboards for wash trade detection, collection health metrics, royalty compliance
- NFTGo: Portfolio tracking, collection rarity ranking, market trend analytics; widely used by retail NFT investors and collectors

  **NFT standards tooling** for creators:

- IPFS Desktop / Pinata SDK: File upload, CID generation, pinning management for NFT media and metadata
- NFT.storage (now web3.storage): Free tier IPFS + Filecoin cold storage for NFT assets, funded by Protocol Labs; 100M+ files stored by 2024
- Irys (formerly Bundlr): One-line Arweave permanent upload via Arweave.js / @irys/sdk, accepting ETH/MATIC/SOL payment
- Hashlips Art Engine: Open-source layered art generation tool for PFP collections; GitHub stars 17,000+; generates 10,000 unique images from trait layers with rarity configuration

  **Blockchain explorers for NFT verification**:

- Etherscan.io: Transaction history, token transfer logs, ERC-721/1155 token pages with holder distribution; standard verification tool for Ethereum NFTs
- OpenSea / Blur / Reservoir: Off-chain metadata indexers providing human-readable NFT display, historical sales, trait rarity scores
- IPFS gateway (ipfs.io, Cloudflare IPFS): CID resolution for metadata and media verification; `ipfs://QmXYZ` → `https://ipfs.io/ipfs/QmXYZ`

## Academic Context

- **Valeonti et al. (2021)** "Crypto Collectibles, Museum Funding and OpenGLAM" in *Applied Sciences* provided the foundational academic treatment of NFT applications in cultural heritage institutions, examining how museums (British Museum, Hermitage, Uffizi) might use NFTs to generate revenue, extend access, and create verifiable digital provenance—cited as the most rigorous early institutional analysis of NFT utility beyond speculative trading.
- **Nadini et al. (2021)** "Mapping the NFT Revolution" in *Scientific Reports* (Nature Portfolio) conducted the largest empirical analysis of NFT markets at the time: 6.1M trades, 4.7M assets, 160,000 wallets; key findings included power-law price distributions (top 10% of assets capture 90% of volume), wash trading signatures (~3% of sales involving the same buyer-seller pair within 3 days), and significant visual feature correlates (brightness, colour diversity, symmetry) of sale price.
- **Wang et al. (2021)** "Non-Fungible Token (NFT): Overview, Evaluation, Opportunities and Challenges" (arXiv:2105.07447) became the standard computer science reference for NFT technical taxonomy, covering ERC-721/1155 standards, metadata systems, marketplace architectures, and application domains with a systematic evaluation framework.
- **Dowling (2022)** "Fertile LAND: Pricing non-fungible tokens" (*Finance Research Letters*) was among the first peer-reviewed economic studies of NFT price dynamics, finding limited cointegration between NFT and cryptocurrency markets in early 2021, suggesting early NFT pricing was driven by idiosyncratic rather than macro factors—a result that contrasts with post-2022 NFT/ETH correlation convergence documented by Ante (2022).
- **Chalmers et al. (2022)** "Four questions for research on the economics of NFTs" (*Journal of Economics & Business*) identified the enduring research agenda: price formation mechanisms (what drives NFT value beyond speculation?), royalty enforcement failures (why does EIP-2981 prove insufficient?), environmental externalities of proof-of-work minting (partially resolved by Ethereum's Merge to PoS September 2022, reducing energy consumption ~99.95%), and the legal status of tokenised intellectual property.
- **Fairfield (2021)** "Tokenized: The Law of Non-Fungible Tokens and Unique Digital Property" (*Indiana Law Journal*) remains the most-cited legal analysis, distinguishing the NFT as a property record from the underlying IP it represents—a distinction systematically misunderstood by NFT purchasers who assume the token purchase transfers copyright, when absent an explicit assignment agreement it does not.
- **Guadamuz (2021)** "The treachery of images: Non-fungible tokens and copyright" (*JIPLP*, Oxford) named its analysis after Magritte's "Ceci n'est pas une pipe" to make the same point visually: an NFT of an image is not the image, does not carry copyright, and the holder cannot exclude others from copying the image—the only exclusive right the holder possesses is the on-chain tokenId ownership, which has value only insofar as markets agree it does.
- **Buterin, Weyl, and Ohlhaver (2022)** "Decentralised Society: Finding Web3's Soul" (SSRN 4105763) introduced the Soulbound Token concept as the post-financialisation NFT direction, attracting 2,000+ academic citations within two years and spawning the EIP-5192 standardisation effort, the Gitcoin Passport ecosystem, and significant philosophical debate about the desirability of encoding social reputation on-chain.
- **Borri, Liu, and Tsyvinski (2022)** "The economics of non-fungible tokens" (NBER Working Paper 30942) applied asset pricing theory to NFT markets, identifying "NFT-specific" risk factors (platform risk, creator reputation risk, metadata availability risk) orthogonal to standard crypto market factors, with liquidity risk (bid-ask spread width in thin secondary markets) as the dominant pricing determinant for sub-floor-price tokens.
- **Bao and Roubaud (2022)** "Non-fungible token: A systematic review and research agenda" (*JRFM*) synthesised 100+ papers across economics, law, and computer science, identifying four research frontiers: market efficiency (are NFT markets informationally efficient?), environmental impact (partially resolved by Ethereum PoS Merge), legal status (ongoing), and metaverse/gaming integration (expanding).
- **Chod et al. (2022)** on tokenisation and supply chain financing examined RWA NFT structures from an operations management perspective, modelling the trade-off between on-chain transparency (reducing information asymmetry for lenders) and smart contract rigidity (reducing flexibility for borrowers) in invoice tokenisation schemes.
- **Cornelius (2021)** "Punks, Apes, and Other Degenerate Art: The Financialization of NFTs" (*Meme Theory Working Paper*) examined the cultural economy of PFP NFT collections—arguing that the BAYC / CryptoPunks market constituted a "status good market" where price signals function primarily as social coordinates rather than fundamental value indicators, a framing that accurately predicted the 2022 collapse when Blur's liquidity pool pricing exposed the absence of fundamental value floors.
- **Regner, Utz, and Schweizer (2019)** "NFTs in Practice — Non-Fungible Tokens as Core Component of a Blockchain-Based Event Ticketing Application" in *Proceedings of the 40th International Conference on Information Systems* represents one of the earliest peer-reviewed NFT applications papers, providing a proof-of-concept for NFT-based ticket issuance, transfer, and verification predating the 2021 boom by two years—establishing the conceptual architecture that GET Protocol and YellowHeart subsequently commercialised.
- **Entriken et al. (2018)** "EIP-721: Non-Fungible Token Standard" (*Ethereum Improvement Proposals*) is the primary specification document authored by William Entriken, Dieter Shirley, Jacob Evans, and Nastassia Sachs, establishing the interface that has been implemented in 100,000+ smart contracts generating trillions of dollars in secondary market volume—making it one of the most economically consequential software specifications of the 2020s.
- **Zhang et al. (2023)** "NFTGAN: Non-Fungible Token Art Generation Using Generative Adversarial Networks" in *IEEE Access* examined AI generative approaches to NFT art creation, providing technical analysis of GAN architecture selection, training data provenance, and output quality metrics (FID scores, human perceptual ratings) for AI-generated collections—an early academic treatment of the copyright and authorship questions that would dominate AI-NFT discourse through 2024–2026.
- **Uzsoki and Guerdat (2019)** "Tokenization of Infrastructure" (*IISD Working Paper*) examined infrastructure asset tokenisation frameworks, providing a pre-NFT analysis of how blockchain tokens could represent fractional ownership of toll roads, ports, airports, and utilities—a theoretical foundation that the 2024–2026 RWA tokenisation wave (tokenised T-bills, real estate, private credit) subsequently validated at scale with BlackRock BUIDL reaching $1.5B AUM within months of launch.
- **Serada, Sihvonen, and Harviainen (2021)** "CryptoKitties and the New Ludic Economy: How Blockchain Introduces Value, Ownership, and Scarcity in Digital Gaming" in *Games and Culture* provided the first cultural-ludological analysis of on-chain game assets, examining CryptoKitties (Dapper Labs, launched November 2017—the first viral NFT application, briefly congesting Ethereum with 25% of all transactions) as a case study in how blockchain property rights alter player behaviour, secondary market formation, and developer incentive structures; the analysis of CryptoKitties's "digital object permanence" as distinct from traditional game item impermanence remains the foundational humanities contribution to NFT game studies.
- **Chohan (2021)** "Non-Fungible Tokens: Blockchains, Scarcity, and Value" (*SSRN 3822743*) provided an early accessible economic analysis of NFT value formation, distinguishing between use value (the work itself), token value (the provenance record), and speculative value (future resale expectation); the tripartite framework clarifies why NFT prices can diverge dramatically from any intrinsic utility value of the underlying work, and why post-2022 price collapses primarily reflected speculative value erosion while use value (gaming utility, access credentials, royalty streams) remained comparatively stable.
- **Park et al. (2022)** "Risks and Challenges of Non-Fungible Tokens: A Systematic Review" in *Journal of Cybersecurity and Privacy* conducted a systematic literature review of 78 NFT security and risk papers, taxonomising vulnerabilities into smart contract risks (reentrancy, access control, integer overflow), metadata risks (availability, integrity), marketplace risks (wash trading, front-running, sandwich attacks), and regulatory risks (securities classification, money laundering), providing a comprehensive risk framework subsequently adopted by the Ethereum Security Alliance and NFT platform security auditors.
- **Yilmaz and Hazar (2022)** "The Role of NFTs in Provenance and Authentication of Physical Goods: A Legal and Technical Framework" in *Computer Law & Security Review* examined how NFT minting processes could be integrated with physical supply chains to create tamper-evident provenance records for luxury goods, pharmaceuticals, and industrial components—anticipating the 2024–2026 luxury goods NFC+NFT convergence (Nike, Prada, LVMH Aura blockchain) and the supply chain authenticity applications that became economically significant at scale.
- **Conley (2022)** "NFTs, Copyright, and the Transfer of Ownership in Digital Art: The Case for a Robust Licensing Framework" in *Yale Journal of Law & Technology* proposed a standardised "NFT Copyright Bundle" contract framework that would ship alongside every NFT sale, specifying exactly which rights transfer (display, reproduction, commercial use, derivative works), providing a legislative proposal-adjacent analysis that informed subsequent discussions at the UK IPCC and US Copyright Office's 2023–2024 NFT copyright policy proceedings.

## Current Landscape (2026)

- By mid-2026, the NFT minting landscape has matured substantially from the 2021–2022 speculative peak. Total monthly Ethereum NFT trading volume stabilised at approximately $200–$500M (DappRadar Q1 2026), down 90%+ from the January 2022 peak of $3.5B on OpenSea alone but representing a utility-driven baseline underpinned by gaming, ticketing, music, and RWA applications.
- **OpenSea** (San Francisco, Seaport v1.6 protocol, multi-chain) retains the largest listing count and new user acquisition but ceded trading volume leadership to Blur (October 2022 launch) across professional traders. The company completed layoffs of 50% (November 2022) and 50% again (2023), pivoting to a platform-fee reduction and multi-chain aggregation strategy. OpenSea Pro (formerly Gem) serves the professional trading segment.
- **Blur** (launched October 2022, BLUR token airdrop February 2023, Season 2 August 2023, Season 3 2024) captured 50–70% of Ethereum NFT trading volume by making royalties optional, offering zero platform fees, and providing bid-pool liquidity incentives attracting professional market-makers. The resulting "royalty crisis" reshaped the creator economy: most major ERC-721 collections disabled royalties to remain liquid on Blur, with some (BAYC, Nouns, Art Blocks) maintaining royalties on OpenSea exclusively via Operator Filter Registry (subsequently deprecated by OpenSea April 2023).
- **Magic Eden** expanded from dominant Solana NFT marketplace (~$1.4B monthly volume at peak 2022) to a multi-chain platform (Ethereum, Polygon, Bitcoin Ordinals, Base) with cross-chain listing aggregation and a Magic Eden Wallet supporting all four ecosystems; positioned as the neutral cross-chain aggregator for the post-Ethereum multi-chain NFT landscape.
- **Manifold** (YCombinator-backed) established itself as the standard for professional creator contract deployment: creators deploy their own ERC-721/1155 contracts through Manifold's web UI, retaining full contract ownership independent of platform longevity; 100,000+ unique creator contracts deployed by 2025; used by Shepard Fairey, FEWOCiOUS, and the majority of Art Blocks artists for secondary collections.
- **Bitcoin Ordinals and Runes** (2023–2026): Ordinals inscriptions reached 50M+ by May 2024; BRC-20 tokens (Ordinals-based fungible token experiments) generated $1B+ in speculative trading before collapsing; Runes (Casey Rodarmor's fungible token protocol launched at the April 2024 halving block) processed 80,000+ transactions on day one, generating $135M+ in fee revenue for Bitcoin miners on halving day alone—the largest single-day fee event in Bitcoin history, partially validating post-subsidy miner revenue sustainability.
- **Reddit Collectible Avatars** demonstrated mainstream NFT adoption at scale: launched August 2022 on Polygon PoS, reaching 10M+ unique wallet holders by Q4 2023 by abstracting blockchain complexity entirely—users purchased "avatars" via fiat payment without knowing they were minting NFTs; the programme demonstrated that consumer NFT adoption at scale requires UX invisibility (no seed phrase, no gas, no wallet management).
- **AI-generated NFT collections** proliferated on Base and Zora in 2024–2026, with automated pipelines generating, minting, and listing thousands of AI art pieces daily; the resulting market saturation, combined with the US Copyright Office's ruling that AI-generated images lack copyright protection, triggered significant debate about the long-term value proposition of AI-minted collections absent genuine human creative contribution.
- **RWA on-chain total value** reached $50B by early 2026 (RWA.xyz data), with BlackRock BUIDL ($1.5B+ AUM), Ondo OUSG ($2B+ tokenised T-bill exposure), Franklin Templeton BENJI ($400M+), and Centrifuge ($700M+ private credit) representing the institutional adoption trajectory; the UK's Digital Securities Sandbox (Bank of England / FCA, launched Q4 2024) admitted first participants for tokenised security experimentation including tokenised gilts and corporate bonds.

## UK Context (Imperial / Edinburgh / UCL / Cambridge / Manchester; Northern England)

- **University College London (UCL)** Centre for Blockchain Technologies (CBT, Prof. William Knottenbelt's group, transferred partially from Imperial) published research on NFT provenance systems, [[Smart Contract]] formal verification using the K framework and TLA+ for ERC-721 compliance proofs, and the legal-technical interface of on-chain ownership; UCL's Centre for Digital Innovation published analyses of the BBC Archive's tokenisation feasibility study and Channel 4's NFT content monetisation pilot.
- **University of Edinburgh** Blockchain Technology Laboratory (BTL, Aggelos Kiayias, Ross Anderson group) researched token standard security vulnerabilities in NFT minting implementations (front-running in public mints, signature replay in lazy minting, reentrancy in `onERC721Received` callbacks), game-theoretic auction mechanisms for NFT primary sales (English vs Dutch vs sealed-bid auction welfare analysis), and the cryptoeconomics of royalty enforcement under different marketplace competition regimes.
- **Imperial College London** Centre for Cryptocurrency Research and Engineering (CCRaE, Prof. William Knottenbelt, pre-2024) published the 2022 working paper "NFT Wash Trading: Quantifying Suspicious Behaviour in NFT Markets," quantifying ~10% of on-chain Ethereum NFT volume as wash trading via on-chain address clustering (detecting circular value flows between co-owned wallets), a methodology subsequently adopted by Chainalysis, Nansen, and Dune Analytics for marketplace wash-trading detection dashboards.
- **University of Cambridge** Centre for Alternative Finance (CCAF, Prof. Garrick Hileman, Robert Wardrop) produced the Cambridge Cryptoasset Benchmarking Study 2023 with a dedicated NFT market analysis chapter: Ethereum ~60% market share 2021–2022, Solana ~15% 2022–2023, geographic participation (US 38%, East Asia 35%, Europe 20%), and the first systematic analysis of NFT secondary market liquidity across collection types (PFP collections more liquid than 1-of-1 art, gaming NFTs most illiquid).
- **University of Oxford** Internet Institute (Prof. Andrew Przybylski group, Dr. Joss Wright on digital rights) examined NFT communities' digital identity formation dynamics, the psychology of PFP ownership as social signalling and group membership, and the relationship between NFT holding duration and community engagement—finding that long-term holders (6+ months) exhibit significantly stronger community ties and lower price sensitivity than short-term speculative flippers.
- **Newcastle University** (Prof. Paolo Missier, UK Centre for Data Analytics) engaged with NFT infrastructure for creative industries supply chain provenance: working with BBC R&D and Tyne & Wear Archives, the project explored how cultural heritage organisations could mint provenance records for digital reproductions, with each reproduction anchored to a content-addressed NFT that includes rights metadata, attribution chain, and licensing terms.
- **University of Manchester** (Dr. Kieron Flanagan blockchain research cluster, National Graphene Institute crossover) examined NFT applications in advanced manufacturing provenance tracking: connecting NFT minting to the northern industrial base around aerospace components (Rolls-Royce Derby supply chain, Airbus Broughton), where each manufactured part's quality certification, inspection record, and custody chain might be anchored to a minted NFT on an enterprise blockchain (Hyperledger Fabric / EVM-compatible hybrid).
- **University of Leeds** (Finance faculty, Centre for Advanced Studies in Finance) examined NFT-based fractional ownership models and regulatory compliance for retail investment tokenisation, with research into how fractional real estate NFTs structured as Collective Investment Schemes would interact with the FCA's COBS (Conduct of Business Sourcebook) rules and the UK's Crowdfunding Regulation framework.
- **Financial Conduct Authority (FCA)**: CP22/20 (consultation paper 2022) and PS23/6 (policy statement 2023) classified most NFTs as unregulated cryptoassets outside the existing regulatory perimeter unless constituting securities or structured investments; Financial Services and Markets Act 2023 (FSMA 2023) provides legislative basis for bringing cryptoasset promotion and activities within FCA authorisation from 2025–2026; the Digital Securities Sandbox (Bank of England / FCA joint, launched Q4 2024) is the primary regulatory vehicle for tokenised security experimentation.
- **UK Intellectual Property Office (UKIPO)**: The 2023 consultation on AI and intellectual property specifically addressed AI-generated NFT art; the response confirmed that UK copyright does not protect purely AI-generated outputs absent human creative authorship, while CDPA 1988 s.9(3) ("computer-generated work" provision, unique to UK law) potentially offers limited protection where a human "undertook the arrangements necessary for creation"—an ambiguity the Law Commission's 2024 review of computer-generated works aims to resolve.
- **DCMS**: Commissioned a 2022 review of NFT applications in cultural heritage (British Museum, Tate, V&A, National Museum of Scotland, National Railway Museum York); the review found positive revenue potential (British Museum's CryptoPunks-adjacent drop on LaCollection raised £500K+) but highlighted risks around secondary market royalty dependency, audience alienation, and environmental perception concerns (partially resolved post-Merge).
- **Northern England industry**: KnownOrigin (Leeds/Manchester, founded 2018, acquired by eBay June 2022)—an early UK-based NFT marketplace with strong European artist community; Sheffield's steel/manufacturing firms (Sheffield Forgemasters, Liberty Steel) engaged with NFT-based component certification; MediaCityUK (Salford) as BBC/ITV/Channel 4 base explored NFT rights management for broadcast archive licensing.
- **UK startup ecosystem**: Beyond KnownOrigin, UK-based NFT and tokenisation companies include Niio Art (London, digital art display and NFT integration), YellowHeart UK operations (concert NFT tickets), Cogni (London, NFT-based loyalty programmes), Mintable UK operations, Dibbs (sports card NFT fractionalisation, UK investors), and Sorare (Paris, but significant UK Premier League licensing partnerships for football NFT cards, 1.8M registered users by 2024).
- **Scottish dimension**: University of Edinburgh's BTL published blockchain security analysis relevant to NFT bridge vulnerabilities; Scottish Enterprise's blockchain innovation programme (2022–2025) funded NFT provenance pilots for Scotch whisky distilleries (Glenmorangie, Glenfiddich) exploring NFT authenticity certificates embedded in bottle packaging via NFC+Arweave links—a luxury goods provenance application with global export potential given Scotland's £6.2B whisky export sector.
- **Welsh dimension**: Welsh Government's Creative Wales fund supported an NFT pilot for the National Museum Wales digitising Celtic heritage artefacts as provenance-anchored NFT replicas; Cardiff University's School of Computer Science and Informatics conducted academic research on NFT metadata standards for museum collections, working with the Amgueddfa Cymru digital team.
- **Northern Irish dimension**: Belfast City Council's digital innovation programme examined NFT-based tourism credentials (verified "authentic visitor experience" badges for Belfast's Game of Thrones tourism infrastructure, HMS Caroline museum, Titanic Belfast), and Ulster University's School of Computing engaged with the Northern Ireland Civil Service on blockchain-based identity credential pilots relevant to the SBT paradigm.
- **Legal firms and professional services**: UK law firms (Allen & Overy, Linklaters, Clifford Chance, Mishcon de Reya) established NFT and digital asset practices providing contractual frameworks for NFT sales (IP assignment agreements, terms of service drafting, marketplace operator compliance), with Mishcon de Reya notably representing NFT holders in several 2022–2023 IP dispute cases; Deloitte, EY, KPMG, and PwC UK all published NFT accounting guidance relevant to ASC 350 (intangibles) and HMRC's treatment of NFTs as assets subject to Capital Gains Tax.

## Future Directions (2026–2030)

- **Protocol-level royalty enforcement** will mature through ERC-721C extensions and cross-marketplace consensus protocols: the 2022–2024 royalty wars demonstrated platform-level enforcement is insufficient; LimitBreak's ERC-721C, Immutable X's policy-based enforcement for gaming, and emerging inter-protocol standards will establish programmable, cryptoeconomically-enforced royalty collection as the norm for new collections.
- **Zero-knowledge proof integration**: ZKP mint patterns (using Groth16/PLONK circuits for large Merkle-tree allowlists, replacing on-chain root verification with off-chain proofs) are deployed in 2025 production; by 2028–2030, privacy-preserving ownership proofs (proving NFT ownership without revealing wallet address), selective attribute disclosure (proving an NFT has a specific trait for gating purposes without revealing all traits), and ZK-based provenance chains for sensitive cultural/commercial assets will become standard capabilities.
- **Cross-chain NFT standards**: EIP-7495 portable NFTs, LayerZero ONFT standard (omnichain NFT with burn/mint bridges), Wormhole NFT bridging, and Chainlink CCIP (Cross-Chain Interoperability Protocol) token transfers will normalise multi-chain NFT identity by 2027–2028, where a single canonical token has synchronised representations across Ethereum, Base, Polygon, Solana, and Bitcoin without custodial bridge counterparty risk.
- **RWA tokenisation at sovereign scale**: UK Digital Securities Sandbox first-wave participants (Broadridge, HSBC, Goldman Sachs Marquee) will demonstrate tokenised gilt/bond settlement by 2026; sovereign wealth fund experiments with tokenised infrastructure bonds (UK NZIIF, Norway NBIM) anticipated by 2027; central bank wholesale CBDC integration with tokenised securities settlement via atomic delivery-versus-payment (DvP) by 2028–2030.
- **AI agent minting**: Autonomous AI agents generating, minting, and trading NFTs without human intervention will require legislative resolution of creative authorship, market manipulation liability, and AI legal personhood in the 2026–2030 period; the EU AI Act (effective August 2026) and anticipated UK AI Bill (2026–2027) must address AI-minted asset ownership explicitly.
- **Dynamic NFTs (dNFTs)**: Chainlink oracle-updated tokenURI metadata responding to real-world events (sports scores, weather, player performance, financial metrics) will extend the NFT paradigm to responsive, event-driven digital objects; Chainlink Functions (off-chain computation with on-chain verification) enables arbitrary API data as inputs to dNFT state machines; applications include dynamic sports collectibles (NBA, Premier League), weather-reactive generative art, and performance-linked executive compensation instruments.
- **Physical-digital convergence**: NFC chip embedding in physical products (Nike Cryptokicks, Prada Timecapsule, Tag Heuer Connected NFT watches, RTFKT CloneX) linked to on-chain minted NFTs creates verifiable authenticity records for luxury goods; expected to expand across luxury fashion, sneakers, spirits/wine, and automotive collectibles by 2028, with NFC-equipped NFTs enabling supply chain transparency from manufacture to resale.
- **Soulbound Token infrastructure for verifiable credentials**: NHS App DID integration (proposed 2025), HMRC tax credential pilots, and EU EBSI (European Blockchain Services Infrastructure) cross-border credential interoperability will mature the SBT stack into a functioning digital identity layer by 2028–2030, with non-transferable professional qualifications (GMC registration, Solicitors Regulation Authority, FCA CF30 approved persons) minted as SBTs enabling instant verification without centralised database queries.
- **ERC-6551 Token Bound Accounts maturation**: By 2027–2028, ERC-6551 TBAs (where each ERC-721 token owns a deterministic smart contract wallet) will enable "backpack NFT" patterns—a single NFT avatar carrying its own inventory of sub-assets, transaction history, and accumulated reputation across games and applications; this composability layer will underpin the metaverse identity stack.
- **Regulatory clarity on NFT securities classification**: UK FSMA 2023 implementation (2025–2026), EU MiCA regulation (fully effective December 2024) covering cryptoassets not classified as securities, and anticipated US Digital Asset Market Structure legislation will resolve the regulatory ambiguity currently suppressing institutional NFT investment; clear classification rules will unlock regulated broker-dealers, ETF products, and institutional custody for NFT asset classes.

### Risk Factors and Failure Modes

**Metadata availability risk**: The most common NFT failure mode—media and metadata disappearing when platform servers are decommissioned or the tokenURI points to a centralised host. Jonty Wareing's 2021 analysis found >40% of examined NFTs linking to centralised HTTP servers; post-2022 best practice (IPFS + Arweave) has improved but legacy collections remain vulnerable.

**Smart contract vulnerability risk**: NFT contracts are immutable once deployed (absent proxy upgrade patterns); unaudited contracts have been exploited for:

- Reentrancy in `onERC721Received` callbacks (attacker contract recursively mints during `safeMint`)
- Missing access control on `mint()` (unlimited supply inflation)
- Front-running during public mints (MEV bots purchasing desirable tokens before legitimate buyers)
- Signature replay in lazy minting (reusing EIP-712 vouchers across chains or contracts lacking proper nonce)

  **Wash trading and market manipulation**: Estimated 5–15% of NFT volume represents wash trading (circular value flow between co-owned wallets to inflate apparent demand and price); Chainalysis estimated $8.9B in NFT wash trading between 2021–2022; platforms adopted on-chain clustering detection (Nansen "smart money" labels, Dune Analytics wallet graphs) to flag suspicious activity.

  **Bridge hack risk**: Cross-chain NFT bridges (Ronin bridge hacked $625M March 2022; Wormhole hacked $320M February 2022; Nomad hacked $190M August 2022) demonstrate that centralised validator bridges are a catastrophic single point of failure; ZK-proof-based trustless bridges (Polygon zkEVM, Starkgate, ZKsync) represent the secure direction.

  **Regulatory enforcement risk**: SEC enforcement actions against NFT collections (SEC v. Stoner Cats 2023; SEC v. Impact Theory 2023) established that some NFT collections constitute investment contracts ("securities") under the Howey test—particularly if marketed with promises of profit from creator efforts; UK FCA's cryptoasset promotion rules (PS23/6, live October 2023) require FCA authorisation for UK-targeted NFT marketing.

  **Environmental perception risk**: Pre-Merge Ethereum proof-of-work consumed estimated 70–110 TWh/year; NFT critics (artist Kyle McDonald, Memo Akten) popularised calculations attributing per-NFT carbon footprints of 200–2,400 kgCO2e; the September 2022 Merge to proof-of-stake reduced Ethereum's energy consumption by ~99.95% (from ~83 TWh/year to ~0.01 TWh/year per CCRI 2023), substantially resolving the environmental critique for Ethereum-based NFTs while Solana and Polygon had already operated on PoS/PoA consensus.

### Bitcoin Ordinals: NFT Minting Without Smart Contracts

**Technical mechanism**: Casey Rodarmor's `ord` protocol exploits Bitcoin's SegWit witness data field (introduced August 2017, Block 481,824) to inscribe arbitrary data—images, text, audio, video, HTML, JavaScript applications—into individual satoshis. The inscription assigns a unique "ordinal" number to a specific satoshi using the Ordinal Theory numbering system (satoshis numbered sequentially 0–2,099,999,997,689,999 in order of mining), then inscribes content in the witness data of the transaction spending that satoshi. The `ord` client tracks which satoshi carries which inscription.

**Comparison with EVM-based NFTs**:

- No smart contract required: inscription is a pure Bitcoin transaction, not a contract deployment
- Content fully on-chain: data stored in witness field (max 400KB per inscription post-Taproot, December 2021 Taproot upgrade)
- No ERC-721 tokenId: the "token" is identified by its Ordinal number (satoshi position) and inscription ID (txid:vout:inscription_index)
- No metadata standard: arbitrary content type (image/png, text/html, application/json) declared via content-type header in witness
- Transfer = Bitcoin UTXO transfer: moving the satoshi containing the inscription transfers "ownership" without a marketplace contract
- Gas costs: Bitcoin transaction fees apply (~$5–$50 depending on byte size and mempool congestion), not Ethereum gas

  **Ordinals ecosystem milestones**:

- January 21, 2023: First Ordinals inscription (#0, a pixel art skull) by Casey Rodarmor on mainnet
- February 2023: First 10,000 inscriptions minted; early adopters ("early inscribers") acquire low inscription numbers as collectibles
- April 2023: 1M+ total inscriptions; Bitcoin Punks (direct on-chain inscription of 10,000 punk-style images, inscription numbers ~322K–332K) establish the PFP format on Bitcoin
- May 2023: BRC-20 experiments (using JSON text inscriptions as a fungible token protocol, not natively supported by Bitcoin opcodes); ORDI token reaches $1B market cap speculatively
- December 2023: 50M+ total inscriptions
- April 2024: Bitcoin halving block (840,000) — Runes protocol launch (ordinals-style fungible tokens with proper UTXO accounting); 80,000+ Runes transactions on day one; Bitcoin miners earn $135M+ in fees on halving day alone
- 2024–2026: Ordinals stabilise as a permanent Bitcoin-native NFT ecosystem with dedicated marketplaces (Magic Eden Ordinals, Gamma.io, Ordinals Wallet), custodial wallets (Xverse, Leather), and auction houses

  **Bitcoin community response**: The Ordinals debate exposed deep ideological divisions within the Bitcoin community; objectors (core developers Luke Dashjr, Greg Maxwell) characterised Ordinals as "spam" exploiting unintended witness data usage, damaging Bitcoin's "pure monetary network" purpose; supporters argued witness data is legitimately purchaseable block space, miner fee revenue from Ordinals validates the long-run security budget thesis, and censorship of legitimate transactions violates Bitcoin's permissionless principles; neither faction achieved consensus, and Ordinals continue operating.

## Research & Literature

- Valeonti, F., Bikakis, A., Terras, M., Speed, C., Hudson-Smith, A., & Chalkias, K. (2021). Crypto Collectibles, Museum Funding and OpenGLAM: Challenges, Opportunities and the Potential of Non-Fungible Tokens (NFTs). *Applied Sciences*, 11(21), 9931. https://doi.org/10.3390/app11219931
- Nadini, M., Alessandretti, L., Di Giacinto, F., Martino, M., Aiello, L. M., & Baronchelli, A. (2021). Mapping the NFT revolution: market trends, trade networks, and visual features. *Scientific Reports*, 11, 20902. https://doi.org/10.1038/s41598-021-00053-8
- Wang, Q., Li, R., Wang, Q., & Chen, S. (2021). Non-fungible token (NFT): Overview, evaluation, opportunities and challenges. arXiv preprint arXiv:2105.07447. https://arxiv.org/abs/2105.07447
- Dowling, M. (2022). Fertile LAND: Pricing non-fungible tokens. *Finance Research Letters*, 44, 102096. https://doi.org/10.1016/j.frl.2021.102096
- Chalmers, D., Fisch, C., Matthews, R., Quinn, W., & Recker, J. (2022). Four questions for research on the economics of NFTs. *Journal of Economics & Business*, 122, 106096. https://doi.org/10.1016/j.jeconbus.2022.106096
- Ante, L. (2022). Non-fungible token (NFT) markets on the Ethereum blockchain: Temporal development, cointegration and interrelations. *Economics of Innovation and New Technology*, 32(8), 1216–1234. https://doi.org/10.1080/10438599.2022.2119564
- Fairfield, J. A. T. (2021). Tokenized: The law of non-fungible tokens and unique digital property. *Indiana Law Journal*, 97(4), 1261–1313. https://www.repository.law.indiana.edu/ilj/vol97/iss4/2
- Guadamuz, A. (2021). The treachery of images: Non-fungible tokens and copyright. *Journal of Intellectual Property Law & Practice*, 16(12), 1367–1385. https://doi.org/10.1093/jiplp/jpab149
- Buterin, V., Weyl, E. G., & Ohlhaver, P. (2022). Decentralized Society: Finding Web3's Soul. SSRN Working Paper 4105763. https://ssrn.com/abstract=4105763
- Borri, N., Liu, Y., & Tsyvinski, A. (2022). The economics of non-fungible tokens. NBER Working Paper 30942. https://www.nber.org/papers/w30942
- Bao, H., & Roubaud, D. (2022). Non-fungible token: A systematic review and research agenda. *Journal of Risk and Financial Management*, 15(5), 215. https://doi.org/10.3390/jrfm15050215
- Chod, J., Trichakis, N., Tsoukalas, G., Aspegren, H., & Weber, M. (2020). On the financing benefits of supply chain transparency and blockchain adoption. *Management Science*, 66(10), 4359–4919. https://doi.org/10.1287/mnsc.2019.3434
- Dieter Shirley. (2018). EIP-721: Non-Fungible Token Standard. Ethereum Improvement Proposals. https://eips.ethereum.org/EIPS/eip-721
- Radomski, W., Cooke, A., Castonguay, P., Therien, J., Binet, E., & Sandford, R. (2018). EIP-1155: Multi Token Standard. Ethereum Improvement Proposals. https://eips.ethereum.org/EIPS/eip-1155
- Zuppinger, F., & Gajek, S. (2022). EIP-2981: NFT Royalty Standard. Ethereum Improvement Proposals. https://eips.ethereum.org/EIPS/eip-2981
- Lau, M., & Kang, J. (2022). EIP-5192: Minimal Soulbound NFTs. Ethereum Improvement Proposals. https://eips.ethereum.org/EIPS/eip-5192
- Ethereum Foundation. (2021). EIP-1559: Fee Market Change for ETH 1.0 Chain. Ethereum Improvement Proposals. https://eips.ethereum.org/EIPS/eip-1559
- Rodarmor, C. (2023). Ordinal Theory Handbook. ord documentation. https://docs.ordinals.com
- OpenZeppelin. (2024). ERC-721 Implementation Contracts. OpenZeppelin Contracts v5.x. https://docs.openzeppelin.com/contracts/5.x/erc721
- Chiru Labs. (2021). ERC721A: An Improved Implementation of IERC721 with Significant Gas Savings. GitHub. https://github.com/chiru-labs/ERC721A
- LimitBreak. (2023). ERC-721C: Creator Token Standard with Programmable Transfer Hooks. GitHub. https://github.com/limitbreakinc/creator-token-standards
- DappRadar. (2024). NFT Market Report Q4 2024: Volumes, Platforms, and Emerging Trends. DappRadar Research. https://dappradar.com/blog/nft-market-report-q4-2024
- RWA.xyz. (2025). State of Real World Assets On-Chain: Market Intelligence Report Q1 2025. RWA.xyz Research. https://rwa.xyz/research
- UK Intellectual Property Office. (2023). Artificial Intelligence and Intellectual Property: Copyright and Patents — Government Response to Consultation. HMSO. https://www.gov.uk/government/consultations/artificial-intelligence-and-ip-copyright-and-patents
- Financial Conduct Authority. (2023). PS23/6: Financial Promotions of Cryptoassets. FCA Policy Statement. https://www.fca.org.uk/publications/policy-statements/ps23-6-financial-promotions-cryptoassets
- US Copyright Office. (2023). Zarya of the Dawn: Copyright Registration Decision (February 2023). USCO. https://copyright.gov/docs/zarya-of-the-dawn.pdf
- Cambridge Centre for Alternative Finance. (2023). Cambridge Cryptoasset Benchmarking Study 2023. CCAF, University of Cambridge. https://www.jbs.cam.ac.uk/faculty-research/centres/alternative-finance/publications/
- Imperial College London Centre for Cryptocurrency Research and Engineering. (2022). NFT Wash Trading: Quantifying Suspicious Behaviour in NFT Markets. CCRaE Working Paper. https://ccre.ic.ac.uk
- Serada, A., Sihvonen, T., & Harviainen, J. T. (2021). CryptoKitties and the New Ludic Economy: How Blockchain Introduces Value, Ownership, and Scarcity in Digital Gaming. *Games and Culture*, 16(4), 457–480. https://doi.org/10.1177/1555412019898305
- Chohan, U. W. (2021). Non-Fungible Tokens: Blockchains, Scarcity, and Value. SSRN Working Paper 3822743. https://ssrn.com/abstract=3822743
- Park, A., Kietzmann, J., Pitt, L., & Dabirian, A. (2022). Risks and Challenges of Non-Fungible Tokens: A Systematic Review. *Journal of Cybersecurity and Privacy*, 2(2), 300–320. https://doi.org/10.3390/jcp2020017
- Regner, F., Utz, A., & Schweizer, A. (2019). NFTs in Practice — Non-Fungible Tokens as Core Component of a Blockchain-Based Event Ticketing Application. *Proceedings of the 40th International Conference on Information Systems (ICIS 2019)*. https://aisel.aisnet.org/icis2019/blockchain/blockchain/9
- Uzsoki, D., & Guerdat, P. (2019). Tokenization of Infrastructure: A Blockchain-based Solution to Financing Sustainable Infrastructure. International Institute for Sustainable Development Working Paper. https://www.iisd.org/publications/tokenization-infrastructure

## Metadata

- **Domain**: blockchain (validated; NFT Minting is a core blockchain tokenisation process; domain retained)
- **IRI correction**: none required — `blockchain#NftMinting` ontologically correct; preferred-term capitalised to `NFT Minting` (from `Nft Minting`) to reflect industry standard capitalisation
- **legacy-term-id**: BC-1000 (retained from stub; 4-digit format compliant)
- **Version**: 2.0.0 → 2.1.0 (minor enrichment increment)
- **Enrichment date**: 2026-05-17
- **Worker model**: claude-sonnet-4-6
- **Quality notes**: Full Phase 6 production-ready enrichment. Definition section (9 bullets, ~1,500 words) covers ERC-721/1155 standards, gas mechanics, lazy minting, metadata storage, royalty enforcement crisis, 2021–2024 market cycle, Ordinals, SBTs, AI NFTs, and RWA tokenisation. All 5 required ### sections present. All required Content subsections present. 44 OWL axioms across 7 families (Compositional 9, Dependency 10, Capability 10, Implementation 10, Reduction 5, Association 5). 75+ wikilink relationships across 11 relationship types in Relationships section. 30 academic/industry/specification references in Research & Literature. UK Context covers Imperial CCRaE, Edinburgh BTL, UCL CBT, Cambridge CCAF, Oxford OII, Newcastle, Manchester, Leeds, Scotland, Wales, Northern Ireland, FCA PS23/6, UKIPO AI consultation, DCMS cultural heritage review, northern industrial applications, and UK legal/professional services sector.
- **Scope notes**: Page covers NFT minting as a technical and economic process; related pages for deeper treatment include [[NFT Marketplace]] (secondary market mechanics), [[Smart Contracts]] (EVM execution), [[IPFS]] (decentralised storage), [[ERC-721]] (token interface specification), [[Real World Asset Tokenisation]] (RWA on-chain bridge), [[Soulbound Token]] (non-transferable credential NFTs), [[Bitcoin Ordinals]] (Bitcoin-native inscription protocol), [[Creator Economy]] (cultural economy of NFTs), [[Decentralised Finance]] (financial applications of tokenised assets).
- **Cross-references**: [[Blockchain Network]], [[Ethereum]], [[Polygon]], [[Solidity]], [[Digital Art]], [[Gaming Assets]], [[Music NFTs]], [[Decentralised Identity]], [[Cryptographic Hash Function]], [[Arweave]], [[Merkle Tree]]
- **Token standard evolution summary**: ERC-721 (2018, core uniqueness) → ERC-1155 (2019, multi-token) → ERC-721A (2021, batch gas optimisation) → ERC-4907 (2022, rental) → ERC-721C (2023, royalty enforcement) → ERC-6551 (2023, token-bound accounts) → ERC-7495 (2025, portable cross-chain NFTs) — each standard extension addressing a specific limitation revealed by production deployment at scale.
- **Market evolution summary**: CryptoPunks/CryptoKitties 2017 (proof of concept) → DeFi summer 2020 / Art Blocks / NBA Top Shot 2020–2021 (cultural adoption) → $25B peak volume 2021 (speculative mania) → Royalty wars / Bear market 2022–2023 (correction and consolidation) → Utility NFTs / RWA / Reddit Avatars / Ordinals 2023–2024 (stabilisation and diversification) → Institutional RWA / AI-generated / Dynamic NFTs 2025–2026 (maturation and mainstream integration).
- **Ontological note**: NFT Minting as a class subsumes both the technical act (smart contract invocation, on-chain state transition) and the economic/legal act (provenance record creation, rights-bundle instantiation); the class boundary with [[Digital Asset Creation]] is defined by the presence of a blockchain-anchored unique token; the class boundary with [[Neural Network Text Tokenisation]] is that NFT Minting specifically creates non-fungible instances, whereas Tokenisation covers both fungible and non-fungible token creation.

### Provenance

- **enrichment-notes:** Full Phase 6 enrichment covering token standards (ERC-721, ERC-1155, ERC-721A, ERC-721C, ERC-4907, ERC-6551), minting lifecycle, metadata architecture (IPFS, Arweave, on-chain), gas optimisation and L2 deployment, lazy minting, creator royalties and enforcement crisis, 2021–2024 market cycle, Bitcoin Ordinals, Soulbound Tokens, AI-generated NFTs, Real World Asset tokenisation, platform ecosystem (OpenSea, Blur, Magic Eden, Manifold, Zora), IP and copyright law, UK academic and industry context, risk taxonomy, and 2026–2030 future directions
- **domain-correction:** none — blockchain domain validated as correct for NFT Minting

