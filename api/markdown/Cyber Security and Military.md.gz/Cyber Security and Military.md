Cyber Security and Military denotes the doctrinal, organisational, technical and operational fusion of cyberspace as a recognised warfighting domain alongside land, sea, air and space — codified by NATO at the 2016 Warsaw Summit declaration that cyberspace is "a domain of operations in which NATO...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:hasPart security:OffensiveCyberOperations))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:hasPart security:DefensiveCyberOperations))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:hasPart security:CyberMissionForce))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:hasPart security:NationalCyberForce))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:hasPart security:ComputerNetworkExploitation))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:hasPart security:CyberIntelligence))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:hasPart security:InformationOperations))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:hasPart security:ElectromagneticSpectrumOperations))

    ## Dependency Relationships
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:requires security:CyberDoctrine))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:requires security:SovereignAuthority))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:requires security:SignalsIntelligence))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:requires security:VulnerabilityResearch))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:requires security:AttributionCapability))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:requires security:TrainedCyberOperators))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:dependsOn security:Cryptography))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:dependsOn security:ThreatIntelligence))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:dependsOn security:ZeroDayExploits))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:dependsOn security:CriticalInfrastructure))

    ## Capability Relationships
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:enables security:CyberDeterrence))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:enables security:CriticalInfrastructureDisruption))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:enables security:AdversaryIntelligenceCollection))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:enables security:StrategicCoercion))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:enables security:BattleDamageAssessment))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:enables security:JointAllDomainOperations))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:enables security:HybridWarfare))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:supports security:NationalDefence))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:supports security:AlliedCoalitionOperations))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:supports security:FiveEyesIntelligence))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:supports security:NATOArticle5))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:supports security:CounterTerrorism))

    ## Implementation Relationships
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:implements security:TallinnManualRules))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:implements security:LawOfArmedConflict))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:implements security:JointTargetingCycle))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:implements security:F3EADTargeting))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:implements security:PersistentEngagement))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:implements security:DefendForward))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:uses security:ZeroDayExploits))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:uses security:Malware))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:uses security:CommandAndControlInfrastructure))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:uses security:LivingOffTheLandTechniques))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:uses security:SupplyChainCompromise))

    ## Reduction Relationships
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:reduces security:KineticEscalationRisk))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:reduces security:AdversaryC2Resilience))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:reduces security:StrategicSurprise))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:reduces security:InformationAsymmetry))

    ## Association Relationships
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:relatedTo security:ElectronicWarfare))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:relatedTo security:InformationWarfare))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:relatedTo security:SpaceOperations))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:relatedTo security:DroneWarfare))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:contrastsWith security:CivilianCybersecurity))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:contrastsWith security:LawEnforcementCyber))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:contrastsWith security:Cybercrime))
    SubClassOf(security:CyberSecurityAndMilitary
      ObjectSomeValuesFrom(security:contrastsWith security:Hacktivism))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(security:hasIdentifier security:CyberSecurityAndMilitary "SEC-1107"^^xsd:string)
    DataPropertyAssertion(security:authorityScore security:CyberSecurityAndMilitary "0.87"^^xsd:decimal)
    DataPropertyAssertion(security:nato5thDomainYear security:CyberSecurityAndMilitary "2016"^^xsd:integer)
    DataPropertyAssertion(security:cyberMissionForceTeams security:CyberSecurityAndMilitary "133"^^xsd:integer)
    DataPropertyAssertion(security:cyberMissionForcePersonnel security:CyberSecurityAndMilitary "6200"^^xsd:integer)
    DataPropertyAssertion(security:tallinnManualRules security:CyberSecurityAndMilitary "154"^^xsd:integer)
    DataPropertyAssertion(security:notPetyaDamageUSD security:CyberSecurityAndMilitary "10000000000"^^xsd:integer)
    DataPropertyAssertion(security:globalDefenceCyberMarketUSD2025 security:CyberSecurityAndMilitary "230000000000"^^xsd:integer)
    DataPropertyAssertion(security:globalDefenceCyberMarketUSD2030 security:CyberSecurityAndMilitary "480000000000"^^xsd:integer)

    ## Property Constraints
    SubClassOf(security:CyberSecurityAndMilitary
      DataMinCardinality(1 security:hasDoctrine xsd:string))
    SubClassOf(security:CyberSecurityAndMilitary
      DataMinCardinality(1 security:hasOperationalCommand xsd:string))
    SubClassOf(security:CyberSecurityAndMilitary
      DataAllValuesFrom(security:isStateActivity xsd:boolean))
    SubClassOf(security:CyberSecurityAndMilitary
      DataSomeValuesFrom(security:foundingYear xsd:integer))

    ## Annotations
    AnnotationAssertion(rdfs:label security:CyberSecurityAndMilitary "Cyber Security and Military"@en)
    AnnotationAssertion(rdfs:comment security:CyberSecurityAndMilitary "The doctrinal, organisational and operational fusion of cyberspace as a recognised warfighting domain (NATO 2016 Warsaw declaration, reaffirmed 2022 Strategic Concept) encompassing state offensive and defensive cyber operations, computer network exploitation, information operations and electromagnetic spectrum operations conducted by uniformed commands (USCYBERCOM 133-team Cyber Mission Force, UK National Cyber Force at Samlesbury, Russia GRU 26165/74455, PLA Information Support Force April 2024 reorg, Israeli Unit 8200, Iranian IRGC Cyber-Electronic Command, DPRK Lazarus), governed by the NATO CCDCOE Tallinn Manual 2.0 (154 rules, 2017) and Tallinn Manual 3.0 (2021-2026), UN GGE norms, US DoDD 3600.01 Information Operations, UK Defence Cyber Strategy 2022, distinguished from civilian cybersecurity by its kinetic-coercive purpose under Law of Armed Conflict constraints, exemplified by Stuxnet (Olympic Games 2007-2010), NotPetya ($10B+ damage 2017), WannaCry, SolarWinds, Colonial Pipeline, Viasat KA-SAT (24 Feb 2022), Volt Typhoon and Salt Typhoon, fused with electronic warfare, unmanned systems (Ukraine FPV, Russia Shahed-136/Lancet-3), counter-drone (UK DragonFire 50kW laser) and space cyber, supported in the UK by NCSC Cheltenham, NCF Samlesbury, MOD Defence Cyber Command, the Cyber Resilience Centre Network and academic centres at Royal Holloway ISG, Imperial, UCL, Edinburgh, Bristol, Oxford, Surrey and Lancaster, comprising a $230B+ 2025 / $480B 2030 global defence-cyber market shaping deterrence, escalation and the laws of armed conflict."@en)
    AnnotationAssertion(dcterms:identifier security:CyberSecurityAndMilitary "SEC-1107"^^xsd:string)
    AnnotationAssertion(dcterms:subject security:CyberSecurityAndMilitary "Military Cyber Operations, Defence Cybersecurity, NATO Doctrine, Tallinn Manual, USCYBERCOM, National Cyber Force"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(security:requires)
  AsymmetricObjectProperty(security:enables)
  AsymmetricObjectProperty(security:implements)
  AsymmetricObjectProperty(security:contrastsWith)
  TransitiveObjectProperty(security:dependsOn)
  FunctionalDataProperty(security:nato5thDomainYear)
  FunctionalDataProperty(security:hasIdentifier)

## About Cyber Security and Military

- **Cyber Security and Military** designates the intersection where cyberspace operations become an instrument of state coercion, deterrence and warfighting rather than a corporate risk-management activity. Although the underlying technical primitives — exploits, implants, command-and-control channels, intrusion-detection systems, cryptography — are shared with civilian information security, the purpose, authorities, oversight, escalation logic and legal regime differ fundamentally. A corporate Security Operations Centre (SOC) defends shareholder value against criminal monetisation; a military cyber command degrades adversary capability to achieve political objectives within the Law of Armed Conflict (LOAC).
- The conceptual shift began in the mid-2000s. The 2007 Estonian cyberattacks against banking, parliament and media — attributed widely to Russian state-coordinated actors during the Bronze Soldier dispute — prompted NATO to designate cyber as a strategic concern and led directly to the founding of the **NATO Cooperative Cyber Defence Centre of Excellence (CCDCOE)** in Tallinn (2008). The 2010 Stuxnet disclosure — when Symantec, Kaspersky and Ralph Langner reverse-engineered the malware to reveal a US-Israeli joint operation against Iran's Natanz uranium enrichment — provided the first publicly confirmed instance of a cyber weapon causing physical destruction. By the **2016 NATO Warsaw Summit**, cyberspace was formally recognised as the fifth operational domain alongside land, sea, air and space.
- This recognition transformed force structure. **US Cyber Command** elevated from sub-unified command (created 2009) to **unified combatant command** (May 2018), commanding the 133-team **Cyber Mission Force (CMF)** that reached full operational capability the same year. The CMF organises around three lines of effort: 13 National Mission Teams defending DoD interests, 68 Combat Mission Teams supporting combatant commands, and 25 Cyber Protection Teams plus 27 support teams. Authorised end strength stood at ~6,200 personnel in 2024, with the **CYBERCOM 2.0** workforce expansion plan targeting 14,000 by 2028. The **United Kingdom** stood up the **National Cyber Force (NCF)** in 2020 as a permanent joint MOD-GCHQ command, announced its permanent **Samlesbury Lancashire headquarters** in 2021, achieved initial operating capability 2023, and is projected to reach 3,000+ personnel by 2030. **Russia** organises offensive cyber primarily through GRU (military intelligence) units 26165 (Fancy Bear/APT28) and 74455 (Sandworm/Voodoo Bear), with FSB and SVR conducting parallel intelligence-led operations. **China**'s People's Liberation Army Strategic Support Force (PLA SSF), founded 2015, was dissolved in **April 2024** and reorganised into four direct CMC-subordinate forces: **Information Support Force, Cyberspace Force, Aerospace Force, and Joint Logistics Force**.

### Doctrine and Legal Framework

Military cyber operations are governed by an expanding doctrinal corpus combining international law, national legislation, joint doctrine and rules of engagement.

#### NATO CCDCOE and the Tallinn Manuals

The **Tallinn Manual 1.0** (2013) addressed the law of cyber warfare — the application of *jus in bello* and *jus ad bellum* to cyber operations. The **Tallinn Manual 2.0** (Cambridge University Press, 2017) expanded to 154 rules covering peacetime cyber operations, sovereignty, due diligence, state responsibility, international human rights and the law of countermeasures. Authored by an International Group of Experts under the editorship of **Michael N. Schmitt** (US Naval War College, Exeter Law School), it is not binding law but is widely cited by foreign ministries and operational lawyers as the most authoritative statement of *lex lata* in cyberspace. The **Tallinn Manual 3.0** project (2021-2026) expands coverage to AI-enabled operations, supply-chain attacks, ransomware, election interference and below-threshold coercion (the "grey zone").

Key Tallinn 2.0 rules operationally cited:

- **Rule 4** (Sovereignty): States have sovereignty over cyber infrastructure on their territory; violation may constitute internationally wrongful conduct.
- **Rule 14** (Due diligence): States must not knowingly allow their territory to be used for acts contrary to the rights of other states.
- **Rule 71** (Threshold of armed attack): A cyber operation rises to an armed attack when its scale and effects are comparable to non-cyber operations of an armed-attack character — the Schmitt criteria of severity, immediacy, directness, invasiveness, measurability, military character, state involvement and presumptive legality.
- **Rule 92** (Distinction): Cyber attacks must distinguish between civilian objects and military objectives.

  #### UN Norms and the OEWG

  Parallel to NATO doctrine, the **UN Group of Governmental Experts (GGE)** produced consensus reports in **2015** (eleven voluntary norms) and **2021** (additional norms). The **Open-Ended Working Group (OEWG)** broadened participation to all UN member states, producing reports 2021 and 2023. Core norms: states should not knowingly allow their territory to be used for internationally wrongful cyber acts; should not damage critical infrastructure; should respond to requests for assistance from another state whose CI is under attack; should protect computer emergency response teams (CERTs) from being used to engage in malicious activity.

  #### US Doctrine

- **DoD Joint Publication 3-12 (Cyberspace Operations)**, last revised December 2022, defines offensive cyberspace operations (OCO), defensive cyberspace operations (DCO) and DoD Information Network operations.
- **DoDD 3600.01 (Information Operations)**, 2013 with major 2024 reissue, governs the integration of IO with kinetic effects.
- **DoD Manual 5240.01** (2020) governs the conduct of DoD intelligence activities, particularly the protections afforded to US persons under Executive Order 12333.
- The **2018 DoD Cyber Strategy** introduced **Defend Forward** — operating outside US networks to disrupt adversary cyber activity before it reaches US targets — and **Persistent Engagement**, contesting adversaries continuously rather than reacting to discrete intrusions.
- **National Security Presidential Memorandum 13 (NSPM-13)** of 2018 streamlined the inter-agency approval process for offensive cyber operations.

  #### UK Doctrine

- **National Cyber Strategy 2022** (HMG, December 2021 for the 2022-2030 period) sets the £2.6B+ investment trajectory.
- **Defence Cyber Strategy 2022** (MOD, May 2022) commits Defence to becoming a cyber-capable, cyber-resilient and cyber-confident force.
- **Integrated Operating Concept** (CDS General Sir Nick Carter, September 2020) and the **Integrated Review** (March 2021) and **Refresh** (March 2023) establish the strategic frame.
- **National Security Act 2023** modernised espionage offences, introducing a Foreign Influence Registration Scheme and offences for assisting foreign intelligence services.
- **Computer Misuse Act 1990** ss.1-3A remains the primary domestic offence statute, with proposed reform under HMG consultation 2023-2025.
- **Investigatory Powers Act 2016** (as amended by the Investigatory Powers (Amendment) Act 2024) governs bulk equipment interference, the primary UK statutory basis for offensive cyber.

  #### European Union

- **NIS2 Directive (EU) 2022/2555** imposes mandatory cybersecurity obligations on essential and important entities across 18 sectors with national transposition by October 2024.
- **Cyber Resilience Act (CRA) 2024** sets cybersecurity requirements for products with digital elements.
- **Cyber Solidarity Act 2025** establishes the European Cybersecurity Shield with cross-border Security Operations Centres.

### Operational Commands and Force Structure

#### United States: US Cyber Command (USCYBERCOM)

Headquartered at Fort Meade, Maryland, co-located with the National Security Agency (the NSA Director also serving as USCYBERCOM commander under the dual-hat arrangement reviewed periodically since 2017). Components include:

- **Army Cyber Command (ARCYBER)**: HQ Fort Eisenhower (formerly Fort Gordon), Georgia
- **Marine Corps Forces Cyberspace Command (MARFORCYBER)**: Fort Meade
- **Fleet Cyber Command / Tenth Fleet**: Fort Meade
- **Sixteenth Air Force (Air Forces Cyber)**: Joint Base San Antonio-Lackland
- **US Coast Guard Cyber Command**

  The 133 CMF teams totalled ~6,200 personnel in 2024. CYBERCOM 2.0 — announced by General Timothy Haugh on assuming command February 2024 — restructures around persistent engagement, defends forward operations, and integration with Joint All-Domain Command and Control (JADC2).

  #### United Kingdom: NCF, NCSC, Defence Cyber Command

- **National Cyber Force (NCF)** at **Samlesbury Lancashire** — co-located with BAE Systems' Samlesbury site. Joint command between **MOD, GCHQ, SIS** and the **Defence Science and Technology Laboratory (Dstl)**. Operates under Director-level command rotating between MOD and GCHQ. Announced site decision 2021; main building construction underway 2024-2027.
- **National Cyber Security Centre (NCSC)** — part of GCHQ at Cheltenham (plus London office), established October 2016, ~700 staff, public-facing technical authority for UK cyber defence. CEO Felicity Oswald (from April 2024 following Lindy Cameron).
- **MOD Defence Cyber Command** — re-established under **UK Strategic Command** in 2022, absorbing the **Joint Forces Cyber Group** (founded 2013). Led by a 2-star Director with operational authorities over Defensive Cyber Operations (DCO) and Network Operations.
- **Strategic Command** (formerly Joint Forces Command, renamed 2019) under General Sir Jim Hockenhull KBE ADC Gen — the lead military authority for cyber, special operations, and joint enablers.

  #### Russia

  Russian offensive cyber operations are conducted by multiple agencies under competing equities:

- **GRU Main Centre for Special Technologies Unit 74455** (Sandworm, Voodoo Bear, BlackEnergy operators): NotPetya, Olympic Destroyer (PyeongChang 2018), Ukraine power-grid attacks 2015/2016, Viasat KA-SAT.
- **GRU Unit 26165** (Fancy Bear, APT28): DNC hack 2016, anti-doping agencies, OPCW, Bundestag 2015.
- **FSB Centre 16 and Centre 18**: SolarWinds-related Cozy Bear activities historically attributed to SVR but with FSB co-operation per US/UK 2021 attribution.
- **SVR (Foreign Intelligence Service) APT29 (Cozy Bear)**: SolarWinds Orion compromise December 2020, Microsoft 365 attacks 2023-2024.

  #### People's Republic of China

  The **PLA Strategic Support Force (SSF)**, founded 31 December 2015 consolidating space, cyber, electronic warfare and psychological operations, was dissolved on **19 April 2024** by Xi Jinping and reorganised into four CMC-subordinate forces:

- **Information Support Force (ISF)**: network communications, ISR data fusion
- **Cyberspace Force**: offensive and defensive cyber operations
- **Aerospace Force**: space operations and counter-space
- **Joint Logistics Force** (already existed pre-reorg)

  Major attributed PRC actors:

- **APT41 (Double Dragon)**: dual espionage/criminal hybrid
- **APT40 (Leviathan, Bronze Mohawk)**: maritime/naval targeting
- **Volt Typhoon (Voltzite, Bronze Silhouette)**: US critical infrastructure prepositioning
- **Salt Typhoon (Famous Sparrow, Earth Estries)**: telecom intrusions 2024

  #### Other State Actors

- **Israel Unit 8200** (IDF Military Intelligence Directorate, SIGINT/cyber)
- **Iran IRGC Cyber-Electronic Command** and MOIS; APT35 Charming Kitten, APT33 Elfin, APT34 OilRig, MuddyWater
- **DPRK Reconnaissance General Bureau Bureau 121**: Lazarus Group (Sony 2014, WannaCry 2017, $2B+ cryptocurrency theft 2017-2024), Andariel, BlueNoroff (financial), Kimsuky (espionage)

### Landmark Operations

#### Stuxnet (Operation Olympic Games, 2007-2010)

Joint US-Israeli operation against Iran's **Natanz Fuel Enrichment Plant** uranium centrifuge cascade. The malware, discovered publicly in June 2010 by Belarusian VirusBlokAda and analysed by Symantec, Kaspersky and **Ralph Langner**, used **four zero-day exploits** (MS10-046, MS10-061, MS10-073, MS10-092), stolen Realtek and JMicron digital certificates, and a custom payload targeting Siemens **Step7** PLC software controlling Siemens S7-315/417 controllers and Vacon/Fararo Paya frequency converters. Worked by varying centrifuge rotor speed between 1,410 Hz (above safe operating frequency) and 2 Hz over 50 minutes whilst replaying recorded "normal" data to operator displays. **Estimated impact**: ~1,000 IR-1 centrifuges of ~5,000 destroyed, setting back Iran's enrichment programme by ~2 years according to David Albright's Institute for Science and International Security analysis. First publicly confirmed cyber-physical weapon. Disclosed in detail by **David E. Sanger** (NYT 2012) and Kim Zetter's *Countdown to Zero Day* (2014).

#### NotPetya (27 June 2017)

Wiper malware masquerading as ransomware, propagating via the M.E.Doc Ukrainian tax-accounting software supply-chain compromise. Used **EternalBlue** (SMB exploit MS17-010 from Shadow Brokers NSA leak April 2017) and **Mimikatz** credential theft. Targeted Ukrainian government, banks and energy infrastructure but spread globally via multinational subsidiaries:

- **Maersk**: $300M loss, 4,000+ servers and 45,000 PCs rebuilt over 10 days
- **Merck**: $870M loss, production of vaccines including HPV vaccine Gardasil disrupted
- **FedEx TNT Express**: $400M loss
- **Mondelez (Cadbury)**: $188M claim — basis of the *Mondelez v Zurich Insurance* litigation 2018-2022 over the "hostile/warlike action" exclusion
- **Total estimated damage**: $10 billion+ globally (White House CEA estimate 2018)
- **Attribution**: US, UK, Canada, Australia, New Zealand and Denmark formally attributed to Russia GRU on 15 February 2018; UK NCSC named GRU Unit 74455 directly.

  #### WannaCry (12 May 2017)

  Ransomware worm exploiting EternalBlue, infecting 200,000+ machines across 150 countries within 24 hours. Halted (largely) by **Marcus Hutchins** (then 22, Devon UK) registering the kill-switch domain $11. UK impact: **80 of 236 NHS trusts in England** affected per NAO October 2017 report, 19,500 medical appointments cancelled, ambulances diverted from five accident-and-emergency departments. **Estimated NHS cost** £92M (DHSC 2018: £19M in lost output during the attack + £73M IT remediation). **Attribution**: US (Tom Bossert, December 2017), UK NCSC, Australia, Canada, New Zealand and Japan attributed to **DPRK Lazarus Group**.

  #### SolarWinds Orion / SUNBURST (Disclosed December 2020)

  Russian SVR APT29 (Cozy Bear) inserted malicious code into SolarWinds Orion network-monitoring software updates between March and June 2020. ~18,000 customers received the compromised updates; the threat actor selectively exploited ~100 high-value targets including US Treasury, Commerce, State Department, Department of Energy/NNSA, Justice Department email systems, plus **Microsoft, FireEye Mandiant, Cisco**. Disclosed by **FireEye Mandiant** 8 December 2020 after detecting the breach in its own networks. Subsequent **HAFNIUM/Microsoft Exchange ProxyLogon** zero-days disclosed March 2021 enabled broader exploitation. US formally attributed to SVR on 15 April 2021 alongside sanctions and ten-diplomat expulsion.

  #### Colonial Pipeline (7 May 2021)

  **DarkSide** ransomware-as-a-service affiliate (Russian-speaking criminal group, ambiguous state relationship) encrypted Colonial Pipeline business systems. Although operational technology controlling the 5,500-mile pipeline was not directly compromised, Colonial proactively shut down operations to prevent lateral movement. **45% of US East Coast refined-fuel supply** disrupted for 6 days. **$4.4 million ransom paid** in Bitcoin; FBI recovered $2.3 million via DOJ Ransomware and Digital Extortion Task Force. Triggered **TSA Security Directive 02/2021-2024** mandating pipeline cybersecurity reporting.

  #### Viasat KA-SAT AcidRain (24 February 2022)

  At 04:00 UTC on the day of Russia's full-scale invasion of Ukraine, **AcidRain wiper malware** disabled ~30,000 Viasat KA-SAT modems used by Ukrainian military, government and civilian users. Spillover affected 5,800 **Enercon wind turbines in Germany** and customers in France, Italy, Hungary, Greece, Poland. Disabled command-and-control for Ukrainian forces in the opening hours of the invasion. **Formal attribution** to Russia by UK, US, EU and Five Eyes 10 May 2022 — the **first NATO/EU joint cyber attribution to coincide with kinetic invasion**. SentinelLabs and Mandiant published the technical reverse engineering.

  #### Volt Typhoon (CISA/FBI/NSA Joint Advisory, May 2023; updated February 2024)

  PRC state-sponsored APT identified pre-positioning in **US critical infrastructure** — water, energy, transportation, communications systems in continental US, Guam, Hawaii. Distinctive **living-off-the-land (LOTL)** tradecraft using PowerShell, Windows Management Instrumentation, ntdsutil rather than custom malware — defeating signature-based detection. **FBI Director Christopher Wray** January 2024 House Select Committee testimony: "the defining threat of our generation". CISA Director **Jen Easterly** February 2024: pre-positioning is consistent with preparing for "destructive cyber attacks" during a Taiwan crisis.

  #### Salt Typhoon (Disclosed October 2024)

  PRC-attributed intrusions into US telecommunications networks including **AT&T, Verizon, T-Mobile, Lumen** discovered 2024. Compromised **CALEA lawful-intercept systems** providing potential access to law-enforcement wiretap data. Compromised the mobile communications of **Trump-Vance and Harris-Walz campaign staff** during the 2024 US presidential election. Senate Intelligence Committee briefings December 2024 described it as one of the most significant telecommunications compromises in US history.

### Cyber-Kinetic Integration: Ukraine 2022-2026

The Russo-Ukrainian war from February 2022 represents the most extensive integration of cyber, electronic warfare, unmanned systems and kinetic effects in modern conflict.

**Cyber-EW-Kinetic Fusion**:

- **Russian Electronic Warfare**: Krasukha-2/4 (Avtobaza), R-330Zh Zhitel, RB-301B Borisoglebsk-2 jamming Ukrainian Starlink, Bayraktar TB2, HIMARS GPS guidance, ATACMS terminal-guidance
- **Ukrainian counter-EW**: Delta battlefield awareness platform, ASGARD targeting integration, AWS-hosted government data resilience (Microsoft, Amazon, Google moved Ukrainian state IT to cloud Feb-Apr 2022)
- **CISA/Mandiant/Microsoft Threat Intelligence**: documented 8+ distinct wiper families deployed by GRU against Ukraine 2022-2024 (HermeticWiper, WhisperGate, IsaacWiper, CaddyWiper, AcidRain, DesertBlade, RoarBat, SwiftSlicer)

  **Drone Warfare**:

- **Ukrainian FPV drones**: $400-$2,000 unit cost, ~1M+ produced 2024 per President Zelensky, destroying $3M T-90M tanks, $5M S-300 launchers. Drone-launched-from-drone, fibre-optic-tethered (immune to EW jamming) variants 2024-2025.
- **Ukrainian naval drones**: Magura V5, Sea Baby USVs sinking/damaging Russian Black Sea Fleet vessels including landing ship Caesar Kunikov (Feb 2024) and patrol ship Sergei Kotov (Mar 2024). Black Sea Fleet pushed from Sevastopol to Novorossiysk.
- **Russian Shahed-136/Geran-2** Iranian-designed loitering munitions, ~$20K unit cost, Alabuga Tatarstan production scaled to 5,000+/month 2024. Shahed-238 jet-powered variant introduced 2024.
- **Russian Lancet-3** ZALA Aero loitering munition, ~$35K unit cost.

  **Counter-Drone**:

- **UK DragonFire 50kW laser DEW**: MOD/Dstl/MBDA/Leonardo/QinetiQ programme, £100M+ investment, demonstrated 2024 first UK high-power laser engagement, **£10/shot vs £100K Sea Ceptor missile**, planned Royal Navy Type 45 destroyer fielding 2027 then Type 26 frigate by 2030. UK announced gifting 2024 to Ukraine for accelerated combat validation.
- **US Coyote Block 2/3** Raytheon interceptors deployed Ukraine
- **Israeli Iron Beam** 100kW laser DEW operational status 2025

  **Space Cyber**:

- **Starshield**: SpaceX classified Starlink variant for DoD, NRO contract awarded 2024
- **Russian Cosmos 2553**: launched February 2022, US assessment 2024 (publicly disclosed) as nuclear-EMP ASAT test platform
- **Chinese SJ-21**: dual-use rendezvous-proximity satellite demonstrated 2022 docking with defunct Beidou-2 G2

### UK Context: Academic Leadership and Industrial Innovation

The United Kingdom holds an unusually strong position in military cyber, combining sovereign signals-intelligence heritage (Bletchley Park 1939-1945, GCHQ 1946-present), one of the world's oldest cybersecurity research institutions (Royal Holloway ISG), a £2.6B+ National Cyber Strategy 2022-2030 investment, and proximity between academia, government and a concentrated Northern English defence-industrial base.

#### Sovereign Operational Commands

**National Cyber Security Centre (NCSC)** — GCHQ Cheltenham + London office, ~700 staff, established October 2016 incorporating CESG and CCA. Public-facing technical authority. Active Cyber Defence programme (Web Check, Mail Check, Protective DNS, Takedown Service) blocked ~5.5M domains in 2024. CEO Felicity Oswald (April 2024–).

**National Cyber Force (NCF)** — permanent HQ at **Samlesbury, Lancashire** announced 2021 (£5B+ programme including MOD-GCHQ-Dstl integration). Joint chain of command with annual rotation between MOD and GCHQ leads. Co-located with BAE Systems Samlesbury — strategic linkage to UK aerospace defence-industrial base. Initial operating capability 2023, projected 3,000+ personnel by 2030. Tasked with offensive cyber under the NSC-approved authorities framework.

**MOD Defence Cyber Command** — re-established under **Strategic Command** in 2022, absorbing the **Joint Forces Cyber Group**. Led by 2-star Director. Authorities over DCO and MOD Network Operations across the Defence Information Infrastructure (DII).

**Cyber Resilience Centre Network (CRCN)** — nine regional CRCs (England, Wales, Scotland) launched 2019-2022 under Home Office/Cabinet Office/regional police partnership. Provide free cyber guidance to SMEs and third sector. Coordinate with NCA NCCU and regional police ROCUs.

#### Academic Research Centres

**Royal Holloway University of London — Information Security Group (ISG)**:

- Founded **1990** — one of the world's oldest cybersecurity research institutions
- **Centre for Doctoral Training in Cyber Security** (CDT-CS) — EPSRC-funded, ~10 PhD students per cohort
- Smart Card Centre (founded 2002 with Vodafone, Orange, Giesecke+Devrient)
- **Key faculty**: Keith Mayes (Smart Card Centre, formerly head of ISG), Kenny Paterson (now ETH Zurich, applied cryptography), Carlos Cid (cryptography, Simula UiB), Lorenzo Cavallaro (now KCL, ML security)
- **NCSC Academic Centre of Excellence in Cyber Security Research (ACE-CSR)** — Royal Holloway accredited since the scheme's launch 2012

  **Imperial College London — Institute for Security Science and Technology (ISST)**:

- Cross-faculty institute coordinating Department of Computing security research
- **Key faculty**: Sergio Maffeis (web security, software security), Soteris Demetriou (mobile/IoT security)
- **Imperial X / I-X**: AI-security and adversarial ML research, partnerships with Dstl

  **University College London — Information Security Research Group**:

- **NCSC ACE-CSR** accredited
- **Key faculty**: George Danezis (privacy, distributed systems, formerly Microsoft Research), Steven Murdoch (Tor Project core developer, banking authentication), Sarah Meiklejohn (cryptography, blockchain forensics)
- **UCL Centre for Doctoral Training in Cybersecurity** with Alan Turing Institute

  **University of Edinburgh — Security and Privacy Research Group**:

- **Key faculty**: David Aspinall (formal methods, mobile security), Aggelos Kiayias (blockchain, cryptography — Chief Scientist IOG/Cardano)
- **Blockchain Technology Laboratory** with Input Output Global

  **University of Bristol — Cryptography Group**:

- Co-founded by **Nigel Smart** (now KU Leuven COSIC, co-founded Unbound Security acquired by Coinbase 2022)
- **Key faculty**: Elisabeth Oswald (side-channel attacks, now Klagenfurt), Bogdan Warinschi (provable security)
- Multi-Party Computation research, used by **Bristol-based Unbound Security** (now Coinbase Cloud) for institutional cryptocurrency custody

  **University of Oxford — Cyber Security Oxford**:

- Cross-departmental coordination (Department of Computer Science, Oxford Internet Institute, Blavatnik School)
- **Key faculty**: Andrew Martin (CDT in Cyber Security), Joss Wright (privacy), Lucas Kello (cyber politics, *The Virtual Weapon* 2017)

  **University of Surrey — Surrey Centre for Cyber Security (SCCS)**:

- **NCSC ACE-CSR** accredited
- 5G Innovation Centre (5GIC) cyber-physical security research
- **Key faculty**: Steve Schneider (formal methods, voting systems), Helen Treharne (security protocols)

  **Lancaster University — Security Lancaster**:

- **NCSC ACE-CSR** accredited
- Geographic proximity to **NCF Samlesbury** and **BAE Systems Warton/Samlesbury**
- **Key faculty**: Awais Rashid (socio-technical security, CyBOK lead), Daniel Prince (industrial control systems security)
- **CyBOK** — Cyber Security Body of Knowledge, funded by NCSC, produced by Bristol-Lancaster-Oxford-Cardiff-RHUL consortium

  **Other NCSC ACE-CSRs**: Newcastle, Birmingham, Cardiff, Cambridge, Kent, Queen's Belfast, Southampton, Strathclyde, Warwick, KCL, De Montfort, Plymouth, Portsmouth (19 total as of 2024).

  #### Northern English Industrial Hubs

  **Lancashire / Manchester**:

- **BAE Systems Samlesbury** — F-35 Lightning II rear fuselage, Eurofighter Typhoon. **NCF co-location.** ~6,000 employees regionally.
- **BAE Systems Warton** — Tempest/GCAP development, Typhoon flight test.
- **NCC Group plc** — FTSE 250 cybersecurity consultancy headquartered Manchester. ~2,200 employees. Acquired Fox-IT (NL) 2015, IB Consulting 2018.
- **The Hut Group THG / Ingenuity** — Manchester e-commerce/cybersecurity infrastructure.
- **University of Manchester / Manchester Met** — significant cyber research, Greater Manchester Cyber Foundry.

  **Leeds / Yorkshire**:

- **GCHQ Manchester regional office** at Heron House, opened 2018.
- **Leeds Cyber Security and Resilience Centre** — regional CRCN node.
- **First Direct / HSBC UK Tech Hub Leeds** — major financial-services cyber operations.

  **Sheffield / South Yorkshire**:

- **Sheffield Hallam University Centre of Excellence in Terrorism, Resilience, Intelligence and Organised Crime Research (CENTRIC)**.
- **AMRC (Advanced Manufacturing Research Centre)** Boeing/Rolls-Royce industrial cyber-physical research.

  **Newcastle / North East**:

- **Newcastle University** NCSC ACE-CSR — industrial IoT, supply-chain security
- **Sage Group plc** Newcastle — cybersecurity for SME accounting/ERP
- **Digital Catapult NE** SME accelerator including 20+ cybersecurity startups

  **Liverpool / Merseyside**:

- **Hartree Centre (STFC Daresbury)** — government HPC facility, £20M IBM-NVIDIA collaboration, hosts cyber-modelling workloads.
- **Liverpool John Moores Centre for Cybersecurity**.

  #### UK Defence-Industrial Primes

- **BAE Systems Applied Intelligence** (formerly Detica, acquired £531M 2008) — Guildford HQ, NetReveal financial-crime, threat intelligence, NCF/NCSC supplier
- **Thales UK Cyber & Consulting** — Crawley HQ, Manchester growth centre, ~1,000 cyber employees UK
- **Leonardo UK Cyber Operations** — Bristol/Lincoln, Hawk cyber range
- **QinetiQ Cyber** — Malvern (alongside DSTL), Farnborough; £1.7B revenue 2024, ~50% MOD/UK Gov
- **Roke Manor Research** (Chemring Group) — Romsey Hampshire, NCF supplier
- **Babcock International** — Bristol/Coventry cyber and intelligence
- **Sopra Steria UK** — major Cabinet Office, MOD, Home Office cyber contractor
- **Nexor Ltd** — Nottingham, cross-domain solutions / data diodes for MOD
- **PA Consulting** — defence-cyber consulting, Cambridge campus
- **Sophos** — Abingdon Oxfordshire, endpoint security, acquired by Thoma Bravo $3.9B 2020

### Contrasts with Adjacent Domains

Cyber-military operations are routinely conflated with adjacent cyber activities. Five distinctions matter operationally and legally.

#### vs Civilian Cybersecurity

Civilian cybersecurity (corporate CISO function, SOC operations, vulnerability management, compliance) protects organisational assets against criminal monetisation, reputational damage and regulatory penalty. Its measure is risk-reduction expressed in business terms (ALE, MTTR, incidents prevented, audit findings closed). Military cyber's measure is **effect on adversary capability** to achieve commander's intent — denying, degrading, disrupting, deceiving, destroying or manipulating. Civilian cybersecurity operates within domestic law (Computer Misuse Act, GDPR, PCI-DSS); military cyber operates under sovereign prerogative and international humanitarian law. Civilian incident response notifies regulators, customers, ICO; military cyber operations are normally classified and not publicly attributed unless strategic communication requires it.

#### vs Law Enforcement Cyber

Law enforcement cyber (UK NCA National Cyber Crime Unit, regional ROCUs, City of London Police; US FBI Cyber Division and Internet Crime Complaint Center IC3; Europol EC3) pursues criminal investigation under judicial authority, building evidentiary chains admissible in court. Its tools include lawful interception under judicial warrant, mutual legal assistance treaties (MLATs), takedown of criminal infrastructure (Operation Cronos LockBit February 2024, Operation Endgame May 2024 against IcedID/SmokeLoader/Pikabot/Bumblebee/SystemBC), and asset forfeiture. Military cyber pursues **strategic effects** under intelligence/military authority; its evidence does not need to satisfy the criminal standard of proof, and operations often deliberately remain unattributed. Convergence points: joint task forces (DOJ-DoD ransomware task force 2021, NCA-NCSC-MOD operational coordination), shared infrastructure attribution (Bitcoin tracing, malware signatures).

#### vs Non-State Actors

Three categories of non-state cyber actors operate outside (but sometimes alongside) state structures:

- **Organised cybercrime**: Conti, REvil, LockBit, ALPHV/BlackCat, DarkSide, Cl0p, Akira — primarily Russian-speaking groups operating from jurisdictions with limited cooperation; revenue ~$1.1B-1.5B ransomware payments per Chainalysis 2023-2024.
- **Hacktivism**: Anonymous, IT Army of Ukraine (semi-state hybrid 2022-present, ~400K Telegram volunteers conducting DDoS and minor intrusions), Killnet (pro-Russia DDoS collective), GhostSec (Israel-Hamas conflict).
- **Insiders and lone actors**: Edward Snowden 2013, Reality Winner 2017, Joshua Schulte 2017 Vault 7 disclosures; Lapsus$ (UK/Brazilian teenagers including Arion Kurtaj prosecuted 2023 Crown Court).

  States exploit these populations: GRU's use of cybercriminal forums for credentialing, Iran's pseudo-hacktivist Predatory Sparrow fronting IRGC operations, DPRK Lazarus's financial-crime fund-raising (~$2B+ cryptocurrency theft 2017-2024 per Chainalysis). The Tallinn Manual rules on state responsibility (Rules 14-17) and due diligence increasingly address this state-proxy ambiguity.

### Current Landscape (2026)

As of May 2026, the cyber-military domain has consolidated around several structural features.

#### Threat Landscape

- **State-sponsored APTs**: Mandiant M-Trends 2025 reported 73 named APT groups actively tracked, with PRC (32), Russia (15), Iran (9), DPRK (7) as top sponsors.
- **Ransomware**: Chainalysis reported ~$1.1B paid 2023 with rebound to $1.5B 2024; LockBit takedown Operation Cronos (NCA/FBI February 2024) disrupted the dominant RaaS but ALPHV/BlackCat, Cl0p, Akira and Play continued.
- **Supply-chain compromise**: SolarWinds, 3CX (DPRK 2023), MOVEit (Cl0p 2023, 2,700+ victims), XZ Utils backdoor (CVE-2024-3094, near-miss disrupted by Andres Freund).
- **Living-off-the-land**: Volt Typhoon validated LOTL as the dominant tradecraft for state-sponsored prepositioning, driving CISA/NCSC joint guidance February 2024.
- **Hypervisor and edge-device targeting**: 2024-2025 saw concentrated APT exploitation of network-edge appliances (Ivanti Connect Secure CVE-2024-21887, Fortinet FortiOS, Cisco ASA/FTD), VMware ESXi ransomware (Akira, Black Basta), and Microsoft Azure/Entra ID identity compromise (Midnight Blizzard SVR breach of Microsoft corporate email January 2024 disclosed via 8-K filing).
- **Submarine cables and undersea infrastructure**: 2024 Baltic Sea incidents (Estlink 2 power cable, BCS East-West and C-Lion1 data cables, Newnew Polar Bear Chinese vessel implicated October 2023 Balticconnector) prompted **NATO Baltic Sentry mission** January 2025 with maritime patrols, AIS monitoring and SACEUR-level coordination.

  #### Market and Investment

- **Global defence-cyber market 2025**: ~$230B (subset of $1.7T+ SIPRI global military expenditure 2024)
- **Projected 2030**: ~$480B (CAGR 16%, IDC/Gartner consensus)
- **UK National Cyber Strategy 2022-2030**: £2.6B+ investment
- **US DoD FY2025 cyber budget request**: $14.5B
- **US Cyber Excepted Service Workforce**: ~14,000 by 2028 target

  #### NATO and Allied Cooperation

- **NATO CCDCOE Tallinn** — 39 sponsoring nations 2025
- **NATO Cyberspace Operations Centre (CyOC)** at Mons Belgium, declared 2018, full operational capability 2023
- **Virtual Cyber Incident Support Capability (VCISC)** — endorsed Vilnius Summit 2023, providing voluntary national assistance during major incidents
- **AUKUS Pillar 2** — Australia/UK/US advanced capabilities including cyber, AI, quantum
- **Five Eyes (UKUSA)** — UK-US-CA-AU-NZ SIGINT/cyber sharing, FY2024 reorganisation of cyber subgroups

  #### Regulatory and Policy Developments

- **EU NIS2 Directive** — transposition deadline October 2024, enforcement actions 2025
- **EU Cyber Resilience Act 2024** — manufacturer obligations from December 2027
- **US SEC Cybersecurity Disclosure Rules** (December 2023) — public companies must disclose material cyber incidents within 4 business days
- **UK PSTI Act 2022** — IoT device security baseline
- **CIRCIA** US Cyber Incident Reporting for Critical Infrastructure Act 2022 — CISA final rule 2025

### Future Directions (2026-2030)

#### AI-Cyber Convergence

Generative AI and agentic systems are entering the offensive cyber lifecycle:

- **Vulnerability discovery**: DARPA AI Cyber Challenge (AIxCC) finals at DEF CON 32 (Aug 2024) and 33 (2025) demonstrating LLM-driven autonomous patching of open-source codebases
- **Phishing/social engineering**: NCSC 2024 assessment "AI will almost certainly intensify cyber threats over next two years" with GenAI lowering the skill threshold for credential phishing and BEC
- **Adversarial ML against AI defences**: prompt injection, jailbreaks, RAG poisoning of corporate copilots
- **Autonomous cyber agents**: research prototypes (Anthropic, OpenAI, DeepMind 2024-2026) demonstrating end-to-end exploitation chains; UK AI Safety Institute (renamed AI Security Institute 2024) red-teaming foundation models for cyber-uplift

  #### Quantum Threat (Q-Day)

- **NIST Post-Quantum Cryptography Standardisation** finalised first standards August 2024 (ML-KEM/CRYSTALS-Kyber for KEM, ML-DSA/CRYSTALS-Dilithium for signatures, SLH-DSA/SPHINCS+ stateless hash signatures); FIPS 203/204/205 published.
- **Harvest-now-decrypt-later** threats: state actors archiving encrypted traffic for future quantum decryption.
- **UK NCSC PQC migration roadmap** March 2024: critical national infrastructure to complete by 2035.
- **Quantum key distribution (QKD)**: UK Quantum Network Bristol-Cambridge, ChinaSat Micius

  #### Space Cyber

- **Russian Cosmos 2553** nuclear-EMP ASAT capability assessment, publicly disclosed by ABC News/Pentagon February 2024
- **Starshield** SpaceX-NRO classified contract, ~$1.8B over five years (2024 disclosure)
- **EU IRIS² Constellation** — €10.6B secure satellite communications, contract awarded December 2024 to SpaceRise consortium
- **UK Space Command** at RAF High Wycombe, established 2021

  #### Cyber-Kinetic Doctrine Maturation

- **Tallinn Manual 3.0** expected publication 2026, expanding to AI/autonomy, supply chain, ransomware as below-threshold coercion
- **NATO Cyber Defence Pledge 2024** revised commitments
- **Hybrid warfare doctrine**: integration with information operations, lawfare, economic coercion under UK Integrated Operating Concept refresh

  #### Critical Infrastructure Resilience

- **OT/ICS security**: convergence of IT-OT under NIS2, increased ISA/IEC 62443 adoption
- **Sector-specific regulators**: Ofgem (energy), Ofcom (telecoms), Ofwat (water), CAA (aviation), DfT (rail/road) under UK CAF Cyber Assessment Framework
- **Submarine cable security**: increasing focus following 2024 Baltic Sea incidents (Estlink 2, BCS East-West, C-Lion1); NATO Baltic Sentry mission January 2025

  #### Projected Market Trajectories

- **2026**: $260B global defence-cyber, 14,000 USCYBERCOM personnel target, 3,000 NCF personnel
- **2028**: $360B market, AI-cyber tools mainstream in red-teams and blue-teams
- **2030**: $480B market, PQC migration of CNI substantially complete, hybrid warfare standardised in NATO doctrine

  #### Deterrence Theory in the Cyber Age

  Classical nuclear deterrence theory (Bernard Brodie, Thomas Schelling, Herman Kahn) rested on assured second-strike capability, clear attribution, rational unitary actors and a small number of weapons producing categorical effects. Cyber violates all four assumptions: attribution is contested and delayed, effects are reversible and ambiguous, the attacker community spans state, proxy and criminal actors, and the offence is permissive (low cost of entry). Three doctrinal responses have emerged.

  **Deterrence by denial**: harden targets so attacks fail or are not worth the cost. NIS2, CRA, US CISA's Cyber Performance Goals, UK Cyber Assessment Framework, Zero Trust Architecture (NIST SP 800-207). Limitations: defence-favouring shifts are slow and partial; sophisticated actors retain access.

  **Deterrence by punishment**: impose costs on attackers via attribution, indictment, sanctions, expulsion, retaliatory cyber action. US DOJ APT indictments (Mueller GRU 2018 DNC indictment, FBI/DOJ Conti 2024 Trickbot indictments), UK OFSI/EU sanctions on GRU officers, retaliatory cyber operations under NSPM-13/Defend Forward. Limitations: extradition rarely succeeds against state actors; signalling clarity is weak.

  **Deterrence by entanglement**: increase the costs of escalation through economic, alliance and reputational interdependence. NATO Article 5 ambiguity (declared cyber-applicable 2014, never invoked), Five Eyes joint attributions, EU Cyber Diplomacy Toolbox. The 2022 Russo-Ukrainian war has tested entanglement: Russia's exclusion from SWIFT, technology export controls, and Western private-sector withdrawal demonstrated entanglement working, whilst kinetic conflict proceeded regardless.

  Contemporary scholarship (Kello 2017, Buchanan 2020, Maschmeyer 2024) increasingly frames cyber as a **below-threshold subversion** instrument unsuited to traditional deterrence — best understood through Cold War intelligence-contest frameworks than nuclear-deterrence frameworks. The strategic implication: states should expect persistent intrusion and design for resilience, attribution, denial and selective response rather than expect attacks to be deterred categorically.

### Research and Literature

**Foundational Doctrine**:
1. Schmitt, M.N. (Ed.) (2017). *Tallinn Manual 2.0 on the International Law Applicable to Cyber Operations*. Cambridge University Press. [154 rules, the authoritative doctrinal text]
2. Schmitt, M.N. (Ed.) (2013). *Tallinn Manual on the International Law Applicable to Cyber Warfare*. Cambridge University Press. [Tallinn 1.0]
3. NATO CCDCOE (2008–present). Tallinn Manual 3.0 Project Documentation. https://ccdcoe.org/research/tallinn-manual/
4. UN GGE (2015). Report of the Group of Governmental Experts on Developments in the Field of Information and Telecommunications. A/70/174.
5. UN GGE (2021). Final Report. A/76/135. [Eleven norms reaffirmed and expanded]
6. US DoD (2022). *Joint Publication 3-12: Cyberspace Operations*.
7. US DoD (2024). *DoD Directive 3600.01: Information Operations* (reissue).
8. US DoD (2020). *DoD Manual 5240.01: Procedures Governing the Conduct of DoD Intelligence Activities*.
9. HM Government (2021). *National Cyber Strategy 2022*. https://www.gov.uk/government/publications/national-cyber-strategy-2022
10. UK Ministry of Defence (2022). *Defence Cyber Strategy 2022*.

**Operational Case Studies**:
11. Sanger, D.E. (2012). *Confront and Conceal: Obama's Secret Wars and Surprising Use of American Power*. Crown. [Stuxnet attribution]
12. Zetter, K. (2014). *Countdown to Zero Day: Stuxnet and the Launch of the World's First Digital Weapon*. Crown.
13. Greenberg, A. (2019). *Sandworm: A New Era of Cyberwar and the Hunt for the Kremlin's Most Dangerous Hackers*. Doubleday. [GRU Unit 74455, NotPetya]
14. UK NCSC, US CISA, FBI, NSA (2018). Joint Statement on NotPetya Attribution. February 2018.
15. UK National Audit Office (2017). *Investigation: WannaCry cyber attack and the NHS*. HC 414, October 2017.
16. CISA, FBI, NSA (2023, updated February 2024). *Joint Cybersecurity Advisory: PRC State-Sponsored Cyber Actors Living Off the Land to Evade Detection (Volt Typhoon)*. AA23-144a / AA24-038a.
17. SentinelLabs & Mandiant (2022). Technical analysis of AcidRain wiper and Viasat KA-SAT incident.

**Strategy and Theory**:
18. Kello, L. (2017). *The Virtual Weapon and International Order*. Yale University Press.
19. Buchanan, B. (2020). *The Hacker and the State: Cyber Attacks and the New Normal of Geopolitics*. Harvard University Press.
20. Healey, J. (Ed.) (2013). *A Fierce Domain: Conflict in Cyberspace, 1986 to 2012*. Atlantic Council / Cyber Conflict Studies Association.
21. Rid, T. (2013). *Cyber War Will Not Take Place*. Hurst/Oxford University Press.
22. Singer, P.W., & Friedman, A. (2014). *Cybersecurity and Cyberwar: What Everyone Needs to Know*. Oxford University Press.
23. Sanger, D.E. (2018). *The Perfect Weapon: War, Sabotage, and Fear in the Cyber Age*. Crown.
24. Maschmeyer, L. (2024). *Subversion: From Covert Operations to Cyber Conflict*. Oxford University Press.

**Technical and Forensic**:
25. Langner, R. (2013). *To Kill a Centrifuge: A Technical Analysis of What Stuxnet's Creators Tried to Achieve*. Langner Communications.
26. MITRE Corporation (2024). *MITRE ATT&CK for Enterprise v15*. https://attack.mitre.org/
27. Mandiant (2025). *M-Trends 2025 Annual Threat Report*. Google Cloud / Mandiant Intelligence.
28. NCSC, CISA, ASD, CCCS, NCSC-NZ (2024). Joint Advisory on Living-off-the-Land Techniques. February 2024.

**UK Academic and Doctrinal**:
29. Rashid, A., et al. (2021). *CyBOK: The Cyber Security Body of Knowledge*, v1.1. https://www.cybok.org/ [NCSC-funded consortium of Bristol, Lancaster, Oxford, RHUL, Cardiff]
30. Smart, N.P. (2016). *Cryptography Made Simple*. Springer. [Bristol Cryptography Group]

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review during Phase 6 enrichment sprint
- **Verification**: Doctrine sources verified against NATO CCDCOE Tallinn Manual 2.0 (Cambridge University Press 2017), US Joint Publication 3-12 (2022), UK National Cyber Strategy 2022 and Defence Cyber Strategy 2022 (HMG); operational attributions cross-referenced against CISA/FBI/NSA Joint Cybersecurity Advisories, UK NCSC formal attribution statements, Mandiant M-Trends 2025, SentinelLabs technical reports, MITRE ATT&CK group attributions; UK organisational structure verified against NCSC public website, GOV.UK NCF announcement July 2020 and Samlesbury site announcement July 2021, MOD Strategic Command public communications
- **Regional Context**: UK academic institutions (Royal Holloway ISG, Imperial College London ISST, UCL Information Security, University of Edinburgh, University of Bristol Cryptography Group, University of Oxford Cyber Security Oxford, University of Surrey SCCS, Lancaster Security Lancaster) and Northern English defence-industrial hubs (Lancashire — BAE Samlesbury/Warton, NCF Samlesbury, NCC Group Manchester; Leeds — GCHQ Manchester regional office, financial-services cyber; Sheffield — Sheffield Hallam CENTRIC, AMRC; Newcastle — Newcastle University ACE-CSR, Sage Group; Liverpool — Hartree Centre Daresbury) detailed with concrete sites, organisations and personnel
- **Domain Correction**: Original frontmatter classified the concept under `infrastructure` domain — reclassified to `security` reflecting the canonical placement of cyber-military operations as a security/defence domain concept. IRI/URI rewritten to security namespace; legacy-term-id SEC-1107 assigned. The original page's `bridges-to:: [[Blockchain]]` cross-link preserved given blockchain forensics' role in ransomware investigation (Chainalysis Reactor, Elliptic) and the Colonial Pipeline Bitcoin recovery
- **Production-Ready**: Complete OWL formal semantics; comprehensive coverage of doctrine (Tallinn 2.0/3.0, UN GGE, US JP 3-12, DoDD 3600.01, UK NCS 2022 / Defence Cyber Strategy 2022), operational commands (USCYBERCOM, NCF, GRU 26165/74455, PLA SSF→ISF/Cyberspace/Aerospace April 2024 reorg, Israeli Unit 8200, Iranian IRGC, DPRK Lazarus), landmark operations (Stuxnet 2007-2010, NotPetya 2017 $10B+, WannaCry NHS impact £92M, SolarWinds Dec 2020, Colonial Pipeline May 2021, Viasat 24 Feb 2022, Volt Typhoon 2023-2024, Salt Typhoon 2024), cyber-kinetic integration (Ukraine drone war, UK DragonFire 50kW), UK ecosystem and 2026-2030 future directions
- **Authority Score**: 0.87 (consolidating warfighting domain since 2016 NATO Warsaw declaration; foundational doctrinal corpus in Tallinn Manuals; major standing commands USCYBERCOM/NCF; $230B 2025 → $480B 2030 market; ongoing intense activity through Russo-Ukrainian war, Volt/Salt Typhoon, evolving AI-cyber convergence; broad UK academic-industrial base)

### Provenance

- **domain-correction:** infrastructure → security (original misclassification; cyber-military operations canonically belong to security/defence domain). Legacy bridges-to:: [[Blockchain]] preserved due to blockchain forensics' role in ransomware investigation and Colonial Pipeline Bitcoin recovery

