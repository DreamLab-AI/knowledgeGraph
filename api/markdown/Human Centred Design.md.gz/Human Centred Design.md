Human centred design is a problem-solving approach that places the needs, capabilities and behaviours of people at the centre of the design process, iteratively shaping products and systems around real user contexts. It draws on empirical understanding of users and tasks, involves stakeholders throughout development, and refines solutions through repeated evaluation. The practice underpins usable, accessible and inclusive interactive systems across digital and physical domains.

### Overview

- The approach originates in ergonomics and cognitive psychology and is codified internationally in design-process standards such as ISO 9241-210.
- Rather than starting from technology or organisational convenience, human centred design begins with explicit study of users, their tasks and the environments in which work happens.
- Solutions are produced as candidate designs, evaluated against user requirements, and revised across multiple cycles until they satisfy measurable usability and accessibility criteria.
- The methodology is deliberately interdisciplinary, blending research, visual and interaction craft, and engineering feasibility.

### Key aspects

- Explicit understanding of users, tasks and contexts of use through field research and contextual enquiry.
- Active involvement of users and stakeholders throughout specification, design and evaluation.
- Allocation of functions between people and technology informed by human capabilities and limitations.
- Iteration of design solutions driven by user-centred evaluation.
- A holistic concern for the whole user experience, not isolated interface elements.
- Multidisciplinary teams combining research, design, accessibility and engineering perspectives.

### Mechanisms

- Contextual enquiry, interviews and observation to capture genuine user needs.
- Persona and scenario construction to keep teams aligned on whom they design for.
- Low- and high-fidelity prototyping to test concepts cheaply before commitment.
- Usability testing and accessibility audits to surface defects against real tasks.
- Continuous feedback loops that fold evaluation findings back into design.

### Applications

- Consumer software and mobile application interfaces.
- Public-sector and government digital services where inclusivity is mandated.
- Medical devices, vehicle cockpits and other safety-critical interfaces.
- Spatial and immersive systems where embodied interaction must match human perception.
- Enterprise tooling where adoption depends on fit to actual work practice.

### Provenance

