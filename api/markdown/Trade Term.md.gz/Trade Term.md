A trade term is a standardised expression in a contract of sale that fixes where delivery happens and which party carries the tasks, costs and risks of moving the goods to that point, with Incoterms the best-known set.[^1][^2]

The International Chamber of Commerce describes Incoterms rules as standards used in international and domestic contracts for the delivery of goods, clarifying the tasks, costs and risks involved in delivery from sellers to buyers.[^1] The US International Trade Administration calls them terms of sale and says they specify who is responsible for paying for and managing the shipment, insurance, documentation, customs clearance and other logistical activities.[^2]

## Scope and distinctions

Trade terms are not confined to the ICC set. The US Uniform Commercial Code treats F.O.B. as a delivery term. Where the term is F.O.B. the place of shipment, the seller must ship the goods at that place and bear the expense and risk of putting them into the possession of the carrier. Where it is F.O.B. the place of destination, the seller must transport the goods to that place at its own expense and risk.[^3] The same abbreviation therefore means different things under the Code and under Incoterms.[^3][^4]

A trade term is narrower than a sales contract. According to the International Trade Administration, Incoterms do not address all the conditions of a sale, and they do not settle when title to the goods passes from seller to buyer.[^2] Payment method and timing, the contract price and liability for late or non-conforming delivery also lie outside them.[^2]

Within this domain, [[Incoterms]] is the main trade term class, with [[Free on Board]] and [[Delivered Duty Paid]] as two of its rules. Trade terms matter to [[International Trade]] and to customs work because each rule states which party obtains export and import clearance, though the International Trade Administration adds that Incoterms have no regulatory basis.[^2]

## In practice

The International Trade Administration notes that parties may agree to use an earlier version of Incoterms provided they say which version they have chosen.[^2] The page also says its summary is not legal advice and is not the official or full definition of each rule.[^2]

## What the sources do not establish

No opened source defines trade term as a general category. This page generalises from the ICC and US government descriptions of Incoterms and from the Uniform Commercial Code, and it does not claim a complete list of trade term families.

[^1]: International Chamber of Commerce, Incoterms rules page. https://iccwbo.org/business-solutions/incoterms-rules/
[^2]: International Trade Administration (US Department of Commerce), “Know Your Incoterms”. https://www.trade.gov/know-your-incoterms
[^3]: Cornell Law School Legal Information Institute, “§ 2-319. F.O.B. and F.A.S. Terms.” (Uniform Commercial Code). https://www.law.cornell.edu/ucc/2/2-319
[^4]: Export Council of Australia, “FOB – Free on Board (Named Place) Incoterms® 2020”. https://export.org.au/?p=17266

