Customs clearance is the process of declaring goods to customs and completing the formalities needed for them to be released across a border.[^1][^2]

Maersk's glossary describes it as the process of declaring and clearing cargoes through customs.[^1] The European Commission says that before goods can enter the European single market they need to be cleared by customs, and that this procedure allows goods to circulate freely and changes the status of non-EU goods to that of goods produced in the EU.[^3] GOV.UK frames the same step for imports as making an import declaration and getting goods through the UK border, and warns that getting customs clearance is complicated.[^4]

## Terms in the Union Customs Code

The Code's definitions that bear on the topic are customs formalities, defined as all the operations which must be carried out by a person and by the customs authorities in order to comply with the customs legislation, and release of goods, defined as the act whereby the customs authorities make goods available for the purposes specified for the customs procedure under which they are placed.[^2] Clearance as a name for the whole sequence of declaration, formalities and release is the carrier glossary's usage; the Code names the component acts.[^1][^2]

## Who does it

GOV.UK says an importer can hire a transporter or customs agent to make the import declaration, and that most businesses that import goods use one.[^4][^5] A freight forwarder will arrange clearing the goods through customs, and customs agents and brokers make sure goods clear.[^6] See [[Customs Broker]], [[Freight Forwarder]] and [[Customs Declaration]].

## Evidence limits

Maersk's glossary is a carrier's working definition, and the other sources describe EU and UK practice. No opened source gives clearance times or costs, and none is used for them here.[^1][^3][^4]

[^1]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms
[^2]: European Parliament and Council, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code (recast)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^3]: European Commission, “Importation - Taxation and Customs Union - European Commission”. https://taxation-customs.ec.europa.eu/customs/customs-procedures-import-and-export/importation_en
[^4]: HM Revenue and Customs, “Get UK customs clearance when importing goods into the UK: step by step - GOV.UK”. https://www.gov.uk/import-customs-declaration
[^5]: HM Revenue and Customs, “Import goods into the UK: step by step - GOV.UK”. https://www.gov.uk/import-goods-into-uk
[^6]: HM Revenue and Customs, “Get someone to deal with customs for you - GOV.UK”. https://www.gov.uk/guidance/appoint-someone-to-deal-with-customs-on-your-behalf

