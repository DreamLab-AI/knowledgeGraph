Inventory management is a set of policies and controls designed to monitor the levels of inventory, including raw materials, components and finished products, across the locations of a supply chain such as warehouses and production systems.[^1]

A review of operations and supply chain management gives its goal as maintaining the right quantity of products to meet demand while minimising holding costs and preventing stockouts. It says inventory management should address three questions: where to stock the product, when to place the order to replenish the stock, and how much to order.[^1] An open operations text puts the objective as achieving satisfactory levels of customer service while keeping inventory costs reasonably low, with a trade-off between how much inventory is kept and the service level provided.[^2] Georgia Tech class notes say the overall objective of holding inventory is to satisfy an acceptable level of customer demand, and that the inventory control system attempts to minimise the total system cost of providing that level of service.[^3]

## Scope and distinctions

MIT lecture slides define inventory as goods that a business holds for resale or redistribution, and list the questions a manager faces as which items to stock, where to stock them, how much to order and when to place an order.[^4] The stock itself is classified at [[Inventory Type]]; the rules for ordering are at [[Inventory Policy]]. Stock held against uncertainty is covered at [[Safety Stock]], and the forecasts that drive replenishment at [[Demand Forecasting]].

Inventory management is related to [[Procurement]] and [[Logistics]]; this page does not cover how goods are bought or moved. Models for choosing order sizes, such as the [[Economic Order Quantity]], are covered on their own pages.

## What the sources do not establish

An earlier version of this page, written without sources, described identification technologies such as barcodes and RFID, sector applications in retail, healthcare and spare parts, and the use of real-time visibility. None of the sources opened here supports those statements, so they are not repeated. The sources agree on the purpose of inventory management but use different lists of decisions, and none gives a measure of how much inventory a firm should hold.

[^1]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749
[^2]: Business LibreTexts (Introduction to Operations Management, NWTC), “9: Inventory Management (chapter introduction)”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management
[^3]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design, Chapter 5. Inventory Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/inventory_systems/inventory_systems.pdf
[^4]: Stephen C. Graves, MIT OpenCourseWare 15.772J D-Lab: Supply Chains, lecture 13 slides, “Inventory Management”. https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2014/b0b41cc09a83ffa4cf1335ac65f5f9ab_MIT15_772JF14_Lec13.pdf

