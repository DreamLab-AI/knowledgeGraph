Scientific machine learning is the discipline that fuses data-driven learning with the governing equations, conservation laws and mechanistic structure of the physical sciences. It embeds domain knowledge such as differential equations and symmetries directly into model architectures and loss functions so that learned models remain physically consistent, data-efficient and extrapolative. The field spans surrogate modelling of expensive simulators, discovery of governing equations from data, and hybrid models that blend numerical solvers with neural components.

### Overview

- Scientific machine learning responds to a recurring problem in computational science: purely data-driven models ignore hard-won physical laws and generalise poorly, while traditional simulators are accurate but slow and inflexible. By encoding mechanistic priors into learnable models, the field obtains predictors that respect physics, train from sparse and noisy measurements, and accelerate simulation by orders of magnitude.
- It is modelled as a subclass of [[Machine Learning]] within the machine-learning domain.
- A defining feature of scientific machine learning is differentiability through the physics. By implementing numerical solvers in automatic-differentiation frameworks, gradients can flow from a downstream loss back through the simulator to its parameters, unifying calibration, control and learning in a single optimisation. This blurs the historical boundary between simulation and statistical inference.
- The field is data-efficient by design: because mechanistic constraints supply much of the inductive bias that a purely data-driven network would otherwise have to learn, models can be trained from sparse, noisy or partial observations that would be insufficient for an unconstrained network.

### Mechanisms

- Physics-informed losses: residuals of governing differential equations are added to the training objective so predictions satisfy known dynamics.
- Neural surrogates: learned models approximate expensive numerical solvers for rapid forward and inverse evaluation.
- Equation discovery: sparse regression and symbolic methods recover governing equations directly from observed trajectories.
- Hybrid solvers: differentiable numerical integrators are composed with neural components for end-to-end training.

### Applications

- Surrogate modelling for fluid dynamics, climate and materials simulation.
- Inverse problems and data assimilation in geophysics and medical imaging.
- Accelerating digital twins and design optimisation loops in engineering.

### Considerations

- Balancing data-fit and physics-residual terms in the loss is delicate; poor weighting can let one term dominate and degrade the other.
- Stiff dynamics and multi-scale phenomena remain challenging for naive physics-informed training, motivating curriculum and domain-decomposition strategies.
- Verification against trusted numerical baselines is essential before scientific conclusions are drawn from a learned surrogate.

### Provenance

