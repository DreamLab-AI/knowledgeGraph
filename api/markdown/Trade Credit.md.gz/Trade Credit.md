Trade credit is credit that a seller extends to a buyer between the time the buyer receives goods or services and the time it pays for them.[^1][^2]

OpenStax's Introduction to Business gives the standard example: when a tire maker sells to a carmaker, the carmaker does not pay cash on delivery, the supplier bills regularly, and the buyer pays at a later date. The buyer enters the credit on its books as an account payable, which in effect makes it a short-term loan from the seller.[^1] Its Principles of Finance text says trade credit, also known as accounts payable, is granted by vendors to creditworthy companies when they purchase materials, inventory and services.[^2]

## How it works

Invoices specify the credit terms, and OpenStax says there is usually no interest expense associated with trade credit.[^2] It says most trade credit is offered to a company with an open account that has a credit limit, up to which it can purchase without paying cash up front.[^2] The same section calls trade credit spontaneous financing, because payables rise with the gearing up of operations and the extra investment in current assets.[^2] See [[Open Account Trade]].

## As a source of finance

A European Central Bank working paper says trade credit is an important source of finance for firms, especially when firms find it difficult to obtain external funding via credit institutions.[^3] It describes trade credit of euro area non-financial firms, in the form of accounts payable and receivable, as moving broadly in line with the business cycle.[^3]

## In international sales

The US International Trade Administration notes that the extension of credit by the seller to the buyer is more common abroad, so exporters who are reluctant to extend credit may lose sales to competitors.[^4] See [[Trade Payment Method]] and [[Credit Risk]].

## What the sources do not establish

Both OpenStax sections are from one publisher, so the definition rests on one textbook family plus the ECB paper. The alias Supplier Credit does not appear in the sources opened. The sources do not give typical credit periods outside the 30, 60 or 90 days the ITA mentions for open account sales, and they do not give the cost of trade credit.[^1][^2][^3][^4]

[^1]: OpenStax, “16.3 Obtaining Short-Term Financing”, Introduction to Business. https://openstax.org/books/introduction-business/pages/16-3-obtaining-short-term-financing
[^2]: OpenStax, “19.2 What Is Trade Credit?”, Principles of Finance. https://openstax.org/books/principles-finance/pages/19-2-what-is-trade-credit
[^3]: Annalisa Ferrando and Klaas Mulier, European Central Bank Working Paper Series No 1502, December 2012, “Do Firms Use the Trade Credit Channel to Manage Growth?”. https://www.ecb.europa.eu/pub/pdf/scpwps/ecbwp1502.pdf
[^4]: US International Trade Administration, “Trade Finance Guide: A Quick Reference for U.S. Exporters”, updated 2021 (PDF). https://www.trade.gov/sites/default/files/2021-03/Trade%20Finance%20Guide%20Updated%20030421%20FINAL.pdf

