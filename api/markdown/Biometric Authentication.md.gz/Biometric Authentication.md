Biometric authentication is an identity verification method that uses measurable, unique physiological or behavioural characteristics of an individual — such as fingerprints, facial geometry, iris patterns, voice, or behavioural signals like keystroke dynamics — to confirm the claimed identity of a subject. Unlike password-based or token-based mechanisms, biometric credentials are inherent to the individual and cannot be forgotten, shared, or easily replicated, though they introduce irreversibility concerns because compromised biometric data cannot be reset. A complete system comprises enrolment, secure template storage (typically on-device in a secure enclave), a matching engine evaluated by false acceptance rate and false rejection rate, and presentation attack detection to counter spoofing. Biometric authentication underpins modern identity assurance frameworks such as FIDO2/WebAuthn, eIDAS 2.0 digital identity wallets, and biometric border control systems worldwide.

### Overview

- Biometric authentication emerged from forensic science — fingerprint identification was systematised in law enforcement before 1900 — and expanded into automated systems during the 1970s with Automated Fingerprint Identification Systems (AFIS). Consumer mainstream adoption arrived with on-device fingerprint sensors around 2013–2014 and face unlock systems shortly thereafter.
- The appeal of biometrics is threefold: high usability (nothing to remember or carry), strong binding to the genuine user, and resistance to phishing because the credential cannot be typed or replayed. The principal risks are: biometric data is permanently sensitive once compromised; matching accuracy varies across demographic groups, creating equity concerns; and large centralised biometric databases represent high-value attack targets.
- Modern best practice places biometric matching exclusively on-device inside a [[Secure Enclave]] or [[Trusted Execution Environment]], with only a cryptographic attestation signal leaving the device. This architecture, formalised in [[FIDO2]] and [[WebAuthn]], decouples biometric verification from server-side authentication logic and eliminates centralised template stores.

### Key Components and Mechanisms

- **Enrolment subsystem** — captures one or more raw biometric samples, extracts a compact feature template, and stores it in protected memory. Quality checks reject poor captures at enrolment time to reduce future false rejections.
- **Secure template storage** — templates reside in a [[Hardware Security Module]] or on-device [[Secure Enclave]] (e.g. Apple Secure Enclave, ARM TrustZone, Qualcomm SPU). Storage is isolated from the main OS so malware cannot exfiltrate the template.
- **[[Feature Extraction]]** — converts raw sensor data (image, audio waveform, keystroke timing) into a normalised mathematical representation. Deep learning feature extractors (CNNs for face and iris, RNNs for voice) have largely superseded hand-crafted descriptors.
- **Matching engine** — computes a similarity score between the live sample feature vector and the enrolled template; accepts or rejects based on a configurable threshold. Performance is characterised by false acceptance rate (FAR), false rejection rate (FRR), and the equal error rate (EER) where FAR = FRR.
- **[[Presentation Attack Detection]]** (liveness detection) — determines whether a biometric sample originates from a live person rather than a spoof artefact (printed photograph, silicone fingerprint, 3D face mask, replay recording). PAD is standardised in ISO/IEC 30107.
- **Biometric modalities**:
  - *Fingerprint* — oldest automated modality; minutiae-based matching; used in smartphones, border control, physical access control.
  - *Facial recognition* — 2D and 3D analysis; mass-market via smartphones; also used in border eGates and surveillance (subject to high-risk AI Act classification in the EU).
  - *Iris recognition* — extremely high FAR/FRR performance; used in border control, high-security environments.
  - *Voice / speaker recognition* — behavioural-physiological hybrid; used in telephone banking and voice assistants.
  - *Behavioural biometrics* — keystroke dynamics, gait, mouse movement; used for [[Continuous Authentication]] in fraud detection without explicit user action.

### Applications and Use Cases

- **Consumer device unlock** — fingerprint and facial unlock on smartphones and laptops; Touch ID (2013), Face ID (2017), Windows Hello (2015) drove mass adoption.
- **[[Passwordless Authentication]] for web services** — [[FIDO2]]/[[WebAuthn]] passkeys use on-device biometric unlock to release a private signing key, replacing passwords for web and app logins; deployed by Apple, Google, Microsoft, and major enterprises.
- **[[Digital Identity Verification]] and KYC** — biometric selfie matching against passport chip data for remote identity proofing in financial services onboarding; mandated for high-assurance levels under [[eIDAS 2.0]].
- **Border control and travel** — automated biometric border control (eGates) at international airports match live face or iris against passport chip; major airports in UK, EU, USA, UAE, Australia.
- **Physical access control** — fingerprint and facial readers on data centre doors, high-security facilities, and time-and-attendance systems.
- **Financial services** — biometric payment confirmation; voice banking; continuous behavioural biometric scoring for transaction fraud detection.
- **Healthcare** — patient identification to reduce medication errors and ensure correct record access; biometric time-and-attendance for clinical staff.
- **Law enforcement and forensics** — AFIS for criminal fingerprint identification; facial recognition watchlists (subject to significant regulation in democratic jurisdictions).
- **Extended reality / spatial computing** — iris and facial biometrics for user identification in head-mounted displays; eye tracking as implicit authentication signal in [[Spatial Computing]] headsets; bridging biometric identity into immersive environments.

### Standards and Governance Context

- **ISO/IEC 19794** — international family of biometric data interchange formats (fingerprint minutiae, facial image, iris image, etc.).
- **ISO/IEC 30107** — biometric presentation attack detection (liveness detection); three-part standard covering framework, technical testing, and conformance testing.
- **NIST SP 800-76** — biometric specifications for US Personal Identity Verification (PIV) credentials.
- **NIST FRVT** — Face Recognition Vendor Testing; the authoritative ongoing benchmark for facial recognition accuracy and demographic differential performance.
- **[[FIDO2]] / [[WebAuthn]]** — W3C WebAuthn Level 2 and FIDO2 CTAP 2.2; the dominant open standard for integrating on-device biometrics into phishing-resistant web authentication.
- **[[eIDAS 2.0]] (EU 910/2014 as amended)** — mandates biometric-based identity proofing for high-assurance levels in EU Digital Identity Wallets, expected to affect hundreds of millions of EU citizens.
- **GDPR (EU) and UK GDPR** — classifies biometric data processed for the purpose of uniquely identifying natural persons as a special category of personal data; processing requires an explicit legal basis. Relevant to [[Data Protection]] obligations.
- **EU AI Act (2024)** — classifies real-time remote biometric identification in publicly accessible spaces as prohibited AI (with narrow exceptions); post-hoc remote biometric identification as high-risk AI requiring conformity assessment.
- **CCPA / US state privacy laws** — several US states (Illinois BIPA, Texas, Washington) impose specific consent and retention obligations on biometric data collection by private entities.

### Privacy and Equity Considerations

- Biometric data is uniquely sensitive because it is permanently linked to an individual's physical identity and cannot be rotated if compromised, unlike a password or cryptographic key. This irreversibility necessitates strict [[Privacy by Design]] principles — specifically on-device matching, template protection schemes (e.g. cancelable biometrics, biometric cryptosystems), and minimal data retention.
- Published evaluations including NIST FRVT have documented statistically significant differences in false rejection and false acceptance rates across demographic groups (age, sex, skin tone) for facial recognition algorithms. This differential accuracy creates disparate impact in access control contexts and has led to regulatory restrictions on facial recognition in public spaces in several EU member states and major US cities.
- The combination of biometric identification with large-scale population tracking constitutes a qualitatively different privacy risk than individual authentication, motivating the EU AI Act's near-prohibition on real-time remote biometric identification in public spaces.
- [[Self Sovereign Identity]] architectures attempt to address control and consent issues by allowing individuals to hold their own biometric templates in a personal data store and selectively present derived credentials, rather than sharing raw biometric data with relying parties.

### Technical Integration Patterns

- **On-device matching with cryptographic attestation** — the dominant modern pattern: biometric match triggers a hardware-backed private key signature; the server verifies the signature without receiving any biometric data. Implemented via [[FIDO2]] platform authenticators.
- **Biometric template protection** — cancelable biometrics apply a one-way transform to the raw template; biometric cryptosystems (fuzzy extractors, fuzzy vaults) derive a cryptographic key from a biometric sample such that the key is reproducible within match threshold tolerance but the template cannot be recovered from the key.
- **Continuous and implicit authentication** — behavioural biometrics (keystroke, mouse, touch, gait) collected passively during a session are scored against a user model to detect anomalous session take-over, bridging to [[Machine Learning]] inference and [[On-Device Inference]] for low-latency fraud signals.
- **Federated biometric identity** — biometric verification at one relying party can assert an identity claim to other relying parties via a verifiable credential, linking to [[Self Sovereign Identity]] and [[Digital Identity Verification]] federation patterns.

### Provenance

