Google DeepMind is an AI research and development division of Alphabet Inc., formed in April 2023 by the merger of Google Brain (founded 2011) and DeepMind (founded 2010, acquired by Google in 2014). It is responsible for foundational breakthroughs in reinforcement learning, protein structure prediction (AlphaFold), and large-scale multimodal AI (Gemini), and pursues both long-term fundamental research and product integration across Google's services. Operating from London, Mountain View, and additional global sites, it is one of the largest and most influential AI research institutions in the world, with a stated mission of advancing artificial intelligence for the benefit of humanity whilst maintaining safety-centred development practices.

### Overview

- Google DeepMind sits at the apex of modern AI research, combining the complementary strengths of two historically significant laboratories into a single unified entity.
- **Historical roots** — DeepMind was founded in London in 2010 by Demis Hassabis, Shane Legg, and Mustafa Suleyman. Google Brain emerged from a 2011 internal project at Google led by Jeff Dean and Andrew Ng, becoming the company's core deep learning research unit. Google acquired DeepMind in 2014 for approximately £400 million.
- **The 2023 merger** — In April 2023, Alphabet merged the two labs under the Google DeepMind banner, with Demis Hassabis as CEO. The rationale was to eliminate duplication, pool compute resources, and accelerate delivery of [[Foundation Model]] and AI-powered products.
- **Scale** — The organisation employs several thousand researchers and engineers across London (HQ), Mountain View, New York, Paris, Tel Aviv, and other cities.
- **Mission** — Formally expressed as "solving intelligence, and then using that to solve everything else," with an explicit commitment to [[AI Safety Research]] as a co-equal research pillar alongside capability development.
- **Relationship to Google** — Products and capabilities are integrated into Google Search, Google Cloud Vertex AI, Gmail, Google Workspace, YouTube, and Waymo, giving research direct commercial expression.

### Key Milestones & Systems

- **AlphaGo (2016)** — First AI to defeat a world champion Go player, demonstrating the power of combining [[Deep Learning]] with [[Monte Carlo Tree Search]] and [[Reinforcement Learning]].
- **DQN (2013–2015)** — Deep Q-Network that learned Atari games from raw pixels, launching the modern era of deep [[Reinforcement Learning]].
- **AlphaZero (2017)** — Achieved superhuman performance in chess, shogi, and Go through pure [[Self-Play Reinforcement Learning]] without human game data.
- **AlphaStar (2019)** — Reached Grandmaster level in StarCraft II, advancing [[Multi-Agent Systems]] and long-horizon planning research.
- **MuZero (2020)** — Extended AlphaZero to environments without known rules using [[Model-Based Reinforcement Learning]].
- **[[AlphaFold]] 2 (2020)** — Predicted protein three-dimensional structure from amino acid sequence with near-experimental accuracy, achieving a breakthrough in [[Computational Biology]] and [[Drug Discovery]] that earned Demis Hassabis the 2024 Nobel Prize in Chemistry.
- **AlphaFold 3 (2024)** — Extended predictions to DNA, RNA, and small molecules, further expanding the scope of [[Protein Structure Prediction]].
- **[[Gemini Multimodal Language Model]] (2023–2025)** — A family of natively multimodal [[Large Language Model]] (Gemini Ultra, Pro, Flash, Nano) integrated into Google products, competing with GPT-4 and [[Anthropic]] Claude models.
- **AlphaCode (2022) / AlphaCode 2 (2023)** — Code generation systems demonstrating competitive-programming-level performance, contributing to [[AI-Assisted Software Engineering]].
- **Lyria (2023)** — A generative music model, extending DeepMind's reach into creative [[Generative AI]].
- **Veo (2024)** — A video generation model integrating [[Diffusion Models]] and temporal reasoning.
- **GraphCast (2023)** — A [[Graph Neural Network]]-based weather forecasting system outperforming traditional numerical models, advancing [[Climate Modelling]].

### Research Themes

- **Reinforcement Learning** — Foundational contributions to [[Policy Gradient Methods]], [[Actor-Critic Methods]], [[Distributional RL]], and [[Offline Reinforcement Learning]] including R2D2, IMPALA, and Agent57.
- **Foundation Models** — Large-scale pretraining research spanning language, vision, and multimodal modalities, including PaLM (with Google Research), Chinchilla scaling laws, and [[Gemini Multimodal Language Model]].
- **AI Safety & Alignment** — Research into [[Reward Modelling]], [[Scalable Oversight]], specification gaming avoidance, and [[Interpretability]] of neural networks, pursued in a dedicated safety team.
- **Scientific AI** — Applying machine learning to [[Genomics]], structural biology, climate science, and [[Drug Discovery]], positioning AI as an accelerant for the natural sciences.
- **Robotics** — Research into [[Robotic Manipulation]] and embodied agents, including RT-2 and contributions to the broader [[Robotics]] research community.
- **Neuroscience-inspired AI** — Ongoing investigation of [[Neuroscience]]-inspired learning rules, memory systems, and cognitive architectures as guides for next-generation AI development.

### Applications

- **Healthcare** — Partnerships with NHS trusts for medical imaging (retinal disease detection, mammography), [[Genomics]] variant calling, and clinical note summarisation.
- **Drug Discovery** — [[AlphaFold]] databases used by millions of researchers; direct collaboration with pharmaceutical companies to identify drug targets.
- **Scientific Research** — AlphaFold Protein Structure Database (200 million+ structures) freely available; GraphCast weather forecasts publicly accessible.
- **Google Products** — Gemini models power Google Assistant, Google Search AI Overviews, Google Workspace "Help me write," and Google Cloud Vertex AI endpoints.
- **Climate & Energy** — DeepMind's work on data-centre cooling optimisation reduced Google's cooling energy usage; climate modelling research via GraphCast and related systems.
- **Code Generation** — AlphaCode and successors support software engineers; integrated via Google's internal coding assistants and Gemini Code Assist.
- **Creative Tools** — Lyria underpins YouTube Dream Track and MusicFX, and Veo feeds into Google's video creation offerings.

### Governance & Ethics

- Google DeepMind operates under Alphabet's corporate governance and is subject to [[AI Governance]] frameworks including the EU AI Act and applicable national regulations.
- The organisation published a set of AI Principles (inherited from Google's 2018 AI Principles) committing to responsible development and refusing to pursue certain applications (autonomous weapons, mass surveillance).
- Internally, a dedicated [[AI Safety Research]] team publishes on [[Reward Hacking]], [[Specification Gaming]], [[Interpretability]], and long-term risk from advanced AI systems.
- Demis Hassabis has publicly stated that [[Artificial General Intelligence]] may be achievable within a decade, which drives the organisation's concurrent investment in safety infrastructure.
- DeepMind was a signatory of the 2023 Frontier AI Safety Commitments made at Bletchley Park, pledging to share safety information with governments prior to deploying frontier models.
- The organisation participates in [[AI Governance]] initiatives including the AI Safety Institute (UK) and contributes to standards discussions at ISO and IEEE.

### Standards & Context

- **Chinchilla Scaling Laws** — DeepMind's 2022 paper established compute-optimal training recipes that influenced [[Large Language Model]] training across the industry.
- **Model Cards & Safety Evaluations** — Gemini model releases include detailed model cards, red-team evaluations, and responsible deployment documentation.
- **Open Science** — AlphaFold model weights and the Protein Structure Database are publicly released under open licences; some RL codebases (e.g., Acme, TRFL) are open-sourced.
- **Regulatory Engagement** — Actively engaged with the UK Information Commissioner's Office, the EU AI Office, and equivalent bodies for compliance with [[AI Governance]] obligations.
- **Publication Norms** — Publishes in Nature, Science, NeurIPS, ICML, ICLR, and other top venues, maintaining academic research norms despite commercial pressures.

### Provenance

