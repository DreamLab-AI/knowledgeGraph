Live Streaming is the real-time delivery of audio and video over a network as the content is captured, allowing audiences to view events with minimal delay rather than after recording. It relies on continuous encoding, packetisation, and adaptive distribution through content delivery networks to reach large, geographically dispersed audiences. Live streaming trades the buffering headroom of on-demand playback for low end-to-end latency, demanding careful management of bitrate adaptation, jitter, and edge caching.

### Overview

- Live Streaming powers broadcasts, gaming, conferencing, and interactive media where immediacy is essential. A capture source feeds a continuous encoder that segments the stream for adaptive-bitrate delivery, after which a [[Content Delivery Network]] fans the content out to edge nodes close to viewers. Reducing glass-to-glass latency while preserving resilience under bandwidth fluctuation is the central engineering challenge, distinguishing it from on-demand [[Video Streaming]].

### Key aspects

- Continuous real-time encoding and segmentation of source media.
- Adaptive-bitrate distribution to handle heterogeneous [[Bandwidth]].
- Low-latency protocols balancing immediacy against buffering safety.
- Edge caching and [[Content Delivery Network]] fan-out for scale.
- Interactivity layers such as chat and synchronised events.

### Applications

- Sports and concert broadcasting to global audiences.
- Game streaming and esports platforms.
- Live commerce and interactive shopping events.
- Webinars and real-time corporate communications.

### Provenance

