
A delegation scope defines the semantic boundaries of delegated authority, including capability constraints, intent framing and operational limits.[^1]

The class is declared in the delegation module and is reached from an [[Agent Delegation]] through the property `delegationScope`. Its properties carry the limits. `allowedCapability` lists the capabilities the delegate is authorised to perform, with an [[Agent Capability]] as range. `intentConstraint` names the [[Agent Intent]] under which the delegate may operate. `validFrom` and `validUntil` bound the scope in time, and `executionConstraint` points to an [[Execution Constraint]].

The core module introduces the property `delegationScope` for the same relation.[^2] visionGraph places the concept under [[Least Privilege]], since the scope states what a delegate may do and nothing wider.

[^1]: Semantic Agent Communication Community Group, “Delegation Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/delegation.ttl
[^2]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl

