Networking is the discipline and practice of connecting computing devices so they can exchange data through shared communication channels and protocols. It encompasses the hardware, addressing, routing and protocol layers that move packets reliably between hosts across local and wide-area networks. Networking provides the connective substrate on which the internet, cloud services and distributed systems are built.

### Overview

- Networking is situated within the [[Infrastructure]] area of the infrastructure domain.
- It connects a number of established concepts in the knowledge graph, anchoring edges that previously referenced it without a defining page.

### Key aspects

- Network Protocol (hasPart)
- Internet Protocol (hasPart)
- Firewall (hasPart)
- Infrastructure (partOf)
- TCP/IP (uses)

### Mechanisms

- Operates through its relationships with [[Infrastructure]] and [[Network Protocol]].
- Provides capabilities consumed by dependent and enabled classes listed under Relationships.

### Applications

- Supports [[Distributed Systems]]
- Supports [[Cloud Computing]]
- Supports [[Real-Time Communication]]
- Supports [[Interoperability]]

### Provenance

