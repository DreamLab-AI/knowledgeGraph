Product information management (PIM) is the business process, and the system that supports it, for managing the information a company needs to sell its products.[^1][^2]

Jorij Abraham's book introduction says that as companies sell online they are confronted with the fact that not all information necessary to sell their products is available, and that, where marketing, sales and finance have long been core processes, PIM is a new business process with its own unique implementation and management challenges.[^1] The book describes the core PIM processes and their strategic, tactical and operational benefits and implementation challenges.[^1]

## In practice

An open-access study in Logistics, based on two distribution and retail companies, describes a PIM system as one that “utilises product master data obtained from the HOST to establish connections between products and points of sale”, while the eCommerce department imports and enhances them with the attributes needed for the web shop.[^2] The study finds that the quality of product master data has a significant impact on the performance of logistics processes.[^2]

## Scope and distinctions

PIM draws on product master data, covered at [[Supply Chain Master Data]], and the data may be shared with trading partners; GS1 describes its data synchronisation network as a way to share master product information by subscribing to a certified data pool.[^3] See [[Global Trade Item Number]].

## What the sources do not establish

Evidence is thin. The sources are a book introduction and one study of two companies, and neither gives a standard definition or a list of PIM functions. They do not compare PIM systems with master data management systems, and they do not describe the data model a PIM system uses.[^1][^2][^3]

[^1]: Jorij Abraham, Product Information Management: Theory and Practice, Springer, 2014 (SpringerLink introduction, Internet Archive copy). https://web.archive.org/web/2024/https://link.springer.com/book/10.1007/978-3-319-04885-7
[^2]: Impact of the Product Master Data Quality on the Logistics Process Performance, Logistics 8(2), 43, MDPI (Internet Archive copy). https://web.archive.org/web/2024/https://www.mdpi.com/2305-6290/8/2/43
[^3]: GS1, “GS1 Global Data Synchronisation Network (GS1 GDSN) - Services”. https://www.gs1.org/services/gdsn

