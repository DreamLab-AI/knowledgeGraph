A freight carrier is a person or business organisation that provides transportation services and operates the transport of goods. The Industrial Ontologies Foundry defines a carrier as a “person or business organization who provides transportation services”, with trucking companies and airlines as examples.[^1]

## Definitions in the sources

The IOF ontology records three wordings for the term: a company that provides air, sea or land transportation services (APICS), a firm that transports goods or people via land, sea or air (CSCMP), and, from GS1, the party that provides freight transportation services or a physical or electronic mechanism that carries business information.[^1] The first two are close; the GS1 wording is wider because it extends to non-physical carriage of information, and this vault uses the transport sense only.[^1]

United States statutes define carriers by mode and by legal status. The statute on interstate transportation says that “carrier” means a motor carrier, a water carrier and a freight forwarder.[^2] For maritime trades the Federal Maritime Commission describes a vessel-operating common carrier as one that holds itself out to the general public to carry cargo for compensation between the United States and a foreign country, assumes responsibility for the transportation from the port or point of receipt to the port or point of destination, and operates a vessel for all or part of it.[^3]

## Scope and distinctions

Carriers are kinds of [[Logistics Service Provider]]. Two kinds have their own pages: the [[Ocean Carrier]] and the [[Parcel Carrier]]. A carrier differs from a [[Freight Forwarder]], which arranges carriage on behalf of a shipper, although the US statute above counts forwarders as carriers for its purposes, and FedEx, UPS and DHL are given by the IOF as examples of businesses that combine transportation with freight forwarding.[^1][^2] For vehicle operations see also [[Fleet Management]].

## What the sources do not establish

Sources opened here do not list the modes of freight carriage in a single taxonomy or give the number of carriers by mode. The legal definitions are those of one country, and the IOF definitions come from one ontology that quotes trade glossaries. No source opened here compares carrier definitions between countries.

[^1]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^2]: Cornell Law School Legal Information Institute, “49 U.S. Code § 13102 - Definitions”. https://www.law.cornell.edu/uscode/text/49/13102
[^3]: US Federal Maritime Commission, “Vessel-Operating Common Carriers”. https://www.fmc.gov/resources-services/vessel-operating-common-carriers/

