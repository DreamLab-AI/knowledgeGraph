Kaizen is a Japanese word that means continuous improvement, and in production it names the practice of making small, incremental improvements in processes and systems that lead to significant long-term benefits.[^1]

The Lean Enterprise Institute says the kaizen process is based on plan-do-check-act cycles, and that the kaizen philosophy was first introduced to the world by Masaaki Imai in 1986.[^1] Toyota says all of its employees implement daily incremental kaizen within the Toyota Production System.[^2] A review of operations and supply chain management describes Toyota's production system as incorporating principles of human behaviour such as respect for people and continuous improvement, naming Kaizen.[^4]

## Relationship to standardised work

The Institute quotes Taiichi Ohno as saying there can be no kaizen without a standard, and says management must first establish a stable operating condition before engaging in continuous improvement.[^1] Toyota's page links kaizen to waste: its account of jidoka says the work should first be done by hand, implementing kaizen to eliminate waste, inconsistencies and unreasonable requirements, and calls the implementation of kaizen on work the bedrock of jidoka.[^2]

## Scope and distinctions

Kaizen is filed under [[Lean Production]]. A US government page notes that some organisations integrate their kaizen processes, which it describes as rapid continual improvement, with Six Sigma approaches; see [[Six Sigma]].[^3] The general idea of ongoing improvement also appears in [[Total Quality Management]].

## What the sources do not establish

None of the sources measures the effect of kaizen. The date and attribution for the word's introduction rest on the Institute alone. The review mentions kaizen in a single sentence about Toyota and the sources do not distinguish continuous improvement from the Japanese term in other settings.[^4]

[^1]: Lean Enterprise Institute, “Kaizen — A Resource Guide”. https://www.lean.org/lexicon-terms/kaizen/
[^2]: Toyota Motor Corporation, “Toyota Production System”. https://global.toyota/en/company/vision-and-philosophy/production-system/
[^3]: US Environmental Protection Agency, “Lean Thinking and Methods - Six Sigma”. https://www.epa.gov/sustainability/lean-thinking-and-methods-six-sigma
[^4]: Fotios Petropoulos and colleagues, arXiv:2503.05749v2 (2025), “Operations & Supply Chain Management: Principles and Practice”. https://arxiv.org/pdf/2503.05749

