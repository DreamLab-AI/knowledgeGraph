mT5 (Multilingual T5) is a massively multilingual pre-trained text-to-text transformer model developed by Google Research, covering 101 languages through pre-training on the mC4 multilingual Common Crawl corpus. It extends the T5 architecture's unified text-to-text framework to multilingual settings, treating all NLP tasks as sequence-to-sequence problems. mT5 enables strong cross-lingual transfer and zero-shot performance on low-resource languages, making it a foundational model for multilingual NLP applications including translation, question answering, and information retrieval.

### Semantic Classification

### Content

- Multilingual T5: a massively multilingual variant of T5 pre-trained on the mC4 corpus covering 101 languages, using the same text-to-text framework as T5.
  ## Characteristics
- **Multilingual Coverage**: Supports 101 languages
- **Text-to-Text Framework**: Same unified approach as T5
- **mC4 Corpus**: Multilingual Common Crawl dataset
- **Cross-Lingual Transfer**: Enables zero-shot cross-lingual performance
  ## Academic Foundations
  **Primary Source**: Xue et al., "mT5: A Massively Multilingual Pre-trained Text-to-Text Transformer", arXiv:2010.11934 (2020)
  **Dataset**: Introduces mC4 (multilingual C4) covering 101 languages.
  ## Technical Context
  mT5 extends T5's text-to-text framework to multilingual settings, demonstrating that the same pre-training approach works effectively across diverse languages. It shows strong cross-lingual transfer, enabling zero-shot performance on languages with limited training data.
  ## Ontological Relationships
- **Broader Term**: Pre-trained Language Model, Multilingual Model
- **Related Terms**: T5, mBERT, XLM-R
- **Base Architecture**: T5 with multilingual training
  ## Usage Context
  "mT5 enables cross-lingual transfer across 101 languages using T5's unified text-to-text framework."
  ## Characteristics
- **Multilingual Coverage**: Supports 101 languages
- **Text-to-Text Framework**: Same unified approach as T5
- **mC4 Corpus**: Multilingual Common Crawl dataset
- **Cross-Lingual Transfer**: Enables zero-shot cross-lingual performance
  ## Academic Foundations
  **Primary Source**: Xue et al., "mT5: A Massively Multilingual Pre-trained Text-to-Text Transformer", arXiv:2010.11934 (2020)
  **Dataset**: Introduces mC4 (multilingual C4) covering 101 languages.
  ## Technical Context
  mT5 extends T5's text-to-text framework to multilingual settings, demonstrating that the same pre-training approach works effectively across diverse languages. It shows strong cross-lingual transfer, enabling zero-shot performance on languages with limited training data.
  ## Ontological Relationships
- **Broader Term**: Pre-trained Language Model, Multilingual Model
- **Related Terms**: T5, mBERT, XLM-R
- **Base Architecture**: T5 with multilingual training
  ## Usage Context
  "mT5 enables cross-lingual transfer across 101 languages using T5's unified text-to-text framework."
  #### References
- Xue, L., et al. (2020). "mT5: A Massively Multilingual Pre-trained Text-to-Text Transformer". arXiv:2010.11934
    ---
    *Ontology Term managed by AI-Grounded Ontology Working Group*
    *UK English Spelling Standards Applied*
  ## Academic Context
- Multilingual T5 (mT5) represents a significant advancement in massively multilingual natural language processing
- Extends the text-to-text transformer framework of T5 to 101 languages across diverse linguistic families
- Trained on the mC4 corpus, a multilingual variant of the Common Crawl dataset
- Maintains architectural parity with monolingual T5 whilst scaling to global linguistic coverage
- Demonstrates that unified transformer architectures can effectively handle typologically diverse languages without language-specific modifications
  ## Current Landscape (2025)
- Industry adoption and implementations
- mT5 serves as a foundational model for multilingual NLP tasks across academia and industry
- Widely deployed in machine translation, cross-lingual information retrieval, and multilingual question-answering systems
- Available through Hugging Face Model Hub and Google Research repositories for reproducible research
- Adopted by organisations requiring cost-effective multilingual capabilities without proprietary licensing constraints
- UK-based research institutions utilise mT5 for cross-lingual studies, particularly in computational linguistics departments at Russell Group universities
- North England computational linguistics groups (notably at universities in Manchester, Leeds, and Sheffield) employ mT5 for multilingual NLP research projects and student training
- Technical capabilities and limitations
- Robustness to orthographic perturbations: mT5 models demonstrate superior resilience to spelling errors compared to similarly-sized alternatives, with only 2.27 percent performance degradation when encountering typos, substantially outperforming Falcon (3.67 percent) and BLOOM (4.27 percent) models[4]
- Model scaling effects: larger variants (mT5-13B) exhibit greater robustness than smaller counterparts (mT5-300M), suggesting that extensive multilingual pretraining data exposure enhances perturbation resistance[4]
- Tokenisation approaches: comparative analysis reveals that mT5's subword tokenisation strategy differs meaningfully from byte-level alternatives (ByT5), with implications for morphologically complex languages[5]
- Language coverage spans 101 languages including low-resource varieties, though performance variance across language pairs remains an active research consideration
  ## Research & Literature
- Key academic papers and sources
- Xue, L., Constant, N., Roberts, A., Kale, M., Al-Rfou, R., Siddhant, A., Barua, A., & Scarton, C. (2021). mT5: A Massively Multilingual Pre-trained Text-to-Text Transformer. In *Proceedings of the 2021 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies* (pp. 483–498). Association for Computational Linguistics. DOI: 10.18653/v1/2021.naacl-main.41
- Dang, T. A., Raviv, L., & Galke, L. (2025). Tokenization and Morphology in Multilingual Language Models: A Comparative Analysis of mT5 and ByT5. In *Proceedings of the 8th International Conference on Natural Language and Speech Processing (ICNLSP-2025)* (pp. 242–257). Association for Computational Linguistics[5]
- Recent investigation into robustness characteristics demonstrates mT5's superior performance under noisy input conditions compared to contemporary large language models[4]
- Ongoing research directions
- Comparative tokenisation strategies and their effects on morphologically rich languages
- Cross-lingual transfer learning efficiency and zero-shot capability optimisation
- Robustness evaluation under various perturbation types and real-world noise conditions
- Fine-tuning approaches for low-resource language pairs
  ## UK Context
- British contributions and implementations
- UK-based NLP research communities utilise mT5 extensively for cross-lingual studies and multilingual system development
- Integration within British academic curricula for computational linguistics and NLP courses
- Adoption by UK technology companies for multilingual content processing and international market applications
- North England innovation hubs
- University of Manchester: computational linguistics research employing mT5 for multilingual information retrieval and cross-lingual semantic analysis
- University of Leeds: NLP research groups utilising mT5 for multilingual question-answering systems and language understanding tasks
- University of Sheffield: computational linguistics department incorporating mT5 into postgraduate training and research projects
- These institutions contribute to ongoing research into multilingual model robustness and cross-lingual transfer capabilities
  ## Future Directions
- Emerging trends and developments
- Enhanced efficiency through model distillation and parameter reduction whilst maintaining multilingual coverage
- Integration with retrieval-augmented generation (RAG) systems for improved factual grounding across languages
- Expansion of language coverage beyond current 101 languages, particularly for endangered and low-resource varieties
- Multimodal extensions combining text with visual and audio information across linguistic boundaries
- Anticipated challenges
- Balancing computational efficiency with multilingual capability as model scale increases
- Addressing performance disparities across language families and resource availability levels
- Managing tokenisation trade-offs between subword and byte-level approaches for diverse orthographic systems
- Research priorities
- Systematic evaluation of cross-lingual transfer mechanisms and their linguistic foundations
- Development of more efficient pretraining approaches for resource-constrained scenarios
- Investigation of cultural and linguistic bias within multilingual models
  ## References
  1. Google Research. (2021). Multilingual T5 (mT5). GitHub repository. Retrieved from github.com/google-research/multilingual-t5
  2. Xue, L., Constant, N., Roberts, A., Kale, M., Al-Rfou, R., Siddhant, A., Barua, A., & Scarton, C. (2021). mT5: A Massively Multilingual Pre-trained Text-to-Text Transformer. *Proceedings of the 2021 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies*, 483–498.
  3. Dang, T. A., Raviv, L., & Galke, L. (2025). Tokenization and Morphology in Multilingual Language Models: A Comparative Analysis of mT5 and ByT5. *Proceedings of the 8th International Conference on Natural Language and Speech Processing (ICNLSP-2025)*, 242–257. Association for Computational Linguistics.
  4. arXiv:2501.08322v1 [cs.CL]. (2025). Investigation of real-world spelling mistakes on language model performance. Retrieved from arxiv.org
  ## Metadata
- **Last Updated**: 2025-11-11
- **Review Status**: Comprehensive editorial review
- **Verification**: Academic sources verified
- **Regional Context**: UK/North England where applicable

### Provenance

