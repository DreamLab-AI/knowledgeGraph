Robin Hanson is an economist, futurist, and author (George Mason University) known for contrarian analysis of AI progress timelines, the economics of prediction markets, and his book Age of Em which models a future dominated by brain emulations. He maintains a measured scepticism about near-term AGI, arguing that inertia, demographic decline, and adoption barriers make transformative AI further off than mainstream discourse suggests. His blog Overcoming Bias applies economic and evolutionary reasoning to cognition, signalling, and technology adoption.

### Semantic Classification

### Content

- automatically published
- AI, the Economy, and the Future of Work:
- Robin Hanson, economist, author, and a leading voice on futurism, is a famous naysayer about the medium term potential of AI and automation. While he does believe in AI that is capable of replacing and exceeding human capability, he is stanchly of the opinion that it's not generalisable in the short term and that humanity is heading for significant slowdown and fallback due to demographics.
- This scans with my feeling that in the main people are NOT adopting these AI tools en masse because of habits and simply intertie.
- He offers thought-provoking perspectives on the potential impact of Artificial Intelligence on society and the economy, With a focus on his book Age of Em and the blog "Overcoming Bias," Hanson's insights challenge conventional narratives about AI and its applications, but I wonder how much his research is simply convoluted with the slump in innovation due to the [[Lead Poisoning Hypothesis]].

<iframe src="https://www.overcomingbias.com/" style="width: 100%; height: 600px"></iframe>

- Hanson's Measured Approach to AI Progress
- Despite the excitement surrounding recent AI advancements, including those of Google's Gemini 1.5, Hanson expresses a measure of skepticism about the imminent arrival of transformative AI (often termed Artificial General Intelligence or AGI). He observes a historical pattern of overestimating the immediate impact of new AI paradigms, highlighting the importance of a long-term and factual approach to assessing AI progress.
- Hanson emphasizes that the question of AI feasibility is a separate one from AI integration and adoption. He cites his son's software firm's experiences with language models, illustrating the challenges of adapting human workflows to effectively leverage AI tools. This underscores the gap between AI potential and the behavioural changes needed for its successful deployment.
- The talks about "rot" as potentially evergreen problem (also see [How complex systems fail](https://www.researchgate.net/publication/228797158_How_complex_systems_fail))
- The Growth Trajectory
- Hanson does envision a future where AI plays a pivotal role in driving economic growth, potentially mitigating the challenges of population decline. He believes AI could take over many human jobs, supporting economic expansion even in the face of demographic shifts. Hanson's book Age of Em further explores this idea, contemplating a future where brain emulations enhance human labour and reshape economic systems. He sees it as between 60 and 90 years away.
- Economic Disruptions and Adaptations
- The discussion of AI naturally leads to its economic implications, both for individual businesses and society as a whole. Hanson stresses the need to understand broader economic shifts when predicting how the labor market might change in response to AI. While acknowledging the potential for disruption, Hanson believes the process will likely be incremental, with a need for continuous adaptation by individuals and organizations.
- Insights Grounded in Perspectives
- At the heart of these discussions lies Hanson's calculated timeline of 60 to 90 years for achieving full, human-level AI. This timeframe, however, is not merely a guess; it reflects Hanson's ongoing analysis of AI progress and challenges. The ongoing advancement of powerful AI models like Gemini 1.5 prompts continuous reevaluation of how AI development might reshape our understanding of AI timelines and societal impact.
- Hanson's insights extend beyond core AI development into areas where AI's influence may reshape our world. Here are a few key aspects of the wide-ranging discussion:
- AI's Uncertain Timeline: Hanson acknowledges how breakthroughs in AI research could disrupt his forecasts but remains cautious about the rapid attainment of AGI.
- The Innovation Pause: Hanson suggests a possible pause in innovation due to demographic shifts, potentially influencing the timeline of AI development. Regulation and Adaptation: The integration of AI technologies into domains such as medicine raises legal and regulatory hurdles, which will need to be addressed alongside societal acceptance.

### Provenance

