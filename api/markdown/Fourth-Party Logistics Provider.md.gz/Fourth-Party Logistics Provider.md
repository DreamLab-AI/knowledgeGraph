A fourth-party logistics provider (4PL), also called a lead logistics provider (LLP), is usually described as an integrator that coordinates the other logistics providers serving a client. Maersk describes a traditional 4PL provider as an orchestrator that oversees all transport management, taking ownership of the coordination and management of a variety of 2PL and 3PL players in an end-to-end logistics offering, as well as coordinating the vendors.[^1]

## Competing descriptions

No agreed definition of the term exists. Maersk states that there is “no unified, industry standard definition” of 3PL, 4PL and similar models, and quotes Gartner as saying that even those within the industry who understand the 4PL concept struggle to define what services a 4PL provides and how it differs from a 3PL.[^1] A trade article in Logistics Management reports that if ten logistics professionals were asked to define the difference between a 3PL and a 4PL, one would probably get ten different answers.[^2]

In that article, consultant Clifford Lynch of C. F. Lynch & Associates calls a fourth party a non-asset business process outsourcing provider, which may or may not be a consultant, often contracts out the services it provides, and is mode neutral.[^2] Evan Armstrong of Armstrong & Associates prefers the term “lead logistics provider” for the value-added function that has recently been tossed into the 4PL bucket, and his colleague Richard Armstrong is quoted as saying that Anderson Consulting is credited with creating the expression 4PL.[^2] That attribution is his claim and no other opened source confirms it.[^2]

The Industrial Ontologies Foundry lists 4PL and LLP alongside 3PL among the businesses typically referred to by the logistics service provider role, without defining either separately.[^3]

## Scope and distinctions

A 4PL is a kind of [[Logistics Service Provider]] in this vault, distinct from the asset-based or service-executing [[Third-Party Logistics Provider]]. See also [[Supply Chain Control Tower]].

## What the sources do not establish

Evidence is thin and entirely practitioner material: one carrier's article and one trade-press article, with the IOF note as a third, indirect witness. No standards body, public agency or peer-reviewed source defining 4PL was opened. The sources do not agree on whether a 4PL may own assets: Lynch describes a non-asset provider, while another interviewee in the same article, Van Boven, allows that a 4PL could also be a 3PL with its own network provided it is mode neutral.[^2][^1]

[^1]: Maersk, “The difference between 3PL vs 4PL”. https://maersk.com/insights/growth/2023/09/26/3pl-vs-4pl
[^2]: Logistics Management (republished by Supply Chain 24/7), “Global Logistics: Demystifying the 4PL”. https://www.supplychain247.com/article/global_logistics_demystifying_the_4pl/
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf

