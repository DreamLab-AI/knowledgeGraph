
An agent interface specification is a declaration of an interface through which an agent integrates with its surrounding system, declared as `InterfaceSpec` in the agent module of the Agent Ontology.[^1] The Agent Ontology declares the class without a definition; this one follows from its use. visionGraph places it under [[Specification]] and relates it to [[Interface]].

An [[Agent System Integration]] relates to its interface specifications through `interface`. The specification names what the agent exposes or consumes at the operating-system level, for example a protocol, an endpoint or a message format, so that other components can connect without reading the agent's code.

The class is the declaration, not the interface itself: it stands for the documented contract, while the running interface is an implementation of it. It scopes to what an agent depends on and exposes at system level, which is narrower than an [[Agent Contract]], whose terms concern obligations between parties.

[^1]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

