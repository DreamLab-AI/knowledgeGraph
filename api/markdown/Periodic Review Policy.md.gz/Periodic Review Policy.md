A periodic review policy checks the inventory position at fixed intervals and, at each review, places an order to bring the position up to a target level.[^1][^2]

A Penn State teaching note describes a periodic review system as one that reviews the inventory position at fixed intervals T to place orders that will increase it to a predetermined base-stock or order-up-to level. The order quantity is therefore not fixed: the system orders the quantity that will return the inventory position to the base-stock level.[^1] An open operations text calls the method periodic review, or fixed order interval, and says the level is checked at the end of each fixed interval and, if inventory is below a maximum level, the difference is ordered.[^2]

## Forms

MIT slides write periodic review as the case where the review period R is greater than zero. The order-up-to-level policy (R, S) orders S minus the inventory position every R periods; the hybrid (R, s, S) policy orders only when the position is at or below s, and otherwise does not order.[^3] See [[Base Stock Policy]].

## Trade-offs

The Penn State note says the out-of-stock exposure period includes both the lead time and the review period, so more safety inventory is required to meet the same availability target than in a continuous review system, while periodic replenishment makes it easier to consolidate orders across items and reduce shipping cost.[^1] See [[Safety Stock]].

## Scope and distinctions

Its contrast is [[Continuous Review Policy]]. Both are review types within an [[Inventory Policy]].

## What the sources do not establish

Sources use T and R for the review period, and S, OUL and the base stock level for the target. They give no figures for the cost of extra safety stock under periodic review.

[^1]: J. E. Tyworth, Penn State Smeal College of Business SCM 810 technical note, February 2014, “Basic Multi-period Inventory Systems”. https://courses.smeal.psu.edu/SCM810/scm_810_module_3/Multi%20Period%20Inventory%20Systems%20Teaching%20Note.pdf
[^2]: Business LibreTexts (Introduction to Operations Management, NWTC), “9.2: Inventory Management Models”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/09%3A_Inventory_Management/9.02%3A_Inventory_Management_Models
[^3]: Chris Caplice, MIT OpenCourseWare ESD.260 Logistics Systems, October 2006, “Inventory Management: Probabilistic Demand”. https://ocw.mit.edu/courses/esd-260j-logistics-systems-fall-2006/8b53c45fd26ffff706d815131e8d177e_lect11.pdf

