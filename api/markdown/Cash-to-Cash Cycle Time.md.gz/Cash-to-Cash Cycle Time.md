Cash-to-cash cycle time (C2C) is the number of days between paying suppliers and collecting from customers, calculated as days of inventory plus days of receivables minus days of payables.[^1]

Hutchison, Farris and Adhikari take three balance sheet variables, inventory, accounts receivable and accounts payable, and convert them to days using the income statement items revenues and cost of goods sold.[^1] They call the three resulting measures the inventory conversion period, the receivables conversion period and the payables deferral period.[^1] The first is the average number of days a firm holds its inventory before selling it, the second the average number of days it takes to collect a receivable once stock has been sold on credit, and the third the average number of days it takes to pay its accounts payable to a supplier.[^1]

## Reading the figure

A positive number indicates, on average, how many days a firm's capital is unavailable while it awaits payment from a customer, and a negative number indicates how many days it received cash from sales before payment is required to suppliers.[^1] The authors treat cash cycle, cash conversion cycle and net trade cycle as synonyms and prefer the name C2C.[^1] See [[Inventory Turnover]].

## In supply chain measurement

SCOR 12.0 lists Cash-to-Cash Cycle Time as a level-1 asset management metric, with Days Sales Outstanding, Inventory Days of Supply and Days Payable Outstanding as related metrics below it.[^3] An abstract by Farris, Staberhofer and Losbichler says that firms seeking supply chain improvements must develop metrics between firms, and presents C2C as a way to do so.[^2] The 2018 authors expect C2C to keep a dominant role in business operations as supply chain finance grows in popularity.[^1] See [[Supply Chain Finance]] and [[Supply Chain Performance Measure]].

## What the sources do not establish

This page states no benchmark values, since none were excerpted from the sources opened. The original 2002 article by Farris and Hutchison was not accessible beyond an abstract listing, and the SCOR entries are metric names without formulae.[^1][^2][^3]

[^1]: Paul D. Hutchison, M. Theodore Farris II and Subash Adhikari, Southwest Business and Economics Journal, 2018, “Managing C2C to Increase Company Profitability”. https://www.cameron.edu/storage/departments/business/Journals/Vol_25_-_Managing_C2C_to_Increase.pdf
[^2]: Theodore M. Farris, Franz Staberhofer and Heimo Losbichler, “Managing the Supply Chain Using the Cash-to-Cash Metric” (University of Applied Sciences Upper Austria record, abstract only). https://pure.fh-ooe.at/en/publications/managing-the-supply-chain-using-the-cash-to-cash-metric/
[^3]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf

