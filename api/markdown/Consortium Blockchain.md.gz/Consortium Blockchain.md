Consortium Blockchain is a permissioned distributed ledger architecture in which a pre-approved set of legally distinct organisations jointly operates the validator infrastructure, governs the protocol rules, and controls the read/write access matrix — occupying a deliberate middle position in th...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:MembershipServiceProvider))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ChannelsAndPrivateDataCollections))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:OrderingService))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:EndorsementPolicy))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:CertificateAuthority))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:NotaryService))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ValidatorNode))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:hasPart blockchain:ChaincodeContainer))

    ## Dependency Relationships
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:requires blockchain:ByzantineFaultTolerance))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:requires blockchain:PublicKeyInfrastructure))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:requires blockchain:MultiPartyGovernance))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:requires blockchain:IdentityManagementSystem))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:requires blockchain:SmartContractPlatform))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:ThresholdCryptography))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:X509Certificate))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:ConsortiumGovernanceFramework))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:dependsOn blockchain:LegalAgreement))

    ## Capability Relationships
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:enables blockchain:TokenisedDeposit))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:enables blockchain:TokenisedRealWorldAsset))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:enables blockchain:TradeFinanceDigitisation))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:enables blockchain:SupplyChainProvenance))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:enables blockchain:WholesaleCBDC))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:enables blockchain:SelectiveDisclosure))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:enables blockchain:AtomicDvPSettlement))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:supports blockchain:ProjectAgora))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:supports blockchain:ProjectMBridge))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:supports blockchain:EBSI))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:supports blockchain:Kinexys))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:supports blockchain:CitiTokenServices))

    ## Implementation Relationships
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:implements blockchain:PBFT))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:implements blockchain:IBFT))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:implements blockchain:QBFT))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:implements blockchain:RaftConsensus))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:implements blockchain:SmartBFT))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:implements blockchain:ProofOfAuthority))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:uses blockchain:HyperledgerFabric))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:uses blockchain:HyperledgerBesu))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:uses blockchain:R3Corda))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:uses blockchain:Quorum))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:uses blockchain:HyperledgerIroha))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:uses blockchain:AzureConfidentialConsortiumFramework))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:uses blockchain:HardwareSecurityModule))

    ## Reduction Relationships
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:reduces blockchain:ReconciliationOverhead))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:reduces blockchain:CounterpartyRisk))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:reduces blockchain:SettlementLatency))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:reduces blockchain:OperationalCost))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:reduces blockchain:DataAsymmetry))

    ## Association Relationships
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:Tokenisation))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:CBDC))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:SmartContract))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:BlockchainInteroperability))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:SelfSovereignIdentity))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:relatedTo blockchain:VerifiableCredentials))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:PublicBlockchain))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:PermissionlessBlockchain))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:PrivateBlockchain))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:TraditionalEDI))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:contrastsWith blockchain:SWIFTMessaging))

    ## Standardization Relationships
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:ISO22739))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:ISO23257))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:EnterpriseEthereumAlliance))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:HyperledgerFoundation))
    SubClassOf(blockchain:ConsortiumBlockchain
      ObjectSomeValuesFrom(blockchain:standardizedBy blockchain:EthTrustSecurityLevels))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(blockchain:hasIdentifier blockchain:ConsortiumBlockchain "BC-0432"^^xsd:string)
    DataPropertyAssertion(blockchain:authorityScore blockchain:ConsortiumBlockchain "0.87"^^xsd:decimal)
    DataPropertyAssertion(blockchain:typicalValidatorCount blockchain:ConsortiumBlockchain "10"^^xsd:integer)
    DataPropertyAssertion(blockchain:maxValidatorBFTPractical blockchain:ConsortiumBlockchain "21"^^xsd:integer)
    DataPropertyAssertion(blockchain:typicalFinalitySeconds blockchain:ConsortiumBlockchain "3"^^xsd:integer)
    DataPropertyAssertion(blockchain:typicalThroughputTPS blockchain:ConsortiumBlockchain "3500"^^xsd:integer)
    DataPropertyAssertion(blockchain:ibmFoodTrustParticipants blockchain:ConsortiumBlockchain "200"^^xsd:integer)
    DataPropertyAssertion(blockchain:kinexysDailyVolumeUSD blockchain:ConsortiumBlockchain "1000000000"^^xsd:integer)
    DataPropertyAssertion(blockchain:ebsiPartnerCountries blockchain:ConsortiumBlockchain "30"^^xsd:integer)
    DataPropertyAssertion(blockchain:mBridgeMVPYear blockchain:ConsortiumBlockchain "2024"^^xsd:integer)

    ## Property Constraints
    SubClassOf(blockchain:ConsortiumBlockchain
      DataMinCardinality(2 blockchain:hasMemberOrganisation xsd:string))
    SubClassOf(blockchain:ConsortiumBlockchain
      DataSomeValuesFrom(blockchain:consensusAlgorithm xsd:string))
    SubClassOf(blockchain:ConsortiumBlockchain
      DataAllValuesFrom(blockchain:isPermissioned xsd:boolean))
    SubClassOf(blockchain:ConsortiumBlockchain
      DataMinCardinality(1 blockchain:hasGovernanceCharter xsd:string))

    ## Annotations
    AnnotationAssertion(rdfs:label blockchain:ConsortiumBlockchain "Consortium Blockchain"@en)
    AnnotationAssertion(rdfs:comment blockchain:ConsortiumBlockchain "Permissioned distributed ledger architecture where a pre-approved set of legally distinct organisations jointly operates validator infrastructure and governs protocol rules under a hybrid trust model intermediate between public permissionless chains (Bitcoin, Ethereum) and single-organisation private ledgers; implemented via Hyperledger Fabric (Fabric 3.0 SmartBFT), Hyperledger Besu (IBFT 2.0, QBFT), R3 Corda (5.x multi-tenant), Quorum/GoQuorum (Consensys, JPM Onyx/Kinexys), Hyperledger Iroha (Soramitsu, Cambodia Bakong), Microsoft Azure Confidential Consortium Framework (TEE-based); production deployments include IBM Food Trust (200+ supply-chain participants), MediLedger (DSCSA pharma), Komgo (commodity finance), EBSI (EU government, 30 countries), Singapore TradeTrust, GLEIF vLEI, JPMorgan Kinexys ($1B+ daily), Citi Token Services, plus central-bank consortia BIS Project Agorá, Project mBridge (HKMA-PBoC-BoT-CBUAE-SAMA MVP 2024), Project Cedar, Project Mariana, Project Jasper, BoE Project Rosalind, Project Aber; significant consortium failures 2022-2023 include TradeLens (IBM-Maersk), Marco Polo Network, we.trade, B3i, Contour."@en)
    AnnotationAssertion(dcterms:identifier blockchain:ConsortiumBlockchain "BC-0432"^^xsd:string)
    AnnotationAssertion(dcterms:subject blockchain:ConsortiumBlockchain "Permissioned blockchain, enterprise DLT, multi-organisation governance, BFT consensus, tokenisation, wholesale CBDC, trade finance, supply chain"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(blockchain:requires)
  AsymmetricObjectProperty(blockchain:enables)
  AsymmetricObjectProperty(blockchain:implements)
  AsymmetricObjectProperty(blockchain:contrastsWith)
  TransitiveObjectProperty(blockchain:dependsOn)
  FunctionalDataProperty(blockchain:typicalFinalitySeconds)
  FunctionalDataProperty(blockchain:typicalThroughputTPS)

## About Consortium Blockchain

- **Consortium Blockchain** is the institutional answer to a structural mismatch between the architectural commitments of public permissionless blockchains and the operational realities of regulated multi-party business networks. Public chains assume an open validator set with anonymous participants, optimise for censorship resistance and credible neutrality, and expose all transaction data on a globally replicated ledger; regulated enterprise networks require known and contractually accountable counterparties, regulatory-compliant identity verification (KYC/CDD/AML), commercial confidentiality between competing members of a shared business network, and deterministic settlement finality reconcilable with traditional financial market infrastructure. Consortium blockchains resolve this tension by **permissioning every layer of the stack**: validators are admitted by governance vote of existing members; cryptographic identities are issued by member-operated certificate authorities under a hierarchical PKI rather than by anonymous self-attested keypairs; transaction visibility is partitioned via channels, private data collections, point-to-point messaging (Corda), or zero-knowledge proofs into selective-disclosure subsets; consensus reduces to a deterministic BFT protocol amongst a small known committee rather than to probabilistic economic finality amongst an open mining/staking population.
- The intellectual lineage extends much further back than the 2015 enterprise-blockchain narrative would suggest. **Practical Byzantine Fault Tolerance** (Castro and Liskov, OSDI 1999) established the cryptographic feasibility of asynchronous Byzantine consensus amongst a known committee with O(n²) message complexity tolerating f < n/3 faulty replicas — the theoretical bedrock under every modern consortium consensus algorithm. The Lampson, Lamport, and Schneider state-machine-replication tradition (1978-1990) provides the formal model of replicated deterministic computation that consortium chaincode/smart-contract execution instantiates. **Raft** (Ongaro and Ousterhout, USENIX ATC 2014) supplied the crash-fault-tolerant ordering primitive used by Hyperledger Fabric pre-3.0 alongside Apache Kafka. The conceptual breakthrough of 2015-2017 was the recognition that these classical distributed-systems primitives could be packaged with smart contracts, modular identity, and selective disclosure to produce a multi-party operational substrate that competitor organisations could meaningfully share — a recognition driven simultaneously by the **Linux Foundation Hyperledger Project** announcement (December 2015 with founding members including IBM, Cisco, Intel, J.P. Morgan, Wells Fargo, ANZ Bank, Accenture, Digital Asset, BNY Mellon), the **R3 consortium** (September 2015 with ~40 founding banks including Barclays, Credit Suisse, Goldman Sachs, J.P. Morgan, Morgan Stanley, RBS, UBS), the **Enterprise Ethereum Alliance** (February 2017), and the J.P. Morgan internal Quorum fork of Ethereum (October 2016).

### Core Trust Model and Distinguishing Properties

The defining property of a consortium blockchain — distinguishing it from both public chains and single-organisation private ledgers — is the **multi-organisation governance over a permissioned validator set under a hybrid public-private trust model**. Five sub-properties operationalise this definition:

**1. Known Validator Set**: Validators are explicitly enumerated organisations admitted by consortium governance, not anonymous keypairs participating via economic stake. Typical production consortia operate 4-21 validating organisations (the upper bound determined by PBFT/IBFT/QBFT consensus message-complexity practicality — beyond ~21 nodes the O(n²) message overhead degrades throughput sharply). Each validator's identity is bound to a corporate entity and enforceable legal agreement.

**2. Hierarchical PKI Identity**: Participants authenticate via X.509 certificates issued under a tree of certificate authorities — typically a consortium-level root CA, organisation-level intermediate CAs operated by each member, and end-entity certificates for individual users, services, and devices. Hyperledger Fabric's **Membership Service Provider (MSP)** abstraction formalises this hierarchy with attribute-based access control. Corda's identity model uses **Doorman** and **Network Map Service** to bind legal entity attestations to public keys.

**3. Deterministic BFT Consensus**: Consensus is a deterministic Byzantine-fault-tolerant protocol — **PBFT** (Castro-Liskov 1999), **IBFT 1.0/2.0** (Moniz et al., AMIS Labs 2018), **QBFT** (Quorum Byzantine Fault Tolerance), **SmartBFT** (Vukolić et al., used by Fabric 3.0), or **Tendermint** — providing single-slot finality in 1-5 seconds compared with public-chain probabilistic finality (Bitcoin ~60 minutes economic finality, Ethereum 12-19 minutes post-Merge under healthy conditions). Throughput typically ranges 1,000-10,000 TPS depending on configuration, compared with Bitcoin's 7 TPS and Ethereum mainnet's ~15-20 TPS.

**4. Permissioned Read/Write Access**: Read access to transaction data is selectively disclosed via **channels** (Fabric private sub-ledgers), **private data collections** (PDCs with on-channel hash anchoring), **point-to-point flows** (Corda's "tell who needs to know" model rejecting global state replication), or **ZK-based selective disclosure**. Write access requires endorsement by configured organisation subsets per endorsement policy (e.g., "any 2 of {OrgA, OrgB, OrgC}" or "OrgA AND any 1 of {OrgB, OrgC}").

**5. Negotiated Multi-Party Governance**: Protocol upgrades, member admission, fee structures, and dispute resolution operate under an explicit governance charter (often a Memorandum of Understanding or Consortium Operating Agreement) negotiated between members. Governance decisions typically require supermajority approval (commonly 2/3 or 3/4) of voting members, with weighted voting structures reflecting financial contribution, transaction volume, or strategic importance.

### Architecture and Components

Consortium blockchain platforms expose a modular architectural decomposition that reflects the multi-tenant operational reality of inter-organisational deployment:

#### Membership Service Provider (MSP)
The cryptographic identity layer. Issues X.509 certificates binding public keys to legal entities; defines roles (Admin, Client, Peer, Orderer) and attributes used by attribute-based access control; enables fine-grained authorisation through certificate-policy enforcement; supports HSM-backed key management for production deployments. Each organisation typically operates its own MSP with autonomy over its members' identity lifecycle, whilst the consortium-level MSP governs organisation admission and revocation.

#### Ordering Service
Sequences endorsed transactions into blocks and distributes them to peer nodes for validation and commit. Fabric pre-3.0 supports **Kafka-based** (deprecated 2.0+) and **Raft-based** (crash fault tolerant, O(n) message complexity) orderers; Fabric 3.0 introduced **SmartBFT** as the first production BFT orderer in the platform, finally providing Byzantine fault tolerance at the ordering layer. Besu, Quorum, Corda use validator-set BFT consensus directly without a separate ordering layer.

#### Endorsement Policy and Smart-Contract Execution
Endorsement policies specify which subset of organisations must co-sign a transaction proposal before it is submitted to the ordering service. Common patterns include "AND of all organisations" (full consensus), "majority of organisations" (typical), or "specific authoritative organisations" (e.g., regulator must endorse all transactions). Chaincode (Fabric) / CorDapps (Corda) / Solidity contracts (Besu, Quorum) execute on peer nodes within isolated containers (Docker for Fabric, JVM for Corda).

#### Channels and Private Data Collections (Fabric-specific)
Channels are completely separate sub-ledgers within a single Fabric network visible only to enumerated organisations — enabling competing organisations to participate in shared network infrastructure whilst maintaining bilateral confidentiality. Private Data Collections (PDCs) provide finer-grained privacy where transaction data is gossiped only amongst specified organisations whilst cryptographic hashes anchor to the main channel for verifiability without disclosure.

#### Notary Service (Corda-specific)
Corda rejects global state replication in favour of point-to-point transaction sharing between counterparties. To prevent double-spending without seeing transaction content, Corda introduces **notary services** — clusters of independent validator nodes that sign transaction inputs proving uniqueness using either non-validating (simple uniqueness check) or validating (full contract verification) notary models, often via BFT consensus.

#### Certificate Authority Hierarchy and Hardware Security Modules
Production deployments employ HSM-backed key custody using FIPS 140-2 Level 3 certified devices (Thales Luna, AWS CloudHSM, Azure Dedicated HSM, IBM Crypto Express, Utimaco) for root CA keys and validator signing keys. Consortium governance typically dictates HSM requirements as a precondition for validator status.

#### Off-Chain Data Stores
GDPR Article 17 (right to erasure) and similar regulations are incompatible with naïve immutability. Production consortia commonly store personal data **off-chain** in conventional databases with cryptographic hash anchors on-chain — enabling data deletion via key destruction or off-chain deletion whilst maintaining tamper-evidence of historical state.

### Consensus Algorithms for Consortium Blockchains

Consortium chains employ a distinct family of consensus algorithms optimised for known-participant settings, abandoning the cryptoeconomic security model of public chains in favour of classical Byzantine fault tolerance:

**Practical Byzantine Fault Tolerance (PBFT, Castro and Liskov 1999)**: The seminal three-phase (pre-prepare, prepare, commit) protocol providing safety under f < n/3 Byzantine faults with O(n²) message complexity. The intellectual ancestor of all consortium BFT variants. Production use: original Hyperledger Fabric 0.6 (deprecated), Hyperledger Sawtooth (PBFT mode, now EOL).

**IBFT 1.0 and IBFT 2.0 (Istanbul Byzantine Fault Tolerance)**: AMIS Labs and Quorum-team extension of PBFT to permissioned Ethereum. IBFT 2.0 (Moniz et al. 2018) added safety proofs and immediate finality. Production use: Hyperledger Besu IBFT 2.0, Quorum IBFT, AMIS-Pala.

**QBFT (Quorum Byzantine Fault Tolerance)**: Refinement of IBFT 2.0 by Consensys Quorum team adding validator-set changes via on-chain governance transactions, supporting smoother validator-rotation. Production use: GoQuorum default consensus, Hyperledger Besu QBFT, J.P. Morgan Onyx/Kinexys.

**SmartBFT (Vukolić et al.)**: Modular BFT protocol developed for Hyperledger Fabric 3.0 (released 2024), finally bringing Byzantine-fault-tolerant ordering into Fabric after years of Raft-only crash-fault-tolerant ordering. Significant for high-stakes consortia (CBDC, tokenised securities) requiring BFT at the ordering layer.

**Tendermint BFT**: Single-slot finality BFT used by Cosmos SDK, deployed in Hyperledger Burrow (semi-deprecated), Project mBridge Ledger (derived from Hyperledger Besu but with Tendermint-style finality), and various Cosmos-based consortium deployments.

**Raft (Ongaro and Ousterhout 2014)**: Crash-fault-tolerant (CFT) consensus tolerating f < n/2 crashes but not Byzantine failures. Higher throughput and simpler implementation than BFT, used where validators are within a single trust boundary or BFT is not required. Production use: Hyperledger Fabric ordering service (pre-3.0 default), etcd, CockroachDB.

**Proof of Authority (PoA)**: Simpler validator-rotation scheme where a fixed set of authorised signers takes turns producing blocks under round-robin or sealer-vote schemes. Used by Ethereum-based consortium deployments via the Clique algorithm (Geth, OpenEthereum); historically used by xDAI/Gnosis Chain (pre-merge), Polygon Edge.

### Major Platforms and Implementations (2026)

#### Hyperledger Fabric
The dominant enterprise consortium platform, originated at IBM 2015 and contributed to Linux Foundation Hyperledger Foundation December 2015. Current production status: **Fabric 2.5 LTS** (long-term support) and **Fabric 3.0** (released 2024 with SmartBFT ordering). Distinctive architectural features include modular consensus (Raft, SmartBFT), chaincode in Go/Java/JavaScript/TypeScript, channels and private data collections, hierarchical MSP identity, and Hyperledger Caliper for performance benchmarking. Major production deployments include IBM Food Trust (200+ participants), TradeLens (pre-closure), we.trade (pre-closure), MediLedger (DSCSA pharmaceutical), Komgo, IBM Trust Your Supplier (~250K supplier identities), Project Aber (SAMA-UAE CBDC), Project Jasper Phase 2 (Bank of Canada). The 2024 transition to the **Linux Foundation Decentralized Trust** umbrella (announced LF Decentralized Trust, encompassing the former Hyperledger Foundation plus Linux Foundation Web3, Trust over IP Foundation) consolidated Hyperledger's institutional positioning.

#### Hyperledger Besu
Enterprise Ethereum client originally developed by PegaSys (Consensys), contributed to Hyperledger 2019. Implements full Ethereum JSON-RPC API supporting public mainnet, public testnets, and permissioned consortium deployments via IBFT 2.0, QBFT, and Clique PoA consensus. Distinctive features include Ethereum tooling compatibility (Solidity, Truffle, Hardhat, Foundry, MetaMask), permissioning at the network and account level, and pluggable consensus. Major production deployments include **Project Rosalind** (Bank of England retail CBDC API layer Phase 1-2), **Project mBridge Ledger** (custom derivative), **Komgo** commodity finance, **Project Cedar** (NY Fed), multiple EBSI nodes.

#### R3 Corda
Designed by R3 (London-headquartered, founded 2015) explicitly for regulated financial services. Distinctive design rejects global state replication — Corda transactions are shared point-to-point between counterparties with notary clusters ensuring uniqueness, achieving stronger commercial confidentiality at the cost of unfamiliarity to developers expecting an Ethereum-like global state. **Corda 5.x** (released 2023-2024) introduced fully multi-tenant cluster architecture enabling multiple CorDapp deployments per cluster. Major production deployments include **HQLAx** (high-quality liquid asset collateral, ~$50B notional), **Contour** (trade finance, paused 2023), **Marco Polo Network** (administration 2022), **DTCC TIW** ($11T derivatives, decommissioned 2023 due to commercial issues), **SDX** (SIX Digital Exchange Switzerland tokenised securities), various Project Jasper / Project Stella phases.

#### Quorum / GoQuorum
Originated as a J.P. Morgan-internal Ethereum fork October 2016, sold to Consensys May 2020 and rebranded **GoQuorum** with continued open-source development plus Consensys-supported commercial offering. Supports IBFT, QBFT, Raft consensus; private transactions via Tessera transaction manager; full EVM compatibility. Underpins **J.P. Morgan Onyx Coin Systems / Kinexys** (rebranded 2024) processing $1B+ daily in tokenised deposit transfers, **Citi Token Services** (launched September 2023), Project Khokha (South African Reserve Bank), various Singapore MAS Ubin phases.

#### Hyperledger Iroha
Soramitsu-led Japanese consortium platform focused on mobile and IoT use cases. Production deployment: **National Bank of Cambodia Bakong** wholesale digital payment system (launched October 2020, 8M+ users by 2024), one of the most operationally successful production consortium blockchain deployments globally serving retail and wholesale settlement.

#### Microsoft Azure Confidential Consortium Framework (CCF)
Open-source TEE-based consortium ledger using Intel SGX or AMD SEV-SNP hardware enclaves to provide hardware-enforced confidentiality and integrity. Distinct from BFT-consensus platforms in trust model: CCF reduces trust to hardware-attested TEE rather than committee honesty. Foundation of Azure Confidential Ledger service used for regulatory audit trails, supply-chain integrity, and compliance recording.

#### Hyperledger Sawtooth (Deprecated)
Intel-originated platform with distinctive Proof of Elapsed Time (PoET) consensus exploiting Intel SGX TEEs. Reached **end-of-life February 2025** following sustained maintainer attrition. Historical relevance includes early MediLedger deployments, supply-chain experiments, and conceptual contribution to TEE-secured consensus.

### Use Cases / Major Families

#### Trade Finance Consortia (The Boom and Bust)
The 2017-2021 wave produced an enormous cohort of trade-finance consortia — **TradeLens** (IBM-Maersk container shipping, Hyperledger Fabric, signed MSC/CMA CGM/Hapag-Lloyd, **shut down December 2022** despite operational maturity due to insufficient industry-wide commercial collaboration), **Marco Polo Network** (R3 Corda + TradeIX, 30+ banks including BNP Paribas, Commerzbank, ING, Standard Chartered, NatWest, **administration March 2022**), **we.trade** (Hyperledger Fabric European trade finance for SMEs, Deutsche Bank/HSBC/KBC/Natixis/Nordea/Rabobank/Santander/Société Générale/UniCredit, **ceased trading June 2022**), **Contour** (R3 Corda, BNP Paribas/HSBC/Standard Chartered/ING/Bangkok Bank/CTBC, **paused late 2023**), **Voltron** (precursor to Contour). The Trade Finance Distribution Initiative (TFD Initiative) continues operating with multi-platform support. The unifying failure mode was not technical viability — these platforms demonstrably worked — but commercial collaboration: insufficient mandatory adoption, unresolved free-rider economics, competing incumbent systems, and the inability to coordinate behaviour amongst competing organisations with adjacent commercial interests.

#### Supply Chain Provenance Consortia (The Durable Survivors)
**IBM Food Trust** (Hyperledger Fabric) connects Walmart, Carrefour, Nestlé, Tyson Foods, Dole, Driscoll's, McCormick, McLane, Golden State Foods with 200+ participants tracking food provenance from farm to retailer; famously demonstrated Walmart contamination tracing for mangoes reducing source-identification from 6 days to 2.2 seconds. **MediLedger Network** (Chronicled, Hyperledger Fabric / Sawtooth hybrid) operates the production reference solution for **US Drug Supply Chain Security Act (DSCSA)** compliance with Pfizer, Genentech, Gilead, Amgen, GSK, Sanofi, Novartis, Bayer, Merck, AmerisourceBergen, McKesson, Cardinal Health — providing the pharmaceutical industry's largest production consortium blockchain network. **GS1 Trust Your Supplier** anchors supplier-identity verifiable credentials. **IBM Blockchain Transparent Supply** powers Maersk operations beyond TradeLens. These survivors share the property of clear regulatory drivers (DSCSA, food safety enforcement) and dominant-anchor-customer mandates (Walmart for Food Trust) overcoming the free-rider problem that killed the trade-finance cohort.

#### Commodity Trade Finance
**Komgo SA** (Geneva-headquartered, Quorum-derived) continues operating across ABN AMRO, BNP Paribas, Citi, Crédit Agricole, ING, Macquarie, Mercuria, MUFG, Natixis, Rabobank, Shell, Société Générale, Total, processing physical-commodity trade finance documentation. Komgo's persistence — distinguishing it from the failed banking trade-finance platforms — reflects the smaller, more cohesive commodity-trading membership and clearer documentation-digitisation value proposition.

#### Insurance Consortia
**B3i Services AG** (Blockchain Insurance Industry Initiative, founded 2016 with Aegon, Allianz, Munich Re, Swiss Re, Zurich; expanded to 18+ insurers including AIG, Generali, Hannover Re, Liberty Mutual, SCOR, **entered liquidation July 2022**). **Insurwave** (Maersk + EY + Microsoft + Guardtime + ACORD marine insurance, Willis Towers Watson, XL Catlin, MS Amlin) operates marine insurance with hull-and-machinery policies; reportedly continues at reduced scale. **RiskStream Collaborative** (Institutes RiskStream, North American P&C insurance) operates multi-line use cases.

#### Government and Regulatory Consortia
**EBSI (European Blockchain Services Infrastructure)** is operated by the European Commission alongside the 30-country **European Blockchain Partnership** (all EU member states plus Norway and Liechtenstein), running Hyperledger Besu and IOTA-based nodes across member-state infrastructure. Production EBSI use cases include verifiable diploma credentials (ESSIF self-sovereign identity stack), notarisation of regulatory documents, audit trails for European institutions, and pilots for trusted-data spaces under Gaia-X. **Singapore TradeTrust** (IMDA + MPA) standardises electronic transferable records under UNCITRAL Model Law on Electronic Transferable Records (MLETR), interoperating with permissioned Ethereum-compatible chains. **AuthBridge India** and various Indian state-government consortia operate on Hyperledger Fabric. **GLEIF vLEI** (verifiable Legal Entity Identifier) developed by the Global Legal Entity Identifier Foundation under UK GLEIS governance issues machine-verifiable LEIs on consortium-blockchain rails using W3C Verifiable Credentials and ToIP DIDs.

#### Wholesale CBDC and Tokenised Deposit Consortia
The most consequential post-2023 consortium-blockchain wave concerns central-bank wholesale CBDC and institutional tokenised deposits — **the area in which consortium blockchain architecture is most demonstrably appropriate and most rapidly maturing**. **BIS Project Agorá** (announced April 2024) is the flagship initiative — central banks of France/Eurosystem (Banque de France), UK (Bank of England), Japan (BoJ), South Korea (BoK), Mexico (Banxico), Switzerland (SNB), United States (NY Fed), with the Institute of International Finance coordinating 40+ private financial institutions including BlackRock, Citi, Deutsche Bank, Goldman Sachs, HSBC, J.P. Morgan, Mastercard, MUFG, Société Générale, Standard Chartered, Visa, exploring wholesale CBDC combined with tokenised commercial-bank deposits on a unified consortium ledger. **Project mBridge** (Multiple CBDC Bridge) consortium of HKMA, PBoC Digital Currency Institute, Bank of Thailand, Central Bank of UAE, Saudi Central Bank (SAMA joined formally 2024) reached **MVP June 2024** on the bespoke **mBridge Ledger** derived from Hyperledger Besu with bridging architecture supporting multiple CBDC issuance — the largest production cross-border CBDC consortium globally. **Project Cedar** (NY Fed Innovation Center): Phase 1 (2022) wholesale FX settlement, Phase 2 (2022-2023) cross-border with MAS. **Project Mariana** (BIS Innovation Hub + Banque de France + SNB + MAS, 2023) concluded September 2023 with technical viability demonstrated for AMM-based cross-border CBDC FX. **Project Jasper** (Bank of Canada, 2016-2017) ran on R3 Corda Phase 1 and Hyperledger Fabric Phase 2 — one of the earliest central-bank consortium experiments. **BoE Project Rosalind** (Bank of England + BIS Innovation Hub London, Phase 1 2022-2023, Phase 2 2024) tested retail CBDC API layer for private-sector innovation on Hyperledger Besu. **Project Aber** (SAMA-UAE 2018-2020) was the first cross-border wholesale CBDC consortium using Hyperledger Fabric. On the institutional-deposit side, **JPMorgan Onyx Coin Systems** (rebranded **Kinexys** 2024) processes $1B+ daily on permissioned Quorum rails; **Citi Token Services** (launched September 2023) handles cross-branch tokenised deposits and programmable trade-finance flows on a private permissioned ledger; **HSBC Orion** issues tokenised bonds; **Société Générale FORGE** issues tokenised securities; **Goldman Sachs DAP** (Digital Asset Platform on Daml) operates tokenised securities; **BNY Mellon Digital Asset Platform** custodies tokenised assets.

### Academic Context

Consortium blockchain research draws on distributed systems theory, applied cryptography, mechanism design, and organisational economics — with an emerging cross-disciplinary literature on multi-party governance:

#### Distributed Systems and Consensus Foundations
**Castro and Liskov (1999)** *Practical Byzantine Fault Tolerance* (OSDI 1999) — foundational PBFT protocol enabling asynchronous Byzantine consensus amongst a known committee with O(n²) message complexity tolerating f < n/3 faulty replicas. The theoretical bedrock under every modern consortium consensus algorithm.

**Ongaro and Ousterhout (2014)** *In Search of an Understandable Consensus Algorithm* (USENIX ATC) — the Raft protocol providing crash-fault-tolerant consensus with pedagogical clarity superseding Paxos in production systems including Hyperledger Fabric ordering services.

**Moniz, Vukolić et al. (2018)** *The Istanbul Byzantine Fault Tolerance Protocol* and subsequent IBFT 2.0 formalisation — the BFT protocol adopted by Hyperledger Besu, Quorum, and AMIS Labs deployments.

**Vukolić (2015)** *The Quest for Scalable Blockchain Fabric* (iNetSec) — comparative analysis of BFT vs Nakamoto consensus that motivated Hyperledger's BFT-first architectural philosophy.

**Cachin and Vukolić (2017)** *Blockchain Consensus Protocols in the Wild* — IBM Research SoK paper categorising consortium consensus algorithms.

#### Hyperledger and Enterprise Blockchain Architecture
**Androulaki, Barger, Bortnikov, Cachin et al. (2018)** *Hyperledger Fabric: A Distributed Operating System for Permissioned Blockchains* (EuroSys 2018) — the foundational Fabric architecture paper. Heavily cited (5,000+ citations) as the canonical description of the execute-order-validate transaction flow distinguishing Fabric from order-execute public chains.

**Brown, Carlyle, Grigg, Hearn (R3, 2016)** *Corda: An Introduction* — foundational design document articulating the point-to-point messaging philosophy.

**Sousa, Bessani, Vukolić (2018)** *A Byzantine Fault-Tolerant Ordering Service for the Hyperledger Fabric Blockchain Platform* — the SmartBFT precursor.

#### Governance, Economics, and Sociotechnical Analysis
**Hsieh, Vergne, Wang (2017)** *Bitcoin and the Rise of Decentralized Autonomous Organizations* — typology of governance models including consortium pre-cursors.

**De Filippi and Wright (2018)** *Blockchain and the Law* (Harvard University Press) — legal frameworks for consortium governance.

**Catalini and Gans (2020)** *Some Simple Economics of the Blockchain* (Communications of the ACM) — economic theory of blockchain adoption applicable to consortium formation.

**Beck, Müller-Bloch, King (2018)** *Governance in the Blockchain Economy* (Journal of the AIS) — empirical study of consortium governance structures.

**Lacity (2018, 2020)** *A Manager's Guide to Blockchains for Business* — practitioner-academic synthesis from University of Arkansas Blockchain Center of Excellence.

#### UK Academic Consortium Blockchain Research
**Imperial College Centre for Cryptocurrency Research and Engineering (CCRE)** led by William Knottenbelt, including Daniel Perez and Catherine Mulligan (consortium governance and regulatory technology).

**UCL Centre for Blockchain Technologies (CBT)** led by Paolo Tasca with substantial output on consortium economics, tokenisation, and CBDC architecture; produced UK-government-commissioned reports including the 2024 "DLT for Capital Markets" Treasury consultation response.

**Cambridge Centre for Alternative Finance (CCAF)** produced the foundational *Global Enterprise Blockchain Benchmarking Study* (2019, 2020) — the most-cited empirical survey of consortium adoption.

**Edinburgh Blockchain Technology Lab** under Aggelos Kiayias contributes consensus-protocol research applicable to consortium deployments.

### Current Landscape (2026)

As of May 2026, the consortium-blockchain landscape exhibits a distinctive consolidation: most 2017-2021 trade-finance ventures have shut down, supply-chain provenance and pharmaceutical-tracking consortia have stabilised at smaller scale, **wholesale CBDC and institutional tokenised-deposit consortia represent the most active growth frontier**, and government-operated consortia (EBSI, TradeTrust, GLEIF vLEI) have moved into measurable production:

#### Platform Market Structure
**Hyperledger Fabric** retains majority enterprise market share with Fabric 3.0 SmartBFT release providing renewed institutional confidence. **Hyperledger Besu** dominates CBDC and Ethereum-aligned consortium deployments. **R3 Corda** retains financial-services niche with Corda 5.x multi-tenant architecture, though the dissolution of Marco Polo Network, Contour, and DTCC TIW substantially eroded R3's commercial position relative to 2018-2020 peak. **Quorum/GoQuorum** under Consensys stewardship maintains relevance via J.P. Morgan Kinexys and Citi Token Services. **Hyperledger Iroha** continues at Cambodia Bakong scale. **Microsoft CCF** captures TEE-secured niches.

#### Governance and Standards Evolution
**ISO/TC 307 Blockchain and DLT** standards relevant to consortia include **ISO 22739:2024** (updated vocabulary), **ISO 23257:2022** (reference architecture), **ISO/TR 23455:2019** (smart contracts overview), **ISO 24165** (Digital Token Identifier DTI). The **Enterprise Ethereum Alliance** published **EthTrust Security Levels Specification v3** (2025) defining audit levels [S]/[M]/[Q] for smart contracts deployable on permissioned and public Ethereum-based consortium networks. The **Linux Foundation Decentralized Trust** (2024 rebrand/expansion encompassing Hyperledger, LF Web3, ToIP) consolidated open-source stewardship. **InterWork Alliance Token Taxonomy Framework** standardises cross-platform token representation.

#### Wholesale CBDC Consortium Maturation
The single most consequential 2024-2026 development is the maturation of wholesale CBDC consortia. **Project Agorá** (BIS, central banks of France/UK/Japan/South Korea/Mexico/Switzerland/US plus 40+ private institutions) frames the emerging architecture: a unified consortium ledger combining wholesale CBDC, tokenised commercial-bank deposits, and tokenised real-world assets under a hybrid public-private governance with central-bank ultimate authority and private-sector operational participation. **Project mBridge** reached MVP June 2024 on mBridge Ledger demonstrating production cross-border CBDC settlement amongst HKMA-PBoC-BoT-CBUAE-SAMA. These initiatives explicitly validate consortium architecture as the appropriate substrate for institutional digital money.

#### Tokenised Deposit Resurgence
J.P. Morgan **Kinexys** processes $1B+ daily; Citi Token Services operates cross-branch tokenised deposits; HSBC Orion issues tokenised bonds; Société Générale FORGE issues tokenised securities; the **City of London Corporation** published the **UK Tokenisation Strategy** (2024) explicitly positioning consortium-rail tokenisation as central to UK financial competitiveness post-Brexit. The **FCA Digital Sandbox** and **PSR Open Banking** evolution incorporate consortium-blockchain experimentation tracks.

#### Failures and Lessons Learned
The 2022-2023 wave of consortium failures (TradeLens, Marco Polo, we.trade, B3i, Contour, DTCC TIW decommissioning) yielded a robust empirical literature on **why technically functional consortia fail commercially**: (i) free-rider problems where some members extract disproportionate value without commensurate contribution; (ii) competing strategic interests amongst consortium members preventing aligned roadmaps; (iii) incumbent-system inertia and switching costs; (iv) inability to mandate participation across an industry; (v) unclear value capture and revenue distribution amongst consortium members and the platform operator (IBM/Maersk for TradeLens, R3 for Corda networks).

### UK Context

The United Kingdom hosts a distinctive concentration of consortium-blockchain research, industry leadership, and regulatory experimentation:

#### London as Consortium-Blockchain Hub
**R3 Corda** is headquartered in London (Worship Street, EC2 historically; expanded to NYC and Singapore offices) with the majority of its core engineering and partnership team remaining UK-based. R3 was founded September 2015 in London by David Rutter (ex-ICAP) with ~40 founding banks including Barclays, RBS, HSBC, Standard Chartered, Lloyds, Santander — the original UK consortium-blockchain anchor.

**City of London Corporation** published the **UK Tokenisation Strategy** (2024) explicitly positioning the City as a global leader in regulated tokenisation infrastructure built on consortium rails, partnering with HM Treasury, the Bank of England, and the Financial Conduct Authority.

**Bank of England Project Rosalind** (Phase 1 2022-2023, Phase 2 2024) tested retail CBDC API layer on Hyperledger Besu in partnership with BIS Innovation Hub London — establishing the BoE's architectural commitment to consortium-rail digital money infrastructure.

**FCA Digital Sandbox** (Financial Conduct Authority sandbox launched 2020, expanded with permanent track 2023-2024) provides regulated experimentation environment used by consortium-blockchain projects including tokenised asset issuance and verifiable-credential pilots.

**GLEIF UK GLEIS** (Global Legal Entity Identifier Foundation UK governance) operates the international LEI infrastructure with the verifiable LEI (vLEI) project building on consortium-blockchain rails.

#### UK Academic Research
**Imperial College Centre for Cryptocurrency Research and Engineering (CCRE)** under William Knottenbelt produces SoK papers including Zamyatin et al. *SoK: Communication Across Distributed Ledgers* (2019, 2021) — foundational for cross-consortium interoperability.

**UCL Centre for Blockchain Technologies (CBT)** under Paolo Tasca produces UK-government-commissioned consortium-blockchain analysis including capital-markets DLT consultation responses.

**Cambridge Centre for Alternative Finance (CCAF)** produced the *Global Enterprise Blockchain Benchmarking Study* (2019, 2020) — the most-cited empirical survey of consortium adoption globally.

**Edinburgh Blockchain Technology Lab** under Aggelos Kiayias contributes consensus-protocol research applicable to consortium deployments, with Edinburgh's status as the leading Scottish computer-science department reinforcing UK consortium research breadth.

#### Northern English Industrial and Fintech Centres
**Manchester** has emerged as a significant fintech hub with the **Manchester Blockchain Hub**, hosting consortium-blockchain startups and the **Greater Manchester Combined Authority** experimenting with public-sector consortium use cases.

**Leeds** (with Leeds Beckett University and University of Leeds blockchain research) anchors Northern fintech in financial services and supply chain.

**Sheffield** hosts the University of Sheffield's blockchain research group with applied work on supply-chain consortia.

**Newcastle** (Newcastle University, Open Lab) contributes blockchain research with HCI focus, applicable to consortium governance interfaces.

These Northern centres complement the London-centric financial-services consortium landscape with applied, industrial, and supply-chain-focused research and deployment activity.

### Future Directions (2026-2030)

#### Convergence with Public Chains and Modular Blockchain Stack
The 2026-2030 trajectory most likely involves **erosion of the strict consortium/public divide**: institutional tokenised assets issued on consortium rails (J.P. Morgan Kinexys, Citi Token Services, HSBC Orion) increasingly bridge to public chains via cross-chain messaging protocols (Chainlink CCIP SWIFT pilot, Axelar GMP for J.P. Morgan, LayerZero V2 for institutional flows). The emerging architecture combines consortium-grade issuance and governance with public-chain liquidity and composability via standardised cross-chain primitives.

#### Restaking-Secured Consortium Validators
EigenLayer-style restaking applied to consortium contexts enables consortium validators to bond restaked ETH against attestation integrity, providing economic security comparable to L1 chains whilst retaining the known-validator governance model. Early experiments include Polymer Hub (IBC for Ethereum rollups), Hyperlane Validator AVS, and emerging consortium-AVS hybrids.

#### Confidential Computing Integration
Microsoft Azure CCF and equivalent TEE-based consortium ledgers — Intel SGX, Intel TDX, AMD SEV-SNP, Arm CCA — provide hardware-attested confidentiality that complements consortium-blockchain logical permissioning. Major financial-services consortia (Project Agorá, mBridge) increasingly require TEE-secured execution environments for sensitive computation.

#### Post-Quantum Cryptography Migration
NIST PQC standardisation (CRYSTALS-Kyber, CRYSTALS-Dilithium, FALCON, SPHINCS+ finalised 2024) drives quantum-resistant cryptographic migration in consortium deployments. Long-lived consortium archives (regulatory audit trails, GLEIF vLEI, EBSI) face particular post-quantum pressure due to multi-decade retention requirements.

#### Cross-Consortium Interoperability
**Hyperledger Cactus / Hyperledger Cacti** specifically addresses blockchain interoperability for enterprise consortium use cases. **ITU Cross-Chain Reference Architecture**, **ISO/TC 307** interoperability work items, and emerging **EthTrust** cross-platform audit specifications provide standards-track interoperability between consortium platforms.

#### Verifiable Credentials and Self-Sovereign Identity Integration
W3C **Verifiable Credentials** and **Decentralized Identifiers (DIDs)**, **Trust over IP (ToIP)** governance frameworks, and **EBSI Verifiable Credentials** for diploma recognition increasingly anchor consortium-blockchain identity primitives, with GLEIF **vLEI** providing the legal-entity-identification authoritative root.

#### Regulatory and Legislative Maturation
**EU MiCA** (Markets in Crypto-Assets Regulation, fully applicable December 2024) provides legal certainty for tokenised-asset issuance on consortium rails. **UK FSMA 2023** (Financial Services and Markets Act) enables HM Treasury to designate Digital Securities Sandbox participants on consortium rails. **EU DLT Pilot Regime** (operational 2023-2026) provides regulated experimentation environments. **US SEC Project Crypto** and CFTC initiatives evolve regulatory clarity. **Switzerland DLT Act** (2021) provides ongoing legal foundation. **Singapore Payment Services Act** and **MAS Project Guardian** continue establishing Asian consortium-blockchain regulatory precedent.

#### CBDC Production Deployment
Project mBridge moves from MVP to production wholesale CBDC settlement. Project Agorá produces production tokenised-deposit consortium platforms by 2028-2029. **PRC e-CNY wholesale** extends cross-border capability via mBridge integration. **ECB digital euro** wholesale layer (planned 2026-2028 decision-window) likely settles on consortium-rail infrastructure. **BoE digital pound** wholesale infrastructure decision-window 2025-2027 builds on Project Rosalind foundations.

### Research & Literature

**Foundational Distributed Systems and BFT**:
1. Castro, M., & Liskov, B. (1999). Practical Byzantine fault tolerance. *Proceedings of OSDI '99*, 173-186.
2. Lamport, L., Shostak, R., & Pease, M. (1982). The Byzantine generals problem. *ACM TOPLAS*, 4(3), 382-401.
3. Ongaro, D., & Ousterhout, J. (2014). In search of an understandable consensus algorithm. *USENIX ATC '14*, 305-320.
4. Fischer, M.J., Lynch, N.A., & Paterson, M.S. (1985). Impossibility of distributed consensus with one faulty process. *Journal of the ACM*, 32(2), 374-382.
5. Cachin, C., & Vukolić, M. (2017). Blockchain consensus protocols in the wild. *arXiv:1707.01873*.

**Hyperledger and Enterprise Platforms**:
6. Androulaki, E., Barger, A., Bortnikov, V., Cachin, C., Christidis, K., De Caro, A., ... & Yellick, J. (2018). Hyperledger Fabric: A distributed operating system for permissioned blockchains. *EuroSys '18*. DOI:10.1145/3190508.3190538
7. Vukolić, M. (2015). The quest for scalable blockchain fabric: Proof-of-work vs. BFT replication. *iNetSec 2015*. DOI:10.1007/978-3-319-39028-4_9
8. Brown, R.G., Carlyle, J., Grigg, I., & Hearn, M. (2016). Corda: An introduction. *R3 Whitepaper*.
9. Sousa, J., Bessani, A., & Vukolić, M. (2018). A Byzantine fault-tolerant ordering service for the Hyperledger Fabric blockchain platform. *DSN '18*, 51-58.
10. Moniz, H. (2020). The Istanbul BFT consensus algorithm. *AMIS Labs Technical Report*.

**Consortium Governance and Economics**:
11. Beck, R., Müller-Bloch, C., & King, J.L. (2018). Governance in the blockchain economy: A framework and research agenda. *Journal of the AIS*, 19(10).
12. Catalini, C., & Gans, J.S. (2020). Some simple economics of the blockchain. *Communications of the ACM*, 63(7), 80-90.
13. Hsieh, Y.Y., Vergne, J.P., & Wang, S. (2017). The internal and external governance of blockchain-based organizations. *Bitcoin and Beyond*, Routledge.
14. De Filippi, P., & Wright, A. (2018). *Blockchain and the Law: The Rule of Code*. Harvard University Press.
15. Lacity, M. (2018). Addressing key challenges to making enterprise blockchain applications a reality. *MIS Quarterly Executive*, 17(3).

**Industry Reports and Empirical Studies**:
16. Hileman, G., & Rauchs, M. (2017, 2019, 2020). Global Enterprise Blockchain Benchmarking Study. *Cambridge Centre for Alternative Finance*.
17. Carson, B., Romanelli, G., Walsh, P., & Zhumaev, A. (2018). Blockchain beyond the hype: What is the strategic business value? *McKinsey & Company*.
18. World Economic Forum (2020). *Inclusive Deployment of Blockchain for Supply Chains*.

**CBDC and Tokenisation**:
19. Bank for International Settlements (2024). *Project Agorá: Banks and central banks collaborate on tokenised future*. BIS Innovation Hub.
20. BIS, HKMA, PBoC DCRI, Bank of Thailand, CBUAE (2024). *Project mBridge: experimenting with a multi-CBDC platform for cross-border payments*. BIS Innovation Hub.
21. BIS, Banque de France, Swiss National Bank, MAS (2023). *Project Mariana: cross-border exchange of wholesale CBDCs using automated market makers*. BIS Innovation Hub.
22. Federal Reserve Bank of New York (2022, 2023). *Project Cedar Phase 1 and Phase 2 Reports*. NY Fed Innovation Center.
23. Bank of England & BIS Innovation Hub (2023, 2024). *Project Rosalind Phase 1 and Phase 2 Reports*.
24. Bank of Canada (2018, 2019). *Project Jasper: A Canadian Experiment with Distributed Ledger Technology*.
25. SAMA & Central Bank of UAE (2020). *Project Aber: Saudi Central Bank and Central Bank of the U.A.E. Joint Digital Currency and Distributed Ledger Project*.

**UK and European Academic**:
26. Zamyatin, A., Wolter, M., Werner, S., Harz, D., Knottenbelt, W.J., & Mehar, M.I. (2021). SoK: Communication across distributed ledgers. *Financial Cryptography '21*. (Imperial College London)
27. Tasca, P., & Tessone, C.J. (2019). A taxonomy of blockchain technologies: Principles of identification and classification. *Ledger*, 4. (UCL CBT)
28. Kiayias, A., Russell, A., David, B., & Oliynykov, R. (2017). Ouroboros: A provably secure proof-of-stake blockchain protocol. *CRYPTO '17*. (Edinburgh)

**Standards and Specifications**:
29. ISO 22739:2024 *Blockchain and distributed ledger technologies — Vocabulary*. International Organization for Standardization.
30. ISO 23257:2022 *Blockchain and distributed ledger technologies — Reference architecture*.
31. Enterprise Ethereum Alliance (2025). *EthTrust Security Levels Specification v3*.
32. Linux Foundation Decentralized Trust (2024). *Hyperledger Foundation Strategic Roadmap*.

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive editorial review, Phase 6 enrichment
- **Verification**: Academic sources cross-referenced, platform release notes verified (Fabric 3.0 SmartBFT 2024, Corda 5.x, Sawtooth EOL Feb 2025), CBDC pilot status verified against BIS/central-bank publications (Project Agorá April 2024, mBridge MVP June 2024, Cedar Phase 1-2, Mariana Sept 2023, Rosalind Phase 1-2, Aber 2018-2020), consortium failure dates verified (TradeLens Dec 2022, Marco Polo March 2022, we.trade June 2022, B3i July 2022, Contour late 2023)
- **Regional Context**: UK consortium-blockchain hub (R3 London HQ, BoE Project Rosalind, City of London Tokenisation Strategy, FCA Digital Sandbox, GLEIF UK GLEIS), UK academic institutions (Imperial CCRE, UCL CBT, Cambridge CCAF, Edinburgh Kiayias group), Northern English centres (Manchester Blockchain Hub, Leeds, Sheffield, Newcastle)
- **Production-Ready**: Complete OWL formal semantics covering 6 axiom families (Compositional, Dependency, Capability, Implementation, Reduction, Association) plus Standardization and Data Properties, comprehensive content coverage (theory, platforms, consensus algorithms, use case families including TradeLens/Marco Polo/we.trade/B3i/Contour failure analysis, CBDC consortia Project Agorá/mBridge/Cedar/Mariana/Jasper/Rosalind/Aber, tokenised-deposit deployments JPM Kinexys/Citi Token Services/HSBC Orion/SocGen FORGE, UK context, future directions 2026-2030)
- **Authority Score**: 0.87 (foundational distributed-systems theory, mature enterprise deployment, comprehensive standards landscape via ISO/TC 307 and EEA, active central-bank consortium experimentation, well-documented failure cases providing empirical validation of governance challenges)

### Provenance

- **domain-correction:** null (domain `blockchain` correct for consortium DLT concept)

