Brain-Computer Interfaces (BCIs), also termed brain-machine interfaces (BMIs) or direct neural interfaces, are biomedical and neurotechnological systems establishing a direct, real-time bidirectional or unidirectional communication channel between the central nervous system (predominantly the cer...

### Semantic Classification

### Content

## Compositional Relationships (Components)
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:hasPart infra:MicroelectrodeArray))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:hasPart infra:SignalAmplifier))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:hasPart infra:AnalogToDigitalConverter))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:hasPart infra:NeuralDecoder))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:hasPart infra:StimulationDriver))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:hasPart infra:WirelessTelemetryModule))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:hasPart infra:BiocompatibleEncapsulation))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:hasPart infra:SpikeSorter))

    ## Dependency Relationships
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:requires infra:BiocompatibleMaterials))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:requires infra:LowNoiseAnalogElectronics))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:requires infra:NeurosurgicalProcedure))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:requires infra:RealTimeComputing))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:requires infra:MachineLearningDecoder))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:dependsOn infra:Neuroscience))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:dependsOn infra:Electrophysiology))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:dependsOn infra:ComputationalNeuroscience))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:dependsOn infra:SignalProcessing))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:dependsOn infra:InformationTheory))

    ## Capability Relationships
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:enables infra:MotorRestoration))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:enables infra:SpeechRestoration))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:enables infra:SensoryRestoration))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:enables infra:ClosedLoopNeuromodulation))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:enables infra:LockedInPatientCommunication))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:enables infra:CognitiveAugmentation))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:supports infra:TetraplegiaRehabilitation))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:supports infra:ALSCommunication))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:supports infra:ParkinsonsDiseaseTreatment))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:supports infra:RefractoryEpilepsyTreatment))

    ## Implementation Relationships
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:implements infra:ActionPotentialRecording))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:implements infra:LocalFieldPotentialRecording))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:implements infra:Electrocorticography))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:implements infra:Electroencephalography))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:implements infra:IntracorticalMicrostimulation))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:uses infra:KalmanFilter))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:uses infra:RecurrentNeuralNetwork))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:uses infra:TransformerArchitecture))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:uses infra:LinearDiscriminantAnalysis))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:uses infra:CommonSpatialPatterns))

    ## Reduction Relationships
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:reduces infra:CommunicationBarriers))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:reduces infra:MotorDisability))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:reduces infra:NeurologicalSymptomBurden))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:reduces infra:CaregiverDependency))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:reduces infra:SocialIsolation))

    ## Contrast & Association Relationships
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:contrastsWith infra:Keyboard))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:contrastsWith infra:EyeTracking))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:contrastsWith infra:EMGWristband))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:contrastsWith infra:PeripheralNerveInterface))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:relatedTo infra:Neuroprosthetics))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:relatedTo infra:Neurorights))
    SubClassOf(infra:BrainComputerInterfaces
      ObjectSomeValuesFrom(infra:relatedTo infra:CognitiveEnhancement))

    ## Data Properties (Characteristics)
    DataPropertyAssertion(infra:hasIdentifier infra:BrainComputerInterfaces "BC-1001"^^xsd:string)
    DataPropertyAssertion(infra:authorityScore infra:BrainComputerInterfaces "0.87"^^xsd:decimal)
    DataPropertyAssertion(infra:firstHumanImplantYear infra:BrainComputerInterfaces "2004"^^xsd:integer)
    DataPropertyAssertion(infra:neuralinkFirstHumanDate infra:BrainComputerInterfaces "2024-01-28"^^xsd:date)
    DataPropertyAssertion(infra:speechBCIWordsPerMinute infra:BrainComputerInterfaces "78"^^xsd:integer)
    DataPropertyAssertion(infra:globalMarketSize2030USD infra:BrainComputerInterfaces "20000000000"^^xsd:decimal)
    DataPropertyAssertion(infra:dbsImplantCountGlobal infra:BrainComputerInterfaces "200000"^^xsd:integer)
    DataPropertyAssertion(infra:rnsEpilepsyImplantCount infra:BrainComputerInterfaces "4000"^^xsd:integer)

    ## Property Constraints
    SubClassOf(infra:BrainComputerInterfaces
      DataAllValuesFrom(infra:requiresInformedConsent xsd:boolean))
    SubClassOf(infra:BrainComputerInterfaces
      DataSomeValuesFrom(infra:invasivenessClass xsd:string))
    SubClassOf(infra:BrainComputerInterfaces
      DataMinCardinality(1 infra:hasChannelCount xsd:integer))
    SubClassOf(infra:BrainComputerInterfaces
      DataMinCardinality(1 infra:hasSamplingRateHz xsd:integer))
    SubClassOf(infra:BrainComputerInterfaces
      DataMaxCardinality(1 infra:hasRegulatoryApprovalStatus xsd:string))

    ## Annotations
    AnnotationAssertion(rdfs:label infra:BrainComputerInterfaces "Brain Computer Interfaces"@en)
    AnnotationAssertion(rdfs:comment infra:BrainComputerInterfaces "Direct communication channel between the central nervous system and an external computer, spanning invasive penetrating microelectrode arrays (Utah Array, Michigan probes, Neuropixels, Neuralink N1 1024-channel, Paradromics, Precision Neuroscience Layer 7), partially invasive ECoG and Synchron Stentrode endovascular interfaces, and non-invasive EEG/fNIRS/MEG/fMRI systems; decodes spikes, LFP, ECoG, and scalp potentials via Kalman filters, LDA, deep RNN/transformer/Mamba decoders; enables motor restoration (BrainGate), 78-wpm speech restoration (Pancho, Ann, Willett), sensory feedback (DARPA HAPTIX), closed-loop neuromodulation (DBS, RNS, spinal cord stimulation Onward), and emerging consumer applications; governed by FDA BCI Guidance 2021, EU MDR Class III, UK MHRA, IEEE 2731, and emergent neurorights frameworks (Chile 2021, UNESCO 2024, Yuste Columbia)."@en)
    AnnotationAssertion(dcterms:identifier infra:BrainComputerInterfaces "BC-1001"^^xsd:string)
    AnnotationAssertion(dcterms:subject infra:BrainComputerInterfaces "Neurotechnology, Neuroprosthetics, Brain-Machine Interface, Neural Decoding, Neuromodulation"@en)
  )

  ## Property Characteristics
  AsymmetricObjectProperty(infra:requires)
  AsymmetricObjectProperty(infra:enables)
  AsymmetricObjectProperty(infra:implements)
  AsymmetricObjectProperty(infra:reduces)
  TransitiveObjectProperty(infra:dependsOn)
  FunctionalDataProperty(infra:invasivenessClass)
  FunctionalDataProperty(infra:hasRegulatoryApprovalStatus)

## About Brain-Computer Interfaces

- **Brain-Computer Interfaces (BCIs)** establish a direct, real-time communication channel between neural tissue and an external computing system, fundamentally bypassing the conventional sensorimotor pathway through muscles and peripheral nerves. The field originated in the 1970s with Jacques Vidal's UCLA visual-evoked-potential work, but the modern era began with Phil Kennedy's 1998 neurotrophic-electrode implants, Donoghue and colleagues' 2004 BrainGate first human Utah-array implant in Matthew Nagle, and Nicolelis's primate brain-machine-interface programmes at Duke. What was once a niche academic and clinical-translation enterprise has, in 2024-2026, become a multi-billion-dollar deep-tech sector with first commercial implants, regulatory frameworks, and a vigorous neurorights debate.
- The defining feature of a BCI is that it **reads from or writes to the central nervous system directly**, rather than relying on intermediate biomechanical actuators (the larynx, fingers, eye-gaze muscles). This permits restoration of function for people whose efferent pathways are damaged (tetraplegia, ALS, locked-in syndrome, stroke), but it also opens the prospect of augmenting healthy users with input bandwidth and modalities not available through conventional interfaces. Every BCI implementation balances four orthogonal axes: **invasiveness** (the surgical/biological cost of placement), **spatial resolution** (how locally the signal originates), **temporal resolution** (millisecond-class spikes versus second-class haemodynamics), and **channel count** (single-electrode through 10,000+ channel arrays).

### Core Signal Modalities

BCIs differ principally in **what they measure** and **where**. The five canonical acquisition modalities form a clear hierarchy along the invasiveness/resolution trade-off.

#### 1. Intracortical Single-Unit and Multi-Unit Activity

**Signal**: Extracellular action potentials ("spikes") from individual neurons within ~50-150 μm of a penetrating electrode. Amplitude 50-500 μV, duration ~1 ms, instantaneous firing rates 0.1-200 Hz per neuron. Sampling at 30 kHz with band-pass 300 Hz – 7.5 kHz.

**Hardware**:

- **Utah Array** (Blackrock Neurotech, Salt Lake City): 4×4 mm silicon substrate, 96-128 platinum-iridium needles 1.0-1.5 mm long, FDA-cleared for human research; standard in BrainGate, Caltech, UCSF, Pittsburgh.
- **Michigan probes** (NeuroNexus, Diagnostic Biochips): planar silicon shanks with 16-64 recording sites; widely used in rodent and non-human-primate neuroscience.
- **Neuropixels** (IMEC/Janelia/Allen/HHMI consortium): integrated CMOS probe, 960 sites (v1.0) or 5120 sites (v2.0), 384-768 simultaneous channels, 10 mm shank — has revolutionised systems neuroscience since 2017.
- **Neuralink N1**: 1024-channel flexible polymer threads inserted by the R1 robot, on-chip spike sorting, wireless inductive power and Bluetooth telemetry; first human Noland Arbaugh January 2024, second Bradford Smith (ALS) March 2025.
- **Paradromics Connexus**: 1024-channel high-data-rate cortical module; FDA Breakthrough Designation; targeting 100,000+ channels per patient by 2030.

  **Decoding**: Kalman filters and Wiener filters were the original mainstays (Wu, Black, Donoghue 2002-2008 for kinematic decoding) and remain widely used. Deep recurrent decoders (LSTMs, GRUs, bidirectional RNNs) and transformer/Mamba architectures now dominate state-of-art speech decoding (Willett et al. 2021 handwriting BCI 90 char/min; Willett et al. 2023 speech BCI 62-78 wpm).

  **Strengths**: Highest information rate (~bits per second) per channel; access to fine motor and speech representations; closed-loop latency <20 ms feasible.
  **Weaknesses**: Open craniotomy, durotomy, parenchymal penetration; signal stability degrades over months-years from foreign-body response and micromotion; lifetime expected 1-7 years for current generation though Neuralink and Paradromics are explicitly engineering for decadal stability.

  #### 2. Local Field Potentials (LFP)

  **Signal**: Lower-frequency (0.5-300 Hz) extracellular potentials reflecting the summed synaptic activity of thousands of neurons within ~250-1000 μm of the electrode. Provides population-level information complementary to spikes; particularly useful for motor preparation, decision-making, and sensory processing.

  Many penetrating electrodes record both spikes and LFP simultaneously, simply by applying different filter bands to the same signal. LFP is more robust to electrode encapsulation than single-unit recording and is the principal signal exploited by long-term DBS and RNS devices.

  #### 3. Electrocorticography (ECoG) and Micro-ECoG (μECoG)

  **Signal**: Subdural or epidural surface potentials from the cortical surface; bandwidth 1-200 Hz with high-γ (70-200 Hz) carrying most decoding information for motor and speech. SNR 100-1000× scalp EEG.

  **Hardware**:

- Clinical ECoG (Ad-Tech, PMT): 2-4 mm electrodes at 5-10 mm pitch, used routinely for epilepsy localisation and increasingly for BCI research.
- μECoG: 0.5-2 mm pitch, 100-1000+ channels (UCSF Chang lab speech BCIs; Stanford BrainGate ECoG arms).
- **Precision Neuroscience Layer 7 Cortical Interface**: 1024-electrode polyimide film, 200 μm thickness, placed via cranial micro-slit without parenchymal penetration; FDA 510(k) clearance April 2025 for ≤30-day temporary use, breakthrough pathway for permanent implantation.
- **NeuroOne Evo Cortical Electrode**: 510(k)-cleared thin-film grid.

  **Strengths**: No parenchymal damage; multi-year stability demonstrated; clinically deployable through existing neurosurgical workflows; sufficient bandwidth for 78-wpm speech decoding (UCSF Pancho/Ann).
  **Weaknesses**: Still requires craniotomy or burr-hole + dural opening; lower information rate than intracortical for fine motor control.

  #### 4. Endovascular Electrodes (Stentrode)

  **Signal**: Vascular-adjacent local field potentials recorded from the lumen of the superior sagittal sinus and cortical veins.

  **Hardware**: **Synchron Stentrode** — 8-16 platinum electrodes on a self-expanding nitinol stent, ~4 mm × 40 mm, delivered through the jugular vein under fluoroscopic guidance and parked in the superior sagittal sinus over motor cortex; eliminates craniotomy entirely. FDA Investigational Device Exemption 2021; COMMAND trial enrolling US patients since 2022; SWITCH trial in Australia. Backed by Bezos Expeditions, Bill Gates, ARCH Venture Partners.

  **Strengths**: Minimally invasive, day-case procedure; leverages mature endovascular neurosurgery; multi-year vessel stability demonstrated.
  **Weaknesses**: Limited to surfaces adjacent to large dural sinuses; lower channel count and SNR than direct cortical contact; risk of thrombosis (mitigated by antithrombotic regimens in trial protocols).

  #### 5. Electroencephalography (EEG)

  **Signal**: Scalp potentials, 0.1-100 μV, 0.5-50 Hz; spatially smeared by skull and scalp impedance (~3-5 cm cortical mixing). Decomposed into δ/θ/α/β/γ bands and event-related potentials (P300, N400, ERN).

  **Hardware tiers**:

- **Research/clinical wet**: 64-256 channel Ag/AgCl electrodes with gel (BrainVision actiCHamp, EGI Geodesic, Compumedics Neuroscan, ANT eego, g.tec g.HIamp).
- **Research dry**: 32-128 active dry electrodes (g.tec g.Nautilus, Cognionics Quick-30).
- **Prosumer/consumer**: OpenBCI Cyton (8/16-ch), Emotiv EPOC X (14-ch), Muse 2 (4-ch), NextMind/Snap (visual cortex band), Neurable Enten (focus headphones), Neurosity Crown.

  **Use cases**: P300 spellers (Farwell & Donchin 1988 — still the workhorse for ALS communication research); SSVEP BCIs (40-100+ bits/min with high-frequency flicker grids); motor-imagery BCIs (Pfurtscheller, Wolpaw, Birbaumer schools); neurofeedback for ADHD, anxiety, peak-performance training (controversial efficacy).

  **Strengths**: Non-invasive, low-cost, ubiquitous; suitable for at-home use and consumer products.
  **Weaknesses**: Information rate orders of magnitude below intracortical (~10-100 bits/min realistic); susceptibility to EMG, EOG, line-noise, electrode-impedance drift; setup time and user discomfort with wet electrodes.

  #### 6. Optical and Other Non-Invasive Modalities

- **fNIRS** (functional near-infrared spectroscopy): Hemodynamic signal through 1-3 cm cortical depth; ~3-5 s temporal resolution. Vendors: NIRx, Artinis, Hitachi ETG, **Kernel Flow** (time-domain fNIRS, 52 modules, 100k+ channels in a wearable helmet); Bryan Johnson's Kernel pivoted into research-services. Used for prefrontal-cortex monitoring, BCI control in motor-imagery paradigms, and Open-fNIRS academic research.
- **MEG** (magnetoencephalography): SQUID-based systems (Elekta, CTF) require cryogenics; **optically-pumped magnetometers (OPM-MEG)** from Cerca Magnetics, FieldLine, and QuSpin enable wearable, ambulatory MEG and are a UK strength (Nottingham Sir Peter Mansfield Imaging Centre, UCL Wellcome Centre for Human Neuroimaging).
- **Functional MRI BCI**: Real-time BOLD neurofeedback at 1.5-7 T; 1-2 s temporal resolution, mm spatial; primarily research-grade.
- **Functional Ultrasound (fUS)**: Emerging modality from Forest Neurotech (US) and Iconeus (FR) measuring cerebral blood-volume changes at sub-mm spatial resolution through small acoustic windows.

### Components / Architecture

A typical implanted BCI is a layered pipeline of biocompatible, low-power, real-time subsystems engineered against tight constraints: cortical-tissue safety limits the total electrical power deliverable into brain parenchyma to ~40 mW/cm² (to keep temperature rise <1 °C per FDA-recommended thermal limits); a fully implanted device with no transcutaneous wires must rely on inductive coupling or rechargeable battery, capping continuous-operation power to ~10-100 mW total; data telemetry must transmit 100 kbit/s – 1 Gbit/s of neural data through 5-10 mm of scalp, skull, dura, and ~3 mm of skin; and every materials choice must satisfy 5-20-year biocompatibility (ISO 10993), MRI-conditional safety (most clinical contexts require 1.5-3 T scanner compatibility), and explant-without-tissue-damage requirements.

#### A. Implanted Hardware

1. **Electrode interface**: 16-10,000+ recording sites in platinum, iridium oxide, PEDOT:PSS, **graphene** (Inbrain Neuroelectronics, ICN2 Barcelona), or carbon-nanofibre. Site impedance 10 kΩ – 1 MΩ at 1 kHz. Coatings reduce impedance and improve charge-injection capacity for stimulation.
2. **Front-end ASIC**: Low-noise amplifiers (~2-5 μV RMS input-referred noise), programmable-gain stages, anti-alias filters, 10-16-bit ADCs sampling at 20-30 kHz/channel. On-chip spike detection and feature extraction reduce telemetry bandwidth by 10-1000×.
3. **Stimulation driver**: Current-controlled biphasic, charge-balanced pulses ~10-500 μA, 100-500 μs/phase, 1-300 Hz pulse rate; safety-of-charge-density limits per Shannon equation (k = log(D)+log(Q) ≤ 1.85).
4. **Telemetry and power**: Inductive coupling 2-13.56 MHz for power; ultra-wideband (UWB), Bluetooth Low Energy, or 2.4-GHz proprietary radios for data; emerging optical (Galvani Bioelectronics) and ultrasonic (Neural Dust, Maharbiz/Carmena) links for deep, mm-scale free-floating implants.
5. **Encapsulation**: Hermetic titanium or ceramic for active electronics; polyimide, parylene-C, liquid-crystal polymer, or silicone for flexible leads; biocompatibility tested per ISO 10993.

#### B. External Processing

1. **Receiver/host**: Worn or bedside unit handling demodulation, packet recovery, real-time DSP.
2. **Decoder**: Runs Kalman, LDA, RNN, transformer, or Mamba models. Latency budget for closed-loop motor BCI is ~20-100 ms end-to-end.
3. **Calibration and adaptation**: Online recalibration to accommodate non-stationary neural signals (closed-loop decoder adaptation Orsborn et al. 2014; continual learning Sussillo et al. 2016).
4. **Application layer**: Cursor and click drivers (HID emulation), iOS/macOS accessibility APIs (Apple AAOP integration), AR/VR headsets, robotic arms, FES sleeves, speech synthesisers, smart-home control, and wheelchairs.

#### C. Surgical Platform

Robotic insertion is increasingly important: Neuralink R1 inserts 64 threads in ~20 minutes with sub-millimetre precision while avoiding surface vasculature using machine-vision. Precision Neuroscience's procedure uses a sub-millimetric cranial slit. Synchron requires only a jugular venous catheterisation. Conventional Utah-array implantation remains a craniotomy with pneumatic high-velocity insertion (Normann pneumatic inserter, 8-9 m/s impact velocity).

#### D. Decoding-Pipeline Software Stack

Modern BCI decoders are increasingly cloud-augmented but with on-device fallback. A canonical 2025-era stack comprises: (1) **real-time spike sorting** using Kilosort 4, Mountainsort 5, or on-chip template-matching ASICs; (2) **feature engineering** producing firing-rate, LFP-band-power, and high-γ envelope features at 50-100 Hz update rate; (3) **decoder model** — for motor control, a Kalman filter (50 ms latency, low compute) or LSTM/GRU (100-200 ms latency, higher accuracy); for speech, a stacked RNN-transformer encoder feeding into a phoneme decoder coupled to a 1-3B-parameter language-model rescorer (Gemma, Phi, on-device LLaMA variants); (4) **task interface** — HID emulation for cursor/keyboard, ROS for robotic-arm control, Apple BCI HID protocol for iOS/macOS accessibility, Bluetooth LE GATT profile for wheelchair/FES interfaces; (5) **online adaptation** — Bayesian decoder retuning per-session, Kalman gain self-calibration, recursive least squares, or continual fine-tuning of neural decoders against gold-standard target trajectories elicited by structured calibration tasks; (6) **safety and integrity layer** — anomaly detection on neural signal quality (impedance drift, common-mode noise, EMG contamination), stimulation watchdog timers, charge-balance audit, and clinician override.

#### E. Surgical and Clinical Workflow

A full BCI clinical deployment involves: pre-operative high-resolution structural and functional MRI (3-7 T anatomical, BOLD fMRI for motor/speech localisation, diffusion tractography); intraoperative neuro-navigation (Brainlab, Medtronic StealthStation, ROSA surgical robot); awake craniotomy with electrocorticography mapping for eloquent-cortex avoidance; implantation (Utah array, Neuralink threads, Precision film, or Synchron stent); peri-operative imaging confirmation (CT, post-implant MRI within MRI-conditional limits); 1-4-week post-operative rest period; structured calibration sessions across 2-12 weeks producing initial decoder; longitudinal in-home use with weekly-to-monthly recalibration; and ongoing engineering, neurology, occupational-therapy, and speech-and-language-therapy support throughout the device lifetime.

### Neural Decoders: Algorithmic Approaches

The decoder is the computational heart of a BCI. The space of decoding algorithms has evolved across four eras:

#### Era 1: Linear and Bayesian (1990s-2010s)

- **Linear regression / Wiener filter**: map firing-rate vectors to continuous kinematics y = Wx + b. Simple, interpretable, sub-millisecond inference. Used in Wessberg/Nicolelis 2000 primate BMI demonstrations.
- **Population vector** (Georgopoulos 1986): each neuron contributes a preferred-direction-weighted vote; the population mean predicts intended movement direction. Conceptually clean, widely-used in motor-cortex BMIs.
- **Kalman filter** (Wu, Black, Donoghue 2002-2008): state-space model with linear-Gaussian dynamics and observation models; produces optimal posterior estimate of kinematic state under those assumptions. Variants include the steady-state Kalman, ReFIT (recalibrated feedback intention-trained) Kalman, and Kalman with offset correction. Remains the workhorse of clinical BrainGate motor BCIs.
- **Linear Discriminant Analysis (LDA)**: workhorse classifier for discrete BCI commands and P300 spellers.
- **Logistic regression / Naïve Bayes / SVM**: discrete-command BCIs and EEG motor-imagery classification.
- **Common Spatial Patterns (CSP)** (Müller-Gerking et al. 1999, Blankertz et al. 2008): linear spatial filtering that maximises variance ratio between two classes; foundational for EEG motor-imagery decoding.
- **Riemannian-geometry tangent-space methods** (Barachant et al. 2012, Congedo et al. 2017): treat covariance matrices as points on a Riemannian manifold; achieves state-of-art EEG classification with minimal calibration.

  #### Era 2: Recurrent Deep Learning (2015-2022)

  Long Short-Term Memory networks (Hochreiter & Schmidhuber 1997) and Gated Recurrent Units enabled sequence-to-sequence neural decoding. Sussillo, Stavisky, Kao et al. 2016 demonstrated LSTM-based motor decoders outperforming Kalman filters by 30-50% on neural population activity. Pandarinath et al. 2017 used RNN decoders for handwriting BCIs and Willett et al. 2021 reached 90 char/min on handwritten characters from a Utah array. Bidirectional RNN encoders, attention mechanisms, and CTC loss enabled the breakthrough Willett et al. 2023 *Nature* speech BCI at 62 wpm.

  #### Era 3: Transformers and State-Space (2022-2025)

  Transformer architectures (Vaswani et al. 2017) applied to neural sequences: Neural Data Transformer (NDT, Ye & Pandarinath 2021), POYO (Azabou et al. 2023) — a cross-subject, cross-task neural foundation model trained on 158 sessions across 9 datasets, demonstrating few-shot transfer to held-out subjects. Brain-LM, NeuroFM, and the Stanford BrainBERT family. Mamba state-space models (Gu & Dao 2024) offer linear-time alternatives to transformer attention with comparable accuracy on long neural sequences — particularly attractive for on-device implant decoders.

  #### Era 4: Foundation Models and LLM-Augmented Decoding (2024-)

  Card et al. 2024 (*NEJM*) demonstrated a fully self-calibrating speech BCI integrating an RNN-CTC phoneme decoder with a large-language-model rescorer (GPT-style); the rescorer constrains decoded phoneme lattices to grammatically and semantically plausible sentences, sharply reducing word-error rate. Wairagkar et al. 2025 streamed transformer outputs into a Gemma-2 9B on-device LLM running real-time, achieving conversational latency. The principle generalises beyond speech: any low-bit-rate cortical-intent signal becomes useful if paired with a powerful prior model. This is the modern decoder paradigm.

  Open benchmarks driving the field: **Neural Latents Benchmark** (Pei et al. 2021); **MOABB EEG benchmarks** (Aristimunha et al. 2024); **BCI Competition I-V** datasets; **POYO/NDT cross-subject benchmarks**; **OpenBMI** (Korea Brain BCI dataset, Lee et al. 2019); **BlackrockNF/Falcon Benchmarks** (2024).

### Use Cases / Major Families

#### 1. Motor Restoration in Tetraplegia and ALS

- **BrainGate consortium** (Brown, Stanford, MGH, Case Western, Pittsburgh, Providence VA): foundational human trials since 2004. Hochberg et al. 2006 (*Nature*) demonstrated point-and-click cursor control by Matthew Nagle from a Utah-array implant; Hochberg et al. 2012 (*Nature*) — Cathy Hutchinson self-feeding with a DEKA arm; Aflalo et al. 2013 (*Science*) — Caltech posterior-parietal-cortex 7-DOF control by Erik Sorto; Collinger et al. 2013 (*Lancet*) — Pittsburgh Jan Scheuermann high-DOF prosthetic arm; Bouton et al. 2016 (*Nature*) Battelle/Ohio State NeuroLife reanimating Ian Burkhart's paralysed hand via cortical-to-muscle FES; Ajiboye et al. 2017 — full-arm FES.
- **Neuralink Telepathy**: Noland Arbaugh (28 January 2024, C4-C5 SCI) achieved cursor control for chess, Civilization VI, and Mac OS use; Bradford Smith (March 2025, ALS) became the third human and first ALS recipient, using Telepathy to edit and publish YouTube videos.
- **Synchron Stentrode COMMAND trial**: Multiple US patients with ALS and SCI using endovascular BCI for tablet control at home.

  #### 2. Speech Restoration

- **UCSF Chang lab** — Moses et al. 2021 (*NEJM*) "Pancho" 50-word vocabulary decoded from ECoG in ALS-related anarthria; Metzger et al. 2023 (*Nature*) and Littlejohn et al. 2024 multimodal decoding of voice and avatar at **78 wpm** with personalised voice reconstruction; Wairagkar et al. 2025 streaming decoder.
- **Stanford BrainGate** — Willett et al. 2023 (*Nature*) Utah-array speech BCI at **62 wpm** with 23.8% word error rate on a 125,000-word vocabulary using RNN decoders.
- **Caltech / USC** — Wandelt et al. 2024 (*Nature Human Behaviour*) supramarginal-gyrus single-neuron decoding of internal speech.

  #### 3. Sensory Restoration

- **DARPA HAPTIX programme** (2015-2022): intracortical microstimulation of S1 producing percepts of touch and proprioception (Flesher et al. 2016 *Science Translational Medicine*; Cronin et al. 2024 closed-loop somatosensory feedback during prosthetic-arm tasks).
- **Argus II** (Second Sight, retina, 60 electrodes — discontinued 2022 leaving 350 implant recipients in regulatory limbo, a cautionary case-study in neurotech business risk).
- **Orion** (Second Sight cortical visual prosthesis programme transferred to **Cortigent** 2022), **CortiVis** (Spain), and **Phosphoenix** EU projects: cortical visual prostheses producing phosphene-based vision.
- **Cochlear implants** (Cochlear, MED-EL, Advanced Bionics): the most successful neural interface in human history, 1M+ recipients globally — sometimes excluded from the BCI definition because they stimulate the auditory nerve rather than the brain, but functionally equivalent.

  #### 4. Closed-Loop Neuromodulation

- **Deep Brain Stimulation (DBS)** for Parkinson's, essential tremor, dystonia, OCD, and (under investigation) Tourette syndrome, refractory depression, and Alzheimer's memory enhancement. Vendors: Medtronic Activa/Percept (sensing-enabled), Boston Scientific Vercise Genus, Abbott Infinity. ~200,000 cumulative implants worldwide; Percept PC and Genus enable closed-loop adaptive DBS based on subthalamic-nucleus β-band biomarkers (Little et al. 2013).
- **Responsive Neurostimulation (NeuroPace RNS System)**: closed-loop epilepsy device with ~4,000 implants; detects ictal patterns and delivers cortical stimulation to abort seizures.
- **Subcallosal-cingulate DBS for treatment-resistant depression** (Mayberg 2005; BROADEN trial failed primary endpoint 2017 but biomarker-guided responder analyses ongoing; Abbott's depression-DBS programme received FDA Breakthrough 2022).
- **Spinal cord stimulation for paralysis**: **Onward Medical ARC-EX** (non-invasive) and **ARC-IM** (implanted) systems following the Courtine-Bloch CHUV Lausanne STIMO and STIMO-HEMO trials restoring volitional standing and stepping in chronic paraplegics (Wagner et al. 2018; Rowald et al. 2022).
- **Vagus Nerve Stimulation (LivaNova SenTiva, SetPoint Medical)** for refractory epilepsy, depression, and (investigational) rheumatoid arthritis and post-stroke rehabilitation.

  #### 5. Communication and AR/VR / Consumer Adjacent

- **Cognixion ONE**: gaze-plus-EEG AR headset for ALS communication.
- **Apple Vision Pro**: eye-tracking + hand-pinch as a neural-adjacent input modality; Apple's 2024 BCI HID protocol (announced May 2024) explicitly supports Synchron Stentrode and Neuralink as switch-control devices via the Apple Accessibility Framework.
- **Meta CTRL-Labs EMG wristband**: not a BCI in the strict sense (peripheral nerve, not CNS) but commercialises high-bandwidth neuromuscular decoding for AR/VR (Meta Orion glasses 2024 prototype, neural wristband planned for general release).
- **Snap NextMind**: discontinued 2022 after Snap acquisition; technology re-emerging in Snap Spectacles Gen 5.
- **Neurable Enten**: consumer focus-monitoring headphones using dry-electrode EEG.
- **Muse / Emotiv / Neurosity**: meditation, neurofeedback, and developer EEG platforms.

  #### 6. Research and Defence Applications

- **DARPA Next-Generation Nonsurgical Neurotechnology (N3) programme**: $104M 2018-2024 funding six teams (Battelle, Carnegie Mellon, Johns Hopkins APL, PARC, Rice, Teledyne) to develop high-bandwidth non-invasive BCIs for warfighter applications.
- **DARPA Targeted Neuroplasticity Training (TNT)** and **Restoring Active Memory (RAM)** programmes.
- **IARPA MICrONS** mouse-cortex connectomics (relevant for next-gen decoding architectures).
- **DARPA HAPTIX** (Hand Proprioception and Touch Interfaces, 2014-2022) for sensorimotor restoration in amputees.
- **DARPA RAM Replay** (Restoring Active Memory) targeting episodic memory encoding/decoding via hippocampal stimulation.
- **DARPA Subnets** for subnetwork stimulation in psychiatric disorders.
- **NIH BRAIN Initiative U01 / U19 cooperative agreements** funding multi-site neuro-engineering consortia at >$200M annual run-rate through 2026.

  #### 7. Neurorehabilitation and Stroke Recovery

  Beyond pure replacement of lost function, BCIs are increasingly used as **rehabilitation devices** that drive neuroplasticity to restore biological function. The principle (Birbaumer, Cohen, Ang, Soekadar): a BCI detects motor-imagery in residual cortical tissue and triggers a peripheral movement (FES sleeve, robotic exoskeleton, rubber-hand illusion) closing the sensorimotor loop and inducing Hebbian plasticity. Multi-centre RCTs (Cervera et al. 2018 meta-analysis; Mrachacz-Kersting and Aliakbaryhosseinabadi 2021 systematic review) show statistically and clinically significant improvements in upper-limb Fugl-Meyer Assessment scores in chronic-stroke patients. The Soekadar/Birbaumer stroke-BCI exoskeleton and Ang's Singapore NUS NeuroStyle systems are leading examples; UK trials are emerging via NIHR-funded Newcastle, Sheffield, and Manchester stroke-rehabilitation programmes.

### Academic Context

BCI research now spans dozens of major laboratories, the most influential of which include:

- **Brown University / Providence VA / Massachusetts General Hospital / Stanford** (BrainGate consortium): John Donoghue (founding PI), Leigh Hochberg, Krishna Shenoy (1969-2023), Jaimie Henderson, Frank Willett, Sergey Stavisky, David Brandman.
- **University of California San Francisco**: Edward Chang (speech BCIs), Karunesh Ganguly (motor BCIs and stroke rehabilitation).
- **University of California Berkeley**: Jose Carmena, Michel Maharbiz (neural dust), Rikky Muller.
- **Caltech**: Richard Andersen (posterior-parietal-cortex BCI, Aflalo et al.), Tyson Aflalo, Charles Liu.
- **University of Pittsburgh**: Andrew Schwartz, Jennifer Collinger, Rob Gaunt (sensory BCI).
- **Duke University**: Miguel Nicolelis (early primate BMI; Walk Again Project World Cup 2014 demo).
- **Northwestern / Shirley Ryan AbilityLab**: Lee Miller, Sara Solla.
- **École polytechnique fédérale de Lausanne (EPFL) / CHUV**: Grégoire Courtine, Jocelyne Bloch (spinal-cord stimulation, Onward Medical spinout).
- **Universiteit Maastricht / Donders Institute Nijmegen**: Pim Haselager, Nick Ramsey (Utrecht UMC long-term home BCI).
- **Tsinghua University**: Bo Hong (high-speed SSVEP BCIs; Tsinghua Wireless BCI dataset).

  **UK research nodes** (expanded in the UK Context section below): Imperial College London (Centre for Bio-Inspired Technology, Brain Sciences), UCL (Institute of Neurology Queen Square, Wellcome Centre for Human Neuroimaging, Sobell Motor Neuroscience), Oxford (MRC Brain Network Dynamics Unit, Nuffield Department of Clinical Neurosciences), Cambridge (Cambridge Centre for Brain Repair, MRC CBSU, Engineering Department neuro-electronics), Newcastle (Andrew Jackson Lab), Edinburgh (Centre for Clinical Brain Sciences, Patrick Wild Centre), Manchester (Manchester Centre for Health Informatics, Royal Infirmary functional neurosurgery), Sheffield (SITraN), Nottingham (Sir Peter Mansfield Imaging Centre and Cerca Magnetics OPM-MEG), Bristol (Bristol Neuroscience, MRC IEU), Strathclyde (rehabilitation BCI).

  Major conferences and journals: *Society for Neuroscience* annual meeting (~30,000 attendees), *Cognitive Computational Neuroscience (CCN)*, *IEEE EMBC*, *IEEE Neural Engineering Conference*, *International BCI Meeting (Asilomar/Brussels biennial)*, *Brain-Computer Interfaces* (Taylor & Francis), *Journal of Neural Engineering* (IOP), *Nature*, *Nature Neuroscience*, *Nature Biomedical Engineering*, *Nature Communications*, *Neuron*, *Science Translational Medicine*, *NEJM*, *Lancet*, *eLife*, *Cell Reports Methods*, *Brain Stimulation*, and *Journal of Neuroscience Methods*. Open neural-data infrastructure increasingly important: **Distributed Archives for Neurophysiology Data Integration (DANDI)**, **OpenNeuro**, **NeuroVault**, **Open Source BCI competitions (BCI Award, BCI Competition I-V)**, **Neural Latents Benchmark (NLB)**, **MOABB EEG benchmarks**, **POYO/NDT cross-subject foundation-model datasets**, and **EBRAINS** (European Brain Research Infrastructure) all enable reproducible benchmarking and the deep-learning revolution in neural decoding.

  Key training pipelines: NIH-funded T32 graduate programmes (e.g. Carnegie Mellon CNBC, Brown NeuroEngineering, Pittsburgh NEPTNE); Marie Skłodowska-Curie ITN networks (NeuTouch, INCIPIT); UK EPSRC Centres for Doctoral Training (Imperial Neurotechnology, Edinburgh Biomedical AI); DARPA Young Faculty Awards; and the BRAIN Initiative Neuroethics consortium ensuring ethics training is integrated into technical curricula.

### Current Landscape (2026)

The BCI sector in 2026 looks fundamentally different from even five years ago.

**Companies and capitalisation**:

- **Neuralink** (Elon Musk, 2016) — three human implants (Arbaugh Jan 2024, second patient Aug 2024, Bradford Smith Mar 2025), pursuing FDA approval for the Telepathy device, $1.5B raised through late 2024 at a $8B+ valuation; 1024-electrode N1 with R1 surgical robot.
- **Synchron** (Tom Oxley, 2012) — Stentrode endovascular BCI, COMMAND and SWITCH trials, ~10 implanted patients in home use, FDA pivotal trial entering 2025; backed by Bezos, Gates, ARCH; $145M Series C 2022; Apple BCI HID partnership 2024.
- **Paradromics** (Matt Angle, 2015) — Connexus 1024-channel cortical module, first human implant June 2024; FDA Breakthrough; $33M Series A.
- **Precision Neuroscience** (Ben Rapoport, Michael Mager, 2021) — Layer 7 Cortical Interface, FDA 510(k) clearance April 2025 for short-term use; >35 human surgical cases for temporary intra-operative recording; $135M raised; pursuing permanent-implant breakthrough pathway.
- **Blackrock Neurotech** (founded 2008 from Utah-array technology) — supplies Utah arrays to virtually every academic intracortical BCI lab; consumer arm "MoveAgain" pivoted.
- **Onward Medical** (Lausanne, 2014) — Euronext-listed; ARC-EX FDA De Novo clearance Dec 2023 for upper-limb function in SCI; ARC-IM in clinical trial.
- **Inbrain Neuroelectronics** (Barcelona, 2020) — graphene cortical interfaces; first-in-human surgery June 2024; CE-marked clinical trial.
- **Motif Neurotech** (Houston, 2021) — minimally-invasive wireless DBS implant for depression; pre-clinical.
- **Forest Neurotech** (San Francisco, 2023) — functional-ultrasound BCI; $50M Schmidt Futures / ARCH Venture seed.
- **Cognixion** (Santa Barbara, 2014) — gaze+EEG ALS communication; FDA De Novo pursuit.
- **Kernel** (Bryan Johnson, 2016) — Flow TD-fNIRS helmet; pivoted from BCI to neuroscience-as-a-service.
- **Neurable, Emotiv, Muse, OpenBCI, Neurosity, g.tec, Brain Products, BrainCo, Cognionics, NextMind/Snap** — consumer and research EEG ecosystem.
- **Medtronic, Boston Scientific, Abbott, LivaNova, NeuroPace, Nevro, Saluda Medical** — established neuromodulation incumbents.

  **Clinical milestones 2023-2026**:

- Willett et al. 2023 (*Nature*) — 62-wpm speech BrainGate.
- Metzger et al. 2023 (*Nature*) — 78-wpm speech UCSF Pancho with avatar.
- Card et al. 2024 (*NEJM*) — BrainGate self-paced ALS communication.
- Neuralink first human Noland Arbaugh Jan 2024; Bradford Smith Mar 2025.
- Synchron Apple Vision Pro integration demo 2024.
- Precision Neuroscience FDA 510(k) Apr 2025.
- Inbrain Neuroelectronics first graphene cortical interface human surgery Jun 2024.
- Forest Neurotech first functional-ultrasound recordings in awake humans 2025.

  **Market**: Global BCI/neurotech market estimated $2.7B 2024 → ~$5B 2026 → $15-22B 2030 (Precedence Research, Grand View, MarketsAndMarkets converging estimates), dominated by neuromodulation (DBS, SCS, VNS, RNS) but with the implantable-BCI segment growing fastest from a small base.

### UK Context

The UK is a globally significant BCI ecosystem with strengths across academia, regulation, and clinical infrastructure, though commercial scale lags the US.

**Academic centres**:

- **Imperial College London** — Brain Sciences Programme; Adam Hampshire (cognitive neuroimaging, neurotech); Tim Constandinou (neural-interface ASICs, Centre for Bio-Inspired Technology); Daniel Leff (surgical fNIRS).
- **University of Oxford** — Centre for Neural Circuits and Behaviour (Akerman, Goodwin); MRC Brain Network Dynamics Unit (Magill, Mallet); Nuffield Department of Clinical Neurosciences (Aziz functional neurosurgery, Green DBS for chronic pain).
- **UCL** — Institute of Neurology Queen Square; Wellcome Centre for Human Neuroimaging (Friston, Holmes); Department of Medical Physics and Biomedical Engineering (Holder EIT, Brookes OPM-MEG, Hebden NIRS); Sobell Department of Motor Neuroscience.
- **University of Cambridge** — Cambridge Centre for Brain Repair; MRC Cognition and Brain Sciences Unit; the Brain Mind Forum; Department of Engineering neuro-electronics (Malliaras conductive polymers, Mannix microelectrode arrays).
- **University of Edinburgh** — Centre for Clinical Brain Sciences; Patrick Wild Centre; School of Informatics neural computation.
- **University of Manchester** — Manchester Centre for Health Informatics; Aalo Manoharan neurotech; Manchester Royal Infirmary functional neurosurgery.
- **Newcastle University** — Andrew Jackson Faculty of Medical Sciences (primate BMI, vagus-nerve stimulation, intracortical microstimulation); Patrick Degenaar (retinal/cortical visual prostheses); ARC Centre.
- **University of Sheffield** — Sheffield Institute for Translational Neuroscience (SITraN) and ALS research; Department of Computer Science (Mahmood Akhtar EEG signal processing).
- **University of Leeds** — School of Computing (EEG, motor-imagery BCIs).
- **University of Nottingham** — Sir Peter Mansfield Imaging Centre (Bowtell, Brookes OPM-MEG); Cerca Magnetics spinout — world-leading ambulatory OPM-MEG.
- **University of Bristol** — Bristol Neuroscience; Department of Engineering Mathematics (neural decoding); MRC Integrative Epidemiology Unit (neuropsychiatric genetics).
- **King's College London** — Institute of Psychiatry, Psychology and Neuroscience (IoPPN); Centre for Neuroimaging Sciences; Mick Lapeden DBS-depression research.
- **University of Strathclyde / Glasgow** — Andy Astell BCI rehabilitation; computer-vision-EEG hybrid systems.

  **Industrial / clinical**:

- **Cerca Magnetics** (Nottingham) — OPM-MEG wearable systems; £40M Series A 2024.
- **NeuroBio** (Cambridge) — neuromodulation pharma adjacent.
- **Magstim** (Whitland, Wales) — TMS systems for research and depression treatment.
- **Cambridge Bioaugmentation Systems / BIOS Health** (Cambridge) — peripheral-nerve and vagus-nerve closed-loop interfaces; FDA Breakthrough 2023.
- **Galvani Bioelectronics** (Stevenage, GSK/Verily JV) — bioelectronic medicines and small implantable nerve cuffs.
- **MintNeuro** (Imperial spinout) — neural-interface ASICs.
- **CamCog / Cambridge Cognition** — digital cognitive assessment; BCI-adjacent.
- **Faculty AI** (London) — neural-decoder ML services.

  **Regulation and funding**:

- **MHRA** — Medical Devices Regulation; UKCA marking; Software-as-a-Medical-Device guidance 2022; Innovative Devices Access Pathway (IDAP) 2024.
- **BSI** — Notified Body for UKCA and CE; key for neurotech Class III pathways.
- **ARIA (Advanced Research and Invention Agency)** — *Programmable Plants and Precision Neurotechnologies* programme £69M 2024-2030 funding next-generation high-channel-count, minimally-invasive BCIs through Tris Dyson and Jacques Carolan; an explicit attempt to seed a UK Neuralink-equivalent.
- **UKRI / MRC / EPSRC / Wellcome Trust** — substantial neurotechnology funding, including the £20M EPSRC Centre for Doctoral Training in Neurotechnology at Imperial.
- **NIHR** — National Institute for Health and Care Research clinical-trial infrastructure; **NHS** Specialised Commissioning for DBS, VNS, and RNS.
- **Office for Life Sciences** — neurotech included in 2024 Life Sciences Vision.
- **Royal Society** — *iHuman* report 2019 framed UK neurorights and neurotech-ethics debate; ongoing policy dialogue with House of Lords Science and Technology Committee.

  **Northern English industrial strengths**: Manchester (Royal Infirmary functional neurosurgery, Manchester Metropolitan computational neuroscience, AI Foundry, Manchester BCI Group, Christie NHS Foundation Trust neuro-oncology overlap); Leeds (computing-school BCI groups, NIHR Leeds Biomedical Research Centre, Leeds Teaching Hospitals NHS Trust neurosurgery, Centre for Computational Imaging and Modelling in Medicine CIMM); Sheffield (Sheffield Institute for Translational Neuroscience SITraN as the UK's leading ALS research centre with Pamela Shaw's chief-investigator role on multiple BCI-relevant trials, Royal Hallamshire Hospital neurosurgery, AMRC Advanced Manufacturing Research Centre for medical device manufacturing); Newcastle (Andrew Jackson Lab at Faculty of Medical Sciences for primate BMI and vagus-nerve stimulation, Newcastle Helix biotech cluster, Newcastle Hospitals NHS Trust functional neurosurgery, National Innovation Centre for Ageing); Liverpool (Walton Centre NHS Foundation Trust — the UK's only standalone neurology and neurosurgery hospital, performing one of Europe's largest DBS programmes and host to BCI clinical-trial infrastructure, University of Liverpool ALS research, Liverpool Health Partners regional cluster); Sunderland and the wider North East (NETPark life-sciences campus); and Hull (Hull York Medical School neural-engineering research).

  **UK-specific clinical and policy strengths**: the NHS provides a unified pathway for cohort recruitment of rare-disease patients (ALS via Motor Neurone Disease Association MNDA registries, SCI via UK Spinal Cord Injury Association SIA, locked-in syndrome via Headway and SLINT); NICE provides health-technology-assessment infrastructure that BCI vendors must navigate post-MHRA approval; the UK Biobank's 500K-participant resource includes neuroimaging in 100K participants, providing population-scale priors for normalising BCI signals; the Wellcome Leap Multi-Channel Psych programme (£60M 2022-2027) funds psychiatry-adjacent neurotech; and the BBSRC/EPSRC Industrial Biotechnology Catalyst supports biocompatible-electrode chemistry. Cross-sector convergence between AI (DeepMind, Faculty AI, Stability), neuroimaging (Oxford Nuffield Department of Clinical Neurosciences, Cambridge MRC CBSU), and medical devices is the structural advantage that UK policy is currently betting on via ARIA's neurotechnology programme.

### Future Directions (2026-2030)

**Channel scaling**: Paradromics, Neuralink, Precision Neuroscience, and Inbrain are converging on 10,000-100,000-channel cortical interfaces by 2028-2030; this enables full-vocabulary continuous speech decoding, multi-DOF whole-body avatar control, and dense somatosensory feedback.

**Minimally invasive convergence**: Synchron's endovascular approach, Precision's sub-pial film, Forest's functional ultrasound, Motif's stereotactic minimally-invasive DBS, and the Carmena/Maharbiz "neural dust" trajectory all aim to deliver high-bandwidth recording without craniotomy, dramatically expanding the addressable population.

**Closed-loop precision neuromodulation**: Biomarker-guided adaptive DBS for Parkinson's (Medtronic Percept), epilepsy (NeuroPace RNS), depression (Abbott trial), OCD, and Tourette syndrome will increasingly use real-time decoding to gate stimulation, replacing today's open-loop continuous stimulation.

**Speech BCIs in clinical care**: The current research pipeline (BrainGate, UCSF Chang, Stanford Henderson/Willett, Synchron) is on track to deliver FDA-cleared speech BCIs for locked-in ALS, brainstem-stroke, and severe anarthria patients by 2027-2029, with words-per-minute approaching natural-conversational rates (120-160 wpm).

**AR/VR-native consumer neural inputs**: Meta's CTRL-Labs EMG wristband and Apple's BCI HID accessibility protocol indicate that the first mass-market neural input will be peripheral-nerve EMG and BCI accessibility integration on smartphones and headsets; broader consumer brain-reading remains speculative through 2030 given EEG bandwidth limits.

**Foundation models for neural decoding**: Transformer and Mamba-state-space architectures pre-trained on cross-subject, cross-task, cross-modality neural recordings (POYO, NDT, Neural Latents Benchmark, Brain-LM) promise zero-shot or few-shot decoder generalisation, drastically reducing per-patient calibration time.

**Neurorights and regulation**: By 2030, expect FDA BCI device class definitions, IEEE 2731 v2, UNESCO binding neurotech ethics instrument, and 5-15 national jurisdictions adopting neurorights amendments following Chile's lead. The UK MHRA Innovative Devices Access Pathway is likely to be the principal route for high-channel-count BCI clinical entry in Britain.

**Hybrid AI-BCI agents**: BCIs paired with large language models (Apple Intelligence-class on-device LLMs, GPT-class cloud agents) form what some commentators call a "cognitive co-processor": the BCI provides intention signal, the LLM expands it into language, action plans, and tool-use. Willett et al. and Wairagkar et al. have already demonstrated LLM-augmented BCIs for typing and speech. This is the most plausible near-term path to BCIs being attractive for non-disabled users — not as a replacement keyboard, but as a low-bandwidth high-relevance intent channel to an AI agent.

**Risks and unsolved problems**: long-term electrode biocompatibility beyond 5-7 years (chronic foreign-body response, glial encapsulation, micromotion-induced electrode drift, parylene-C/polyimide delamination, signal-loss kinetics under continuous wireless telemetry power budgets); cybersecurity of wireless implants (FDA "Refuse to Accept" cyber-security guidance 2023 mandates threat-modelling, secure boot, signed firmware update, and TLS-equivalent encrypted links — yet many in-trial devices still use proprietary radios without independent third-party security review); informed consent in cognitively impaired populations including ALS-progressing aphasia, late-stage dementia, severe TBI, and locked-in syndrome where the BCI itself may be required to obtain meaningful assent (a chicken-and-egg ethical situation flagged by Lazaro-Munoz, Klein, and Goering); commercial viability when patient counts are small — the Second Sight Argus II retinal-prosthesis shutdown 2022 left ~350 implant recipients without manufacturer support, software updates, or repair pathway, becoming the field's defining cautionary tale and triggering both FDA "right-to-repair" discussions and proposals for mandatory escrow of firmware/training-data for orphaned neuroprostheses; mental-privacy and decoding-out-of-distribution mental states (preference inference, lie detection, emotional surveillance, advertising targeting, employment screening); military and surveillance applications (DARPA N3 and analogous PLA Chinese programmes raise dual-use concerns); equitable access — at projected $50K-$250K per implant procedure plus ongoing decoder cloud service, first-mover BCIs risk replicating cochlear-implant access inequalities documented in Blume's *The Artificial Ear* across global income lines; identity and self-continuity questions raised by long-term decoder co-adaptation (Klein, Goering, Yuste); and the regulatory open question of what happens when an FDA-cleared implant requires a cloud LLM or vendor-controlled decoder whose underlying model is deprecated, sunsetted, or acquired by an adversarial corporate successor.

**The 2030 vision**: by decade's end, a realistic synthesis of these threads is a clinical landscape in which (a) speech BCIs are first-line standard-of-care for ALS, locked-in syndrome, and severe brainstem stroke, with FDA labelling for at-home self-administered use; (b) closed-loop adaptive DBS replaces open-loop DBS for Parkinson's, essential tremor, and refractory OCD/depression; (c) Onward and successor spinal-cord-stimulation systems provide community-deployable gait restoration after SCI; (d) the prosumer market remains dominated by EEG/EMG (consumer-grade BCI for healthy users continues to fall short of bandwidth thresholds attractive vs. existing input modalities, with the exception of AR/VR-native pinch+gaze+EMG that Meta and Apple are normalising); (e) a robust UK BCI clinical-research network anchored by ARIA's Precision Neurotechnologies programme delivers two or three home-grown implantable-BCI companies competing internationally; and (f) global neurorights jurisprudence — beginning with Chile and UNESCO and propagating through national constitutional and consumer-protection law — establishes mental privacy, cognitive liberty, free will, equitable access, and identity-continuity as legally enforceable rights, with the UK MHRA, House of Lords Science and Technology Committee, and Information Commissioner's Office playing a coordinating role.

### Ethics, Neurorights and Regulation

BCIs are amongst the most ethically charged emerging technologies of the 21st century because they touch directly on the substrate of personhood. The principal frameworks include:

#### Neurorights (Yuste, Goering et al. 2017 in *Nature*)

The five proposed neurorights — articulated by Rafael Yuste's Columbia NeuroRights Foundation and endorsed by the OECD Recommendation on Responsible Innovation in Neurotechnology (2019) — are:

1. **Right to mental privacy** — protection from non-consensual decoding of neural activity for inference of preferences, beliefs, identity, sexuality, political opinion, or mental health states.
2. **Right to personal identity** — protection of the continuity of self against decoder-induced personality changes (documented in DBS literature, where patients report "I don't know who I am with the stimulator on or off").
3. **Right to free will / agency** — protection from coercive or undisclosed neural stimulation that influences decision-making.
4. **Right to fair access** — equitable distribution of cognitive-enhancement BCIs across socioeconomic strata to prevent neuro-stratification.
5. **Right to protection from algorithmic bias** — applicable to neural decoders whose training data may not represent demographic, neurological, or cultural diversity.

Chile became the first nation to amend its constitution (2021, Article 19 §1) to recognise mental integrity and brain data as legally protected. Spain, Brazil, France, Mexico, Colombia, Argentina, and the US (Colorado consumer-data law 2024 explicitly including "neural data") have followed with varying legislative instruments.

#### Regulatory Pathways

- **US FDA**: 2021 Draft Guidance on Implanted BCIs; Center for Devices and Radiological Health Q-submission pathway; Breakthrough Device Designation (granted to Synchron, Neuralink, Paradromics, Precision Neuroscience, Onward, Motif Neurotech, Inbrain, BIOS Health, others); 510(k), De Novo, and PMA pathways depending on novelty/risk.
- **EU MDR 2017/745**: Class III for active implantable BCIs; Notified Body review (BSI, TÜV SÜD, DEKRA); MDR transition period extended to 2027/2028 by Regulation 2023/607. UDI registration in EUDAMED.
- **UK MHRA**: post-Brexit UKCA marking (transition deadline now June 2030); Innovative Devices Access Pathway IDAP 2024 (a UK Breakthrough analogue); Software-as-a-Medical-Device guidance 2022; AI as a Medical Device Programme 2023-2025.
- **Standards**: **IEEE 2731** Unified Terminology for BCIs; **IEEE 3209** Neurotechnology Interoperability draft; **ISO 14708** Active Implantable Medical Devices (general); **IEC 60601-1** electrical safety; **ISO 10993** biocompatibility; **HL7 FHIR** for neural-data interchange; **IEEE Brain Initiative Standards Roadmap** 2024.
- **UNESCO 2024 Recommendation on the Ethics of Neurotechnology**: 193 member-state framework adopted November 2024; commits signatories to neuro-rights protection, equitable access, transparency, and accountability.
- **WHO 2023 Global Mental Health Strategy** — includes neurotech ethics dimensions.

  #### Ongoing Controversies

- Definition of "neural data" for consumer-protection purposes (Colorado, Minnesota, California state laws diverge).
- Whether consumer EEG headsets fall under neurorights frameworks or only implantable devices.
- Right-to-repair and orphaned-device liability post-Argus II.
- Decoder-as-a-service liability when commercial cloud LLMs underpin medical devices.
- Cross-border neural-data flows under GDPR Article 9 (special-category data).
- Workplace neuromonitoring (already in use in Chinese rail and trucking under EEG-fatigue-detection systems; emerging in EU and US debate as ETUC and Reuters reporting documented).

### Research and Literature

**Foundational and Pre-2010**:
1. Vidal, J.J. (1973). Toward direct brain-computer communication. *Annual Review of Biophysics and Bioengineering*, 2, 157-180. [Coined the term BCI]
2. Farwell, L.A., & Donchin, E. (1988). Talking off the top of your head: toward a mental prosthesis utilizing event-related brain potentials. *Electroencephalography and Clinical Neurophysiology*, 70(6), 510-523. [P300 speller]
3. Wolpaw, J.R., Birbaumer, N., McFarland, D.J., Pfurtscheller, G., & Vaughan, T.M. (2002). Brain-computer interfaces for communication and control. *Clinical Neurophysiology*, 113(6), 767-791. [Field-defining review]
4. Kennedy, P.R., Bakay, R.A., Moore, M.M., Adams, K., & Goldwaithe, J. (2000). Direct control of a computer from the human central nervous system. *IEEE Transactions on Rehabilitation Engineering*, 8(2), 198-202. [First chronic human implant]

**Intracortical motor and sensory BCIs**:
5. Hochberg, L.R., Serruya, M.D., Friehs, G.M., Mukand, J.A., Saleh, M., Caplan, A.H., Branner, A., Chen, D., Penn, R.D., & Donoghue, J.P. (2006). Neuronal ensemble control of prosthetic devices by a human with tetraplegia. *Nature*, 442(7099), 164-171. [BrainGate1]
6. Hochberg, L.R., Bacher, D., Jarosiewicz, B., Masse, N.Y., Simeral, J.D., Vogel, J., Haddadin, S., Liu, J., Cash, S.S., et al. (2012). Reach and grasp by people with tetraplegia using a neurally controlled robotic arm. *Nature*, 485(7398), 372-375. [Cathy Hutchinson]
7. Collinger, J.L., Wodlinger, B., Downey, J.E., Wang, W., Tyler-Kabara, E.C., Weber, D.J., McMorland, A.J., Velliste, M., Boninger, M.L., & Schwartz, A.B. (2013). High-performance neuroprosthetic control by an individual with tetraplegia. *Lancet*, 381(9866), 557-564.
8. Aflalo, T., Kellis, S., Klaes, C., Lee, B., Shi, Y., Pejsa, K., Shanfield, K., Hayes-Jackson, S., Aisen, M., Heck, C., Liu, C., & Andersen, R.A. (2015). Decoding motor imagery from the posterior parietal cortex of a tetraplegic human. *Science*, 348(6237), 906-910.
9. Bouton, C.E., Shaikhouni, A., Annetta, N.V., Bockbrader, M.A., Friedenberg, D.A., Nielson, D.M., et al. (2016). Restoring cortical control of functional movement in a human with quadriplegia. *Nature*, 533(7602), 247-250. [NeuroLife FES]
10. Flesher, S.N., Collinger, J.L., Foldes, S.T., Weiss, J.M., Downey, J.E., Tyler-Kabara, E.C., Bensmaia, S.J., Schwartz, A.B., Boninger, M.L., & Gaunt, R.A. (2016). Intracortical microstimulation of human somatosensory cortex. *Science Translational Medicine*, 8(361), 361ra141.

**Speech BCIs**:
11. Moses, D.A., Metzger, S.L., Liu, J.R., Anumanchipalli, G.K., Makin, J.G., Sun, P.F., Chartier, J., Dougherty, M.E., Liu, P.M., et al. (2021). Neuroprosthesis for decoding speech in a paralyzed person with anarthria. *New England Journal of Medicine*, 385(3), 217-227. [UCSF Pancho]
12. Willett, F.R., Kunz, E.M., Fan, C., Avansino, D.T., Wilson, G.H., Choi, E.Y., Kamdar, F., Glasser, M.F., Hochberg, L.R., et al. (2023). A high-performance speech neuroprosthesis. *Nature*, 620(7976), 1031-1036. [BrainGate 62-wpm speech]
13. Metzger, S.L., Littlejohn, K.T., Silva, A.B., Moses, D.A., Seaton, M.P., Wang, R., Dougherty, M.E., Liu, J.R., Wu, P., et al. (2023). A high-performance neuroprosthesis for speech decoding and avatar control. *Nature*, 620(7976), 1037-1046. [UCSF Ann 78-wpm with avatar]
14. Card, N.S., Wairagkar, M., Iacobacci, C., Hou, X., Singer-Clark, T., Willett, F.R., Kunz, E.M., Fan, C., Vahdati Nia, M., et al. (2024). An accurate and rapidly calibrating speech neuroprosthesis. *New England Journal of Medicine*, 391(7), 609-618.
15. Wandelt, S.K., Bjånes, D.A., Pejsa, K., Lee, B., Liu, C., & Andersen, R.A. (2024). Representation of internal speech by single neurons in human supramarginal gyrus. *Nature Human Behaviour*, 8(6), 1136-1149.

**Endovascular and surface BCIs**:
16. Oxley, T.J., Opie, N.L., John, S.E., Rind, G.S., Ronayne, S.M., Wheeler, T.L., Judy, J.W., McDonald, A.J., Dornom, A., et al. (2016). Minimally invasive endovascular stent-electrode array for high-fidelity, chronic recordings of cortical neural activity. *Nature Biotechnology*, 34(3), 320-327. [Stentrode]
17. Mitchell, P., Lee, S.C.M., Yoo, P.E., Morokoff, A., Sharma, R.P., Williams, D.L., MacIsaac, C., Howard, M.E., et al. (2023). Assessment of safety of a fully implanted endovascular brain-computer interface for severe paralysis in 4 patients: the Stentrode With Thought-Controlled Digital Switch (SWITCH) Study. *JAMA Neurology*, 80(3), 270-278.

**Neuromodulation and DBS**:
18. Little, S., Pogosyan, A., Neal, S., Zavala, B., Zrinzo, L., Hariz, M., Foltynie, T., Limousin, P., Ashkan, K., FitzGerald, J., et al. (2013). Adaptive deep brain stimulation in advanced Parkinson disease. *Annals of Neurology*, 74(3), 449-457.
19. Mayberg, H.S., Lozano, A.M., Voon, V., McNeely, H.E., Seminowicz, D., Hamani, C., Schwalb, J.M., & Kennedy, S.H. (2005). Deep brain stimulation for treatment-resistant depression. *Neuron*, 45(5), 651-660.
20. Wagner, F.B., Mignardot, J.-B., Le Goff-Mignardot, C.G., Demesmaeker, R., Komi, S., Capogrosso, M., Rowald, A., Seáñez, I., et al. (2018). Targeted neurotechnology restores walking in humans with spinal cord injury. *Nature*, 563(7729), 65-71. [Courtine/Bloch, Onward antecedent]
21. Rowald, A., Komi, S., Demesmaeker, R., Baaklini, E., Hernandez-Charpak, S.D., Paoles, E., Montanaro, H., Cassara, A., et al. (2022). Activity-dependent spinal cord neuromodulation rapidly restores trunk and leg motor functions after complete paralysis. *Nature Medicine*, 28(2), 260-271.

**Neural decoding methods**:
22. Wu, W., Gao, Y., Bienenstock, E., Donoghue, J.P., & Black, M.J. (2006). Bayesian population decoding of motor cortical activity using a Kalman filter. *Neural Computation*, 18(1), 80-118.
23. Pandarinath, C., O'Shea, D.J., Collins, J., Jozefowicz, R., Stavisky, S.D., Kao, J.C., Trautmann, E.M., Kaufman, M.T., Ryu, S.I., et al. (2018). Inferring single-trial neural population dynamics using sequential auto-encoders (LFADS). *Nature Methods*, 15(10), 805-815.
24. Willett, F.R., Avansino, D.T., Hochberg, L.R., Henderson, J.M., & Shenoy, K.V. (2021). High-performance brain-to-text communication via handwriting. *Nature*, 593(7858), 249-254.

**Hardware and electrodes**:
25. Maynard, E.M., Nordhausen, C.T., & Normann, R.A. (1997). The Utah intracortical electrode array: a recording structure for potential brain-computer interfaces. *Electroencephalography and Clinical Neurophysiology*, 102(3), 228-239.
26. Jun, J.J., Steinmetz, N.A., Siegle, J.H., Denman, D.J., Bauza, M., Barbarits, B., Lee, A.K., Anastassiou, C.A., Andrei, A., et al. (2017). Fully integrated silicon probes for high-density recording of neural activity. *Nature*, 551(7679), 232-236. [Neuropixels]
27. Musk, E. & Neuralink (2019). An integrated brain-machine interface platform with thousands of channels. *Journal of Medical Internet Research*, 21(10), e16194. [Neuralink white paper]

**Ethics, neurorights, and regulation**:
28. Yuste, R., Goering, S., Arcas, B.A. y, Bi, G., Carmena, J.M., Carter, A., Fins, J.J., Friesen, P., Gallant, J., et al. (2017). Four ethical priorities for neurotechnologies and AI. *Nature*, 551(7679), 159-163. [Foundational neurorights paper]
29. UNESCO (2024). *Draft Recommendation on the Ethics of Neurotechnology*. UNESCO General Conference. [Global ethics instrument]
30. US FDA (2021). *Implanted Brain-Computer Interface (BCI) Devices for Patients with Paralysis or Amputation — Non-clinical Testing and Clinical Considerations*. Draft Guidance, Center for Devices and Radiological Health.

### Provenance

- **domain-correction:** none (infrastructure retained — BCI is a hardware/interface concept; alternative classifications neurotechnology/biomedical-engineering noted as inferred domains)

## Metadata

- **Last Updated**: 2026-05-16
- **Review Status**: Comprehensive Phase 6 enrichment; queen-led Opus rewrite of original 35-line stub
- **Verification**: Academic sources cross-referenced against arXiv, *Nature*, *NEJM*, *Science*, *Lancet*, *Neuron*, IEEE Xplore, Nature Biomedical Engineering; commercial milestones cross-referenced against SEC filings, FDA Breakthrough/510(k) databases, company press releases (Neuralink Sep 2024, Synchron 2024, Precision Neuroscience Apr 2025, Paradromics Jun 2024, Inbrain Jun 2024, Onward Dec 2023); UK academic context against UKRI, MRC, ARIA, NIHR public funding announcements
- **Regional Context**: UK academic institutions (Imperial College London, University of Oxford, UCL, University of Cambridge, University of Edinburgh, University of Manchester, Newcastle University, University of Sheffield, University of Leeds, University of Nottingham, University of Bristol, King's College London, University of Strathclyde); Northern English clinical/industrial nodes (Manchester Royal Infirmary, Leeds NIHR BRC, Sheffield Institute for Translational Neuroscience SITraN, Newcastle Helix, Walton Centre Liverpool); UK companies (Cerca Magnetics, BIOS Health, Galvani Bioelectronics, Magstim, MintNeuro, NeuroBio, Faculty AI); regulatory framework (MHRA, BSI, NIHR, NHS Specialised Commissioning, ARIA Precision Neurotechnologies programme £69M)
- **Domain Classification**: Retained `infrastructure` reflecting BCI as biomedical hardware/interface infrastructure rather than a pure AI algorithm. Inferred sub-domains: neurotechnology, biomedical-engineering, human-computer-interaction, accessibility. No frontmatter `domain::` correction applied; alternative classifications recorded as `owl-inferred::` and `belongs-to-domain::` enrichment.
- **Production-Ready**: Complete OWL formal semantics covering compositional / dependency / capability / implementation / reduction / contrast axiom families; comprehensive substantive content (signal modalities, hardware components, decoding methods, clinical milestones, company landscape 2024-2026, UK ecosystem, future directions, ethics/regulation); 30 academic and regulatory citations spanning 1973-2025
- **Authority Score**: 0.87 (mature multi-decade clinical-translation field with foundational Vidal 1973 framing, first-in-human BrainGate 2004 and Neuralink 2024 deployments, $5B 2026 market projected $15-22B 2030, vigorous active research with 78-wpm speech BCI 2023-2024 milestones, well-developed FDA/MHRA/EU MDR regulatory frameworks, emerging neurorights jurisprudence Chile 2021 / UNESCO 2024, deep UK academic and ARIA investment £69M)

