
A critical capability is a kind of [[Agent Capability]] whose exercise is consequential enough to need distinct handling. It is the sibling of [[Restricted Capability]], and the two classes are disjoint. The Agent Ontology declares `CriticalCapability` without a definition; this one follows from its position and its one axiom.

The security-binding module declares it as a subclass of the core `Capability` with `owl:disjointWith` `RestrictedCapability`, under the heading that agents cannot claim conflicting capabilities.[^1] The threat-model module restates the axiom to prevent contradictory capability claims.[^2]

No capability may therefore belong to both classes, and a reasoner flags an agent whose declared capabilities fall into both. Which capabilities count as critical is for the deploying party to decide.

[^1]: Semantic Agent Communication Community Group, “Security Binding Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/security-binding.ttl
[^2]: Semantic Agent Communication Community Group, “Threat Model Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/threat-model.ttl

