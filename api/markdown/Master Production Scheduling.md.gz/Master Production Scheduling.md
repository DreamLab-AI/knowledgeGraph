Master production scheduling is the preparation of the master production schedule (MPS), which states which end items are to be produced, when they are needed and in what quantities, and is a primary input to material requirements planning.[^1]

A University of North Carolina Wilmington course module says the MPS is one of three primary MRP inputs, derives its quantities from the production plan of sales and operations planning, which is stated in product groups, and drives MRP with a schedule of finished products by week.[^1] Its quantities may combine customer orders and demand forecasts and represent what needs to be produced, not what can be produced.[^1] The module divides the schedule into windows set by time fences: frozen, where no changes are allowed; moderately firm or slushy, where specific changes are allowed within product groups as long as parts are available; and flexible or liquid, where significant variation is allowed as long as overall capacity requirements stay at the same levels.[^1]

Robinson, Sahin and Gao study the design of the MPS time interval in a two-stage rolling schedule. They simulate four design factors, including the frozen interval length and the non-frozen interval policy, and find that moving from a liquid to a slushy strategy increases the manufacturer's costs but may lower system costs when the vendor has low flexibility.[^2]

## Scope and distinctions

Beasley's OR-Notes use the phrase differently: the master production schedule is the plan for production, staffing and inventory, built at an aggregate level and cost driven.[^3] See [[Aggregate Planning]], [[Material Requirements Planning]] and [[Sales and Operations Planning]].

## What the sources do not establish

Usage of the phrase differs between a course module on MRP and the OR-Notes, and the simulation study is one model of one rolling-schedule setting, so no rule for the frozen interval length is given.[^1][^3][^2]

[^1]: Terry Janicki, University of North Carolina Wilmington, OPS 370 course module, “Materials Requirements Planning Module 11”. https://csbapp.uncw.edu/janickit/ops370/modules/Module11.pdf
[^2]: E. Powell Robinson Jr, Funda Sahin and Li-Lian Gao, International Journal of Production Research, 2008 (copy hosted by the University of Houston C. T. Bauer College of Business), “Master production schedule time interval strategies in make-to-order supply chains”. https://www.bauer.uh.edu/doctoral/scm/docs/sahin-1.pdf
[^3]: J. E. Beasley, OR-Notes, Brunel University London (originally Imperial College), “Master production schedule”. https://people.brunel.ac.uk/~mastjjb/jeb/or/masprod.html

