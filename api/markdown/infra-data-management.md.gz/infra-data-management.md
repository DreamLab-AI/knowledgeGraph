Taxonomy category root for Data Management within Infrastructure. The concept itself is described at [[Data Management]], which sits under this category; the category exists so the published graph can group its members.

