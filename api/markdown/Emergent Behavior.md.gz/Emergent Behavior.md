Emergent Behavior is complex, system-level behaviour that arises from the interactions of many simpler components or agents and is not explicitly programmed into any individual part. In AI-driven game agents and open-world simulations it produces lifelike, unscripted dynamics from local rules and agent decisions. Emergence is valued for richness and replayability but can be hard to predict, test, and control.

### Semantic Classification

### Content

## Compositional Relationships (Components)

```
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:hasPart ai:SelfOrganisation))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:hasPart ai:FeedbackLoop))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:hasPart ai:PhaseTransition))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:hasPart ai:CollectiveIntelligence))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:hasPart ai:NonlinearDynamics))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:hasPart ai:LocalInteractionRule))
```

## Dependency Relationships

```
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:requires ai:MultiAgentSystem))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:requires ai:AutonomousAgent))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:requires ai:EnvironmentModel))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:dependsOn ai:AgentBasedModelling))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:dependsOn ai:LocalInteractionRules))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:dependsOn ai:StochasticProcess))
```

## Capability Relationships

```
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:enables ai:SwarmIntelligence))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:enables ai:CollectiveIntelligence))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:enables ai:EmergentGameplay))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:enables ai:SocialSimulation))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:enables ai:InnovationDiffusion))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:enables ai:OpenEndedness))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:enables ai:EmergentCapabilities))
```

## Implementation Relationships

```
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:implements ai:ComplexAdaptiveSystems))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:implements ai:SelfOrganisation))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:implements ai:ArtificialLife))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:uses ai:CellularAutomata))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:uses ai:ReinforcementLearning))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:uses ai:GeneticAlgorithm))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:uses ai:GameTheory))
```

## Reduction Relationships

```
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:reducesTo ai:LocalInteractionRule))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:reducesTo ai:PhaseTransition))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:reducesTo ai:SelfOrganisation))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:reducesTo ai:NonlinearDynamics))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:reducesTo ai:AgentInteraction))
```

## Support and Contrast Axioms

```
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:supports ai:AIGameAgent))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:supports ai:AgentBasedModelling))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:supports ai:DigitalTwin))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:supports ai:SocialSimulation))
SubClassOf(ai:EmergentBehavior
  ObjectObjectComplementOf(ai:ScriptedBehavior))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:bridgesTo ai:EmergentCapabilities))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:relatedTo ai:MultiAgentReinforcementLearning))
SubClassOf(ai:EmergentBehavior
  ObjectSomeValuesFrom(ai:relatedTo ai:OpenEndedness))
```

## About

Emergent Behavior is the defining phenomenon of [[Complex Adaptive Systems]] science: the appearance of coherent, ordered, and often surprising global patterns from the iterated local interactions of many relatively simple components, without any external designer or central controller specifying the global outcome. Philip Anderson's 1972 essay "More is Different" in Science is the canonical scientific statement of this reductionist limit: higher levels of organisation — atomic to molecular to crystalline to biological to social — each require new concepts and laws not derivable from the level below, because the aggregate interactions produce qualitatively new phenomena. The slogan captures the principle: knowing every molecular bond in a water molecule does not tell you that water has surface tension, that ice floats, or that water waves propagate — these are emergent properties of the many-molecule system, not of individual molecules. Holland's 1998 formalisation in computational terms established a three-part characterisation of emergence applicable to [[Agent-Based Modelling]]: (i) the system consists of agents following local rules over a shared environment; (ii) global patterns arise that are not specified in any agent's rules; and (iii) the global patterns feed back on agent behaviour through environmental signals, making the system adaptive. This adaptive feedback loop distinguishes complex adaptive systems from merely complex systems: a turbulent fluid has emergent vortices, but the fluid molecules do not adapt their behaviour in response to the vortex structure; an ant colony has emergent trail networks, and individual ants do adapt their foraging route selection in response to pheromone concentrations that encode the emergent trail state, creating positive feedback that reinforces successful trails until the colony's collective foraging converges on near-optimal exploitation routes without any individual ant comprehending the global optimisation problem being solved.

The intellectual lineage of emergence research runs from the Santa Fe Institute's foundational work on [[Complex Adaptive Systems]] in the late 1980s — particularly Stuart Kauffman's NK fitness landscape models of biological evolution, Murray Gell-Mann's work on complex adaptive systems, and Holland's classifier systems and [[Genetic Algorithm]] — through Craig Reynolds' 1987 Boids paper that demonstrated three-rule emergence of flocking dynamics in computer simulation, Thomas Schelling's 1969-1971 residential segregation model showing how mild individual preferences produce stark aggregate segregation, and Conway's Game of Life (1970) demonstrating Turing-complete computation emerging from a four-rule deterministic cellular automaton. These foundational demonstrations established that emergence is computationally ubiquitous: any sufficiently interconnected system of locally-interacting components with feedback can generate genuinely surprising global order. Research in the 1990s and 2000s extended this to economics (the Santa Fe artificial stock market, Bak-Tang-Wiesenfeld self-organised criticality and power-law wealth distributions), ecology (individual-based population models, predator-prey emergence), and sociology (Axelrod's culture dissemination model, Epstein-Axtell's Sugarscape). By the 2020s, emergence had become central to two fast-moving research frontiers: [[Multi-Agent System]] coordination using [[Large Language Model]] as agent decision engines, where emergent social behaviours including event planning, information propagation, and norm formation arise from populations of LLM agents with individual persona descriptions (Park et al., 2023); and [[Emergent Capabilities]] in frontier LLMs, where qualitative capabilities such as [[Chain-of-Thought Reasoning]] and multi-step arithmetic appear abruptly past scale thresholds, with ongoing debate about whether these represent genuine cognitive phase transitions or measurement artefacts.

In [[AI Agent System]] engineering, emergence is simultaneously a design goal and a control challenge. Designers of [[Open World]] games, smart city simulations, [[Digital Twin]] architectures, and autonomous swarm systems want their systems to exhibit emergent richness — dynamic patterns no individual rule specified, creating replayability, narrative surprise, and adaptive response to unpredicted inputs. But the same unpredictability that makes emergence valuable makes it difficult to ensure that emergent behaviour stays within acceptable boundaries: unintended emergent outcomes in deployed AI systems include AI traffic optimisers in Seoul generating unexpected congestion on side streets as a by-product of route optimisation; smart thermostat and solar battery systems accidentally synchronising to create power-grid demand spikes; and multi-agent trading systems producing flash crashes through emergent feedback loops between automated trading strategies. These real-world cases illustrate why emergence is not merely a curiosity but a safety-relevant property of any deployed [[Multi-Agent System]] — and why the 2024-2025 AI safety community has identified emergent capability evaluation in frontier models as a central challenge, with the UK AI Security Institute conducting systematic dangerous capability evaluations across frontier models since November 2023.

## Components / Architecture

- **Local Interaction Rules**: The micro-level specifications governing each agent's behaviour — the fundamental substrate from which emergence arises. Local rules are defined over a limited neighbourhood (spatial proximity, network adjacency, or information access range) and do not reference or require knowledge of global system state. The rule set can range from minimal (three rules in Boids; birth/survival conditions in Conway's Life) to rich (dozens of weighted utility functions in The Sims; full LLM reasoning chains in generative agent simulations). The key design insight is that rule simplicity does not bound emergent complexity: a three-rule Boids model produces globally realistic flocking dynamics, while a cellular automaton with four rules (Conway) is Turing-complete and can simulate any computable process. Rule design is the primary lever of emergence engineering: changing a single rule parameter (e.g., the radius of a Boids agent's neighbourhood) can qualitatively shift the emergent regime from dispersed individuals to tight flocks to milling vortices.
- **Environment Model**: The shared world space that agents inhabit, sense, and modify — the coupling medium through which local interactions aggregate into global patterns. Environments range from discrete grids (Conway's Life; [[Cellular Automata]] models; Schelling's segregation grid) through continuous spatial domains (Boids 3D space; pedestrian social force models; ecological ABMs over GIS terrain) to abstract state spaces (economic models of market participation; social models of information network topology). Environmental feedback is essential to emergence: agents modify the environment (deposit pheromones, consume resources, broadcast information, price assets), and the modified environment in turn alters subsequent agent perceptions and actions. Without this bidirectional coupling — agents reading and writing to a shared environment — agents are merely executing independent programs, and true emergence cannot occur.
- **Feedback Loops and Self-Organisation**: The dynamic circuits through which emergent patterns reinforce or dampen themselves. Positive feedback amplifies small perturbations into coherent structures: ant trail formation through pheromone reinforcement; financial bubbles through momentum-chasing trading strategies; innovation adoption cascades through social proof and network externalities. Negative feedback provides stability and limits growth: resource depletion constraining population expansion; price competition reducing profit margins in crowded markets; predator population growth constrained by prey depletion. The interplay of positive and negative feedback loops at different timescales determines the qualitative regime of emergent dynamics: fixed-point attractors (stable equilibria); limit cycles (periodic oscillations); strange attractors (deterministic chaos); and power-law critical states (self-organised criticality at the boundary between order and chaos, as studied by Bak, Tang, and Wiesenfeld in 1987).
- **Phase Transitions and Critical Thresholds**: Many emergent systems exhibit sharp transitions between qualitatively distinct regimes as a control parameter crosses a critical value. In statistical physics, phase transitions between solid, liquid, and gaseous states involve all-or-nothing qualitative changes in macroscopic properties at thermodynamic critical points, driven by collective interaction effects. Analogous critical phenomena appear in [[Complex Adaptive Systems]]: the Ising model's magnetisation transition; the percolation threshold in random graphs where a giant connected component suddenly spans the network; the jamming transition in pedestrian flow where smooth flow suddenly crystallises into stop-and-go waves; and critically, the capability phase transitions in [[Large Language Model]] identified by Wei et al. (2022), where performance on tasks like multi-digit arithmetic and chain-of-thought reasoning jumps from near-random to substantially above random past model-size thresholds. Identifying critical thresholds in advance — before deploying systems that might exhibit undesired emergent regime shifts — is a central challenge for [[AI Agent System]] safety.
- **Stochasticity and Robustness**: Most emergent systems rely on stochastic variation — random fluctuations in agent decisions, environmental conditions, or initialisation — both for realism and for robustness. Stochasticity breaks symmetry in initialisation, allowing the system to explore the space of possible emergent outcomes rather than converging to a single deterministic attractor. The statistical distribution of emergent outcomes across many stochastic runs reveals the system's robustness: if all runs converge to qualitatively similar emergent patterns despite different random seeds, the emergence is robust; if outcomes vary widely, the system is sensitive to initial conditions (in the dynamical systems sense) or to specific stochastic events. Robustness analysis using [[Monte Carlo Simulation]] ensembles and Sobol-indexed [[Sensitivity Analysis]] quantifies how much each rule parameter contributes to variance in emergent outputs.
- **Adaptation and Learning**: The distinguishing feature of [[Complex Adaptive Systems]] compared to merely complex systems is that agents adapt their behaviour in response to system-level feedback, producing more sophisticated emergent phenomena than static rule sets can generate. Adaptation mechanisms include: [[Reinforcement Learning]] (agents update action policies based on received reward signals, enabling emergent specialisation and division of labour in [[Multi-Agent Reinforcement Learning]] populations); [[Genetic Algorithm]] (populations of rule sets evolve through variation and selection, producing emergent evolutionary dynamics); imitation and social learning (agents copy successful neighbours' strategies, producing emergent cultural norms and fashion dynamics); and Bayesian belief updating (agents revise world models based on observations, producing emergent epistemic coordination). In generative [[Agent-Based Modelling]] using [[Large Language Model]], the LLM provides an implicit adaptation mechanism: the agent's contextual reasoning over its memory and current situation produces contextually appropriate, personality-consistent behaviour without any explicit learning rule.

## Use Cases / Major Families

- **Game AI and Virtual Worlds**: [[AI Game Agent]] populations in [[Open World]] and simulation games exhibit emergent civilisation, ecology, and economy dynamics when agents pursue individual survival, resource, and social goals under shared world constraints. Dwarf Fortress (Bay 12 Games) is the canonical example: individual dwarves pursuing sleep, food, socialisation, and task goals produce emergent fortress economies, social tragedies, military disasters, and cultural institutions that no designer scripted. The Sims franchise demonstrates emergent daily life narratives from utility-AI agents managing multiple simultaneous drives. [[Open World]] titles like RDR2 and Cyberpunk 2077 use layered agent architectures to produce emergent street life, wildlife behaviour, and faction conflict from independently operating NPC populations. Emergent behaviours are experienced as the "aliveness" of virtual worlds — the quality that makes players feel they are in a world that exists independently of their presence.
- **Swarm Robotics and Autonomous Systems**: Physical robot swarms exhibit emergent collective behaviours — formation flying, stigmergic construction, foraging optimisation, collective navigation — from onboard sensing and local communication only. Applications include search-and-rescue (distributed area coverage without global map); environmental monitoring (ocean sensor swarms forming adaptive sensor networks); agricultural automation (crop inspection swarms using emergent spatial coverage); and military coordination (drone swarms using emergent tactical formations). [[Swarm Intelligence]] algorithms including Ant Colony Optimisation and Particle Swarm Optimisation are deployed in industrial scheduling and routing optimisation, treating the solution space as an environment over which virtual agents produce emergent optima.
- **Multi-Agent AI Systems**: Contemporary [[Multi-Agent System]] architectures using [[Large Language Model]] as agent decision engines exhibit emergent coordination, specialisation, and problem-solving that exceeds individual agent capabilities. In a 2024 study, multi-agent discussion systems where LLM agents argue in turns outperformed single-agent chain-of-thought on mathematical and reasoning benchmarks without additional training data. Agentic AI systems — orchestrators coordinating specialised sub-agents for research, coding, data analysis, and tool use — exhibit emergent task decomposition, error recovery, and workflow optimisation from agent-level interaction rules, producing system-level capabilities not specified in any individual agent's prompt or policy.
- **Financial Markets**: Emergent market dynamics — price discovery, volatility clustering, flash crashes, bubble-and-bust cycles — arise from the local trading decisions of heterogeneous market participants using diverse strategies. The Santa Fe artificial stock market demonstrated that heterogeneous agent populations using technical and fundamental analysis strategies produce emergent return distributions with fat tails and volatility clustering matching empirical market data, which homogeneous rational-expectations models cannot replicate. High-frequency trading [[Multi-Agent System]] are a deployed instance where emergent dynamics have produced unintended outcomes: the 2010 Flash Crash produced a 1000-point Dow Jones drop in minutes from emergent feedback between automated trading strategies without any individual strategy targeting this outcome.
- **Social and Urban Systems**: Emergent segregation, opinion clustering, cultural homogenisation and diversification, traffic congestion, and epidemic spread are studied through [[Agent-Based Modelling]] of individual-level social interaction rules. Real-world deployed instances of unintended emergence: AI traffic routing systems in Seoul producing unexpected secondary congestion as side-street drivers respond to primary-route route recommendations; smart grid demand management systems accidentally synchronising device activation to create demand spikes from individually rational household optimisation.
- **Biological and Ecological Systems**: Emergence in natural systems provides the empirical validation base for complex systems theory. Murmuration dynamics of starling flocks (emergent from three proximity rules validated against GPS-tracked individual trajectories); army ant bridge formation (emergent structural engineering from individual weight-and-position sensing rules); bacterial quorum sensing (emergent gene expression coordinated at population scale through chemical signal concentration thresholds); protein folding (emergent 3D structure from amino acid sequence through thermodynamic free energy minimisation across the conformational landscape). These biological cases provide the intuition and metaphors that motivate computational emergence research.
- **Epidemiology and Public Health**: One of the highest-consequence real-world applications of emergence modelling is epidemic spread, where individual-level infection, recovery, and mortality events produce emergent population-level epidemic curves, herd immunity thresholds, and healthcare demand surges. SIR and SEIR compartmental equation-based frameworks capture mean-field emergence analytically, while [[Agent-Based Modelling]] produces heterogeneity-aware emergent epidemic dynamics including super-spreader events, household cluster transmission, spatial containment effects, and healthcare capacity constraints. The COVID-19 pandemic (2020-2022) deployed this understanding at national policy scale: Imperial College London's CovidSim [[Epidemiological Modelling]] ABM produced emergent epidemic projections directly informing the UK March 2020 lockdown decision, demonstrating that emergent behaviour research has concrete, high-stakes real-world consequences that are not confined to theoretical or simulated domains.
- **Digital Twins and Cyber-Physical Systems**: [[Digital Twin]] architectures increasingly embed emergent behaviour simulation as their behavioural layer — modelling the autonomous decisions and interactions of individual entities (vehicles, workers, customers, market participants) that jointly produce emergent system-level dynamics. Real-time sensor data updates the twin's agent state continuously, making the emergent simulation a live projection of current and near-future system behaviour rather than a static pre-computed scenario. Smart city twins model emergent pedestrian flow, traffic congestion, energy demand spikes, and emergency response logistics from individual agent mobility decisions; factory floor twins model emergent workflow patterns, bottleneck formation, and quality anomaly propagation from individual machine and worker agent states; supply chain twins model emergent demand propagation, inventory oscillation (the Bullwhip effect), and disruption cascade dynamics from individual supplier, logistics, and retailer agent decisions.
- **LLM-Driven Social and Political Simulation**: Populations of [[Large Language Model]] agents exhibiting emergent social dynamics have been deployed for political simulation, public health communication modelling, and social science research. AgentSociety (2025) simulates large-scale societal dynamics with thousands of LLM-driven agents, studying emergent social norms, economic inequality, and political polarisation dynamics. Sentipolis (2025) incorporates emotion-aware LLM agents for crisis communication and political simulation, producing emergent public opinion dynamics from individual agent emotional responses to news events. These simulations raise fundamental questions about validity — do LLM agent populations, initialised from text corpora that over-represent specific cultural and linguistic perspectives, produce emergent dynamics that reflect real human social systems or reflect biases in the training data?

## Quantitative Characterisation of Emergence

Measuring emergence quantitatively requires information-theoretic frameworks that go beyond the qualitative identification of "surprising" global patterns. Several complementary approaches are established:

**Transfer Entropy (Schreiber, 2000)**: T(X→Y) quantifies how much knowledge of the history of variable X reduces uncertainty about the future of Y, beyond Y's own history. In emergent systems, high transfer entropy from collective state to individual behaviour and vice versa signals genuine bidirectional causal coupling — the signature of true emergence rather than independent parallel computation. Transfer entropy has been applied to financial market microstructure, neural population dynamics, and [[Multi-Agent System]] information networks.

**Integrated Information (Tononi, 2008)**: Phi (φ) measures the degree to which a system generates information beyond the sum of its independent subsystems. Systems with high phi are emergent in the sense that their collective computation is irreducible — decomposing the system into independent parts causes information loss. While computationally expensive for large systems, phi provides a principled measure of emergence strength applicable to both [[Agent-Based Modelling]] and neural network architectures.

**Synergistic Information (Williams and Beer, 2010)**: Partial information decomposition separates mutual information between agents and collective system state into unique, redundant, and synergistic components. Synergistic information — the portion of collective state that requires knowing all agents simultaneously and cannot be obtained from any agent subset — directly quantifies emergence: it measures what is genuinely produced by the collective interaction beyond what any individual provides. High synergy signals genuine emergence; high redundancy signals that individual agent properties already determine the collective state.

**Entropy Production and Dissipative Structure**: In Prigogine's (1977) thermodynamic framework, emergent systems are dissipative structures maintained far from equilibrium by continuous energy throughput, spontaneously organising into lower-entropy ordered states at the expense of higher entropy in their environment. Shannon entropy decreases as agents self-organise into coherent patterns; the rate of entropy production measures the thermodynamic cost of maintaining the emergent structure against diffusion and noise. ScienceDirect research (2025) applying these thermodynamic concepts to [[Agent-Based Modelling]] of swarm dynamics has quantified how local interaction rules modulated by environmental feedback give rise to emergent ordered structures through entropy-driven processes, with mutual information of agent state distributions capturing the evolving order-disorder balance during emergence.

## Formal Properties of Emergence

- **Weak vs. Strong Emergence**: Philosopher David Chalmers (2006) distinguished weak emergence — where higher-level properties are in principle deducible from lower-level rules, even if computationally intractable to derive — from strong emergence, where higher-level properties are genuinely irreducible to lower-level descriptions and require fundamentally new explanatory vocabulary. Almost all computational emergence in [[Agent-Based Modelling]], [[Swarm Intelligence]], and [[Multi-Agent System]] is weak emergence in this sense: given the agent rules and initial conditions, the emergent global behaviour is deterministically computed (or stochastically sampled), and in principle each macro-level observation is deducible from the micro-level. The philosophical importance of this distinction is that weak emergence does not contradict physicalism or computationalism: novel macro-level patterns do arise, but they are not causally independent of their micro-level substrate. For practical system design, however, weak emergence is still surprising and hard to predict in advance — the intractability of simulating large agent populations without running the simulation is equivalent for engineering purposes to the philosophical claim that the macro is not simply reducible to the micro. Strong emergence, if it exists, would imply properties that cannot be simulated even in principle from lower-level rules — a claim most associated with consciousness science rather than AI engineering, but relevant to ongoing debates about whether frontier [[Large Language Model]] exhibit genuine understanding irreducible to statistical next-token prediction.
- **Descriptive levels and hierarchical emergence**: Emergence is always relative to a descriptive level — a property is emergent with respect to a lower-level description if it is not present in or predicable from that description. This relativity means emergence is not a binary property of systems but a relationship between description levels: a traffic jam is emergent with respect to individual vehicle behaviours but not emergent with respect to a traffic-level model that already includes congestion dynamics. In hierarchical [[AI Agent System]] architectures — where individual agents have emergent group behaviours, groups of groups exhibit higher-level emergent dynamics, and the overall system exhibits meta-level emergent patterns — emergence must be tracked across all levels simultaneously. The MAEBE framework (2025) addresses this by distinguishing intra-agent emergence (unexpected behaviours arising within a single LLM agent's reasoning from its training), inter-agent emergence (capabilities arising from the interaction of multiple agents that are absent from individual agent evaluation), and system-level emergence (properties of the full multi-agent architecture not visible at any individual component level).
- **Measuring Emergence**: Quantifying emergence in computational systems requires information-theoretic measures that capture the degree to which macro-level patterns contain information not deducible from micro-level descriptions. Proposed measures include: transfer entropy (Schreiber, 2000) — the degree to which knowledge of the history of one variable reduces uncertainty about the future of another variable, capturing directed information flow in emergent dynamics; integrated information (Tononi's phi) — the degree to which a system generates information beyond the sum of its parts, originally proposed as a measure of consciousness but applicable to emergent collective information in agent systems; synergistic information (Barrett-Barnett partial information decomposition) — the portion of output information that requires simultaneous knowledge of all input variables and cannot be obtained from any subset. These measures are computationally expensive for large systems but are being developed into practical tools for emergent behaviour monitoring in production [[AI Agent System]].

## Emergence and AI Safety

The intersection of emergent behaviour and AI safety is one of the most important and least understood aspects of contemporary AI development. Emergent capabilities in frontier [[Large Language Model]] — where qualitative abilities appear at scale thresholds without explicit training for those abilities — represent a fundamental challenge to pre-deployment safety evaluation: if a dangerous capability does not exist in the pre-deployment evaluation model but emerges in the production model through capability jump, the standard evaluation pipeline will fail to detect it. The UK AI Security Institute has identified this as a primary concern, noting that dangerous capabilities may emerge as by-products of improvements in general capabilities, without being specifically targeted or desired by model developers.

Beyond capability emergence in individual models, emergent behaviour in deployed [[Multi-Agent System]] presents a complementary safety challenge. Systems designed to be individually safe can exhibit unsafe emergent behaviour at the system level: individually compliant agents coordinating to produce collectively non-compliant outcomes, individually honest agents producing collectively misleading outputs through emergent information filtering, or individually constrained agents combining capabilities through multi-step interaction to circumvent individual-level constraints. The MAEBE paper (2025) explicitly categorises "unplanned emergence" — unexpected system-level behaviours arising from agent interaction rules — as a safety-relevant phenomenon requiring monitoring infrastructure and intervention mechanisms in production agentic AI deployments.

Governance responses to emergent behaviour safety risks include: pre-deployment capability evaluation frameworks (Anthropic's Responsible Scaling Policy, OpenAI's Preparedness Framework, UK AISI evaluations) that specifically probe for dangerous capabilities at scale thresholds; red-teaming programmes where adversarial evaluation teams attempt to elicit undesired emergent behaviours from deployed systems; runtime monitoring of deployed [[Multi-Agent System]] for anomalous emergent dynamics; and international coordination frameworks (the Bletchley Declaration, November 2023; the Seoul AI Safety commitments, May 2024; the Paris AI Action Summit, February 2025) that establish shared standards for dangerous capability evaluation across frontier model developers. The AI Governance dimension of emergent behaviour is expected to be one of the dominant policy challenges in AI for the 2026-2030 period as frontier model capabilities continue to advance.

## Key Terminology

- **Emergence**: The appearance of properties at the collective/system level that are not present in or reducible to individual component descriptions.
- **Self-organisation**: The process by which emergent ordered structure arises from local interactions without external specification of the global order.
- **Phase transition**: A sharp, qualitative change in system-level properties as a control parameter crosses a critical threshold.
- **Complex Adaptive System**: A system of adaptive agents whose local interactions produce emergent global dynamics; the theoretical category encompassing emergent behaviour in biological, social, and artificial systems.
- **Emergence threshold**: The scale (model size, agent count, interaction density) at which a specific emergent property appears, analogous to a phase transition critical point.
- **Planned vs. unplanned emergence**: A distinction from the MAEBE (2025) framework between emergence intentionally used as an engineering strategy (planned) and unexpected system-level behaviours arising from agent interaction (unplanned).
- **Weak emergence**: Macro-level properties that are in principle derivable from micro-level rules, even if computationally intractable to derive; the standard form of emergence in computational systems.
- **Strong emergence**: Macro-level properties claimed to be irreducible to any micro-level description; controversial and most associated with consciousness science.

## Academic Context

The academic study of emergent behavior sits at the intersection of statistical physics, theoretical biology, computational social science, and AI, united by the Santa Fe Institute (founded 1984) which was the first interdisciplinary institution dedicated to complex systems and emergence across disciplines. The key theoretical frameworks are: self-organised criticality (Bak, Tang, Wiesenfeld, 1987, Physical Review Letters) — systems driven to a critical point through local interaction spontaneously organise to produce power-law distributions of event sizes, providing a universal mechanism for scale-free phenomena; complex adaptive systems theory (Holland, Kauffman, Gell-Mann, Axelrod) — formalising adaptive agents, emergent structure, and fitness landscapes; dynamical systems and nonlinear dynamics (Strogatz, Lorenz, May) — bifurcations, attractors, and chaos as the mathematical basis of emergent qualitative change; and network science (Barabási, Watts, Strogatz) — providing the topological substrate for emergence in systems where agent interaction is structured by network rather than spatial proximity.

The formal philosophical analysis of emergence was significantly advanced by Chalmers (2006) "Strong and Weak Emergence" in The Re-Emergence of Emergence (Oxford University Press), which distinguished computationally derivable weak emergence from genuinely irreducible strong emergence and argued that all emergence studied in complexity science and AI is weak in this sense. Bedau and Humphreys (2008) "Emergence: Contemporary Readings in Philosophy and Science" (MIT Press) compiled the canonical interdisciplinary readings, spanning physics, philosophy, and cognitive science. The information-theoretic tradition — beginning with Tononi's integrated information theory (2008) and extending through the partial information decomposition framework (Williams and Beer, 2010) and transfer entropy applications (Schreiber, 2000; Lizier, 2012) — provides quantitative operational measures of emergence applicable to simulation outputs and neural network activations alike.

The Journal of Artificial Societies and Social Simulation (JASSS, 1998-present, University of Surrey) is the primary venue for [[Social Simulation]] emergence research. ALIFE (Artificial Life conference, MIT Press) covers computational emergence in biological and artificial systems. The AAMAS (Autonomous Agents and Multi-Agent Systems) conference is the primary venue for AI-engineering perspectives on emergence in deployed [[Multi-Agent System]]. The Complex Systems Society and its flagship journal Complexity cover interdisciplinary emergence research. Key benchmark models that define the research vocabulary include: Schelling's segregation model (1969); Reynolds' Boids (1987); Langton's Ant and Lambda (1990, establishing computation at the edge of chaos); Bak-Tang-Wiesenfeld sandpile (1987); Axelrod's culture model (1997); and Epstein-Axtell Sugarscape (1996). The 2025 JASSS special issue on "Emergence in Generative Agent Simulations" addresses the specific challenges of validating and interpreting emergent behaviours in LLM-driven [[Agent-Based Modelling]], including the stochasticity of LLM outputs, cultural bias in agent populations, and the challenge of comparing LLM agent emergent outputs to empirical social science benchmarks.

## Current Landscape (2026)

By 2026, emergent behavior research has bifurcated into two distinct but connected domains: (1) classical complex systems science applied to simulation and modelling — [[Agent-Based Modelling]], swarm robotics, computational social science — where the field is mature with established tools (NetLogo, Mesa, FLAME GPU, AnyLogic) and community standards (ODD protocol); and (2) emergent behavior in AI systems — both the engineered emergence of [[Multi-Agent System]] built from [[Large Language Model]] and the spontaneous emergent capabilities arising in frontier LLMs as they scale.

In the AI engineering domain, the MAEBE (Multi-Agent Emergent Behavior Framework) paper (arXiv:2506.03053, 2025) introduced a structured framework for characterising and studying emergent behaviors in deployed multi-agent systems, noting that agentic systems consisting of specialised sub-agents that collaboratively plan and reason exhibit system-level emergent properties not present in any individual agent. The framework distinguishes planned emergence (designers intentionally use emergence as an engineering strategy) from unplanned emergence (unexpected system behaviours arising from agent interactions that may be beneficial or harmful). The UK AI Security Institute (AISI) has conducted systematic evaluations of emergent dangerous capabilities in frontier AI models since November 2023, noting in its 2025 Frontier AI Trends Report that AI models can now complete apprentice-level cyber tasks 50% of the time compared to just over 10% in early 2024 — evidence of emergent capability accumulation requiring monitoring and evaluation frameworks. Real-world emergent behaviour incidents in deployed AI — route recommendation systems producing unexpected congestion patterns, demand-management systems accidentally synchronising — motivate the development of emergence monitoring infrastructure for production [[AI Agent System]].

## Historical Development

The concept of emergence has a philosophical history spanning more than a century before its computational formalisation in the 1980s. The British Emergentists of the 1920s — particularly C.D. Broad ("The Mind and its Place in Nature," 1925) and Samuel Alexander ("Space, Time, and Deity," 1920) — articulated the philosophical doctrine that higher levels of natural organisation exhibit genuinely novel properties not explicable by the properties and laws governing lower levels. This emergentist philosophy was a minority position in mid-20th century science, when reductionism dominated: the success of quantum mechanics in explaining chemical bonding, molecular biology in explaining heredity, and neuroscience in explaining brain function through neuronal activity seemed to support a reductionist account where all higher-level phenomena are in principle reducible to physics. Anderson's 1972 "More is Different" essay marked the turning point, arguing from within physics that the condensed matter physicist's job — understanding collective phenomena in systems of many interacting particles — is not a mere application of particle physics but requires genuinely new conceptual frameworks for each level of organisation.

The computational formalisation of emergence came through the [[Artificial Life]] research community beginning in the mid-1980s. Christopher Langton's 1987 PhD thesis at the University of Michigan introduced "artificial life" as the study of life-as-it-could-be rather than life-as-it-is, proposing [[Cellular Automata]] and agent simulations as tools for studying how life-like emergent properties — self-reproduction, evolution, adaptation, computation — can arise from simple rules operating on digital substrates. The First Artificial Life workshop at Los Alamos (1987) gathered the pioneers: Langton, John Holland ([[Genetic Algorithm]], complex adaptive systems), Stuart Kauffman (NK model, origins of order), Craig Reynolds (Boids), and Thomas Ray (Tierra, an evolving digital ecosystem). The Santa Fe Institute (founded 1984 by Murray Gell-Mann, Philip Anderson, Kenneth Arrow, and colleagues) provided the permanent interdisciplinary home for complex systems and emergence research, drawing researchers from physics, economics, biology, computer science, and social science to study emergent phenomena across disciplines.

The 1990s saw the first large-scale deployment of emergence as an engineering strategy in commercial entertainment: The Sims (Maxis/EA, 2000) allowed millions of consumers to observe emergent daily life narratives from agent-level utility maximisation; Creatures (Steve Grand, 1996) implemented biochemically-modelled creatures that evolved emergent learning and behaviour through [[Genetic Algorithm]] selection; and the real-time strategy game genre required emergent unit coordination from simple pathfinding and combat rules. These commercial deployments established emergence as a viable and valuable engineering approach rather than a purely scientific research topic.

The 2020s integration of [[Large Language Model]] into agent architectures opened a qualitatively new frontier: LLM agents whose individual decision-making draws on the implicit knowledge of billions of training examples can produce emergent collective social dynamics with far richer cultural, linguistic, and situational specificity than rule-based agents allow. The key open question — as of 2026 — is whether this enrichment of individual agent capabilities produces qualitatively richer emergent collective phenomena (emergent social dynamics that more closely reflect real human social systems) or merely more verbose and less reliable emergent dynamics that are harder to validate against empirical baselines.

## UK Context

- **University of Southampton**: A leading UK centre for [[Multi-Agent System]] research, with the Agents, Interaction and Complexity (AIC) research group contributing foundational work on emergent coordination in autonomous agent systems, trust and reputation in open multi-agent systems, and semantic web agent architectures. Southampton hosted the AgentLink network of excellence connecting European MAS researchers.
  - Research themes: emergent self-organisation in open multi-agent systems, mechanism design for emergent resource allocation, trust and reputation dynamics in agent populations
  - Key researchers: Nic Jennings (CBE, former Chief Scientific Adviser to UK Government on AI), Tim Norman, Enrico Gerding
  - Applications: emergent energy demand coordination in smart grids; emergent scheduling in multi-robot manufacturing systems
- **University of Sussex**: The Evolutionary and Adaptive Systems (EASy) group at Sussex is one of the UK's pre-eminent complex systems and [[Artificial Life]] research centres, with long-running research on emergent morphogenesis (how body plans emerge from gene regulatory network dynamics), autonomous robotics exhibiting emergent locomotion, and computational models of evolution and development. Sussex's Sackler Centre for Consciousness Science contributes emergence-relevant research on how conscious experience may arise from neural network dynamics.
  - Key researchers: Inman Harvey, Phil Husbands (Evolutionary Robotics), Chris Buckley (neural circuit emergence), Anil Seth (consciousness emergence)
  - Notable work: GasNet evolved neural circuits for robot walking — emergent locomotion gaits from evolutionary search in neural architecture space
  - Theoretical contribution: distinguishing "designed emergence" (intentional use of emergence engineering) from "natural emergence" (emergence observed in natural or unengineered systems)
- **University of Manchester**: Strong interdisciplinary complex systems research spanning engineering and social science; the Centre for Policy Modelling at Manchester Metropolitan University (founded by Nigel Gilbert, one of the UK's most eminent [[Social Simulation]] researchers) has studied emergent social phenomena in [[Agent-Based Modelling]] for over three decades. Manchester's proximity to major Northern industrial sectors provides context for emergence research applied to manufacturing and logistics systems.
  - Centre for Policy Modelling (CPM, MMU): one of Europe's earliest dedicated [[Social Simulation]] ABM research centres; produced SDML, a declarative agent modelling language; current research on emergent policy effects in complex social systems
  - Manchester's AI industry (Peak AI, ThoughtRiver, Matillion): applies emergent behaviour concepts in commercial demand forecasting, contract analysis, and data integration products
  - Northern manufacturing context: AMRC (Sheffield), Siemens Energy (Manchester), and multiple advanced manufacturing SMEs studying emergent coordination in human-robot manufacturing cells and automated warehouse systems
- **University of York**: The Intelligent Systems Group at York has contributed research on emergent coordination in embedded and cyber-physical systems, with applications to manufacturing automation and autonomous vehicle systems where emergent interaction between independently programmed components must be detected and managed.
  - Research focus: formal verification of emergent properties in autonomous systems; runtime monitoring of emergent behaviour in deployed cyber-physical systems
  - Application: autonomous vehicle platoon coordination; emergent collision avoidance in multi-robot industrial scenarios
- **University of Edinburgh**: Edinburgh's School of Informatics and Alan Turing Institute connection provide a hub for emergent capabilities research in [[Large Language Model]] and emergent coordination in [[Multi-Agent Reinforcement Learning]]. The EPCC national supercomputing facility provides frontier-scale compute for large-scale emergent behaviour simulation research.
  - AI Research Resource (AIRR) hosted at Edinburgh: national compute access for UK academic researchers studying emergence at scale
  - School of Informatics: significant LLM evaluation and emergent capability research; MARL research on emergent communication and coordination
- **Imperial College London**: Department of Computing contributes to multi-agent systems, emergent dynamics in financial networks, and AI safety research on emergent dangerous capabilities. The MRC Centre for Global Infectious Disease Analysis (Neil Ferguson) produced CovidSim — the highest-stakes UK ABM deployment in history.
  - London AI Technology Centre (Lenovo partnership, 2025): White City Deep Tech Campus; frontier model research and emergent AI applications
  - Thomson Reuters-Imperial Frontier AI Lab (December 2025): legal and financial emergent AI capabilities research
- **Alan Turing Institute**: The national institute for data science and AI in the UK coordinates emergence-relevant research across urban analytics (emergent urban dynamics from individual mobility), social simulation, epidemiological ABMs (emergent epidemic dynamics from individual contact networks), and AI safety (emergent dangerous capabilities in frontier models). The Institute's Urban Analytics programme directly studies emergent urban behaviour from individual movement data combined with ABM.
  - Urban Analytics programme: Nick Malleson (Leeds), Roger Bivand, Robin Lovelace; pedestrian dynamics ABMs fused with anonymised CCTV tracking and GPS mobility data; emergent crowd behaviour for city planning
  - AI safety programme: emergent dangerous capabilities evaluation in frontier models; connection to UK AISI evaluation framework
- **Northern England Industrial Context**:
  - Sheffield AMRC (Advanced Manufacturing Research Centre): emergent coordination in human-robot manufacturing cells; predictive maintenance through emergent anomaly detection in sensor networks
  - Leeds NEXUS: rail operations and transport planning uses emergent traffic flow modelling at regional scale; connection to National Rail emergency simulation infrastructure
  - Newcastle Urban Observatory: largest UK real-time urban sensor network; collects data against which emergent urban dynamic ABMs are validated; operates sensor fusion infrastructure for smart city emergence monitoring
  - Liverpool City Region Combined Authority: emergent public transport demand modelling for Merseyrail electrification and zero-emission bus fleet planning
  - Manchester-Leeds Technology Corridor: AI investment and deployment zone where emergent AI system dynamics in supply chain and logistics are actively studied and deployed

## Standards, Tools, and Platforms

- **NetLogo** (Northwestern University, Uri Wilensky, 1999-present): the dominant academic ABM platform for studying emergent behaviour in educational and research contexts
  - Logo-derived agent programming syntax; integrated BehaviorSpace for systematic emergence exploration across parameter space
  - 400,000+ registered users; world's largest repository of emergence demonstration models (traffic, flocking, epidemic, segregation, economics)
  - NetLogo models library includes canonical emergence demonstrations: Boids, Schelling Segregation, Fire (percolation), Ants (pheromone trail formation), Wolf Sheep Predation (population cycling)
- **Mesa** (Python, Mesa 3.0, 2025): dominant Python-ecosystem ABM platform integrating with NumPy, Pandas, and NetworkX for analysis of emergent network dynamics
  - Mesa 3.0 (2025): pluggable scheduler architectures enabling study of emergent scheduler-dependence in complex systems
- **FLAME GPU** (University of Sheffield, Paul Richmond): GPU-accelerated ABM enabling billion-agent emergence simulation on a single NVIDIA A100
  - Enables study of emergence at scales previously inaccessible — phase transitions in populations orders of magnitude larger than CPU-based platforms
  - NVIDIA-endorsed; applications in [[Epidemiological Modelling]], [[Crowd Simulation]], and financial market emergence
- **AnyLogic** (commercial): industry-standard platform uniquely combining ABM, [[System Dynamics]], and [[Discrete Event Simulation]] for hybrid emergence modelling in supply chain and healthcare
- **OASIS** (2024): social-media-scale generative ABM enabling emergence study at platform scale with millions of concurrent LLM-driven agents
- **Concordia** (Google DeepMind, 2024): structured [[Social Simulation]] library for LLM-driven emergent behaviour research with multi-model support
- **AgentSociety** (2025): large-scale societal simulation with LLM-driven agent populations for studying emergent social dynamics at civilisation scale
- **Repast** (Argonne National Laboratory): high-performance ABM platform for defence and national security emergence simulation, supporting billion-agent social simulations

## Contrasts with Related Concepts

- **Emergent Behavior vs. Programmed Behavior**: Programmed behaviour is explicitly specified by a designer who determines what will happen in each situation; emergent behaviour is not explicitly specified and arises from the collective dynamics of agents following rules that make no reference to the emergent outcome. The distinction is not always crisp — a designer who writes a Boids rule intending to produce flocking is in some sense programming for emergence — but the key criterion is that the emergent outcome is not computable from inspection of any individual agent's rule without running the simulation.
- **Emergent Behavior vs. [[Emergent Capabilities]]**: Emergent Behavior refers to the classical complex systems phenomenon — system-level patterns from local agent interaction rules — applicable to [[Agent-Based Modelling]], [[Swarm Intelligence]], game AI, and social simulation. [[Emergent Capabilities]] is the more specific concept from LLM scaling research, referring to qualitative abilities appearing in large language models at scale thresholds. The two concepts share the core mechanism (qualitative change from quantity) but differ in context: EB occurs in multi-agent systems, while EC occurs in single-model training dynamics. The connection is that LLM-driven multi-agent systems may exhibit both simultaneously — individual LLM agents exhibiting EC-style capability emergence from scale, and multi-agent populations exhibiting EB-style collective dynamics from agent interaction.
- **Emergent Behavior vs. Self-Organisation**: Self-organisation is the narrower concept of emergent ordered structure without external specification; emergent behavior is the broader concept encompassing any system-level property absent from individual agents, including both ordered structure (self-organisation) and complex functional patterns (ant trail formation, market price discovery) that need not be simply "ordered." All self-organisation is emergent, but not all emergent behaviour is simple spatial or temporal order.
- **Emergent Behavior vs. [[Collective Intelligence]]**: [[Collective Intelligence]] emphasises the problem-solving and adaptive capacity of the collective system, implying that the emergent dynamics are beneficial and produce correct or useful outcomes. Emergent Behavior is neutral — emergent dynamics can be harmful (flash crashes, unintended AI coordination against safety goals) as well as beneficial. Every instance of [[Collective Intelligence]] exhibits emergent behavior, but not all emergent behavior constitutes [[Collective Intelligence]].
- **Emergent Behavior vs. [[Chaos Theory]]**: [[Chaos Theory]] studies deterministic systems with sensitive dependence on initial conditions, producing complex, apparently random trajectories from deterministic rules. Emergent behaviour and chaos both arise from nonlinear dynamics, but emergent behaviour specifically concerns the appearance of new qualitative properties at the collective level, while chaos concerns the unpredictability of individual trajectories within a fixed qualitative regime. A chaotic system's attractor is itself an emergent structure — it is not specified in the differential equations but arises from their collective dynamics.

## Future Directions (2026-2030)

- **Emergence Safety Engineering**: Developing systematic methods for predicting, detecting, and constraining undesired emergent behaviours in deployed [[AI Agent System]] — analogous to formal verification in traditional software but adapted to the non-deterministic, adaptive nature of emergent systems.
  - Formal agent-level specifications with emergent property guarantees: specifying what global patterns the system must (and must not) produce from given local rules
  - Runtime monitoring of deployed [[Multi-Agent System]] for emergence anomaly detection: tracking system-level metrics (entropy, transfer entropy, diversity indices) for deviations from expected emergent regime
  - Intervention mechanisms: population-level parameter adjustment, agent communication restriction, system-level override triggers for correcting undesired emergent regimes without full system shutdown
  - Red-teaming for undesired emergence: adversarial testing attempting to elicit harmful emergent dynamics from individually safe agent configurations
- **LLM-Driven Generative Emergence**: As populations of [[Large Language Model]] agents become computationally tractable at city and platform scale (OASIS, AgentSociety, GATSim), the question of what qualitatively new social, cultural, and economic phenomena emerge from large-scale LLM agent interaction — phenomena no designer specified in any individual agent's prompt or persona — becomes both scientifically interesting and practically important.
  - Validation methodology: comparing LLM agent simulation emergent outputs to empirical social science data at multiple levels of analysis
  - Cultural bias auditing: LLM training corpus biases affecting agent populations representing non-Western or non-English social contexts
  - Hybrid architectures: LLM agents for qualitatively rich rare-event reasoning; rule-based agents for high-volume routine behaviour; reducing compute cost while maintaining emergent richness where it matters
- **Emergent Coordination in Agentic AI**: Multi-agent AI systems built from LLM orchestrators and specialised sub-agents are already exhibiting emergent task decomposition, error recovery, and workflow organisation from local agent-level interaction rules.
  - Understanding emergence engineering principles that produce reliable, beneficial system-level capabilities
  - Identifying failure modes that produce unreliable or unsafe emergent behaviours from locally compliant agents
  - Development of emergence monitoring infrastructure for production agentic AI deployments
- **Cross-Domain Unification of Emergence Theory**: Connecting emergence in statistical physics, evolutionary biology, [[Complex Adaptive Systems]] theory, and AI through shared mathematical frameworks.
  - Non-ergodic dynamical systems theory for unified modelling of emergence across time scales
  - Information-theoretic measures (Tononi's phi, transfer entropy, synergistic information) applicable across physical, biological, and AI emergence domains
  - Prospects for a principled science of emergence enabling a priori prediction of emergence thresholds in any complex adaptive system
- **Emergent Governance and Policy**: AI systems exhibiting emergent dynamics at societal scale — LLM agent populations mediating political discourse, financial market AI producing emergent price dynamics, autonomous vehicle fleets producing emergent traffic patterns — require governance frameworks that explicitly address system-level emergent properties rather than only individual agent behaviour.
  - Emergence impact assessment as part of AI safety and regulatory evaluation frameworks
  - Standards for monitoring and reporting emergent dynamics in deployed AI systems
  - International coordination on emergent AI behaviour safety standards, analogous to existing financial market circuit breaker standards for emergent market dynamics

## Research & Literature

- [1] Anderson, P.W. (1972). More is different. *Science*, 177(4047), 393-396.
- [2] Holland, J.H. (1998). *Emergence: From Chaos to Order*. Oxford University Press.
- [3] Holland, J.H. (1992). *Adaptation in Natural and Artificial Systems*. MIT Press.
- [4] Reynolds, C.W. (1987). Flocks, herds and schools: A distributed behavioral model. *ACM SIGGRAPH Computer Graphics*, 21(4), 25-34.
- [5] Bak, P., Tang, C. and Wiesenfeld, K. (1987). Self-organized criticality: An explanation of the 1/f noise. *Physical Review Letters*, 59(4), 381.
- [6] Epstein, J.M. and Axtell, R.L. (1996). *Growing Artificial Societies: Social Science from the Bottom Up*. MIT Press.
- [7] Epstein, J.M. (1999). Agent-based computational models and generative social science. *Complexity*, 4(5), 41-60.
- [8] Schelling, T.C. (1971). Dynamic models of segregation. *Journal of Mathematical Sociology*, 1(2), 143-186.
- [9] Axelrod, R. (1997). The dissemination of culture: A model with local convergence and global polarisation. *Journal of Conflict Resolution*, 41(2), 203-226.
- [10] Kauffman, S.A. (1993). *The Origins of Order: Self-Organization and Selection in Evolution*. Oxford University Press.
- [11] Grimm, V. et al. (2006). A standard protocol for describing individual-based and agent-based models. *Ecological Modelling*, 198(1-2), 115-126.
- [12] Park, J.S. et al. (2023). Generative agents: Interactive simulacra of human behavior. *UIST 2023*. arXiv:2304.03442.
- [13] Wei, J. et al. (2022). Emergent abilities of large language models. *Transactions on Machine Learning Research*. arXiv:2206.07682.
- [14] Schaeffer, R., Miranda, B. and Koyejo, S. (2023). Are emergent abilities of large language models a mirage? *NeurIPS 2023*. arXiv:2304.15004.
- [15] Bonabeau, E. (2002). Agent-based modeling: Methods and techniques for simulating human systems. *PNAS*, 99(suppl 3), 7280-7287.
- [16] Wooldridge, M. (2009). *An Introduction to MultiAgent Systems* (2nd ed.). Wiley.
- [17] Strogatz, S.H. (2001). Exploring complex networks. *Nature*, 410(6825), 268-276.
- [18] Barabási, A.L. and Albert, R. (1999). Emergence of scaling in random networks. *Science*, 286(5439), 509-512.
- [19] Castellano, C., Fortunato, S. and Loreto, V. (2009). Statistical physics of social dynamics. *Reviews of Modern Physics*, 81(2), 591.
- [20] LeBaron, B., Arthur, W.B. and Palmer, R. (1999). Time series properties of an artificial stock market. *Journal of Economic Dynamics and Control*, 23(9-10), 1487-1516.
- [21] Dorigo, M. and Stutzle, T. (2004). *Ant Colony Optimization*. MIT Press.
- [22] Helbing, D. and Molnar, P. (1995). Social force model for pedestrian dynamics. *Physical Review E*, 51(5), 4282.
- [23] MAEBE: Multi-Agent Emergent Behavior Framework (2025). arXiv:2506.03053.
- [24] UK AI Security Institute (2025). Frontier AI Trends Report. aisi.gov.uk/frontier-ai-trends-report.
- [25] Fromm, J. (2004). The Emergence of Complexity. University of Kassel Press.
- [26] Gell-Mann, M. (1994). *The Quark and the Jaguar: Adventures in the Simple and the Complex*. W.H. Freeman.
- [27] LLMs and Generative Agent-Based Models for Complex Systems Research (2024). *Humanities and Social Sciences Communications*, Nature. DOI:10.1038/s41599-024-03611-3.
- [28] Unified View of Grokking, Double Descent and Emergent Abilities: A Perspective from Circuits Competition (2024). arXiv:2402.15175.

### Provenance

