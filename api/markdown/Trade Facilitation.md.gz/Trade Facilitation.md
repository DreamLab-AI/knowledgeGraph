Trade facilitation is the simplification, modernisation and harmonisation of export and import processes, in the wording used by the World Trade Organization (WTO).[^1]

The WTO says bureaucratic delays and red tape pose a burden for moving goods across borders for traders, and that trade facilitation has therefore become an important issue for the world trading system.[^1] The World Customs Organization (WCO) places it inside the mission of customs, which it describes as developing an integrated set of policies and procedures that ensure increased safety and security as well as effective trade facilitation and revenue collection.[^2] It also advocates eliminating duplication and delays in international supply chains, such as multiple reporting requirements and inspections.[^2]

## Instruments

Within the WTO, the main instrument is the Agreement on Trade Facilitation, in force since 22 February 2017; see [[WTO Trade Facilitation Agreement]].[^1] The Revised Kyoto Convention of the WCO promotes trade facilitation and effective controls through simple procedures, and names principles that include standardisation and simplification of the goods declaration and supporting documents, maximum use of information technology, use of risk management and audit based controls, and coordinated interventions with other border agencies.[^3] The WCO's [[WCO SAFE Framework]] is titled as a framework to secure and facilitate global trade.[^4] Two specific tools covered in this corpus are the [[Single Window]] and the [[Authorised Economic Operator]] scheme, both of which appear in the WTO agreement text.[^5]

## Benefits

The WCO says business benefits through enhanced competitiveness in national and international markets because of reduced delays and costs from predictable and efficient movement of goods across borders.[^2] The WTO reports estimates that full implementation of its agreement could reduce trade costs by an average of 14.3% and boost global trade by up to 1 trillion US dollars a year.[^1] These are estimates, and only the WTO page was opened for them.

## Scope and distinctions

The WCO treats it as one aim of customs beside security and revenue collection, and the Kyoto Convention pairs facilitation with effective controls.[^2][^3] See also [[Customs Trade Facilitation]] and [[International Trade and Customs]].

## What the sources do not establish

The OECD and UNCTAD trade facilitation pages returned errors when fetched, so their definitions and indicators are not reported here. The opened sources give two organisational wordings rather than one agreed definition.

[^1]: World Trade Organization, “Trade facilitation”. https://www.wto.org/english/tratop_e/tradfa_e/tradfa_e.htm
[^2]: World Customs Organization, Procedures and Facilitation overview page. https://www.wcoomd.org/en/topics/facilitation/overview.aspx
[^3]: World Customs Organization, “The Revised Kyoto Convention”. https://www.wcoomd.org/en/topics/facilitation/instrument-and-tools/conventions/pf_revised_kyoto_conv.aspx
[^4]: World Customs Organization, “SAFE Framework of Standards 2021”. https://www.wcoomd.org/-/media/wco/public/global/pdf/topics/facilitation/instruments-and-tools/tools/safe-package/safe-framework-of-standards.pdf
[^5]: World Trade Organization, “Agreement on Trade Facilitation”. https://www.wto.org/english/docs_e/legal_e/tfa-nov14_e.htm

