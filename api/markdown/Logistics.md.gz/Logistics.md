Logistics is the part of supply chain management that plans and controls the flow and storage of goods, services and related information. The CSCMP glossary describes logistics management as that part of supply chain management that plans, implements and controls forward and reverse flow and storage of goods, services and related information between the point of origin and the point of consumption in order to meet customers' requirements.[^1]

## Civil definitions

The European Commission describes logistics as a fundamental part of supply chain management that consists of the organisation and management of flows of goods related to purchasing, production, warehousing, distribution and the disposal, reuse and exchange of products, as well as the provision of added value services.[^2] The Industrial Ontologies Foundry defines a logistics process as a business process composed of one or more processes such as transport, shipment preparation, storage or receiving that are coordinated to enable the movement, handling or distribution of material entities across one or more locations within a supply chain, and a logistics service as a commercial service that consists of at least one transport process, packaging process, freight forwarding or storage process.[^3]

## Military origin

NATO's allied joint doctrine for logistics defines logistics as the science of planning and carrying out the movement and maintenance of forces.[^4] The copy of the publication read here is edition B version 1 of December 2018 and carries a withdrawn mark, so it is evidence of the definition at that date, not of current doctrine.[^4] The civil wordings above use goods, services and information where the military wording uses forces.

## Scope and distinctions

Logistics sits under [[Supply Chain Management]] in this vault, and its operational areas include [[Freight Transportation]] and [[Warehousing and Distribution]]. [[Logistics Management]] is the managerial practice and is kept as a separate page; the CSCMP wording defines logistics management and not logistics alone, and this vault treats the two as near-synonyms.[^1] Related pages are [[Reverse Logistics]], [[Logistics Optimisation]] and [[Logistics Service Provider]].

## What the sources do not establish

Sources opened do not give a single agreed definition across the civil and military uses.[^1][^2][^4]

[^1]: Council of Supply Chain Management Professionals, “SCM Definitions and Glossary of Terms” (cite-only, paraphrased). https://cscmp.org/CSCMP/Educate/SCM_Definitions_and_Glossary_of_Terms.aspx
[^2]: European Commission, Directorate-General for Mobility and Transport, “Logistics”. https://transport.ec.europa.eu/transport-themes/logistics-and-multimodal-transport/logistics_en
[^3]: Industrial Ontologies Foundry, Supply Chain Ontology (SupplyChain.rdf, pinned commit 50a88d4b, MIT licence). https://raw.githubusercontent.com/iofoundry/ontology/50a88d4bfed6cd388bb11e132778cb2dcd1d7483/supplychain/SupplyChain.rdf
[^4]: NATO Standardization Office, “Allied Joint Doctrine for Logistics”, AJP-4 Edition B Version 1, December 2018 (copy published on GOV.UK, marked as withdrawn). https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/907825/doctrine_nato_logistics_ajp_4.pdf

