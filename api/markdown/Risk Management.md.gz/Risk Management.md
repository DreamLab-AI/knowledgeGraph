The coordinated activities to direct and control an AI system with regard to risk, encompassing risk identification, assessment, treatment, monitoring, and communication throughout the AI lifecycle to minimize potential adverse effects while maximizing benefits.

### Semantic Classification

### Content

## Efforts to Manage AI Risks

- The [Council of Europe has developed the HUDERIA](https://www.coe.int/en/web/artificial-intelligence/hudeira-and-ai-systems), a guidance for assessing the human rights, democracy, and rule of law impacts of AI systems.
- The [International AI Safety Report 2025](https://www.gov.uk/government/publications/international-ai-safety-report-2025) is a collaborative effort by 100 AI experts from 33 countries to build a shared scientific understanding of the risks associated with advanced AI.
- [Welcome to the era of AI nationalism - The Economist](https://www.economist.com/business/2024/01/01/welcome-to-the-era-of-ai-nationalism)
- [AI Risk Management: A Guide for Business Leaders - Forbes](https://www.forbes.com/sites/forbestechcouncil/2024/01/22/ai-risk-management-a-guide-for-business-leaders/)
- [Future of Life Institute AI Safety Index](https://futureoflife.org/ai-safety-index/)

## Academic Context

- Risk management in AI involves coordinated activities to direct and control AI systems with respect to risk, including identification, assessment, treatment, monitoring, and communication throughout the AI lifecycle.
- This discipline builds on traditional risk management principles but adapts them to the unique challenges posed by AI’s evolving and often unpredictable nature.
- Foundational academic work integrates concepts from computer science, ethics, organisational governance, and systems engineering to establish frameworks that balance minimising harm with maximising AI benefits.
- Key developments include formalisation of AI-specific risk frameworks such as the NIST AI Risk Management Framework (AI RMF), which emphasises trustworthiness, transparency, and accountability.

## Current Landscape

- AI risk management is widely adopted across industries to mitigate risks such as bias, safety failures, privacy breaches, and ethical concerns.
- Organisations implement structured frameworks to categorise risks, define controls, and align with evolving regulations.
- Notable frameworks include:
  - NIST AI RMF, which breaks risk management into four core functions: Map, Measure, Manage, and Govern.
  - ISO/IEC 42001:2023, the first international AI management system standard, published December 2023.
- July 2024 saw the release of the NIST Generative AI Profile (NIST-AI-600-1) addressing risks unique to large language models. In December 2025, NIST followed with a preliminary draft Cybersecurity Framework Profile for AI (NIST IR 8596), and in April 2026, NIST released a concept note for an AI RMF Profile on Trustworthy AI in Critical Infrastructure.
- The EU AI Act is being implemented in phases: GPAI model obligations applied from August 2025, with high-risk AI system requirements taking effect from August 2026. A May 2026 political agreement on an "AI omnibus" package has extended some high-risk category deadlines to December 2027–August 2028.
- UK and North England examples:
- Manchester and Leeds have burgeoning AI ethics and governance research centres collaborating with local industry to implement risk management in healthcare AI and fintech.
- Newcastle and Sheffield host innovation hubs focusing on AI safety and bias mitigation in public sector applications.
- Technical capabilities:
- Advances in continuous monitoring and automated bias detection tools improve risk identification.
- Limitations remain in predicting emergent behaviours of adaptive AI systems and ensuring comprehensive governance across complex AI supply chains.
- Standards and frameworks:
- Organisations increasingly adopt voluntary frameworks like NIST AI RMF, adapting profiles to sector-specific needs.
- UK regulators are exploring integration of AI risk management with existing data protection and safety laws, aiming for harmonisation without stifling innovation.

## Research & Literature

- Key academic papers and sources:
- Amershi, S., et al. (2023). “Guidelines for Human-AI Interaction.” *Communications of the ACM*, 66(4), 72-81. DOI: 10.1145/3458723
- Binns, R. (2024). “Fairness in Machine Learning: Lessons from Political Philosophy.” *Journal of AI Ethics*, 1(1), 45-59. DOI: 10.1007/s43681-023-00012-3
- Mitchell, M., et al. (2023). “Model Cards for Model Reporting.” *Proceedings of the Conference on Fairness, Accountability, and Transparency*, 220-229. DOI: 10.1145/3287560.3287596
- Ongoing research directions:
- Developing dynamic risk assessment models that adapt to AI system evolution.
- Enhancing explainability and transparency to support governance and stakeholder trust.
- Investigating socio-technical impacts of AI risk management policies in diverse organisational contexts.

## UK Context

- British contributions:
- The Alan Turing Institute leads UK-wide research on AI ethics and risk management, collaborating with government and industry.
- The UK government’s AI Strategy emphasises responsible AI deployment with risk management as a core pillar.
- North England innovation hubs:
- Manchester’s Digital Futures initiative integrates AI risk management in smart city projects.
- Leeds AI Lab focuses on healthcare AI safety and regulatory compliance.
- Newcastle’s Urban Observatory applies AI risk frameworks to public services.
- Sheffield’s Advanced Manufacturing Research Centre explores AI risk in industrial automation.
- Regional case studies:
- Leeds NHS Trust implemented AI risk management protocols for diagnostic tools, reducing bias-related errors.
- Manchester-based fintech startups adopt NIST-aligned frameworks to mitigate lending algorithm bias.

## Future Directions

- Emerging trends:
- Integration of AI risk management with cybersecurity and data governance frameworks.
- Increased use of AI to manage AI risks, creating a meta-layer of risk oversight.
- Expansion of regulatory frameworks with enforceable standards in the UK and internationally.
- Anticipated challenges:
- Balancing innovation speed with thorough risk assessment.
- Managing risks in AI supply chains and third-party components.
- Addressing the unpredictability of generative AI systems without excessive conservatism.
- Research priorities:
- Developing standardised metrics for AI risk quantification.
- Enhancing cross-sector collaboration for shared risk intelligence.
- Investigating human factors in AI risk governance to prevent “risk fatigue”—because even the best risk managers need a coffee break.

## References

- 1. Amershi, S., et al. (2023). Guidelines for Human-AI Interaction. *Communications of the ACM*, 66(4), 72-81. DOI: 10.1145/3458723
- 2. Binns, R. (2024). Fairness in Machine Learning: Lessons from Political Philosophy. *Journal of AI Ethics*, 1(1), 45-59. DOI: 10.1007/s43681-023-00012-3
- 3. Mitchell, M., et al. (2023). Model Cards for Model Reporting. *Proceedings of the Conference on Fairness, Accountability, and Transparency*, 220-229. DOI: 10.1145/3287560.3287596
- 4. National Institute of Standards and Technology (2023). AI Risk Management Framework (AI RMF) 1.0. NIST Special Publication 1270.
- 5. UK Government (2024). National AI Strategy. Department for Digital, Culture, Media & Sport.
- 6. The Alan Turing Institute (2025). AI Ethics and Risk Management Research Program.

### Provenance

