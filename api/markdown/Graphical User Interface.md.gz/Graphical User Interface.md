A form of user interface that lets people interact with computing systems through visual elements — windows, icons, menus, buttons, and pointers — rendered on a two-dimensional display and manipulated directly with a pointing device or touch. By replacing memorised text commands with recognisable on-screen objects and immediate visual feedback, the GUI established the dominant interaction paradigm of personal computing from the 1980s onward and remains the baseline against which 3D, voice, and spatial interfaces are contrasted.

### Semantic Classification

### Content

## Definition

A **graphical user interface** (GUI) presents a computing system's state and capabilities as visual objects on a screen and accepts input through direct manipulation of those objects. The classic formulation is the WIMP model — windows, icons, menus, pointer — in which overlapping windows partition the display, icons stand for files and applications, menus expose commands, and a pointing device selects and drags. The design principles behind it, articulated in [[Human Computer Interaction]] research, are recognition over recall, direct manipulation with continuous feedback, and reversibility of actions: users see what is available rather than remembering command syntax, and the interface responds visibly to every gesture.

The paradigm's lineage runs from Douglas Engelbart's 1968 demonstration of the mouse and windowed hypertext, through Xerox PARC's Alto and Star systems in the 1970s, to commercial breakthrough with the Apple Macintosh (1984) and mass adoption via Microsoft Windows. Later generations extended the model to touch — smartphones replaced the pointer with fingers, gestures, and momentum scrolling — while retaining the underlying grammar of visual widgets, event-driven programming, and a desktop or home-screen metaphor. Practically every widget toolkit, from Cocoa and Qt to the browser DOM and mobile frameworks, is an industrialisation of GUI concepts, and [[User Interface Design]] as a profession largely grew up around them.

Within this knowledge graph the GUI serves as the canonical 2D contrast case for spatial computing. A [[3D User Interface]] situates interaction in a volumetric space with six-degree-of-freedom input, gaze, and hand tracking, whereas the GUI constrains interaction to a plane with two-degree-of-freedom pointing — a constraint that brings precision, low fatigue, and fifty years of refined convention, which is precisely why immersive environments so often re-embed flat GUI panels for text-heavy and high-precision tasks.

## Current Landscape

GUIs remain the default interface for productivity computing and show no sign of displacement. Contemporary evolution happens along several axes: design systems (Material Design, Fluent, Apple's Human Interface Guidelines) standardise component behaviour across platforms; declarative UI frameworks (React, SwiftUI, Jetpack Compose, Flutter) have replaced imperative widget trees with state-driven rendering; and accessibility APIs expose the visual hierarchy to screen readers and automation. Two frontiers are notable for this corpus. First, XR platforms are hybridising the GUI rather than abandoning it — visionOS and Quest render familiar windows, buttons, and menus as floating panels controlled by gaze-and-pinch, keeping GUI semantics inside spatial containers. Second, GUI agents — multimodal AI models that perceive screens and operate interfaces by synthetic clicks and keystrokes — have turned the GUI itself into a machine-facing API, making interface legibility relevant to software agents as well as people.

- **Computer-use / GUI agents (2024-2026)**: Anthropic shipped Computer Use with Claude 3.5 Sonnet in October 2024; OpenAI's Computer-Using Agent (Operator) and Google's Gemini 2.5 Computer Use followed. These vision-language-action systems capture screenshots, ground UI elements and emit bounded actions (click, type, scroll). On the OSWorld desktop benchmark, scores rose from a ~12% baseline to 61.4% (Claude Sonnet 4.5) against a 72.4% human ceiling; Gemini 2.5 Computer Use reports ~88.9% on WebVoyager but remains browser- rather than OS-optimised.
- **Hybrid architectures**: production 2026 agents (e.g. Microsoft UFO²) fuse OS accessibility trees with vision-based parsing (OmniParser) rather than relying on pixels alone, reflecting that much GUI interaction logic is deterministic and needn't route through the model.
- **Standardisation pressure**: proposals to expose application semantics to assistants via the Model Context Protocol (MCP) and declarative OS interfaces aim to make GUIs first-class targets for agents while keeping the human-facing widget grammar intact.
- **Human-facing evolution**: design systems (Material Design, Fluent, Apple HIG) and declarative frameworks (React, SwiftUI, Jetpack Compose, Flutter) remain the mainstream, and XR platforms (visionOS, Quest) re-embed flat GUI panels as gaze-and-pinch-controlled floating windows.

  **Sources**:

- https://www.marktechpost.com/2025/10/10/what-are-computer-use-agents-from-web-to-os-a-technical-explainer/
- https://arxiv.org/html/2510.06223v1
- https://arxiv.org/html/2510.04607v2

### Provenance

