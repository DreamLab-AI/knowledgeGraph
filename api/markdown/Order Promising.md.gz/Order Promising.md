Order promising is the process of making a delivery commitment, that is of answering the question of when an order can ship.[^1]

The ASCM (APICS) certification text, citing the APICS Dictionary, adds that for make-to-order products order promising usually involves a check of uncommitted material and availability of capacity, often as represented by the master schedule available-to-promise.[^1] The same text defines order entry as the process of accepting and translating what a customer wants into terms used by the manufacturer or distributor, and says the commitment should be based on the available-to-promise line in the master schedule.[^1] It adds that the closer one gets to the present, the more the cumulative actual orders displace forecasts or available capacity.[^1]

Infor's documentation describes available-to-promise as the uncommitted portion of inventory and planned production in the master schedule that supports customer order promising, which enables a company to provide reliable delivery dates to customers.[^2] Oliver Wight's glossary likewise calls available-to-promise a tool for order promising, normally calculated from the master production schedule.[^3]

## Capable-to-promise

That ASCM text defines capable-to-promise as the process of committing orders against available capacity as well as inventory. It may involve multiple manufacturing or distribution sites, is used to determine when a new or unscheduled customer order can be delivered, and employs a finite-scheduling model of the manufacturing system.[^1] See [[Available-to-Promise]], [[Make-to-Order]] and [[Master Production Scheduling]].

## What the sources do not establish

All three sources are certification, vendor or consultancy material, and the ASCM definitions are paraphrased here because the dictionary is cite-only. No peer-reviewed or standards source could be opened for order promising.[^1][^2][^3]

[^1]: ASCM (APICS), CPIM Version 6.1, 2019 Edition, excerpt citing the APICS Dictionary, 15th edition, excerpt of the certification text, Section F: Master Planning. https://learningsystem.ascm.org/wp-content/uploads/2018/11/APICS_CPIM_2019_Excerpt.pdf
[^2]: Infor, Infor M3 documentation, “Available-to-promise (ATP)”. https://docs.infor.com/m3udi/16.x/en-us/m3beud/scplanhs/cts090.html
[^3]: Oliver Wight Americas, glossary, “Available-to-Promise (ATP)”. https://www.oliverwight-americas.com/glossary-terms/available-to-promise-atp/

