The right to erasure, also known as the right to be forgotten, is a data-subject right under the UK GDPR and EU GDPR that allows individuals to require a controller to delete their personal data in defined circumstances. It applies where data is no longer necessary, consent is withdrawn, processing is unlawful, or the data subject objects without overriding legitimate grounds. The right is qualified by exemptions such as freedom of expression, legal obligations, and the public interest.

### Overview

- The right to erasure operationalises the principle that personal data should not be retained longer than necessary for its purpose.
- It is one of several [[Data Subject Rights]] codified in the [[UK GDPR]] and is closely associated with the [[Right to Be Forgotten]].
- It sits in tension with immutable architectures such as a [[Distributed Ledger]], where deletion is technically difficult.

### Key aspects

- Grounds for erasure: data no longer necessary, withdrawn consent, unlawful processing, or objection.
- Exemptions: freedom of expression, legal obligation, public-interest archiving, and legal claims.
- Downstream notification: informing recipients and, where data was made public, other controllers.
- Interaction with retention schedules and [[Consent Management]] systems.
- Verification of identity before acting on an erasure request.

### Applications

- Implementing deletion workflows across primary stores, backups, and logs.
- Search-engine de-indexing requests for outdated or irrelevant results.
- Designing [[Privacy By Design]] systems with built-in deletion capability.
- Compliance auditing under [[Data Protection]] regimes.

### Provenance

