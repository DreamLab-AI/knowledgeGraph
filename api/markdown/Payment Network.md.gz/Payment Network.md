A payment network is an infrastructure system of interconnected nodes, protocols, messaging standards, and settlement mechanisms that enables the authenticated transfer of value between participants — individuals, merchants, financial institutions, or autonomous software agents — with guarantees on finality, atomicity, and fraud prevention. Payment networks operate at multiple layers: a messaging layer (e.g. SWIFT MT/MX, ISO 20022) carries authenticated payment instructions; a clearing layer nets obligations across participants; and a settlement layer achieves irrevocable finality through central bank reserves or distributed ledger consensus. The architecture spans traditional four-party card networks (Visa, Mastercard), interbank clearing systems (SWIFT, ACH, SEPA, Fedwire), cryptographic peer-to-peer blockchain networks, and second-layer off-chain channel networks such as the Lightning Network, collectively underpinning commerce, financial inclusion, and machine-to-machine value exchange.

### Overview

- Payment networks form the backbone of the global economy, channelling value across borders, industries, and increasingly across software agents and IoT devices. Their defining properties are:
  - **Reach**: the set of participants (individuals, merchants, financial institutions) interconnected by shared rules and addressing schemes.
  - **Finality**: the guarantee that a settled transaction cannot be reversed by any single party.
  - **Speed**: time from payment initiation to irrevocable settlement — ranging from multi-day batch ACH to sub-second [[Real-Time Payments]].
  - **Cost**: per-transaction fees that determine economic viability for different use cases (e.g. [[Micropayments]] require sub-cent costs).
  - **Programmability**: the ability to embed conditions, triggers, and logic into value transfer via [[Smart Contract]] or HTTP-native protocols.
- Payment networks are not monolithic. They layer messaging standards (SWIFT, [[ISO 20022]]), clearing functions ([[Clearing House]]), and settlement rails (central bank RTGS, [[Blockchain]] consensus) into a stack. Governance models range from closed proprietary networks (Visa, Mastercard) to open, permissionless [[Distributed Ledger Technology]] networks (Bitcoin, Ethereum) and hybrid public-private arrangements (CBDC pilots).

### Key Components

- **Participants and Roles**
  - Issuers: banks or fintechs that provision payment instruments (cards, wallets) to end users.
  - Acquirers: institutions that accept payments on behalf of merchants and route them to the network.
  - Network Operators: entities (Visa, Mastercard, SWIFT, ACH operators) that maintain the central scheme rules, messaging infrastructure, and dispute processes.
  - Central Banks: provide ultimate settlement finality through reserve accounts in real-time gross settlement (RTGS) systems such as Fedwire or TARGET2.
  - Nodes: in [[Blockchain]] networks, miners or validators replacing centralised operators with distributed [[Consensus Mechanism]].
- **Messaging Layer**
  - Carries authenticated payment instructions between participants.
  - [[ISO 20022]] is the dominant global standard for rich, structured financial messaging (XML/JSON), enabling data-rich cross-border payments.
  - SWIFT MT (legacy) and SWIFT MX (ISO 20022 compliant) messages underpin correspondent banking.
  - EMV (Europay, Mastercard, Visa) standards govern card-present chip-and-PIN transactions.
- **Clearing Layer**
  - Nets bilateral obligations to reduce the volume of settlement transactions.
  - [[Clearing House]] infrastructure (ACH, BACS, SEPA SCT, CLS for FX) computes net positions across participants in a settlement cycle.
  - In [[Blockchain]] networks, clearing is implicit: the mempool and block production sequence transactions before final confirmation.
- **Settlement Layer**
  - Achieves irrevocable finality — the point at which ownership definitively transfers.
  - Traditional RTGS systems settle in central bank money in real time (Fedwire, CHAPS, TARGET2).
  - [[Blockchain]] achieves settlement through cryptographic consensus, typically with probabilistic finality after enough block confirmations.
  - [[State Channel]] and [[Layer 2 Scaling]] solutions defer on-chain settlement, batching many micro-transactions into periodic on-chain closes.
- **[[Payment Gateway]]**
  - The merchant-facing API and security layer (tokenisation, 3D Secure authentication) that connects merchants to acquiring banks and the broader network.
- **[[Clearing House]]**
  - Centralised or decentralised entity that nets obligations and guarantees settlement between direct participants, reducing counterparty risk.

### Mechanisms and Architecture Patterns

- **Four-Party Model** (card networks)
  - Cardholder → Issuer → Network Scheme → Acquirer → Merchant; scheme sets interchange fees and dispute rules.
- **Correspondent Banking**
  - Bilateral nostro/vostro accounts hold pre-funded liquidity; SWIFT messages coordinate transfers; slow and expensive for exotic currency pairs.
- **Automated Clearing House (ACH / SEPA)**
  - Batch settlement in scheduled cycles (T+1, T+0 for Faster Payments variants); low cost; domestic-centric; underpins payroll, direct debit.
- **Real-Time Gross Settlement (RTGS)**
  - Continuous, irrevocable settlement of high-value payments in central bank money; eliminates settlement risk; used by central banks globally.
- **Distributed Ledger / Blockchain**
  - Permissionless (Bitcoin, Ethereum) or permissioned (Ripple, Corda, Hyperledger Fabric) architectures replace central operator with distributed [[Consensus Mechanism]]; finality model varies.
- **[[State Channel]] / Off-Chain Routing**
  - [[Lightning Network]] routes Bitcoin micropayments through a mesh of pre-funded bidirectional channels; only open/close transactions appear on-chain; enables sub-cent [[Micropayments]] at high throughput.
- **[[Layer 2 Scaling]] (Rollups)**
  - Optimistic and ZK-rollups on Ethereum batch thousands of transactions, post compressed proofs to L1; dramatically reduces per-transaction cost while inheriting L1 security.
- **HTTP-Native Payments (x402 / L402 Protocol)**
  - Embeds payment into HTTP request/response cycle; enables [[Machine to Machine Payments]] and API metering without a human in the loop; bridges [[Payment Network]] and [[Internet Infrastructure]].

### Applications and Use Cases

- **Retail Commerce**: card-present and card-not-present transactions processed through four-party card networks at point of sale and online checkout.
- **Cross-Border Remittances**: migrant workers sending value home; traditional SWIFT-correspondent routes being challenged by [[Stablecoin]] and blockchain rails offering lower fees and faster settlement.
- **B2B and Supply Chain Finance**: RTGS and ACH for payroll, supplier payments, invoice financing; [[ISO 20022]] enriched data enables automated reconciliation and [[Supply Chain]] visibility.
- **[[Micropayments]] and Content Monetisation**: streaming audio/video pay-per-second, in-game asset purchases, tip jars; viable only on low-fee rails ([[Lightning Network]], L2 rollups).
- **[[Machine to Machine Payments]]**: IoT devices paying for bandwidth, compute, or sensor data autonomously; [[Agentic AI]] systems purchasing API calls, model inference, or data via HTTP 402 micropayment channels.
- **[[Decentralised Finance]] (DeFi)**: on-chain [[Smart Contract]] protocols enabling lending, exchange, and derivatives without traditional intermediaries; payment networks provide the settlement layer.
- **CBDC Pilots**: over 130 central banks exploring or piloting [[Central Bank Digital Currency]] as programmable, sovereign-issued digital money on state-operated payment network rails.
- **Real-Time Payroll and Earned Wage Access**: [[Real-Time Payments]] rails (FedNow in the US, Faster Payments in the UK) enabling workers to access earned wages instantly rather than on bi-weekly cycles.
- **Autonomous Vehicle Tolling and Mobility**: vehicles authenticating and paying toll or parking fees programmatically without human action, enabled by embedded payment network clients.

### Standards and Governance Context

- **[[ISO 20022]]**: the global financial industry standard for electronic data interchange between financial institutions; structured XML/JSON messages replace older MT codes; mandated for cross-border wires in the EU (SEPA), UK (NPA migration), and US (Fedwire) through 2025-2026.
- **[[Payment Card Industry Standard]] (PCI DSS)**: security standard governing cardholder data protection across all entities handling card payments; mandates encryption, tokenisation, and access controls.
- **EMV Standard**: global chip-card standard (Europay, Mastercard, Visa) for card-present authentication; dramatically reduced card-present fraud after widespread adoption.
- **SWIFT GPI (Global Payments Innovation)**: initiative adding end-to-end tracking, speed SLAs, and fee transparency to correspondent banking; predecessor to ISO 20022 migration for SWIFT.
- **PSD2 (EU)**: Payment Services Directive 2 mandates open banking APIs, strong customer authentication (SCA), and third-party payment service provider (TPSP) access to account data; reshaping European payment network topology.
- **FedNow (US)**: Federal Reserve's real-time payment service launched in 2023; enables instant credit transfers between US bank accounts 24/7/365.
- **MiCA (EU)**: Markets in Crypto-Assets regulation governs stablecoin issuers and crypto-asset service providers operating on blockchain payment rails within the EU; came into force 2024.
- **BIS / CPMI**: Bank for International Settlements Committee on Payments and Market Infrastructures publishes the Principles for Financial Market Infrastructures (PFMI) — the globally accepted risk management framework for systematically important payment networks.
- **FATF Recommendations**: Financial Action Task Force guidance on anti-money-laundering (AML) and counter-terrorist financing (CTF) compliance obligations for payment network operators and virtual asset service providers (VASPs).
- **Lightning Network BOLTs**: Basis of Lightning Technology specifications defining the protocol stack for the Lightning [[State Channel]] network — peer-to-peer messaging (BOLT 1), channel establishment (BOLT 2), onion routing (BOLT 4), and invoice encoding (BOLT 11).

### Taxonomy and Typology

- Payment networks can be classified along several orthogonal dimensions:
  - **Topology**: centralised (card schemes, ACH operators) vs. decentralised ([[Blockchain]], [[Lightning Network]]) vs. federated (SWIFT correspondent chains).
  - **Settlement medium**: central bank money (RTGS), commercial bank money (ACH), cryptoassets (Bitcoin, Ether), or algorithmic stablecoins.
  - **Access model**: open/permissionless (Bitcoin) vs. permissioned/consortium (Ripple, Corda) vs. closed proprietary (Visa Direct).
  - **Finality model**: real-time gross (Fedwire), deferred net (ACH), probabilistic (proof-of-work blockchain), deterministic (BFT-based consensus).
  - **Value scope**: fiat currencies only, cryptoassets only, or multi-asset ([[Stablecoin]], tokenised assets).

### Current Landscape (2026)

- ISO 20022 reached critical mass across the major rails: SWIFT completed its cut-over from legacy MT messages on 22 November 2025 (around 97% of payment instructions now in the new format), and the US Fedwire Funds Service migrated on 14 July 2026, joining already-native rails such as The Clearing House's RTP and FedNow; by November 2026 all SWIFT users must be able to consume ISO 20022 camt.110 investigation requests.
- US instant-payment rails scaled sharply: FedNow reached roughly 1,600 participating institutions by end-2025 (up ~500 on the year), raised its per-transaction limit from $1m to $10m in November 2025, and is piloting a network-intelligence "pre-check" tool; The Clearing House's RTP raised its own ceiling from $1m to $10m in February 2025 and processed over $1.3tn in 2025.
- The GENIUS Act, signed on 18 July 2025, created the first US federal framework for payment stablecoins (100% high-quality liquid-asset reserves, BSA/AML compliance, dual federal/state chartering), with FDIC, OCC and FinCEN/OFAC rulemakings running in parallel through 2026 and full effect from 18 January 2027; an IMF working paper estimated the law cut incumbent payment firms' market capitalisation by ~18% (~$300bn).
- Card networks moved stablecoin settlement into production: Visa deployed stablecoin capability across Visa Direct from 5 August 2026 (USDC, Zero Hash compliance layer, 195 countries), building on the Visa Stablecoin Platform launched 16 July, while Mastercard completed its acquisition of BVNK (up to $1.8bn) and extended 24/7 intraday/weekend card settlement in fiat or regulated stablecoins.
- Stablecoins matured as a parallel settlement rail: total supply passed $300bn in 2025 (Circle USDC, Tether USDT), Circle's CCTP V2 launched March 2025 across 17 chains, and Western Union launched its Solana-based Stablecard on 4 August 2026 — though stablecoins remain roughly 1% of global payment flows.
- Europe tightened its regime: the Instant Payments Regulation mandates 10-second euro credit transfers with mandatory Verification of Payee (phase two live from October 2025), MiCA's transitional runway for crypto-asset service providers closed on 1 July 2026, and DORA supervision shifted from remediation to enforcement.
- Open challenges as of 2026 include settlement finality and par-convertibility risk for stablecoin rails, the $10m instant-rail ceiling that keeps large-value flows on Fedwire/CHIPS, extending FedNow beyond its domestic-only design for cross-border use, and embedding AI-driven, explainable fraud and sanctions controls as a baseline across every rail.

### References

- 1. Spark Money (2026). Payment Network Interoperability: Standards Bridging Crypto and Traditional Rails. https://www.spark.money/research/payment-network-interoperability-standards
- 2. Qube Events (2026). 5 Payments Trends Reshaping the US Market in 2026. https://www.qubevents.com/post/payments-trends-reshaping-us-market-2026
- 3. Chargeflow (2026). Cross Border Payments Trends 2026: What's Changing and Why. https://www.chargeflow.io/blog/cross-border-payments-trends
- 4. Yahoo Finance (2026). Visa Puts Stablecoins Into Its Cross-Border Payout Rail via Visa Direct. https://finance.yahoo.com/markets/crypto/articles/visa-puts-stablecoins-cross-border-222304577.html
- 5. IMF (2026). Stablecoins and the Future of Payments: Evidence from Financial Markets (WP/2026/052). https://www.imf.org/-/media/files/publications/wp/2026/english/wpiea2026052-source-pdf.pdf
- 6. Federal Reserve Bank of Chicago (2026). Could Instant Payments or Stablecoins Be the Answer to 24/7 Settlement? Chicago Fed Letter No. 519. https://www.chicagofed.org/publications/chicago-fed-letter/2026/519

### Provenance

