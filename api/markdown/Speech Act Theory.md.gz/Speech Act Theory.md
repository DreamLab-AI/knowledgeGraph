Speech Act Theory is a framework from the philosophy of language holding that utterances perform actions rather than merely describing states of affairs. In distributed and multi-agent systems it underpins agent communication languages by classifying messages as performatives such as inform, request, commit, and declare, each carrying defined intent and felicity conditions. It distinguishes the locutionary content, illocutionary force, and perlocutionary effect of a communicative act, giving coordinating agents a shared semantics for interaction.

### Overview

- **Speech Act Theory** sits within the [[Distributed Systems]] area of the distributed systems domain.
- It is referenced by existing classes in the knowledge graph and is materialised here as a defined, rooted node so those edges resolve.

### Key aspects

- Establishes a precise, shared meaning for speech act theory usable across coordinating components.
- Integrates with neighbouring concepts through the relations enumerated below.
- Maturity assessed as established based on established practice and literature.

### Mechanisms

- Operates through the dependencies and components captured in its `requires`, `uses`, and `hasPart` relations.
- Produces the capabilities captured in its `enables` and `supports` relations.

### Applications

- Applied wherever distributed systems systems need the function described above.
- Connects to broader workflows via the bridging relations listed below.

### Provenance

