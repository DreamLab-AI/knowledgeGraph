Freight transport regulation is the body of public rules, treaties and industry standards that govern how freight is carried, by whom and under what conditions.[^1]

None of the opened sources defines the term. Rodrigue, Notteboom and Slack describe regulatory control as a widely employed means of influencing transportation: governments set up public agencies to oversee sections of the transport industry, and such agencies may control entry and exit, which firms can offer services, at what prices and to which markets.[^1] They give the standard rule that the public sector usually provides infrastructure and the regulatory framework, while the private sector provides and operates many modes and terminals.[^1]

## Examples from the sources

Road haulage drivers' hours are set in the European Union by Regulation (EC) No 561/2006, which the European Commission describes as a common set of rules on maximum daily and fortnightly driving times and minimum daily and weekly rest. Its stated aim is to avoid distortion of competition, improve road safety and ensure good working conditions for drivers, and compliance is monitored through tachograph records.[^2]

The Convention on the Contract for the International Carriage of Goods by Road (CMR), done at Geneva in 1956, applies to contracts for carriage of goods by road in vehicles for reward where the places of taking over and delivery are in two different countries, at least one of them a contracting country. It provides that the contract of carriage is confirmed by a consignment note.[^3]

For sea carriage, an insurer's note describes the SOLAS amendment, adopted in November 2014 by the IMO Maritime Safety Committee, requiring the gross mass of packed containers to be verified and declared before loading; it says a container whose verified gross mass is not declared must not be loaded. This point rests on that one commentary and not on the IMO text.[^4]

## Standards that are not public law

The IATA Temperature Control Regulations are published by an industry association. IATA's page says the manual contains government regulations, with variations by country, and carrier regulations, so the manual also summarises public rules.[^5] See [[IATA Temperature Control Regulations]].

## Evidence limits

Examples are one road rule set, one road treaty, one sea rule and one air standard. They are not a map of the field; customs, dangerous goods, rail and cabotage rules are not covered. See [[Freight Transportation]].[^2][^3][^4][^5]

[^1]: Jean-Paul Rodrigue, Theo Notteboom and Brian Slack, The Geography of Transport Systems, “9.1 – The Nature of Transport Policy”. https://transportgeography.org/contents/chapter9/nature-transport-policy/
[^2]: European Commission, Mobility and Transport, “Driving time and rest periods - Mobility and Transport”. https://transport.ec.europa.eu/transport-modes/road/social-provisions/driving-time-and-rest-periods_en
[^3]: University of Oslo Faculty of Law, treaty library, “Convention on the Contract for the International Carriage of Goods by Road (CMR) - The Faculty of Law”. https://jus.uio.no/english/services/library/treaties/07/7-02/cmr-consolidated.html
[^4]: West P&I, “SOLAS - Verified Gross Mass of Packed Containers”. https://www.westpandi.com/publications/news/solas-verified-gross-mass-of-packed-containers
[^5]: International Air Transport Association, “IATA - Temperature Control Regulations (TCR)”. https://www.iata.org/en/publications/manuals/temperature-control-regulations/

