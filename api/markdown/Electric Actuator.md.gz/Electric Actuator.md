Electric actuator converts electrical energy into controlled mechanical motion through electromagnetic forces, providing the primary means of actuation in modern robots.

### Semantic Classification

### Content

Electric actuators dominate robotic systems due to their high energy density (compared to pneumatics), clean operation (no compressed gas infrastructure), and amenability to precise [[Servo Control]]. [[Brush DC Motors]] provide simple, robust performance with direct torque proportional to current. [[Stepper Motors]] enable open-loop positioning in low-speed applications. [[Brushless DC Motors]] and [[AC Induction Motors]] eliminate brush maintenance, achieving higher efficiency and longer lifespan. [[Linear Actuators]] convert rotary electric motor output into straight-line motion through mechanical transmission (screw threads, racks).

The fundamental control challenge in electric actuation involves managing the electromagnetic time constants—typically 10–100 milliseconds—that limit force ramp rates despite high electrical bandwidth. [[Servo Amplifiers]] and [[PWM]] (pulse-width modulation) drivers enable fine force/torque control. Integration with [[Gearboxes]] trades speed for torque, increasing effective torque constant but introducing compliance and backlash that complicates control. [[Spring-Loaded Mechanisms]] and {{compliant transmissions}} enable [[Force Control]] and improved disturbance rejection.

Contemporary electric actuators incorporate integrated encoders for [[Feedback Control]], embedded electronics enabling fieldbus communication, and thermal management for continuous high-power operation. Soft actuators using [[Electroactive Polymers]] and pneumatic systems mimicking biological muscle enable safer human-robot collaboration. Research explores AI-driven [[Adaptive Control]] that learns motor characteristics online, multi-axis electric motors reducing mechanical complexity, and supercapacitor-based energy storage enabling brief high-power bursts in [[Energy-Constrained Robots]].

### Provenance

