
A skill parameter defines one parameter of an [[Atomic Skill]], including its name and type. The Agent Ontology declares it as `Parameter` in the capability module, with the comment "Defines a parameter for a Skill, including its name and type."[^1]

An atomic skill points to its parameters through the `hasParameter` property. Two datatype properties describe the parameter itself: `parameterName` and `parameterType`, both strings. The type string is not restricted to a fixed set of values. The class holds no property for a parameter's value, because it describes the shape of an input and not a particular call.

A skill parameter is therefore a declaration, made once per skill. The values supplied when a skill is invoked belong to [[Intent Parameter]], the intent-side class, which carries `paramName`, `paramType` and `paramValue` for a concrete request.[^2] Keeping the two apart lets a skill advertise what it accepts independently of any one intent that calls it. visionGraph places Skill Parameter under [[Parameter]] and as part of Atomic Skill.

[^1]: Semantic Agent Communication Community Group, “Capability Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/capability.ttl
[^2]: Semantic Agent Communication Community Group, “Intent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/intent.ttl

