Sales and operations planning (S&OP) is a cross-functional planning process that integrates inputs from sales, operations and finance into one organisation-wide plan.[^1][^2]

An open operations management textbook calls S&OP a broader process than aggregate planning and describes the two as interrelated and complementary.[^1] Jatta describes S&OP as a forum in which different functional strategies meet to establish a production plan that economically serves the market while supporting the strategic and financial plans of the firm, with two sub-processes, demand and supply, and a monthly executive meeting to finalise the plan.[^3] Unlike CPFR, he says, S&OP is predominantly an intrafirm planning tool.[^3]

A Brazilian master's dissertation cites the definition of Thomé and colleagues: a cross-functional, integrated tactical planning process that unifies different business plans (sales, marketing, new product development, manufacturing, purchasing and finance) into plans integrated within the firm and across the supply chain. It aims to balance supply and demand at the level of products and product families, and encourages horizontal alignment between functions and vertical alignment from the business plan to operations.[^2]

## Scope and distinctions

A university course module shows how the S&OP production plan, stated in product groups, feeds the master schedule that drives material requirements planning.[^4] See [[Aggregate Planning]], [[Master Production Scheduling]], [[Demand Planning]] and [[Supply Planning]].

## What the sources do not establish

The Grimson and Pyke maturity framework and the Thomé research synthesis could not be opened, so this page does not describe maturity stages. Two of the three sources are secondary descriptions, one of them in Portuguese and paraphrased here.[^2][^3]

[^1]: Operations Management open textbook, eCampusOntario Pressbooks, section 14.2, “Concept and Horizon of Aggregate Planning”. https://ecampusontario.pressbooks.pub/opsmgmt/chapter/14-2-concept-and-horizon-of-aggregate-planning/
[^2]: Joao Paulo Gelmini Martins, PUC-Rio master dissertation, 2017 (in Portuguese), “Sales and Operations Planning (S&OP): Estudo de caso numa empresa de varejo brasileira”. https://www.maxwell.vrac.puc-rio.br/33680/33680.PDF
[^3]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content
[^4]: Terry Janicki, University of North Carolina Wilmington, OPS 370 course module, “Materials Requirements Planning Module 11”. https://csbapp.uncw.edu/janickit/ops370/modules/Module11.pdf

