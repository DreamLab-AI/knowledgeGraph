Mass production is the practice of producing high volumes of identical goods at a cost low enough to price them for large numbers of customers.[^1]

An open textbook says goods are made in anticipation of future demand, based on forecasts, and kept in inventory for later sale. It treats mass production as another name for the make-to-stock strategy, says it generally results in shorter cycle times than make-to-order, and says it takes advantage of economies of scale. The textbook adds that its disadvantage is that customers have to accept standardised products as they come off assembly lines.[^1]

## As a production system type

Another open text calls this the repetitive process: products are more standardised and output is usually high, the equipment is specialised and often highly customised to the process, and examples are automobile or electronics assembly lines.[^2] Georgia Tech class notes call it a mass production flow shop. The layout is determined by the product, the equipment is arranged in the sequence required, large quantities are made on specialised machines, and there is a limited number of different products with only minor variations.[^3] See [[Production System Type]].

## History of the assembly line

The Henry Ford museum says that in 1913 Ford Motor Company combined the standardisation of interchangeable parts with the subdivision of labour and the fluid movement of work to workers to create the assembly line, and that it came in stages, with flywheel magnetos placed on moving lines around 1 April 1913.[^5] The Library of Congress says Ford introduced the moving assembly line at the Highland Park factory in October 1913, and that what took workers 12.5 hours to assemble was reduced to 93 minutes.[^4] The museum says the separate lines had fused into three continuous lines able to produce a finished Model T every 93 minutes by early 1914.[^5] The two sources give different starting points, April and October 1913, and the museum describes a staged introduction.[^4][^5]

## Scope and distinctions

Mass production differs from [[Mass Customisation]], which keeps volume but customises each order, and from [[Job Shop Production]] at the opposite end of variety.[^1][^2] This corpus keeps mass production as a system type and [[Make-to-Stock]] as a strategy, although the textbook equates them.[^1]

## What the sources do not establish

History here rests on two public institutions and covers Ford's line only. The Library of Congress says mass production of the Model T allowed Ford to cut costs significantly; its price figures are not repeated here.[^4]

[^1]: eCampusOntario Pressbooks (Introduction to Canadian Business), “Operations Management”. https://ecampusontario.pressbooks.pub/bus108g/chapter/opsmanagement/
[^2]: Business LibreTexts (Introduction to Operations Management, NWTC), “6.3: Process Types”. https://biz.libretexts.org/Courses/Northeast_Wisconsin_Technical_College/Introduction_to_Operations_Management_(NWTC)/06:_Process_Design/6.03:_Process_Types
[^3]: Georgia Institute of Technology, School of Industrial and Systems Engineering, “Logistics Systems Design Class Notes, Chapter 12. Manufacturing Systems”. https://www2.isye.gatech.edu/~mgoetsch/cali/Logistics%20Systems%20Design/Full%20Text%20PDF/Manufacturing%20Systems.pdf
[^4]: Library of Congress, Business Reference Research Guides, “Ford Implements the Moving Assembly Line”. https://guides.loc.gov/this-month-in-business-history/October/Ford
[^5]: The Henry Ford, “Ford Methods and the Ford Shops”. https://www.thehenryford.org/collections/explore/articles/ford-methods-and-the-ford-shops

