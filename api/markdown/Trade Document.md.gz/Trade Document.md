A trade document is a document that accompanies, records or evidences a transaction in goods that move across borders.[^1][^2]

No opened source defines the term in general. UK exporter guidance says the completed invoice and any licences or certificates must travel with the goods, that proof of origin may be needed where the destination applies a reduced or zero duty rate, and that commercial invoices and customs paperwork must be kept.[^1] HM Revenue and Customs' archiving guidance lists transport documents to keep: shipping orders, bills of lading, air or sea waybills and consignment notes.[^2]

## Kinds in the sources

Maersk's glossary describes a commercial invoice as describing the commercial transaction between buyer and seller, a certificate of origin as a document issued by a certifying authority stating the country of origin, and an export declaration as a document required of the exporter by the export authority.[^3] GOV.UK says an importer must include the commodity code and the value of the goods on an import declaration.[^4] See [[Customs Declaration]], [[Bill of Lading]] and [[Rules of Origin]].

## A statutory subset

The UK Electronic Trade Documents Act 2023 defines a narrower class, the paper trade document: a paper document of a type commonly used in connection with trade in or transport of goods, or financing such trade or transport, possession of which is required for a person to claim performance of an obligation.[^5] Its examples are a bill of exchange, a promissory note, a bill of lading, a ship's delivery order, a warehouse receipt, a mate's receipt, a marine insurance policy and a cargo insurance certificate.[^5] An invoice does not appear among them.[^5] See [[Electronic Bill of Lading]] and [[Trade Finance]].

## Evidence limits

Sources are UK guidance, a UK statute and a carrier glossary. Other jurisdictions and the UN layout and data standards were not opened.[^1][^2][^3][^5]

[^1]: HM Revenue and Customs, “Export goods from the UK: step by step - GOV.UK”. https://www.gov.uk/export-goods
[^2]: HM Revenue and Customs, “Archiving your trade documents - GOV.UK”. https://www.gov.uk/guidance/archiving-your-trade-documents
[^3]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms
[^4]: HM Revenue and Customs, “Import goods into the UK: step by step - GOV.UK”. https://www.gov.uk/import-goods-into-uk
[^5]: UK Parliament, “Electronic Trade Documents Act 2023”, section 1. https://www.legislation.gov.uk/ukpga/2023/38/section/1

