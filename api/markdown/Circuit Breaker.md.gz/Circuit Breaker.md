The circuit breaker is a fault-tolerance design pattern that monitors calls to a remote service or resource and, once failures exceed a threshold, trips open to fail fast and stop sending requests for a cooling-off period. After a timeout it allows a limited number of trial calls in a half-open state to test recovery before closing again. The pattern prevents cascading failures, protects struggling dependencies, and enables graceful degradation in distributed systems.

- A [[Circuit Breaker]] is a [[Fault Tolerance]] pattern that monitors calls to a dependency and, when failures pass a threshold, trips open to fail fast and stop hammering a struggling service. It is a building block of system [[Resilience]].
- After a cooldown it enters a half-open state to test recovery, complementing [[Rate Limiting]] and commonly deployed in an [[API Gateway]] or [[Service Mesh]].

### Overview

- Named after electrical circuit breakers, the pattern protects a distributed system from cascading failure: rather than queuing requests against a failing dependency until resources exhaust, the breaker short-circuits and returns errors or fallbacks immediately.
- It maintains a small state machine - closed, open, half-open - driven by observed success and failure counts within a rolling window.
- The breaker is essential in [[Microservices]] architectures where one slow dependency can otherwise saturate thread pools and bring down upstream services.

### Mechanisms

- Closed state: requests pass through and failures are counted.
- Open state: requests fail fast for a configured timeout, sparing the dependency.
- Half-open state: a limited number of trial calls probe recovery before closing.
- Thresholds: error rate or count over a window decides when to trip.
- Fallbacks: cached values, defaults or degraded responses cover the open period.

### Applications

- Protecting microservices from cascading dependency failures.
- Guarding external API calls behind an API gateway.
- Embedded in service meshes and resilience libraries as a standard policy.
- Combined with retries and timeouts in reliability engineering.

### Provenance

