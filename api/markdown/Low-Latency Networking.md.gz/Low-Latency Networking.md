Low-latency networking is the design and operation of network architectures that minimise the round-trip delay between communicating endpoints, typically targeting single-digit or sub-millisecond latencies. It combines edge placement, optimised transport protocols, traffic prioritisation and predictable routing to support interactive and time-critical workloads. In spatial computing it underpins responsive immersive experiences where perceptual lag must remain below human-detectable thresholds.

### Overview

- Low-latency networking treats end-to-end delay as the primary optimisation target rather than raw throughput. Latency budgets are decomposed across propagation, transmission, queuing and processing delays, then each component is attacked through edge placement, congestion control tuning, hardware offload and deterministic scheduling. The discipline is foundational to spatial computing, where motion-to-photon delay above roughly twenty milliseconds breaks the sense of presence and can induce discomfort.

### Key aspects

- Edge placement of compute and rendering to shorten propagation paths
- Transport optimisation through modern congestion control and protocols such as QUIC
- Traffic prioritisation and quality-of-service marking for interactive flows
- Deterministic routing and jitter reduction to keep latency variance low
- Motion-to-photon budgeting for immersive and teleoperated systems

### Applications

- Cloud and remote rendering of immersive XR scenes
- Cloud gaming and interactive streaming
- Remote teleoperation of robots and vehicles
- Real-time collaborative virtual environments
- Industrial control loops with strict timing constraints

### Provenance

