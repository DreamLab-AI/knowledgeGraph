A staking reward is the compensation paid to participants who lock cryptocurrency to help secure a proof-of-stake network. Rewards are typically funded by protocol issuance and transaction fees and are distributed in proportion to the amount staked and the validator's correct, online participation in consensus. They create the economic incentive that aligns validator behaviour with network security and liveness.

### Overview

- Staking rewards convert capital commitment into network security. By requiring validators to bond stake that can be lost through slashing for misbehaviour, the protocol makes honest participation the economically rational strategy. Reward rates are usually a function of total stake, validator uptime and protocol inflation parameters, and they fund the broader ecosystem of liquid staking and delegated participation that lets non-operators earn yield.

### Key aspects

- Funding sources spanning protocol issuance and transaction fees
- Proportional distribution weighted by stake and validator performance
- Penalty mechanisms such as slashing that offset reward incentives
- Compounding and reward-rate dynamics tied to total network stake
- Delegation models allowing token holders to earn without operating nodes

### Applications

- Securing proof-of-stake layer-1 networks
- Liquid staking derivatives and yield products
- Delegated staking through exchanges and pools
- Validator economics and infrastructure businesses
- Treasury and inflation management for protocols

### Provenance

