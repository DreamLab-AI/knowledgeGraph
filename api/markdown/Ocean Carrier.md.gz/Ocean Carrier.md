An ocean carrier is a business that operates the vessels carrying cargo by sea. In United States law an ocean common carrier is defined as a vessel-operating common carrier.[^1]

## Legal definition

The Federal Maritime Commission describes a vessel-operating common carrier (VOCC), or ocean common carrier, as one that holds itself out to the general public to provide transportation by water of passengers or cargo between the United States and a foreign country for compensation, assumes responsibility for the transportation from the port or point of receipt to the port or point of destination, and operates, for all or part of that transportation, a vessel operating on the high seas or the Great Lakes between a port in the United States and a port in a foreign country.[^2]

Its contrast is the non-vessel-operating common carrier (NVOCC), defined in the statute as a common carrier that does not operate the vessels by which the ocean transportation is provided and that is a shipper in its relationship with an ocean common carrier.[^1] The Commission adds that an NVOCC issues its own house bill of lading or equivalent document.[^3]

## Scope and distinctions

An ocean carrier is a kind of [[Freight Carrier]], and so of [[Logistics Service Provider]]. For the sector see [[Container Shipping]] and [[Ocean Freight]]. A carrier in this sense differs from a [[Freight Forwarder]], which in United States law may be an ocean freight forwarder arranging space on behalf of shippers rather than operating a vessel.[^1]

## What the sources do not establish

This page rests on a single legal system. Both sources are United States regulatory material, and the Commission's page restates the statute, so they are not independent in substance. The definitions apply to carriage between the United States and foreign countries, and the sources opened do not give an international or European definition, nor do they say what share of world trade the carriers carry. The alias “shipping line” is not defined by any source opened for this page.

[^1]: Cornell Law School Legal Information Institute, “46 U.S. Code § 40102 - Definitions”. https://www.law.cornell.edu/uscode/text/46/40102
[^2]: US Federal Maritime Commission, “Vessel-Operating Common Carriers”. https://www.fmc.gov/resources-services/vessel-operating-common-carriers/
[^3]: US Federal Maritime Commission, “Ocean Transportation Intermediaries”. https://www.fmc.gov/resources-services/ocean-transportation-intermediaries/

