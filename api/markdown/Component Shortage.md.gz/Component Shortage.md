A component shortage is a shortage of a part or material that a producer needs and cannot readily replace, so that output is held back until supply recovers.[^1]

No opened source defines the term, and the best-documented case among the sources is the semiconductor shortage of 2021. The Federal Reserve Bank of Cleveland found evidence that a global semiconductor shortage constrained US vehicle production during the COVID-19 pandemic.[^1] Manufacturers in the industry cited insufficient materials, including a lack of semiconductors, as increasingly responsible for lower output.[^1]

## Effects in that case

The Cleveland Fed commentary reports that new car prices accelerated and vehicle inventories fell, which suggested that the supply of new cars was insufficient to meet demand.[^1] Its authors' best guess was that the materials shortages and their effects on new car prices would subside within the next six to nine months, which is a forecast made in 2021 and not a finding.[^1]

## Structural conditions

Christopher and Peck list long lead-times, such as the time taken to replenish components from order to delivery, as a characteristic of a critical path in a supply network.[^2] AMRO says that shipping bottlenecks, in addition to raw material and input shortages, disrupted trade flows and raised production costs around the world.[^3]

The European Central Bank adds a policy dimension: in 2022 the United States vastly expanded its unilateral control regime on certain semiconductors and manufacturing equipment destined for China.[^4] That concerns access to chips and tools, not the 2021 shortage, and the ECB paper does not link them.

## Scope and limits

A component shortage is a type of [[Supply Chain Disruption]]. For the industry in which the best-known cases arise see [[Semiconductor Supply Chain]]. This page rests mainly on one central bank commentary; the Commerce Department survey of semiconductor buyers and a Congressional Research Service note on vehicle chips were not usable, so causes such as wafer capacity or concentration of foundry supply are not asserted here.

[^1]: Federal Reserve Bank of Cleveland, Economic Commentary 2021-17, “Semiconductor Shortages and Vehicle Production and Prices”. https://www.clevelandfed.org/publications/economic-commentary/2021/ec-202117-semiconductor-shortages-vehicle-production-prices
[^2]: Martin Christopher and Helen Peck, International Journal of Logistics Management, 2004 (Cranfield repository postprint), “Building the Resilient Supply Chain”. https://dspace.lib.cranfield.ac.uk/server/api/core/bitstreams/6ce1ceca-e8c6-4b37-8f26-6fdbe3c08a8a/content
[^3]: ASEAN+3 Macroeconomic Research Office (AMRO), Analytical Note, 25 July 2022, “The Great Supply Chain Disruption: What Does the Shipping Crystal Ball Foretell?”. https://amro-asia.org/wp-content/uploads/2022/07/AMRO-Analytical-Note_The-Great-Supply-Chain-Disruption_What-Does-the-Shipping-Crystal-Ball-Foretell-_July-25-2022.pdf
[^4]: European Central Bank, Occasional Paper Series, “Navigating a fragmenting global trading system: insights for central banks (No 365)”. https://ecb.europa.eu/pub/pdf/scpops/ecb.op365~362d801aee.es.pdf

