Indirect procurement is the purchasing of goods and services that are used in running a business or in production without being incorporated into the product, for example maintenance, repair and operations supplies and information technology.[^1][^2]

An abstract of a Western Michigan University honors thesis says indirect procurement has largely been ignored in scholarly research because it represents only a small portion of a firm's expenditures, and that it suffers from a confusing nomenclature. It adds that indirect procurement is a diverse and crucial component of purchasing that allows sustainable competitive advantage and reduced costs if managed properly.[^1] The thesis finds that most current research concerns maintenance, repair and operations and information technology procurement, and that maintenance, repair and operations purchasing has its own confusing nomenclature because the term can refer to two very different types of purchase.[^1]

## Scope and distinctions

United States customs rules define indirect materials as goods used in the production, testing or inspection of another good but not physically incorporated into it, or used in the maintenance of buildings or the operation of equipment, including fuel and energy, tools, dies and molds, and spare parts and materials used in maintenance.[^2] That is a rules-of-origin definition and does not describe purchasing practice.[^2] See [[Direct Procurement]], [[Procurement]] and [[Spend Analysis]].

## What the sources do not establish

This page rests on one abstract and one customs definition, and the thesis itself could not be opened, so it does not describe the research findings in detail or give any share of spend.[^1][^2]

[^1]: Daniel Israel, Western Michigan University honors thesis (ScholarWorks record with abstract), “Trends in the Study of Indirect Procurement”. https://scholarworks.wmich.edu/honors_theses/3190/
[^2]: US Code of Federal Regulations, 19 CFR 102.1 (rules of origin), Cornell Legal Information Institute copy, “19 CFR § 102.1 - Definitions”. https://www.law.cornell.edu/cfr/text/19/102.1

