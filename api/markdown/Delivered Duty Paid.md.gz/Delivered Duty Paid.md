Delivered Duty Paid (DDP) is an Incoterms 2020 rule under which the seller delivers the goods when they are placed at the buyer's disposal, cleared for import, on the arriving means of transport ready for unloading at the named place of destination.[^1]

The Export Council of Australia says the seller must clear the goods for export and for import, pay any duty for both, and carry out all customs formalities, and that the seller bears all the costs and risks of bringing the goods to the place of destination.[^1] The trade software vendor AEB describes the seller as paying all costs in bringing the goods to the destination, including import duties and taxes.[^2] The US International Trade Administration lists DDP among the seven Incoterms 2020 rules for any mode of transport.[^3]

## Scope and distinctions

DDP places the greatest responsibility on the seller. The Export Council of Australia says so directly, and adds that the rule is often misinterpreted.[^1] The seller is not responsible for unloading the goods, according to both the Export Council of Australia and AEB.[^1][^2]

Risk passes to the buyer at the moment the goods are delivered at the agreed place, so the contract should name that place precisely.[^1] The seller may also need an import licence.[^1]

DDP is one rule inside [[Incoterms]], a [[Trade Term]] family, and it contrasts with [[Free on Board]], under which the seller's duty ends once the goods are on the vessel at the port of shipment.[^4] Because the seller must clear the goods for import and pay the duty, the rule touches [[Customs Clearance]], [[Customs Duty]] and [[Customs Declaration]].[^1] The sources opened say that the seller must complete the customs formalities, but they do not say who is the declarant or the importer of record in any given country.[^1]

## What the sources do not establish

The ICC text of the rule is copyright and was not read. The opened sources do not give the tax treatment of DDP sales, such as who accounts for import VAT in a given country, and they do not discuss cases where a seller without a local presence cannot clear goods itself. AEB is a trade software vendor, so its glossary is used only as corroboration of the Export Council of Australia and US government descriptions.

[^1]: Export Council of Australia, “DDP - Delivered Duty Paid - Incoterms® 2020 Rule”. https://export.org.au/ddp-delivered-duty-paid-incoterms-2020-rule/
[^2]: AEB, “DDP – Delivered Duty Paid (Incoterm)”. https://www.aeb.com/en/glossary/ddp-delivered-duty-paid-incoterm.php
[^3]: International Trade Administration (US Department of Commerce), “Know Your Incoterms”. https://www.trade.gov/know-your-incoterms
[^4]: Export Council of Australia, “FOB – Free on Board (Named Place) Incoterms® 2020”. https://export.org.au/?p=17266

