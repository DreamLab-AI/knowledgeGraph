A food supply chain is the full range of actors and their interlinked activities involved in the production, aggregation, processing, distribution, labelling, marketing, consumption and disposal of food products.[^1]

That is the definition in AGROVOC, the multilingual thesaurus of the Food and Agriculture Organization (FAO), which adds that the actors work across the supply side of a food system and that the activities add social, cultural and economic value.[^1] An FAO occasional paper describes agrifood chains in similar terms: sets of interrelated activities organised as sequences of stages, which in the agricultural, food and fibre sector start at the farm, including input supply, and continue through first handling, processing and distribution.[^2] As products pass through the stages, transactions take place between chain actors such as producers, processors and retailers, money changes hands, information is exchanged and value is added.[^2]

## Scope and distinctions

The FAO paper says that, from a broader systemic view, the chain concept also includes the rules of the game, meaning laws, regulations, policies and other institutional elements, and the support services that form the environment for the activities.[^2] The UK Food Security Report measures the stability and resilience of the UK food supply chain from production to consumption, including its physical, human and economic infrastructure.[^3] It separates shocks, which often come from outside the food supply chain and cause immediate disruption, from stresses such as climate change, which strain the chain over the longer term and worsen the effect of shocks.[^3]

This page sits under [[Sector Supply Chain]]. See also [[Cold Chain Monitoring]], [[Supply Chain Resilience]] and [[Digital Product Passport]].

## What the sources do not establish

The AGROVOC entry and the FAO paper are from the same organisation, so they are not fully independent witnesses to the definition, although the UK report supports the production-to-consumption scope from a separate origin.[^1][^2][^3] None of the sources gives a fixed list of stages, and the stage names differ between them.[^1][^2]

[^1]: FAO, AGROVOC multilingual thesaurus, “food supply chains (AGROVOC concept page)”. https://agrovoc.fao.org/browse/agrovoc/en/page/c_2630c679
[^2]: FAO, Agricultural Management, Marketing and Finance Occasional Paper, “Guidelines for rapid appraisals of agrifood chain performance in developing countries”. https://fao.org/docrep/pdf/010/a1475e/a1475e01.pdf
[^3]: UK Department for Environment, Food and Rural Affairs, Official Statistics, “United Kingdom Food Security Report 2024: Theme 3: Food Supply Chain Resilience”. https://www.gov.uk/government/statistics/united-kingdom-food-security-report-2024/united-kingdom-food-security-report-2024-theme-3-food-supply-chain-resilience

