Supply chain performance and finance is the part of this domain that deals with how well a supply chain performs and what it costs, and with the financial measures and arrangements that connect supply chain operations to a firm's money.[^1][^2]

No source opened here defines the grouping, so this page maps what two sources show. The Supply Chain Operations Reference model, SCOR, treats performance through attributes and metrics. An attribute is a grouping of metrics used to express a specific strategy, and it cannot itself be measured; SCOR 12.0 recognises five: reliability, responsiveness, agility, cost and asset management efficiency.[^1] Gunasekaran, Patel and Tirtiroglu, in a 2001 paper in the International Journal of Operations and Production Management, develop a framework for measuring performance at the strategic, tactical and operational levels and present a list of key performance metrics.[^2]

## Where the topics sit

Delivery, inventory, forecasting and equipment measures sit under [[Supply Chain Performance Measure]], and measures of expense sit under [[Supply Chain Cost Measure]]. The financial side appears inside the measures themselves: SCOR files Cash-to-Cash Cycle Time and Days Sales Outstanding under asset management efficiency, and lists Total Supply Chain Management Costs as a cost metric.[^1] Those are covered at [[Cash-to-Cash Cycle Time]] and [[Supply Chain Finance]]. The reference model is covered at [[SCOR Model]].

The Gunasekaran abstract says its emphasis is on measures dealing with suppliers, delivery performance, customer service, and inventory and logistics costs.[^2]

## What the sources do not establish

Both sources are partial. SCOR is cite-only and was read from a quick reference guide for version 12.0, and the current edition regroups the attributes, which was not opened. The Gunasekaran paper was read as an abstract record only. Neither source covers supply chain financing instruments, so this page makes no claims about them.[^1][^2]

[^1]: APICS Supply Chain Council, “SCOR Version 12.0 Quick Reference Guide” (Internet Archive copy of the APICS document). https://web.archive.org/web/2023/https://www.apics.org/docs/default-source/scor-p-toolkits/apics-scc-scor-quick-reference-guide.pdf
[^2]: A. Gunasekaran, C. Patel and E. Tirtiroglu, International Journal of Operations and Production Management 21(1-2), 2001 (Penn State record, abstract only), “Performance measures and metrics in a supply chain environment”. https://pure.psu.edu/en/publications/performance-measures-and-metrics-in-a-supply-chain-environment/

