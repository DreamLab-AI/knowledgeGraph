The WTO Trade Facilitation Agreement (TFA) is a multilateral agreement of the World Trade Organization (WTO), concluded at the 2013 Bali Ministerial Conference, that entered into force on 22 February 2017 after ratification by two-thirds of the WTO membership.[^1]

The WTO says the TFA contains provisions for expediting the movement, release and clearance of goods, including goods in transit, and measures for effective cooperation between customs and other appropriate authorities on trade facilitation and customs compliance issues.[^1] It also provides for technical assistance and capacity building.[^1] The legal text states that it applies only to the WTO members that have accepted it.[^2]

## Content

Articles in the text include publication and availability of information, advance rulings, release and clearance of goods, border agency cooperation, formalities connected with importation, exportation and transit, freedom of transit and customs cooperation.[^2] Under release and clearance, members are to adopt or maintain procedures allowing the option of electronic payment, to the extent practicable, for duties, taxes, fees and charges collected by customs.[^2] The text also covers a single window, which members shall endeavour to establish or maintain, and measures for authorised operators; see [[Single Window]] and [[Authorised Economic Operator]].[^2] The text does not say that members must create a single window; the wording is an endeavour.[^2]

## Implementation and differentiated treatment

For the first time in WTO history, the requirement to implement the Agreement is directly linked to the capacity of the country to do so, according to the WTO.[^1] Developing and least-developed members self-designate each provision under Category A, B or C. Category A provisions are implemented on entry into force, or within one year for least-developed members. Category B provisions follow a transitional period, and Category C provisions follow a transitional period and need capacity building assistance.[^2] The WTO's Committee on Trade Facilitation oversees implementation and gives members a forum for related questions.[^1]

## Estimated effects

The WTO states that estimates show full implementation could reduce trade costs by an average of 14.3% and boost global trade by up to 1 trillion US dollars per year, with the biggest gains in the poorest countries.[^1] These are WTO estimates, which this page has not checked against an independent study.

## Scope and distinctions

The TFA is the WTO's instrument on [[Trade Facilitation]]. It is separate from WCO instruments such as the [[WCO SAFE Framework]] and from the customs law of individual jurisdictions (see [[Customs Regulation]]).[^1][^3] The earlier body of this page described its measures as mandated in all cases; the text opened shows several, such as the single window, are drafted as endeavours. The page also relates to [[Customs Trade Facilitation]] and [[World Trade Organization]].

[^1]: World Trade Organization, “Trade facilitation”. https://www.wto.org/english/tratop_e/tradfa_e/tradfa_e.htm
[^2]: World Trade Organization, “Agreement on Trade Facilitation”. https://www.wto.org/english/docs_e/legal_e/tfa-nov14_e.htm
[^3]: World Customs Organization, “SAFE Framework of Standards 2021”. https://www.wcoomd.org/-/media/wco/public/global/pdf/topics/facilitation/instruments-and-tools/tools/safe-package/safe-framework-of-standards.pdf

