A customs declaration is the act, or the document, by which a person tells customs authorities what goods are being moved and which customs procedure they are to be placed under.[^1][^2]

The Union Customs Code defines it as the act whereby a person indicates, in the prescribed form and manner, a wish to place goods under a given customs procedure, with an indication, where appropriate, of any specific arrangements to be applied.[^1] The European Commission describes it as an official document that gives details of goods being imported or exported, and as the legal act by which an operator indicates the intention to place goods under an EU customs procedure.[^2] The Code requires all goods intended to be placed under a customs procedure, except under the free zone procedure, to be covered by a declaration appropriate to it.[^1] Goods enter free circulation by means of a customs declaration.[^3]

## Who makes it and what it contains

The Commission says it is usually made by the owner of the goods or a representative, and that declarations must be made online.[^2] For UK imports, GOV.UK says the declaration must include the commodity code, which determines the rate of duty and whether an import licence is needed, and the value of the goods, which helps work out duty and VAT.[^4] Most businesses use a transporter or customs agent to make it.[^4]

## Related declarations

The Code defines other declarations separately. An entry summary declaration is the act whereby a person informs the customs authorities that goods are to be brought into the customs territory of the Union.[^1] The Commission describes it as a safety and security requirement under which carriers supply advance information on goods to be imported.[^3] Maersk's glossary defines an export declaration as a document required of the exporter by the export authority of the country the goods are leaving.[^5] See [[Customs Clearance]].

## Evidence limits

Sources report EU and UK practice, and the glossary is a carrier's. Declaration data sets, time limits and simplified procedures are outside the passages read here.[^1][^2][^4][^5]

[^1]: European Parliament and Council, “Regulation (EU) No 952/2013 of the European Parliament and of the Council of 9 October 2013 laying down the Union Customs Code (recast)”. https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32013R0952
[^2]: European Commission, “Customs declaration - Taxation and Customs Union - European Commission”. https://taxation-customs.ec.europa.eu/customs/customs-procedures-import-and-export/customs-operations/customs-declaration_en
[^3]: European Commission, “Importation - Taxation and Customs Union - European Commission”. https://taxation-customs.ec.europa.eu/customs/customs-procedures-import-and-export/importation_en
[^4]: HM Revenue and Customs, “Import goods into the UK: step by step - GOV.UK”. https://www.gov.uk/import-goods-into-uk
[^5]: Maersk, “Glossary of shipping terms”. https://www.maersk.com/support/glossaries/shipping-terms

