Material requirements planning (MRP) is a computer-based system that develops plans for ordering and producing dependent demand items.[^1]

The UNCW course module says MRP derives requirements from the production schedule of parent items and offsets production orders to account for lead time. Its three primary inputs are the master production schedule, the bill of materials and inventory records.[^1] The bill of materials specifies the assemblies, subassemblies, parts and raw materials, and the amounts of each needed to make a single unit of the finished product.[^1] Inventory records give the status of each item by period, including gross requirements, scheduled receipts and the amount on hand.[^1]

Jatta, reviewing the literature, says firms commonly use MRP for arranging purchases and remanufacturing order releases, maintaining bills of materials and tracking materials. He adds that MRP systems are some of the most important systems in planning manufacturing operations, even though researchers weigh in heavily on their drawbacks.[^2] In his account the forecast is aggregated in the forecast management system and disaggregated for detailed planning, scheduling and production tracking in the MRP system.[^2]

## Scope and distinctions

The UNCW module lists benefits of MRP as low in-process inventories, the ability to track material requirements and to evaluate capacity requirements, a means of allocating production time and an easy way to determine inventory use. It says a successful system needs accurate master schedules, bills of materials and inventory records.[^1] See [[Master Production Scheduling]], [[Bill of Materials]] and [[Manufacturing Resource Planning]].

## What the sources do not establish

Only one course module and one literature review were opened, so this page gives no history, lot sizing rules or quantified benefits.[^1][^2]

[^1]: Terry Janicki, University of North Carolina Wilmington, OPS 370 course module, “Materials Requirements Planning Module 11”. https://csbapp.uncw.edu/janickit/ops370/modules/Module11.pdf
[^2]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content

