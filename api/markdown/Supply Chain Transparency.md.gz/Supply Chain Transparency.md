Supply chain transparency is the disclosure of information about the suppliers, conditions and impacts in a supply chain to parties outside the organisation, and no source opened here defines the term.[^1][^2]

Disclosure is required by law in some places. Section 54 of the UK Modern Slavery Act 2015 requires a commercial organisation within its scope to prepare a slavery and human trafficking statement for each financial year, setting out the steps taken to ensure that slavery and human trafficking is not taking place in its supply chains or its own business, or stating that it has taken no such steps.[^1]

## In guidance

The UN Global Compact and BSR guide names three principles for successful supply chain sustainability management, governance, transparency and engagement, which it says are essential to every step of its model.[^2] It notes that engaging with sub-tier suppliers is complicated by a lack of transparency in the supply chain and “lack of company leverage”.[^2] The later UN Global Compact guide to traceability says that developments in technology and demands for greater transparency from business and government are making traceability increasingly manageable.[^3]

## Relation to other concepts

Transparency concerns what is disclosed; [[Supply Chain Traceability]] is the capability to trace goods, and [[Supply Chain Visibility]] is an organisation's own view of its chain. Both can supply the information that transparency discloses. The legal duty to disclose is part of some instruments in [[Supply Chain Due Diligence Instrument]], and [[Ethical Sourcing]] is one area where it is demanded.

## What the sources do not establish

None of the sources measures how transparent a chain is, or shows that disclosure improves conditions. The Modern Slavery Act allows an organisation to state that it has taken no steps, so a statement is evidence of disclosure and not of action.

[^1]: UK Parliament, Modern Slavery Act 2015, section 54, “Modern Slavery Act 2015, section 54: Transparency in supply chains etc”. https://www.legislation.gov.uk/ukpga/2015/30/section/54
[^2]: United Nations Global Compact and Business for Social Responsibility, 2010, “Supply Chain Sustainability: A Practical Guide for Continuous Improvement”. https://www.bsr.org/reports/BSR_UNGC_SupplyChainReport.pdf
[^3]: United Nations Global Compact and BSR, 2014, “A Guide to Traceability: A Practical Approach to Advance Sustainability in Global Supply Chains”. https://www.unglobalcompact.org/docs/issues_doc/supply_chain/Traceability/Guide_to_Traceability.pdf

