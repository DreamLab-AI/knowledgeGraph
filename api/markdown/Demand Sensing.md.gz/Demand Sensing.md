Demand sensing is a short-horizon way of forecasting demand that draws on recent demand signals such as point-of-sale data to improve the near-term forecast.[^1][^2]

Both sources opened are software vendor blogs, and the SAS author notes that depending on who you talk to there are varying definitions and opinions about demand sensing, from sensing short-range replenishment based on sales orders to the manual blending of point-of-sale data and shipments.[^1] He describes a short-term forecast of one to eight weeks as critical for understanding and predicting changing consumer demand patterns tied to promotions, events, weather and unexpected shifts.[^1] Arkieva says traditional demand sensing uses point-of-sale data from retail stores to understand actual demand from end customers, and that demand sensing helps identify actual customer order trends and improve the near-term forecast.[^2] It adds another method, which it calls market buzz: comments, queries and emails on online forums, social media activity and online search.[^2]

## Scope and distinctions

The SAS blog contrasts demand sensing with traditional time-series techniques, which model patterns of trend and seasonality and so estimate future demand from historical patterns only.[^1] Goetschalckx describes ordinary short-term forecasting as extrapolating historical observations, which is the contrast the vendors draw.[^3] See [[Demand Forecasting]] and [[Demand Planning]].

## What the sources do not establish

No standards body, academic or public agency source was opened for this term, so the page rests on two vendor blogs and should be read as a practitioner description.[^1][^2] Neither source gives a measured accuracy gain, and the horizon of one to eight weeks is one author's figure.[^1][^2]

[^1]: Charlie Chase, SAS Voices blog (SAS Institute, a software vendor), 19 October 2020, “Is short-term demand sensing a key component of your digital supply chain transformation?”. https://blogs.sas.com/content/sascom/2020/10/19/is-short-term-demand-sensing-a-key-component-of-your-digital-supply-chain-transformation/
[^2]: Arkieva (a planning software vendor), blog post, “Improve Forecast Accuracy with Demand Sensing”. https://arkieva.com/blog/demand-sensing/
[^3]: Marc Goetschalckx, Georgia Institute of Technology course text, “Chapter 2. Forecasting”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/forecasting/forecasting.pdf

