
A delegation chain is a sequence of delegation instances forming a multi-level authority graph. The ontology adds that it is "useful for modeling nested or transitive delegation across agents".[^1]

The class is declared in the delegation module, and visionGraph places it under [[Agent Relationship]]. A single property connects it to its members: `hasDelegation`, with a `DelegationChain` as domain and a `Delegation` as range. Each member is an [[Agent Delegation]] with its own delegator, delegate and [[Delegation Scope]].

The module states no rule on how a later link's scope relates to an earlier one, for example that it may not widen. It names the structure and leaves any narrowing rule to implementers. The word "graph" in the definition indicates that a chain need not be a simple line.

[^1]: Semantic Agent Communication Community Group, “Delegation Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/delegation.ttl

