Climate-related supply chain risk is the risk that the physical effects of climate change, or the policy and market changes of a transition to a lower-carbon economy, disrupt or raise the cost of supply.[^1][^2]

The Task Force on Climate-related Financial Disclosures separates two kinds. Transition risk follows from the policy, legal, technology and market changes that moving to a lower-carbon economy may entail.[^1] Physical risk results from climate change and can be event driven (acute) or a longer-term shift in climate patterns (chronic).[^1] Acute physical risks include increased severity of extreme weather events such as cyclones, hurricanes and floods, and chronic physical risks include sustained higher temperatures that may cause sea level rise or chronic heat waves.[^1]

## How it reaches supply

The Task Force says physical risks can bring indirect impacts from supply chain disruption, and the Network for Greening the Financial System makes the same point, citing the disruption of global supply chains as an indirect effect.[^1][^3] The UK Climate Change Committee says climate change can stress supply chains, causing price rises, disruptions, delays and even failures in supply.[^2] It lists three routes: failure of infrastructure services such as transport, energy and digital; direct effects on business output and locations; and effects felt through markets, such as price rises for components or raw materials.[^2]

Its examples include flooding in Thailand, which caused extensive disruption for the automotive and high-tech sectors, and record low river levels in Europe, China and the US in the summer of 2022, which led cargo ships to carry smaller loads.[^2]

## Practice and limits

The Center for Climate and Energy Solutions finds that corporate resilience planning has grown since COVID-19 but that climate risk is still treated separately from supply chain management, and that resilience frameworks often overlook climate-specific risks.[^4] The Task Force and the Network for Greening the Financial System write from a financial viewpoint, so their classifications are not supply chain standards.

See [[Supply Chain Risk Type]] for the wider set of categories and [[Supply Chain Disruption]] for events.

[^1]: Task Force on Climate-related Financial Disclosures, “Recommendations of the Task Force on Climate-related Financial Disclosures, Final Report, June 2017”. https://assets.bbhub.io/company/sites/60/2020/10/FINAL-2017-TCFD-Report-11052018.pdf
[^2]: UK Climate Change Committee, “Resilient Supply Chains (briefing, 2022)”. https://www.theccc.org.uk/wp-content/uploads/2022/10/Resilient-Supply-Chains-.pdf
[^3]: Network for Greening the Financial System, “NGFS First Progress Report, October 2018”. https://www.ngfs.net/sites/default/files/medias/documents/818366-ngfs-first-progress-report-20181011.pdf
[^4]: Center for Climate and Energy Solutions (C2ES), September 2025, “Assessing the Landscape of Climate Risk and Supply Chain Resilience: A Primer for Corporate Leaders and Climate Risk Professionals”. https://www.c2es.org/wp-content/uploads/2025/09/Climate-Risk-and-Supply-Chain-Report_FINAL_v3.pdf

