
An agent entity is a general semantic entity participating in agent communication, delegation or execution.[^1] It is declared as `AgentEntity` in the core module and is the most general class of the vocabulary. visionGraph places it under the AI Research Area hub.

[[Agent]] is its direct subclass, and [[Human Agent]] and [[Organisational Agent]] sit beneath that, so people and organisations are agents on the same footing as software. Anything an agent depends on at system level is also an agent entity: the `dependsOn` property of an [[Agent System Integration]] ranges over it, so a declared dependency can be another agent or any other participant.[^2]

[[Agent Capability]], [[Agent Task]] and [[Agent Action]] are separate classes and are not agent entities. They describe what agents can do, what is asked of them and what they have done, not who takes part.

[^1]: Semantic Agent Communication Community Group, “Core Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/core.ttl
[^2]: Semantic Agent Communication Community Group, “Agent Ontology” (Agent Ontology, CC BY 4.0). https://github.com/s-agent-comm/agent-ontology/blob/750e06d276dd568313a6c03c4e78203887d3fa4b/ontologies/agent.ttl

