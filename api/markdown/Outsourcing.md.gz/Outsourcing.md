Outsourcing is the transfer of an activity that a firm performed in-house to an outside provider.[^1][^2]

Eurostat defines sourcing as the total or partial movement of core or support business functions currently performed in-house to non-affiliated external suppliers or to affiliated enterprises, located domestically or abroad.[^1] A glossary of the UN Economic and Social Commission for Western Asia describes outsourcing as contracting, sub-contracting or externalising non-core activities to free up cash, personnel, time and facilities for activities where the firm holds a competitive advantage; the entry sits in the ICT domain and gives web sites as its source.[^2]

Medina-Serrano and colleagues frame the underlying choice as a make-or-buy decision between designing and manufacturing parts or services in-house, buying them from external providers, or combining both.[^3] Their keywords include outsourcing, plural sourcing and hybrid sourcing.[^3]

## Scope and distinctions

Pylypenko and Herasymenko separate offshoring, in which a transnational company keeps ownership of the activities it moves abroad, from offshore outsourcing, which involves purchasing products or services from another firm located overseas.[^4] The OECD wording quoted by ESCWA covers both, since it defines offshoring as purchases from foreign providers at arm's length or the transfer of tasks to foreign affiliates.[^5] Eurostat notes that international sourcing is sometimes also called off-shoring, near-shoring, delocalisation or outsourcing.[^1] See [[Offshoring]] and [[Supply Chain Configuration Decision]].

## What the sources do not establish

Eurostat counts moves to affiliated enterprises as sourcing, whereas the ESCWA entry speaks of contracting out to others.[^1][^2] No source opened here gives evidence on the cost, quality or risk effects of outsourcing.[^3]

[^1]: Eurostat, Statistics Explained glossary entry, “Glossary:Sourcing”. https://ec.europa.eu/eurostat/statistics-explained/index.php?title=Glossary:Sourcing
[^2]: United Nations Economic and Social Commission for Western Asia, sustainable development glossary (ICT domain), “Outsourcing”. https://www.unescwa.org/sd-glossary/outsourcing
[^3]: Ruben Medina-Serrano and colleagues, Journal of Industrial Engineering and Management, 2020, “Strategic Sourcing: Developing a Progressive Framework for Make-Or-Buy Decisions”. https://jiem.org/index.php/jiem/article/download/2858/922
[^4]: N. M. Pylypenko and T. V. Herasymenko, Economics Bulletin (Dnipro University of Technology), 2022, “Reasons and dynamics of reshoring in the European Union and USA”. https://ev.nmu.org.ua/docs/2022/4/EV20224_034-041.pdf
[^5]: United Nations Economic and Social Commission for Western Asia, sustainable development glossary (finance domain, citing the OECD), “Offshoring”. https://www.unescwa.org/sd-glossary/offshoring

