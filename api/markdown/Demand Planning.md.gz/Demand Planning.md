Demand planning is the part of supply chain planning that produces the demand plan, which serves as the strategy from which the other plans in the supply chain are generated.[^1]

Jatta, citing Wagner, gives the purpose of demand planning as improving decisions that affect demand accuracy and the determination of safety stock to achieve desired service levels, through collaborative efforts.[^1] He says forecasting and demand planning are at times used interchangeably but are functionally distinct: the objective of forecasting is to predict demand, while that of demand planning is to shape demand and produce a resource requirement plan, citing Malpass and Shah.[^1]

Jatta calls demand information distortion a pervasive and perennial challenge to demand planning and forecasting, and names collaborative planning, forecasting and replenishment and sales and operations planning as two well-documented tools against it.[^1]

## Scope and distinctions

Other sources use the term differently. Goetschalckx writes that an often-used alternative term for short-term forecasting is demand planning, specifically tactical and operational demand planning.[^2] Chopra and Meindl note that the forecasting module of a supply chain IT system is often called the demand planning module and is a core supply chain software product.[^3] In the sales and operations planning process described by Jatta, the demand planning team leads the organisation in the monthly cycle and works with other functional teams to synchronise supply with demand.[^1] See [[Demand Forecasting]], [[Demand Management]] and [[Sales and Operations Planning]].

## What the sources do not establish

Sources disagree on whether demand planning is distinct from forecasting. Jatta treats the two as different activities, whereas Goetschalckx and Chopra and Meindl use the term for forecasting and for forecasting software.[^1][^2][^3] The earlier unsourced body of this page was replaced.[^1]

[^1]: John S. Jatta, Wichita State University dissertation, 2016 (SOAR repository), “Supply Chain Planning and Control: An Examination of Demand Planning and Inventory Classification”. https://soar.wichita.edu/server/api/core/bitstreams/282b6411-c8a8-463c-b478-ce91fe475a23/content
[^2]: Marc Goetschalckx, Georgia Institute of Technology course text, “Chapter 2. Forecasting”. https://www2.isye.gatech.edu/~mgoetsch/cali/logistics_systems_design/forecasting/forecasting.pdf
[^3]: Sunil Chopra and Peter Meindl, Supply Chain Management textbook chapter (copy hosted by Indiana University Kelley School of Business), “Chapter 7: Demand Forecasting in a Supply Chain”. https://host.kelley.iu.edu/mabert/e730/chopra-chap-7.pdf

