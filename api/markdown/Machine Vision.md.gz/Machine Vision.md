Machine vision is the engineering discipline that applies digital imaging, optics, and automated image analysis to perform inspection, measurement, guidance, and identification tasks in industrial and manufacturing environments. It integrates hardware components — cameras, illumination, optics, and frame grabbers — with software pipelines that extract actionable decisions from image data, typically operating in real time under strict cycle-time constraints. Distinguished from the broader research field of computer vision by its emphasis on reliability, determinism, and seamless integration with programmable logic controllers and industrial automation systems. Modern machine vision systems increasingly incorporate deep learning inference alongside classical morphological and blob-analysis algorithms to handle appearance variability that rule-based methods alone cannot address.

### Overview

- Machine vision emerged as a formal engineering discipline in the 1970s and 1980s, driven by the need to automate repetitive visual inspection tasks on production lines that were too fast, too fatiguing, or too precise for human inspectors.
- The discipline sits at the intersection of optics, electronics, and software. A machine vision system captures images under controlled illumination, extracts measurements or classifications from those images, and passes decisions to downstream control systems — typically a programmable logic controller (PLC) or robot controller — within the cycle time of the production process.
- The distinction between machine vision and [[Computer Vision]] is partly cultural and partly technical: machine vision connotes the application-engineering side (reliability, harsh environments, integration standards, real-time constraints), while computer vision connotes the broader scientific study of visual perception and representation.
- The sector is served by dedicated industry bodies such as the Automated Imaging Association (AIA) and standardisation efforts including the [[GenICam Standard]] interface that decouples camera hardware from software libraries.

### Key Components

- **Optics and Illumination**
  - [[Optical Systems]] — lenses, telecentric optics for dimensional metrology, macro lenses for close-up inspection.
  - [[Illumination]] — controlled lighting (structured light, backlighting, coaxial, ring, dome, strobe) is arguably the most critical variable; repeatable images require repeatable illumination.
  - Spectral selection — near-infrared, UV, or polarised light can reveal surface features invisible to the naked eye.
- **Image Acquisition**
  - [[Camera]] types: area scan, line scan (for web or continuous-motion inspection), time-of-flight, hyperspectral.
  - [[Sensor]] technologies: CCD and CMOS image sensors with varying resolution, frame rate, and sensitivity trade-offs.
  - Frame grabbers and GigE Vision / USB3 Vision interfaces carrying images to processing hardware.
- **Image Processing Pipeline**
  - [[Image Preprocessing]] — noise reduction, flat-field correction, geometric distortion correction.
  - [[Edge Detection]] and morphological operations for shape analysis.
  - Blob analysis, caliper tools, and template matching for classical rule-based inspection.
  - [[Image Segmentation]] for region-of-interest isolation.
- **Analysis and Classification**
  - [[Feature Extraction]] — deriving geometric, photometric, and textural descriptors.
  - [[Pattern Recognition]] — classical statistical classifiers and look-up approaches.
  - [[Convolutional Neural Network]] (CNN) inference for defect classification and [[Object Detection]] when appearance variability exceeds rule-based capability.
  - [[Optical Character Recognition]] (OCR) for reading part numbers, date codes, and serial numbers directly on components.
- **Integration and Output**
  - Communication with PLCs via digital I/O, serial, Ethernet/IP, PROFINET, or OPC-UA.
  - [[Robot Guidance]] — providing 2D or 3D pose estimates to articulated robots for pick-and-place or assembly.
  - Data logging to [[Quality Control]] databases and statistical process control (SPC) systems.

### Applications and Use Cases

- **Dimensional Measurement** — verifying that machined parts, injection-moulded components, or assembled products meet geometric tolerances without contact, replacing or supplementing CMM (coordinate measuring machine) workflows.
- **Defect Detection** — surface-scratch inspection on glass, metal, or painted surfaces; solder joint inspection in PCB assembly; label verification on pharmaceutical packaging.
- **[[Barcode Scanning]] and Code Reading** — reading 1D barcodes, 2D DataMatrix codes, QR codes, and direct-part markings (DPM) at high speed on moving conveyors.
- **[[Robot Guidance]]** — 2D bin-picking for randomly oriented parts; 3D pose estimation using stereo or structured-light [[3D Imaging]] for flexible assembly.
- **Presence/Absence Verification** — confirming all required components are present in an assembly before downstream processing.
- **Agricultural Sorting** — grading fruit and vegetables by size, colour, and surface blemish; detecting foreign objects.
- **Medical Device and Pharmaceutical Inspection** — sterile-environment inspection of syringe barrels, tablet coating, and fill-level verification, subject to FDA 21 CFR Part 11 audit trails.
- **Traffic and Transport** — licence-plate recognition, axle-load cameras, rail-track inspection systems.
- **[[Augmented Reality]] Calibration** — machine vision underpins spatial calibration and marker tracking in industrial AR guidance overlays.

### Standards and Context

- **GenICam** (Generic Interface for Cameras) — EMVA standard defining a transport-layer-agnostic API for camera control and image acquisition, enabling software to work across GigE Vision, USB3 Vision, CoaXPress, and CameraLink interfaces without driver changes.
- **GigE Vision** — AIA standard for transmitting images over Gigabit Ethernet, widely adopted in industrial cameras; successor interfaces include 10GigE Vision.
- **USB3 Vision** — AIA standard extending GenICam over USB 3.0, common in embedded and compact vision systems.
- **CoaXPress** — JIIA/AIA standard for very-high-speed camera links over coaxial cable, used in ultra-high-frame-rate line scan applications.
- **OPC-UA** — industrial communication standard increasingly used to expose machine vision result data to MES and [[Digital Twin]] systems, enabling closed-loop process control.
- **ISO 9001 / IATF 16949** — quality management standards that mandate automated inspection in automotive supply chains, driving machine vision adoption.
- **FDA 21 CFR Part 11** — US regulation governing electronic records and signatures in pharmaceutical manufacturing; machine vision inspection systems must maintain compliant audit logs.
- The Automated Imaging Association (AIA, part of A3) publishes market reports, maintains standards, and runs the annual Vision Show trade event.

### Integration with AI and Emerging Trends

- The adoption of [[Deep Learning]], particularly [[Convolutional Neural Network]] architectures, has shifted machine vision from hand-crafted rule sets to learned feature representations, dramatically expanding the range of inspection problems that are commercially viable to automate.
- [[Transfer Learning]] from large image classification networks (e.g., ImageNet-pretrained backbones) enables inspection classifiers to be trained with hundreds rather than tens of thousands of labelled defect images.
- Edge deployment of AI inference on embedded GPU or FPGA hardware inside smart cameras reduces latency and bandwidth, moving processing closer to the sensor.
- Integration with [[Digital Twin]] models enables simulation-driven development of inspection algorithms before physical production assets are available.
- 3D machine vision using structured light, time-of-flight, and stereo disparity maps is expanding robot-guidance accuracy and enabling new measurement modalities.
- Hyperspectral imaging combines machine vision with spectroscopy for food safety, pharmaceutical authenticity, and recycling-stream sorting.

### Provenance

