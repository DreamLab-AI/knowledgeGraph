Automatic identification and data capture (AIDC) names the field of techniques, including barcodes and radio frequency identification, that identify items automatically.[^1][^2][^3]

ISO/IEC 19762 is the harmonized vocabulary for the field. The catalogue record for the 2016 edition says it provides general terms and definitions for automatic identification techniques and data entry, and essential terms for non-technical users who need to communicate with AIDC specialists.[^1] That edition is shown as withdrawn, and the record points to ISO/IEC 19762:2025 as the new version, which was not opened here.[^1]

## Barcodes and radio tags

GS1 describes barcodes as symbols that can be scanned electronically using laser or image-based technology, and says they let retailers, manufacturers, transport providers and hospitals automatically identify and track products as they move through the supply chain.[^2] See [[Barcode]] and [[QR Code]].

Radio frequency identification works differently. The RAIN Alliance describes RFID as a wireless technology that allows the easy and inexpensive allocation and detection of the identity of an item, with a tag placed on the item and a reader used to interrogate the tag.[^3] GS1 says RAIN RFID tags can be read at distances well in excess of 10 metres without line-of-sight contact.[^4] See [[RFID]], [[RAIN RFID Tag]] and [[Near Field Communication]].

## In the GS1 system

The GS1 General Specifications include AIDC validation rules, which provide rules for validating and processing GS1 element strings without human intervention.[^5] The General Specifications say GS1 identifiers are defined independently of technology such as AIDC data carriers, and that the chosen technology defines how an identifier is represented.[^5]

## What the sources do not establish

No source opened here gives a plain definition of AIDC. The ISO record is an abstract of a withdrawn edition, and its wording is awkward, so this page describes the field through how GS1 and the RAIN Alliance use it. An address for the AIM glossary returned a not-found error. The sources do not compare the accuracy, cost or reading speed of the technologies.[^1][^2][^3]

[^1]: ISO, “ISO/IEC 19762:2016 - Information technology — Automatic identification and data capture (AIDC) techniques — Harmonized vocabulary” (catalogue record). https://www.iso.org/standard/61301.html
[^2]: GS1, “GS1 Barcodes”. https://www.gs1.org/standards/barcodes
[^3]: RAIN Alliance, “FAQs”. https://rainrfid.org/faqs/
[^4]: GS1, “RFID”. https://www.gs1.org/standards/epc-rfid
[^5]: GS1, “GS1 General Specifications Standard”, release 26.0. https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf

