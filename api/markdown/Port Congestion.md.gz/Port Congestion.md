Port congestion is the build-up of vessels waiting for, or delayed at, a port, so that ships spend longer than normal in port; no source opened here defines the term, and the description rests on how port time is measured and on one account of an episode.[^1][^2]

## How time in port is measured

The World Bank and S&P Global Market Intelligence produce the Container Port Performance Index, which treats port time as all time from a vessel's AIS-detected arrival at the port limit or anchorage zone to the time it leaves the berth.[^1] Its arrival hours, the time from arrival at anchorage or pilot station to the start of cargo operations, consist of waiting time, where applicable, and steam-in time.[^1] The index excludes operations after the ship leaves the berth, such as bunkering, repairs or waiting in a safe area, because they are not influenced by the operational performance of the port.[^1] The note does not call any of this congestion, so waiting time is a component of the measure rather than a definition of the problem.

## Episode of 2020 to 2022

AMRO reports widespread port congestion, shipment delays and a surge in freight costs since the third quarter of 2020, and says that as port congestion worsened in 2021, manufacturing surveys indicated longer supplier delivery times.[^2] It notes that delays at US ports cascaded through the supply chains and contributed to congestion worldwide.[^2] A vector autoregression model in the same note, using vessel turnaround as a proxy, shows that more congestion in the United States can have a statistically significant impact on congestion in other countries.[^2]

AMRO names several causes: a shortage of container boxes in Asia against a pile-up of empty containers at ports in the West, and, during the Shanghai lockdowns of 2022, a shortage of truck drivers that worsened congestion despite port staff remaining onsite.[^2] It also reports estimates, attributed to Tirschwell, that congestion caused a 10-15 percent reduction in vessel capacity globally.[^2]

## Scope

Port congestion is a type of [[Supply Chain Disruption]] and concerns the [[Seaport]]. The index covers container ports only, and the AMRO account is a single note from 2022.

[^1]: World Bank and S&P Global Market Intelligence, Methodology Note: Container Port Performance Index (CPPI), 10 June 2026. https://thedocs.worldbank.org/en/doc/aac122f6df85534428d66a7b9af4b7f6-0400012026/original/CPPI-Methodology-Note.pdf
[^2]: ASEAN+3 Macroeconomic Research Office (AMRO), Analytical Note, 25 July 2022, “The Great Supply Chain Disruption: What Does the Shipping Crystal Ball Foretell?”. https://amro-asia.org/wp-content/uploads/2022/07/AMRO-Analytical-Note_The-Great-Supply-Chain-Disruption_What-Does-the-Shipping-Crystal-Ball-Foretell-_July-25-2022.pdf

