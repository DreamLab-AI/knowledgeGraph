Bytecode is a compact, platform-independent instruction set produced by compiling source code, designed to be executed by a virtual machine rather than directly by hardware. In blockchain systems, smart contracts written in high-level languages such as Solidity are compiled to bytecode that the Ethereum Virtual Machine deterministically executes across every node. Bytecode strikes a balance between the portability of source code and the efficiency of native machine code.

### Overview

- Bytecode occupies the layer between human-readable source and the raw operations a virtual machine performs, encoding a program as a sequence of single-byte opcodes and their operands. A compiler translates high-level contract logic into this intermediate form once, after which any conforming virtual machine can execute it identically. On a blockchain this determinism is essential: every validating node must reach the same result from the same bytecode and inputs.

### Key aspects

- Compact opcode-based instruction encoding for a virtual machine
- Platform independence: write once, execute on any conforming VM
- Deterministic execution required for consensus across nodes
- Gas accounting per opcode to bound and price computation
- Decompilation and verification of deployed contract bytecode

### Applications

- Deployment and execution of Ethereum smart contracts
- Verification that on-chain bytecode matches published source
- Cross-platform virtual-machine languages such as the JVM and WebAssembly
- Static analysis and auditing of compiled contract logic

### Provenance

