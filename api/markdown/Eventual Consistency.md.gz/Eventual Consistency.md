Eventual consistency is a consistency model for distributed data stores that guarantees that, in the absence of new updates, all replicas of a given data item will eventually converge to the same value. The model deliberately relaxes the requirement for immediate, global agreement in favour of higher availability and tolerance of network partitions, as described by the CAP theorem. Reads may transiently return stale data, and divergent replicas are reconciled through background propagation, gossip protocols, or explicit conflict resolution strategies such as last-write-wins or multi-version concurrency control. It is foundational to the design of large-scale internet-facing systems including DNS, distributed caches, and wide-area NoSQL databases.

### Overview

- Eventual consistency emerged as a pragmatic engineering response to the fundamental trade-offs exposed by the [[CAP Theorem]]: a distributed system can guarantee at most two of consistency, availability, and partition tolerance simultaneously. By relaxing the consistency guarantee, architects unlock both availability and partition tolerance — essential properties for globally replicated systems that must continue serving requests during network splits.
- The model was popularised through Amazon's Dynamo paper (2007) and Werner Vogels' articulation of the trade-off at scale. It underlies the design of systems like Amazon DynamoDB, Apache Cassandra, Riak, CouchDB, and the global Domain Name System (DNS).
- Under eventual consistency, a write to one replica is propagated asynchronously to peers. During the propagation window, concurrent reads from different replicas may return different values. Once propagation completes and no further writes occur, all replicas settle on a common value — typically within milliseconds to seconds in well-tuned deployments.

### Key Mechanisms

- **[[Gossip Protocol]]** — Nodes periodically exchange state digests with randomly chosen peers, flooding updates across the cluster without a central coordinator. This provides probabilistic convergence with logarithmic message complexity.
- **[[Vector Clocks]]** — Logical timestamps that track causality between events across nodes. Each node maintains a vector of counters; comparisons reveal whether updates are concurrent, causally related, or identical, enabling principled conflict detection.
- **[[Anti-Entropy]]** — Background reconciliation processes (often using [[Merkle Tree]] comparisons) periodically compare replica state and patch divergences, guaranteeing eventual convergence even when gossip misses updates.
- **[[Conflict Resolution]]** — When concurrent updates to the same key are detected, a resolution strategy must be applied:
  - *Last-Write-Wins (LWW)*: the update with the highest timestamp (or logical clock value) wins; simple but may lose data.
  - *Multi-Value (siblings)*: all concurrent versions are preserved and surfaced to the application for resolution (used by Riak).
  - *[[CRDT]] (Conflict-free Replicated Data Types)*: data structures designed so that all concurrent operations commute, eliminating conflicts entirely. Examples include G-Counters, OR-Sets, and LWW-Registers.
- **[[Multi-Version Concurrency Control]]** — Retaining multiple versions of a value allows readers to access a consistent snapshot whilst writers propagate updates in the background.
- **[[Quorum Consensus]]** — Read and write quorums (R, W, N where R + W > N) can be tuned to strengthen or weaken consistency guarantees dynamically, giving operators a continuous dial between availability and consistency.
- **Hinted Handoff** — If a target replica is temporarily unavailable, another node stores the update with a hint and forwards it once the target recovers, preserving availability without blocking the write.

### Consistency Spectrum

- Eventual consistency sits at one end of a spectrum of [[Consistency Model]] variants. Key positions on that spectrum include:
  - *Eventual consistency* — weakest guarantee; maximum availability.
  - *Monotonic read consistency* — once a value is read, subsequent reads return the same or newer value.
  - *Read-your-writes consistency* — a client always sees its own writes.
  - *Causal consistency* — causally related operations are seen by all nodes in causal order.
  - *Sequential consistency* — all nodes see operations in the same total order (not necessarily real time).
  - *[[Linearizability]]* — real-time, atomic ordering; the strongest practical guarantee.
  - *[[Serializability]]* — transaction-level ordering; the basis of [[ACID Properties]].

### Applications and Use Cases

- **Domain Name System (DNS)** — The canonical real-world example: DNS record updates propagate across global resolver infrastructure over minutes to hours. Clients may read stale records during propagation.
- **[[NoSQL Database]] systems** — Apache Cassandra, Amazon DynamoDB, Riak, CouchDB, and Voldemort are all designed around eventual consistency with tunable quorums.
- **Distributed Caches** — Systems such as Memcached clusters and Redis Cluster use eventual consistency to maximise read throughput.
- **Content Delivery Networks** — CDN edge nodes cache content with TTL-based invalidation; during cache refresh windows, users in different regions may receive different versions.
- **Collaborative Editing** — [[CRDT]]-based editors (e.g. Automerge, Yjs) rely on eventual consistency semantics to allow offline edits that merge without conflicts when peers reconnect — used in Notion, Linear, and Figma.
- **[[Blockchain Consensus]]** — Proof-of-Work and many Proof-of-Stake blockchains exhibit eventual consistency: forks may coexist briefly before the canonical chain is determined by accumulated work or stake weight.
- **[[Federated Learning]]** — Gradient aggregation across federated nodes is inherently eventually consistent; parameter server architectures tolerate stale gradients to maintain training throughput.
- **Shopping Carts and Wish Lists** — Amazon's Dynamo was explicitly designed for shopping cart use cases where temporary divergence is acceptable and merge strategies (union of items) prevent data loss.
- **Social Media Feeds** — Like counts, follower counts, and feed ordering typically employ eventual consistency; users may briefly see differing counts across page loads.

### Design Trade-offs

- Adopting eventual consistency imposes application-level responsibilities that are absent under strong consistency:
  - Application code must tolerate stale reads and handle divergent values gracefully.
  - Conflict resolution logic must be explicitly designed; the choice of strategy (LWW vs CRDT vs siblings) directly affects correctness and user experience.
  - Testing and reasoning about concurrent behaviour is significantly harder; tools such as [[TLA+]] and model checkers are commonly used to verify correctness.
  - Observability tooling must track replication lag, anti-entropy success rates, and conflict rates to detect consistency degradation in production.
- Where data correctness is paramount (financial ledgers, inventory counts), tunable consistency via quorum reads/writes or selective strong consistency for critical paths is preferred over pure eventual consistency.

### Standards and Context

- No formal ISO or IETF standard governs eventual consistency as a model, but it is described in several foundational academic and industry publications:
  - Vogels, W. (2009). "Eventually Consistent." *ACM Queue* 6(6). — introduced the term to mainstream distributed systems discourse.
  - DeCandia et al. (2007). "Dynamo: Amazon's Highly Available Key-Value Store." *SOSP '07*.
  - Shapiro et al. (2011). "Conflict-free Replicated Data Types." *SSS '11*. — formal basis for [[CRDT]].
- The [[PACELC Theorem]] extends [[CAP Theorem]] to also characterise the latency/consistency trade-off in the absence of partitions, providing a more nuanced framework for comparing systems.
- Apache Cassandra's consistency levels (ONE, QUORUM, ALL) and Amazon DynamoDB's eventually consistent and strongly consistent read modes are the most widely deployed production implementations of tunable eventual consistency.

### Provenance

