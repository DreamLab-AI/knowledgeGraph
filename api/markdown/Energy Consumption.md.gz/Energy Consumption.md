Energy consumption is the total quantity of energy drawn by a system, process, or device over a defined time period, typically expressed in kilowatt-hours (kWh) or joules. In computing and digital infrastructure contexts it encompasses the electrical power used by processors, memory, networking equipment, and cooling systems. It is a foundational metric in evaluating the environmental footprint, operational cost, and sustainability compliance of data centres, blockchain networks, AI training pipelines, and distributed systems. Minimising energy consumption without sacrificing throughput or reliability is a core design constraint across hardware architecture, consensus mechanisms, and large-scale deployment.

### Overview

- Energy consumption quantifies how much electrical or thermal energy a process requires to complete its work. It differs from *power* (instantaneous rate, in watts) in that it integrates power over time: E = P × t.
- In information technology, total energy draw depends on:
  - Compute intensity — the number and type of arithmetic operations performed
  - Memory access patterns — DRAM refresh and bandwidth costs are non-trivial
  - Data movement — inter-chip, inter-node, and cross-datacentre transfers
  - Idle overhead — baseline draw of powered-on but inactive components
- Why it matters:
  - **Cost**: electricity is often the dominant operational expense for large-scale infrastructure
  - **Carbon**: most grids still carry significant fossil-fuel generation, making energy draw directly proportional to greenhouse gas emissions
  - **Regulation**: the EU [[Corporate Sustainability Reporting Directive]] and comparable frameworks require organisations to disclose Scope 2 (purchased electricity) and Scope 3 emissions
  - **Hardware design**: thermal limits set by [[Thermal Design Power]] constrain clock speeds, core counts, and packaging density

### Key Components

#### Measurement Units and Metrics

- **kWh / MWh / GWh** — standard billing and reporting units for electrical energy
- **[[Power Usage Effectiveness]] (PUE)** — ratio of total facility power to IT equipment power; a PUE of 1.0 is theoretically perfect; hyperscale operators typically achieve 1.1–1.2
- **[[Carbon Usage Effectiveness]] (CUE)** — extends PUE to account for carbon intensity of the energy supply
- **[[Water Usage Effectiveness]] (WUE)** — companion metric for cooling water overhead
- **Total Cost of Ownership (TCO)** — energy spend typically represents 40–60 % of multi-year TCO for compute-intensive workloads

#### Compute Subsystems

- **CPU energy** — dominated by leakage current, clock-gating effectiveness, and instruction-level parallelism
- **GPU / accelerator energy** — matrix-multiply units (tensor cores, matrix engines) consume peak power during [[Deep Learning]] inference and training
- **Memory hierarchy** — DRAM access costs orders of magnitude more energy per bit than on-chip SRAM; [[Memory Bandwidth]] optimisation directly reduces consumption
- **Networking** — high-speed NICs, switches, and transceivers contribute measurably at datacenter scale

#### Cooling and Facility Overhead

- Air-side economisation, liquid cooling (direct-to-chip or immersion), and free-cooling are primary strategies to reduce the facility overhead captured by [[Power Usage Effectiveness]]
- [[Data Centre]] location choices (cold climates, proximity to hydroelectric generation) influence both cooling costs and grid carbon intensity

### Applications and Use Cases

#### Blockchain and Consensus Mechanisms

- [[Proof of Work]] (PoW) consensus requires miners to perform repeated hash computations, consuming substantial electricity proportional to network hash rate
- The [[Proof of Stake]] model eliminates competitive hashing; validators lock collateral rather than compute, reducing network-level energy consumption by orders of magnitude (Ethereum's merge to PoS is the canonical example)
- [[Distributed Ledger Technology]] architects must weigh the security properties of PoW against the energy profile of alternative consensus mechanisms such as [[Delegated Proof of Stake]] or [[Proof of Authority]]

#### Artificial Intelligence and Machine Learning

- [[AI Model Training]] for large language models and diffusion models involves weeks of sustained GPU cluster operation; the energy draw of a single large training run can be comparable to several transatlantic flights
- [[Inference]] at scale is increasingly the dominant energy cost as models are deployed to millions of users
- Techniques such as [[Model Quantisation]], [[Knowledge Distillation]], and [[Sparse Activation]] aim to reduce per-token or per-image energy cost
- [[Neuromorphic Computing]] and [[In-Memory Computing]] architectures promise sub-watt inference by co-locating computation with storage

#### Cloud and Data Centre Operations

- Hyperscale providers publish annual [[Sustainability]] reports disclosing total energy consumption, [[Renewable Energy]] procurement, and progress toward net-zero commitments
- [[Workload Scheduling]] across time zones and grid-mix profiles (carbon-aware computing) shifts jobs to times and locations with lower-carbon electricity
- [[Serverless Computing]] and function-as-a-service reduce idle energy by consolidating workloads and suspending unused capacity

#### Edge and IoT

- [[Edge Computing]] devices operate under strict power budgets (milliwatts for sensors, a few watts for edge gateways), requiring aggressive duty-cycling, [[Dynamic Voltage and Frequency Scaling]] (DVFS), and sleep-state management
- [[Internet of Things]] deployments with battery-powered nodes treat energy consumption as a primary design constraint alongside latency and bandwidth

#### Spatial Computing and XR

- [[Head-Mounted Displays]] for [[Augmented Reality]] and [[Virtual Reality]] are constrained by battery capacity and thermal comfort; rendering, sensor fusion, and wireless streaming all draw from the same limited budget
- Foveated rendering and [[Dynamic Resolution Scaling]] reduce GPU energy by focusing full-quality rendering only where the user is looking

### Standards and Context

- **ISO 50001** — international standard for [[Energy Management Systems]]; specifies requirements for establishing, implementing, and improving energy performance
- **IEC 62443** — industrial cybersecurity standard that intersects with energy monitoring in operational technology environments
- **Green Grid Metrics** — PUE, CUE, WUE published by The Green Grid consortium and widely adopted by hyperscale operators
- **EU Energy Efficiency Directive (EED)** — mandates energy audits and efficiency improvement targets for large enterprises operating in EU member states
- **Science Based Targets initiative (SBTi)** — provides a framework for companies to set emissions reduction targets aligned with [[Climate Change]] agreements, which requires robust energy consumption accounting
- **GHG Protocol Scope 2 Guidance** — distinguishes location-based and market-based methods for attributing purchased electricity emissions; directly relevant to data centre and cloud provider reporting
- **ASHRAE TC9.9** — thermal guidelines for data processing environments that inform acceptable operating ranges and influence cooling energy design targets
- **IEEE P2030** — smart grid interoperability standards relevant to demand-response programmes where data centres shed or shift load in response to grid signals

### Provenance

