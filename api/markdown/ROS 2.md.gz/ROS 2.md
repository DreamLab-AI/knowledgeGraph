ROS 2 (Robot Operating System 2) is an open-source robotics middleware framework developed by Open Robotics that provides a standardised publish-subscribe communication layer built on the DDS (Data Distribution Service) standard, along with a comprehensive ecosystem of drivers, libraries, and tools for sensor integration, motion planning, simulation, and hardware abstraction. ROS 2 supersedes ROS 1 with support for real-time execution, multi-robot systems, production-grade security via DDS-Security, and native Windows and macOS compatibility. It has become the de facto standard software framework for research and increasingly for commercial robotic platforms.

### Semantic Classification

### Content

- ROS 2 is structured around the concept of nodes—self-contained processes that publish and subscribe to typed message topics, provide and call services, and expose action servers for long-running tasks. The underlying transport is DDS (most commonly Eclipse Cyclone DDS or eProsima Fast DDS), which provides configurable Quality of Service (QoS) policies including reliability, durability, and deadline settings essential for real-time robotic applications.
- The ROS 2 ecosystem includes Navigation 2 (Nav2) for autonomous mobile robot navigation, MoveIt 2 for manipulator motion planning, ros2_control for hardware-abstracted joint control, and Gazebo or Ignition simulators for physics-accurate robot simulation. The colcon build tool and the ROS package manager rosdep standardise dependency management across the ecosystem. URDF and SDF robot description formats are used to define kinematic and dynamic properties of robot models consumed by simulation, motion planning, and visualisation tools such as RViz 2.
- ROS 2's adoption in production environments is driven by its support for AUTOSAR-compliant real-time executors (via the rclcpp Executor API), DDS-Security for encrypted, authenticated inter-node communication, and its compatibility with safety-certified operating systems such as QNX. The ROS 2 Iron Irwini and Jazzy Jalisco LTS distributions support extended maintenance periods appropriate for product deployment cycles.

### Current Landscape (2026)

- The release cadence has settled into a yearly LTS/non-LTS rhythm: Kilted Kaiju (eleventh release, May 2025, non-LTS, EOL late 2026) followed by Lyrical Luth (twelfth release and latest LTS, 22 May 2026, supported to May 2031 on Ubuntu 26.04), while Jazzy Jalisco (May 2024, LTS to 2029) remains the practical default for mature package support and Humble Hawksbill still dominates deployed industrial fleets.
- Kilted Kaiju made Eclipse Zenoh (rmw_zenoh_cpp) the first non-DDS middleware promoted to Tier 1, packaged with the binary releases; it uses a brokered zenohd router for discovery instead of DDS UDP multicast, making cloud-connected and multi-host graphs far easier to route over TCP/QUIC/TLS, though Fast DDS remains the shipped default RMW.
- Kilted delivered concrete tooling gains: a Python events executor ported from rclcpp (up to ~10x lower callback latency, opt-in), CLI action introspection via ros2 action echo, multi-bag rosbag playback with a progress bar and a first-class recording action server, NV12 image support in common_interfaces, and a switch to Pixi/Conda for reproducible Windows installs.
- The end of ROS 1 was a defining event: Noetic reached EOL on 31 May 2025, ending all security patches and pushing teams onto ros1_bridge incremental migration, per-node rewrites, or freeze-and-greenfield strategies; MCAP has become the recommended rosbag backend over SQLite3.
- The 2026 stack has consolidated around ROS 2 plus Nav2, MoveIt 2, ros2_control, Gazebo Harmonic and NVIDIA Isaac Sim 5.0, increasingly topped by vision-language-action models (OpenVLA, pi0, GR00T N1) on humanoid platforms; ABI Research reported roughly 72% of commercial robots using ROS/ROS 2 in 2025.
- Security remains the sharpest open challenge: default ROS 2 deployments still ship without authentication or encryption, SROS2/DDS-Security is complex to configure and carries known weaknesses (the 2022 Deng et al. V1–V3 findings, a 2025 demonstration of trojanised sros2 CLI supply-chain attacks exfiltrating keystore credentials), and real-world incidents such as Ghost Robotics Vision 60 CVE-2025-41108 (CVSS 9.2, disclosed October 2025) underline the exposure.
- Functional-safety certification is still a frontier: ROS 2 itself is not safety-certified, so industrial integrators lean on separate SIL 3/PLe safety PLCs alongside standards such as ISO 10218, ISO/TS 15066 and IEC 62443, while the ROS-Industrial Conference 2025 flagged documentation quality, real-time performance and humanoid safety as persistent gaps.

### References

- 1. Open Robotics (2025). ROS 2 Kilted Kaiju released. https://www.openrobotics.org/blog/2025/5/23/ros-2-kilted-kaiju-released
- 2. ROS 2 Documentation (2025). Kilted Kaiju (codename 'kilted'; May, 2025) release notes. https://docs.ros.org/en/jazzy/Releases/Release-Kilted-Kaiju.html
- 3. ROS 2 Documentation (2026). Different ROS 2 middleware vendors (Rolling). https://docs.ros.org/en/rolling/Concepts/Intermediate/About-Different-Middleware-Vendors.html
- 4. iotdigitaltwinplm.com (2026). ROS 2 DDS vs Zenoh: Robotics Middleware Compared (2026). https://iotdigitaltwinplm.com/ros2-dds-vs-zenoh-robotics-middleware-comparison-2026/
- 5. ROS-Industrial (2026). ROS 2 in Industry: Key Takeaways from the ROS-Industrial Conference 2025. https://rosindustrial.org/news/2026/2/17/ros-2-in-industry-key-takeaways-from-the-ros-industrial-conference-2025
- 6. arXiv (2026). Cybersecurity of Teleoperated Quadruped Robots: A Systematic Review. https://arxiv.org/html/2602.23404v1

### Provenance

