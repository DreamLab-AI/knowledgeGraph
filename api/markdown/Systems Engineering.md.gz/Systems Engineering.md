Systems Engineering is an interdisciplinary methodology for designing, integrating, and managing complex systems over their entire lifecycle, from concept definition through disposal. It applies structured processes — requirements analysis, functional decomposition, architecture definition, interface control, verification, and validation — to ensure that the emergent behaviour of integrated subsystems meets overall system objectives within defined cost, schedule, and performance constraints. Systems Engineering is distinguished from narrower disciplines by its holistic perspective: it treats the system as a whole rather than optimising individual components in isolation. Governing standards include ISO/IEC/IEEE 15288 (Systems and Software Life Cycle Processes) and the INCOSE Systems Engineering Handbook.

### Overview

- Systems Engineering emerged as a discipline in the mid-twentieth century, driven by the complexity of aerospace, defence, and nuclear programmes where failures of subsystem integration caused programme-level failures. The discipline formalises the insight that large engineered systems exhibit emergent properties that cannot be predicted by analysing components in isolation.
- Core motivation: as systems grow in scale, the interfaces between subsystems become a primary source of risk. Systems Engineering manages this risk through structured communication, documented interfaces, and rigorous lifecycle processes.
- Unlike [[Project Management]], which governs schedule and resources, Systems Engineering governs technical content — what the system must do, how it is decomposed, how components interact, and how conformance is demonstrated.
- Modern practice increasingly employs [[Model-Based Systems Engineering]] (MBSE), in which a central system model (often in SysML or similar notation) replaces document-centric artefacts, enabling consistency checking and automated traceability across lifecycle phases.
- The discipline spans domains: aerospace (NASA, ESA), defence (MIL-STD-499), automotive (ISO 26262 integration), energy, rail, healthcare devices, and large-scale software-intensive systems.

### Key Components

#### Lifecycle Processes (ISO/IEC/IEEE 15288)

- **Concept Definition** — mission analysis, stakeholder needs elicitation, concept of operations (CONOPS)
- **System Requirements Definition** — translating stakeholder needs into verifiable system requirements; traceable to [[Requirements Engineering]]
- **Architecture Definition** — logical and physical decomposition, allocation of functions to physical elements; feeds [[System Architecture]]
- **Design Definition** — detailed design of elements, interface specifications, technology selection
- **System Analysis** — trade studies, modelling, [[Simulation]] to evaluate design options
- **Implementation** — realisation of elements; integration with [[Software Engineering]] and hardware engineering
- **Integration** — incremental assembly and testing of subsystems; requires [[Interface Management]]
- **Verification** — confirming the system meets its specified requirements (did we build it right?)
- **Validation** — confirming the system meets stakeholder needs in the operational context (did we build the right thing?)
- **Transition** — deployment into the operational environment
- **Operation & Maintenance** — in-service support, sustainment, performance monitoring
- **Disposal** — decommissioning, safety-compliant end-of-life processes

#### Cross-Cutting Technical Processes

- [[Requirements Engineering]] — elicitation, analysis, specification, management, traceability
- [[Risk Management]] — identification, analysis, mitigation planning, residual risk acceptance
- [[Configuration Management]] — baseline control, change management, version governance
- [[Interface Management]] — interface control documents (ICDs), interface control working groups (ICWGs)
- Technical Performance Measurement (TPM) — tracking key parameters against requirements margins
- Decision Analysis — structured trade studies using weighted criteria and [[Simulation]]

#### Enabling Methods & Notations

- SysML (Systems Modelling Language) — block definition diagrams, parametric diagrams, activity diagrams
- DODAF / TOGAF / NAF — architecture frameworks used in defence and enterprise contexts; relates to [[Technical Architecture Framework]]
- Functional Flow Block Diagrams (FFBD)
- N2 Charts and Dependency Structure Matrices (DSM) — interface mapping tools
- Fault Tree Analysis (FTA) and Failure Modes Effects and Criticality Analysis (FMECA) — [[Functional Safety]] tools
- [[Digital Twin]] — runtime models enabling in-service systems engineering

### Applications and Use Cases

#### Aerospace and Space

- NASA mission development (Apollo, Artemis) employs Systems Engineering as the primary technical discipline governing all programme phases.
- ESA applies ECSS standards (European Cooperation for Space Standardisation) derived from Systems Engineering principles for satellite and launcher development.

#### Defence

- MIL-STD-499 (US) established early formalisation of Systems Engineering processes for weapons systems.
- Modern defence acquisition (MOSA — Modular Open Systems Approach) uses Systems Engineering to define open interface standards enabling component substitution.

#### Automotive

- ISO 26262 (Functional Safety for Road Vehicles) embeds Systems Engineering in its hazard analysis and safety case processes; tightly coupled with [[Functional Safety]].
- Autonomous vehicle development relies on Systems Engineering to manage interactions between perception, planning, control, and [[Cyber-Physical Systems]].

#### Rail and Transport

- EN 50126/50128/50129 (RAMS — Reliability, Availability, Maintainability, Safety) standards for railway systems apply Systems Engineering lifecycle processes.

#### Large-Scale Software-Intensive Systems

- Cloud infrastructure platforms treat capacity planning, resilience engineering, and service mesh design as Systems Engineering problems.
- Integration with [[Distributed Systems]] design is critical where partial failures must be handled gracefully.

#### Robotics and AI Integration

- [[Robotics]] development — robot operating system (ROS)-based architectures are managed using Systems Engineering processes for sensor fusion, actuation, and safety interlocks.
- Deployment of [[Artificial Intelligence]] into safety-critical systems (e.g. medical devices, autonomous systems) requires Systems Engineering to define operational design domains, performance envelopes, and failure modes.

#### System of Systems

- [[System of Systems]] engineering extends the discipline to federations of independently operated systems (e.g. the internet of things, national infrastructure), where no single authority controls all elements.

### Standards and Context

- **ISO/IEC/IEEE 15288:2023** — Systems and Software Engineering: System Life Cycle Processes. The primary international standard defining lifecycle processes, outcomes, and activities for systems engineering. Harmonised with ISO/IEC/IEEE 12207 (software) and 15289 (documentation).
- **INCOSE Systems Engineering Handbook** (v5) — practical guidance from the International Council on Systems Engineering; widely used as a companion to 15288.
- **MIL-STD-499C** — US Department of Defense Systems Engineering standard; predecessor to the 15288 family; still referenced in legacy defence programmes.
- **ECSS Standards** (European Cooperation for Space Standardisation) — space-specific Systems Engineering standards used by ESA and European space industry.
- **ISO 26262** — [[Functional Safety]] standard for automotive electrical/electronic systems; embeds Systems Engineering in its safety lifecycle.
- **EN 50126/50128/50129** — RAMS standards for railway systems; Systems Engineering underpins the hazard and risk analysis process.
- **SysML v2** (OMG standard) — next-generation modelling language for [[Model-Based Systems Engineering]]; significant revision improving parametric and port/flow modelling.
- **TOGAF / DODAF / NAF** — enterprise and defence architecture frameworks that intersect with Systems Engineering at the architecture definition phase.
- **INCOSE** (International Council on Systems Engineering) — primary professional body; manages the CSEP/ESEP certification programme.
- **IEEE Aerospace and Electronic Systems Society** — publishes IEEE Transactions on Systems, Man, and Cybernetics.

### Provenance

